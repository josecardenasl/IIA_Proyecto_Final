# Grupo de danza urbana Movimiento danza​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Grupo de danza urbana Movimiento danza​

Director: Rafael Suárez

*    Grupo de Danza Urbana Movimiento Danza​ 

### Acerca de MD

El grupo de danza urbana Movimiento Danza de la Universidad EAFIT realiza montajes y trabajos basados en las diferentes danzas urbanas a nivel mundial como dancehall, hip hop, Funky, Breakdance, Breaking, Popping, House, Rocking, Bboying, Downroc entro otros. Este grupo realiza trabajos de puesta en escena basado en temáticas puntuales con un alto componente de impacto social.

###### Quienes hagan parte de Movimiento Danza podrán desa​rrollar:

La capacidad de introspección que generan los procesos de investigación y montajes que los lleva a un mayor auto reconocimiento.

La capacidad de permitirse preguntarse por lo que sea y emplear la danza como pretexto para indagar sobre ello.

La creatividad es otro proceso ya que el director los lleva a encontrar su parte creadora, en MD no solo monta coreografías el director, también hacemos procesos de creación colectiva.

Sin duda quien llega al grupo no se va tal cual como llego, afianza su danza, pero su ser también trasciende y crece como sujeto epistémico de cohesión. ​

Licenciado en Danzas y Fisioterapéuta, con experiencia de más de 15 años como creador artístico, coreógrafo, docente e intérprete. Desde hace 8 años se desempeña como director del grupo de Danza Urbana de la Universidad EAFIT y como docente de cátedra en el Departamento de Desarrollo Artístico.

Ha liderado proyectos de creación en entidades como Bumayé Compañía de Danza, Fábrica de galletas Noél, Universidad EAFIT y Colegio Alemán.

La imaginación, versatilidad e hibridación de conceptos y técnicas son valores que caracterizan su ejercicio profesional.

El Grupo de danza urbana de la Universidad EAFIT se crea a partir del Taller de Danza moderna, que por espacio de dos años mantuvo un trabajo constante, en el cual las coreografías del jazz y el pop fueron ganando vida propia. A partir del año 2001 el Taller desaparece y se crea el Grupo de proyección de danza moderna, dirigido por el bailarín Augusto Jaramillo, quien lo conforma y lo alienta hasta la llegada de su nuevo director, Roberto Sampayo, en el año 2002.

Posteriormente, a través de la expresión corporal y de la música que le da la nota a las nuevas generaciones, el Grupo, bajo la dirección de Diego Alejandro Londoño, puso de relieve los géneros del jazz, el pop, la música contemporánea y otras propuestas musicales, con una dirección susceptible de combinaciones dancísticas, y con el ánimo de lograr una diferente propuesta corporal en sus participantes para que fuera, además, un aporte humano e integral para su vida cotidiana.

Jaisson Restrepo haciendo un trabajo más inclinado hacía la danza urbana. Continua ​Rafael Suárez, quien es su actual director, profundiza en la exploración de la danza urbana, y desde 2014 Movimiento Danza reafirma su estilo urbano, buscando a través del arte transmitir mensajes con un sentido social. Temporadas como "Sin Etiquetas", "CAOS","Negadxs" y "Abraxas" han demostrado la habilidad del director y del Grupo para reflexionar y construir colectivamente en torno a problemáticas sociales como la discriminación y el posconflicto. De esta manera, Movimiento Danza ha expandido sus horizontes, usando la música urbana como vehículo para la difusión de ideas sociales frescas, llamativas, juveniles y transformadoras. Para el 2019 lideró la Revista de danza y baile bajo la temática de Mundos mágicos de Disney.

En el año 2021 y 2022 el grupo representa al Departamento de Antioquia en el Encuentro Nacional de Danzas Urbanas Ascun Cultura.

Todo participante que desee estar en Movimiento Danza, debe pasar primero por el semillero de danzas urbanas donde se realizará una evaluación de su conocimiento y desempeño para ser promovido. Una vez el Grupo cuente con la posibilidad de recibir nuevos integrantes, serán tenidos en cuenta quienes tengan y demuestren un mayor avance.

###### Horario y lugar de ensayo del grupo:

Martes y jueves de 6:00p.m. a 9:00 p.m.

Aula de ensayo de baile: 12-201​.

###### Semillero de danza urbana

Este espacio está creado para dar una formación en corporalidad que se alinee hacia los movimientos de la danza urbana, acercamiento a creación de figuras, movimiento, géneros de las danzas urbanas y trabajo en conjunto para el montaje de presentaciones.​​​

###### Ensayos del semillero

Viernes 2:00p.m. a 4:00 p.m. ​

Aula de ensayo de baile: 12-201.

##### Requerimientos técnicos y logísticos para presentaciones:

El espacio requerido para las presentaciones del Grupo es de mínimo 8mtrs x 8 mtrs., con piso en madera o baldosa, o en su defecto una tarima. No es conveniente bailar en pisos de granito o cemento porque se pueden presentar lesiones y problemas en las rodillas de los bailarines.

Adaptar cerca del lugar de la presentación un espacio cubierto con área suficiente para 20 personas y el vestuario correspondiente de cada una de ellas.

Si la presentación es en la noche se requieren luces para el espectáculo.

Transporte ida y regreso.

Brindar refrigerio e hidratación a cada uno de los integrantes del Grupo.

Garantizar una buena amplificación de sonido que incluya mínimo dos retornos.

Debe realizarse montaje y ensayo de sonido, mínimo 30 minutos antes de la presentación del Grupo.

Empezar el programa a la hora señalada, para cumplir con el tiempo de presentación del grupo, dado que los integrantes son en su mayoría estudiantes, que deben cumplir con otros compromisos académicos.

Contar con un presentador que haga la respectiva presentación del Grupo, o posibles intervenciones a lo largo de la presentación y el cierre de la misma al finalizar.​

**Cualquier información adicional, será atendida en el correo**[dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co).

### En acción​

## Síguenos en nuestras redes sociales

### Facebook

### Instagram

### X

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate