**1. Objetivo**

Con el propósito de contar con un instrumento que recopile los lineamientos que regulen las actividades culturales, artísticas y recreativas ofrecidas por los Grupos de expresión artística de la Universidad EAFIT, se establece el presente documento.

**2. Campo de aplicación**

Esta política se aplicará a todos los Grupos de expresión artística pertenecientes al Departamento de Desarrollo Artístico de la Universidad EAFIT.

**3. Competencia**

Desarrollo Artístico es el departamento encargado de ejecutar todo el proceso relacionado con los Grupos de expresión artística de la Universidad EAFIT.

**4. Aspectos Generales**

1.   **Definiciones:** las presentes definiciones sirven para dar un mayor entendimiento a los destinatarios de la misma. 

**Grupos de expresión artística:** Son aquellos que buscan proyectar a la Universidad en presentaciones dentro y fuera del campus, así como la participación en festivales e invitaciones especiales, todas ellas de carácter cultural y en ningún momento de recreación comercial. Los Grupos de expresión artística serán conformados exclusivamente por integrantes de la comunidad universitaria, entendiendo por estos estudiantes activos de pregrado y posgrado, empleados, jubilados y egresados de la Universidad.

Los Grupos de expresión artística también cuentan con categoría infantil, los cuales serán conformados por hijos, hermanos, sobrinos o nietos de empleados, egresados, estudiantes y jubilados de la Universidad EAFIT.

**Inscripción:** Es la manifestación expresa y formalizada, por parte del integrante de la comunidad universitaria, de su interés para ingresar a uno de los Grupos de expresión artística. Esta inscripción se realizará en las fechas que establezca el Departamento de Desarrollo Artístico conjuntamente con el aval de cada director del Grupo de expresión artística y se podrá tramitar a través del sistema designado por la Universidad EAFIT para tales efectos, el cual se podrá consultar con el Departamento de Desarrollo Artístico.

La inscripción a un Grupo de expresión artística no genera la obligación para la Universidad de capacitar o instruir a los integrantes del Grupo en el desarrollo de las aptitudes técnicas o artísticas requeridas.

**Integrante:** Aquellos integrantes de la comunidad universitaria (estudiantes activos de pregrado y posgrado, empleados, jubilados y egresados) que de forma libre y voluntaria, y cumpliendo con las condiciones de ingreso y permanencia establecidas en la presente política, se inscriban a alguno de los grupos de expresión artística.

De manera excepcional se permitirá que personas diferentes a las anteriormente enunciadas hagan parte de los Grupos de expresión artística, previa autorización del Jefe del Departamento de Desarrollo Artístico, quien evaluará con el Director del respectivo Grupo la pertinencia de la aceptación del integrante.

**Requisitos de ingreso:** Cada grupo de expresión artística podrá determinar y establecer demostración de aptitudes o requisitos para el ingreso y la permanencia en el mismo.

**5. Derechos y obligaciones de los integrantes del Grupo de expresión artística**

Los integrantes de los Grupos de expresión artística tendrán durante su permanencia en estos, los siguientes:

**5.1. DERECHOS**

1.   A utilizar las instalaciones del campus que el Departamento de Desarrollo Artístico gestione, en los horarios estipulados para ello, siguiendo las normas de convivencia y las consagradas en esta política.
2.   A tener una comunicación directa y permanente con el personal del Departamento de Desarrollo Artístico.
3.   A participar y representar a la Universidad EAFIT, por intermedio del Grupo en el que esté inscrito, en eventos artísticos, culturales o recreativos a los que sea invitada la Institución.
4.   A tener acceso a un buzón de quejas y sugerencias.
5.   A ingresar a los Grupos de expresión artística sin costo.

**5.2 OBLIGACIONES**

1.   Utilizar correctamente las instalaciones, vestuario, equipos y mobiliario dispuesto por el Departamento de Desarrollo Artístico, evitando actos que los deterioren.
2.   Asistir cumplidamente a los ensayos y/o reuniones y presentaciones que sean programados por los directores de cadaGrupo de expresión artística, en el horario y lugar asignado para ello.
3.   Cumplir con las directrices universitarias en las salidas de campo.
4.   Mantener un trato respetuoso y educado.
5.   Reportar inmediatamente cualquier accidente o lesión, personal o de algún integrante, al personal encargado.
6.   Responder por los daños personales y/o materiales que pudiera producir a otros integrantes o miembros del personal, cuando se comporte en contravención al presente político o de forma negligente, o actué con dolo.
7.   Respetar los horarios establecidos para el uso de las instalaciones de Desarrollo Artístico.
8.   Respetar los lineamientos establecidos por cada uno de los grupos de expresión artística.
9.   Informar sobre posibles infracciones a los derechos de autor cuando de alguna presentación o proyecto se trate. Así mismo, informar al Departamento de Desarrollo Artístico sobre los derechos morales y patrimoniales que le pertenezcan por alguna obra presentada como propia por el grupo de expresión artística del que sea parte.
10.   Mantener un comportamiento adecuado en los eventos o salidas de campo en los que se esté representando a la Universidad.
11.   Usar un lenguaje apropiado, evitando referirse a los demás de forma grosera o soez.
12.   Usar un volumen de voz apropiado para el lugar.
13.   Evitar en todo momento el comportamiento inadecuado, procurando mantener el orden. No realizar juegos o bromas que perturben el correcto desarrollo de las actividades.
14.   Abstenerse de ingresar bebidas alcohólicas, sustancias alucinógenas o psicotrópicas, o ingresar bajo el efecto de ellas.
15.   Respetar en todo momento las pertenencias personales de los demás integrantes de los Grupos de expresión artística.
16.   Mantener actualizados sus datos personales en el sistema de información dispuesto para ello por la Universidad EAFIT.

**6. Horario y reglas específicas de uso de las instalaciones**

El Departamento de Desarrollo Artístico establecerá la periodicidad y los horarios en los que cada Grupo de expresión artística se reunirá a desarrollar sus actividades. En temporadas especiales, como vacaciones, Festival de la canción, encuentros, entre otros, estos horarios podrán ser modificados.

Los grupos de expresión artística se reunirán en horarios previamente definidos para cada semestre académico, los cuales serán publicados en la página web de la Universidad.

**7. Propiedad intelectual**

Las obras artísticas y literarias que se produzcan por los integrantes de los grupos de expresión artística pertenecen a los creadores de éstas en proporción a sus aportes. Sin perjuicio de lo anterior, en calidad de titulares de derechos de las obras artísticas y literarias, autorizan a la Universidad EAFIT, a título gratuito, de manera total, sin limitación alguna y en un ámbito a nivel mundial, por un periodo de tiempo indefinido, para su uso, adaptación, reproducción, comunicación pública y exhibición en cualquier medio conocido o por conocer, en aras de que la Institución pueda dar cuenta de las obras y presentaciones artísticas realizadas por cada uno de los Grupos.

**8. Participación y premios en competencias o concursos**

Los integrantes de los Grupos no recibirán remuneración alguna por parte de la Universidad EAFIT por su participación en competencias o concursos en representación de la institución y no tendrán derecho sobre los pagos que sean realizados por concepto de exhibiciones, presentaciones y cualquier clase de evento artístico, cultural o de entretenimiento que se haga en representación de la Universidad.

Los premios otorgados a los Grupos de expresión artística de la Universidad EAFIT por concepto de participación en concursos, exhibiciones, presentaciones y cualquier clase de evento artístico, serán propiedad de la Universidad EAFIT y estarán destinados al centro de costos del Departamento de Desarrollo Artístico, encargado de administrarlos.

La participación en eventos por parte de alguno de los Grupos de expresión artística requerirá de la aprobación del Departamento de Desarrollo Artístico. Los integrantes y directores de los Grupos no podrán comprometer la participación de los mismos, ni aceptar invitaciones para ello, sin la previa autorización del Departamento de Desarrollo Artístico.

**9. Retiro Temporal**

Los integrantes de los Grupos de expresión artística podrán solicitar al Departamento de Desarrollo Artístico un retiro temporal no superior a un semestre académico. El retiro temporal se sujetará a los siguientes parámetros:

Se debe solicitar en medio escrito al correo: dllo.artistico@eafit.edu.co y a más tardar hasta la tercera semana de encuentros o ensayos del respectivo grupo.

La solicitud estará supeditada al plan de trabajo de cada Grupo y en caso de afectar el desempeño artístico del mismo, esta podrá ser negada por el jefe del Departamento o el director del Grupo.

En caso de aprobar la solicitud de retiro temporal, el Departamento de Desarrollo Artístico conservará al integrante como inscrito en el sistema, anotando en el campo Observaciones la fecha en la cual el integrante deberá reintegrarse a las actividades.

Si al vencimiento del periodo de retiro temporal el integrante no se reintegra a las actividades del Grupo, se entenderá como abandono al Grupo y en consecuencia será retirado del sistema.

**10. Exclusión de responsabilidad**

La participación en los Grupos de expresión artística de la Universidad EAFIT es voluntaria, por lo tanto, los integrantes lo hacen de forma libre, asumiendo los riesgos inherentes a la actividad que realicen.

Los integrantes expresamente aceptan que al inscribirse al Grupo de expresión artística lo hacen bajo su propia responsabilidad y riesgo, aceptando conocer la presente política, y en el expreso entendido de que la Universidad EAFIT no responde en ninguna circunstancia por daños o perjuicios de cualquier naturaleza que los inscritos pudieren sufrir.

**11. Régimen disciplinario**

Los Grupos de expresión artística se rigen, de forma general, por los lineamientos previstos en los reglamentos institucionales vigentes y, de forma específica, por esta política.

Los integrantes de los Grupos que no cumplan con lo aquí estipulado o con los reglamentos institucionales, podrán ser retirados del Grupo de expresión artística al que pertenezcan a decisión del Departamento de Desarrollo Artístico.

La ausencia injustificada por el integrante a más de tres (3) reuniones o presentaciones, dará lugar a que sea retirado del Grupo de expresión artística al que pertenece.

**12. Salidas de campo**

El recorrido de ida al lugar de la actividad, como el viaje de regreso a la Universidad, así como todo trayecto intermedio necesario para su cabal desenvolvimiento, forman parte integral de la salida de campo, y quedan en consecuencia cobijados esas salidas tanto por el Reglamento Estudiantil general de la Universidad, como por el acatamiento a las políticas aquí estipuladas.

El comportamiento de cada integrante en la totalidad de la actividad realizada en representación de los Grupos de expresión artística dentro y fuera de los predios de la Universidad ha de ser el mismo que guarde toda persona en el interior de las instalaciones de la Universidad.

El Director a cargo de la correspondiente actividad es la máxima autoridad académica y disciplinaria en la totalidad de la misma. Es deber de todo integrante acatar sus indicaciones y contribuir para que los demás las acaten. A la vez, es deber de dicho Director velar permanentemente y estar alerta para conservar la armonía y velar por el buen comportamiento de todos los integrantes, paralelamente con la obtención de los objetivos de la correspondiente actividad.

El consumo de sustancias alcohólicas y alucinógenas queda expresamente prohibido en toda actividad artística realizada dentro y fuera de los predios de la Universidad. También queda expresamente prohibido porte de armas en esas actividades. Es deber del Director que esté a cargo de la actividad en la que se presentaren hechos anómalos, lo mismo que de todo participante en la misma, informar por escrito y de manera pronta y detallada al Jefe del Departamento de Desarrollo Artístico sobre dichas situaciones.

En los casos en los que la Universidad ponga a disposición del Grupo de expresión artística un vehículo que facilite el transporte a la presentación, el conductor del mismo queda expresamente facultado para impedir el ingreso al vehículo a todo integrante que intente agredir de palabra o de hecho, con o sin armas, a otro integrante o a extraños, así como para aquel que intente ingresar con sustancias alcohólicas, sustancias alucinógenas, o estar bajo el efecto de alguna de ellas, o pretenda ingresar con armas.

Sólo tendrán acceso al vehículo aquellas personas debidamente inscritas o citadas para la correspondiente actividad, y que, para salidas por fuera del área metropolitana de Medellín, hayan firmado la carta de exoneración de responsabilidad suministrada por Departamento de Desarrollo Artístico.

Los integrantes deberán contar con afiliación vigente a una EPS, en calidad de cotizante o beneficiario, para poder participar de las salidas, por tanto, la Universidad se exonera y exime de todos los gastos derivados de la atención médica y hospitalaria.

Los integrantes deberán acreditar su afiliación al sistema de salud, tanto en el momento de organizar la salida, como al momento de salir. De igual forma los asistentes a la salida deberán portar en todo momento sus documentos de identidad, incluyendo el respectivo carnet que acredita su vínculo con la Universidad.

Los integrantes, en caso de causar daños a terceros o a la Universidad, deberán indemnizar los perjuicios ocasionados por su comportamiento.

**13. Incumplimiento**

El incumplimiento de los lineamientos establecidos en el presente documento acarreará la expulsión temporal o permanente del Grupo de expresión artística, así como la aplicación de sanciones de orden disciplinario a que hubiere lugar en caso de incumplimiento de los Política s de la Universidad.

El procedimiento para establecer los incumplimientos a los que se refiere el presente capítulo garantizará el debido proceso consagrado constitucionalmente.

**14. Vigencia**

La política aquí establecida rige a partir de su promulgación.

**15. Efectos**

Desde la fecha en que entra en vigencia el presente documento, quedan sin efecto las disposiciones, política s o manuales que se hubiesen podido adoptar con anterioridad sobre el mismo objeto.

**16. Situaciones no previstas**

Cualquier situación no prevista en el presente documento será resuelta por Desarrollo Artístico.

**17. Promulgación**

La difusión y promulgación de la presente política estará a cargo de Desarrollo Artístico, quien a su vez será el encargado de resolver las dudas que se deriven de su aplicación.

**Universidad EAFIT**

Marzo 2020