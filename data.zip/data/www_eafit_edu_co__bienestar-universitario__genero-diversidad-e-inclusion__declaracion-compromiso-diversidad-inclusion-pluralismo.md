# Declaración de nuestro compromiso con la diversidad, la inclusión y el pluralismo - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Declaración de nuestro compromiso con la diversidad, la inclusión y el pluralismo

*    Declaración de Nuestro Compromiso Con La Diversidad, La Inclusión y El Pluralismo 

###### En EAFIT cultivamos lo humano, y con ello el valor de lo único, lo diverso y lo plural

Nos encontramos construyendo comunidad en la empatía y la solidaridad, abriendo puertas para que desde nuestras capacidades podamos ofrecer oportunidades para todas las personas.​

Nos declaramos en aprendizaje permanente, creando espacio con nuestras ideas, decisiones y acciones a todas las manifestaciones de la experiencia humana, haciendo de la inclusión un proceso proactivo e intencionado, que empiece por retar la indiferencia y que permita que cada integrante de esta comunidad se sienta parte esencial de ella.

Rechazamos cualquier forma de exclusión y de violencias que vulneren la integridad y el respeto que emana del hecho común de ser seres humanos.El camino de la inclusión, el pluralismo y la diversidad es nuestra elección por la cocreación y la libertad.

## ​Conoce nuestra Área​ de Gén​ero, Diversidad ​e I​nclusión ​y nuestros protocolos para una vida libre de violencia y discriminación ​+

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)