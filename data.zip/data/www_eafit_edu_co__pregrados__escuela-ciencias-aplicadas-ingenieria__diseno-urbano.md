# Diseño Urbano - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Pregrado

# Diseño Urbano y Gestión del Hábitat

SNIES 109454, Medellín

Aquí aprenderás a diseñar y gestionar ciudades y territorios en armonía con la naturaleza y las personas. Enfrentamos el reto de vivir en un planeta cada vez más urbano, donde más de la mitad de la población vive en ciudades que se expanden aceleradamente y, al hacerlo, producen impactos ecológicos y sociales. Hoy sabemos que esas urbes deben diseñarse y construirse con criterios que apunten al bienestar no solo de los humanos, sino de todas las formas de vida que conviven en ellas.

En el pregrado de Diseño Urbano más que aprender a diseñar casas, espacios interiores o proyectos arquitectónicos, se aprende a pensar, comprender, diseñar y transformar ciudades y territorios sostenibles desde parques, infraestructuras de gran escala, proyectos urbanos y de movilidad, aplicando conocimientos como la arquitectura, el diseño y el urbanismo en conexión con disciplinas interdisciplinares como ecología, geología, ingeniería, artes, sociología, ciencias políticas, derecho, economía, administración, entre otros.

Los diseñadores urbanos de EAFIT entienden las problemáticas ambientales, espaciales y de comunidades, de políticas y de reglamentación-normativa, y usan estos saberes para proyectar y diseñar soluciones integrales sostenibles que inciden en mejorar la calidad de vida de los habitantes de las ciudades y territorios. Su campo de acción laboral es muy amplio y pueden escoger desempeñarse en el sector público o privado, en el mundo de la investigación y academia, en el sector solidario y de cooperación internacional, consultorías independientes como asesores o emprendedores, además de entidades que consideran que los espacios urbanos del mundo son su hogar.

Si te gustan las ciudades, eres un gomoso del dibujo, te gusta hacer maquetas o tomar fotografías, en el programa de Diseño Urbano desarrollarás tus habilidades de diseño, aprenderás a pensar, comprender, diseñar y transformar ciudades y territorios… que, al final, son tu aula de clase.

*    Escuela Ciencias Aplicadas Ingenieria 
*    Diseño Urbano y Gestión del Hábitat 

## Registro calificado

Resolución 016543 del 9 de septiembre de 2020. Vigencia: 7 años

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 109454

Valor del primer semestre

$15.442.901

Valor promedio de los semestres

$14.413.374

Becas y financiación

## Sobre el programa

Calidad y excelencia

**Somos top en el mundo**

Este pregrado tiene el respaldo académico del Centro de Estudios Urbanos y Ambientales URBAM de la Universidad EAFIT, un laboratorio de investigación, formación, formulación y ejecución de proyectos que, a través de la experiencia acumulada de 15 años, ha reflexionado sobre los procesos urbanos y ambientales, y ha actuado en contextos emergentes y en transformación.

Somos el primer pregrado en Latinoamérica en tener convenio de doble titulación con el Tecnológico de Monterrey.

Doble Titulación

El pregrado en Diseño Urbano tiene Doble Titulación con el Tecnológico de Monterrey.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

Nuestra Escuela cuenta con el respaldo de un gran ecosistema de laboratorios: tenemos 43 de ellos equipados con infraestructura de última generación.

Contamos con un bloque nuevo completamente equipado para las ciencias aplicadas y la ingeniería, construido con la idea de generar bajo impacto ambiental, y diseñado para ser sostenible con el uso eficiente de la energía, el cuidado del aire, la gestión de residuos y la movilidad. Todo integrado al trabajo de investigadores, estudiantes en semilleros y jefes de laboratorio, configurando un verdadero engranaje de investigación y aprendizaje abierto y a disposición de la comunidad estudiantil.

Nuestro campus es un espacio vivo, activo y natural, y un escenario de experimentación y aprendizaje para los temas de biología, diseño y urbanismo, entre otros.

Contamos también con un laboratorio propio para el pregrado de Diseño Urbano, diseñado especialmente para crear colaborativamente distintos escenarios de aprendizaje.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: lo mejor de la academia, la ciencia y las artes converge en EAFIT. Asimismo, ocurre en Urbam, donde estamos conectados con las agendas de la ciudad y proponemos diálogos improbables con actores del territorio, comunidades y académicos.

**Somos actor clave de una ciudad universitaria.**

Medellín ocupa el segundo puesto como la mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año, EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Este pregrado está en constante fricción con la realidad. Las expediciones a los territorios y los barrios son nuestra principal aula de clase, nos permiten conocer, caminar y palpar situaciones y problemas reales, y atraer distintos conocimientos, saberes y metodologías en busca de soluciones desde el diseño y la gestión.

En cada semestre, se viven espacios centrales donde profesores de distintas áreas de conocimiento (ecología, geología, sociología, antropología, ciencias políticas, derecho, economía, administración, ingeniería, arquitectura, urbanismo, artes y diseño) buscarán dar respuesta a los problemas latentes de la sociedad de manera más integral y participativa, de la mano de los actores principales del territorio (comunidad, sector público y sector privado) para trabajar colectivamente.

Nuestra Escuela será la primera en implementar las trayectorias profesionales. Estos son caminos educativos configurados por los estudiantes para posibilitar la homologación, el doble título o un posgrado que quieran cursar.

El pregrado de Diseño Urbano se vincula a las líneas de énfasis existentes en la universidad, debido al amplio campo disciplinario del programa que permite a los estudiantes explorar y profundizar sus intereses en distintos campos de conocimiento.

Puedes aplicar a la maestría en Procesos Urbanos y Ambientales y titularte como magíster con solo un año más de estudios.

Innovación y liderazgo

**Somos innovación en educación**

La innovación educativa de este pregrado implica la enseñanza y el aprendizaje del conocimiento a través de alternativas tales como: el pensamiento sistémico y la sinergia de saberes; la inter y la transdisciplinariedad; los “aprendizajes por fricción” con las realidades territoriales; el aprendizaje experiencial; la formación integral, bajo la premisa de la educación para el desarrollo sostenible; la reflexión crítica, y la acción creativa por medio del currículo modular. Este último representa nuevas oportunidades para el aprendizaje y la creación de conocimientos, lo mismo que el desarrollo de competencias o capacidades requeridas para promover la sostenibilidad de los sistemas urbanos y lograr el bienestar de sus habitantes.

Al analizar la oferta académica de formación profesional que Colombia y el mundo presentan en los campos y áreas del conocimiento similares, este pregrado surge como una innovación educativa y profesional única que afronta los desafíos urbanos, ambientales y sociales, y las tendencias interdisciplinares de la educación, en busca de promover el bienestar y la sostenibilidad de los asentamientos humanos del presente y el futuro.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. Además, tienen una formación multidisciplinaria gracias a las cinco escuelas de EAFIT y a las áreas de conocimiento que las componen.Además, el 73% de nuestros profesores de planta tienen doctorado.

**Cultivamos el liderazgo temprano y la investigación**

Estos futuros profesionales en Diseño Urbano y Gestión del Hábitat serán íntegros, empáticos y pluralistas. Actuarán con criterio ético y responsabilidad social y ambiental; serán propositivos, creativos, innovadores y trabajarán colaborativamente y de manera transdisciplinar ante situaciones complejas y de incertidumbre. Por lo que se formarán para actuar con responsabilidad y liderazgo, en busca de la excelencia y el aprendizaje continuo como agentes de transformación de los territorios.

Tenemos una conexión directa con la Maestría en Procesos Urbanos y Ambientales para que los estudiantes del pregrado de Diseño Urbano comiencen tempranamente sus procesos de investigación y de liderazgo seleccionando la línea de énfasis de la maestría para avanzar en sus estudios de posgrado.

En EAFIT tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Como Escuela, tenemos más de 20 grupos de investigación y más de 60 semilleros enfocados en la experimentación y el desarrollo de tecnologías prácticas.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Este pregrado nace en Urbam, el Centro de Estudios Urbanos y Ambientales, que promueve procesos en los que el conocimiento técnico de lo urbano se conjuga con el saber de las comunidades, transformando el paisaje y las infraestructuras a favor de la sostenibilidad. Esto les permite a nuestros estudiantes tener contacto permanente con la realidad, con voces expertas de la arquitectura, el diseño y el urbanismo, líderes de opinión pública y profesionales en cargos de decisión en la ciudad y en el país. Además, le da una importancia a las expediciones y metodologías de aprendizaje que involucran experimentar la calle, los territorios y relacionarse con actores clave.

Contamos con la posibilidad de doble titulación en el Tecnológico de Monterrey. Convenio con la Red Andes Pacífico, además de todas las alianzas que han desarrollado Urbam y EAFIT en el mundo. Gracias a esto, hemos recibido estudiantes de intercambio de Francia, Canadá y México.

Trabajamos de la mano con NODO, el centro de formación en tecnologías de EAFIT, un espacio donde se transforma el talento y se pone al servicio de los retos reales de las organizaciones, creando procesos de aprendizaje práctico y exponencial en temas relacionados con desarrollo web.

Disponemos de una revista de Ingeniería y Ciencia que presenta y difunde trabajos de investigación básica y aplicada que contribuyen al desarrollo de la tecnología, la ciencia y la industria.

Contamos con un Centro de Estudios e Incidencia, Valor Público y con un espacio de innovación y desarrollo social: EAFIT Social.

En EAFIT, tenemos una línea especial de Gerencia y Empresa que presta consultoría y, también, a ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad, tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

**Somos una puerta al mundo**

Como Universidad, contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrado han empezado sus emprendimientos. Doce de ellos están en la lista de las 100 mejores start-ups de Colombia.

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Pruebas Saber Pro

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Geología

Duración

9 semestres

Lugar

Medellín

Horario 

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES: 1251

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$16.060.617

Becas y Financiación

#### Ingeniería Civil

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1247

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$15.786.076

Becas y Financiación

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Con más de 700 organizaciones aliadas, así se expande la relación de EAFIT con las empresas

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)