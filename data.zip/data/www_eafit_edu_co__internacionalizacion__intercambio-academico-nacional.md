# Intercambio académico nacional - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Intercambio académico nacional

Conoce los pasos para participar en la movilidad nacional saliente en instituciones que tienen convenios vigentes con la Universidad EAFIT.

*    Intercambio Académico Nacional 

#### **Convocatorias**

Para participar debes postularle en la convocatoria correspondiente:

## Primer semestre del año

Agosto 22 - octubre 8

## Segundo semestre del año

Marzo 01 - abril 02

###### **Conoce los pasos que debes seguir**

1. Asiste a una charla informativa

Consulta las fechas escribiendo un correo a [**movilidadnacional@eafit.edu.co**](mailto:movilidadnacional@eafit.edu.co)

2. Elige tu universidad de destino

Verifica haciendo clic [**aquí**](https://app.powerbi.com/view?r=eyJrIjoiYjVmNTk3M2YtMjdmZi00MDI2LWFiZWItZDJhMWZkOTEyNjdlIiwidCI6Ijk5ZjdiNTVlLTljYmUtNDY3Yi04MTQzLTkxOTc4MjkxOGFmYiIsImMiOjR9) los convenios vigentes para realizar tu movilidad nacional.

3. Reúne los siguientes documentos

1.   Formulario de aplicación:

1.   Plan Académico: se genera en EPIK a través de “progreso académico”.
2.   Certificado de afiliación a seguro médico.
3.   Fotocopia del documento de identidad.
4.   Foto reciente a color.

4. Aplica

Aplica a tu intercambio a través de la plataforma de movilidad nacional. En los siguientes enlaces encontrarás las instrucciones en donde te enseñamos cómo aplicar y cuáles notificaciones recibirás durante el proceso. Para acceder a los instructivos debes iniciar sesión con tu cuenta de EAFIT.

1.   Diligenciar y enviar el formulario de aplicación: [**Ver el PDF instructivo.**](https://universidadeafit.widen.net/s/pqxnkmvq7x/instructivo-aplicacion--diligenciar-y-enviar-el-formulario-de-aplicacion-1)
2.   Comprender las notificaciones del proceso y la actualización del acuerdo académico. [**Ver el PDF instructivo.**](https://universidadeafit.widen.net/s/t5njdqdc5m/instructivo--comprender-las-notificaciones-del-proceso-y-la-actualizacion-del-acuerdo-academico-1)

##### Requisitos

Para realizar una movilidad nacional debes cumplir con las siguientes características:

Matrícula

Estar matriculado y ser estudiante activo de un programa de pregrado o posgrado.

Promedio

Contar con un promedio crédito acumulado igual o superior a:

*   Pregrado: 3.5
*   Posgrado: 4.0

Semestre

Cumplir con el semestre mínimo requerido, de acuerdo con el tipo de convenio:

*   Bilateral y 4U: Mínimo cuarto (4) semestre (equivalente al 40% de los créditos totales del programa).
*   Sígueme: Mínimo tercer (3) semestre.

Autorización del jefe del programa

Cuenta con la autorización del jefe/ coordinador de programa y la asesoría de las asignaturas a cursar.

Pago de la matrícula

Pagar los derechos de matrícula en la Universidad EAFIT.

Sanciones disciplinarias

No estar en proceso o bajo sanción disciplinaria.

Requisitos adicionales

Las universidades de destino pueden establecer, de manera general, algún requisito adicional. Esta información se suministra durante el proceso de aplicación.

## Contacto

Movilidad Nacional[movilidadnacional@eafit.edu.co](mailto:movilidadnacional@eafit.edu.co)

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate