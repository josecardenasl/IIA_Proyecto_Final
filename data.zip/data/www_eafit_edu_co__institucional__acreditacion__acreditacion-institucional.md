# Acreditación Institucional

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Nuestras Acreditaciones

*    Nuestras Acreditaciones 

## Calidad en EAFIT - Trayectorias

###### Acreditación

###### Institucional

###### Acreditación de

Programas ​Académicos

En 1997 la Universidad se inscribió al Sistema Nacional de Acreditación con siete programas de pregrado. Luego de que se aceptó la inscripción al Sistema, se inició un proceso de autoevaluación, que continuó con las demás etapas necesarias para la acreditación institucional.

En 2003, EAFIT obtuvo su primera Acreditación Institucional por seis años, lo que la convirtió en esa época en la primera institución privada de Antioquia en lograr este reconocimiento público a la alta calidad que hace el Estado. [Resolucion número 2086 del 5 de septiembre de 2003](https://universidadeafit.widen.net/s/ll2zwftdwr/resolucion-acreditacion-institucional-2086-2003).

Uno de los logros más significativos es que a través de la [Resolución número 1680 del 16 de marzo de 2010](https://universidadeafit.widen.net/s/vlqctdmld6/renovacion-acreditacion-inst-res-1680-2010),​ expedida por el Ministerio de Educación Nacional, la Universidad EAFIT fue la primera en recibir la renovación de la Acreditación Institucional de alta calidad por ocho años más. "EAFIT obtuvo esta distinción con honores", dijo Cecilia María Vélez White, ministra de Educación Nacional de la época, al referirse a este logro alcanzado por la Universidad EAFIT.

En 2018 se renovó la acreditación institucional hasta 2026, EAFIT preservará el reconocimiento de la alta calidad, así lo indicó el Ministerio de Educación Nacional (MEN) al acoger el concepto favorable del Consejo Nacional de Acreditación (CNA) y renovar, por ocho años más, la Acreditación Institucional de EAFIT mediante la [Resolución 2158 del 13 de febrero de 2018](https://universidadeafit.widen.net/s/gnplvvfrv6/resolucion-2158-2018-acreditacion-institucional).

#### Documentos de Acreditación Institucional

​​2003 - 2009​

###### ​​2003 - 2009​

2010 - 2018

###### 2010 - 2018

​2018 - 2026

###### ​2018 - 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)