# Horarios de entrenamiento - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 4: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Horarios de entrenamiento

Deporte Representativo competitivo 2026-1. ​​​​​​​​​​Para estudiantes de pregrado y posgrado, empleados y graduados.

*    Horarios de Entrenamiento 

## Conoce el proceso de convocatoria para quienes desean hacer parte de nuestros equipos competitivos

**Entrenador:** ​Jeison Asprilla​

**Horarios:**

Lunes - 12:00 m.

Miércoles - 2:00 p.m.

Sábado - 10:30 a.m.

**Gimnasio al aire libre**

**Entrenador:**Milena Restrepo​

**Horarios:**

Martes - 6:00 p.m.

Jueves - 4:00 p.m.

**Pista atlética**

**Entrenador:** Luis Guillermo Blandón

**Horarios:**

Martes - 10:00 a.m.

​Jueves y viernes - 1:00 p.m.

**Salón de Bienestar - Bloque 26.**

**Entrenador:** Milena Restrepo Agudelo​​

**Horario:** Martes, miércoles y viernes 10​:00 a.m.

**Pista atlética**

**Entrenador:**Milena Restrepo Agudelo

**Horario:** Martes, miércoles y Jueves - 12:00 m ​

**​Pista atlética**

**Entrenador:** Jeyson A. Asprilla

**Horarios:**

Lunes, miércoles y viernes - 5:00 p.m.

**Placa cubierta**

**Entrenador:** Juan David Marín Ossa

**Horarios:**

Martes y jueves: 5:30 p.m.

Viernes: 2:00 p.m.

**Placa cubierta**

**Entrenador:**Juan David Marí​n Ossa

**Horario:** Lunes y miércoles - 7:30 p.m.

**Placa cubierta**

**Entrenador:** Julian Villa

**Horarios:**

- Lunes 2:00 p.m.​

- Miércoles 9:00 a.m. mixto

- Jueves 1:00 p.m

**Placa sintética No. 1**

**Entrenador:** Julian Villa

**Horarios:**

Martes y jueves - 6:00 p.m.

Miércoles mixto - 9:00 a.m.

**Placa sintética No. 1**

**Entrenador:**Yina P.Cartagena Muñoz

**Horarios:**

Lunes - ​12:00 m.

**Cancha sintética**

Miércoles - ​12:00 m.

**Cancha de grama**

Viernes (mixto) - 2:00 p.m.

**Cancha de sintética​**

**Entrenador:** Yina Cartagena Muñoz

**Horarios:**

Lunes - 2:00 p.m.

**Cancha sintética**

Miércoles - 2:00 p.m.

**Cancha de grama**

Viernes (Mixto) - 2:00 pm

**Cancha Sintética**

**Entrenador:** Katherine García Ospina

**Horarios:**

Martes - 12:00 p.m.

Miércoles* 5:00 pm. ​

Viernes - 8:00 a.m.

**​Cancha de grama**

***Cancha sintética​ de Itagüí**

**Entrenador:** Diego Sanabria González

**Horarios:**

Martes - 7:00 p.m.

Miércoles* - 12:00 m. ​

Jueves - 5:00 p.m.

Viernes* - 12:00 m.

**​Cancha de grama**

***Cancha sintética​**

**Entrenador:** Carlos Sánchez Valencia

**Horario:**

Lunes y miércoles - 7:00 p.m.

**Cancha de grama**

**Entrenador:** Cristian Salazar Gallego

**Horario:**

Lunes y jueves ​- 12:00 m.

**Cancha de grama**

**Entrenador:** Christian Henao Restrepo

**Horario:**

Lunes, miércoles y viernes - 5:00 p.m.

​​​ 

**Placas sintéticas**

**Entrenador:** Christian Henao Restrepo

**Horario:**

Lunes y miércoles - 7:00 p.m.

**Placas sintéticas ​**

**Entrenador:** Fernando A.Espinosa Estrada

**Horario:**

Lunes, miércoles y viernes - 2:00 p.m.

**Salón de artes marciales - Coliseo menor Los Guayabos**

**Entrenador:** Richard David Lopez

**​Horario:**

Martes, miércoles, jueves y viernes - 7:30 a.m.

**​Piscina**

**Entrenador:**Andrés Giovany Ruiz Colorado​

**Horarios:**

Martes y Jueves - 6:00 p.m.

Sábado - 11:00 a.m.

**Salón de artes marciales - Coliseo menor Los Guayabos​**

**Entrenador:** M. Catalina Ramírez Martínez

**Horarios:**

Lunes y miércoles - 12:00 m​.

Viernes (Mixto) - 12:00 m.

**Placas sintéticas**

**Entrenador:** M. Catalina Ramírez Martínez

**Horarios:**

Martes y jueves - 9:00 a.m.

Viernes(Mixto) - 12:00 m.

**Placas sintéticas**

**Entrenador:** M.Catalina Ramírez Martínez

**Horario:**

Lunes y miércoles - 12:00 m.

**Placas sintéticas**

**Horario:**

Lunes y miércoles 12:00 m.

Viernes 10:00 a.m.

**Salón de tenis de mesa - Coliseo os Guayabos**

**​Horario:**

- Lunes 8:00 a.m.

-Miércoles 9:00 a.m.

-Viernes 7:00 a.m.

**Placa cubierta​**

**​Entre​nador:**Anderson Henao

**Horarios:**

Martes y jueves - 7:30 p.m.

Viernes - 9:00 am.

**Placa cubierta**

## Políticas de deportes representativos competitivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate