# Universidad EAFIT - Wikipedia, la enciclopedia libre

- [x] Menú principal 

Menú principal

mover a la barra lateral ocultar

 Navegación 

Buscar

- [x] Apariencia 

- [x] Herramientas personales 

## Contenidos

mover a la barra lateral ocultar

*   [1 Historia](https://es.wikipedia.org/wiki/Universidad_EAFIT#Historia)Alternar subsección Historia

*   [2 Identidad](https://es.wikipedia.org/wiki/Universidad_EAFIT#Identidad)Alternar subsección Identidad

*   [3 Campus y sedes](https://es.wikipedia.org/wiki/Universidad_EAFIT#Campus_y_sedes)Alternar subsección Campus y sedes

*   [4 Estructura académica](https://es.wikipedia.org/wiki/Universidad_EAFIT#Estructura_acad%C3%A9mica)Alternar subsección Estructura académica

*   [5 Investigación](https://es.wikipedia.org/wiki/Universidad_EAFIT#Investigaci%C3%B3n)Alternar subsección Investigación

*   [6 Cultura](https://es.wikipedia.org/wiki/Universidad_EAFIT#Cultura)Alternar subsección Cultura

- [x] Cambiar a la tabla de contenidos 

# Universidad EAFIT

- [x] 3 idiomas 

- [x] español 

- [x] Herramientas 

Herramientas

mover a la barra lateral ocultar

 Acciones 

 General 

 Imprimir/exportar 

 En otros proyectos 

Apariencia

mover a la barra lateral ocultar

De Wikipedia, la enciclopedia libre

| Universidad EAFIT |
| --- |
| [![Image 4](https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Escudo_Universidad_EAFIT.svg/120px-Escudo_Universidad_EAFIT.svg.png)](https://es.wikipedia.org/wiki/Archivo:Escudo_Universidad_EAFIT.svg) Escudo institucional |
| [![Image 5](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Centro_cultural_Biblioteca_%22Luis_Echavarr%C3%ADa_Villegas%22.jpg/330px-Centro_cultural_Biblioteca_%22Luis_Echavarr%C3%ADa_Villegas%22.jpg)](https://es.wikipedia.org/wiki/Archivo:Centro_cultural_Biblioteca_%22Luis_Echavarr%C3%ADa_Villegas%22.jpg) Centro cultural Biblioteca «Luís Echavarría Villegas», en la sede central. |
| [Lema](https://es.wikipedia.org/wiki/Lema "Lema") | _Inspira, Crea, Transforma_ |
| Tipo | Privada |
| Fundación | 4 de mayo de 1960 (66 años) |
| Localización |
| Dirección | Carrera 49 N° 7 Sur - 50 [![Image 6: Bandera de la Ciudad de Medellín](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Flag_of_Medell%C3%ADn.svg/20px-Flag_of_Medell%C3%ADn.svg.png)](https://es.wikipedia.org/wiki/Archivo:Flag_of_Medell%C3%ADn.svg "Bandera de la Ciudad de Medellín")[Medellín](https://es.wikipedia.org/wiki/Medell%C3%ADn "Medellín") Colombia![Image 7: Bandera de Colombia](https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Flag_of_Colombia.svg/20px-Flag_of_Colombia.svg.png)[Colombia](https://es.wikipedia.org/wiki/Colombia "Colombia") |
| [Campus](https://es.wikipedia.org/wiki/Campus "Campus") | [El Poblado](https://es.wikipedia.org/wiki/El_Poblado_(Medell%C3%ADn) "El Poblado (Medellín)") |
| Coordenadas | [6°11′59″N 75°34′43″O / 6.19973333, -75.57868611](http://tools.wmflabs.org/geohack/geohack.php?language=es&pagename=Universidad_EAFIT&params=6.19973333_N_-75.57868611_E_type:edu) |
| Otras sedes | * [Bogotá](https://es.wikipedia.org/wiki/Bogot%C3%A1 "Bogotá") * [Pereira](https://es.wikipedia.org/wiki/Pereira "Pereira") * [Rionegro](https://es.wikipedia.org/wiki/Rionegro_(Antioquia) "Rionegro (Antioquia)") |
| Administración |
| [Rector](https://es.wikipedia.org/wiki/Rector "Rector") | [Claudia Restrepo Montoya](https://es.wikipedia.org/wiki/Claudia_Restrepo_Montoya?action=edit&redlink=1 "Claudia Restrepo Montoya (aún no redactado)") |
| Afiliaciones | [ASCUN](https://es.wikipedia.org/wiki/ASCUN "ASCUN") |
| Academia |
| [Estudiantes](https://es.wikipedia.org/wiki/Estudiante "Estudiante") | 13.000 |
| •[Pregrado](https://es.wikipedia.org/wiki/Pregrado "Pregrado") | 10.000 |
| •[Posgrado](https://es.wikipedia.org/wiki/Posgrado "Posgrado") | 3.000 |
| Colores | Azul y amarillo dorado |
| Sitio web |
| [www.eafit.edu.co](https://www.eafit.edu.co/) |
| [![Image 8](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Logo_de_la_Universidad_EAFIT.png/250px-Logo_de_la_Universidad_EAFIT.png)](https://es.wikipedia.org/wiki/Archivo:Logo_de_la_Universidad_EAFIT.png) |
| [[editar datos en Wikidata](https://www.wikidata.org/wiki/Q3997314 "d:Q3997314")] |

La **Universidad EAFIT** (originalmente las siglas de **Escuela de Administración, Finanzas e Instituto Tecnológico**) es una [universidad privada](https://es.wikipedia.org/wiki/Universidad_privada "Universidad privada")[colombiana](https://es.wikipedia.org/wiki/Colombia "Colombia"). Su sede principal se encuentra en el sur de la ciudad de [Medellín](https://es.wikipedia.org/wiki/Medell%C3%ADn "Medellín"), en el barrio [El Poblado](https://es.wikipedia.org/wiki/El_Poblado_(Medell%C3%ADn) "El Poblado (Medellín)"). También cuenta con sedes en [Bogotá](https://es.wikipedia.org/wiki/Bogot%C3%A1 "Bogotá"), [Pereira](https://es.wikipedia.org/wiki/Pereira "Pereira") y [Rionegro](https://es.wikipedia.org/wiki/Rionegro_(Antioquia) "Rionegro (Antioquia)"). Su oferta académica consta de 25 pregrados, 44 especializaciones, 42 maestrías y 6 doctorados. En 2003, obtuvo del Ministerio de Educación la Acreditación Institucional, y desde 2010, cuenta con Acreditación Institucional de Alta Calidad.[[1]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-1) Como Institución de Educación Superior, está sujeta a inspección y vigilancia del [Ministerio de Educación Nacional](https://es.wikipedia.org/wiki/Ministerio_de_Educaci%C3%B3n_de_Colombia "Ministerio de Educación de Colombia") por medio de las Leyes 1740 de 2014 y 30 de 1992.

## Historia

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=1 "Editar sección: Historia")]

### Fundación

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=2 "Editar sección: Fundación")]

Hacia finales de la década de 1950, un grupo de industriales y empresarios antioqueños pertenecientes a la [Asociación Nacional de Industriales (ANDI)](https://es.wikipedia.org/wiki/Asociaci%C3%B3n_Nacional_de_Industriales "Asociación Nacional de Industriales"), concibió la idea de establecer en Colombia una carrera de [Administración](https://es.wikipedia.org/wiki/Administraci%C3%B3n "Administración"), con el propósito de capacitar en el país a los directivos y empleados de sus organizaciones. El 4 de mayo de 1960, a fin de concretar el proyecto, se formalizó en Medellín la creación de la entonces denominada Escuela de Administración y Finanzas (EAF), la cual fue reconocida como Fundación por el [Ministerio de Educación Nacional](https://es.wikipedia.org/wiki/Ministerio_de_Educaci%C3%B3n_de_Colombia "Ministerio de Educación de Colombia") el 11 de junio del mismo año. Las labores académicas iniciaron el 17 de agosto con 59 alumnos matriculados, con la cátedra de contabilidad dictada por el profesor estadounidense Bernard J. Hargadon Jr., en la sede del [Banco Central Hipotecario](https://es.wikipedia.org/wiki/Banco_Central_Hipotecario "Banco Central Hipotecario") del centro de Medellín.[[2]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:1-2)

### Creación del Instituto Tecnológico

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=3 "Editar sección: Creación del Instituto Tecnológico")]

El 19 de febrero de 1962, gracias al apoyo de la Fundación _Whirlpool_ y del programa _Tools for Freedom_ del gobierno de los [Estados Unidos](https://es.wikipedia.org/wiki/Estados_Unidos "Estados Unidos"), la Escuela abrió los programas medios de Tecnología Textil, Industrial, Mecánica y Programación de Computadores, naciendo así el Instituto Tecnológico. Con motivo de este crecimiento, la institución pasó a llamarse Escuela de Administración, Finanzas e Instituto Tecnológico - EAFIT.[[2]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:1-2)

### Consolidación y expansión

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=4 "Editar sección: Consolidación y expansión")]

Escuela de Ingenierías en el campus de El Poblado.

En 1963 la institución adquirió un predio ubicado en el sector de La Aguacatala, al sur de Medellín, con el fin de construir su ciudadela universitaria, trasladando a ella sus labores académicas.[[2]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:1-2)

En 1971 el Ministerio de Educación le otorgó a la escuela el título de Universidad y el sentido de la sigla cambió a Escuela de Administración, Finanzas y Tecnologías - EAFIT.

Escuela de Administración en el campus de El Poblado.

En 1973 con el apoyo de la [Universidad de Georgia](https://es.wikipedia.org/wiki/Universidad_de_Georgia "Universidad de Georgia"), EAFIT creó su Maestría en Administración, dando inicio a los posgrados, y en 1976 desaparecieron las carreras medias transformándose en carreras profesionales de ingeniería.[[3]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-3)

En 1980 al cumplirse 20 años de su fundación, la Universidad recibió la Cruz de plata de la [Orden de Boyacá](https://es.wikipedia.org/wiki/Orden_de_Boyac%C3%A1 "Orden de Boyacá"), y en el plano académico, dio inicio a la carrera de Ingeniería Civil; al año siguiente se sumó [Ingeniería Mecánica](https://es.wikipedia.org/wiki/Ingenier%C3%ADa_mec%C3%A1nica "Ingeniería mecánica"), y en 1983, Geología. En 1987 inauguró en su sede central el Auditorio Fundadores, y dos años después abrió su primera seccional en la ciudad de Bogotá.[[4]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-4)

Áreas comerciales del campus de El Poblado.

En 1993 se creó el programa de Negocios Internacionales, y en 1995 fue inaugurada la sede de la universidad en Pereira, a la que se sumaría el año siguiente la sede de Llanogrande en Rionegro. Ese mismo año surge el pregrado de Economía, seguido en 1996 de la carrera de Ingeniería de Procesos.

En 1997 inició labores la Escuela de Ciencias y Humanidades, lo que representó una diversificación importante del programa académico de la institución, que hasta entonces tenía una vocación estrictamente técnica. Dicha Escuela inició labores con el pregrado de Música. Dos años después, fue inaugurado el Centro Cultural [Biblioteca Luis Echavarría Villegas](https://es.wikipedia.org/wiki/Biblioteca_Luis_Echavarr%C3%ADa_Villegas "Biblioteca Luis Echavarría Villegas"), y fue creada la carrera de Ingeniería en Diseño de Producto.[[5]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-5)

En el año 2002 fue creado al pregrado en Ingeniería Matemática, y en 2004 las carreras de Ingeniería Física, Comunicación Social y Ciencias Políticas. En mayo de 2008 el campus de Medellín recibió el [Premio Lápiz de Acero](https://es.wikipedia.org/wiki/Premio_L%C3%A1piz_de_Acero "Premio Lápiz de Acero") de la revista _Proyectodiseño_ en la categoría de espacios públicos por su proyecto de Universidad Parque. Al año siguiente egresó de la Universidad el primer doctor en Administración de una universidad del país, y en 2010 fue la primera institución de educación superior en recibir la renovación de la acreditación de alta calidad por parte del Ministerio de Educación Nacional.[[6]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-6)[[7]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-7)

En junio de 2010 se inauguró el nuevo edificio de la Escuela de Ingeniería en el costado sur del campus de El Poblado,[[8]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-8) contiguo al sector residencial del barrio La Aguacatala, en el que funcionan algunos centros académicos así como dependencias administrativas.[[9]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-9) Ese mismo año, en Pereira, se dio al servicio nueva infraestructura física.

En 2011 comenzaron dos programas de pregrado en la Escuela de Administración: Psicología y Mercadeo, y en 2012, la carrera de Biología en la Escuela de Ciencias y Humanidades. En 2014, inició el pregrado en Finanzas, y en 2015, la institución obtuvo el puesto 69 en el Ranking QS Latinoamérica, quedando incluida entre las 100 mejores universidades de la región.[[10]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-10)[[11]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-11)

### Rectores

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=5 "Editar sección: Rectores")]

## Identidad

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=6 "Editar sección: Identidad")]

### Escudo

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=7 "Editar sección: Escudo")]

El escudo consta de una [rueda dentada](https://es.wikipedia.org/wiki/Engranaje "Engranaje") (o piñón) de doce dientes de color [azul marino](https://es.wikipedia.org/wiki/Azul_marino "Azul marino"), como símbolo de las tecnologías. En su interior se inscribe un círculo de color [amarillo dorado](https://es.wikipedia.org/wiki/Dorado_(color) "Dorado (color)") que contiene un triángulo equilátero dividido en tres franjas que representan la pirámide de [Henry Fayol](https://es.wikipedia.org/wiki/Henri_Fayol "Henri Fayol"), prototipo de la teoría de la Administración. Aunque a lo largo de su historia la Universidad ha ampliado sus áreas de enseñanza e investigación más allá de las originarias ramas de la administración y las tecnologías, el escudo ha permanecido como vínculo de unión con sus orígenes.[[12]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:2-12)

### Bandera

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=8 "Editar sección: Bandera")]

La bandera se compone de dos franjas iguales en proporción 2:3. La franja superior es de color amarillo dorado y la inferior azul. Estos colores surgieron a partir de la vinculación de la institución con la [Universidad de Siracusa](https://es.wikipedia.org/wiki/Universidad_de_Siracusa "Universidad de Siracusa"). Tanto la bandera como el escudo fueron adoptados oficialmente por el Consejo Directivo el 4 de noviembre de 1964.[[12]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:2-12)

### Himno

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=9 "Editar sección: Himno")]

En noviembre de 1988, ante la solicitud de algunos estudiantes, la Universidad convocó a un concurso con el fin de seleccionar su marcha simbólica. Como propuesta ganadora fue seleccionada una composición con letra de Hernán Gómez González y música de Guillermo González Arenas. El himno se entona de manera especial en las ceremonias de graduación, así como en eventos solemnes dentro de la institución.[[12]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:2-12)

### Lemas

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=10 "Editar sección: Lemas")]

*   2000-2014: «Abierta al mundo»
*   2015-presente: «Inspira, Crea, Transforma»

## Campus y sedes

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=11 "Editar sección: Campus y sedes")]

### Medellín

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=12 "Editar sección: Medellín")]

Campus de la Universidad EAFIT en Medellín, Colombia.

La sede principal de Medellín alberga a los órganos directivos y administrativos de la Universidad. Cuenta con un área de 148 339 m², de los cuales están construidos 84 747 m², compuestos por la biblioteca, aulas, laboratorios, etc. Las zonas verdes ascienden a 29 844 m², y, gracias a sus numerosos árboles de pimientos, carboneros y guayacanes, el campus constituye un espacio propicio para la [avifauna](https://es.wikipedia.org/wiki/Avifauna "Avifauna") de la ciudad.[[13]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-13)

### Bogotá

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=13 "Editar sección: Bogotá")]

La sede Bogotá ofrece posgrados en los niveles de especialización y maestría.

En 2019 EAFIT abrió un centro de innovación Bogotá con el fin de gestionar iniciativas que promuevan el progreso del conocimiento y aporten al desarrollo del país.[[14]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-14)

### Pereira

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=14 "Editar sección: Pereira")]

Aunque los vínculos de la Universidad con el [Eje cafetero](https://es.wikipedia.org/wiki/Eje_cafetero "Eje cafetero") se remontan a 1978, la universidad mantiene presencia permanente en la región, a través de su sede en Pereira abierta en 1995. En ella se imparten posgrados, programas de educación continua e inglés virtual.

En 2010, y gracias a las gestiones del director regional y egresado de la institución, Roberto Arenas Mejía, la Universidad desarrolló una infraestructura propia en el sector de Pinares, desde la cual, además de su oferta propia, ha establecido convenios con otras universidades del occidente del país.[[15]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-15)

### Rionegro

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=15 "Editar sección: Rionegro")]

La sede de Rionegro, ubicada en el sector de Llanogrande, fue inaugurada en 1997. Es un campus destinado a cursos de formación avanzada, idiomas y posgrados. Su ubicación estratégica acerca los servicios de la Universidad a la población del [Oriente antioqueño](https://es.wikipedia.org/wiki/Oriente_antioque%C3%B1o "Oriente antioqueño").[[16]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-16)

## Estructura académica

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=16 "Editar sección: Estructura académica")]

### Acreditación institucional de alta calidad

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=17 "Editar sección: Acreditación institucional de alta calidad")]

Mediante el decreto 2158, la Universidad recibió por tercera vez la Acreditación Institucional de Alta Calidad, otorgada por el Ministerio de Educación Nacional,[[17]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:0-17) con vigencia hasta 2026. El 13 de febrero de 2018 Recibió la Acreditación Institucional del [CNA](https://es.wikipedia.org/wiki/Consejo_Nacional_de_Acreditaci%C3%B3n "Consejo Nacional de Acreditación") por un período de 8 años. EAFIT es considerada [una de las mejores universidades de Colombia](https://es.wikipedia.org/wiki/Clasificaci%C3%B3n_acad%C3%A9mica_de_universidades_de_Colombia "Clasificación académica de universidades de Colombia") por el ranking **QS** ([Quacquarelli Symonds](https://es.wikipedia.org/wiki/Quacquarelli_Symonds "Quacquarelli Symonds")).[[18]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-18)

Escuelas y Pregrados| Gerencia y Empresa | Ciencias Aplicadas e Ingeniería | Artes y Humanidades | Derecho | Finanzas, Economía y Gobierno |
| --- | --- | --- | --- | --- |
| Administración de Negocios Negocios Internacionales Contaduría Pública Mercadeo | Ingeniería Civil Ingeniería de Diseño de Producto Ingeniería Mecánica Ingeniería de Procesos Ingeniería de Producción Ingeniería de Sistemas Ingeniería Agronómica Biología Geología Ingeniería Matemática Ingeniería Física | Música Comunicación Social Psicología Literatura Diseño Interactivo Diseño Urbano y Gestión del Hábitat | Derecho | Economía Finanzas Ciencias Políticas |

### Centro de Estudios Urbanos y Ambientales - urbam EAFIT

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=18 "Editar sección: Centro de Estudios Urbanos y Ambientales - urbam EAFIT")]

Artículo principal:_[Centro de Estudios Urbanos y Ambientales - urbam EAFIT](https://es.wikipedia.org/wiki/Centro\_de\_Estudios\_Urbanos\_y\_Ambientales\_-\_urbam\_EAFIT "Centro de Estudios Urbanos y Ambientales - urbam EAFIT")_

El Centro de Estudios Urbanos y Ambientales, también urbam EAFIT, fue fundado en 2010 por el entonces rector [Juan Luis Mejía Arango](https://es.wikipedia.org/wiki/Juan_Luis_Mej%C3%ADa_Arango "Juan Luis Mejía Arango") y el arquitecto Alejandro Echeverri. A partir de entonces se ha instituido como un referente en temas de planeación urbana, ocupación sostenible y proyección social. Además, desde la apertura de la Maestría en Procesos Urbanos y Ambientales,[[19]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-19) urbam también se convirtió en un departamento académico de la Universidad. En 2020 se dio apertura al pregrado en Diseño Urbano y Gestión del Hábitat.[[20]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-20)

En el año 2021, el Grupo de Investigación, acreditado por MinCiencia y conformado por los profesores e investigadores del Centro, recibió el máximo nivel de la convocatoria, A1.

Edificio de Idiomas en el campus de El Poblado.

### Centro de Educación Continua

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=19 "Editar sección: Centro de Educación Continua")]

El Centro de Educación Continua tiene como misión ofrecer cursos intensos que permitan capacitar habilidades o conocimientos en poco tiempo. Este tipo de ofertas permiten acercar a la universidad grupos poblacionales como el de adultos mayores, así como a profesionales que por su alta carga laboral, disponen de poco tiempo. El Centro estructura diplomados, cursos cortos, eventos académicos, programas para altos ejecutivos, y programas de verano.[[21]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-21)

### Dirección de Idiomas

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=20 "Editar sección: Dirección de Idiomas")]

Idiomas EAFIT cuenta con más de 270 docentes y aproximadamente 13 000 estudiantes matriculados en programas de enseñanza de siete idiomas diferentes.[[22]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-22)

## Investigación

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=21 "Editar sección: Investigación")]

Sala de equipos de Apolo.

Las actividades de investigación, son orientadas por la Vicerrectoría de Ciencia, Tecnología e innovación. La Universidad cuenta con más de 600 investigadores y más de 40 grupos clasificados por el Ministerio de Ciencias de Colombia.[[23]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-23)

Además, está integrado por otros programas como la Universidad de los Niños,[[24]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-24) la oferta del [Centro Cultural Biblioteca "Luís Echavarría Villegas"](https://es.wikipedia.org/wiki/Biblioteca_Luis_Echavarr%C3%ADa_Villegas "Biblioteca Luis Echavarría Villegas"),[[25]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:3-25) y el Centro de Computación Científica Apolo[[26]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:4-26)

### Biblioteca

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=22 "Editar sección: Biblioteca")]

La Biblioteca "Luís Echavarria Villegas" cuenta con diversos acervos. La colección general comprende libros, tesis, proyectos de grado, documentos (CEDO-CEMDOC), catálogos, partituras e investigaciones. La colección de reserva está compuesta por textos guía en todas las áreas del conocimiento presentes en la Universidad. La biblioteca cuenta además con una [hemeroteca](https://es.wikipedia.org/wiki/Hemeroteca "Hemeroteca") y colecciones de textos patrimoniales, material audiovisual y digital.[[25]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:3-25)

### Apolo

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=23 "Editar sección: Apolo")]

El Centro de Computación Científica Apolo cuenta con un datacenter dedicado al procesamiento de datos para proyectos de investigación e inicitivas de computación de alto rendimiento. Esta super-computadora está actualmente en el puesto 11 de las máquinas con mayor capacidad de cómputo de Latinoamérica, siendo la primera en Colombia.[[26]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-:4-26)[[27]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-27)

## Cultura

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=24 "Editar sección: Cultura")]

### Grupos estudiantiles

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=25 "Editar sección: Grupos estudiantiles")]

Los grupos estudiantiles son colectivos creados por iniciativa de los estudiantes con el fin de aportar procesos de práctica, investigación, cultura y recreación en beneficio de la comunidad universitaria. Esta estrategia permite además desarrollar en los estudiantes un sentido de responsabilidad y pertenencia que posibilite la continuidad de este tipo de procesos.[[28]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-28)

| Grupo | Objetivo |
| --- | --- |
| Organización estudiantil | Agrupar a los estudiantes de las distintas facultades, promoviendo eventos de integración.[[29]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-29) |
| Tutores EAFIT | Guiar a los estudiantes nuevos en la integración a la vida universitaria.[[30]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-30) |
| Grupo de Proyección Gerencial | Organizar el congreso _Gerenciar,_ así como otras actividades dirigidas al [Emprendimiento](https://es.wikipedia.org/wiki/Emprendimiento "Emprendimiento") y el [Liderazgo](https://es.wikipedia.org/wiki/Liderazgo "Liderazgo")[[31]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-31) |
| Club de Mercadeo | Organizar el congreso de mercadeo _CONAMERC_, así como conferencias y talleres para la enseñanza del [Mercadeo](https://es.wikipedia.org/wiki/Mercadotecnia "Mercadotecnia")[[32]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-32) |
| Aiesec EAFIT | Integrar a los estudiantes de EAFIT con otras organizaciones AIESEC del mundo.[[33]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-33) |
| Seres | Desarrollar actividades con enfoque social.[[34]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-34) |
| Periódico estudiantil Nexos | Divulgar información de interés universitario en formatos digitales.[[35]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-35) |
| UN Society | Reunir estudiantes interesados en las [Relaciones Internacionales](https://es.wikipedia.org/wiki/Relaciones_Internacionales "Relaciones Internacionales"), el [Derecho](https://es.wikipedia.org/wiki/Derecho "Derecho") y la [Diplomacia](https://es.wikipedia.org/wiki/Diplomacia "Diplomacia")[[36]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-36) |
| SPIE Student chapter | Estudiar la [Óptica](https://es.wikipedia.org/wiki/%C3%93ptica "Óptica") y la [Fotónica](https://es.wikipedia.org/wiki/Fot%C3%B3nica "Fotónica"). Esta organización cuenta con Capítulos en diversas universidades del mundo.[[37]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-37) |
| Producciones TVU | Realizar audiovisuales sobre diferentes temáticas para la Universidad.[[38]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-38) |
| Saberes de Vida | Agrupación de profesionales matriculados en programas de Formación Avanzada, con el fin de compartir experiencia en sus campos de conocimiento.[[39]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-39) |
| Partners Campus | Partners Campus EAFIT es un capítulo de la red Partners of the Americas, integrado a la universidad EAFIT .[[40]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-40) |
| Club de inversión y negocios | Desarrollo de competencias de liderazgo, comunicación y otras habilidades con enfoque a negocios e inversión.[[41]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-41) |

### Editorial EAFIT

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=26 "Editar sección: Editorial EAFIT")]

La Editorial EAFIT realiza publicaciones con enfoque cultural, histórico o educativo. Entre los autores publicados se encuentran filósofos como [Fernando González](https://es.wikipedia.org/wiki/Fernando_Gonz%C3%A1lez_Ochoa "Fernando González Ochoa") y [Gonzalo Arango](https://es.wikipedia.org/wiki/Gonzalo_Arango "Gonzalo Arango"), y escritoras como [Rocío Vélez de Piedrahíta](https://es.wikipedia.org/wiki/Roc%C3%ADo_V%C3%A9lez_de_Piedrah%C3%ADta "Rocío Vélez de Piedrahíta").[[42]](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_note-42)

## Egresados notables

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=27 "Editar sección: Egresados notables")]

Categoría principal:_[Alumnado de la Universidad EAFIT](https://es.wikipedia.org/wiki/Categor%C3%ADa:Alumnado\_de\_la\_Universidad\_EAFIT "Categoría:Alumnado de la Universidad EAFIT")_

## Convenios

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=28 "Editar sección: Convenios")]

EAFIT mantiene convenios con diversas universidades en el ámbito nacional e internacional, en áreas de cooperación científica e intercambios.

| Universidades hermanas |
| --- |
| País | Ciudad | Universidad |
| Colombia![Image 16: Bandera de Colombia](https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Flag_of_Colombia.svg/20px-Flag_of_Colombia.svg.png)[Colombia](https://es.wikipedia.org/wiki/Colombia "Colombia") | [Cali](https://es.wikipedia.org/wiki/Cali "Cali") | [Universidad Icesi](https://es.wikipedia.org/wiki/Universidad_Icesi "Universidad Icesi") |
| **Convenios con universidades** |
| Colombia![Image 17: Bandera de Colombia](https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Flag_of_Colombia.svg/20px-Flag_of_Colombia.svg.png)[Colombia](https://es.wikipedia.org/wiki/Colombia "Colombia") | [Medellín](https://es.wikipedia.org/wiki/Medell%C3%ADn "Medellín") | [Universidad Pontificia Bolivariana](https://es.wikipedia.org/wiki/Universidad_Pontificia_Bolivariana "Universidad Pontificia Bolivariana") |
| Colombia![Image 18: Bandera de Colombia](https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Flag_of_Colombia.svg/20px-Flag_of_Colombia.svg.png)[Colombia](https://es.wikipedia.org/wiki/Colombia "Colombia") | [Medellín](https://es.wikipedia.org/wiki/Medell%C3%ADn "Medellín") | [Tecnológico de Antioquia](https://es.wikipedia.org/wiki/Tecnol%C3%B3gico_de_Antioquia "Tecnológico de Antioquia") |
| Estados Unidos[![Image 19: Bandera de Estados Unidos](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Flag_of_the_United_States.svg/20px-Flag_of_the_United_States.svg.png)](https://es.wikipedia.org/wiki/Archivo:Flag_of_the_United_States.svg "Bandera de Estados Unidos")[Estados Unidos](https://es.wikipedia.org/wiki/Estados_Unidos "Estados Unidos") | [Chicago](https://es.wikipedia.org/wiki/Chicago "Chicago") | [Illinois Institute of Technology](https://es.wikipedia.org/wiki/Instituto_de_Tecnolog%C3%ADa_de_Illinois "Instituto de Tecnología de Illinois") |
| Estados Unidos[![Image 20: Bandera de Estados Unidos](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Flag_of_the_United_States.svg/20px-Flag_of_the_United_States.svg.png)](https://es.wikipedia.org/wiki/Archivo:Flag_of_the_United_States.svg "Bandera de Estados Unidos")[Estados Unidos](https://es.wikipedia.org/wiki/Estados_Unidos "Estados Unidos") | [West Lafayette](https://es.wikipedia.org/wiki/West_Lafayette_(Indiana) "West Lafayette (Indiana)") | [Purdue University](https://es.wikipedia.org/wiki/Universidad_Purdue "Universidad Purdue") |
| **Convenios con organizaciones** |
| Estados Unidos[![Image 21: Bandera de Estados Unidos](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Flag_of_the_United_States.svg/20px-Flag_of_the_United_States.svg.png)](https://es.wikipedia.org/wiki/Archivo:Flag_of_the_United_States.svg "Bandera de Estados Unidos")[Estados Unidos](https://es.wikipedia.org/wiki/Estados_Unidos "Estados Unidos") | **-** | International Student Exchange Program |

## Véase también

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=29 "Editar sección: Véase también")]

## Referencias

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=30 "Editar sección: Referencias")]

1.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-1)[«Acreditación en Alta Calidad»](https://www.eafit.edu.co/institucional/calidad-eafit/calidad/Paginas/calidad-eafit-acreditacion-institucional.aspx).
2.   [1](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:1_2-0)[2](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:1_2-1)[3](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:1_2-2)[«Década de 1960 - Universidad EAFIT, 60 años - Universidad EAFIT»](https://www.eafit.edu.co/institucional/historia/60/Paginas/decada60.aspx). _www.eafit.edu.co_. Consultado el 23 de noviembre de 2021.
3.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-3)[«Década de 1970 - Universidad EAFIT, 60 años - Universidad EAFIT»](https://www.eafit.edu.co/institucional/historia/60/Paginas/decada70.aspx). _www.eafit.edu.co_. Consultado el 23 de noviembre de 2021.
4.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-4)[«Década de 1980 - Universidad EAFIT, 60 años - Universidad EAFIT»](https://www.eafit.edu.co/institucional/historia/60/Paginas/decada80.aspx). _www.eafit.edu.co_. Consultado el 23 de noviembre de 2021.
5.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-5)[«Década de 1990 - Universidad EAFIT, 60 años - Universidad EAFIT»](https://www.eafit.edu.co/institucional/historia/60/Paginas/decada90.aspx). _www.eafit.edu.co_. Consultado el 23 de noviembre de 2021.
6.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-6)[«Década de 2000 - Universidad EAFIT, 60 años - Universidad EAFIT»](https://www.eafit.edu.co/institucional/historia/60/Paginas/decada00.aspx). _www.eafit.edu.co_. Consultado el 23 de noviembre de 2021.
7.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-7)[«Consejo Nacional de Acreditación de Colombia, lista de instituciones»](http://201.234.245.136/cna/Buscador/BuscadorInstituciones.php). Consultado el 8 de agosto de 2010.([enlace roto](https://es.wikipedia.org/wiki/Ayuda:C%C3%B3mo_recuperar_un_enlace_roto "Ayuda:Cómo recuperar un enlace roto") disponible en [Internet Archive](https://es.wikipedia.org/wiki/Internet_Archive "Internet Archive"); véase el [historial](https://web.archive.org/web/*/http://201.234.245.136/cna/Buscador/BuscadorInstituciones.php), la [primera versión](https://web.archive.org/web/1/http://201.234.245.136/cna/Buscador/BuscadorInstituciones.php) y la [última](https://web.archive.org/web/2/http://201.234.245.136/cna/Buscador/BuscadorInstituciones.php)).
8.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-8)González, María Cecilia. [«Un gigante que impacta»](http://www.elmundo.com/sitio/noticia_detalle.php?idcuerpo=2&dscuerpo=La%20Metro&idseccion=54&dsseccion=&idnoticia=148640&imagen=&vl=1&r=noticia_detalle.php&idedicion=1737). El Mundo. Consultado el 8 de agosto de 2010.
9.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-9)Valencia, Alejandro Gómez. [«Eafit le mete todo a investigar»](http://www.elcolombiano.com/BancoConocimiento/E/eafit_le_mete_todo_a_investigar/eafit_le_mete_todo_a_investigar.asp). El Colombiano. Consultado el 8 de agosto de 2010.
10.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-10)S.A.S, Editorial La República. [«Universidad Externado y La Sabana son las que más subieron en ranking QS»](https://www.larepublica.co/globoeconomia/universidad-externado-y-la-sabana-son-las-que-mas-subieron-en-ranking-qs-2264661). _Diario La República_. Consultado el 23 de noviembre de 2021.
11.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-11)[«Década de 2010 - Universidad EAFIT, 60 años - Universidad EAFIT»](https://www.eafit.edu.co/institucional/historia/60/Paginas/decada10.aspx). _www.eafit.edu.co_. Consultado el 23 de noviembre de 2021.
12.   [1](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:2_12-0)[2](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:2_12-1)[3](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:2_12-2)[«Símbolos Institucionales - Acerca de EAFIT / Institucional - Universidad EAFIT»](https://www.eafit.edu.co/institucional/info-general/Paginas/simbolos-institucionales.aspx). _www.eafit.edu.co_. Consultado el 24 de noviembre de 2021.
13.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-13)[«Campus EAFIT - Acerca de EAFIT / Campus EAFIT - Universidad EAFIT»](https://www.eafit.edu.co/campus-eafit). _www.eafit.edu.co_. Consultado el 24 de noviembre de 2021.
14.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-14)[«Impacto en la región - Posgrados, cursos, diplomados e idiomas en EAFIT Bogotá - EAFIT Bogotá / Acerca de EAFIT Bogotá - Universidad EAFIT»](https://www.eafit.edu.co/bogota/acerca-de-eafit-bogota/Paginas/nosotros.aspx). _www.eafit.edu.co_. Consultado el 24 de noviembre de 2021.
15.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-15)[«Sobre EAFIT Pereira - EAFIT Pereira / Acerca de - Universidad EAFIT»](https://www.eafit.edu.co/pereira/acerca-de-eafit-pereira/Paginas/sobre-eafit-pereira.aspx). _www.eafit.edu.co_. Consultado el 24 de noviembre de 2021.
16.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-16)[«EAFIT Llanogrande - EAFIT Llanogrande - Universidad EAFIT»](https://www.eafit.edu.co/llanogrande/Paginas/inicio.aspx). _www.eafit.edu.co_. Consultado el 24 de noviembre de 2021.
17.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:0_17-0)[«Consejo Nacional de Acreditación de Colombia»](http://201.234.245.136/cna/Buscador/Fortalezas.php?Id=3). Consultado el 8 de agosto de 2010.([enlace roto](https://es.wikipedia.org/wiki/Ayuda:C%C3%B3mo_recuperar_un_enlace_roto "Ayuda:Cómo recuperar un enlace roto") disponible en [Internet Archive](https://es.wikipedia.org/wiki/Internet_Archive "Internet Archive"); véase el [historial](https://web.archive.org/web/*/http://201.234.245.136/cna/Buscador/Fortalezas.php?Id=3), la [primera versión](https://web.archive.org/web/1/http://201.234.245.136/cna/Buscador/Fortalezas.php?Id=3) y la [última](https://web.archive.org/web/2/http://201.234.245.136/cna/Buscador/Fortalezas.php?Id=3)).
18.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-18)[«Las mejores universidades de Colombia, según 'ranking' mundial QS»](https://www.eltiempo.com/vida/educacion/las-mejores-universidades-de-colombia-y-el-mundo-segun-nuevo-ranking-qs-594442). _[El Tiempo (Colombia)](https://es.wikipedia.org/wiki/El\_Tiempo\_(Colombia) "El Tiempo (Colombia)")_. 14 de junio de 2021. Consultado el 5 de febrero de 2022.
19.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-19)[«Inicio - Maestría en Procesos Urbanos y Ambientales»](https://www.eafit.edu.co/maestria-procesos-urbanos-ambientales). _www.eafit.edu.co_. Consultado el 9 de mayo de 2022.
20.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-20)[«Pregrado en Diseño Urbano y Gestión del Hábitat - Diseño Urbano y Gestión del Hábitat - Universidad EAFIT»](https://www.eafit.edu.co/pregrado-diseno-urbano). _www.eafit.edu.co_. Consultado el 9 de mayo de 2022.
21.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-21)[«Centro de Educación Continua - Cursos, Diplomados, Programas, Seminarios, Congresos - Universidad EAFIT»](https://web.archive.org/web/20211126012336/https://www.eafit.edu.co/cec/home/Paginas/inicio.aspx). _www.eafit.edu.co_. Archivado desde [el original](https://www.eafit.edu.co/cec/home/Paginas/inicio.aspx) el 26 de noviembre de 2021. Consultado el 26 de noviembre de 2021.
22.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-22)[«Inicio - Idiomas EAFIT - Universidad EAFIT»](https://www.eafit.edu.co/idiomas/Paginas/inicio.aspx). _www.eafit.edu.co_. Consultado el 26 de noviembre de 2021.
23.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-23)[«Grupos de Investigación - Investigación / Grupos - Universidad EAFIT»](https://www.eafit.edu.co/investigacion/grupos/Paginas/grupos-de-investigacion.aspx). _www.eafit.edu.co_. Consultado el 26 de noviembre de 2021.
24.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-24)[«Universidad de los niños»](https://www.eafit.edu.co/ninos/informacion-general/Paginas/inicio.aspx). _www.eafit.edu.co_. Consultado el 26 de noviembre de 2021.
25.   [1](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:3_25-0)[2](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:3_25-1)[«Biblioteca - Centro Cultural Biblioteca Luis Echavarría Villegas - Universidad EAFIT»](https://www.eafit.edu.co/biblioteca/Paginas/Inicio.aspx). _www.eafit.edu.co_. Consultado el 26 de noviembre de 2021.
26.   [1](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:4_26-0)[2](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-:4_26-1)[«Home - Apolo - Universidad EAFIT»](https://www.eafit.edu.co/apolo). _www.eafit.edu.co_. Consultado el 26 de noviembre de 2021.
27.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-27)[«Por las dependencias / Apolo, la supercomputadora de EAFIT, entre las mejores de América Latina»](http://entrenos.eafit.edu.co/noticias/2013/octubre/Paginas/por-las-dependencias-apolo-la-supercomputadora-de-eafit-entre-las-mejores-de-america-latina.aspx). _entrenos.eafit.edu.co_. Consultado el 26 de noviembre de 2021.
28.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-28)[«Grupos estudiantiles- EAFIT»](https://www.eafit.edu.co/bienestar-universitario/grupos-estudiantiles/Paginas/inicio.aspx). Consultado el 29 de noviembre de 2021.
29.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-29)[«Organización Estudiantil (OE) - Grupos estudiantiles / Organización Estudiantil (OE) - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/organizacionestudiantil/Paginas/oe.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
30.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-30)[«Tutores - Grupos estudiantiles / Tutores - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/tutores-eafit/Paginas/tutores.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
31.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-31)[«Grupo de Proyección Gerencial (GPG) - Grupos estudiantiles / Grupo de Proyección Gerencial (GPG) - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/gpg-eafit/Paginas/gpg.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
32.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-32)[«Club de Mercadeo - Grupos estudiantiles / Club de Mercadeo - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/club-de-mercadeo/Paginas/clubdemercadeo.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
33.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-33)[«Aiesec - Grupos estudiantiles / Aiesec - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/aiesec-eafit/Paginas/aiesec.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
34.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-34)[«Grupo Seres - Grupos estudiantiles / Grupo Seres - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/gruposeres/Paginas/seres.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
35.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-35)[«Periódico Estudiantil Nexos - Nexos - Universidad EAFIT»](https://www.eafit.edu.co/nexos/Paginas/nexos.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
36.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-36)[«UN Society - Grupos estudiantiles / UN Society - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/unsociety/Paginas/unsociety.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
37.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-37)[«SPIE Student Chapter - Grupos estudiantiles / Spie - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/spie-eafit/Paginas/spie.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
38.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-38)[«Producciones TVU - Grupos estudiantiles / Producciones TVU - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/informestvu/Paginas/tvu.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
39.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-39)[«Saberes de Vida - Grupos estudiantiles / Saberes de Vida - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/saberes-de-vida/Paginas/saberes-de-vida.aspx). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.
40.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-40)[«Partners Campus - Grupos estudiantiles / Partners Campus - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/partnerscampus/Paginas/partners-campus.aspx). _www.eafit.edu.co_. Consultado el 22 de febrero de 2022.
41.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-41)[«Club de Inversión y Negocios - Grupos Estudiantiles / Club IN - Universidad EAFIT»](https://www.eafit.edu.co/estudiantes/grupos-estudiantiles/clubin/Paginas/inicio.aspx). _www.eafit.edu.co_. Consultado el 22 de febrero de 2022.
42.   [↑](https://es.wikipedia.org/wiki/Universidad_EAFIT#cite_ref-42)[«inicio - Editorial EAFIT - Universidad EAFIT»](https://www.eafit.edu.co/editorial). _www.eafit.edu.co_. Consultado el 29 de noviembre de 2021.

## Enlaces externos

[[editar](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&action=edit&section=31 "Editar sección: Enlaces externos")]

*   ![Image 22: Commonscat](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/20px-Commons-logo.svg.png)[Wikimedia Commons](https://es.wikipedia.org/wiki/Wikimedia_Commons "Wikimedia Commons") alberga una categoría multimedia sobre la **[Universidad EAFIT](https://commons.wikimedia.org/wiki/Category:Universidad%20EAFIT "commons:Category:Universidad EAFIT")**.

| [Control de autoridades](https://es.wikipedia.org/wiki/Control_de_autoridades "Control de autoridades") | * **Proyectos Wikimedia** * [![Image 23: Wd](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/20px-Wikidata-logo.svg.png)](https://es.wikipedia.org/wiki/Wikidata "Wikidata") Datos:[Q3997314](https://www.wikidata.org/wiki/Q3997314 "wikidata:Q3997314") * [![Image 24: Commonscat](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Commons-logo.svg/20px-Commons-logo.svg.png)](https://es.wikipedia.org/wiki/Wikimedia_Commons "Commonscat") Multimedia:[Universidad EAFIT](https://commons.wikimedia.org/wiki/Category:Universidad_EAFIT) / [Q3997314](https://commons.wikimedia.org/wiki/Special:MediaSearch?type=image&search=%22Q3997314%22) * * * * **Identificadores** * [VIAF](https://es.wikipedia.org/wiki/Fichero_de_Autoridades_Virtual_Internacional "Fichero de Autoridades Virtual Internacional"):[148362089](https://viaf.org/viaf/148362089) * [ISNI](https://es.wikipedia.org/wiki/International_Standard_Name_Identifier "International Standard Name Identifier"):[0000000099894956](https://isni.org/isni/0000000099894956) * [GND](https://es.wikipedia.org/wiki/Gemeinsame_Normdatei "Gemeinsame Normdatei"):[220655-9](https://d-nb.info/gnd/220655-9) * [LCCN](https://es.wikipedia.org/wiki/Library_of_Congress_Control_Number "Library of Congress Control Number"):[n84129623](https://id.loc.gov/authorities/n84129623) * [NKC](https://es.wikipedia.org/wiki/Biblioteca_Nacional_de_la_Rep%C3%BAblica_Checa "Biblioteca Nacional de la República Checa"):[ko2009479315](https://aleph.nkp.cz/F/?func=find-c&local_base=aut&ccl_term=ica=ko2009479315) * [NLI](https://es.wikipedia.org/wiki/Biblioteca_Nacional_de_Israel "Biblioteca Nacional de Israel"):[987007337373405171](https://www.nli.org.il/en/authorities/987007337373405171) * **Identificadores fiscales** * [VAT](https://es.wikipedia.org/wiki/N%C3%BAmero_de_Identificaci%C3%B3n_Fiscal_a_efectos_del_IVA_(NIF-IVA) "Número de Identificación Fiscal a efectos del IVA (NIF-IVA)"):CO8909013895 |
| --- |

Obtenido de «[https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&oldid=168590350](https://es.wikipedia.org/w/index.php?title=Universidad_EAFIT&oldid=168590350)»

[Categorías](https://es.wikipedia.org/wiki/Especial:Categor%C3%ADas "Especial:Categorías"): 

Categorías ocultas: 

*    Esta página se editó por última vez el 22 jul 2025 a las 02:16.
*   La página fue renderizada con [Parsoid](https://www.mediawiki.org/wiki/Special:MyLanguage/Parsoid "mw:Special:MyLanguage/Parsoid").
*   El texto está disponible bajo la [Licencia Creative Commons Atribución-CompartirIgual 4.0](https://es.wikipedia.org/wiki/Wikipedia:Texto_de_la_Licencia_Creative_Commons_Atribuci%C3%B3n-CompartirIgual_4.0_Internacional "Wikipedia:Texto de la Licencia Creative Commons Atribución-CompartirIgual 4.0 Internacional"); pueden aplicarse cláusulas adicionales. Al usar este sitio aceptas nuestros [términos de uso](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/es) y nuestra [política de privacidad](https://foundation.wikimedia.org/wiki/Policy:Privacy_policy/es).

Wikipedia® es una marca registrada de la [Fundación Wikimedia](https://wikimediafoundation.org/es/), una organización sin ánimo de lucro.

Buscar

Buscar

- [x] Cambiar a la tabla de contenidos 

Universidad EAFIT

3 idiomas[Añadir tema](https://es.wikipedia.org/wiki/Universidad_EAFIT#)