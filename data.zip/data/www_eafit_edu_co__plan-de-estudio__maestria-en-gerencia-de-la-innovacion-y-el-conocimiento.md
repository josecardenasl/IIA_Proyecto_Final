# Maestría en Gerencia de la Innovación y el Conocimiento - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Maestría en Gerencia de la Innovación y el Conocimiento

*    Plan de Estudio 
*    Maestría En Gerencia de La Innovación y El Conocimiento 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas electivas 

- [x] Plan de estudios del programa 

- [x] Trabajo de grado 

Semestre 1

Créditos 

totales-

Créditos 2

#### Hombre, Ciencia y Sociedad

Código: OG0377

Plan de estudios del programa
## Hombre, Ciencia y Sociedad

2 Créditos

2 UMES

Código: **OG0377**

Créditos 2

#### Fundamentos de Conocimiento e Innovación

Código: OG0378

Plan de estudios del programa
## Fundamentos de Conocimiento e Innovación

2 Créditos

2 UMES

Código: **OG0378**

Créditos 2

#### Organizaciones

Código: OG0379

Plan de estudios del programa
## Organizaciones

2 Créditos

2 UMES

Código: **OG0379**

Créditos 2

#### Estrategia y modelos de negocio

Código: OD7003

Plan de estudios del programa
## Estrategia y modelos de negocio

2 Créditos

3 UMES

La asignatura "Estrategia y Modelos de Negocio" se justifica como un componente esencial en el plan de estudios de la Maestría en Arquitectura Organizacional, ya que proporciona a los estudiantes las herramientas fundamentales para comprender y diseñar estructuras organizacionales en un entorno empresarial dinámico. Al finalizar el curso, los estudiantes habrán desarrollado competencias clave para analizar entornos complejos, proponer procesos estratégicos acordes a las organizaciones analizadas, diseñar modelos de negocio innovadores y alinear la arquitectura organizacional con los objetivos estratégicos.

Código: **OD7003**

Créditos 2

#### Principios de Dirección y Liderazgo

Código: OG0381

Plan de estudios del programa
## Principios de Dirección y Liderazgo

2 Créditos

2 UMES

Código: **OG0381**

Créditos 2

#### Pensamiento Sistémico y Complejidad

Código: OG0382

Plan de estudios del programa
## Pensamiento Sistémico y Complejidad

2 Créditos

2 UMES

Código: **OG0382**

Créditos 2

#### Seminario de Investigación I

Código: OG0383

Plan de estudios del programa
## Seminario de Investigación I

2 Créditos

2 UMES

Código: **OG0383**

Créditos 1

#### Proyecto integrador I

Código: OG0384

Plan de estudios del programa
## Proyecto integrador I

1 Créditos

1 UMES

Código: **OG0384**

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas electivas 

- [x] Plan de estudios del programa 

- [x] Trabajo de grado 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)