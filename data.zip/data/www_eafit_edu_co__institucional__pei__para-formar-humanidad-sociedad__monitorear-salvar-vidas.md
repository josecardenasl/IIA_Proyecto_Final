# Monitorear para salvar vidas, una​ misión de EAFIT a través del Siata

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Monitorear para salvar vidas,na​ misión de EAFIT a través del Siata​

*    Monitorear Para Salvar Vidas, Una​ Misión de EAFIT A Través del Siata 

​​​De la unión de EAFIT y el Área Metropolitana del Valle de Aburrá (AMVA) se desprenden investigación y desarrollo de instrumentos que favorecen desde el conocimiento científico y el desarrollo tecnológico y la innovación, hasta los mecanismos oportunos para identificar y pronosticar la ocurrencia de fenómenos naturales y antrópicos que alteren las condiciones ambientales de la región.

El Sistema de Alerta Temprana de Medellín y el Valle de Aburrá (Siata) es liderado por el Área Metropolitana y la Alcaldía de Medellín, con aportes de entidades como EPM e Isagén, y su gestión está a cargo de EAFIT. Desde hace diez años, el Siata monitorea las condiciones medio ambientales de la región en tiempo real, información que es útil para la prevención oportuna de emergencias naturales.

En la actualidad, está equipado con 23 tipos de sensores que conforman las redes de medición de variables hidrometeorológicas, sísmicas, de calidad del aire y de detección de incendios forestales. Además de los datos masivos generados para el estudio y la divulgación científica, el sistema presta servicios de gran utilidad para los ciudadanos como el pronóstico del clima a través de aplicativos móviles.

## En 2010 se consolida Siata como sistema de monitoreo en tiempo real.

## En 2014 se crea la aplicación para dispositivos móviles, desarrollada por el Siata.​

> En estos años que llevamos de monitoreo en tiempo real hemos prevenido casos muy importantes, lo que pasa es que cuando se salvan vidas no se nota y los periódicos no cuentan que una comunidad evacuó gracias a la información del Siata. Esta herramienta se la entregamos a los alcaldes del Área Metropolitana y a sus oficinas de Gestión del Riesgo para que ellos puedan hacer evacuaciones preventivas. De esta manera hemos salvado muchísimas vidas”Luz Jeannette Mejía Chavarriaga, líder en Unidad de la Gestión del Riesgo del AMVA e investigadora eafitense que participó en la gestación del Siata.

## 13. Acción por el clima

## 17. Alianzas para lograr el objetivo

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate