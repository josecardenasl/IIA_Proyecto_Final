# Expresión Corporal - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Expresión Corporal

*    Expresión Corporal 

###### ​Presentación

La vida universitaria se presenta como un campo nuevo, territorio desconocido, donde se articulan nuevos roles y dinámicas a los que debes enfrentarte y adaptarte. Desde esta perspectiva se presenta la Opción de Expresión corporal, entendiendo que estimular en ti como estudiante una actitud equilibrada contigo mismo y con el otro, parte de una comunicación honesta con tu sentir y las maneras de expresarlo en comunidad. A partir de un lenguaje lúdico la expresión corporal, te permitirá el afloramiento de la espontaneidad natural en un ámbito de respeto personal y social que se extienda a tu vida cotidiana en el habitar universitario.

###### Evaluación

Los criterios de evaluación se medirán en logros individuales y, en algunas ocasiones, grupales, dependiendo de la actividad y la intensidad de cada sesión.

70% Seguimiento.

30% Final.

###### Contenido

**Unidad 1: Exploración sensitiva: movimiento corporal. Elementos generadores del movimiento**

**Unidad 2: Exploración sensitiva: el movimiento en la relación espacio-tiempo.**

1.   Espacio externo
2.   Espacio íntimo

**Unidad 3: Exploración sensitiva: Dinámicas de tensión del movimiento entre sujetos.**

1.   Tensión proximal
2.   Tensión distal
3.   Posibilidades de exacerbación de sentidos, memoria sensible.

**Unidad 4: Exploración sensitiva: Diálogo Corporal.**

1.   Narrar con el cuerpo ​
2.   Comunicarse con el cuerpo

###### Bibliografía básica

Barba, Eugenio; Saverese, Nicola. 1990. El arte secreto del actor. México. Librería y Editora “Pórtico de la Ciudad de México”.

Cardona, Patricia. 2009. Dramaturgia del Bailarín. San José C.R. Aire en el Agua editores.

Ossott, Hanni. 2006. Memorias en ausencia de imagen, memorias del cuerpo. Medellín. Editorial Universidad de Antioquia.

Serres, Michel. 2011. Variaciones sobre el cuerpo. Argentina. Fondo de Cultura Económica.​​​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)