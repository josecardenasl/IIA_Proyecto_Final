# Estudiantes de colegios se sumergen en el inglés con EAFIT - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Estudiantes de colegios se sumergen en el inglés con EAFIT​

*    Estudiantes de Colegios Se Sumergen En El Inglés Con EAFIT 

Poder impactar en la calidad en la educación es un objetivo que ha motivado a la Universidad a trabajar durante 23 años en la enseñanza del inglés en las instituciones educativas, en condiciones de igualdad, con docentes expertos que aplican su saber y metodología con excelencia en planteles privados y oficiales, de distintas regiones y estratos.

Mejorar las competencias en inglés, asunto en el que aún persisten brechas en el país, ha sido la misión de Sislenguas​, que desde 1997 opera como un servicio de tercerización (outsourcing) integral para que los estudiantes logren alcanzar niveles altos de desempeño en este idiomas.

Adquirir unas fuertes bases en dicho idioma, les abre a los alumnos oportunidades de acceder a la educación superior y a oportunidades laborales en las que se les exige estar cada vez más actualizados. Dos aspectos que marcan una diferencia en la formación que imparte Sislenguas es la calidad de los maestros, no solo en el saber específico del inglés, sino en la didáctica y pedagogía, y el diseño de planes particulares para cada colegio.

## En la actualidad, cuentan con 14 colegios y a lo largo de estos años, en educación pública, han trabajado, además, con la Secretaría de Educación de Medellín y algunas escuelas normales, en convenio con la Gobernación de Antioquia

## 4. Educación de calidad

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)