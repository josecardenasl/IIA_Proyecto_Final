# International Business - EAFIT

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

Discover your profile at EAFIT

Are you a student, professor, graduate, or part of an organization? Explore the options and find the personalized information EAFIT has for you. Click on your profile and access resources, news, and events designed especially for you. Your EAFIT experience starts here!

**Your EAFIT experience starts here!**

Students and graduates

Employees

Teachers

Children and young people

Organizations

Close profiles

Information for you

*   That's EAFIT

Return

*   Study at EAFIT

Return

*   Science, Technology and Innovation

Return

*   Connecting with organizations

Return

*   Internationalization

Return

*   Culture and Wellbeing

Return

*   News

Return

###### **Let's transform together**

Let's make it possible for more young people to access university.

Close Menu

Accessibility

More information Activate contrast Decrease font size Standard font size Increase font size Enable or disable audio for users with visual impairments

Language

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Search 

Search

Menu

Undergraduate

# International Business

SNIES 1244, Medellin

Here you learn to give international dimension to an idea. At the end of this undergraduate, you will be able to carry a business around the world, interacting with diverse cultures, modes of production, distribution and thought schemes.

The globalization and postpania logic of regionalization are not a game, and you must know their rules and paths very well. In this undergraduate, you will develop the skills to negotiate in and for environments very different from the place where you were born: you will be a risk anticipator, connoisseur of markets, problems and possibilities.

If you have a natural inclination towards business and you are interested in establishing relationships beyond our borders, this undergraduate is for you. Here you will find a space to ask you what is international cooperation, foreign and consular service, foreign policy, markets and, in general, express concerns about how the world works and the exchanges that occur in it.

*    International Business 

## Qualified registration

Resolution 0​14359 of August 23, 2023​ valid for 8 years.

Duration

9 semesters

Location

Medellin

Schedule

Full-time

Language

English

More information

More than 80% of the courses are taught in English, with complementary subjects in Spanish and a third language certified by students.

Modality

In Person

SNIES

SNIES 1244

First Semester Tuition Fee

$14,364,164

Average Semester Tuition Fee

$13,981,109

Scholarships and financial aid

## About the program

Calidad y excelencia

**We are top in the world**

As an institution, we are accredited by AMBA (Association of MBAs) and AACSB (Association to Advance Collegiate Schools of Business), two of the three international accreditations that Business Administration, Economics and Finance programs can aspire to.

Our MBA (Master of Business Administration), for which you can transfer credits with our undergraduate degrees, has the highest accreditation from the AMBA (Association of MBAs) for five years and is the best in Colombia, according to the QS Ranking.

**We are backed by experience and tradition**

Our School was the first in Latin America to receive BGA (Business Graduate Association) accreditation; Our International Business program was a pioneer, in its category, in national accreditation.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

MercaLab, un espacio para enfrentarse a los retos de las organizaciones; Aula Makers, un escenario orientado al desarrollo del pensamiento creativo y computacional por medio de actividades de aprendizaje activo; Laboratorio Visual (Eye tracker), un lugar para las investigaciones sobre las diferentes dinámicas de percepción visual de los consumidores; el Aula de Innovación y Creatividad, desarrollado para fortalecer dinámicas de innovación, creatividad, desarrollo de productos y diseño de servicios; y la Cámara Gessell, un laboratorio para el análisis y la investigación desde la observación no participante.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en EAFIT.

Como Escuela organizamos eventos institucionales como Conamerc, Simpro, Gerenciar.

**Tenemos proyección y presencia nacional**

Estamos en Bogotá con nuestros programas de maestría en: Administración Financiera (MAF), Administración (MBA), Gerencia de Proyectos y Especialización en Finanzas. Y llegamos a Pereira con las maestrías en: Administración (MBA), Administración de Riesgos. También con las maestrías y especializaciones en: Mercadeo, Gerencia de Proyectos, Administración Financiera; y con la Especialización en Finanzas. En ambas sedes con flexibilidad de clases presenciales cada quince días y cada mes, según el programa.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

En pregrado cada persona tiene libertad para configurar su plan de estudios con 17 líneas de énfasis para elegir.

Se aprende desde la experiencia con retos empresariales y con la solución de proyectos reales.

Innovación y liderazgo

**Somos innovación en educación**

Nuestro modelo de formación ha sido replicado por universidades como El Tecnológico de Monterrey.

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de EAFIT y las áreas de conocimiento que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

En EAFIT tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Contamos con 40 grupos de investigación, 3 de ellos en categoría A1, la más alta posible; y más de 100 semilleros para el aprendizaje y crecimiento de los estudiantes.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Contamos con centro de estudios e incidencia, Valor Público y con un espacio de innovación y desarrollo social: EAFIT Social.

Tenemos a On.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Contamos con el Centro de estudio e incidencia de Gerencia y Empresa, donde nos preocupamos por entender los problemas presentes y futuros de las organizaciones y de acompañarlas en la construcción de soluciones sostenibles. También en la formación de sus líderes.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

Le damos consultoría a empresas del mundo, como el GOROM Institute.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

Tenemos alianzas con importantes universidades de negocios en Europa: Rennes School of Business, IÉSEG, Universidad de Estrasburgo. Recibimos clases con el Corean Institute.

Nuestros estudiantes pueden obtener doble titulación en el Bachelor in European Managment.

Contamos con posibilidades de aprendizaje como Vive la Experiencia Disney, un intercambio de cinco meses para estudiar y trabajar en los Parques.

**Representamos excelencia para los empleadores**

El 79,4% de nuestros graduados están laborando en las organizaciones donde hicieron las prácticas. Y el 89% de nuestros graduados están empleados.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrados han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores start-ups de Colombia.

## Curriculum

## Teachers

## Get to know our school

## Saber Pro Tests

## Guide for undergraduate applicants

Fechas y guía de inscripción

###### Dates and registration guide

Tu admisión dependerá del cumplimiento de los requisitos establecidos dentro de las fechas que encontrarás a continuación. Si deseas aplicar a una beca con EAFIT debes co​mpletar​ y pagar tu inscripción antes de las 11:59 p.m.​ del 9 de mayo​​ de 2025.

Si realizas tu inscripción antes del 12 de abril de 2025 conocerás el resultado de admisión a partir del 25 de abril.

Si realizas tu inscripción antes del 9 de mayo de 2025 conocerás el resultado de admisión a partir del 16 de mayo.

Si realizas tu inscripción antes del 30 de mayo de 2025 conocerás el resultado de admisión a partir del 6 de junio.

Si realizas tu inscripción antes del 17 de junio de 2025 conocerás el resultado de admisión a partir del 3 de julio.

Conoce la guía de inscripción para que sepas cómo consultar tu horario de clase, cómo asistir a tu inducción, cómo tramitar tu carné de estudiante, entre otros procesos.

Aplica a tu pregrado

###### Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en el este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario.
3.   Realiza el pago de $212.600 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

###### Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

###### Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Begin your registration process

The process has a cost of $212.600 COP.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Marketing

Duration

9 semesters

Location

Medellin

Schedule

Full-time

Language

Spanish

Modality 

In Person 

SNIES

SNIES 90979

First Semester Tuition Fee

$ 13,789,597

Average Semester Tuition Fee

$ 13,725,746

Scholarships and financial aid

#### Public Accounting

Duration

9 semesters

Location

Medellin

Schedule

Full-time

Language

Spanish

Modality 

In Person

SNIES

SNIES 1246

First Semester Tuition Fee

$ 13,789,597

Average Semester Tuition Fee

$ 13,853,428

Scholarships and financial aid

## **Nuestros graduados**

## Catalina Arroyave Restrepo

Cineasta

“Tuve profesores críticos, apasionados y rigurosos que me dieron una visión de la comunicación y el periodismo que sentó las bases de toda mi carrera profesional".

## Raquel Yepes Saldarriaga

Directora de comunicaciones y reputación en Argos

“El pregrado ofrece un enfoque multidisciplinario que me permitió tener los mejores docentes y maravillosas experiencias prácticas, al tiempo que se promueven otras actividades que van más allá del pregrado".

## Andrés Pastrana Cuartas

“What I value most is that I discovered my love for writing, and that was thanks to the diverse knowledge I acquired, which showed me how to put it into practice. Also, because I was challenged to create an excellent product and not just fulfill a requirement.”

### **News**

## The relevance of the teacher and their role in times of uncertainty and transformation

May 14, 2026

## EAFIT achieves its best result in the Saber Pro tests

May 13, 2026

## Global debate with a student touch

April 7, 2026

Study at EAFIT

Connect with EAFIT

Contact us

Legal information

Institutional Accreditation until 2026. 

Supervised by Ministry of Education.

Our campuses

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National line: 01 8000 515 900

Service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Service line: (57) 606 3214115, 606 3214119

Carrera 15 #88-64 office 401

Service line: (57) 601 6114618

Km 3.5 via Don Diego – Rionegro

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks

Original text

Rate this translation

Your feedback will be used to help improve Google Translate