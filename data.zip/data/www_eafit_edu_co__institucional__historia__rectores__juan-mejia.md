# Juan​ Luis M​ejí​a Arango​​​​​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Juan Luis Mejía Arango

(Rector entre 2004 y 2020)​​​

*    Juan​ Luis M​ejí​a Arango​​​​​ 

Un abogado de la Universidad Pontifi​cia Bolivariana llegó a EAFIT en 2004 para posesionarse como rector. Él le ha dado valor a la promesa de ser una universidad que Inspira Crea Transforma.

Desde el inicio de su gestión logró elevar el nivel cultural de los eafitenses al impulsar varios proyectos que así lo pueden constatar como el impulso a una agenda integrada por diferentes manifestaciones artísticas de la que no solo disfrutan los integrantes de la Institución, sino toda la ciudad.

En la parte académica sus directrices fueron, entre otras, la consolidación de la oferta de pregrados, el crecimiento en los segundos y terceros ciclos (maestrías y doctorados), la formación de los docentes y la acreditación de alta calidad de los programas.

De igual forma, fue el gestor del proyecto Universidad Parque donde la naturaleza y la infraestructura física se integran creando un ambiente propicio para la relación entre las personas y el aprendizaje. Esta iniciativa fue reconocida, en 2008, con el premio Lápiz de Acero en la categoría de espacios públicos, que le otorgó la revista ​Proyectodiseño.

​​​Juan Luis Mejía Arango lideró la modernización del campus con obras como la remodelación del bloque 26 de la Escuela de Administración; la construcción del Edificio de Ingenierías y del Centro de Acondicionamiento Físico Vivo; la adquisición del lote Los Guayabos, ubicado al frente del campus actual; la compra y la adecuación de múltiples casas en el barrio La Aguacatala, la adquisición y ampliación de la sede de EAFIT Pereira, la construcción de los edificios de Idiomas y Ciencias, entre otras.

De su gestión también se destaca el apoyo a las actividades de investigación, al programa Universidad de los Niños; así como al replanteamiento del direccionamiento estratégico y el Proyecto Educativo Institucional de EAFIT.

Lograr que EAFIT sea epicentro de eventos importantes para la proyección de la ciudad y el país es otro de sus aportes más visibles.

Pero quizás uno de los logros más importantes se materializó en 2010 y en 2018, cuando el Ministerio de Educación Nacional le entregó a la Universidad las renovaciones de la Acreditación Institucional, lo que le permite tener este aval público a la alta calidad hasta ​2026.

​

*Con datos del libro ​Universidad EAFIT 50 Años.​

#### Semblan​​​za

##### Construcción c​olectiva​​​ de una idea de Universi​​dad​​

## Sobre hombros de gigantes y de manera colectiva se ha construido la idea de Universidad en EAFIT

A punto de culminar su ciclo como rector de EAFIT, Juan Luis Mejía Arango presentó el informe Construcción colectiva de una idea de Universidad​, con un recuento por los últimos 24 años de la Institución, al abarcar los aportes de la Rectoría de Juan Felipe Gaviria (1996-2003) y los de los últimos 16 años (2004-2020) para consolidar a la institución humanista y vanguardista que es hoy.

 Durante este espacio, que se realizó el jueves 10 de diciembre desde el Auditorio Fundadores con trasmisión a través de las plataformas virtuales, el directivo enfatizó en que este no es un balance ni un informe de su Rectoría, sino un recorrido por la construcción de un proyecto educativo que se soporta en el compromiso de toda la comunidad eafitense.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)