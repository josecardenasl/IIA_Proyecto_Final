# Convocatoria Fondo de Solidaridad 60 años EAFIT - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Convocatoria Fondo de Solidaridad 60 años EAFIT

*    Convocatoria Fondo de Solidaridad 60 Años EAFIT 

##### Requisitos

​Los **estudiantes de pregrado y posgrado** que deseen participar en esta convocatoria deben cumplir los siguientes requisitos:

Requisitos para estudiantes de pregrado

Haber sido estudiante activo de pregrado en el semestre 2020-1.​

Demostrar una situación económica que se haya visto afectada, derivada de la coyuntura actual, que te impida a ti o a tu familia pagar la totalidad de la matrícula del semestre 2020-2. Para eso debes anexar una carta donde nos cuentes cuál es tu dificultad económica (máximo 400 palabras); y los documentos que demuestren que el responsable del pago de la matrícula ha tenido disminución o afectación de sus ingresos, pérdida de empleo, licencias no remuneradas, o cambios relevantes en el contrato laboral o como trabajador independiente.

Para 2020-2, estar cursando del segundo semestre de tu pregrado en adelante.

Tener un promedio crédito acumulado mínimo de 3.6 con corte al semestre 2019-2. Si en este momento eres estudiante de primer semestre, debes tener un promedio crédito acumulado mínimo de 3.6 con corte al semestre 2020-1.

Si en 2020-2 estarás entre el segundo y quinto semestre no haber perdido o cancelado más de dos materias. Y, para quienes comiencen el sexto semestre en adelante, máximo cuatro materias.

Debes cursar mínimo dos materias en el semestre 2020-2.

No ser beneficiario de becas o créditos condonables renovables para matrícula. ​

Requisitos para estudiantes de posgrado

Haber sido estudiante activo de posgrado en el semestre 2020-1.

Demostrar una situación económica que se haya visto afectada, derivada de la coyuntura actual, que te impida a ti o a tu familia pagar la totalidad de la matrícula del semestre 2020-2. Para eso debes anexar una carta donde nos cuentes cuál es tu dificultad económica (máximo 400 palabras); y los documentos que demuestren que el responsable del pago de la matrícula ha tenido disminución o afectación de sus ingresos, pérdida de empleo, licencias no remuneradas, o cambios relevantes en el contrato laboral o como trabajador independiente.

Para 2020-2, estar cursando del segundo semestre en adelante de tu posgrado.​

Tener un promedio crédito acumulado mínimo de 4.0 con corte al semestre 2019-2. Si eres estudiante de primer semestre debes tener un promedio crédito acumulado mínimo de 4.0 con corte al semestre 2020-1.

No haber perdido o cancelado más de una materia.

Debes cursar mínimo dos materias en el semestre 2020-2.

No ser beneficiario de becas del 100% o créditos condonables renovables en posgrado.

###### Ten presente

Debes cumplir con todos los requisitos y anexar la documentación completa.

La convocatoria estará abierta entre el 26 de mayo y el 14 de junio de 2020.

En caso de ser necesario, la Universidad te contactará para ampliar información.

Este apoyo económico no es excluyente con las líneas de financiación de EAFIT a tu alcance.

Los resultados serán enviados al correo electrónico institucional de cada estudiante el 30 de junio de 2020.

¿Necesitas más información?

### Teléfono

(57 4) 2619500, 01 8000 515 900.

### Whatsapp

(57) 3108992908

### Correo

contacto@eafit.edu.co

##### Conoce las iniciativas de apoyo que brinda la Universidad

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

###### ¡​Permanecer juntos nos fortalece como Universidad!

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate