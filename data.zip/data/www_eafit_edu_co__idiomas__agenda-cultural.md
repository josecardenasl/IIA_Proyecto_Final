# Agenda cultural - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Agenda cultural

Participa de actividades que te permitirán tener otra mirada del mundo y sus diferentes culturas.

*    Agenda Cultural 

¿Por qué hay tantos días festivos en Colombia?

Martes, 7 de mayo

 11:00 a.m. a 12:00 m

 Bloque 27 - 307

 Campus Universidad EAFIT​

¿Qué caracteriza la gastronomía francesa?

Miércoles, 8 de mayo

 12:45 m. a 1:45 p.m. 

 Bloque 27 - 307

 Campus Universidad EAFIT​

Día de la lengua portuguesa

Miércoles, 8 de mayo

 7:15 p.m a 8:30 p.m. 

 Bloque 35 - 501

 Campus Universidad EAFIT​

Intercambio de idiomas

8, 15, 22 y 29 de mayo

 1:00 p.m. p.m a 2:30 p.m. 

 Piso 3, 

 Idiomas Eafit​

Cineforo: Natale a tutti costi

Jueves, 9 de mayo

 6:45 p.m a 8:30 p.m. ​

 Bloque 33 - 204

 Campus Universidad EAFIT​

Gastronomía alemana

Jueves, 9 de mayo

 7:15 p.m a 8:30 p.m. ​

 Bloque 14 - 106

 Campus Universidad EAFIT

Cómo funciona el sistema de educación en Alemania

Y oportunidades de estudio en ese país.

 Martes, 14 de mayo

 5:00 p.m a 6:15 p.m. 

 Bloque 34 - 402

 Campus Universidad EAFIT

Ajedrez de Wuziqi

Martes, 14 de mayo - Jueves, 16 de mayo

 6:30 p.m. a 8:30 p.m. 

 Bloque 1 - 717

 Campus Universidad EAFIT

¡Tiempo para jugar y aprender!

Jueves, 16 de mayo

 10:30 a.m. a 11:45 a.m. ​

 Piso 3

 Idiomas EAFIT​

Busca ao tesouro!

Jueves, 23 de mayo

 12:15 m. a 1:45 p.m. 

 Piso 3

 Idiomas EAFIT​

Colombia: un lugar que reúne todos los ambientes del trópico

playas, llanuras, montañas, selvas, desiertos y glaciares

 Jueves, 23 de mayo

 11:00 a.m. a 12:00 m. ​

 Bloque 33 - 201

 Campus Universidad EAFIT​

Panoramica sulla storia dell'arte italiana

Miércoles, 29 de mayo

 6:45 p.m. a 8:15 p.m. ​

 Bloque 33 - 101

 Campus Universidad EAFIT​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)