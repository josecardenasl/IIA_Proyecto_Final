# Ingeniería Industrial - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

![Image 20: Pregrado en Ingeniería de Diseño de Producto, Escuela de Ciencias Aplicadas e Ingeniería.
Estudiantes hacen tareas en talleres de la Universidad.](https://universidadeafit.widen.net/content/kwpbslpxc3/web/pregrado-ingenieria-dise%C3%B1o-producto%20(1).jpg?crop=yes&k=c&w=1920&h=788&itok=orcqVjAC)

Pregrado

# Ingeniería Industrial

SNIES 117373, Medellín

¿Te apasiona resolver problemas complejos y transformar organizaciones? En pregrado en Ingeniería Industrial de EAFIT desarrollarás habilidades en analítica y finanzas que te permitirán diseñar, planear y operar cadenas de suministro sostenibles y competitivas.

*    Escuela Ciencias Aplicadas Ingenieria 
*    Ingeniería Industrial 

## Registro calificado

Resolución 019240 del 29 de Octubre de 2024. Vigencia por 7 años.

Duración

9 semestres

Lugar

Medellín​

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 117373

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$15.580.171

Becas y financiación

## Sobre el programa

Contenidos del programa

**1.1 Pregrado de Ingeniería Industrial ¿qué es?**

Aquí aprenderás a resolver problemas en diferentes niveles dentro de una organización: liderarás diversos procesos en toda la cadena de suministro, desde que surge una idea hasta que llega al cliente final. Serás el encargado de planificar y organizar todos estos procesos, y podrás hacerlos más rápidos, menos costosos y de mejor calidad. 

Este programa, planeado con un fuerte énfasis en analítica de datos y finanzas para la cadena de suministro, te permitirá una amplia salida a la vida laboral y oportunidades de especialización en programas como la Especialización en Dirección de Operaciones y Logística, la Maestría en Sostenibilidad, la Maestría en Finanzas y la Maestría en Ciencias de los Datos y Analítica, entre otras.

Si eres una persona propositiva, sueles tener iniciativas e ideas innovadoras, te gusta el pensamiento pragmático, tienes aspiraciones de liderazgo, te gustan las matemáticas y la computación, y tienes una idea de negocio o te gustaría mejorar un proceso que ya existe, este es tu programa.

**1.2 Perfil del aspirante**

Si te identificas con alguna de estas características, el programa en Ingeniería Industrial es para ti:

Te interesa conocer los procesos que hacen posible que los productos y servicios que se utilizan de manera cotidiana estén disponibles para su uso y consumo.​

Quieres saber cómo usar las matemáticas, la computación y las nuevas tecnologías para resolver problemas que afecten el desempeño de las empresas en la prestación de sus servicios y elaboración de productos

Tienes disposición para un aprendizaje continuo y permanente; con pensamiento crítico, que respeta la diversidad, con sentido de responsabilidad y compromiso por la sociedad. 

**1.3 Perfil profesional**

Como ingeniero industrial de la Universidad EAFIT resolverás problemas complejos en los niveles estratégico, táctico y operativo que se presentan en el diseño, la planeación y la operación de una cadena de suministro. Utilizarás técnicas de analítica, herramientas computacionales, financieras y de mejoramiento. Podrás aplicar nuevo conocimiento en diversas áreas de la profesión, comunicarte de forma gráfica, oral y escrita con una amplia variedad de audiencias, desempeñarte efectivamente en equipos de trabajo, e identificar los fenómenos naturales, humanos y sociales que faciliten la resolución participativa de problemas sociales y organizacionales.

Laboratorios

**Warehousing Lab:**

Aquí aprenderás sobre temas de almacenamiento, logística y clasificación de productos; robots, programación y nuevas ideas, que mejoran y facilitan los procesos de las empresas. Trabajarás en el desarrollo y aplicación de nuevas tecnologías que puedan ser adaptadas a las necesidades de la industria, para la toma de decisiones en el marco de la logística 4.0.

**Fábrica de Aprendizaje:**

Este es un espacio para que conozcas los nuevos retos de la industria y vivas las experiencias reales de los procesos de manufactura.

Preguntas Frecuentas

**¿En qué trabaja un ingeniero industrial?**

Podrás desempeñarte en una amplia variedad de cargos que combinan la optimización de procesos, la eficiencia operativa y el manejo de recursos en diferentes tipos de empresas, los cuales evolucionan a medida que adquiere experiencia. Comenzarás en roles operativos o analíticos y, con experiencia y formación adicional, podrás avanzar hacia puestos de liderazgo y gestión estratégica en diversas áreas como compras, producción, logística, calidad o consultoría. A continuación, encontrarás la descripción de algunos de los roles que podrás desempeñar.

**Cargos para recién graduados:**

**Analista de procesos:** Evalúa y mejora los procesos internos de la empresa, identificando ineficiencias y proponiendo soluciones para reducir costos y tiempos.

**Analista de datos:** Recolecta, organiza y analiza datos para apoyar la toma de decisiones en áreas como compras, ventas, producción o logística.

**Auxiliar o coordinador de logística:** Se encarga de gestionar actividades como la distribución de productos, la planificación de rutas y el control de inventarios para garantizar una entrega eficiente.

**Analista de Compras:** Identifica necesidades, evalúa proveedores y analiza precios para garantizar materiales a bajo costo y alta calidad.

**Asistente de producción:** Supervisa las operaciones diarias en la planta de producción, asegurándose de que los procesos se ejecuten según los estándares establecidos.

**Analista de Proyectos:** Planea y supervisa proyectos, optimizando recursos y tiempos mediante herramientas y metodologías de gestión.

**Analista de Planeación:** Diseña estrategias de producción y logística anticipando demandas y maximizando la eficiencia operativa.

**Coordinador de calidad:** Implementa sistemas de control de calidad para garantizar que los productos o servicios cumplan con los requisitos establecidos por la empresa y los clientes.

**Cargos con experiencia intermedia (5 a 10 años):**

**Supervisor de operaciones:** Dirige equipos y supervisa el cumplimiento de metas operativas, optimizando recursos y garantizando eficiencia en las actividades diarias.

**Ingeniero de proyectos:** Planifica, ejecuta y supervisa proyectos de mejora continua, como la implementación de nuevas tecnologías o la expansión de capacidades de producción.

**Coordinador de Compras:** Supervisa y optimiza el área de compras, asegurando procesos eficientes y relaciones sólidas con proveedores.

**Especialista en mejora continua:** Diseña y ejecuta estrategias basadas en metodologías como Lean Manufacturing o Six Sigma para optimizar procesos.

**Líder de cadena de suministro:** Gestiona y optimiza la logística, las compras y los inventarios a nivel estratégico para reducir costos y tiempos.

**Negociador:** Representa a la empresa en acuerdos estratégicos, maximizando beneficios mediante análisis de datos y estrategias de mercado.

**Coordinador de seguridad industrial:** Supervisa y mejora las condiciones de seguridad laboral para garantizar un ambiente de trabajo seguro y conforme a las normativas.

**Cargos con amplia experiencia (más de 10 años):**

**Gerente de operaciones:** Lidera y coordina todas las actividades operativas de la empresa, asegurándose de cumplir con los objetivos estratégicos.

**Gerente de logística o cadena de suministro:** Desarrolla estrategias para optimizar el flujo de bienes y servicios en la organización, negociando con proveedores y mejorando procesos.

**Gerente de planta:** Supervisa el funcionamiento completo de una planta de producción, desde el control de costos hasta la productividad de los empleados.

**Gerente de Compras:**Lidera la estrategia de adquisiciones, optimizando costos y estableciendo alianzas estratégicas en la cadena de suministro.

**Consultor en ingeniería industrial:** Brinda asesoría a empresas en la implementación de estrategias para mejorar su eficiencia operativa, gestión de recursos y productividad.

**Director de calidad:** Lidera las iniciativas de control y mejora de calidad a nivel organizacional, garantizando la satisfacción del cliente y el cumplimiento de normativas internacionales.

**Gerente general o directivo:** Con suficiente experiencia, un ingeniero industrial puede ocupar cargos directivos, liderando la estrategia global de una organización y tomando decisiones clave.

Sí. De hecho, hay programas muy cercanos con los que es fácil hacer doble titulación, por ejemplo, Ingeniería Mecánica, de Producción. Y posgrados como como la especialización en Dirección de Operaciones y Logística, la maestría en Sostenibilidad, la maestría en Finanzas y la maestría en Ciencias de los Datos y Analítica, entre otras.

###### Industrial - Producción

| Créditos Reconocidos | 124 |
| --- |
| % Similitud | 76,07% |
| Créditos por Cursar | 39 |
| Semestres Adicionales (Aprox) | 2 |

###### Industrial - Mecánica

| Créditos Reconocidos | 97 |
| --- |
| % Similitud | 59,50% |
| Créditos por Cursar | 66 |
| Semestres Adicionales (Aprox) | 4 |

###### Industrial - Civil

| Créditos Reconocidos | 91 |
| --- |
| % Similitud | 55,80% |
| Créditos por Cursar | 72 |
| Semestres Adicionales (Aprox) | 4 |

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Pruebas Saber Pro

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Ingeniería de Producción

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1249

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$16.060.617

Becas y financiación

#### Ingeniería de Diseño de Producto

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 7446

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$15.786.076

Becas y Financiación

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Con más de 700 organizaciones aliadas, así se expande la relación de EAFIT con las empresas

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)