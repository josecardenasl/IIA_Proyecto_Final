# Global Explorers - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 6: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Global Explorers

Vive una experiencia de inmersión en inglés en el extranjero. Aprende o mejora tu nivel, conoce nuevas culturas viajando con Idiomas EAFIT.

*    Global Explorers 

###### Embárcate en esta aventura… ​

Sumérgete en una experiencia única de aprendizaje del inglés en otros países. ¡Explora nuevos horizontes lingüísticos y culturales con nuestro programa de inmersión total! Prepárate para el éxito global y sé parte de los Global Explorers.

​Nos aliamos con BEA (Britannia English Academy) una escuela en Manchester, Reino Unido, con más de 10 años de experiencia. ​​

Creamos un plan de estudio según tus necesidades.

Garantizamos una metodología de enseñanza exitosa con resultados de aprendizaje.

Profesores nativos y certificados

Experiencia para personas mayores de 18 años

## Conoce Global Explorers

Destino

###### **Manchester**

Este increíble lugar es el hogar de dos de los clubes de fútbol más populares del mundo, es conocida por ser una ciudad industrial y por ser el centro cultural y deportivo de la región. Esta ubicada en el noroeste de Inglaterra. Su escena musical, arquitectura, hospitalidad multicultural y diversidad la hacen una ciudad única, perfecta para disfrutar. ​

Aterrizaje

###### **BEA**

BEA es una escuela boutique independiente en Manchester, Reino unido, lleva 10 años comprometido en proporcionar un curso académico de alta calidad impartido a través de las metodologías de enseñanza más eficaces que garantiza el logro exitoso de los resultados de aprendizaje.

​Acreditada por el British Council y es miembro de English UK. Estas son organizaciones que representan y ayudan a mantener las mejores escuelas de inglés en el país.

Actividades

###### **Actividades sociales**

1.   Club de conversación 
2.   Tour a BBC
3.   Sábado de talleres
4.   Viajes los fines de semana
5.   Club de fútbol
6.   Club de volleyball
7.   Visitas al estadio
8.   Clases de danza
9.   Clases de yoga

Ubicación

###### BEA

#### **Cursos**

## Inglés general

## Clubes de conversación

## IELTS

## Examen para Cambridge

## Inglés para propósitos específicos

## Lecciones privadas

## Clases virtuales

## Erasmus

## OET

## CLIL

## Inglés financiero

## Inglés para futbolistas

###### Te acompañamos… ​​​

La preparación a estas experiencias es clave para que todo salga bien. Por eso, pensamos en ofrecerte unos talleres pre-viaje para que cuando llegue el momento de tu viaje esté​s con toda la información.

## Inversión desde $8.500.000

Planes de 4 semanas sin tiquetes aéreos incluídos.

 *Estos planes son flexibles, puedes armarlos según tu preferencia en número de semanas y presupuesto.

## Duración 1h 30m c/u​

## 2 talleres​

###### ¿Qué vas a ver en los talleres? ​

1.   **New arrivals**

Información de llegada, migración, aeropuerto, primer transporte, ubicación. ​

1.   **Turismo**

Recomendaciones de lugares para visitar en Manchester y sus alrededores.

1.   **Grey or gray**

Entendiendo diferencias culturales y uso del idioma.

1.   **Apps and more**

Recomendaciones de aplicaciones últiles para el viaje.​

###### Acompañamiento académico constante

En todo tu proceso el equipo de docentes de Idiomas EAFIT te acompañará en varios momentos desde asistencia remota para hacer seguimiento a tu estadía, resolver dudas académicas y darte tips importantes que aportarán valor a tu experiencia. ​​

###### Formas y medios de pago

Realiza el pago directamente a la escuela a través del siguiente enlace, donde encontrarás las opciones disponibles:

Opciones de pago:

1.   Transferencia bancaria
2.   Transferencia internacional
3.   Tarjeta débito o crédito

## ¡Contáctanos!

(57) 604 2619500

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate