# Maestría en Dirección estratégica para el Turismo - EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

Posgrado

# Maestría en Dirección estratégica para el Turismo

SNIES 111456, Medellín

Los profesionales de esta industria deben desarrollar una mentalidad estratégica para realizar análisis sectoriales, prospectiva, estrategias de internacionalización y modelos de expansión. Este programa está diseñado para fomentar esa forma de pensamiento.

*    Maestría En Dirección Estratégica Para El Turismo 

## Registro calificado

Resolución 023341 del 9 de diciembre de 2022. Vigencia de 7 años.

Duración

3 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma 

Español

Modalidad

Blended

SNIES

SNIES 111456

Precio total del programa

$48.090.000 

## Sobre el programa

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Tenemos una pasantía internacional incluida en el tercer semestre, una materia de dos semanas que tomamos en una universidad par fuera de Colombia, a donde vamos y realizamos estudios de campo, casos y exploración de buenas prácticas.

La definición del destino para la pasantía se hace con base en los perfiles e intereses del grupo de estudiantes que viaja, para asegurar que las experiencias de aprendizaje activo en el destino sean de mayor relevancia y utilidad para los estudiantes.

Innovación y liderazgo

**Somos innovación en educación**

Esta es la única maestría en Turismo de Antioquia y la región cafetera, y se apoya en plataformas innovadoras para el aprendizaje remoto y digital, buscando la democratización de la formación avanzada en diferentes regiones del país.

La maestría tiene como objetivo cerrar la brecha de profesionalización en el sector y sistematizar y divulgar el conocimiento localizado del turismo a través de los trabajos de grado. Es un vehículo para contribuir a la generación de conocimiento y dar visibilidad a diferentes casos de estudio locales.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

El programa cuenta con profesores de Colombia, España, Estados Unidos, México y Dinamarca, quienes mantienen una relación permanente con organizaciones, investigaciones y las mejores universidades del mundo.

Nuestros graduados pueden desempeñarse como consultores e incluso desarrollar estrategias de acompañamiento y desarrollo territorial. También tienen la capacidad de ser gerentes de sus proyectos independientes y planeadores estratégicos de diferentes organizaciones del sector.

En el camino del emprendimiento, pueden apoyarse en ON.going, el centro de emprendimiento de alto impacto de EAFIT. En nuestra universidad tienen sede más de 21 iniciativas empresariales y emprendimientos de impacto.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrado han empezado sus emprendimientos. 1 de ellos están en la lista de las 100 mejores startups de Colombia.

Acreditaciones

**Acreditados en 2024**

​Menos del 6% de Escuelas de Negocios a nivel global, cuentan con este [reconocimiento](https://www.aacsb.edu/). Esta acreditación evalúa estándares de calidad académica al más alto nivel y representa el logro más importante para las Escuelas de Administración en el mundo entero.

**Reacreditados en 2019 – 2024**

La [Asociació​n del ​​MBA (Amba)](https://www.amba-bga.com/amba) acreditó a la maestría en Administración de EAFIT por cinco años, válida para los programas de Medellín, Bogotá, Pereira, Armenia y Guatemala. Esta acreditación conviert​e a la Universidad en la primera del departamento en recibir este reconocimiento, lo que le ofrece a sus egresados la posibilidad de competir en el mercado laboral internacional con profesionales de los mejores programas de MBA.

**Acreditados 2019 a 2024**

La [acreditación BGA](https://www.amba-bga.com/) es un sello de alta calidad que se otorga a las escuelas de negocios comprometidas con las prácticas de gestión responsable y el aprendizaje a lo largo de la vida, al mismo tiempo que demuestran un impacto positivo y creciente en sus estudiantes y comunidades. Nuestra Escuela se convirtió en la primera institución en América Latina en recibir esta acreditación en enero de 2020.​​

Membresías

**​European Foundation for Management Developme​nt (Efmd)**

​An international, not-for-profit, membership organization of business schools and corporations, based in Brussels, Belgium, with offices in Asia and the Americas.​

Nearly 900 member organizations from academia, business, public service and consultancy in 86 countries.​

A unique forum for information, research, networking and debate on innovation and best practice in management development.

Recognized globally as an accreditation body for quality & impact assessment in management with established accreditation services for business schools and business school programmes, corporate universities and online courses.​

**Prme**

Principios para una Educación Responsable en la Gestión o Principles for Responsible Management Education (Prme, por sus siglas en inglés), es una iniciativa de la Organización de las Naciones Unidas lanzada en la Cumbre de los Líderes del Pacto Global Mundial de las Naciones Unidas en Ginebra, y que relaciona a las Naciones Unidas y las Escuelas de Negocios con la secretaría de los Prme.

Todo con la finalidad de promover e inspirar una nueva forma de educación, de gestión responsable, de investigación y pensamiento de liderazgo a nivel mundial en los negocios. Para tal fin, proporciona el marco de Principios para la Educación Responsable de la Gestión, al desarrollar comunidades de aprendizaje y promover la conciencia sobre los Objetivos de Desarrollo Sostenible de las Naciones Unidas.

**Paciber​**

The mission of Paciber is to establish linkages to promote internation​al business education, research and exchanges of information, faculty and students; and to promote/widen the scope of cooperation, facilitate communication and expand consciousness about Asia among American member institutions (tomado de su sitio web).

**PMI​®**

EAFIT, desde hace más de tres años, es un Proveedor de Educación Registrado (R.E.P.s) que está aprobada por PMI® para ofrecer programas de este tipo. Es la única universidad en Medellín que tiene esta certificación.

**​Rankings​**

1.   Puesto 17 en América Economía 2023.
2.   Puesto 101 en el World University Rankings - Masters​ in Marketing​.

Renovación de la acreditación

###### Autoevaluación para acreditación​​​

**​¿Qué es la Acreditación de Alta Calidad?​​​**

La acreditación es el reconocimiento de la alta calidad que otorga el Ministerio de Educación Nacional a los programas académicos y a las instituciones que cumplen con los más altos criterios de calidad y que realizan sus propósitos y objetivos, teniendo en cuenta la naturaleza jurídica, identidad, misión, tipología, niveles de formación y modalidades. La acreditación en alta calidad promueve el fortalecimiento de una cultura de la alta calidad de los programas académicos y de las instituciones, que se soporta en los sistemas internos de aseguramiento de la calidad. La evaluación con fines de acreditación en alta calidad se realiza por la institución sobre sí misma y sus programas académicos, los pares académicos, y el Consejo Nacional de Acreditación – CNA.

**¿Qué es el proceso de autoevaluación?​**

La autoevaluación consiste en el ejercicio permanente de revisión, reconocimiento, reflexión e intervención que lleva a cabo la institución sobre sí misma o sobre un programa académico, con una amplia participación de la comunidad institucional y con el objetivo de valorar el desarrollo de sus funciones sustantivas, en aras de lograr la alta calidad en todos sus procesos, conforme los componentes del modelo de acreditación en alta calidad establecidos en el presente Acuerdo. La autoevaluación que adelanta internamente la institución culmina con un informe, el cual contiene los resultados y un plan de mejoramiento.

**¿Cuáles son los requisitos para optar por la acreditación de alta calidad ante el CNA?​**

**Programa académico acreditable. ​**

Es el programa académico que se encuentra autorizado para ser ofrecido y desarrollado por la institución y que cuenta con por lo menos ocho (8) años continuos de funcionamiento, verificable en el Sistema Nacional de Información de la Educación Superior – SNIES. Se consideran acreditables los programas académicos de los niveles de formación técnica profesional, tecnológico, universitario, maestría, especialidad, medico quirúrgica y doctorado.

**¿Quiénes participan de un proceso de autoevaluación y acreditación de programas académicos?**

Para surtir este proceso, se conforma un comité de autoevaluación y acreditación del programa, compuesto por el decano de la escuela, coordinador del programa académico, representantes de profesores, estudiantes y egresados del programa del posgrado, con el fin de tener una visión holística del programa. Este es un grupo responsable de la autoevaluación del programa, quien emite juicio integral sobre la calidad del programa, el cual debe contener argumentos soportados por evidencias cualitativas y cuantitativas. Así mismo, es el encargado de orientar el desarrollo del proceso, la redacción del informe final por parte del respectivo programa, el diagnóstico de problemas, la búsqueda de soluciones y la coordinación de estrategias para sustentar e introducir los cambios que se requieran para mejorar la calidad.​​

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

## **Nuestras acreditaciones**

### También te puede interesar

#### Maestría en Agronegocios

Duración

3 semestres

Lugar

Medellín

Más información

Universidad EAFIT (Medellín - Colombia) y ​Universidad de​ Zamorano (Honduras)

Horario

Encuentros sincrónicos y asincrónicos 

Más información

Clases sincrónicas mediadas por tecnología: miércoles y jueves de 6:00 p.m. a 10:00 p.m. GMT-5, y clases presenciales una semana al semestre en EAFIT y Zamorano.

Idioma 

Español

Modalidad

Blended

Más información

Semipresencial con mediación virtual/Blended

SNIES

SNIES 109910

Precio total del programa

$63.000.000

Más información

Semestre 1: COP 22.050.000

 Semestre 2: COP 22.050.000

 Semestre 3: COP 18.900.000

 Exclusivo pago en EAFIT.

 USD: 15.000, exclusivo pago en Zamorano.

 Nota: por favor, ten en cuenta que los valores pueden tener variaciones de acuerdo con el IPC.

 Valores válidos para 2026. 

#### Maestría en Gerencia de Proyectos - Bogotá

Duración

4 semestres

Más información

(los tres primeros semestres corresponden al plan de estudios de la Especialización en Gerencia de Proyectos).

 Periodicidad de admisión: seis meses.

Lugar

Bogotá

Horario

Viernes y sábado

Más información

Viernes de 6:3​0 p.m. a 10:00 p.m. y sábados de 7:3​0 a.m. a 12:00 m.​ y 1:00 p.m. a 5:00 p.m.

 ​​Puedes consultar la frecuencia semanal y/o quincenal con un asesor.​​​

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 109479

Precio total del programa

$58.768.246

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)