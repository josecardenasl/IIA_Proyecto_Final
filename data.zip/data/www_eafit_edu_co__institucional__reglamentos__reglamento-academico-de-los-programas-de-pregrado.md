# Reglamento académico de los programas de pregrado - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Reglamento académico de los programas de pregrado

*    Reglamentos 
*    Reglamento Académico de Los Programas de Pregrado 

### Lee el reglamento

##### Conoce tus deberes, derechos y ​potestades

Artículo 62. Deberes.

**Articulo 62. Deberes.** Son deberes de los estudiantes regulares de la Universidad EAFIT:

**a)** La asistencia a clase es un deber del estudiante como parte esencial de su formación académica.

**b)** Consultar, acatar y respetar la filosofía, los principios, los valores, la visión, la misión y los objetivos de la Universidad EAFIT, y actuar de conformidad con estos.

**c)** Consultar, acatar y respetar los estatutos y los reglamentos específicos de la Institución y las políticas académicas y administrativas de la Universidad EAFIT, y actuar de conformidad con estos.

**d)** Utilizar y reconocer como medio de comunicación oficial la cuenta de correo electrónico asignada por la Universidad EAFIT o herramientas informáticas establecidas institucionalmente para la gestión académica. El desconocimiento de la información institucional difundida por medio de los mensajes enviados electrónicamente no exime al estudiante de su cumplimiento.

**e)** Pagar oportunamente el valor correspondiente a los derechos de matrícula.

**f)** Presentar las pruebas, realizar los trabajos prácticos y cumplir con las demás obligaciones académicas que les sean asignadas por sus respectivos profesores o por las autoridades o instituciones que controlan, reglamentan y vigilan la educación en Colombia.

**g)** Proteger los bienes de la Institución: edificios, muebles, material de biblioteca, equipo de laboratorios, plataformas de aprendizaje, materiales de enseñanza, etc.

**h)** Dar a toda la comunidad universitaria un trato respetuoso, libre de coerción o intimidación.

**i)** Mantener en todo momento actualizada la información personal requerida por la Institución.

**j)** Presentar el carné de la Institución cuando le sea requerido.

**k)** Informar oportunamente a quien corresponda sobre cualquier anomalía que se presente en el normal desarrollo de su programa.

**l)** No portar, consumir o distribuir, dentro de las instalaciones de la Universidad EAFIT, sustancias prohibidas y controladas por la Ley o que afecten el sistema nervioso central y que no sean medicadas.

**m)**No portar, consumir o distribuir, dentro de las instalaciones de la Universidad EAFIT, salvo autorización expresa de las directivas de la Institución, bebidas embriagantes.

**n)** No portar, almacenar o comercializar armas u otro tipo de elemento que atente contra la integridad de la comunidad universitaria durante el desarrollo de actividades programadas por la Universidad EAFIT o que pueda ser utilizado

para destruir bienes de la Institución.

**o)** Respetar el nombre de la Universidad EAFIT.

**p)** Autogestionar el plan de estudios correspondiente, ya sea por la plataforma que la Universidad EAFIT disponga para el efecto o solicitando asesoría en la Oficina de Registro Académico, al asesor académico o en los canales de atención que establezcan las Escuelas o programas académicos, dado que es el estudiante quien es responsable de su proceso académico.

**q)** Abstenerse de utilizar o registrar el material, el contenido o las actividades pedagógicas de la Universidad EAFIT para finalidades distintas de las dispuestas por ésta, salvo si el profesor o la dependencia correspondiente lo autorizan.

**r)** No usar, difundir o realizar grabaciones o fotografías que registren la voz o la imagen de integrantes de la comunidad universitaria sin la autorización expresa de la persona registrada.

**s)** Evaluar honesta, respetuosa, imparcial y objetivamente las asignaturas y a sus profesores, en los tiempos designados por la Institución para tal fin y teniendo en cuenta los métodos y mecanismos aprobados por el Consejo Académico, con el propósito de garantizar y preservar la excelencia académica y de contribuir al mejoramiento continuo del quehacer docente. La Universidad EAFIT tomará las medidas necesarias para garantizar el cumplimiento de este deber en consideración con las medidas que defina el Consejo Académico.

**t)** Los demás deberes contemplados en este reglamento.

**Parágrafo 1.** Los egresados, durante el tiempo que se les concede para cumplir con los requisitos de grado, estarán sujetos al presente régimen de deberes.

**Parágrafo 2.** Los estudiantes transitorios estarán sujetos al presente régimen de deberes.

Artículo 63. Derechos y potestades.

**Artículo 63. Derechos y potestades.** Son derechos y potestades del estudiante de la Universidad EAFIT:

**a)** Poder elegir y ser elegido para los organismos universitarios colegiados donde los estudiantes tienen representación, siempre y cuando cumpla con los requisitos establecidos para cada caso.

**b)** Los estudiantes tienen el derecho de recibir educación en condiciones de calidad.

**c)** Hacer uso adecuado de las instalaciones y bienes de la Institución.

**d)** Ejercer, en forma responsable, la libertad para estudiar y aprender, acceder a las fuentes de información científica y tecnológica, investigar los fenómenos de la naturaleza y de la sociedad, debatir todas las doctrinas e ideologías y participar en nuevas formas de aprendizaje.

**e)** Participar en las actividades culturales y de recreación que se programen en la Institución.

**f)** Pedir audiencia al Consejo Académico cuando las circunstancias lo exijan.

**g)** Solicitar a la Oficina de Registro Académico la expedición de certificados que lo acrediten como estudiante de la Institución o que informen sobre su rendimiento académico, previa solicitud y pago de los derechos correspondientes y presentación de los documentos de paz y salvo exigidos; advirtiendo que el estudiante debe respetar los plazos establecidos por la Institución para su entrega.

**h)** Expresar su libre opinión en cualquier medio hablado o escrito a su alcance dentro de la Institución y de acuerdo con la reglamentación vigente, y recibir ejemplares de los diferentes medios informativos internos de EAFIT en las condiciones establecidas para cada publicación.

**i)** Contar con un carné y un número de identificación institucional vigentes que lo acrediten como estudiante activo de la Institución.

**j)** Evaluar honesta, respetuosa, imparcial y objetivamente las asignaturas y a sus profesores, en los tiempos designados por la Institución para tal fin y teniendo en cuenta los métodos y mecanismos aprobados por el Consejo Académico, con el propósito de garantizar y preservar la excelencia académica y de contribuir al mejoramiento continuo del quehacer docente. La Universidad EAFIT tomará las medidas necesarias para garantizar el cumplimiento de este deber en consideración con las medidas que defina el Consejo Académico.

**k)** Contar con un profesor especialmente designado por la Universidad EAFIT, por intermedio del jefe del programa de pregrado, con el apoyo de la Oficina de Registro Académico, que le servirá de asesor académico durante el desarrollo

de su itinerario en la Institución.

**l)** Conocer en la primera sesión de clases el programa de la asignatura con los objetivos de aprendizaje previstos, el aporte del programa al logro de los objetivos, la metodología, el instrumental, la bibliografía y las indicaciones sobre la forma de las evaluaciones y el temario comprendido. Lo anterior incluye el porcentaje de cada una de estas en la calificación definitiva de la asignatura y las fechas de realización.

**m)** Recibir oportunamente realimentación relacionada con las actividades evaluativas correspondientes a las asignaturas matriculadas en el período académico vigente.

**n)** Recibir la reposición de una actividad de aprendizaje como, por ejemplo: clases, prácticas de laboratorio, salidas de campo, etc., cuando sea cancelada por el profesor.

**o)** Los demás derechos contemplados en este reglamento.

**Parágrafo 1.**Los egresados, durante el tiempo que se les concede para cumplir con los requisitos de grado, tendrán los derechos aquí consignados.

**Parágrafo 2.** Los estudiantes transitorios tendrán todos los derechos aquí consignados, excepto lo contemplado en el literal a) de este artículo.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate