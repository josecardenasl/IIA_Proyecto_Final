# Así seguimos avanzando en el proceso de Autoevalu​ación Institucional​​​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Así seguimos avanzando en el proceso de Autoevalu​ación Institucional​​​

*    Así Seguimos Avanzando En El Proceso de Autoevalu​ación Institucional​​​ 

La imagen corresponde a uno de los últimos grupos focales que se realizó con integrantes del Comité Rectoral​

*   La Autoevaluación, con miras a la renovación de la Acreditación Institucional de Alta Calidad,​ es una tarea que sigue convocando a todos los eafitenses, especialmente ahor​​a que culminó la fase de aplicación de la encuesta de Autoevaluación Institucional y el desarrollo de grupos focales, para dar inicio a la construcció​​n de los informes de resultados.​​​
*   Más de 2.500 eafitenses, además de representantes del sector público, de los empresarios y empl​eadores, y del Comité Rectoral han participado en los espacios de recolección de ​información. Y como el proceso continúa quisimos compartir cuáles son los momentos que nos esperan para seguir transitando por el camino de la calidad y la excelencia.​

Desde el 29​​​​ de marzo de 2023, y hasta el 8 de mayo, todos los eafitenses fuimos convocados a una misma tarea: participar con compromiso en el proceso de Autoevaluación Institucional para lograr la renovación de la Acreditación Institucional de Alta Calidad.

¿Y cómo lo hicimos? durante esos tres meses diligenciamos la encuesta que recibimos en nuestros correos institucionales y que nos invitaba a revisarnos, a reflexionar sobre nuestra razón de ser, a resaltar lo que hacemos bien y a reconocer los aspectos en los que todavía podemos mejorar.

Este momento se conoce como la fase de recopilación y gestión de evidencias necesaria para continuar la renovación de la Acreditación Institucional, proceso que no podemos perder de vista dentro de nuestro quehacer cotidiano, pues todavía implica varios meses más de trabajo.

Así lo manifiestan Nicolás Carmona Ochoa, coordinador de Calidad Académica, y Lizeth Johana Gómez Ardila, asesora metodológica del proyecto de Renovación de la Acreditación Institucional, quienes explican que, además de este instrumento, también se realizaron unos grupos focales con funcionarios del sector público, empresarios y empleadores, y con integrantes del Comité Rectoral y, además se aplicará un instrumento de preguntas abiertas al Consejo Directivo.

“A los dos primeros, por ejemplo, les preguntamos sobre cómo percibían a la Universidad, cómo ven las nuevas Declaraciones Institucionales y qué consideraban que la Universidad debía mejorar de cara al futuro, especialmente para fortalecer el sistema de conexiones con las organizaciones”, menciona Nicolás Carmona.

A los segundos grupos, agrega el eafitense, les correspondió preguntas de carácter más interno, especialmente con respecto a la reciente transformación institucional, la pertinencia entre la Misión y Visión y las necesidades del entorno, la coherencia con la Universidad que nos soñamos para el futuro, la huella que queremos dejar en la sociedad y la imagen que buscamos proyectar ante los diferentes grupos de interés.

“Acabamos de terminar esa fase de recolección de información y superamos con creces la muestra estadística prevista. Tuvimos una participación de alrededor de 500 personas más de las que esperábamos, algo que evidencia el gran compromiso y el respaldo que tenemos todos con la calidad y la excelencia”, expresa Lizeth Gómez. Con esta información continúa una nueva fase del proyecto de Renovación de la Acreditación Institucional, con unos hitos específicos en el segundo semestre de 2023, y con otros en 2024 y 2025.

#### ¿Qué sigue en el proceso

​de Autoevaluación I​nstitucional?

Durante el mes de julio se estarán integrando los resultados de la encuesta y del desarrollo de los grupos focales, con la información recopilada por las mesas de trabajo establecidas en 2022, para pasar a la fase de análisis y construcción de los informes de cada uno de los 12 factores que serán evaluados. Luego, se avanzará en el análisis de los 12 factores, por parte de las mesas de trabajo, hasta el mes de septiembre.

En 2024, durante el primer semestre del año, los esfuerzos estarán enfocados en la consolidación del informe de Autoevaluación teniendo en cuenta las recomendaciones y correcciones del Comité. Luego pasará a una fase de revisión de estilo y se espera que sea radicado ante el Ministerio de Educación Nacional en agosto de ese año.

Entre los meses de octubre y noviembre de 2024 se realizará el proceso de socialización de los resultados ante el Comité de Autoevaluación Institucional, presidido por la rectora Claudia Restrepo Montoya.

En el resto de 2024 se estarán divulgando los resultados con la comunidad eafitense. Se espera que la visita de pares se realice entre 2024-2 y 2025-2.

“A todos los eafitenses queremos reiterarles nuestra gratitud por su compromiso y participación. E, igualmente, los invitamos a seguir conectados con este proceso, porque no es algo estático sino, por el contrario, una oportunidad, para revisarnos, reflexionar, poner lo mejor de nosotros y hacer que la Acreditación sea una vivencia de todos los días”, Lizeth Johana Gómez Ardila, asesora metodológica del proyecto de renovación de la Acreditación Institucional.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate