# Desarrollo Estudiantil - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Desarrollo Estudiantil

Conoce los servicios que Desarrollo Estudiantil tiene para tu bienestar y cuidado

*    Desarrollo Estudiantil 

El Departamento de Desarrollo Estudiantil, de la Dirección de Desarrollo Humano-Bienestar Universitario, busca contribuir a los procesos de crecimiento, bienestar y aprendizaje de los estudiantes en sus dimensiones psíquica, social, académica y económica a través de estrategias d​e acogida, apoyo, beneficios y formación integral que favorecen su salud mental, estabilidad y permanencia estudiantil.

El departamento se encuentra en el bloque 7 - piso 1 y Boque 29 – piso 5

Correo: [dllo.estudiantil@eafit.edu.co](mailto:dllo.estudiantil@eafit.edu.co)

Si necesitas ayuda psicológica conoce todas las líneas de​ atención [aquí​](https://www.eafit.edu.co/necesitas-ayuda)

###### Servicios e información destacada

Guía de apoyos para la permanencia y la graduación

Recursos, contenidos y contactos con los que la Universidad EAFIT te acompaña para la permanencia y graduación de pregrado

Apoyo Psicosocial y Psicopedagógico

Acompañamos la transición del colegio a la universidad y la integración social y académica, favorecemos la salud mental de los estudiantes, y aportamos al desarrollo de aptitudes y actitudes positivas hacia el aprendizaje.

Programa de monitorías

Entérate de cómo aplicar para las monitorías administrativas, académicas, de investigación, contraprestación y logística.

Ve​​ntas​ estudiantiles

​​¿Te gustaría vender dentro de la universidad?

Grupos y representantes estudiantiles

Los grupos estudiantiles son la unión de varios estudiantes que, de manera voluntaria, desarrollan proyectos desde y para la comunidad universitaria.

Permanencia estudiantil

Buscamos favorecer la permanencia estudiantil y la graduación oportuna en la Universidad EAFIT, mediante estrategias, programas y estudios concertados con la comunidad universitaria.

###### Líneas de atención

604 ​261 95 00 Ext. 9301, 9308​ y 8665

[dllo.estudiantil@eafit.edu.co](mailto:dllo.estudiantil@eafit.edu.co)​

Bloque 7 - piso 1 y loque 29 – piso 5

Contacto - Desarrollo Estudiantil 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

DlloEstudiantil

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Celular*? 

Correo electrónico*? 

Su comentario o solicitud*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)