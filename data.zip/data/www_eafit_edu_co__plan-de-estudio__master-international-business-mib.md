# Master of International Business - MIB - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Master of International Business - MIB

*    Plan de Estudio 
*    Master Of International Business - MIB 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

Semestre 1

Créditos 

totales-

Créditos 0

#### Nivelatorio: International Management

Código: GG7001

Plan de estudios del programa
## Nivelatorio: International Management

0 Créditos

0 UMES

This leveling course explores the impact of internal and external environments on multinational corporations, strengthening decision-making skills to navigate global value chains and competitiveness. Key Competence: Environmental Analysis.

Código: **GG7001**

Créditos 2

#### International Marketing and Sales I

Código: GG7002

Plan de estudios del programa
## International Marketing and Sales I

2 Créditos

2 UMES

Provides a strategic perspective on global consumer behavior and market entry, offering tools to face foreign competition and manage transactions in dynamic, hyperconnected international markets. Key Competence: Strategic Marketing.

Código: **GG7002**

Créditos 2

#### Intercultural Communication

Código: GG7003

Plan de estudios del programa
## Intercultural Communication

2 Créditos

2 UMES

Develops cultural intelligence and sensitivity to lead effectively in diverse workplaces, equipping managers to bridge communication gaps and succeed in multicultural, ever-changing global environments. Key Competence: Cultural Intelligence (CQ).

Código: **GG7003**

Créditos 2

#### International Management

Código: GG7004

Plan de estudios del programa
## International Management

2 Créditos

2 UMES

Focuses on strategic management beyond market factors, analyzing political contexts and stakeholder relations to address complex global realities and enhance critical thinking in international ventures. Key Competence: Non-market Strategy.

Código: **GG7004**

Créditos 2

#### International Marketing and Sales II

Código: GG7005

Plan de estudios del programa
## International Marketing and Sales II

2 Créditos

2 UMES

Focuses on managing B2B/B2C trade relations, emphasizing value propositions and long-term partnerships through effective negotiation and relationship management with international customers and suppliers. Key Competence: Relationship Management.

Código: **GG7005**

Créditos 2

#### International Project Management

Código: GG7006

Plan de estudios del programa
## International Project Management

2 Créditos

2 UMES

Prepares students to lead diverse teams and business projects across geographical distances, addressing global dynamics, regulatory differences, and cultural contexts from startups to SMEs. Key Competence: Global Leadership.

Código: **GG7006**

Créditos 2

#### Capstone Project 1

Código: GG7007

Plan de estudios del programa
## Capstone Project 1

2 Créditos

2 UMES

Cultivates advanced research skills, focusing on data validation and source analysis to support evidence-based decision-making and academic contributions within the international business field. Key Competence: Academic Research.

Código: **GG7007**

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)