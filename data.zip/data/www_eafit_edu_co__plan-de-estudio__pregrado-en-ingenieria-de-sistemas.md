# Curriculum effective from 2024-2. Undergraduate degree in Systems Engineering - EAFIT University

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

Discover your profile at EAFIT

Are you a student, professor, graduate, or part of an organization? Explore the options and find the personalized information EAFIT has for you. Click on your profile and access resources, news, and events designed especially for you. Your EAFIT experience starts here!

**Your EAFIT experience starts here!**

Students and graduates

Employees

Teachers

Children and young people

Organizations

Close profiles

Information for you

*   That's EAFIT

Return

*   Study at EAFIT

Return

*   Science, Technology and Innovation

Return

*   Connecting with organizations

Return

*   Internationalization

Return

*   Culture and Wellbeing

Return

*   News

Return

###### **Let's transform together**

Let's make it possible for more young people to access university.

Close Menu

Accessibility

More information Activate contrast Decrease font size Standard font size Increase font size Enable or disable audio for users with visual impairments

Language

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Look for 

Search

Menu

# Curriculum.

 Curriculum effective from 2024-2. Undergraduate degree in Systems Engineering

*    Study Plan 
*    Curriculum in effect as of 2024-2. Undergraduate Degree in Systems Engineering 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Classification of subjects

Filters

Semesters

1 

2 

3 

4 

5 

6 

7 

8 

9 

Cores, cycles, trajectories and emphasis

- [x] Basic science subjects 

Cantidad de créditos: 

- [x] Emphasis 

Cantidad de créditos: 

- [x] University Induction and Welfare 

Cantidad de créditos: 

- [x] Core of Institutional Training 

Cantidad de créditos: 

- [x] Program curriculum 

Cantidad de créditos: 

- [x] Pre-practice - Practice 

Cantidad de créditos: 

Semester 1

Total credits 17

Credits 0

#### Induction

Code: BU0010

Inducción y Bienestar Universitario
## Inducción

0 Créditos

0 UMES

Código: **BU0010**

Credits 1

#### University Welfare

Code: BU0011

Inducción y Bienestar Universitario
## Bienestar Universitario

 Cancelable 

1 Créditos

1 UMES

La asignatura Bienestar Universitario, por medio de actividades artísticas, deportivas, académicas y de reflexión, facilita la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, contribuyendo a la transición entre el colegio y la Universidad.

Código: **BU0011**

Correquisito Créditos 0

#### Taller de Salud

Código: BU0600

Credits 0

#### Health Workshop

Code: BU0600

Inducción y Bienestar Universitario
## Taller de Salud

0 Créditos

0 UMES

Código: **BU0600**

Credits 3

#### Calculus I

Code: CM0230

Asignaturas de ciencias básicas
## Cálculo I

3 Créditos

4 UMES

Código: **CM0230**

Credits 3

#### Logic

Code: CM0260

Plan de estudios del programa
## Lógica

3 Créditos

4 UMES

Código: **CM0260**

Credits 4

#### Programming Fundamentals

Code: ST0242

Plan de estudios del programa
## Fundamentos de Programación

4 Créditos

6 UMES

Código: **ST0242**

Credits 2

#### Principles of Software Development

Code: ST0243

Plan de estudios del programa
## Principios de Desarrollo de Software

2 Créditos

4 UMES

Código: **ST0243**

Credits 1

#### Systems Engineering Seminar

Code: ST0260

Plan de estudios del programa
## Seminario Ingeniería de Sistemas

1 Créditos

2 UMES

Código: **ST0260**

Credits 3

#### NFI

Code:

Núcleo de Formación Institucional
## NFI

3 Créditos

UMES

Código: 

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas de ciencias básicas 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Núcleo de Formación Institucional 

- [x] Plan de estudios del programa 

- [x] Prepráctica - Práctica 

Study at EAFIT

Connect with EAFIT

Contact us

Legal information

University with Institutional Accreditation until 2026. 

Supervised by the Ministry of Education.

Our headquarters

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National hotline: 01 8000 515 900

Customer service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Customer service line: (57) 606 3214115, 606 3214119

Email: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 office 401

Customer service line: (57) 601 6114618

Email: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks

Original text

Rate this translation

Your feedback will be used to help improve Google Translate