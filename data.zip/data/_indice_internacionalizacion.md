# Índice de Internacionalización - Universidad EAFIT

EAFIT cuenta con los siguientes internacionalización:

- **Partners Campus - Universidad EAFIT** — https://www.eafit.edu.co/internacionalizacion-campus/partners-campus
- **Internacionalización - EAFIT** — https://www.eafit.edu.co/internacionalizacion
- **Aprendizaje Global - EAFIT** — https://www.eafit.edu.co/internacionalizacion/aprendizaje-global
- **Convenios Internacionales - EAFIT** — https://www.eafit.edu.co/internacionalizacion/convenios
- **EAFIT, your next destination** — https://www.eafit.edu.co/internacionalizacion/eafit-next-destination
- **Global Engagement** — https://www.eafit.edu.co/internacionalizacion/global-engagement
- **Intercambio académico nacional - EAFIT** — https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional-eafit
- **Intercambio académico nacional - EAFIT** — https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional
- **Intercambio en el exterior - EAFIT** — https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior
- **Internacionalización en el campus - EAFIT** — https://www.eafit.edu.co/internacionalizacion/internacionalizacion-campus
- **Internacionalización del currículo - EAFIT** — https://www.eafit.edu.co/internacionalizacion/internacionalizacion-del-curriculo
- **Misiones académicas internacionales - EAFIT** — https://www.eafit.edu.co/internacionalizacion/misiones-academicas-salientes
- **Programas cortos de intercambio - EAFIT** — https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio
- **Partnerships - EAFIT** — https://www.eafit.edu.co/internacionalizacion/partnerships
- **EAFIT, tu próximo destino** — https://www.eafit.edu.co/internacionalizacion/tu-proximo-destino
