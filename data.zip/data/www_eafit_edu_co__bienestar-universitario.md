# Bienestar Universitario - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Bienestar Universitario

*    Bienestar Universitario 

###### ​​​​​​​​​​​La filosofía ​​de Bienestar Universitario

La Dirección de Desarrollo Humano y Bienestar pretende hacer del bienestar un valor individual y colectivo en la comunidad eafitense. Desde la conciencia del mutuo cuidado, con base en los valores institucionales invita a que la vida sea un vivir bien. Que las acciones sean una oportunidad para el recto actuar en un ambiente solidario y respetuoso de la diversidad y del entorno.

​Para lograrlo, la Dirección desarrolla programas y servicios para:

Contribuir al desarrollo de las personas en las dimensiones cultural, social, moral, intelectual, psicoafectiva y física.

Promover acciones que mejoren las condiciones de vida de la comunidad eafitense. ​​​

Fomentar hábitos y comportamientos que propicien el bienestar, el cuidado en el relacionamiento con otros y con el entorno, a partir del respeto por la diversidad.

Promover y trabajar por una cultura de respeto y una vida libre de violencia y discriminación, en temas de género, diversidad e inclusión, en la comunidad universitaria.

Promover el acceso, permanencia y graduación oportuna de

 los estudiantes de pregrado y posgrado.

​La Prestación de programas y servicios que se ofrecen desde la Dirección de Desarrollo Humano - Bienestar Universitario de la Universidad EAFIT, se llevan a cabo a partir de tres líneas de acción:

Vida Universitaria

Servicios dirigidos al cuidado, bienestar y mejoramiento de la calidad de vida estudiantil y laboral.

Representación Universitaria

Acompañamiento para la participación y representación universitaria. ​​​

Formación y Desarrollo

Servicios de apoyo que contribuyen al mejoramiento académico, laboral y a la formación integral.​​​

​Estas son algunas de las áreas que propician condiciones de bienestar en EAFIT:​

Departamento de Servicio Médico y Seguridad y Salud en el Trabajo

Deportes y Recreación

Desarrollo Artístico

Desarrollo Estudiantil

Género, diversidad e inclusión

Talento Humano

Contacto - Bienestar universitario 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto - Bienestar universitario

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Celular*? 

Correo electrónico*? 

Contenido de interés 

Su consulta*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)