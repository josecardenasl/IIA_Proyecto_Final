# Centro de Integridad​​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Centro de Integridad​​

###### El Centro fue una dependencia que promovió la reflexión ética, fomentando la educación con sentido y generó procesos edificantes. Hoy se ha transformado en la oficina de Género y Diversidad. Aquí la memoria de esta dependencia

*    Centro de Integridad​​ 

###### ​​​¿Qué era el Centro de Integridad?

## Misión

Fomentar una reflexión ética –individual y colectiva– en la comunidad eafitense que permita una formación humana y profesional, y a su vez contribuya a edificar una cultura de integridad en la Universidad y en la sociedad.​

## Visión

En el 2030 el Centro de Integridad de la Universidad EAFIT habrá inspirado la reflexión ética en la comunidad eafitense y su entorno, creado los cimientos necesarios para el desarrollo de una cultura de integridad y transformado los paradigmas que obstaculizan la coherencia entre el pensar, el sentir y el actuar de manera virtuosa.​​​​

## Ejes

El Centro desarrollaba sus acciones en tres ejes:​​​

 ​Educativo

 Investigativo

 De proyección

###### Objetivos del Centro de Integridad​​

Propiciar una deliberación colectiva y multidisciplinaria sobre la ética y la integridad académica en los diferentes ámbitos, tanto internos como externos a la Universidad.

​Incidir desde los principios de la ética discursiva en aquellas acciones, paradigmas y estereotipos que afectan los principios de la cultura ciudadana y la integridad académica.

Fomentar la apropiación de los Valores Institucionales de la Universidad EAFIT por medio de la interiorización consciente de las normas morales, legales y culturales, encaminada a la edificación de una cultura de integridad.

Acompañar a los docentes y estudiantes de la Universidad a lograr una excelencia en el ámbito académico e investigativo, caracterizada por la integridad.

Contribuir al campo de la ética aplicada a través del estudio de los retos morales contemporáneos, desde la investigación y la divulgación científica

###### ¿Qué es integridad?​

La integridad es el valor supremo de nuestra Universidad, en cuanto le provee horizonte moral a los demás valores institucionales. Integridad da cuenta de completud, de excelencia moral, de un actuar honesto y transparente, en el que la persona -consciente de su limitación humana- intenta cada día vivir de una manera respetuosa y generadora de bienestar para sí, para otros y para la naturaleza. La integridad es la coherencia entre el pensar, el decir y el hacer, siempre bajo principios éticos universales que buscan la justicia, la equidad y la inclusión. Tomado de: Valores Institucionales

###### ¿Qué es integridad académica?​

La integridad académica es un compromiso constante frente a la honestidad, la confianza, la justicia, el respeto, la responsabilidad y el coraje. Incluso en tiempos de adversidad.

**Tomado de: Centro Internacional de Integridad Académica​ - ICAI (1999:4) ​​​​​**

##### Atreverse a pensar​​

###### ¿Qué fue Atreverse a Pensar?​​​

Atreverse a Pensar inicia su construcción hacia finales de 2010 a raíz de la preocupación de representantes estudiantiles, directivas y docentes de la Universidad EAFIT, en torno al incremento en las prácticas deshonestas en las diferentes comunidades académicas en el país y en el mundo. Adicionalmente, en los últimos años las diferentes instituciones de educación superior en Colombia han visto cómo el plagio, manifestado sobre todo en copiar y pegar de Internet o de libros, sin la apropiada citación, se ha vuelto una práctica frecuente entre los estudiantes, e incluso, entre algunos pocos docentes.​

Para esto, se decidió abordar el fraude académico más ampliamente partiendo de la tesis de que éste es una manifestación de un problema sociocultural y de un sistema de valores y creencias de los colombianos, y no obedece solo una conducta específica. En ese sentido, se planteó la siguiente hipótesis: El culto a la viveza, tan imperante en esta sociedad, lleva a justificar en gran medida el incumplimiento de normas, aludiendo a decenas de razones, que en últimas hacen que cada quien defina su código moral y que la ética termine siendo relativa a cada individuo. En ese contexto, la ética, la integridad y la responsabilidad son valores que se ven amenazados diariamente, tanto en el contexto académico como en el de la vida cotidiana.

Aunque no hay evidencia científica de que quien comete fraude académico necesariamente será un corrupto, o quien tira basura a la calle llegará a ser un empleado deshonesto, no es aventurado afirmar que quien no acata las normas y a menudo encuentra caminos para evadirlas – tengan éstas o no sanción de alguna naturaleza – desarrolla dentro de sí un sistema de creencias y unos hábitos que lo influenciarán en distintos momentos y contextos de su vida a actuar en forma poco íntegra, incluso sin ser consciente de que lo está haciendo.​

Por lo tanto, se crea este programa institucional​ orientado a la prevención y erradicación de cualquier forma de fraude académico o administrativo, y a garantizar el pleno respeto de los derechos de autor por parte de estudiantes y profesores, en todas las actividades académicas, a través de la deliberación y reflexión sobre estos diferentes fenómenos que tanto daño le están haciendo al país.

Según Juan Luis Mejía, exrector de EAFIT, la Universidad, en su papel de formador de profesionales y educador de ciudadanos, cree que debe hacer un alto en el camino y abrir un espacio para poner estos asuntos en la conversación y el análisis de la comunidad eafitense. Si bien la Universidad es consciente de que en la ética de los ciudadanos influyen un sinnúmero de factores, sí cree urgente que la posición de nuestra comunidad universitaria frente​ a conductas como la corrupción, la deshonestidad, la mal entendida viveza paisa y el engaño, sea cuestionada.

Fases​

Primera​​ fase: Culto a la viveza​

El culto a la viveza es un fenómeno con el que conviven los colombianos día a día. Se manifiesta en diversos contextos: la manera agresiva al conducir para pasarse al otro, la compra y venta de películas piratas, la evasión de impuestos por parte de personas naturales y jurídicas, la actitud ventajosa en los negocios,​ y la compra y venta de artículos de contrabando, entre muchos otros.

Segunda fase: Ética y academia

En septiembre de 2011 inició una nueva etapa que se concentró en la ética y la academia, una relación que por la naturaleza y la responsabilidad del acto educativo en la universidad debería ser armoniosa pero que, lamentablemente, se rompe con bastante frecuencia. Ahora, ¿qué tiene que ver el culto a la viveza con el fraude académico? Todo.

Tercera fase: Cultura ciudadana

El proyecto Atreverse a Pensar llega a su tercera fase: cultura ciudadana, entendida esta como el conjunto de costumbres, acciones y reglas mínimas compartidas que generan sentido de pertenencia, facilitan la convivencia urbana y conducen al respeto del patrimonio común, y al reconocimiento de los derechos y deberes ciudadanos.

Cuarta fase: Ser mejor

La Universidad EAFIT, en 2012, decidió apostar por la transformación cultural de la comunidad universitaria a través de la definición de Atreverse a Pensar como un programa institucional permanente "orientado a la prevención y erradicación de cualquier forma de fraude académico o administrativo, y a garantizar el pleno respeto de los derechos de autor por parte de estudiantes y profesores, en todas las actividades académicas" (i).

Quinta fase: Integridad acadé​mica

La quinta fase del programa institucional Atreverse a Pensar tiene como tema la integridad académica. Este componente es el eje central de esta parte de la iniciativa que, a través de nuevas frases, imágenes y reflexiones, plantea y refuerza en la comunidad​ académica y universitaria el propósito de esta propuesta permanente de la Universidad que surgió hacia fines de 2010.

Sexta fase: Atreverse a Pensar​

"En esta fase se busca una reflexión para mostrar que esas situaciones que tienen un tinte problemático para la ética académica hay que saberlas resolver, pues muchas veces no nos tocan como estudiantes, sino como amigos y consejeros de otros que pueden estar enfrentándolas", comenta Juan Rafael Peláez Arango, analista de Atreverse a Pensar.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate