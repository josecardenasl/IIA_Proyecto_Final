# Con MinCiencias, EAFIT irradia su conocimiento para aportar a los desafíos​]

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Con MinCiencias, EAFIT irradia su conocimiento para aportar a los desafíos​

*    Con MinCiencias, EAFIT Irradia Su Conocimiento Para Aportar A Los Desafíos​ 

Tres proyectos de investigación de EAFIT y uno más en el que la Universidad participa como parte de la alianza Caoba, fueron aprobados en la convocatoria del Ministerio de Ciencia, Tecnología e Innovación para frenar al nuevo coronavirus. Las propuestas se enmarcan en algunas de las cinco temáticas planteadas por dicha convocatoria: salud pública, sistemas de diagnóstico, estrategias de prevención y tratamiento, equipos y dispositivos, y sistemas de monitoreo.

Ellos son: Viabilidad y validación de la aplicación de modelos de inteligencia artificial para la detección de neumonía en los servicios de radiología de hospitales de tercer y cuarto nivel de Medellín, liderado por Olga Lucía Quintero Montoya, doctora en Ingeniería de Sistemas de Control y profesora del Departamento de Ciencias Matemáticas; Desarrollo a escala piloto de una membrana de filtración basada en nanofibras para el manejo de pacientes con infecciones respiratorias agudas-COVID 19, a cargo de Mónica Lucía Álvarez Láinez, investigadora principal, doctora en Física y profesora del Departamento de Ingeniería de Diseño de Producto; y Plataforma web para la recolección de datos, visualización, análisis, predicción y evaluación de estrategias de control de la enfermedad producida por SARS-CoV-2 mediante herramientas de modelación matemática, simulación e inteligencia artificial, liderado por María Eugenia Puerta Yepes, doctora en Ciencias Matemáticas y profesora del Departamento de Ciencias Matemáticas.

Desarrollo y evaluación de modelos matemáticos y epidemiológicos que apoyen la toma de decisiones en atención a la emergencia por SARS-COv-2 y otros agentes causales de IRA en Colombia utilizando Data Analytics y Machine Learning, que coordina el docente Edwin Nelson Montoya Múnera, doctor en Ingeniería de Telecomunicación y profesor del Departamento de Informática y Sistemas, es otro de los proyectos donde interviene EAFIT como parte del Programa Caoba, un convenio que lidera la Pontificia Universidad Javeriana para el desarrollo de la analítica de datos y el big data.

###### En palabras de los investigadores

> Es un estudio que tiene y busca la validación médica clínica, lo que es muy importante en este tipo de ayudas a la toma de decisiones basadas en inteligencia artificial. Se trata de que los expertos médicos sean los validadores con todo el formalismo de la medicina de este desarrollo”Olga Lucía Quintero Montoya

> En el largo plazo, el desarrollo propuesto no solamente sirve para afrontar esta contingencia. Además, es un sistema que sirve para afrontar la problemática ambiental que genera la contaminación del aire por el material particulado del tipo 2.5 PM (material particulado)”Mónica Lucía Álvarez Láinez

> Este proyecto tendrá impactos para el país a corto, mediano y largo plazo. A corto plazo podrá evaluar diferentes estrategias de mitigación de la pandemia y prever los efectos en las dinámicas socioeconómicas. Esto con el fin de permitir la toma de decisiones más informadas y respaldadas por resultados científicos simulados”María Eugenia Puerta Yepes

> Esto permitirá preparar mejor el sistema de salud. Será un proyecto que integrará las principales fuentes oficiales de Colombia y el mundo sobre el coronavirus para apoyar la toma de decisiones en el Instituto Nacional de Salud (INS). Permitirá contener, entender y conocer los patrones de infección y transmisión para analizar la capacidad hospitalaria del país en atención del covid-19”Edwin Montoya Múnera

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)