# Reserva de escenarios deportivos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Reserva de escenarios deportivos

Reserva escenarios deportivos en EAFIT: cancha sintética, tenis, baloncesto y más. Reserva por correo o Teams.

*    Reserva de Escenarios Deportivos 

##### Realiza tu reserva por correo o por Teams

**Correo:**[​​reservasdeportes@eafit.edu.co](https://www.eafit.edu.co/bienestar-universitario/deportes/%E2%80%8B%E2%80%8Breservasdeportes@eafit.edu.co) ​​

**Teams:** ​​reservasdeportes

Asunto: Reserva placa sintética (tenis de campo, baloncesto, voleibol, o/y fútbol sala)

Nombre completo

Horario reserva

Dia reserva

Número celular

Dependencia/pregrado o posgrado​​

Cancha sintética fútbol 7

Placa sintética de tenis de campo

Placa sintética de fútbolsala

Placa cubierta de baloncesto y voleibol

##### A partir de las 5:00 p.m. las canchas sintéticas son admistradas por el [Gimnasio Vivo](https://www.eafit.edu.co/servicios/gimnasio-vivo)

**Tienes el privilegio de disfrutar de nuestros espacios deportivos, entre las 6:00 a.m. y 5:00 p.m. Previa reserva.**

###### Generalidad​es:

Si requieres implemento deportivo para la pra​ctica, estos se prestan exclusivamente en el momento de la actividad, dejando tu carnet de eafitense.

​Nuestros escenarios son exclusivos para eafitenses y no tiene costo.

​​Los elementos que se tienen en los escenarios deportivos no deben ser movidos ni trasladados a otro lugar, sin previa autorización.

Se encuentra prohibido el consumo de sustancias psicoactivas.

Se encuentra prohibido retirarse la camiseta para el desarrollo de la actividad

​Cuando se presentan codiciones climá​ticas​, con tormentas eléctricas o lluvias fuertes, la actividad deportiva debe ser suspendida.

​​​Los camerinos, tienen duchas con dispensador de jabon.​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate