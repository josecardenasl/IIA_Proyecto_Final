# Especialización en Gestión Tributaria Internacional - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Especialización en Gestión Tributaria Internacional

SNIES 102966, Medellín

Un mundo en el que los negocios son multinacionales requiere personas con un criterio analítico para entender los impuestos locales e internacionales y gestionar situaciones tributarias globales. En nuestra especialización nos enfocamos en un análisis integral para gestionar los impuestos desde las leyes, sus reglamentaciones, la jurisprudencia y la doctrina, así como el entendimiento de los efectos bilaterales de los impuestos en las transacciones comerciales.

Si eres contador, abogado, economista, administrador o tienes un interés en entender el campo tributario internacional porque trabajas o eres el dueño de una empresa que se está globalizando, tienes aliados o clientes en el exterior, y en general te interesa la inversión extranjera, la apertura de nuevos mercados y negociación, esta es la especialización indicada para ti**.**

*    Escuela Administracion 
*    Especialización En Gestión Tributaria Internacional 

## Registro calificado

Resolución 007642 del 4 mayo de 2022.​​ Vigencia por 7 años.

Duración 

2 semestres

Lugar

Medellín

Horario

Viernes y sábado 

Más información

Viernes de 5:00p.m. a 9:00p.m. y sábado de 8:00a.m. a 12:00p.m.

Idioma

Español

Modalidad 

Presencial

SNIES

SNIES 102966

Precio total del programa

$26.484.866

## Sobre el programa

Contacto

###### Ejecutiva de promoción

**Luz Marina Montoya**

+57 310 2273422

lmontoya@eafit.edu.co

### También te puede interesar

#### Maestría en Administración de Riesgos - Medellín

Duración

3 semestres

Lugar

Medellín

Horario

Viernes y sábado

Más información

Presencial fines de semana cada 15 días

 Viernes de 5:00 pm a 9:00 pm y sábado 7:30 am a 4:30 pm. Dependiendo de la extensión de la materia conexión por Teams.

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 102967

Precio total del programa

$56.879.588

#### Maestría en Administración - MBA Medellín

Duración

3 semestres

Lugar

Medellín

Horario

Modalidad regular e intensiva

Más información

Medellín - modalidad regular

 Clases presenciales cada 2 semanas, jueves y viernes de 17.00 a 21.00 y sábados de 08.00 a 12.00

 Medellín - modalidad intensiva

 Clases presenciales una semana al mes, de lunes a viernes de 17.00 a 21.00 y sábados de 08.00 a 12.00

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1265 

Precio total del programa

$84.862.286

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)