# ​​​Geometric analysis of trapezoidal hills subject to vertically incident SH waves​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​​​Geometric analysis of trapezoidal hills subject to vertically incident SH waves​

*    Escuela Ciencias Aplicadas Ingenieria 
*    ​​​Geometric Analysis Of Trapezoidal Hills Subject To Vertically Incident SH Waves​ 

**Abstract**

Topographic effects have been shown to play a significant role on the local ground response during earthquakes. However, due to the large number of involved parameters the problem is rarely considered in seismic design regulations. Recently, there has been a tremendous development by the engineering community, regarding methods and computational infrastructure to address the problem via numerical simulations.

Although numerically based models may give accurate results when fed with appropriate field data, the obtained solutions are still very limited and strongly dependent on unknown factors like the input excitation. Therefore, there is a clear need to develop strong conceptual understanding allowing practising engineers to arrive at first order approximations, useful to validate complex numerical solutions. In this work we explore the use of purely geometrical methods in the determination of the dynamic response of trapezoidal geometries to vertically incident horizontally polarized shear waves.

The geometries may be considered representative of hills or earth embankments, depending on its characteristic dimensions. The hill response is first found with a frequency domain based b​oundary element code and the results are later analysed using a geometric approach, where the solution is partitioned into incident and reflected rays, forming the incoming or optical field, and the diffraction contribution.

This last term is obtained with a technique available from the literature. The analysis corresponding to the optical field, reveals that there are only 5 possible scenarios or different solutions and that any given hill can be classified into one of these five possible cases. Depending upon the dimensionless frequency of the problem (relating incident wavelength to the hill characteristic dimension), the solution is found to be governed by the optical solution or by the contribution from the diffraction terms. The results are first presented in terms of frequency amplitude functions since that description facilitates the analysis by geometric methods, however for completeness, the resulting transfer functions are later used to obtain results in the time domain representative of typical numerical solutions as the ones derived with commercial computational software.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate