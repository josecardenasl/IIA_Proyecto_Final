# Servicios Datapol - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Servicios

El laboratorio sirve de apoyo docente para la implementación de las técnicas que responden a la lógica de análisis cualitativo y cuantitativo para los fenómenos socio-políticos.

*    Servicios Datapol 

Brinda a los estudiantes del pregrado en Ciencias Políticas y de la maestría en Gobierno y Políticas Públicas un centro de cómputo en el que pueden realizar ejercicios para conocer el uso de estas técnicas aplicándolas en sus trabajos de asignaturas.

A su vez, busca ser un espacio material y social para el refuerzo al aprendizaje de herramientas que le permitan a los estudiantes de pregrado y posgrado aplicar los conocimientos específicos para contribuir por medio de la investigación en el ámbito socio-político describiendo, explicando y proponiendo. Finalmente, es un espacio para el desarrollo de las actividades de investigación que se realizan desde los semilleros y grupos de investigación.​​

## Servicios: ¿Cuál es la finalidad?, aprender haciendo

Replica para conocer

Autoaprendizaje, consulta y apoyo didáctico: lunes a jueves de 9:00 a.m. a 12:00 p.m. y de 2:00 a 6:00 p.m. [(Previa reserva de espacios y recursos. Sujeto a disponibilidad del aula).](https://www.eafit.edu.co/reserva-de-espacios-y-recursos)

Uso del aula por parte de estudiantes de pregrado y posgrado del Departamento para mejorar el aprendizaje y la práctica del uso de fuentes de información y tratamiento de datos.

Experimenta para comprender

Trabajo o talleres de clase: para pregrado y posgrado de lunes a viernes a través del formulario de reservas.

Los docentes que deseen hacer uso del préstamo del aula para clases, trabajos o talleres deben hacer la [reserva de espacios y recursos hasta la segunda semana de clases.](https://www.eafit.edu.co/reserva-de-espacios-y-recursos)

Aplica para transformar

Actividades de investigación (semilleros, proyectos): Lunes a viernes de 12:00 a 2:00 p.m. y de 6:00 a 8:00 p.m.

Reuniones académico-administrativas o de consultoría según las [reservas realizadas por los docentes del Departamento a través del formulario de reserva de espacios y recursos.](https://www.eafit.edu.co/reserva-de-espacios-y-recursos)

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)