*    IELTS 

## Información general

Descripción del examen

El examen IELTS (International English Language Testing System) evalúa las habilidades lingüísticas de las personas que desean estudiar, migrar o trabajar en lugares donde el inglés es el idioma oficial de comunicación. Esta certificación está contemplada dentro de la política de lengua extranjera de la Universidad EAFIT.

Proceso de inscripción

El registro y pago del examen se hace de manera exclusiva a través de la página del British Council (la Universidad EAFIT **no recibe pagos bajo ninguna modalidad** ya que la tarifa que usted está cancelando es directamente generada por British Council, ente oficial del examen.)

Inscripción IELTS en computador: [https://ieltsregistration.britishcouncil.org/test-chooser](https://ieltsregistration.britishcouncil.org/test-chooser)

**Descuento para la comunidad de las universidad que hacen parte de la red ASCUN**

Si usted es estudiante activo, egresado y/o empleado con carné vigente de alguna de las universidades que hacen parte de la red ASCUN [http://ascunorg-cp790.wordpresstemporal.com/ies-asociadas/](http://ascunorg-cp790.wordpresstemporal.com/ies-asociadas/) tiene **10% de descuento** en la inscripción al examen IELTS.

Para acceder a este descuento, es necesario que contacte a la universidad ASCUN a la cual está vinculado ([ver lista de contacto aquí](https://universidadeafit.widen.net/s/jhqmsrqgf8/contacto-universidades-ascun))​ solicitando el promo code para la inscripción al IELTS. Debe enviar su nombre completo, documento de identidad, carné escaneado y la fecha en que desea presentar el examen. Después de que le envíen dicho código, puede proceder con la inscripción al examen en la fecha ya informada [https://ieltsregistration.britishcouncil.org/test-chooser](https://ieltsregistration.britishcouncil.org/test-chooser)

**Nota:** El promo-code es personal e intransferible y de un solo uso. Será válido exclusivamente en la fecha que usted informe a su universidad, se aplica **únicamente** para sesiones presenciales en la Universidad EAFIT.

Este promo-code se enviará en **4 días hábiles**.

Estructura

La prueba, cuya duración es de **3 horas**, tiene 4 componentes; escritura, comprensión lectora, escucha y conversación, **este último componente es evaluado con una entrevista presencial** que es adicional al tiempo ya informado.

La universidad EAFIT ofrece el **IELTS Academic y IELTS General ambos a computador y presenciales en nuestro centro de exámenes**, usted debe elegir el formato que más se acomode a sus necesidades.

Inversión

### IELTS

$1.045.700

Calendario 2026

###### Programación de IELTS formato general y académico:

| Fechas |
| --- |
| Abril 24 |
| Mayo 2 |
| Mayo 9 |
| Mayo 15 |
| Mayo 16 |
| Mayo 29 |
| Junio 5 |
| Junio 13 |
| Junio 19 |
| Junio 20 |
| Julio 10 |
| Julio 11 |
| Julio 18 |

Formato

**CD (Computer Delivered):** La prueba se presenta en computador y los resultados se entregan en **7 días hábiles.**

Notificación de resultados

Los resultados se publican en línea **7 días hábiles** después de haber realizado el examen.

Observaciones

Al inscribirse al examen IELTS el candidato tendrá acceso a los siguientes beneficios:

1.   **Road to IELTS: t**utorial de preparación en línea con 30 horas de material gratuito.
2.   **Aplicaciones móviles:** preparación gratuita para el examen desde dispositivos móviles.
3.   **MOOC Understanding IELTS:** curso en línea gratuito para desarrollar técnicas para la presentación del examen.
4.   La citación oficial al examen la recibirá directamente a su correo electrónico y es **enviada por el British Council**. Favor revisar su bandeja de entrada y/o spam con **3 días de anticipación al examen**, allí encontrará la información relacionada: lugar, hora exacta, documentos de identidad válidos, número de registro y toda la información relevante que usted debe conocer antes de presentar la prueba.

###### Preguntas frecuentes

​​​Conoce nuestros protocolos e información general sobre nuestro Testing Center.

1.   Estudiantes que desean ingresar y/o egresar en una institución de educación superior.
2.   Estudiantes en proceso de admisiones y/o egreso del programa de aprendizaje del idioma inglés.
3.   Candidatos que desean presentarse para obtención de becas y certificaciones.
4.   Alumnos de diferentes programas de aprendizaje en idiomas, que desean controlar su progreso.
5.   Estudiantes y trabajadores que solicitan visas.
6.   Empresas y/o instituciones que requieran comprobar la suficiencia en idioma durante los procesos de selección de personal, analizar y certificar el nivel de inglés de sus empleados, hacer un seguimiento de la efectividad de los programas de formación lingüística, evaluar a sus empleados con vistas a ascensos o cargos en el extranjero.​

¿Quieres o te exigen presentar un examen de nivel de inglés, pero no sabes cuál es el adecuado para ti? ¿cuál es la diferencia entre uno y otro de tantos existentes en el mercado? ¿existe algún examen que me diagnostique mi nivel antes de decidir presentar un examen oficial?

La información a continuación puede orientarte un poco y llevarte a tomar la decisión más adecuada para tus necesidades.​

​Una diferencia importante entre todos los exámenes existentes es la validez de los resultados. Dicha validez está sujeta a las políticas y reglamentos de la institución académica, empresa, embajada, etc. solicitante de la prueba. Todas las instituciones son libres de aceptar el o los exámenes que mejor se adecuen a sus reglamentos internos.

Por ejemplo, los exámenes **IELTS y TOEFL** suelen ser más convenientes para los visados, trabajos o solicitudes de admisión universitaria que tengan como requisito de aceptación la posesión de un determinado nivel de inglés.

Exámenes como el **TOEIC, APTIS, TRACK TEST y Oxford Test of English​**son exámenes de inglés cuya novedad es la flexibilidad que aporta al poder evaluar de forma independiente una, dos, tres o todas las competencias del idioma. Estos exámenes son altamente aceptados en las universidades de Colombia.​

Ten en cuenta que cada examen tiene un proceso de inscripción diferente ,el cual varía dependiendo de la casa matriz del mismo.

Los tiempos de entrega también varían dependiendo de las políticas internas del ente oficial del examen. Ten presente el tiempo para tu examen de preferencia.

APTIS

CELPE-BRAS

DELE

IELTS

OTE

PLIDA

TOEFL

TOEIC

TRACK TEST 4 COMPETENCIAS

TRACK TEST COMPRENSIÓN LECTORA

5 días hábiles

4 meses

4 meses

7 días hábiles

15 días hábiles

4 meses

7 días hábiles

15 días hábiles

8 días hábiles

8 días hábiles

| Examen | Valor |
| --- | --- |
| Track Test 4 Competencias presencial | $ 380.000 |
| Track Test 4 Competencias virtual | $ 430.000 |
| Track Test Comprensión Lectora | $ 275.000 |
| Repetición Track Test presencial | $ 185.000 |
| Repetición Track Test virtual | $ 233.000 |
| Aptis for Teachers | $ 412.500 |
| Aptis for Teachers docentes EAFIT | $ 320.000 |
| Aptis General | $ 412.500 |
| Oxford Test of English | $ 486.000 |
| Oxford Test of English una sola habilidad | $ 204.000 |
| TOEFL | $256 dólares |
| IELTS | $ 1.045.700 |
| PLIDA | $ 770.000 |
| CELPE-BRAS | $ 504.000 |

_*Ten en cuenta que estos precios pueden variar en función de tu ubicación y están sujetos a cambios._

**Valores de exámenes de otros idiomas diferentes al inglés a través de nuestra página web.**

​Días antes de presentar la prueba, te llegará un correo electrónico con la citación oficial al examen y las instrucciones que debes seguir para presentarlo.

Para todos, siempre deberás presentar tu documento de identidad ORIGINAL.

Dependiendo si tu examen es a lápiz o a computador deberás traer implementos tales como: lápiz mina # 2, borrador, sacapuntas, lapicero negro.​

**Acceso peatonal:** por la portería de Argos, Las Vegas e Idiomas.​

**Acceso vehicular:** p la portería sur sobre la Avenida las Vegas después de Macrollantas, la del Plástico y del Caucho sobre la Av. Regional y la de Idiomas.

**Acceso de motocicletas:** por la portería sur sobre la Avenida las Vegas después de Macrollantas y la de Idiomas.

Debes tener en cuenta que el pico y placa también rige dentro de la Universidad.

**Valor parqueadero carros** $ 6.000 el día

**Valor parqueadero motos** $ 3.000 el día​

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500