# Guitarra

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 18: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Guitarra - 20 horas

Inscripciones primer semestre de 2026: A partir de las 8:00 a.m. del 26 de enero

*    Guitarra - 20 Horas 

###### Taller dirigido: Estudiantes, graduados​, profesores, empleados y pensionados de la Universidad EAFIT y sus familiares (padres, hijos, hermanos y esposo o compañero permanente). ​​

Si eres estudiante, empleado, profesor o pensionado, al inscribirte en el Taller aceptas la Política de los Talleres Artísticos, por lo tanto ten en cuenta que deberás administrar tus faltas de asistencia. Al momento de incumplir con el 80% de asistencia a tu Taller, el sistema te generará una cuenta de cobro por el costo total del taller, sin descuento ninguno.

​¿Te ha pasado que encuentras en YouTube un curso de guitarra, lo comienzas y ves que tardas mucho en lograr tus objetivos? ¿Te desanimas y lo abandonas? ¿Dejas la guitarra colgada en tu cuarto esperando un mejor momento? El Taller de guitarra acústica te brindará las bases técnicas, teóricas y prácticas para que luego puedas aproximarte por tu cuenta a los cursos que se ofrecen en la red por medio del internet, de las redes sociales o de los canales de video. Con el Taller de Guitarra experimentarás cómo la música armoniza tus emociones, pues es un medio de expresión que te da una alegría que querrás compartir con los otros durante toda la vida.

**Nota:** Este es un Taller único, sin segundas partes, para el que no necesitas conocimiento previo.

Partes de la guitarra, denominación de los dedos de ambas manos. Ejercicios de digitación mano izquierda y mano derecha, y temple y afinación de la guitarra.

Formación de acordes mayores, menores, sostenidos, bemoles, relativas mayores y menores. Acordes con 7ª mayor, 7ª menor, 6ª Mayor, 6ª menor, con novenas, aumentados, disminuidos y suspendidos.

Notación Musical, los signos de la escritura musical, sistema de cifra americana. Aspecto Rítmico, Aspecto Melódico y Aspecto Armónico.

Los círculos armónicos. Escala mayor y escala menor.

Ritmos: Vals, Bolero, Bolero ranchero, Bambuco, Pasillo, Fox, Pasodoble, Balada Rítmica, Balada arpegiada. Montajes de pequeñas obras clásicas.

Aplicación de Canciones, teniendo en cuenta los acordes y los ritmos vistos.

​El Departamento de Desarrollo Artístico dispone de guitarras acústicas para las sesiones del Taller. No tienes que llevar la guitarra a la Universidad​

**Aula: 12-202**

**Horario​:​**

**Grupo: 1**

Fecha inicio: lunes, 9 de febrero de 2026

Fecha fin: lunes, 27 de abril de 2026

Hora: 12:00 m. - 2:00 p. m.

Día: Lunes

Facilitador(a): Julián Usuga

**Grupo: 2**

Fecha inicio: martes, 10 de febrero de 2026

Fecha fin: martes, 21 de abril de 2026

Hora: 2:00 p. m. - 4:00 p. m.

Día: Martes

Facilitador(a): Julián Usuga

**Grupo: 3**

Fecha inicio: miércoles, 11 de febrero de 2026

Fecha fin: miércoles, 22 de abril de 2026

Hora: 10:00 a. m. - 12:00 m.

Día: Miércoles

Facilitador(a): Antonio Solano

**Grupo: 4**

Fecha inicio: miércoles, 11 de febrero de 2026

Fecha fin: miércoles, 22 de abril de 2026

Hora: 12:00 m. - 2:00 p. m.

Día: Miércoles

Facilitador(a): Antonio Solano

Inversión estudiantes de los programas de pregrado y posgrado, profesores y empleados de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

Inversión egresados y graduados de pregrado y posgrado de la Universidad EAFIT: $183.000

Inversión familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado, y de egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT: $183.000

Inversión participantes activos del programa Saberes de Vida: $183.000

Inversión participantes activos de Educación Continua EAFIT o Idiomas EAFIT: $292.800

Costo total del taller a pagar por inasistencia (estudiantes y empleados): $366.000

​​Si eres estudiante de pre y posgrado, profesor y empleado de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

###### Inscripciones a partir de las 8:00 a.m. del 26​ de enero de 2026

Cómo inscribirse en los Talleres Artísticos

### 1

Los talleres artísticos están dirigidos a sus estudiantes, graduados, empleados y pensionados de EAFIT y sus familiares*.

### 2

Elige del menú el taller que quieres cursar y dale clic.

### 3

Lee el contenido del programa, revisa los horarios disponibles y las políticas de los talleres artísticos.

### 4

El día y la hora señalada de inicia de inscripción, será el momento en que se habiliten las opciones de talleres artísticos. Si ingresas antes, no verás opciones de talleres a elegir.

### 5

Una vez ingreses al link de inscripciones, digita tu documento de identidad y sigue la ruta: “Matriculas – Talleres”, y allí buscas el semestre actual.

### 6

Valida que la opción del taller que quieres realizar se encuentre habilitada, la seleccionas y das clic en “Registrarse”.

### 7

Si no encuentras habilitado el taller que quieres cursar, es porque ya se agotaron los cupos.

### 8

Si eres estudiante, empleado o pensionado de EAFIT, debes generar la liquidación para quedar inscrito.

### 9

Si eres graduado o familiar de eafitense, debes generar la liquidación y realizar el pago por los canales establecidos.

*Los familiares corresponden a: padres, hijos, hermanos y esposo o compañero permanente. Tener presente las políticas de los talleres artísticos. Programar muy bien las fechas en que se cursa el taller para hacer un adecuado aprovechamiento de los beneficios que otorga la Universidad. Si al momento de realizar la inscripción no encuentras el taller de tu elección es porque este ya cuenta con cupos disponibles.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate