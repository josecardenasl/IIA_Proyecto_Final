# Literatura - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Pregrado

# Literatura

SNIES 106504, Medellín

La publicación de un libro o de una narrativa en soporte físico, digital o híbrido es el punto culminante de una cadena de valor que requiere de muchos eslabones: los autores trabajan de la mano con editores, promotores, diseñadores y diagramadores, críticos, traductores y libreros, mientras que el reconocimiento literario lo construyen generaciones de lectores que leen, comentan, valorizan y reinterpretan lo que recibieron de la tradición. Espíritus creativos, emprendedores y críticos encontrarán aquí los mejores medios para fortalecer sus cualidades, para informar su pasión y para proyectarse de manera innovadora en un campo literario altamente dinámico.

El profesional en literatura tiene la capacidad de desempeñarse de manera original y competente como creador, crítico y editor en el campo literario y de la cultura. Puede ejercer su capacidad analítica e interpretativa, con sensibilidad humanista, su dominio del lenguaje en la expresión oral y escrita, y sus conocimientos especializados, en múltiples ámbitos profesionales.

*    Escuela Artes Humanidades 
*    Literatura 

## Registro calificado

Resolución 024039 del 12 de diciembre de 2025

Duración

9 Semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 106504

Valor del primer semestre

$15.442.901

Valor promedio de los semestres

$14.413.374

Becas y financiación

## Sobre el programa

Calidad y excelencia

**Somos top en el mundo**

Nuestros profesores están en continua relación con el sector editorial y del libro, proyectos y conversaciones de vanguardia en materia de escritura, edición y circulación de contenidos. También investigan, diseñan y crean.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

MediaLab, un laboratorio de innovación en cultura digital y convergencia; Bitácora, un escenario de contenidos convergentes; Acústica, laboratorio sonoro, un espacio para experimentar con el audio; Celee, un lugar para desarrollar las habilidades y competencias en lectoescritura; [Cámara de Gesell](https://www.eafit.edu.co/escuela-administracion/mercalab/camara-gesell), un espacio altamente especializado para investigaciones, Focus Group y estudios relacionados con el comportamiento humano; Centro multimedial y estudio de producción audiovisual, dos espacios equipados para crear, experimentar y producir contenidos multimediales.

**Tenemos una agenda académica, cultural y social activa**

Hacemos parte de un ecosistema cultural activo: Editorial EAFIT, Centro de artes y exposiciones con alcance regional y nacional, programación viva y activa, Orquesta sinfónica profesional EAFIT y orquesta de estudiantes.

La Escuela ha liderado y ha sido sede de eventos como el Seminario Internacional de Narrativas, el Festival Internacional de Series Web, el Concurso de Debate Crítico, y el Primer Congreso Iberoamericano de Argumentación.

Participamos en eventos como el Salón Iberoamericano del Libro Universitario y el Salón de Nuevas Lecturas de la Fiesta del Libro y la Cultura.

Nos conectamos con nuestro campus y desarrollamos acciones en él: el conocimiento es visible y permea todos los rincones de la Universidad.

**Somos actor clave de una ciudad universitaria.**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe estudiantes de más de 15 países del planeta y de otras ciudades de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Nuestras líneas de énfasis se enfocan en las profesiones del futuro, podrás escoger profundizar en tus capacidades para la edición y la curaduría, la interpretación y la creación de narrativas y contenidos.

Conectamos el pasado, el presente y el futuro con herramientas digitales y metodologías que nos permiten investigar, analizar y crear productos transmediales para explotar el potencial de las humanidades digitales.

Desarrollarás la capacidad para aplicar la literatura en procesos sociales, culturales y tecnológicos, combinando competencias ciudadanas, empatía y trabajo en equipo para resolver problemas de los grupos humanos.

Desarrollamos y resolvemos, en nuestros cursos, retos sociales, ambientales, organizacionales y culturales: estamos conectados con los problemas de nuestra sociedad y procuramos alterativas de solución para estos que se enrutan desde las aulas de clase.

Innovación y liderazgo

**Somos innovación en educación**

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestra escuela edita y publica la Revista Co-herencia, una de las diez mejores revistas en el ámbito de las artes y las humanidades en el país.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de EAFIT y las áreas de conocimiento que las configuran.

Además, su formación se basa en el aprendizaje experiencial, al trabajar con proyectos reales que dan vida a las ideas, integrando teorías, conceptos, metodologías y prácticas.

**Cultivamos el liderazgo temprano y la investigación**

Contamos con más de 30 semilleros de investigación multidisciplinar, grupos y proyectos de investigación, tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Conexiones e incidencias

**Somos un universo empresarial y de emprendimiento activo**

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

**Somos una puerta al mundo**

Estamos en relación continua con el país y con el mundo. Tenemos intercambios y transferencias con más de 147 universidades, contamos con acuerdos, proyectos de investigación y 61 entidades académicas que representan programas de intercambio profesoral e investigativo.

**Representamos excelencia para los empleadores**

El 79,4% de nuestros graduados están laborando en las organizaciones donde hicieron las prácticas. Y el 89% de nuestros graduados están empleados.

Nuestros egresados se desempeñan en sectores tan versátiles y variados como los medios, cine, editoriales, orquestas nacionales e internacionales, organizaciones privadas y públicas.

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Pruebas Saber Pro

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Comunicación Social

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 17691

Valor del primer semestre

$14.825.185

Valor promedio de los semestres

$14.550.644

Becas y Financiación

#### Diseño Interactivo

Duración

9 Semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 109150

Valor del primer semestre

$16.678.333

Valor promedio de los semestres

$14.962.455

Becas y financiación

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate