# Funciones de los decanos

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Funciones de los decanos

*    Funciones de Los Decanos 

Velar porque en la Escuela se cumplan los Estatutos y los Reglamentos de la Universidad.

Actuar como gestor y promotor del desarrollo integral de la Escuela en los campos académico, cultural y administrativo.

Fomentar y preservar en la Escuela condiciones de excelencia para el trabajo universitario y para el desarrollo de la vida académica.

Velar para que el personal docente y administrativo realice sus funciones con puntualidad, eficiencia y sujeción a las disposiciones vigentes, y propiciar el liderazgo académico de los profesores. Esta función se ejerce con el concurso de los Jefes de

Departamento Académico, Jefes de Área y Coordinadores de Programa.

Convocar y presidir las sesiones del Consejo de la Escuela.

Actuar como ordenador de gastos de la Escuela dentro de los límites establecidos por los Estatutos y los Reglamentos de la Universidad o por la delegación que le haga el Rector.

Preparar el proyecto de presupuesto, con la asesoría de la Sección de Presupuesto de la Universidad y con la participación de los Jefes de Departamento Académico, Coordinadores de Programa y Jefes de Área, y presentarlo a la Vicerrectoría Administrativa.

Proponer al Vicerrector Académico los candidatos para jefaturas de Departamento Académico y para coordinaciones de programas de pregrado y de posgrado.

Designar, en acuerdo con los Jefes de Departamento, a los Coordinadores de áreas académicas.

Ejercer la función disciplinaria en la Escuela, con potestad para investigar en todos los casos y para imponer las sanciones que no estén reservadas a otra autoridad.

Reunir a los Jefes de Carrera, Jefes de Departamento y a los profesores de la Escuela, por lo menos una vez cada año, para informarles sobre la marcha de ésta, y de los planes y​ programas que adelanten la dependencia y la Universidad y escuchar sugerencias.

Convocar y reunir, por lo menos una vez cada semestre, al estudiantado de la Escuela para informarlo sobre la marcha de ésta y de los planes y programas que adelanten la dependencia y la Universidad, y escuchar sugerencias. Estas reuniones se pueden hacer por programas y Departamentos Académicos.

Propiciar la interrelación con otras dependencias de la Universidad para el mejor cumplimiento de las funciones de ésta.

Fomentar la interacción académica de la Escuela con instituciones públicas y privadas, nacionales y extranjeras.

Resolver oportunamente, en el ámbito de su competencia, las peticiones estudiantiles y profesorales.

Presentar a las autoridades universitarias nombres de las personas que a juicio del Consejo de la Escuela sean merecedoras de distinción.

Presentar a la Rectoría cada año un informe escrito sobre la marcha de la Escuela.

Procurar la integración de los egresados a la vida de la Escuela.

Desarrollar las políticas y procedimientos de contratación de profesores, previstas en el Estatuto Profesoral vigente.

Las demás que le señalen los Estatutos y los Reglamentos de la Universidad.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

## Utilizamos cookies en este sitio web para mejorar su experiencia de usuario.

Al hacer click en Aceptar, otorga su consentimiento para que establezcamos cookies. [Conoce la política de datos personales](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Aceptar No, gracias