# Definiciones - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Definiciones

*    Definiciones 

​​​​Perspectiva de Género

Plantea la necesidad de solucionar los desequilibrios que existen entre mujeres y hombres, mediante la adopción de acciones, políticas o lineamientos para garantizar el acceso a bienes, servicios, derechos e incluso a la justicia.

​​​​Derecho de las Mujeres

Las mujeres tienen derecho al goce y a la protección d​e todos los derechos humanos, a vivir en escenarios donde no existan posiciones de poder basadas en el género, a una vida libre de violencia, a no ser discriminadas, a no estar sujetas a estereotipos de inferioridad y subordinación entre los sexos, a participar en igualdad de condiciones que el hombre en las esferas políticas, económica, social, cultural o cualquier otra.

Violencia Psicológica

Es aquella que se ocasiona con acciones u omisiones dirigidas intencionalmente a producir en una persona sentimientos de desvalorización e inferioridad sobre sí misma, que amenazan la madurez psicológica de una persona y su capacidad de autogestión y desarrollo personal.

Violencia Sexual

Es todo acto o comportamiento de tipo sexual ejercido sobre una persona a través de la fuerza, la coacción física, psicológica o económica, o cualquier otro mecanismo que anule o limite la voluntad personal aprovechando las situaciones y condiciones de desigualdad, y las relaciones de poder existentes entre la víctima y el agresor. ​

Violencia Económica

Pueden configurarse como tal el abuso económico, el chantaje patrimonial, los castigos monetarios, la prohibición de trabajar, la pérdida o sustracción de elementos, la venta unilateral de bienes de la pareja o destinados a satisfacer las necesidades de la mujer, el daño sobre los elementos de trabajo de la mujer, la inasistencia alimentaria, el daño o sustracción de documentos personales, entre otros. ​

Violencia Laboral

Es la discriminación hacia la mujer en los centros de trabajo públicos o privados que obstaculicen su acceso al empleo, ascenso o estabilidad en el mismo, tales como exigir requisitos sobre el estado civil, maternidad, la edad, la apariencia física o buena presencia, o la solicitud de resultados de exámenes de laboratorios clínicos, que supeditan la contratación, ascenso o la permanencia de la mujer en el empleo. Constituye también discriminación de género en el ámbito laboral quebrantar el derecho de igual salario por igual trabajo. Así mismo incluye el hostigamiento psicológico en forma sistemática sobre una determinada trabajadora con el fin de lograr su exclusión laboral.

Violencia Institucional

Son las acciones u omisiones que realizan las autoridades, funcionarios y funcionarias, profesionales, personal y agentes pertenecientes a cualquier órgano, ente o institución pública, que tengan como fin retardar, obstaculizar o impedir que las mujeres tengan acceso a las políticas públicas y ejerzan los derechos previstos en las leyes para asegurarles una vida libre de violencia. ​

Violencia Obstétrica

Se entiende por violencia obstétrica la apropiación del cuerpo y procesos reproductivos de las mujeres por personal de salud, que se expresa en un trato deshumanizador, en un abuso de medicalización y patologización de los procesos naturales, trayendo consigo pérdida de autonomía y capacidad de decidir libremente sobre sus cuerpos y sexualidad, impactando negativamente en la calidad de vida de las mujeres.

​​​​Discriminación basada en género

Es toda acción u omisión de una persona o grupo de personas que busca excluir, rechazar o generar un trato desigual en relación con otras personas por su pertenencia a determinado sexo, raza, religión, orientación sexual entre otras.

Definiciones tomadas de la página de [Tejiendo Justicia, del Ministerio de Justicia y del Derecho.](https://www.minjusticia.gov.co/Paginas/PageNotFoundError.aspx?requestUrl=https://www.minjusticia.gov.co/Tejiendo_Justicia/Genero_Conceptos_Claves)

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate