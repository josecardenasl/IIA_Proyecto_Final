# Talento Humano

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Talento Humano

*    Talento Humano 

Propósito

**Creamos oportunidades** para nuestro talento, **conectándolos**con experiencias significativas y enriquecedoras que favorezcan el descubrimiento y desarrollo de su potencial. Así mismo, **promovemos el aprendizaje y el bienestar integral**para conectar a las personas con su sentido de propósito y de transformación y de esta manera **contribuir a la sociedad**.

Acerca del departamento

El Departamento de Talento Humano, adscrito a la Dirección de Desarrollo Humano y Bienestar, acompaña y asesora a los líderes para garantizar la adecuada gestión en la incorporación de personas, su integración en la cultura institucional, el desarrollo de habilidades y la garantía del proceso administrativo de vinculación.

Servicios para empleados

###### **¿Qué te ofrecemos como empleado de EAFIT?​**

Los siguientes son algunos de los beneficios que hacen parte de la comunidad eafitense:

Oportunidad de desarrollo integral, extensivo a su familia.

El campus universitario como un centro de las artes y la academia, por medio de la programación de actividades y manifetaciones artísticas y culturales.

Instalaciones deportivas, Librería, Tienda EAFIT, Centro de Acondicionamiento Vivo, locales comerciales y de servicio; y

Centro Cultural Biblioteca Luís Echavarría Villegas.

Amplia oferta de opciones de asegurabilidad

Consulta médica general sin costo

Becas de educación formal en pregrado y posgrado para empleados administrativos y profesores de planta.

Becas de educación no formal en cursos de Idiomas EAFIT y Educación Continua para empleados administrativos (planta, temporales y aprendices) y profesores (planta, cátedra pregrado e idiomas).

Beneficios económicos extralegales, para empleados de planta.

Directorio de servicios de salud con tarifas preferenciales.

Trabaja con nosotros

**En la Universidad EAFIT propendemos por el desarrollo integral de nuestros colaboradores buscando su incorporación a la cultura y a los valores institucionales de excelencia, audacia, responsabilidad, integridad y tolerancia como ejes claves de nuestro éxito.**

Si tienes interés en ser parte del equipo humano de nuestra Institución te invitamos a ingresar a [Magneto365](https://www.magneto365.com/EAFIT), donde encontrarás las indicaciones para registrar tu hoja de vida, consultar y aplicar permanentemente las ofertas laborales.

Puedes gestionar tu hoja de vida a través de la siguiente segmentación de perfiles:​

**Docente de pregrado y posgrado:**

Grupo de profesores que realizan labores académicas en los campos de la docencia, la investigación y la proyección social en la Universidad.

**Docente de idiomas:**

Grupo de profesores que realizan labores de enseñanza de idiomas en los diferentes programas que ofrece la institución a través de la Dirección de Idiomas.

**Empleado dministrativo:**

Cargos de dirección y administrativos que tiene responsabilidades sobre estrategias y procesos que apoyan la gestión académica de la institución.

Constancias laborales y/o contratos de aprendizaje

Las constancias laborales y/o contrato de aprendizaje son documentos en los que se certifica el vínculo laboral y de aprendizaje de los empleados y aprendices que tengan o hayan tenido contrato(s) laboral(es) o de aprendizaje con la Universidad.

Su solicitud se hace a través de un formulario y teniendo presentes las políticas de este proceso.

## Contacto

Bloque 29, Piso 4

(57) 604​ 2619500 Ext. 8725

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate