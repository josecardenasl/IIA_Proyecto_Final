# Laboratorios de Ciencias Biológicas​​​​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Laboratorios de Ciencias Biológicas​​​​

*    Laboratorios de Ciencias Biológicas​​​​ 

#### **Servicios​​**

Los laboratorios ofrecen instalaciones y equipos que permiten llevar a cabo múltiples servicios que facilitan el desarrollo de procesos moleculares, microbiológicos y químicos, para apoyar los programas de Biología, Geología, Ingeniería de Procesos, Agronómica y Física.

El Laboratorio de Biología se divide en 4 áreas específicas del conocimiento: biología molecular, biología animal y vegetal, biotecnología vegetal y fenómenos químicos.

El Laboratorio apoya la programación académica de los programas de Ingeniería de Procesos, Ingeniería Física, Ingeniería Agronómica y Biología.

## Colección biológica

Repositorio de más de 2300 especímenes que han sido catalogados y sistematizados para su uso en proyectos de investigación a nivel nacional.​​

###### **Más información**

Las colecciones biológicas son un conjunto de especímenes de la diversidad biológica que se encuentran preservados bajo estrictos protocolos de curaduría especializada para contribuir al progreso de la Nación mediante la descripción y la caracterización de la diversidad, de tal forma que genere nuevos conocimientos fundamentales sobre principios biológicos y ecológicos.

La Colección Biológica Universidad EAFIT, siendo una de las colecciones más recientes en Colombia, tiene como objetivo ser una colección de referencia que permita ser testigo de la diversidad biótica de aquellas regiones de las cuales provenga el material depositado. Actualmente es el repositorio de especímenes de docencia e investigación que han sido catalogados y sistematizados en 1.367 ejemplares de mamíferos, 641 anfibios y 376 reptiles, correspondientes a 51 familias, 175 géneros y 361 especies, de 8 departamentos y 34 municipios de Colombia.

**En particular, gran parte de la información custodiada pertenece a un banco de aproximadamente 3.000 tejidos, los cuales han sido fuente de proyectos de investigación que pretenden identificar a nivel molecular las especies de vertebrados de Colombia.**

Adicionalmente, la Colección Biológica Universidad EAFIT alberga microorganismos como bacterias, arqueas, hongos y algas, pero por efectos de simplicidad, los distintos grupos bióticos en la colección se clasifican como microorganismos, vertebrados, invertebrados y plantas.

#### **Recursos​**

## Termocicladores​​

## qPCR

## Sintetizador de Oligos

## TapeStation

## Iseq 100

## Spiral plate

## Estereoscopio electrónico

## Cabinas de Bioseguridad Tipo II y III

## Incubadora de CO2

## Cámara anaeróbica

## Contacto

​​Paola Irene Rivera Patiño, coordinadora.

**Correo:**[pirivera​p@ea​fit.edu.co​](mailto:pirivera%E2%80%8Bp@ea%E2%80%8Bfit.edu.co%E2%80%8B)

**Teléfono:** (57) (604) 2619647

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate