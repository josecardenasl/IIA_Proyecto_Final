# Beca cursos y diplomados - Grupos Artísticos Representativos

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Beca cursos y diplomados - Grupos Artísticos Representativos

*    Beca, Cursos y Diplomados - Grupos Artísticos Representativos 

###### Procedimiento para acceder a las becas de silla vacía

Desarrollo Artístico-Educación Continua

Ahora por ser parte de los Grupos Artísticos Representativos de la Universidad EAFIT podrás acceder a cursos y diplomados de manera gratuita, gracias a la alianza del Departamento de Desarrollo Artístico con Educación Continua EAFIT, para que puedas acceder a ellos bajo la modalidad de Silla Vacía.

###### **Requisitos:**

Ser participante activo de los Grupos Artísticos Representativos.

Llevar mínimo dos semestres ininterrumpidos en el Grupo.

Que el horario del curso o diplomado no interfiera con tu participación en los ensayos del Grupo.

###### Cómo postularte a la beca de silla vacía:

Deberás estar pendiente de toda la parrilla de programación de cursos y diplomados de Educación Continua en [www.eafit.edu.co/cec](https://www.eafit.edu.co/cec)

Cuando encuentres un curso o diplomado que quieras realizar, deberás enviar un correo a [dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co)dando la siguiente información:

Nombre completo

Cédula

Grupo al cual perteneces

Curso o diplomado que quieres realizar

Fecha de inicio del curso o diplomado

Desarrollo Artístico validará el cumplimiento de los requisitos y procederá a enviar la solicitud a Educación Continua.

Si el programa que escogiste se abre y tiene sillas vacías disponibles, recibirás un correo de confirmación y obtención de la beca por parte de Educación Continua.

El curso o diplomado que quieras realizar debe inciar al menos 15 días después de realizar la solicitud. ​

Si el programa no llega a punto de equilibrio o no se abre, se te notificará.

###### Bienestar EAFIT piensa en tu formación integral​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)