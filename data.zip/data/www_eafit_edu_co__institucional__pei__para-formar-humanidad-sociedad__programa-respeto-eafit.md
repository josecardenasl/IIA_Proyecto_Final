# Programa #RespetoEnEAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Programa #RespetoEnEAFIT​

*    Programa #RespetoEnEAFIT 

​​Generar un ambiente de respeto en el campus significa convivir con otras personas que viven realidades diversas, y en esa medida, respetar lo que son, lo que hacen, sienten, piensan y quieren, sin hacerles sentir que sus diferencias son un problema. Es, en definitiva, comprender y aceptar con respeto la diferencia del otro, en su orientación sexual, pensamiento político o en sus condiciones socioeconómicas.

Y este mensaje se transmitió cuando la Universidad, comprometida con sus valores de integridad y tolerancia, presentó a la comunidad eafitense el proyecto #RespetoEnEAFIT, iniciativa que lidera el Centro de Integridad, con el respaldo de varias dependencias, y que contempla promover una conversación profunda sobre los temas de equidad de género y sexualidad diversa.

Los actores institucionales no solo fueron testigos de los mensajes que hicieron parte de la fase comunicacional del proyecto y de los espacios de conversación, sino que también tienen a su disposición un Protocolo para la Equidad de Género y la Sexualidad Diversa, que busca prevenir y definir la actuación frente a posibles situaciones de discriminación, y un canal oficial de contacto en caso de que se presenten hechos de discriminación y acoso.​​

## El Protocolo para la Equidad de Género y la Sexualidad Diversa se puede ​consultar ​aqu​í​.

## Salud y bienestar

## 5. Igualdad de género

##### #Respe​toEn​EAFIT​​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate