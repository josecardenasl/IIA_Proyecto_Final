# Derecho - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 19: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

![Image 38: Pregrado en Derecho, Universidad EAFIT.
Estudiantes de Derecho interactúan con un docente en la Sala de Audiencias y la Biblioteca de la Universidad.](https://universidadeafit.widen.net/content/tnfd0mnnar/web/pregrado-derecho-13.jpg?crop=yes&k=c&w=1920&h=788&itok=FtXh5T6r)

Pregrado

# Derecho

SNIES 7227, Medellín

En el pregrado de Derecho te convertirás en alguien capaz de ir más allá de un texto o una norma y, en cambio, lograrás establecer conexiones entre un problema específico y áreas de conocimiento como economía, historia, administración, ciencia política, filosofía y sociología, y también con las nuevas tecnologías. Es decir, serás un abogado integral. Esa capacidad para conectar tu pensamiento con temas más amplios te permitirá aplicar tu conocimiento jurídico en cualquier entorno.

También adquirirás la capacidad de anticiparte a situaciones: descubrirás que desde el derecho se pueden prevenir problemas y crear soluciones de toda índole. Y es que con un plan de estudios con 12 créditos flexibles que te permiten tomar clases de distintas áreas e intereses, 15 créditos de formación institucional que puedes elegir libremente y una planta docente dispuesta a escuchar tus ideas sobre nuevos semilleros, investigaciones y proyectos de grado, tu perfil profesional se configurará de una manera integral.

*    Escuela Derecho 
*    Derecho 

## Renovación de la Acreditación en Alta Calidad y renovación del registro calificado

Resolución de oficio 014360 del 23 de agosto 2023​​​. ​Vigencia de 8 años.

## Modificación

Resolución 023944 del 12 ​de diciembre de 2023.

Duración

10 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 7227

Valor del primer semestre

$14.825.185

Valor promedio de los semestres

$14.886.956

Becas y financiación

## Sobre el programa

Calidad y excelencia

**Somos top en Colombia**

Nuestra Escuela es la mejor en Derecho de Antioquia, de acuerdo con las pruebas Saber Pro. Como pregrado, estamos en el top 5 de las mejores universidades del país según la misma fuente.

El pregrado recibió la reacreditación en Alta Calidad, esta vez por 8 años, un sello de confianza que les permite a nuestros estudiantes tener acceso a becas, incentivos y créditos condonables. También les da prelación en convocatorias gubernamentales.

**Nos respalda la experiencia y la tradición:**

Contamos con 25 años de trayectoria en la formación de abogados integrales que trabajan en campos tan diversos como mercantil, bursátil, digital o penal.

Campus transformador

**Nos respalda un ecosistema de aprendizaje y práctica:**

Contamos con un Consultorio Jurídico con asesoría gratuita para personas naturales en situación de vulnerabilidad de los estratos 1, 2 y 3.

Nuestra sala de audiencias dentro del campus es escenario de importantes discusiones; entre 2006 y 2023 tuvimos 1.215 audiencias de conciliación.

El Ágora, un oasis dentro de la Universidad, es el espacio indicado para la reflexión y las conversaciones.

Nuestra Biblioteca aloja casi 20.000 documentos especializados entre libros, enciclopedias, manuales, vídeos, revistas y proyectos de grado de diversas áreas del Derecho.

**Tenemos una agenda cultural y académica activa**

Lo mejor de la academia, las discusiones y análisis de coyuntura, la ciencia y la cultura convergen en EAFIT.

**Tenemos proyección y presencia nacional**

Nuestra Universidad cuenta con sedes en Bogotá y Pereira. Ha operado y acompañado proyectos de diversa índole en el territorio nacional.

**Somos actor clave de una ciudad universitaria.**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de Ciudades Universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de Ciudades del Aprendizaje. Cada año, EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

En este programa, cada persona tiene la libertad para configurar 24 créditos según sus intereses, incluyendo contenidos de las cinco escuelas de la Universidad y de sus áreas de conocimiento.

Se aprende desde la experiencia con retos y con la exposición a problemas y procesos reales.

Innovación y liderazgo

**Somos innovación en educación**

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes están continuamente expuestos a conversaciones y procesos con casos reales y con los graduados. También reciben una formación multidisciplinaria gracias a las cinco escuelas de EAFIT y las áreas de conocimiento que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

Contamos con 40 grupos de investigación y más de 100 semilleros para el aprendizaje y crecimiento de los estudiantes.

En EAFIT tenemos 14 grupos estudiantiles, con más de 1.500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo:**

Contamos con centro de estudios e incidencia, Valor Público, y con un espacio de innovación y desarrollo social: EAFIT Social.

Nuestros profesores están conectados con las organizaciones, la investigación y las mejores universidades del mundo. También están al tanto de los problemas que afectan a nuestra sociedad. Tenemos conexión permanente con las empresas y los territorios.

En nuestra escuela, nos proyectamos a la sociedad a través de la revista académica Nuevo Foro Penal, de la colección [Justicia y Conflicto](https://libreriasiglo.com/editoriales/siglo-editorial/colecciones/justicia-y-conflicto), de la publicación de obras académicas con la Editorial EAFIT y de la función social realizada por el [Consultorio Jurídico](https://www.eafit.edu.co/consultorio-juridico) y su [centro de conciliación](https://www.eafit.edu.co/centro-de-conciliacion).

Contamos con el Centro de estudio e incidencia Valor público, donde nos preocupamos por entender los problemas presentes y futuros en materia de política pública, seguridad, impacto social, entre otros.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que realizan intercambios al exterior, y programas de intercambio profesoral e investigativo.

Ofrecemos la posibilidad de realizar prácticas profesionales dentro y fuera de Colombia.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrado han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores start-ups de Colombia.

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Ciencias Políticas

Duración

9 Semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1​​​​​9032

Valor del primer semestre

$15.442.901

Valor promedio de los semestres

$14.138.834

Becas y financiación

#### Negocios Internacionales

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Inglés

Más información

Más del 80 % de los cursos se imparten en inglés, con asignaturas complementarias en español y un tercer idioma certificado por los estudiantes.

Modalidad

Presencial

SNIES

SNIES 1244

Valor del primer semestre

$15.442.913

Valor promedio de los semestres

$15.236.996

Becas y Financiación

## **Nuestros graduados**

## Marcela Giraldo

"Un egresado del pregrado en Derecho de EAFIT es una persona dispuesta a trabajar por su sociedad con determinación, con pujanza y con la mente abierta al mundo".

## Juliana Arbeláez

"La Universidad me brindó conocimiento de calidad, método, disciplina y relaciones. EAFIT es una puerta al mundo, es compromiso".

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate