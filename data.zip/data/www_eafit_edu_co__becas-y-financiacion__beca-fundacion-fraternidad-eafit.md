# Beca Fundación Fraternidad - EAFIT - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Beca Fundación Fraternidad - EAFIT

El Fondo Beca cubrirá el**100%** de la matrícula en instituciones de **carácter público.**

*    Beca Fundación Fraternidad - EAFIT 

## Beca Fundación Fraternidad - EAFIT

¿Cuándo se abre la convocatoria?

Para mayor información consultar en [Becas Fondo Fraternidad | Fundación Fraternidad Medellín](https://www.comfama.com/aprendizaje/oferta-becas/fondo-fraternidad/ "https://www.comfama.com/aprendizaje/oferta-becas/fondo-fraternidad/")

¿Quiénes pueden aplicar?

Estudiantes que cumplan con las condiciones establecidas por la Fundación Fraternidad y EAFIT, que sean egresados de las instituciones educativas públicas o de cobertura de los municipios con presencia de la Fundación.

**Oriente:**San Carlos, San Rafael, Granada, San Vicente, El Peñol, San Luis, Rionegro, Marinilla, El Santuario, El Carmen de Viboral, El Retiro y La Ceja.

**Suroeste:** Titiribí, Venecia, Tarso, Jericó, Támesis, Ciudad Bolívar, Fredonia, Jardín y Andes.

**Urabá:**Carepa, Vigía del Fuerte, San Juan de Urabá, Necoclí.

​¿Qué cubre la beca-crédito?

El Fondo Beca cubrirá el 100% de la matrícula en instituciones de carácter público.

En las instituciones educativas de carácter privado, el Fondo aportará un porcentaje sobre el valor de la matrícula, de conformidad con la alianza previamente firmada entre las partes. En caso de que el beneficiario deba aportar algún porcentaje sobre el valor de la matricula, podrá validar el aporte en la página de la fundación fraternidad Medellín y también será informado con anticipación.

Previo análisis de vulnerabilidad y presupuesto de gastos del beneficiario, el Fondo de Becas podrá asignar hasta 4SMLMV semestrales por concepto de manutención.

El beneficiario deberá aportar lo faltante para su manutención; así como, el pago otros procesos académicos y administrativo.

La manutención no se configura como un mínimo vital para los becarios, está destinada solo al apoyo de gastos académicos durante su formación​​​​.

​El aspirante deberá revisar el reglamento del fondo de becas y determinar si puede acogerse a lo que allí se establece como requisitos de permanencia. ​

​Requisitos para aplicar

Ser colombiano.

​Tener entre 15 y 40 años. En caso de ser normalista, no aplica límite de edad.

Tener documento de iden​tidad vigente.

Contar con clasificación del SISBEN, perteneciente al grupo hasta máximo C18. En caso de los padres o tutores sean podrían aplicar.

Ser residente, por un período no inferior a tres años, de los municipios con presencia de la Fundación Fraternidad. Excepto para quienes en el momento de la postulación ya se encuentran estudiando en una Institución de Educación y que por esta razón ya vivan fuera de su municipio.

Ser bachiller egresado de las Instituciones Educativas Públicas, de los municipios con presencia de la Fundación.

Contar con el certificado examen Saber 11 (Icfes) donde se detallen tus datos personales completos y se visualice que obtuviste un puntaje.

Estar admitidos o en proceso de admisión en un programa académico elegible para el Fondo, que cuente con registro del Ministerio de Educación Nacional o de la respectiva Secretaría de Educación Municipal.

Optar por uno de los programas en las Instituciones de Educación superior y/o institución para el trabajo y el desarrollo humano en alianza con la Fundación Fraternidad, [ver aquí](https://fraternidadmedellin.org/).

No contar con estudios previos en educación técnica profesional, tecnológica y universitaria, excepto si desea continuar con estudios relacionados con el área de conocimiento del programa académico ya cursado y culminado, siempre que le permita avanzar en su nivel de formación así: de técnico a tecnólogo, de tecnólogo a profesional.

No contar con apoyo de otra entidad para la financiación de su estudio; excepto si es beneficiario del programa Jóvenes en Acción del Departamento prosperidad Social – DPS.

En caso de encontrarse estudiando al momento de la inscripción, debe tener un promedio acumulado superior a 3.5, y no haber superado el 50% del total de los créditos necesarios para alcanzar el título académico.

Certificado de matrícula o constancia de inscripción o admisión para los aspirantes a primer semestre.

En caso de estar ya estudiando, las notas de los semestres cursados (Historial académico).

Información adicional

Para mayor información: Puedes escribir al correo [becasfraternidad@comfama.com](mailto:becasfraternidad@comfama.com) o contactarnos al 315 270 2908.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate