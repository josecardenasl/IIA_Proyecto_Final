# Declaraciones Institucionales - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Ejes misionales y atributos

*    Pei 2022 
*    Declaraciones Institucionales 

### Educación flexible y relevante

**Gráfica 1. Características del modelo educativo. Proyecto Educativo Institucional, 2022.**

El aprendizaje es el primer eje misional que motivó el nacimiento de nuestra Universidad, hace más de seis décadas, con el propósito de formar a personas, ciudadanos y profesionales capaces de comprender el entorno social, económico, político y cultural en el que viven y de plantear soluciones que aportaran al desarrollo empresarial de la región. Nuestra Institución también fue incorporando, en su transitar, el quehacer y las dinámicas propias de la investigación y la proyección social. La pregunta por el humanismo debe ubicarse en el corazón y la mente de una persona para así poder pensar en cómo cultivar, es decir, cómo desarrollar en ella capacidades para comprender y transformar su vida en armonía consigo misma, con los otros y con el mundo. Así, nuestro proyecto humanista es esencial y situado, ético y político, con vocación de reflexión y de acción, que cultiva el pensamiento crítico, la creatividad, la comunicación y la colaboración como condiciones ciudadanas que permiten poner en común saberes y sentimientos, teorías y vivencias. Esto con el fin de nutrir el conocimiento de cuestiones humanas tanto desde los procesos de decisiones personales como desde las lógicas de acción colectiva que arrojen respuestas a las demandas humanas y sociales.

Las siguientes son las principales características de nuestro Modelo Educativo:

## Educación flexible y relevante

El estudiante en el centro

Reconocemos a los estudiantes como protagonistas del proceso de aprendizaje. Esto significa que están llamados a asumir un rol activo en su experiencia universitaria. En esa medida, los estimulamos a interactuar con el conocimiento; a darle un sentido a lo que aprenden; a interpretar conceptos y procedimientos; a construir, de forma sistémica, gradual y metódica, conocimientos significativos que les permitan transformar el entramado de relaciones en el que ejerzan su profesión, y a actuar de forma autónoma, de tal manera que sean capaces de continuar aprendiendo por sí mismos a lo largo de la vida 1. Además, en EAFIT contamos con grupos estudiantiles, semilleros de investigación y otros mecanismos de representación y agrupación que fortalecen el liderazgo temprano y refuerzan capacidades organizativas e investigativas.

Formamos seres humanos y profesionales que, además de adquirir competencias en diversas áreas del conocimiento, construyen su identidad como personas y ciudadanos; y encuentran posibilidades y capacidades para inspirar y movilizar a otros.

Experiencia integral y transformadora de vida

En EAFIT les ofrecemos a los estudiantes un abanico de oportunidades para el ejercicio pleno de sus capacidades personales y profesionales. Vivir la Universidad significa que nuestros estudiantes son capaces de tomar decisiones íntegras, conectar el desarrollo de su ser con el saber, el hacer, el saber-hacer y la convivencia en sociedad. También los hace conscientes de su papel activo en el aprendizaje; les permite desarrollar las capacidades necesarias para relacionarse de manera responsable e incluyente consigo mismos, con los otros y con la naturaleza; comprometerse con la promoción de mejores condiciones de vida para sí mismos y sus semejantes, al igual que potenciar sus capacidades para la inventiva y la creación de soluciones a los distintos problemas profesionales y sociales.

Profesores que inspiran

Nuestros profesores son los agentes del cambio esenciales para desplegar y consolidar los procesos misionales. Son actores decisivos en el aprendizaje porque les permiten a los estudiantes no solo dominar un saber, sino afrontar las dificultades y los retos que implica la vida adulta. Por lo tanto, esperamos que nuestros profesores inspiren pasión por el conocimiento; impacten los procesos que dirigen hacia la toma de decisiones; y tengan la posibilidad de crear conexiones con las empresas, los sistemas públicos y los emprendimientos para generar reflexiones y soluciones que transformen la sociedad a través del conocimiento práctico y aplicado.

Para ello, ponemos a su disposición estrategias y recursos pedagógicos que les faciliten orientar sus acciones hacia el cumplimiento de los propósitos del aprendizaje y fortalecer la responsabilidad y el compromiso de los estudiantes respecto a su formación académica.

Currículo vivo

El diseño de nuestros planes académicos se orienta al aprendizaje por trayectorias, al dinamismo, la flexibilidad y la adaptabilidad por cuanto favorece no solo la lectura, interpretación y comprensión de los fenómenos sociales y profesionales, sino que, además, potencia la construcción de soluciones que permitan encarar la incertidumbre, responder a los retos que implica la vida en sociedad y establecer una relación potente con los contextos, territorios y organizaciones.

De este modo, el aprendizaje en nuestra Universidad provee habilidades para la vida y el ejercicio profesional mediante el desarrollo de competencias, el aprendizaje activo y experiencial, la convergencia de saberes, la flexibilidad, la innovación, y el uso adecuado de tecnologías que median las diferentes modalidades de aprendizaje, todo esto en conexión con las necesidades de las organizaciones. A su vez, la formación humanista y científica, que es la base de todos nuestros programas académicos, propende por el desarrollo de cuatro competencias esenciales: empatía2, pensamiento crítico3, pensamiento anticipatorio4 y pensamiento sistémico5.

El diseño curricular basado en competencias propicia la creación de distintas trayectorias formativas que se adaptan a las necesidades y los ritmos, tanto de nuestros estudiantes como de los empleadores y demás grupos de interés con los que interactuamos. Dicho diseño hace posible, entre otras cosas, que nuestros estudiantes puedan cursar dos programas académicos en EAFIT ya que se pueden homologar resultados de aprendizaje y asignaturas comunes. Favorece también la doble titulación en asocio con otras universidades del país y del exterior. Por último, permite que los estudiantes diseñen configuraciones personalizadas mediante el ofrecimiento de trayectorias, materias electivas, complementarias y líneas de énfasis.

Despertar las vocaciones científicas, el pensamiento crítico, la indagación y formulación de hipótesis son algunos de los aspectos que se desarrollan, a lo largo del Modelo Educativo, basados en la estrategia de transformación curricular y los conceptos rectores que le dan vida: las competencias y los resultados de aprendizaje.

El campus como laboratorio

Los espacios físicos y virtuales, así como todos los demás recursos disponibles, se adaptan y conectan entre sí para potenciar y enriquecer la experiencia integral de aprendizaje. De este modo, los retos y los proyectos integradores tienen un papel preponderante en nuestros espacios, lo que los convierte en un valioso recurso pedagógico. En EAFIT tenemos más que salones o aulas. Contamos con un laboratorio vivo, un ecosistema en el que se aprende con la vivencia y se proponen soluciones replicables en materia pedagógica, tecnológica, científica, ambiental, artística y social. Un campus conectado con la naturaleza, un escenario de interacciones mediadas por el cuidado; que se proyecta más allá de sus límites y que encuentra en la ciudad y en otros territorios y entornos oportunidades de aprendizaje e interacción con otros.

Con la implementación del modelo educativo impactamos en aspectos fundamentales de la infraestructura física y tecnológica que están pensados para integrar un ecosistema de aprendizaje activo y experiencial que promueva un espíritu innovador, creativo, reflexivo, de trabajo colaborativo y autónomo. El aprendizaje sucede en nuestra cotidianidad y cuenta con escenarios, herramientas y decisiones que permiten hacer visibles los saberes que nos habitan y que, de manera clara, aportan a la apropiación social del conocimiento.

El uso de las herramientas tecnológicas cumple un papel transformador en nuestros procesos de enseñanza y aprendizaje. Hemos adecuado las aulas para que los profesores puedan implementar estrategias pedagógicas innovadoras en sus cursos y, así mismo, los estudiantes desarrollen mejores prácticas de estudio que potencien las competencias necesarias para encarar las demandas del siglo XXI.

### Generación y transferencia de conocimiento consciente y responsable

La ciencia, la tecnología y la innovación es nuestro segundo eje misional. Desde su fundación, nuestra Universidad declaró la investigación como una de las actividades de su quehacer, generando de forma progresiva avances importantes y expandiendo el conocimiento científico a diferentes campos disciplinares para lograr mayor impacto en la sociedad. La expansión y la articulación de estas capacidades han posibilitado el desarrollo del Sistema de Ciencia, Tecnología e Innovación institucional, potenciando la generación, transmisión y apropiación del conocimiento y saberes, a través de la creación y el fortalecimiento de la investigación; el desarrollo tecnológico e innovación; la apropiación social del conocimiento y la formación científica, con las cuales se dinamiza el ecosistema de conocimiento alineado con los ecosistemas de organizaciones, sistemas públicos y emprendimientos.

Los siguientes son los atributos en los que se sustenta el Sistema de Ciencia, Tecnología e Innovación en EAFIT:

## Generación y transferencia de conocimiento consciente y responsable

Democratización y sostenibilidad del conocimiento

La comunidad de saberes y conocimientos representa el entramado de relaciones expresadas en alianzas, aprendizaje experiencial, trabajo colaborativo y cooperación internacional, nacional, regional y local que nos permiten conectar el saber y el conocimiento generado, con los problemas concretos de la sociedad, integrando buenas prácticas, saberes y recursos de forma diversa, expansiva y estratégica. Esta interacción permite que la investigación, el desarrollo tecnológico, la innovación y sus resultados estén conectados con los retos locales y globales, potenciando las capacidades del Sistema de Ciencia, Tecnología e Innovación y brindando soluciones novedosas que generan valor y desarrollo sostenible a la sociedad.

Focos estratégicos para conectar la ciencia, la tecnología y la innovación con los retos de la sociedad

El sistema de conexiones de EAFIT lo dinamizamos mediante la convergencia de capacidades instaladas de nuestra Institución en diversas áreas de conocimiento con las necesidades del entorno. La definición de focos estratégicos brinda oportunidades adicionales para que los procesos de ciencia, tecnología e innovación tengan una mayor incidencia en sus campos, ya sea en educación, aplicaciones tecnológicas, creativas y de diseño, o en el desarrollo de nuevas políticas públicas o capacidades institucionales.

Nuestros focos estratégicos permiten orientar y priorizar el Sistema de Ciencia, Tecnología e Innovación de la Institución para generar conocimientos y saberes que respondan a los principales retos de la sociedad, a través de procesos de investigación, transferencia e innovación. Con dicha priorización definimos las apuestas institucionales, la asignación de recursos financieros, la vinculación de profesores y expertos, y la orientación de procesos de formación de alto nivel de maestría y doctorado.

El desarrollo de estos tópicos contribuye a la expansión de la frontera y la vanguardia del conocimiento y a la conexión con temas neurálgicos de la realidad actual. Esto nos exige aprovechar al máximo las capacidades y alinearlas con los propósitos y necesidades del entorno, al igual que favorece la consolidación de unidades que articulan de manera interdependiente las disciplinas, las metodologías, los talentos y las creaciones de la ciencia, la tecnología y la innovación para transformar el mundo y responder a sus desafíos.

Con la creación de los centros de estudio e incidencia materializamos estas conexiones y brindamos espacio al saber aplicado que conversa con la realidad, promueve el diálogo y la creación con actores sociales, académicos, emprendedores y con las organizaciones. Este espacio alienta a la comunidad académica a pensar en las contribuciones de la investigación en términos de su impacto en la práctica y cómo sus conocimientos, percepciones, métodos y rigor pueden aportar a los problemas, a los retos, a las oportunidades actuales y a generar nuevo conocimiento que impacte la frontera de la ciencia.

Investigación y conocimiento que permean las experiencias de aprendizaje

El aprendizaje activo, colaborativo y experiencial nos exige el desarrollo de competencias que se consolidan progresivamente en diferentes espacios y momentos de la vida, para favorecer el pensamiento crítico, la actitud científica y una experiencia de aprendizaje transformadora. Con este propósito, dinamizamos y articulamos los procesos, las metodologías y los resultados de la investigación que desarrolla nuestra comunidad académica, en los diversos entornos de aprendizaje con elementos propios de la pedagogía y didáctica de las ciencias y el campus como un gran laboratorio en el que se aprende desde la vivencia.

La investigación formativa, teórica y aplicada, es la oportunidad para que los estudiantes se acerquen al reconocimiento de un saber particular de una manera estructurada y rigurosa que, además de ayudarles a potenciar el asombro y la curiosidad, les permita perfeccionar las competencias para explicar, comprender y transformar el entorno.

Así mismo, cultivamos vocaciones científicas y promovemos una investigación apasionada que se convierte en proyecto de vida, al lograr que las actividades de aprendizaje y apropiación social del conocimiento, sean atravesadas por las propias motivaciones e inquietudes de los estudiantes, y aporten en la búsqueda de soluciones propositivas, creativas, dinámicas e innovadoras con relación a los desafíos actuales.

Ciencia, tecnología e innovación aliadas del emprendimiento

El emprendimiento de impacto acelera la conversión de conocimientos científicos e invenciones en tecnologías, productos y servicios prácticos que impactan la sociedad. La investigación impulsada por el impacto se convierte en uno de los mecanismos para materializar procesos de innovación, en los que el emprendimiento es un aliado para la investigación, trayendo nuevos desafíos y posibilitando a su vez la generación de nuevas tecnologías.

Así mismo, generamos valor agregado al impactar a las organizaciones públicas y privadas quienes serán adoptantes de las tecnologías que logran llegar al mercado como resultado de la incubación de estas iniciativas empresariales. En estas dinámicas de interacción participan los diferentes actores de la comunidad universitaria: estudiantes, investigadores, profesores, empleados y graduados.

Con este tipo de emprendimiento con potencial de adaptación, producción y comercialización proporcionamos una puerta de entrada para que los estudiantes accedan a capacidades únicas en la creación de tecnologías, productos y servicios de alto impacto, tras conectar el saber y el conocimiento que se genera con los problemas concretos de la sociedad y sean posteriormente agentes transformadores con la creación de tejido empresarial.

Diálogo constructivo como pilar del desarrollo

A través de la Apropiación Social del Conocimiento (ASC) propendemos por la interacción, el diálogo y el vínculo recíproco entre sociedad y academia dado que el conocimiento científico y tecnológico está inevitablemente asociado al cambio político, económico, cultural y condiciona la vida de las sociedades y sus individuos, constituyéndose en un asunto público. Así, todo grupo social que se precie de ser democrático debe garantizar que la ciudadanía incida y participe en las dinámicas de gestión, cocreación, producción, uso y aplicación del conocimiento, a través de estrategias sociales, de política pública y de producción, de la ciencia abierta y la ciencia ciudadana, entre otras, que hacen relevante el quehacer científico con la sociedad.

Con la comunicación pública hacemos de la ciencia, la tecnología y la innovación un bien accesible a los públicos para promover sus potenciales como agentes transformadores. El ejercicio de circulación consciente y ajustado a las características particulares de los entornos implica la selección de canales pertinentes, la utilización de formatos y lenguajes afines a estos, la adecuada preservación y disponibilidad del conocimiento para impulsar la solución de problemas y la toma de decisiones, a la vez que se crea, usa, transfiere y apropia el conocimiento.

### Construcción de tejido social y productivo

En EAFIT entendemos la posibilidad de construir y fortalecer el tejido social y productivo a partir de programas, acciones o proyectos encaminados a articular grupos de personas y/o empresas que trabajen por satisfacer las necesidades de la sociedad para lograr su bienestar, desarrollo y progreso en los ámbitos social, económico y ambiental. Dicha construcción es posible gracias a las acciones colectivas e iniciativas que se gestan desde la confianza, la solidaridad y la equidad entre personas, organizaciones y redes. Esto se concreta mediante la promoción del saber aplicado para la solución de problemas en tres entornos principales: empresas consolidadas, los sistemas públicos y el emprendimiento.

Los siguientes son las características de la proyección social en EAFIT:

## Construcción de tejido social y productivo

Consciencia social y ambiental

En EAFIT creemos que el conocimiento cobra valor y sentido en la medida que impacta realidades concretas. Por ello fomentamos la innovación y el emprendimiento; la audacia con la que ponemos a disposición los conocimientos que aportan a la construcción de tejido social y productivo; la coherencia ambiental con la que protegemos “nuestra casa común”, la responsabilidad que tenemos de entregarles a las generaciones futuras un planeta mejor que el que recibimos; y la transparencia con la que cuidamos los recursos y aseguramos la sostenibilidad institucional para poder seguir cumpliendo nuestro propósito y misión.

Capacidad relacional

Generamos alianzas y redes de confianza y empatía con personas y organizaciones de diversos sectores que construyen sociedad. Aportamos nuestro conocimiento para la solución de problemas a través de la formación, la ciencia, la tecnología y la innovación.

La relación directa con nuestros graduados y diferentes actores en las organizaciones, y la comprensión de las dinámicas de los sectores en los cuales se mueven hacen posible que dichas conexiones estén basadas en las capacidades de comprender los retos actuales y futuros, y poder ser un aliado en las relaciones de crecimiento para el país a través de nuestro foco en ecosistemas como las organizaciones consolidadas, los sistemas públicos y los emprendimientos de impacto.

Fortalecer lazos perdurables y pertinentes con diferentes sectores nos permite no solo crecer como Universidad, sino contribuir al desarrollo sostenible desde los ámbitos local, regional, nacional y global. Estos vínculos de confianza, por ejemplo, han propiciado una conexión y un trabajo articulado con algunas empresas que incluso hoy están en nuestro campus universitario. Transparencia, seriedad y posibilismo son algunos rasgos que aportan de manera decidida a la capacidad relacional de nuestra Universidad, y que, a su vez, generan reputación y confianza.

Ecosistema colaborativo, ágil y transformador

Somos un ecosistema colaborativo, ágil y transformador en permanente renovación que conecta propósitos con conocimiento. Estas características dan cuenta de la eficiencia, la transparencia y la efectividad de nuestra Universidad al momento de transferir el conocimiento que genera y lo ponen a disposición del sector productivo y del desarrollo tecnológico del país. EAFIT no es una entidad aislada, sino que formamos parte de un ecosistema de conocimiento aún más grande.

A la luz del concepto de ecosistema, desde la biología, EAFIT es también un conjunto de personas que trabajan día tras día por un objetivo en común. Como Universidad hacemos parte del ecosistema de conocimiento local, regional, nacional e internacional, pero también somos un ecosistema en sí mismo porque en nuestro interior generamos una serie de atributos propios que nos permiten interrelacionarnos con otros agentes.

Participación activa en la alianza universidad-empresa-estado-sociedad

Hacemos parte de una cuádruple hélice que tiene en el centro a la sociedad civil a la que nos debemos y que es la beneficiaria del conocimiento. Participamos decidida y activamente de esta alianza integrada por todos los actores de la sociedad para generar desarrollo sostenible. Para que la alianza sea inteligente, es necesario que se realimente constantemente y se apoye en una agenda abierta de encuentros de los que surgen múltiples convenios que generan desarrollo, confianza, equidad y calidad de vida.

Fomento al emprendimiento

Nuestro conocimiento en EAFIT trasciende para transformar sociedad. Uno de los caminos con los que buscamos impactar es el fomento al emprendimiento para proponer alternativas de solución que contribuyan a la dinamización del tejido empresarial.

Tenemos el objetivo de generar una nueva masa crítica emprendedora a través de la formación y de un sistema de información que nos permita encontrar oportunidades y conocer las necesidades de nuestros estudiantes, graduados, colaboradores y emprendedores del país; y así conectar con cadenas de valor para escalar, acelerar y crear sinergias de financiación y promover una plataforma de conocimiento e innovación.

Con el fomento al emprendimiento también damos respuesta a los retos que afronta la sociedad vinculando las personas y las capacidades de la organización con las oportunidades regionales, nacionales y globales, logrando una presencia activa de emprendimientos de impacto, inicialmente en el país, pero posteriormente proyectándonos a escenarios regionales. De esta manera fortalecemos y creamos nuevas alianzas que aportan a la sostenibilidad y la capacidad relacional de nuestra Universidad.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)