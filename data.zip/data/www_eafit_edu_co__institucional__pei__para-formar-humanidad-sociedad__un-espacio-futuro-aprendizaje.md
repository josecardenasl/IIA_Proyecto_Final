# ​​Un espacio de aprendizaje para los futuros investigadores

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# ​​Un espacio de aprendizaje para los futuros investigadores

*    ​​Un Espacio de Aprendizaje Para Los Futuros Investigadores 

En sus mentes rondan muchas ideas. Facilitar la vida a ciertos grupos sociales, innovar en áreas en las que aún hay mucho por descubrir, entender el mundo interconectado en el que viven. Los semilleros de investigación cumplen quince años formando comunidades de aprendizaje y siendo escenarios en los que se generan las condiciones para que nazca en los jóvenes una actitud científica mediante el aprendizaje activo y el desarrollo de habilidades que los conecten con el sentido social.

El semillero de investigación en Sistemas Embebidos (Sise) con el proyecto Invernadero IoT, que aplica la tecnología de sistemas embebidos e internet de las cosas, busca facilitar el trabajo del agricultor a partir de la generación de información en tiempo real para tomar decisiones acertadas con el fin de optimizar el cultivo, mitigar los impactos exógenos que puedan afectar las plantas, controlar su producción de manera precisa y, por tanto, obtener mayores beneficios económicos.

Es solo un caso, pero los esfuerzos de investigación por parte de estudiantes de pregrado y posgrado adscritos a los semilleros han permitido importantes avances en ciencia, tecnología y humanidad.

Entre 2013 y 2019, se ejecutaron 440 proyectos y se pasó de 71 semilleros a 133. A un estudiante consciente de lo que es la investigación y que ha participado en espacios de práctica se le abren caminos para continuar sus estudios de posgrado y para profundizar en temas de interés. Varios egresados, cuyos primeros acercamientos a la investigación se dieron en la Universidad de los Niños o en los semilleros, trabajan hoy en centros de investigación de alto nivel.

## En cuanto al número de estudiantes, el programa reporta una tasa de crecimiento anual del 12 % en el período 2013-2019. Cierra el 2019 con un balance de 1.825 integrantes activos.

> Uno ingresa en un semillero de investigación por el aprendizaje, porque tiene todo el interés de generar nuevos conocimientos. Nos nutrimos de profesionales muy tesos que tienen mucha experiencia, no solo sobre el tema sino sobre metodologías de investigación. Esto motiva bastante. Nos confrontamos con diferentes puntos de vista porque a veces uno se encuentra con que una interpretación no concuerda con otra y aprendemos a debatir, a argumentar y a construir conocimiento”Mateo Orrego López, integrante del semillero de investigación en Análisis del Lenguaje

## 4. Eduación de calidad

## 8. Trabajo decente y crecimiento económico

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)