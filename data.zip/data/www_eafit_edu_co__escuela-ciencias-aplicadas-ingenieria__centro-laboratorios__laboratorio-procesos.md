# ​Laboratorios de Procesos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​Laboratorios de Procesos

*    ​Laboratorios de Procesos 

#### **Servicios​​**

El Laboratorio apoya la programación académica de los programas de Ingeniería de Procesos, Ingeniería Mecánica y Biología. En las áreas de transporte, almacenamiento y extracción de sólidos, líquidos y gases, destilación, intercambio de calor, agitación, mezclado, tamizado, química instrumental y bioprocesos.

Se destaca en el Laboratorio de Operaciones Unitarias, el sistema de extracción completo tipo piloto, para diferentes matrices, el cual incluye trituración y extracción del material hasta la obtención del producto final que puede ser tipo aceite, utilizando el extractor de fluidos Supercríticos o en forma pulverizada con el secador por atomización.

#### **Recursos​**

## Cromatógrafo Liquido (HPLC)

## Cromatógrafo de Gases

## Extractor de Fluidos Supercríticos

## Espectrofotómetro Infrarrojo

## Secador por Atomización

## Bioreactores

## Reactor Químico

## Extracción sólido-líquido

## Extracción Liquido-Liquido

## Torre de Destilación

## Caldera

## Contacto

Edgar Darío Arbeláez Henao, coordinador.

**Correo:**[earbelae@eafit.edu.co​](mailto:earbelae@eafit.edu.co%E2%80%8B)

**Teléfono:** (57) (604) 2619325​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)