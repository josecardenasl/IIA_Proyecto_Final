# Amigurumis - 20 horas

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Amigurumis - 20 horas

Inscripciones primer semestre de 2026: A partir de las 8:00 a.m. del 26 de enero

*    Amigurumis - 20 Horas 

###### Taller dirigido: Estudiantes, graduados​, profesores, empleados y pensionados de la Universidad EAFIT y sus familiares (padres, hijos, hermanos y esposo o compañero permanente). ​​

Si eres estudiante, empleado, profesor o pensionado, al inscribirte en el Taller aceptas la Política de los Talleres Artísticos, por lo tanto ten en cuenta que deberás administrar tus faltas de asistencia. Al momento de incumplir con el 80% de asistencia a tu Taller, el sistema te generará una cuenta de cobro por el costo total del taller, sin descuento ninguno.

Amigurumi (編み包み lit. peluche tejido) Es una tendencia japonesa que consiste en tejer pequeños muñecos mediante técnicas de croché o ganchillo. Los amigurumis toman forma principalmente en animales como ositos, conejos, gatos o perros, pero también adquieren otras formas como comidas, plantas, e incluso accesorios como bolsos, bisutería, etc.

El tejido es una fuente de gran satisfacción, pues además de activar el hemisferio derecho, encargado de fortalecer la concentración, ejercita las manos y la motricidad fina. ​

​De dónde nace el término amigurumi,

Clases de amigurumis y las diferentes formas y utilidades que se les puede dar.

Cómo aumentar y cómo disminuir.

Cómo entender los diagramas o patrones.

Práctica y resolución de dudas.

Inicio del anillo mágico.

Cómo hacer una bola.

Cómo unir las partes (termina el primer amigurumi).

Realización de un proyecto.

​Aguja de crochet gruesa de 3.0mm

Hilo preferiblemente que NO sea negro ni blanco

Ojos de seguridad para amigurumis o 2 Botones negros redondos

Agujas para fieltro o Needle Felting

Algodón siliconado para rellenar

Aguja de hueco grande o lanera

Ganchos marcadores para crochet o ganchitos de ropa

Tijeras.

**Aula: 12-202**

**Horario​:​**

Grupo: 1

Fecha inicio: jueves, 12 de febrero de 2026

Fecha fin: jueves, 23 de abril de 2026

Hora: 12:00 m. - 2:00 p. m.

Día: Jueves

Facilitador(a): Paula Vélez

Inversión estudiantes de los programas de pregrado y posgrado, profesores y empleados de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

Inversión egresados y graduados de pregrado y posgrado de la Universidad EAFIT: $152.500

Inversión familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado, y de egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT: $152.500

Inversión participantes activos del programa Saberes de Vida: $152.500

Inversión participantes activos de Educación Continua EAFIT o Idiomas EAFIT: $244.000

Costo total del taller a pagar por inasistencia (estudiantes y empleados): $305.000

​​Si eres estudiante de pre y posgrado, profesor y empleado de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

###### Inscripciones a partir de las 8:00 a.m. del 26​ de enero de 2026

Cómo inscribirse en los Talleres Artísticos

### 1

Los talleres artísticos están dirigidos a sus estudiantes, graduados, empleados y pensionados de EAFIT y sus familiares*.

### 2

Elige del menú el taller que quieres cursar y dale clic.

### 3

Lee el contenido del programa, revisa los horarios disponibles y las políticas de los talleres artísticos.

### 4

El día y la hora señalada de inicia de inscripción, será el momento en que se habiliten las opciones de talleres artísticos. Si ingresas antes, no verás opciones de talleres a elegir.

### 5

Una vez ingreses al link de inscripciones, digita tu documento de identidad y sigue la ruta: “Matriculas – Talleres”, y allí buscas el semestre actual.

### 6

Valida que la opción del taller que quieres realizar se encuentre habilitada, la seleccionas y das clic en “Registrarse”.

### 7

Si no encuentras habilitado el taller que quieres cursar, es porque ya se agotaron los cupos.

### 8

Si eres estudiante, empleado o pensionado de EAFIT, debes generar la liquidación para quedar inscrito.

### 9

Si eres graduado o familiar de eafitense, debes generar la liquidación y realizar el pago por los canales establecidos.

*Los familiares corresponden a: padres, hijos, hermanos y esposo o compañero permanente. Tener presente las políticas de los talleres artísticos. Programar muy bien las fechas en que se cursa el taller para hacer un adecuado aprovechamiento de los beneficios que otorga la Universidad. Si al momento de realizar la inscripción no encuentras el taller de tu elección es porque este ya cuenta con cupos disponibles.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate