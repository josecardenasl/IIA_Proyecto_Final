Hacer un recorrido por algunas de las experiencias que proyectan a EAFIT como una universidad que inspira vidas e irradia conocimiento para forjar humanidad y sociedad es una oportunidad para materializar un Propósito Superior que, más que solo la letra plasmada en un documento, es una declaración que cobra vida.

Seres humanos que contribuyen a la transformación del mundo y que a lo largo de la vida quieren aprender. A propósito de los 60 años que la Universidad conmemora en 2020, reafirmamos y renovamos el compromiso de responder al momento histórico en el que nos encontramos caminando juntos por las rutas consignadas en el Itinerario EAFIT 2030 que implican nuevos desafíos.

Las iniciativas aquí consignadas también exaltan el descubrimiento y la creación, el compromiso con la sostenibilidad, la importancia de ser ciudadanos íntegros, la necesidad de aportar los talentos para dar nuevas miradas y soluciones desde la innovación y el emprendimiento, y el fortalecimiento de la identidad y de la idea de vivir una existencia con consciencia global, por solo mencionar algunos de los objetivos.

Escuchar al otro, trabajar juntos en pro de soluciones. EAFIT sabe de la importancia de las alianzas, de abrir sus puertas (hoy físicas y virtuales) para generar una conexión inteligente, con cada persona dando lo mejor de sí, con cada sector aportando. Muchas de las apuestas que se desarrollarán a continuación se afianzan en la conexión Universidad-Empresa-Estado-Sociedad que contribuye a dar pasos más certeros para hacer realidad los objetivos y afrontar las nuevas realidades.

Esperanza. Una palabra con una fuerza que se requiere hoy. Forjar humanidad y sociedad, un propósito que se vuelve tangible cada vez que un niño se formula una pregunta, un estudiante lidera acciones y propone diálogos, o un investigador entrega a su entorno un producto que resuelve una necesidad con audacia. Así, todos los integrantes de la comunidad eafitense, desde diferentes actividades y acciones tanbién siguen inspirando, creando, transformando.

### 1. Experiencias para todas las generaciones

## La curiosidad, el origen del descubrir

Como los más de 3.800 niños que han pasado por sus encuentros, expediciones y talleres, la Universidad de los Niños tiene la capacidad de hacerse preguntas, de abrir los sentidos, de abordar la ciencia desde miradas sorprendentes, curiosas, inspiradoras.​

## Más de 100 programas que contribuyen al desarrollo sostenible de la humanidad

A través de 24 pregrados, 43 especializaciones, 42 maestrías y 6 doctorados, que ofrecen sus seis escuelas en diferentes sedes, EAFIT plantea un camino en el que la capacidad de adaptarse, reinventarse y leer las necesidades sociales es fundamental en estos momentos de transformación. Desde la administración, la ingeniería, las humanidades, el derecho, la economía y las finanzas, y las ciencias, EAFIT ofrece programas con los que busca contribuir al desarrollo sostenible de la humanidad.​

## El deleite por el saber

En 2001, cuando Saberes de Vida comenzó, 14 personas aceptaron la invitación a habitar el campus de EAFIT y a dar rienda suelta a su pasión por el conocimiento, sin importar la edad. Saberes de Vida es un espacio diseñado para que los adultos mayores continúen con el deleite del saber y el desarrollo intelectual.

## Oportunidades de educación continua

Desde su Itin​erario 2030, la Universidad EAFIT se concibe como un campus abierto para aprender a lo largo de la vida, como se puede evidenciar con ideas tan inspiradoras como la Universidad de los Niños y Saberes de Vida. Co​nscientes de que ​el conocimiento y el mundo se encuentran en constante evolución, la Institución acompaña cada etapa del ser humano desde Educación Continua, otra de las unidades de la Dirección de Educación Permanente, con un portafolio que alcanza los 500 cursos.

## Por una alta dirección más cualificada y humana

Sus programas no solo impactan en los líderes que orientan las empresas. Es toda la organización la que se beneficia de directivos actualizados en habilidades estratégicas, que adquieren herramientas prácticas, que aprenden del equilibrio entre conocimiento y valores, para orientar equipos más preparados y humanos. Alta Dirección acompaña a esos directivos, pero también aporta desde la investigación y la producción académica con estudios que iluminan asuntos de interés actual.

## Enseñar español a los ciudadanos globales

“Realmente me gustó la atmósfera en el campus, es muy moderno, joven e inspirador. Los cursos se organizan de manera exigente y ​productiva, en salones equipados con lo último en tecnología. El personal docente, los profesores y los administrativos fueron muy amables, serviciales y profesionales. Lo más importante: ¡Progresé mucho en mis habilidades en español!”, expresó Andreas Fischer, de Suiza. Un testimonio que demuestra que la Universidad para todas las generaciones, también lo es para todas las nacionalidades.

## Integridad, el valor supremo que orienta nuestro proyecto educativo

Ya lo decía recientemente Jamil Salmi, experto internacional en educación superior: el propósito de una universidad no es solo formar profesionales de alta calidad académica e innovadores, el foco se encuentra hoy más que nunca en la preparación de buenos ciudadanos, tolerantes, solidarios, éticos, honestos.

## Kratos, una experiencia de aprendizaje activo

Trabajo en equipo, resolución de problemas, innovación, creatividad y comunicación son palabras que se asocian con el progr​ama Kratos, que nació en septiembre de 2017 y en el q​ue estudiantes y profesores de EAFIT, con aliados estratégicos como Postobón y TCC, buscan impactar la educación y sus entornos a través de nuevas metodología​s que impulsan un aprendizaje basado en retos que organizan empresas y universidades en distintos puntos del planeta.

## Diálogos académicos que construyen sociedad

Analizar los hechos desde diferentes visiones y disciplinas. EAFIT cuenta con una rica agenda permanente de actividades académicas que en 2019 alcanzó los cerca de 430 encuentros, una cifra que da cuenta de una institución que abre sus puertas al conocimiento, a actualizarse, a los intercambios y a las alianzas para acceder a expertos de talla mundial.

### 2. Una Universidad más incluyente Y equitativa

## Programa #RespetoEnEAFIT

Generar un ambiente de respeto en el campus significa convivir con otras personas que viven realidades diversas, y en esa medida, respetar lo que son, lo que hacen, sienten, piensan y quieren, sin hacerles sentir que sus diferencias son un problema. Es, en definitiva, comprender y acept​ar con respeto la diferencia del otro, en su orientación sexual, pensamiento político o en sus condiciones socioeconómicas.​

## Becas que transforman vidas

La Universidad EAFIT, consciente de su responsabilidad social y compromiso con la educación de los jóvenes de escasos recursos económicos y excelencia académica, ha configurado un progra​ma de becas propias y bajo acuerdo con aliados estratégicos (empresas, fundaciones y personas naturales) para facilitar el acceso de estudiantes con excelentes condiciones académicas para que puedan realizar sus estudios en la Institución.

## Filantropía para irradiar esperanza

El sector educativo, por su mismo papel como agente transformador, es uno de los terrenos abonados para s​embrar y fomentar la filantropía. Por eso, en febrero de 2019, la Universidad presentó de manera oficial a la comunidad el Centro de Filantropía de EAFIT, que forja humanidad y sociedad conectando agentes, personas, instituciones, fundaciones y empresas que quieran aportar a la sociedad a través de la educación.

## Opciones financieras para motivar la permanencia

Que los estudiantes permanezcan, que puedan disfrutar de cada momento en la Universidad. Que sus dificultades financieras se alivie​n y den continuidad a sus clases con la tranquilidad de que cuentan con los recursos para pagar su semestre.​

## Esa labor que apoya a las personas en situación de discapacidad

Reconocernos en la diversidad y propiciar espacios y herramientas para que la comunidad participe en igualdad de condicio​nes, es un objetivo prioritario en el Consultorio Jurídico y Centro de Conciliación. Más allá de abordar la discapacidad desde la protección y la ley, que es vital, se trata también de reconocer al otro y de eliminar las barreras que les impiden desarrollarse y ser parte de la sociedad.​

## Encuentros permanentes por la igualdad de género

La igualdad de género es un asunto vital en la agenda de EAFIT que siempre busca poner en el escenario temas que necesitan priorizarse en las conversaciones nacionales. Por ello, ponentes de la Universidad y otros analistas son convocados, de forma constante, por la Institución y sus aliados. ​

## El compromiso de ser voluntario

En diciembre de 2019, la Alcaldía de Medellín entregó a la Universidad el reconocimiento Acciones que cuentan. Soy Voluntario, en la categoría mejor voluntariado universitario, por su labor con diferentes colectivos de la ciudad y la comunidad.

#### 4. Investigaciones e innovaciones que transforman

## Creación de nuevo conocimiento en conexión con las necesidades del entorno

Para construir sociedad y unir saberes. Investigar para transformar, leer el entorno y brindar soluciones. Para establecer alianzas. Forjar humanidad y sociedad​ desde la investigación hace parte del ADN de la Universidad. Los proyectos que surgen de los 44 grupos de investigación abarcan las agendas de conocimiento que se basan en las tendencias internacionales y nacionales: industrias 4.0 y tecnologías converg​entes-nano, bio, info y cogno; agrotech: transformación, mercado y producción; ciudades inteligentes; ambiente, biodiversidad y recursos naturales; estado, construcción pacífica, convivencia y posacuerdos; creación, cultura y arte; energías sostenibles; ciencias del comportamiento y cambio social​.

## Un espacio de aprendizaje para los futuros investigadores

En sus mentes rondan muchas ideas. Facilitar la vida a ciertos grupos sociales, innovar en áreas en las que aún hay mucho por descubrir, entender el mundo interconectado en el que viven. Los semilleros de investigación cumplen quince años formando comunidades de aprendizaje y siendo escenarios en los que se generan las condiciones para que nazca en los jóvenes una actitud científica mediante el aprendizaje activo y el desarrollo de habilidades que los conecten con el sentido social.

## EAFIT y Metro: unidos por la investigación y el bienestar de los antioqueños

Gestión del conocimiento. Unión de investigación con las necesidades de organizaciones que son esenciales para el funcionamiento de la sociedad. Con el Metro de Medellín se desarrollan planes que son ejemplos de alianzas que suman.

## Un epicentro en Medellín de la supercomputación

Aliado de la investigación y la innovación, Centro de Supercomputación Apolo​ tiene la facultad de ser un supercomputador de alto rendimiento, logrando que varias máquinas trabajen en paralelo resolviendo el problema científico que se presente en cualquier campo.​

## Monitorear para salvar vidas, una misión de EAFIT a través del Siata

De la unión de EAFIT y el Área Metropolitana del Valle de Aburrá (AMVA) se desprenden investigación y desarrollo de instrumentos que favorecen desde el conocimiento científico y el desarrollo tecnológico y la innovación, hasta los mecanismos oportunos para identificar y pronosticar la ocurrencia de fenómenos naturales y antrópicos que alteren las condiciones ambientales de la región. ​

## Innovaciones al servicio de problemas reales

Obtener una nueva patente es un símbolo de que los investigadores eafitenses dan un paso más hacia soluciones que el mundo necesita. El trabajo es arduo, requiere de tiempo, de pruebas, desarrollos y de conexiones con otras entidades. ​

## De la idea a su materialización: transferencia de tecnología

Inmotion Group se ha dedicado a crear soluciones que impacten en el medioambiente y contribuyan a la movilidad sostenible. En 2014, se concibió oficialmente como una organización, entre otros asuntos, dedicada a la construcción y comercialización de bicicletas eléctricas, aportando una solución innovadora ante los problemas de movilidad y de contaminación del aire por el consumo de energías fósiles.​

## Tras una visión integral de los territorios

Desarrollar un Sistema de Alerta Temprana (SAT) de bajo costo y adaptado al contexto local, de tal manera que esté cultural y espacialmente adaptado a las complejas condiciones de territorios densamente urbanizados, es el objetivo del proyecto Inform@risk: hacia un territorio más seguro, desde el que se adelantan estudios geológicos, evaluación del riesgo y diseño de una red de sensores para anticipar los movimientos de tierra.​

## Estudios que dan respuesta a los desafíos de las ciudades del siglo XXI

Tres estudios que tienen impacto en el proceso de urbanización de las ciudades y abordan los fenómenos de crecimiento urbano en los países en vía de desarrollo, agudizados por la crisis sanitaria del covid-19, son adelantados por investigadores de la red Peak Urban, como un aporte académico para la gestión de la contingencia ambiental y epidemiológica.

## Participación activa en la construcción de políticas públicas

La Universidad no está conforme con el statu quo. Por eso, como una manera de aportar a la ciudad, la región y el país también participa activamente en la formulación, el desarrollo, la actualización, la socialización y la evaluación de políticas públicas que generan soluciones y nuevas posibilidades, de la mano del Centro de Análisis Político (CAP); del Centro de Investigación Económicas y Financieras (Cief), y de algunas acciones del Centro de Estudios Urbanos y Ambientales (Urbam). El primero de estos irradia su conocimiento al entorno en temas relacionados como la equidad de género, la seguridad, la convivencia y paz; el segundo desde el aporte del conocimiento y la producción científica para la toma de decisiones; y el tercero con insumos que permitan apoyar los procesos urbanos y territoriales con enfoque sostenible.​

## Un efecto cacao que potencia la productividad

Su enfoque es productivo, pero lo social también es fundamental. El proyecto de desarrollo rural Efecto Cacao se abre paso en el agro colombiano, permitiendo a los pequeños agricultores cacaoteros capacitarse y proyectarse en el mercado internacional del grano, al potenciar ​la productividad de sus fincas y cultivos.​

### 6. Impulso al liderazgo juvenil

## Universidad-Colegio-Empresa, otra tríada que aporta a la calidad de la educación

Hace unos años se reportaba un caso de éxito en el que la alianza entre EAFIT, Nutresa y el colegio Montessori, para aportar a la calidad de las instituciones educativas no solo había mejorado indicadores académicos en el primer plantel, sino que potenció las capacidades de alumnos y docentes.​

## Jóvenes que siembran ​​​esperanza por todo el país

La Red de Liderazgo Juvenil ha inspirado, creado y transformado la cultura de liderazgo en las instituciones y el entorno social y familiar de los jóvenes, y ha dinamizado sus propios proyectos de vida, sembrando esperanza, mostrando que sí hay un futuro posible, transformando, finalmente, la sociedad. ​

## Ser felices aprendiendo después de las clases

Estudiantes que se conectan con sus gustos e intereses, que exploran el conocimiento a través de experiencias de vida transformadoras. En 2019, EAFIT fue una de las aliadas de Inspiración Comfama, un programa que acompaña procesos formativos, culturales, recreativos y artísticos en la jornada escolar complementaria.​

## Líderes del presente y del futuro

Hay iniciativas que se quedan en el alma, que permanecen, porque reflejan esos sueños de forjar humanidad y sociedad. Una de ellas fue Jóvenes 20/20, que, en 2019, formó líderes para el presente y el futuro, agentes de cambio para una ciudad educadora.​

## La representación universitaria

La Universidad EAFIT se ha caracterizado por propiciar espacios de participación estudiantil y profesoral, donde sus voces son escuchadas y tienen peso en el momento de tomar decisiones acerca del devenir institucional. ​

## La experiencia EAFIT, mejor en colectivo

No solo se unen por convicción, por sueños comunes, lo hacen para vivir juntos la experiencia EAFIT; también para establecer una relación con su entorno, con un espíritu de integridad, excelencia, pluralismo e inclusión.

### 7. Iniciativas de paz y reconciliación

## BioAnorí: descubrimientos científicos y humanos

Catorce nuevas especies de animales y plantas desconocidos para el mundo, reportadas para la ciencia fue el balance numérico que dejó la Expedición Colombia BioAnorí, realizada gracias a la Alianza EPM-PNUD, Colciencias y las universidades EAFIT, Antioquia y CES. Sin embargo, los buenos resultados de esta experiencia van más allá de las cifras. Los científicos contaron con el acompañamiento de 10 excombatientes de las Farc, quienes aparte de ser guías brindaron apoyo logístico y de análisis del material recolectado.​

## Llano Grande, un territorio que respira cambios

Un ejemplo de reconciliación, de desarrollo comunitario y de construcción de paz, se registra en la vereda Llano Grande, de Dabeiba (Antioquia), donde EAFIT, con su capital científico para la conservación de la biodiversidad, se sumó a los esfuerzos de Postobón, Grupo Sura, Grupo Nutresa, Bancolombia, Grupo Argos, Corbeta y la Fundación Fraternidad Medellín, quienes aportaron 270 hectáreas para la reincorporación de excombatientes de las Farc. ​

## Compartir vivencias y proyectos como un ejercicio reparador

El ciclo de conferencias Reincorporación que transforma vidas, promovido por EAFIT, la Agencia para la Reincorporación y la Normalización (ARN), la Misión de Verificación de la ONU en Colombia, Proantioquia y la Alianza para el Desarrollo Sostenible e Incluyente PNUD-EPM, fue, sin dudas, un aporte a la esperanza, una validación de que juntos podemos construir sociedad. ​

## Un manifiesto por la verdad desde la voz de los niños

Los niños tienen mucho que decir y más cuando se trata de sus derechos y del respeto por la vida. Aprender a no juzgar por las apariencias, decir la verdad a las familias de todos los desaparecidos, tenerlos en cuenta en espacios de construcción de memoria, tomar acciones para la reparación de las víctimas y destinar expertos que respondan las preguntas de aquellos que han sido afectados por el conflicto armado en Colombia, son algunas de las recomendaciones que niños y adolescentes presentaron en el Manifiesto por la Verdad.​

### 9. Eafit, epicentro físico y digital de la cultura

## Una programación cultural activa y que acompaña siempre

La dimensión cultural permanece palpitante en EAFIT. En ella se reconocen las diferentes formas de ver y experimentar el mundo, de recrearlo y de inspirar. Sea como punto de encuentro físico o digital, está presente para eafitenses y comunidad en general a través de la preservación de la memoria, de la promoción de nuevos talentos y de la agenda con las diferentes actividades artísticas.​

## Un hogar para los libros y también para el arte

Centro Cultural Biblioteca Luis Echavarría Villegas es un lugar estratégico para la investigación, el encuentro, el diálogo, el arte, la lectura y la escritura, abierto a la ciudad. No es un entorno común, allí se fomenta el trabajo colaborativo, pero también los momentos para adquirir conocimiento, en las diferentes plataformas, de manera individual. ​

## Dos premios para exaltar la literatura

Son momentos importantes en el año, que los amantes de la palabra esperan con ansias. Autores y sus obras se exaltan en estos reconocimientos con los que EAFIT y sus aliados en la cultura, fomentan la creación literaria como una forma de contribuir al desarrollo de las comunidades y a la formación de públicos. ​​

## El universo de las letras

La Editorial EAFIT celebra las letras y los autores, contribuyendo a la sostenibilidad de la cadena del libro y brindando un espacio vital para escritores e investigadores. Acoge y desarrolla todos aquellos proyectos editoriales que tengan como misión apoyar y fortalecer la producción intelectual, científica y literaria que se genera en la Universidad, y contribuye a la divulgación y circulación de obras significativas para el desenvolvimiento social y cultural de la comunidad.

## Las notas sinfónicas de una orquesta con la impronta EAFIT

Hasta enfrentando el desafío de la virtualidad, la Orquesta Sinfónica EAFIT logra conectar a las audiencias con las emociones de la música. Sus integrantes se han adaptado al formato en línea y ensayan con la misma intensidad de siempre, preparando un repertorio variado, con obras universales y colombianas, para los conciertos que han venido ofreciendo y que planean compartir a través de plataformas digitales.​

### Covid-19: el conocimiento a favor de la salud y la vida

## Videolaringoscopios: tecnología e innovación al servicio de todos

Las iniciativas surgen de las diferentes áreas del conocimiento y de todas las dependencias de la Universidad, que se fortalece en la unión, en la solidaridad, en el saber. Y, aunque las circunstancias son nuevas para todos y complejas, la creatividad y la proactividad han surgido para tratar de frenar los efectos del covid-19. Una demostración de que, en las complejidades del mundo, forjar humanidad y sociedad cobra una importancia máxima.​

## Con MinCiencias, EAFIT irradia su conocimiento para aportar a los desafíos

Tres proyectos de investigación de EAFIT y uno más en el que la Universidad participa como parte de la alianza Caoba, fueron aprobados en la convocatoria del Ministerio de Ciencia, Tecnología e Innovación para frenar al nuevo coronavirus. Las propuestas se enmarcan en algunas de las cinco temáticas planteadas por dicha convocatoria: salud pública, sistemas de diagnóstico, estrategias de prevención y tratamiento, equipos y dispositivos, y sistemas de monitoreo.​

## Dos propuestas para informarse mejor

1. El Coronamonitor es una plataforma que busca generar información permanente y con alta precisión geográfica que sea útil para analizar las dinámicas de la crisis sanitaria, en sus diferentes dimensiones. ​

 2. Un nuevo modelo para la gerencia pública de la pandemia es propuesto en el documento Supervivencia, vivencia y convivencia durante y después del covid-19, que presenta 10 estrategias para la adaptación social a la nueva normalidad.​

## Pensar y repensar la crisis

La mirada analítica y reflexiva de 21 expertos académicos en distintas áreas del saber, alrededor de la coyuntura generada por el covid-19, se concentra en el libro Pensar la crisis: perplejidad, emergencia y un nuevo nosotros, una publicación de la Editorial EAFIT que recopila ensayos y artículos sobre diversos temas que aportan a la discusión pública frente a los cambios que supone una nueva realidad en el relacionamiento de la sociedad. ​

## Una cámara que desinfectará

Un dispositivo de radiación ultravioleta que sirve de escudo frente al agente biológico del covid-19 y que puede ubicarse en áreas urbanas de tráfico masivo de personas como aeropuertos, hospitales o zonas de trabajo está siendo desarrollado por investigadores de EAFIT, Universidad CES y la spin off Tezio, en colaboración científica con el Center for Radiological Research de la Universidad de Columbia (Estados Unidos).​