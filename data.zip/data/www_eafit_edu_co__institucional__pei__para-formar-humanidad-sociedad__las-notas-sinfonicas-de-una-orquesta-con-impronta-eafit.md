# Las notas sinfónicas de una orquesta con la impronta EAFIT​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Las notas sinfónicas de una orquesta con la impronta EAFIT​

*    Las Notas Sinfónicas de Una Orquesta Con La Impronta EAFIT​ 

​​Hasta enfrentando el desafío de la virtualidad, la Orquesta Sinfónica EAFIT logra conectar a las audiencias con las emociones de la música. Sus integrantes se han adaptado al formato en línea y ensayan con la misma intensidad de siempre, preparando un repertorio variado, con obras universales y colombianas, para los conciertos que han venido ofreciendo y que planean compartir a través de plataformas digitales.

En 2000 se creó con el objetivo de satisfacer la necesidad cultural de la ciudad de tener una orquesta sinfónica de la más alta calidad, capaz de proporcionar un programa anual estable que incluyera un repertorio sinfónico universal. También surgió en respuesta a las expectativas de los estudiantes de la Escuela de Música de la Universidad, que encuentran en ella un espacio para las prácticas orquestales.

Después de veinte años de trabajo, la Orquesta Sinfónica EAFIT ha desempeñado un papel cultural importante en el departamento y el país, que es ampliamente reconocido. Se exalta su selección del repertorio y la continua invitación de solistas invitados, directores y destacados músicos en la escena musical nacional e internacional. Dirigida por la maestra Cecilia Espinosa Arango, con su labor musical, además, atrae nuevos públicos a través de conciertos didácticos y difunde la música sinfónica colombiana.

En 2019, la Orquesta Sinfónica EAFIT ofreció 21 conciertos de temporada y otra serie de recitales complementarios con un recorrido por la obra y legado de diversos compositores nacionales e internacionales, que disfrutaron más de 6 mil espectadores. La temporada contó, además, con 2 montajes sinfónico-corales, 7 directores internacionales y 17 solistas invitados de diversas nacionalidades.

También es de resaltar que la Universidad ofrece música para todos los gustos. El Área de Extensión Cultural organizó en 2019, 30 conciertos que incluyeron artistas e intérpretes de distintos países en géneros como jazz, tango, electrónica y folk.

## 4. Educación de calidad

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)