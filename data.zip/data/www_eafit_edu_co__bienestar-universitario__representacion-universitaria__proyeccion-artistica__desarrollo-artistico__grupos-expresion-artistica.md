# Grupos de Expresión artística

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Grupos de Expresión artística

*    Grupos de Expresión Artística 

#### Acerca de los grupos

El objetivo primordial de los Grupos de expresión artística es el de reunir intereses comunes e inquietudes similares, con miras a presentaciones dentro y fuera de la Universidad, así como la participación en festivales e invitaciones especiales.

Los participantes de los Grupos de expresión artística pondrán en juego varias o todas sus capacidades estéticas y artísticas, en aras de la realización de las puestas en escena que buscarán, en todo momento, un lenguaje particular y propio, como una forma de expresar (en el más amplio sentido de la palabra) una sensibilidad ante sí mismos y ante las realidades próximas y lejanas que lo constituyen como ser humano, todo ello enmarcado en las actividades extracurriculares, que apoyan la formación académica de la comunidad eafitense, en el contexto de una educación integral.

La Universidad cuenta con 10 Grupos de expresión artística, para los que la inscripción no tiene ningún costo y se puede realizar de forma permanente y gratuita en el Departamento de Desarrollo Artístico, bloque 12 (ingreso por el parqueadero sur), o en el teléfono 604 2619320. Los Grupos están conformados exclusivamente por eafitenses: estudiantes de pre y posgrado, egresados, profesores, empleados y pensionados.

Horarios prioritarios para escoger materias

Después de llevar un año en el grupo podrás acceder a descuentos del valor de la matrícula de pregrado si cumples con los requisitos de la ​beca Grupos de Expresión Artística

Representar a la Universidad en eventos de carácter local o nacional

Desarrollar habilidades artísticas que complementen tu formación integral ​

Beneficios exclusivos por ser parte del Club de Lectores de la Editorial EAFIT​

Beca silla vacía para curs​os y diplomados con Educación Continua EAFIT. Ver requisitos y procedimiento para solicitud de beca. [Ver más aquí](https://www.eafit.edu.co/bienestar-universitario/representacion-universitaria/proyeccion-artistica/desarrollo-artistico/grupos-expresion-artistica/beca-cursos-y-diplomados).

Los Grupos de expresión artística de la Universidad EAFIT buscan proyectar a la Universidad en presentaciones dentro y fuera del campus, así como la participación en festivales e invitaciones especiales, todas ellas de carácter cultural y en ningún momento de recreación comercial. Para solicitar uno de nuestros Grupos de expresión artística, por favor tenga en cuenta:​

Los Grupos de expresión artística no se presentan en eventos de carácter privado.

Antes de solicitar la presentación de los Grupos de expresión artística, el interesado debe asegurarse de conocer los requerimientos técnicos y logísticos del Grupo y garantizar su cumplimiento al momento de la presentación. Los requerimientos pueden ser consultados acá, ingresando a la respectiva página del Grupo de interés.

Para la presentación de los Grupos de expresión artística se debe enviar un correo [adllo.artistico@eafit.edu.co](mailto:adllo.artistico@eafit.edu.co), solicitando el Grup​o de interés y e indicando el tipo de evento, fecha, lugar y hora de la presentación. Esta solicitud debe hacerse con mínimo 30 días calendario de anticipación a la fecha del evento, e implicará que el solicitante conoce y se compromete a cubrir los requerimientos técnicos y logísticos del Grupo.

El Departamento de Desarrollo Artístico dará respuesta a las solicitudes de presentación de los Grupos de expresión artística por lo menos 15 días calendario antes del evento.

La solicitud de un Grupo de expresión artística no asegura la presentación del mismo en el evento: ésta se formalizará una vez el Departamento de Desarrollo Artístico confirme por escrito (vía E-mail) al interesado la participación del Grupo.

Si en el momento del evento los organizadores de éste no cumplen con los requerimientos técnicos y logísticos, el Departamento de Desarrollo Artístico cancelará la participación del Grupo en dicho evento.​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)