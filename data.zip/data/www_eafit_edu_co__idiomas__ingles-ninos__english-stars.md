# English Stars - niños de 4 años - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# English Stars - niños de 4 años

### Edad 4 años

Un programa para aprender inglés y fortalecer habilidades clave para el desarrollo cognitivo, social y comunicativo en la primera infancia.

*    English Stars - Niños de 4 Años 

## English Stars

Inglés para niños de 4 años:

 En esta etapa, aprender un nuevo idioma es mucho más que comunicarse: es abrir la puerta a habilidades cognitivas, sociales y emocionales que acompañarán su desarrollo para toda la vida.

 En English Stars, el juego, la curiosidad y la experiencia son el camino para que los más pequeños vivan el inglés y, con él, nuevas formas de pensar, sentir y relacionarse con el mundo.

Inversión

## Inversión English Stars

$ 896.000

Programación

## Sede Sur

Lunes, miércoles o viernes

## Sede Laureles

Martes y sábado

##### **Programación**

**Lunes**

**Sede Sur:**4:00 p.m. a 5:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Junio 1 | Noviembre 10 - Enero 26 |
| Julio 13 | Noviembre 30 | Mayo 25 - Julio 22 |

**Martes**

**Sede Laureles:** 4:00 p.m. a 5:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 27 | Junio 2 | Noviembre 10 - Enero 22 |
| Julio 21 | Noviembre 24 | Mayo 24 - Julio 21 |

**Miércoles**

**Sede Sur:** 4:00 p.m. a 5:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 28 | Junio 3 | Noviembre 10 - Enero 28 |
| Julio 22 | Noviembre 25 | Mayo 25 - Julio 22 |

**Viernes**

**Sede Sur:**3:30pa.m. a 5:00 p.m. / 5:00 p.m. a 6:30 p.m.

**Sede Norte:** 4:30 p.m. a 6:00 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 23 | Junio 5 | Noviembre 10 - Enero 23 |
| Julio 17 | Noviembre 27 | Mayo 25 - Julio 17 |

**Sábado**

**Sede Laureles:**9:00 a.m. a 10:30 a.m. / 10:30 a.m. a 12:00 m.

**Sede Norte:** 9:00 a.m. a 10:30 a.m. / 10:30 a.m. a 12:00 m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 31 | Junio 6 | Noviembre 10 - Enero 31 |
| Julio 25 | Noviembre 28 | Mayo 25 - Julio 22 |

*Las sesiones 6, 12 y 18 son de 2 horas.

Información adicional

## Acompañamiento durante la sesión:

Nos encantaría que los cuidadores de los niños se quedaran durante el tiempo de la sesión. Esto no solo brinda a los niños un sentido adicional de comodidad y seguridad, sino que también crea un ambiente más acogedor y colaborativo. Mientras los niños y niñas, están en el aula, los padres, madres o cuidadores tendrán cómodos espacios en la sede para la espera.​

## Delantal o ropa de cambio:

Para asegurarnos de que los niños se sumerjan completamente en la cre​atividad, es posible que trabajemos con pinturas y otros recursos que puedan ensuciar un poquito. Por ello, sería genial si los niños pudieran traer un delantal o ropa de cambio. ¡Queremos que se diviertan sin preocupaciones y que su experiencia sea tan colorida como sus creaciones!

## Hidratación y Condiciones Especiales:

Nos encantaría que los cuidadores de los niños se quedaran durante el tiempo de la sesión. Esto no solo brinda a los niños un sentido adicional de comodidad y seguridad, sino que también crea un ambiente más acogedor y colaborativo. Mientras los niños y niñas, están en el aula, los padres, madres o cuidadores tendrán cómodos espacios en la sede para la espera.​​

###### **Temáticas**

Semestre I

**Experiencia:**Módulo 1

**Tema:**A Miniature World / Un mundo en miniatura

**Pregunta esencial**: Why do we have to protect insects

**Experiencia:**Módulo 2

**Tema:**Strong bodies, brilliant minds / Cuerpos fuertes, mentes brillantes

**Pregunta esencial**: Why do we have to eat?

**Experiencia:**Módulo 3

**Tema:**EcoKids/ Protectores del planeta

**Pregunta esencial**: Why do we have to recycle ?

Semestre II

**Experiencia:**Módulo 1

**Tema:**Heartful Explorers / Pequeños Héroes con Corazones Grandes

**Pregunta esencial**: Why should we have empathy?

**Experiencia:**Módulo 2

**Tema:**Friends & Fun / Amigos y diversión

**Pregunta esencial**: Why do we need friends ?

**Experiencia:**Módulo 3

**Tema:** Emotions trip! / Un viaje de emociones

**Pregunta esencial**: Why do I feel like this -self care?​

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)