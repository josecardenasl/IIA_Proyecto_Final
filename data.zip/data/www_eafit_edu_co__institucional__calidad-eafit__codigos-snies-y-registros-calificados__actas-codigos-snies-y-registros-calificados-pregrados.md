Buscar

*    Actas, Códigos SNIES y Registros Calificados Pregrados 

​Escuela de Administración​

###### **Programa: Administración de Negocios**

**Número y fecha del acta:**3 del 22 de julio de 1960

**Consejo:**Directivo

**Código SNIES:**1245

**No. Créditos:**160

**Duración semestres:**9

**Periodicidad Admisión:**Semestral

###### **Programa: Contaduría Pública**

**Número y fecha del acta:**39 del 10 de marzo de 1976

**Consejo**Superior

**Código SNIES:**1246

**No. Créditos:**163

**Duración semestres:**9

**Periodicidad Admisión:**Semestral

###### **Programa: Negocios Internacionales**

**Número y fecha del acta:**323 del 19 de febrero de 1992

**Consejo**Académico

**Código SNIES:**1244

**No. Créditos:**164

**Duración semestres:**9

**Periodicidad Admisión:**Semestral

###### **Programa: Mercadeo**

**Número y fecha del acta:**230 del 2 de octubre de 2010

**Consejo**Superior

**Código SNIES:**90979

**No. Créditos:**161

**Duración semestres:**9

**Periodicidad Admisión:**Semestral

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)