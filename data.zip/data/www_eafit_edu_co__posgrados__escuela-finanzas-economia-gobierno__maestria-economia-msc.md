# Maestría en Economía - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 9: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Maestría en Economía (MSc)

SNIES 54129, Medellín

Este programa está dirigido a profesionales con interés por la investigación económica y que cuenten con las habilidades analíticas y cuantitativas requeridas para proponer soluciones a problemas relevantes de la economía.

El programa fomenta un conocimiento profundo en teoría y modelación económica, con una formación rigurosa en Microeconomía y Macroeconomía, complementada por un aprendizaje avanzado en herramientas cuantitativas, que permite desarrollar con rigor investigaciones económicas teóricas y aplicadas.

Si buscas fortalecer tu perfil investigativo para incidir y convertirte en investigador, consultor o coordinador en organizaciones públicas, privadas o centros de investigación económica de alto impacto, este programa es para ti.

*    Escuela Finanzas Economia Gobierno 
*    Maestría En Economía (MSc) 

## Acreditación en Alta Calidad

Otorgada por Minciencias por el periodo máximo de 8 años, vigente hasta el año 2033.

## Registro calificado

Resolución 006250 del 18 de Junio de 2019​​​​.​​ Vigencia por 7 años.

Duración

3 semestres

Lugar

Medellín

Horario

Martes, jueves y sábado

Más información

Martes y jueves de 5:00 a 8:00 p.m. y los sábados de 9:00 a 12:00 m.

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 54129

Precio total del programa

$47.956.517

## Sobre el programa

Calidad y excelencia

**Somos Top en el Mundo**

Somos la mejor Escuela de Finanzas, Economía y Gobierno de Antioquia, según el ranking QS.

Somos la tercera mejor Escuela del país en investigación económica, según el ranking Research Papers in Economics (RePEc).

Los tres grupos de investigación adscritos a la Escuela de Finanzas y Economía de EAFIT —Sistemas Financieros y Macroeconomía, Políticas y Desarrollo, y el Observatorio de Mercados y Empresas— están clasificados en la máxima categoría (A1) por Colciencias.

Los profesores de la maestría publican regularmente en revistas internacionales indexadas de alto impacto y cuentan con títulos de doctorado otorgados por universidades de reconocido prestigio.

Contamos regularmente con docentes invitados de alto nivel, provenientes de reconocidas universidades de Estados Unidos y Europa, así como de organizaciones multinacionales.

**La tasa de desempleo de los graduados del programa es del 0 %.**

**Menos del 6% de Escuelas de Negocios a nivel global, cuentan con este reconocimiento.** Esta acreditación evalúa estándares de calidad académica al más alto nivel y representa el logro más importante para las Escuelas de Administración en el mundo entero.

Beca Talento en Investigación – Maestría en Economía EAFIT

En la Universidad EAFIT creemos en el poder de la investigación para crear conocimiento y transformar sociedad.

Por eso, ofrecemos la Beca Talento en Investigación, dirigida a quienes deseen cursar la Maestría en Economía, con beneficios como:

-Financiación parcial o total de la matrícula, a través de beca-préstamo condonable.

-En algunos casos, apoyo económico mensual para sostenimiento.

-Cobertura durante el tiempo equivalente a la duración del programa.

Para postularte:

-Consulta las líneas y temáticas de investigación disponibles.

-Contacta al investigador o investigadora de tu interés.

-Completa el formulario de postulación.

-Espera la confirmación del programa.

Conoce todos los detalles en nuestro sitio web: [Beca Talento en Investigación – EAFIT](https://www.eafit.edu.co/becas-y-financiacion/talento-en-investigacion-posgrado)

Doble titulación

El programa ofrece un convenio de doble titulación con la University of Essex (Inglaterra) y la Université Catholique de Louvain (Bélgica). Además, brinda la posibilidad de homologar créditos para continuar con el Doctorado en Economía de nuestra Escuela.

Graduados

Muchos de nuestros graduados han realizado su formación doctoral en universidades de alto prestigio internacional (como University of Michigan, University of Wisconsin, University of Maryland, UCLA, Johns Hopkins University, University of Minnesota, Emory University, Monash University, University of Glasgow, CEMFI y la Universidad Carlos III de Madrid).

Asimismo, una gran parte de los graduados de la Maestría en Economía ha estado vinculada a entidades nacionales, internacionales y multilaterales, o ha participado en proyectos con instituciones como la Reserva Federal de los Estados Unidos, el Banco de la República, el Banco Interamericano de Desarrollo (BID) y el Banco Mundial, entre otras.

Aprendizaje vivo y activo

El programa aplica diversas estrategias pedagógicas y de formación, combinando métodos de aprendizaje teóricos con el análisis de datos reales, aplicaciones econométricas, solución de problemas mediante diversas herramientas estadísticas, y aprendizaje basado en proyectos (ABP).

Durante el proceso de aprendizaje, se hace énfasis en el trabajo colaborativo, el pensamiento crítico y adaptativo, la aplicación de conceptos a problemas reales, la participación en proyectos de investigación y consultoría, la redacción de textos académicos y la docencia directa e indirecta junto con los profesores titulares de las asignaturas de la Escuela.

Conexiones e incidencia

Somos un universo de trabajo por lo público, las organizaciones y de incidencia social

Instituciones académicas, organizaciones multilaterales, el sector público, así como empresas y el sistema financiero, valoran altamente nuestros egresados. Muchos de ellos ocupan cargos estratégicos tanto en el sector público como en el privado, en el país y en el mundo.

Contamos con Valor Público, un centro de estudios e incidencia que acompaña al sector público y privado en proyectos y procesos estratégicos, y con EAFIT Social, un espacio de innovación y desarrollo social.

Tenemos ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas del entorno y la sociedad. En nuestra universidad tienen sede más de 21 landings empresariales y emprendimientos de impacto.

Campus transformador

Nuestra Escuela cuenta con el respaldo de un gran ecosistema de laboratorios: DataPol, un laboratorio de datos método y análisis político; Laboratorio y consultorio financiero, que ofrece consultorías en finanzas empresariales, personales y educación financiera.

La Universidad es el espacio ideal para generar conversaciones, conexiones y relaciones laborales. Contamos con espacios de estudio especializados.

Nuestra Biblioteca es un gran centro cultural con una inmensa colección literaria y de consulta académica, disponible para toda la comunidad eafitense.

Gran parte de nuestros estudiantes son becados, lo que nos da un alto nivel académico.

**Tenemos una agenda académica, cultural y social activa:**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en EAFIT.

**Somos actor clave de una ciudad universitaria:**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Acreditación

Como Institución estamos acreditados por AACSB (Association to Advance Collegiate Schools of Business), una de las coronas internacionales a las que los programas de Economía y Finanzas pueden aspirar. Menos del 6% de universidades a nivel global, cuentan con este [reconocimiento.](https://www.aacsb.edu/members/non-accredited-educational/u/universidad-eafit)

El programa de la Maestría en Economía cuenta con una Acreditación en Alta Calidad otorgada por Minciencias por el periodo máximo de 8 años, vigente hasta el año 2033.

Jefe de programa

###### **Conoce al jefe del programa**

###### **Thomas Goda**

Profesor Titular y Ph.D. en Economía, London Metropolitan University, Reino Unido

correo: [tgoda@eafit.edu.co](mailto:tgoda@eafit.edu.co)

Contacto

###### Ejecutiva de promoción

**Luz Marina Montoya**

+57 310 2273422

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

## Nuestras acreditaciones

### También te puede interesar

#### Maestría en Matemáticas Aplicadas

Duración

4 semestres

Lugar

Medellín

Horario

Lunes a sábado

Más información

Las asignaturas se ofrecen de lunes a viernes al inicio o al final del día, y sábados en la mañana. Los horarios pueden ajustarse en común acuerdo con los estudiantes de cada línea de investigación.

Idioma

Español

Modalidad

Presencial 

Más información

Perfil: Investigación 

 Inicio de nuevas cohortes en el primer semestre del año

SNIES

SNIES 1266

Precio total del programa

$42.915.641

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate