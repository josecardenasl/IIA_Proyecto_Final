# ​​​Innovaciones al servicio de problemas reales

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​​​​Innovaciones al servicio de problemas reales

*    ​​​Innovaciones Al Servicio de Problemas Reales 

Obtener una nueva patente es un símbolo de que los investigadores eafitenses dan un paso más hacia soluciones que el mundo necesita. El trabajo es arduo, requiere de tiempo, de pruebas, desarrollos y de conexiones con otras entidades.

Científicos del grupo de investigación en Ciencias Biológicas y Bioprocesos de EAFIT desarrollaron en conjunto con Augura un procedimiento para el descubrimiento de nuevos antibióticos que ayudan a combatir patógenos como el moko (Ralstonia solanacearum) que se produce en cultivos como el banano, y que además podría ayudar a enfrentar enfermedades causadas por otras bacterias en seres vivos. Este trabajo se convirtió, en julio de 2020, en la patente número 58 de la Universidad.

Previamente, a la patente con Augura, el Sistema machiembra de sección transversal constante y el Sistema machihembrado de traba mecánica, obtuvieron sus respectivas patentes, y parte de su importancia radica en que mejorarán la capacidad de los muros de mampostería para soportar cargas, conectando ladrillos sin pegamento. Sin embargo, lo que más impacta es que estas invenciones contribuyen al medio ambiente al prescindir del mortero de pega, uno de los materiales más contaminantes del sector constructor y considerado una de las debilidades de la mampostería convencional en relación con las fallas estructurales. Cada patente es un universo. Las que se mencionan son solo ejemplos recientes, pero para la Universidad estar atenta a responder a las necesidades de la sociedad ha marcado su carácter a largo de la historia, aportando lo que se requiere de acuerdo con las exigencias de cada época.

## Un total de 10 patentes se lograron en 2019 y EAFIT se sitúa entre las universidades con mayor número de patentes en el país.

## 8. Trabajo decente y crecimiento económico

## 9. Industria, innovación e infraestructura

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate