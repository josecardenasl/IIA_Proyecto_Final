# Maestría en Arquitectura Organizacional - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Maestría en Arquitectura Organizacional

*    Plan de Estudio 
*    Maestría En Arquitectura Organizacional 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

Semestre 1

Créditos 

totales-

Créditos 

#### Conferencia 1

Código: AN7001

Plan de estudios del programa
## Conferencia 1

Créditos

UMES

Código: **AN7001**

Créditos 2

#### Principios de Arquitectura Organizacional

Código: OD7002

Plan de estudios del programa
## Principios de Arquitectura Organizacional

2 Créditos

2 UMES

La arquitectura empresarial se fundamenta en una visión holística de la organización, integrando aspectos de negocio, datos, aplicaciones y tecnología. Este curso se apoya en los fundamentos de teorías y modelos reconocidos que permiten a los estudiantes comprender cómo las distintas partes de una empresa pueden alinearse para alcanzar objetivos estratégicos. La introducción a marcos de referencia como TOGAF y Zachman proporciona a los estudiantes herramientas prácticas y teóricas para analizar y diseñar soluciones arquitectónicas robustas.

Código: **OD7002**

Créditos 2

#### Estrategia y modelos de negocio

Código: OD7003

Plan de estudios del programa
## Estrategia y modelos de negocio

2 Créditos

3 UMES

La asignatura "Estrategia y Modelos de Negocio" se justifica como un componente esencial en el plan de estudios de la Maestría en Arquitectura Organizacional, ya que proporciona a los estudiantes las herramientas fundamentales para comprender y diseñar estructuras organizacionales en un entorno empresarial dinámico. Al finalizar el curso, los estudiantes habrán desarrollado competencias clave para analizar entornos complejos, proponer procesos estratégicos acordes a las organizaciones analizadas, diseñar modelos de negocio innovadores y alinear la arquitectura organizacional con los objetivos estratégicos.

Código: **OD7003**

Créditos 2

#### Liderazgo y gestión del cambio

Código: OD7004

Plan de estudios del programa
## Liderazgo y gestión del cambio

2 Créditos

3 UMES

La asignatura de Liderazgo y Gestión del Cambio es fundamental, dado que aborda las competencias clave necesarias para dirigir y transformar organizaciones en contextos dinámicos. Este curso proporciona a los estudiantes un entendimiento profundo de los principios de dirección, poder y sistemas de comportamiento organizacional, esenciales para ejercer un liderazgo efectivo. Además, se enfoca en la evolución de las teorías de liderazgo, incluyendo las teorías modernas, y en la gestión del cambio, preparando a los alumnos para liderar procesos de transformación organizacional con una visión estratégica y adaptativa. Al final del curso, los estudiantes contarán con conocimientos de principios de liderazgo y técnicas de gestión del cambio en la práctica, lo que les permitirá guiar a sus organizaciones sobre todo teniendo en cuenta el factor humano.

Código: **OD7004**

Créditos 2

#### Diseño de las organizaciones

Código: OD7005

Plan de estudios del programa
## Diseño de las organizaciones

2 Créditos

3 UMES

El diseño es, ante todo, un proceso creativo que requiere de conocimiento amplio del negocio y de la organización. Es un proceso dinámico y estructural, que interviene de manera relevante en el desempeño de la organización y toca no sólo aspectos operativos sino también sociales, en la medida en que contribuye a la configuración de un cierto imaginario en los individuos, quienes encuentran en el diseño, una orientación sobre su lugar y su rol en la organización. Intervenir en el diseño de una organización no es, por tanto, una acción administrativa aislada y puramente operativa. Por el contrario, requiere de un alto sentido ético y de responsabilidad profesional y de vasto conocimiento técnico para plantear el ajuste necesario para la viabilidad de la entidad.

Código: **OD7005**

Créditos 2

#### Experiencia de usuario y servicio

Código: OD7006

Plan de estudios del programa
## Experiencia de usuario y servicio

2 Créditos

3 UMES

La asignatura de Experiencia de Usuario y Servicios es crucial porque conecta la visión epistemológica del conocimiento con su aplicación pragmática en el diseño de experiencias y servicios efectivo. Durante el desarrollo del contenido, él estudiante conocerá en detalle los diferentes componentes usados en la creación y diseño de sitios web y aplicaciones móvil. Adicionalmente estará en capacidad de seguir el proceso para la creación de experiencias innovadoras usando herramientas como: customer journey, Design Thinking, Interfaces, Interacciones y Project management. Desarrollar habilidades para diseñar experiencias de usuario innovadoras para productos y servicios digitales.

Código: **OD7006**

Créditos 

#### Nivelatorio Infraestructura tecnológica

Código: OD7028

Plan de estudios del programa
## Nivelatorio Infraestructura tecnológica

Créditos

UMES

Código: **OD7028**

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate