# Maestría en Gobierno y Políticas Públicas - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Maestría en Gobierno y Políticas Públicas

*    Plan de Estudio 
*    Maestría En Gobierno y Políticas Públicas 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

Semestre 1

Créditos 

totales-

Créditos 2

#### Movilización Social y Actores Políticos

Código: GP0611

Plan de estudios del programa
## Movilización Social y Actores Políticos

2 Créditos

1 UMES

Código: **GP0611**

Créditos 3

#### Seminario 1: Problemas en la Gestión Territorial

Código: GP0612

Plan de estudios del programa
## Seminario 1: Problemas en la Gestión Territorial

3 Créditos

2 UMES

Código: **GP0612**

Créditos 0

#### Conceptos Básicos del Gobierno y las Políticas Públicas

Código: GP0637

Plan de estudios del programa
## Conceptos Básicos del Gobierno y las Políticas Públicas

0 Créditos

0 UMES

Código: **GP0637**

Créditos 0

#### Escritura Académica para Posgrados

Código: GP0638

Plan de estudios del programa
## Escritura Académica para Posgrados

0 Créditos

0 UMES

Código: **GP0638**

Créditos 3

#### Administración Pública

Código: GP0639

Plan de estudios del programa
## Administración Pública

3 Créditos

2 UMES

Código: **GP0639**

Créditos 3

#### Enfoques para el Análisis y Políticas Públicas

Código: GP0642

Plan de estudios del programa
## Enfoques para el Análisis y Políticas Públicas

3 Créditos

2 UMES

Código: **GP0642**

Créditos 3

#### Complementaria I

Código: GP0642 

Plan de estudios del programa
## Complementaria I

3 Créditos

UMES

Código: **GP0642**

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)