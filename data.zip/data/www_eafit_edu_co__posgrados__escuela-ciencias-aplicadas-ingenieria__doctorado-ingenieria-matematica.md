# Doctorado en Ingeniería Matemática - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

Posgrado

# Doctorado en Ingeniería Matemática

SNIES 103604, Medellín

Un doctor o una doctora en Ingeniería Matemática combina matemáticas e ingeniería para crear soluciones innovadoras en áreas como inteligencia artificial, optimización de recursos y modelación de fenómenos. Estos avances abordan desafíos en sectores como la banca, energía, tecnología, industria y academia.

El doctorado se enfoca en áreas como optimización, modelado y simulación, control de sistemas dinámicos y métodos computacionales avanzados. Atrae a quienes desean investigar y aplicar teorías matemáticas complejas a problemas prácticos, impulsando desarrollos en sectores como energía, salud, finanzas y tecnología.

*    Doctorado En Ingeniería Matemática 

## Registro calificado

Resolución​​​ 16305 del ​1 septiembre 2020.

Duración

8 semestres

Lugar

Medellín

Horario

Dedicación completa

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES ​103604

Precio total del programa

$139.684.028

## Sobre el programa

Calidad y excelencia

**Somos top en el mundo**

Nuestras profesoras María Eugenia Puerta Yepes y Olga Lucia Quintero Montoya recibieron un reconocimiento en 2020 por estar dentro de las 25 mujeres Matemáticas más relevantes del país.

Este año, nos encontramos celebrando los 10 años de trayectoria e impacto de nuestro doctorado, que inició en el año 2015 e hizo una renovación de registro calificado en el 2020.

Teniendo presente que nuestro programa ha tenido una evaluación satisfactoria, desde el año 2023 nos encontramos realizando un proceso interno de autoevaluación con el propósito de solicitar la acreditación del programa ante el Ministerio de Educación.

**Convenios internacionales**

Contamos con convenios internacionales en América y Europa, entre ellos:

- **Europa:** TUDelft, en Delft Países Bajos; Universidad de Anges en Francia; Universidad Carlos III de Madrid en España; Centro Alemán de Investigación en Cancer (DKFZ en alemán) en Heidelberg - Alemania; INRIA en Grenoble, Francia; Centro Tecnológico VICOMTECH, España.

- **América**: Universidad Nacional de San Juan en Argentina; Universidad Autónoma de México en el Instituto de Matemáticas, México; Universidad de Louisiana en Laffayette, Estados Unidos; Universidad de Cornell en Ithaca, NY, Estados Unidos.

Innovación y liderazgo

**Somos innovación en educación**

La investigación en este programa está estrechamente vinculada con procesos de innovación y creación. Los estudiantes son motivados a generar nuevas ideas y soluciones que puedan tener un impacto significativo en su campo de estudio.

Generalidades

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Nuestros estudiantes pueden trabajar en empresas financieras y bancarias, energéticas y de recursos naturales, tecnología y consultoría, industria farmacéutica y biotecnología, telecomunicaciones y tecnologías de la información, empresas de ingeniería y construcción, gobierno y organismos internacionales, y educación y academia, enfocadas en la investigación.

Dirigido a aspirantes con formación de pregrado y/o posgrado en matemáticas, ingeniería o áreas afines con pensamiento crítico, que respeten la diversidad, con sentido de responsabilidad y compromiso con la sociedad, y con capacidad de trabajar de forma independiente, que tengan interés en iniciar una formación investigativa, donde asumirán retos relacionados con un aprendizaje continuo y permanente.

Podrán analizar problemas en ámbitos interdisciplinarios que requieran de la matemática y la ingeniería, diseñar procesos académicos e investigativos utilizando herramientas de la ingeniería con rigurosidad matemática y resolver problemáticas y necesidades que aportan al desarrollo científico, tecnológico y empresarial, de manera crítica, integral y ética. Adicionalmente, estarán en capacidad de comunicar y difundir su conocimiento a una variedad de audiencias e interactuar en equipos de trabajo y de investigación en diferentes contextos.

Nuestros graduados podrán desempeñarse como docentes, compartiendo su conocimiento avanzado en matemáticas e ingeniería; como investigadores, liderando la innovación y aplicación de nuevas teorías matemáticas y sus aplicaciones en diferentes campos del saber; como consultores, aportando soluciones matemáticas avanzadas para desafíos empresariales y organizacionales.

​​​​​​​​​Lí​​​neas de investigación ​

Nuestro doctorado cuenta con líneas de investigación que integran conocimientos, intereses y capacidades de la Escuela de Ciencias Aplicadas e Ingeniería para el fortalecimiento de las investigaciones de nuestros estudiantes y la formación de nuestros doctores en Ingeniería Matemática, contribuyendo a solucionar problemas relevantes para la sociedad.

Nuestros estudiantes podrán hacer uso del Centro de Laboratorios de la Universidad EAFIT para el desarrollo de sus investigaciones y, de acuerdo con las áreas de enfoque de su proyecto de grado, tendrán a disposición ciertas capacidades en infraestructura y recursos tecnológicos.

Conoce las capacidades de nuestro Centro de Laboratorios, [aquí](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios)

Requisitos de admisión

**Los aspirantes a nuestro Doctorado en Ingeniería Matemática deberán:**

- Presentar una entrevista de admisión con el jefe del programa o la jefa de posgrados de la Escuela de Ciencias Aplicadas e Ingeniería.

- Preparar su hoja de vida, dos (2) cartas de recomendación y una (1) propuesta de investigación.

- Cumplir con el requisito de segundo idioma: inglés en nivel B1 dentro del Marco Común Europeo de Referencia.

Procedimientos de evaluación

Los exámenes de calificación consisten en dos evaluaciones de conocimientos, que podrán ser escritas (problemas planteados por los profesores evaluadores) o tipo proyecto (solución de un problema planteado) con sustentación oral. Las convocatorias a exámenes de calificación se realizarán al final de cada semestre académico, con al menos cuatro días hábiles de diferencia entre las dos pruebas.

Procedimiento de evaluación de los exámenes de calificación:

El Comité de Doctorado es el encargado de vigilar la realización de los dos exámenes de calificación. Los exámenes serán diseñados por al menos dos profesores (al menos uno externo a EAFIT) que trabajen en el área de interés de la formación doctoral nombrados por el Comité de Doctorado. El director de tesis puede recomendar a los evaluadores, aprobados por el comité de Doctorado, la bibliografía básica y complementaria, que cubra los temas específicos de los exámenes de calificación.

**Examen 1.** Formación disciplinar: Consiste en la evaluación de las competencias del estudiante en alguna(s) de la(s) áreas de formación matemática necesarias para el desarrollo de la temática de investigación, en coherencia con la denominación del programa y el perfil definido. Este

examen comprende evaluar la componente de conocimiento conceptual que debe tener el estudiante, en coherencia con las áreas y actividades de investigación alrededor de las cuales el trabajo doctoral ha de girar.

**Examen 2.** Formación Específica: Este examen busca validar la solvencia, viabilidad, pertinencia y proyección de la investigación que el estudiante de doctorado ha realizado desde el ingreso al programa. Esta evaluación de formación específica hace referencia al impacto de la investigación en curso en las áreas que le permiten llevar sus desarrollos teóricos al campo de la aplicabilidad.

El estudiante deberá aprobar los dos exámenes de calificación para posteriormente entregar la Propuesta de Tesis Doctoral a la jefatura de posgrados y a la dirección del programa. Todo estudiante del programa de Doctorado debe elaborar, en forma individual, una Propuesta de Tesis, con la aprobación de su Director de Tesis. En la Propuesta de Tesis Doctoral se plasman las actividades de investigación relacionadas con la Formación en Investigación adelantada hasta este punto del currículo del plan de estudios. La propuesta debe contener al menos los contenidos relacionados en la estructura vigente en el sistema INVESTIGA de gestión de la investigación dentro de la Universidad EAFIT.

**Notas:**

- La aprobación de los dos exámenes de calificación, la entrega de la propuesta de tesis doctoral y la aprobación total de las asignaturas obligatorias y complementarias conforman la candidatura a Doctor(a) en Ingeniería Matemática.

- Cuando el estudiante adquiere la condición de candidato a doctor y por ende está habilitado para matricular el desarrollo de su tesis, también se compromete a entregar un informe de avance, avalado por el Director de Tesis, al finalizar cada semestre académico.

Todo estudiante del **Doctorado en Ingeniería Matemática** debe elaborar y sustentar una tesis doctoral de forma individual y sobre la temática aprobada para su desarrollo al lograr la categoría del candidato(a). La investigación que sustenta la tesis doctoral es el eje central del trabajo de los estudiantes del programa de

**Doctorado en Ingeniería Matemática**, y en ella el estudiante presenta los resultados obtenidos durante su actividad investigativa, destacando sus aportes originales y significativos al conocimiento matemático o a sus aplicaciones. Ésta debe cambiar el estado del arte y ampliar la frontera del conocimiento. El nivel científico de sus contribuciones debe ameritar la publicación en revistas indexadas de reconocida calidad científica.

**Los aspirantes a nuestro Doctorado en Ingeniería Matemática deberán:**

- Presentar una entrevista de admisión con el jefe del programa o la jefa de posgrados de la Escuela de Ciencias Aplicadas e Ingeniería.

- Preparar su hoja de vida, dos (2) cartas de recomendación y una (1) propuesta de investigación.

- Cumplir con el requisito de segundo idioma: inglés en nivel B1 dentro del Marco Común Europeo de Referencia.

Contacto

###### **Jefe del Doctorado en Ingeniería Matemática**

Cristhian David Montoya Zambrano

Correo: dim@eafit.edu.co

###### **Jefatura de Maestrías y Doctorados de la Escuela de Ciencias Aplicadas e Ingeniería**

Gloria Maria Doria Herrera

**Correo:** jefatura.pos.ecaei@eafit.edu.co

###### **Ejecutivo comercial**

Stiven López Fernández

+57 310 5843006

## Plan de estudios

## Profesores

## Escuela de Ciencias Aplicadas e Ingeniería

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Doctorado en Ciencias de la Tierra

Duración

6 semestres

Lugar

Medellín

Horario

Tiempo completo

Más información

Lunes a viernes 8:00 a.m. a 6:00 p.m. y sábados 8:00 a.m. a 12:00 a.m.

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 102140

Precio total del programa:

$112.431.620

#### Doctorado en Ingeniería

Duración

6 semestres

Lugar

Medellín

Horario

De acuerdo con el número de créditos por semestre

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 52668

Precio total del programa

$158.407.364

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Con más de 700 organizaciones aliadas, así se expande la relación de EAFIT con las empresas

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

## Utilizamos cookies en este sitio web para mejorar su experiencia de usuario.

Al hacer click en Aceptar, otorga su consentimiento para que establezcamos cookies. [Conoce la política de datos personales](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Aceptar No, gracias