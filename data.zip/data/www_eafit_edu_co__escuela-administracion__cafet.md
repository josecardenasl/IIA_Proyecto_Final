# Cafet - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Cafet

*    Cafet 

###### ​Impulsa la industria

¿Sabías que el café es la segunda bebida más consumida en el mundo? Y el segundo producto más comercializado, después del petróleo. Cada taza es el resultado de un arduo trabajo de más miles de familias en países como Colombia, Brasil, Vietnam y muchos más, quienes con dedicación y esfuerzo luchan por mantener viva la tradición cafetera. Te invitamos a que conozcas un poco más sobre esta fascinante industria de una manera divertida.

Cafet es un juego de cartas que busca desarrollar habilidades en los jóvenes a través del conocimiento de la industria cafetera y sus productos.

###### A jugar

¿Estás listo para jugar Cafet?

###### ​Inspírate

¿Quieres utilizar Cafet en tu institución o empresa? Inspírate con estos casos de éxito de diferentes organizaciones que ya probaron el juego.

Otras validaciones - Inspírate

Además de las validaciones con universidades, colegios y empresas, se han realizado algunas actividades con grupos mixtos en los que han participado emprendedores y expertos en mercadeo e innovación.

A continuación podrás conocer los resultados de dichos ejercicios:

El juego se validó con estudiantes de inglés que se encuentran de intercambio en Australia. En el ejercicio, se utilizó el Innovation Game "Remember The Future".

El juego se utilizó con el fin de validar su dinámica en un ambiente diferente al educativo, utilizando el Innovation Game "Speed Boat".

Empresas - Inspírate

Esta validación, con representantes de EAFIT y la Empresa de Desarrollo Urbano (EDU), se realizó utilizando "Podar el árbol del producto", una herramienta de Innovation Games.

Colegios - Inspírate

Los estudiantes de la asignatura Travesía Audaz, de la línea de énfasis en innovación y emprendimiento de la Universidad EAFIT, han realizado validaciones con algunos colegios en la ciudad de Medellín.

A continuación podrás conocer los resultados de dichos ejercicios:

Durante la validación con estudiantes del colegio Fontán, de Medellín, se utilizó la metodología Speed Boat para evaluar los aspectos positivos y negativos del juego.

La directora y un grupo de docentes de la Unidad Educativa Católica La Victoria, en Ecuador, probaron el juego con el fin de validar nuevas metodologías de enseñanza que le permitan a sus estudiantes aprender de manera diferente.

Estudiantes del colegio Montessori, de Medellín, validaron el juego utilizando la herramienta Speed Boat, de Innovation Games.

Universidades - Inspírate

​El juego Cafet ha sido validado por docentes y estudiantes de diferentes universidades, no sólo en Colombia, sino en países como Ecuador, Perú y Chile.

Te invitamos a conocer algunos de estos casos:

Docentes de la Universidad Particular de Loja, en Ecuador, probaron el juego con sus estudiantes, reconociendo la importancia de utilizar nuevas metodologías de aprendizaje en sus clases.

Estudiantes de la asignatura Estudios Empresariales Colombianos probaron el juego durante la clase en la que hablarían de la industria del café en Colombia.

Docentes de la Pontificia Universidad Católica del Ecuador, sede Ibarra, probaron el juego con el fin de validar nuevas metodologías de enseñanza que le permitan a sus estudiantes aprender de manera diferente.

Estudiantes de la línea de énfasis en innovación y emprendimiento reconocieron en Cafet una herramienta que contribuye al fortalecimiento de habilidades.

Estudiantes del semillero de investigación SIMPRO validaron el juego, valorando el producto como una manera divertida de aprender más sobre la industria del café.

Estudiantes de la Universidad Mariano Gálvez de Guatemala validaron el producto y destacaron su dinámica, indicando que resulta divertido y diferente a los juegos tradicionales.

###### Creadores

Durante los últimos años, el área de Innovación y emprendimiento académico de la Universidad EAFIT ha trabajado en el desarrollo de material didáctico que contribuya a la implementación de nuevas metodologías de enseñanza, con el fin de ofrecerles a los estudiantes la posibilidad de aprender de manera diferente y lograr una mayor apropiación del conocimiento. Fue así como surgió el diseño de productos y juegos encaminados a promover el espíritu emprendedor y la cultura de innovación en la Universidad.

Además de Cafet, te invitamos a conocer [Villa Innovadora](https://portalqa.omega.eafit.edu.co/escuela-administracion/villa-innovadora), un juego de rol en el que tendrás que sobrevivir al ataque de los Creaticidas.

###### Contacto

### Correo

empresarismo@eafit.edu.co

### Teléfono

2619500 Ext. 9839

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate