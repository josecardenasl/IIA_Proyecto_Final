# Sigamos juntos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Sigamos juntos

Una iniciativa de los Repres.

*    Sigamos Juntos 

##### Invitación para estudiantes de posgrado

##### ​Invitación para estudiantes de pregrado​

###### ​¿De qué se trata la ini​ciativa?

**Sigamos Juntos** es una iniciativa de los [Representantes Estudiantiles](https://portalqa.omega.eafit.edu.co/bienestar-universitario/representacion-universitaria/representacion-estudiantil-profesoral/repres/representantes-estudiantiles) con la que buscamos acercarnos a los estudiantes con dificultades económicas desatadas por cuenta de la pandemia, conocer su realidad y acompañarlos en el sueño de continuar con sus estudios.

Queremos seguir creciendo juntos, estudiando y cumpliendo nuestros sueños. ¡Que nadie se quede sin estudiar por causa de la pandemia! Así que, si tienes dificultades económicas o conoces a alguien que las tenga, aplica a esta iniciativa o invítalo a participar.

La iniciativa consiste en ayudas económicas para la matrícula del semestre 2022-1. Una vez los estudiantes hayan aplicado, se dispondrá de un análisis para determinar quiénes serán los beneficiarios de este apoyo.

**​Ponte la mano en el corazón y aplica solo si realmente lo necesitas con el fin de ayudar a quienes verdaderamente requieren de apoyo económico y, de esta forma, Sigamos Juntos viviendo la Universidad.**

## Requisitos

Para estudiantes de pregrado

**Para 2022-1**, debes matricular **desde segundo semestre en adelante.**

*Si suspendiste tus estudios en el semestre 2020-2, 2021-1 o 2021-2 debido a la contingencia también podrás aplicar.

**Demostrar una situación económica que siga estando afectada por la emergencia y coyuntura actual** que te impida a ti o a tu familia pagar la totalidad de la matrícula del semestre 2022-1. Para eso debes anexar una carta donde nos cuentes cuál es tu dificultad económica (máximo 300 palabras); y los documentos que demuestren que el responsable de pago de la matrícula ha tenido disminución o afectación de sus ingresos, pérdida de empleo, licencias no remuneradas, o cambios relevantes en el contrato laboral o como trabajador independiente.

Tener un promedio crédito acumulado **mínimo de 3.6.**

**No ser beneficiario** de becas o créditos condonables renovables para matrícula del semestre 2022-1.

*Podrán aplicar estudiantes con becas de reconocimiento al liderazgo, reconocimiento a la expresión artística y beca estudiantes deportistas.

Para estudiantes de posgrado

###### Ten pre​sente

Debes cumplir con todos los requisitos y anexar la documentación completa.

Solo podrás diligenciar el formulario una vez.​​

**La convocatoria estará abierta desde el 2 de diciembre de 2021 a las 9:00 a.m. hasta el 5 de diciembre de 2021 a las 10:00 p.m.**

En caso de ser necesario, te contactaremos para ampliar información.

Este apoyo económico no es excluyente con las líneas de financiación de EAFIT a tu alcance.

Los resultados serán enviados a tu correo electrónico institucional **el 6 de diciembre.**

## Los resultados de esta convocatori​a se notifican por correo electrónico a las personas que diligenciaron el formulario.

## ¿​​​Necesitas más información?

### Instagram

### Correo

representantes@eafit.edu.co​

### Teléfono

(57) 604 26​19500

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)