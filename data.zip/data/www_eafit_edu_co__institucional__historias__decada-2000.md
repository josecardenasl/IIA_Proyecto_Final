# Década de 2000 - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Década 2000

Como parte de la transformación de la Institución que apuntaba a nuevos horizontes nació la Orquesta Sinfónica EAFIT, la Sala Patrimonial y la Universidad Parque.

*    Historias 
*    Década de 2000 

#### **Década de 2000: ​Un nuevo milenio, una nueva Universidad ​**

La música en EAFIT se convierte en orquesta y llegan los doctorados, mientras la Universidad traba​ja para que sus programas y procesos sean acreditados en alta calidad.​​​​​

Febrero de 2000 fue el mes escogido para darle a Medellín “su Orquesta deseada”. Y es que así fue calificada por los críticos musicales que asistieron a la primera temporada de conciertos de la Orquesta Sinfónica de EAFIT, que desde entonces se ha preocupado por montar en su repertorio piezas musicales nunca antes presentadas en la ciudad.

Para 2001 la oferta académica y humanística se amplió con el pregrado en Ciencias Políticas, y en el 2002 se dieron los primeros pasos para dotar a la Universidad con su Sala de Patrimonio Documental, como un apoyo importante para la tarea investigativa de quienes se acercan al Centro Cultural Biblioteca Luis Echavarría Villegas.

En 2003, EAFIT hizo parte de las primeras universidades del país en recibir su Acreditación Institucional de Alta Calidad, un acto voluntario en el que se hace necesario cumplir con unos requisitos o parámetros establecidos por el Consejo Nacional de Acreditación y por el Ministerio de Educación Nacional. La distinción se extendió hasta 2009.

Un año más tarde se aprobó la creación del doctorado en Administración, fruto de un trabajo académico de intercambio y cooperación desarrollado desde 1991 entre la Universidad EAFIT y la École de Hautes Études Commerciales (HEC) de Montreal.

Además, en 2004 nacieron los pregados en Ingeniería Física y Comunicación Social, que consolidaron la oferta de la Escuela de Ciencias y Humanidades. En 2007, por su parte, se le dio vida al doctorado en Ingeniería.

Y como regalo por los 45 años de la Institución, en 2005 se inaugura la Universidad de los Niños, un programa que se mantiene como referente en EAFIT y busca el acercamiento didáctico de los niños a la educación superior.

Otro hito significativo ocurrió en 2006, cuando EAFIT se inserta en el estudio de una región del mundo cada vez más conectada con América Latina: Asia Pacífico. Con esta intención, se inaugura un centro de estudios que le dio más sentido al lema “EAFIT, abierta al mundo”, que acompañaría a la Universidad por casi una década.

El 2008 trajo consigo el premio de diseño y arquitectura Lápiz de Acero, reconocimiento entregado a EAFIT gracias a su concepto de Universidad Parque.​

Pero sin duda uno de los acontecimientos más grandes en la historia de EAFIT fue la graduación en 2009 del primer doctor en Administración formado en una institución colombiana, Ernesto Barrera Duque, hecho que culmina una década de profundos adelantos para la Universidad.

Colombia en el nuevo milenio siguió enfrentando desafíos mayores para lograr una estabilidad económica, política y social. A pesar de los riesgos de fragmentación en el sector rural y la violencia de los grupos armados ilegales, con los que se siguió buscando acuerdos de paz, el país avanzó en ámbitos importantes como la modernización de sus sistemas de transporte y los progresos significativos del deporte nacional con la primera medalla de oro en unos Juegos Olímpicos (María Isabel Urrutia, levantamiento de pesas, Sídney 2000).

Por su parte, la Universidad, con la llegada del nuevo milenio, propició más de cerca el encuentro con la cultura y la investigación, sellos indiscutibles del decenio. De hecho, a partir de esta década, la Institución comenzó a transitar por una nueva etapa: la Universidad de docencia con investigación en la que, sin renunciar a su vocación de formación, también le apuesta de manera decidida a la generación de nuevo conocimiento.

Con el cambio de siglo se crearon, entonces, las ingenierías en Matemática (2002) y Física (2003), apuesta por las ciencias básicas; y el doctorado en Administración (2004), el primero en su género en Colombia, fruto de un trabajo académico de intercambio y cooperación desarrollado desde 1991 entre EAFIT y la École de Hautes Études Commerciales (HEC) de Montreal (Canadá). En 2005 empezó el segundo doctorado, el de Ingenierías.

Como parte de la transformación institucional que apuntaba a nuevos horizontes nació la Orquesta Sinfónica EAFIT (2000), la Sala de Patrimonio Documental (2002) y otros nuevos pregrados. Ciencias Políticas (2001) surgió en un contexto que requería la proposición de soluciones de convivencia en un mundo marcado por la lucha antiterrorista, desde los ataques del 9/11 en 2001; por el Socialismo del siglo XXI en Latinoamérica; y por la búsqueda de mecanismos para alcanzar mejores acuerdos sociales en el país. En 2004, con el pregrado en Comunicación Social, se respondió al reto que trajo el uso masivo de internet, de los teléfonos móviles y de las nuevas plataformas digitales de noticias.

En esta década, la alta calidad siguió siendo una premisa que orientaba el rumbo de EAFIT y fruto de este esfuerzo, en 2003, la Universidad obtuvo, por primera vez, la Acreditación Institucional, por seis años, lo que le permitió ser la primera institución de educación superior privada de Antioquia en obtener este aval.

Y, desde 2004, surgió la Universidad Parque, un concepto en su campus principal de Medellín que orienta la transformación de su infraestructura, y que invita a eafitenses y visitantes a disfrutar de un lugar para permanecer en el que se integran naturaleza, arquitectura y arte, en un ambiente de estudio o conversación. Este proyecto fue reconocido, en 2008, con el premio Lápiz de Acero, en la categoría de espacios públicos, otorgado por revista Proyecto Diseño.

La promoción de la cultura en sus más diversas formas se notó en Colombia con la promulgación de la Ley de Cine en 2003, con muy buenos resultados, y que propició la creación de muchas más obras y el crecimiento de una industria en la que convergen muchas otras profesiones. En el ámbito urbano, la década fue testigo de la llegada de los primeros mandatarios independientes del bipartidismo tradicional.

“Contribuir al progreso social, económico, científico y cultural del país” marcó la Misión de EAFIT desde 2008. Y así lo declaraba y lo materializaba “mediante el desarrollo de programas de pregrado y de posgrado –en un ambiente de pluralismo ideológico y de excelencia académica– para la formación de personas competentes internacionalmente; y con la realización de procesos de investigación científica y aplicada, en interacción permanente con los sectores empresarial, gubernamental y académico”. Con esta postura estratégica, la Institución explicitaba su transitar hacia las llamadas universidades de tercera generación que, además de transmitir y generar nuevo conocimiento, transfieren sus capacidades al entorno y, de esta manera, fortalece su tercer eje misional: la proyección social.

El mundo de la ciencia y la investigación no para en esta década, en la que se completó la secuencia del genoma humano (2003), comenzó a desarrollarse la revolución de las redes sociales (Facebook, 2004) y se confirmó la existencia de agua en Marte (2008). En EAFIT, de otro lado, los ejes de investigación e innovación se potenciaron con nuevos hitos como la creación del Centro para la Innovación, Consultoría y Empresarismo (CICE), en 2006, hoy Innovación EAFIT; la obtención de la primera patente: modelo de utilidad para el Tornillo de troncos giratorios (2005); o, tres años después, la primera patente de invención, denominada Aparato para la medición de las fuerzas de oclusión oral. De igual forma, antes de culminar la década, en 2009, surgió la primera spin off de la Universidad: Tezio-EAFIT.

La Institución, en su ejercicio permanente de repensarse, propuso dos programas innovadores que les dieron la bienvenida a públicos de otras generaciones a la experiencia universitaria. En 2001, inició actividades Saberes de Vida, para el deleite intelectual de los mayores de 55 años; y, en 2005, la Universidad de los Niños, en el que las preguntas permiten acercar la ciencia a niños a partir de los siete años de edad, además de ser uno de los pocos espacios de encuentro en el país entre estudiantes de la educación pública y privada.

También se fortaleció la impronta de EAFIT, a través del Núcleo de Formación Institucional (2007), que forma a los estudiantes para que desarrollen una conciencia lingüística y discursiva, histórica y social, estética y literaria, política, ciudadana y crítica. La internacionalización siguió su marcha con la apertura de la especialización en Mercadeo en Guatemala, el primer programa ofrecido en el exterior.

## Hitos de la década

2000

**Febrero de 2000**

###### **Nació la Orquesta Sinfónica EAFIT**

Con una obra del profesor Andrés Posada Saldarriaga, 42 músicos celebraron los conciertos inaugurales de la Orquesta Sinfónica de EAFIT, los días 24 y 25 de febrero de 2000.

2001

###### **Creación del pregrado en Ciencias Políticas**

Con un nuevo enfoque geopolítico desde la ciencia, la economía, la tecnología y la cultura, la Escuela de Ciencias y Humanidades ofrece este programa desde 2001.

2002

###### **Primeros egresados del programa de Música**

En las áreas de piano, dirección, composición y viola egresaron los seis primeros estudiantes del pregrado en Música, convirtiéndose así en testigos vivientes de ese proceso iniciado en 1998, con la fundación de la carrera. ​

2003

###### **La Universidad obtiene Acreditación de alta calidad**

En 2003, la Universidad recibió una noticia que la llenó de orgullo: el Ministerio de educación Nacional le otorgó la Acreditación Institucional de Alta Calidad, lo que convirtió a EAFIT en la primera institución privada de Antioquia en recibir esta distinción.

2004

###### **Juan Luis Mejía Arango es nombrado rector**

Este año se posesionó como Rector Juan Luis Mejía Arango, quien había sido Ministro de Cultura, y director de la Biblioteca Pública Piloto en Medellín y de la Biblioteca Nacional en Bogotá, entre otras instituciones.

##### **Inicia el doctorado en Administración**

Fue el primer programa de este tipo en Colombia.

##### **Se crean los pregrados en Comunicación Social e Ingeniería Física**

El semestre de 2004-1 arrancó con el lanzamiento de los pregrados en Ingeniería Física y Comunicación Social.

2005

##### Primer Encuentro de Música

Después de siete exitosas ediciones, el Festival de Jazz comienza a celebrarse bajo el nombre de Encuentro de Música Universidad EAFIT, al brindar por primera vez, desde su fundación, un espacio para otros géneros, intérpretes e instrumentos.

##### Otros sucesos importantes en el 2005

La Universidad inaugura su Laboratorio de Sísmica, con la presencia de la Ministra de Educación, Cecilia María Vélez White.

En su aniversario número 45, EAFIT crea la Universidad de los Niños.​

EAFIT obtiene su primera patente: Tornillo de troncos giratorios. Se concede como modelo de utilidad.​

2006

###### **Creación del Centro de Estudios Asia Pacífico**

Asumiendo este importante reto, la Universidad se propuso vincular a estudiantes y profesores que estuvieran interesados en entablar relaciones con países como Japón, China, Corea del Sur y Singapur.

###### **Otros sucesos importantes en el 2006**

Inicia la Universidad Parque, concepto que conjuga la naturaleza con diferentes espacios arquitectónicos.

Surge el Centro para la Innovación, Consultoría y Empresarismo (Cice).​​

2007

###### **Reforma curricular**

Las recomendaciones hechas por los pares académicos durante la visita de acreditación, el fortalecimiento de los cursos de humanidades y la incursión de las nuevas tecnologías de información, fueron algunas de las razones que sentaron los precedentes para que la Universidad comenzara este nuevo proceso institucional.

###### **Otros sucesos importantes en el 2007**

La especialización en Mercadeo inicia en Guatemala. Es el primer programa en el exterior.

La Universidad recibe la aprobación de un nuevo programa de doctorado: el de Ingeniería.

2008

###### **Universidad Parque obtuvo el premio Lápiz de Acero**

Cuatro años después de la creación y funcionamiento del proyecto Universidad Parque, el compromiso que adquirió EAFIT con el medio ambiente a través de esta iniciativa arquitectónica se vio finalmente recompensado el 15 de mayo de 2008 cuando la revista ProyectoDiseño le entregó al rector Juan Luís Mejía Arango el premio Lápiz de Acero en la categoría de Espacios Públicos.

###### **Otros sucesos importantes en el 2008**

EAFIT obtiene dos nuevas patentes de modelo de utilidad: Prensa hidráulica y Cortadora automática de tendidos de telas.

La Superintendencia de Industria y Comercio le otorga a la Universidad su primera patente de invención: Aparato para la medición de las fuerzas de oclusión oral.

El Aparato para la medición de la elasticidad del labio leporino es la segunda patente de invención que logra EAFIT.

El Ministerio de Educación Nacional aprueba las maestrías en Estudios Humanísticos, Economía y Música.

2009

###### **Derecho e Ingeniería de Diseño de Producto recibieron la Acreditación**

En su décimo aniversario, la Escuela de Derecho recibió la Acreditación de Alta Calidad por siete años, concedida por el Ministerio de Educación Nacional, como parte del evento Los Mejores en Educación 2009. El pregrado en Ingeniería de Diseño de Producto ya había sido previamente acreditado en el mes de julio y durante la misma ceremonia también se hizo acreedor de la Orden a la Educación Superior y a la Fe Pública Luis López de Mesa.

###### **Otros sucesos importantes en el 2009**

Ernesto Barrera Duque se gradúa como el primer doctor en Administración de EAFIT y del país.

EAFIT obtiene dos nuevas patentes de modelo de utilidad: el​ Gnatodinamómetro y el Sistema normalizado para el registro radiográfico.

Se crea la primera spin off de la Universidad: Tezio-EAFIT.

## Década de 2000

En el 2005 la Universidad obtuvo la primera patente: modelo de utilidad para el Tornillo de troncos giratorios; tres años después, la primera patente de invención, denominada Aparato para la medición de las fuerzas de oclusión oral.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate