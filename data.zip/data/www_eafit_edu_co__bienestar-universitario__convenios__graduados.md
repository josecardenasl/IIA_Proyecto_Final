# Convenios graduados - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Convenios

*    Convenios Graduados 

PadelHub

El pádel es un deporte de raqueta que se juega en parejas en una cancha cerrada, combinando elementos del tenis y el squash, se distingue por su dinamismo y estrategia, utilizando paredes de vidrio y malla metálica para mantener la pelota en juego.

Con reglas y puntuación similares al tenis, el pádel es accesible para todas las edades y niveles de habilidad, promoviendo tanto el ejercicio físico como la competitividad en un entorno social.

Beneficios físicos y mentales.

Aliado clave para el bienestar personal.

Mejora la forma física y la resistencia.

Regula la presión arterial.

Ayuda a mantener una buena densidad ósea.

Mejora la flexibilidad.

Fortalece músculos, tendones, ligamentos y articulaciones.

Ayuda a perder peso.

No es un deporte de contacto, tiene un riesgo mínimo de lesiones.

En convenio con la Universidad, tendrás lo siguientes beneficios:

Alquiler de canchas de pádel con descuentos del 20%.

Venta de tiqueteras para clases individuales con el 10% al 15% de descuento.

Acceso a programas de formación deportiva en pádel, con el fin de brindar espacios de esparcimiento y actividad física.

Adquirir paquete básico para la organización de torneos de pádel, acordes a los objetivos y ejecución que se requiera, incluye suvenires, manutención y otros servicios.​

###### Contacto​​

Andrés Correa

3162384458

Contacto sede central PADEL HUB DE MODA: 3235117565

Para redimir el beneficio debes reservar a través de la APP EASY CANCHA y abonar al menos el 25% de la reserva.

​Al momento de hacer efectiva la reserva, deberás pagar el saldo restante donde el asesor de la sede aplicará el descuento una vez presentes el carnet de la Universidad EAFIT.​

Para mayor información de la compañía y de los productos que ofrece. Visita la página [https://www.padelhub.com.co/](https://www.padelhub.com.co/) ​

*Aplica para las sedes PADEL HUB DE MODA, PADEL HUB BOLIVARIANA, y PADEL HUB PREMIUM PLAZA.

Colmédica

Colmedica Medicina Prepagada ofrece el plan de beneficios para los egresados de la Universidad, el cual aplica para los padres, parejas e hijos de los egresados. Dicho beneficio es directo para el egresado que desee tener otra alternativa de Salud diferente al plan de beneficios en Salud. Las tarifas aplican para cualquier sede nacional.

###### Contacto​

**Call Center**

301 394 45 40

CEM – Emergencia Médica

​Es un servicio de atención médica para aquellas personas que deseen ser atendidas en la comodidad de su hogar o en el lugar donde se encuentren, ofrece la atención de urgencias, emergencias y consultas médicas.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

**Empleados planta:** Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

**Empleados cátedra:** El empleado deberá realizar el pago directamente en Sura.

**Empleados temporales:** El empleado deberá realizar el pago directamente en Sura.

**Estudiantes de pregrado:** El estudiante deberá realizar el pago directamente en Coomeva.

**Estudiantes de idiomas:** El estudiante deberá realizar el pago directamente en Coomeva.

**Egresados:** El egresado deberá realizar el pago directamente en Coomeva.

**Pensionados:** El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

_* Aplica a nivel nacional._

###### Contacto​

310236​​6526

VetPlus

​​​​​​​​​Servicio de Medicina Prepagada Veterinaria con cobertura a nivel nacional. Presta servicios de medicina preventiva, atención y tratamiento de urgencias, enfermedades y accidentes.

En convenio con la Universidad, se obtiene descuento sobre la tarifa de los diferentes planes ofrecidos por VetPlus.

Aplica para perros y gatos.

_* Aplica a nivel nacional.​_

###### Contacto​​

Tomás Restrepo

3126985599

Para mayor información de la Compañía y de los productos que ofrece.

Visita la página [www.vetpluscolombia.com](https://www.vetpluscolombia.com/)

Prever

Plan de servicio exequial no reembolsable en dinero que otorga tarifas preferenciales sin límite en lazos de consanguinidad o afinidad.

También incluye servicio exequial para mascotas (perros y gatos).

**Pago por nómina****

$ 3.650​ por afiliado.

**Pago por directo**

Plan Previ familia Clásico $5.800 por cliente.

Plan Previ familia Especial $7.400 por cliente.

* Cancelando el trimestre obtiene 20% de descuento o si cancela semestre o anualidad, tiene el 25% de descuento.

* Aplica a nivel nacional.

** Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

***Pago por nómina solo aplica para empleados de planta

###### Contacto​

**Ángela María García**

Teléfono: (57) 3218383205​

E-mail: [angela.garcia@prever.com.co](mailto:angela.garcia@prever.com.co)

Directorio de servicios de salud

##### Directorio de servicios de salud

​​​​​​​​​​​Este servicio es atendido por un grupo de médicos especialistas e instituciones recomendados por la universidad que ofrecen excelentes servicios tarifas diferenciales a: estudiantes de educación formal, empleados con contrato laboral con EAFIT, estudiantes extranjeros, personas con contrato por prestación de servicios

###### AO_DIRECTORIO_SALUD_MENTAL.pdf

En el momento se estan actualizando los convenios con nuestros aliados médicos, las tarifas aún pueden variar

###### DIRECTORIO 2024.pdf

**La Universidad EAFIT a través de la Dirección de Desarrollo Humano–BU ha celebrado convenios con Entidades Externas para el otorgamiento de beneficios, los cuales podrán abarcar descuentos o una propuesta de valor, entre otros, dependiendo de la campaña que se active de manera diferencial para los beneficiarios de cada uno de ellos, a los cuales les aplican las siguientes condiciones y restricciones:**

1.   Los beneficiarios de los convenios deberán validar los términos propios de los mismos y los procedimientos establecidos para el acceso a los beneficios; adicionalmente, deberán tener presente que para adquirir dichos beneficios deberán presentar el original del carnet y/o demás documentos que den cuenta del vínculo exigido.
2.   Será la respectiva Entidad Externa la que le facturará directamente a los beneficiarios, y estos últimos deberán cancelar las sumas debidas al momento de la facturación o cuando así lo determine la mencionada Entidad. Por lo anterior, la Universidad EAFIT no asumirá la responsabilidad por los pagos realizados.
3.   La Universidad EAFIT no se hará responsable por el cumplimiento de las obligaciones asumidas por los beneficiarios, ya que se precisa que éstos actuarán en todo momento a título personal y en ningún caso bajo representación de la Universidad EAFIT.
4.   Si la Universidad EAFIT llegare a recibir un reclamo de los beneficiarios, con ocasión de los convenios aquí relacionados, direccionará el mismo a la correspondiente Entidad Externa, quien será el responsable directo de atenderlo y darle una oportuna respuesta.
5.   La Universidad EAFIT no adquiere obligación alguna por la prestación de los servicios por parte de las Entidades Externas aquí mencionadas. En caso de presentarse algún daño, deficiencia o perjuicio a los beneficiarios, durante o después de la prestación del servicio, será responsabilidad únicamente de la respectiva Entidad Externa el resarcimiento del mismo.Para el caso de los beneficiarios que ostenten la condición de empleados de la Universidad EAFIT, se advierte que los beneficios derivados de los convenios aquí mencionados, son de carácter discrecional, los cuales no constituyen salario en tanto no están retribuyendo el servicio que prestan los empleados a la Institución.
6.   La Universidad EAFIT y las Entidades Externas aquí mencionadas, declaran que rechazan todas las clases de Explotación Sexual Comercial de Niños y Adolescentes (ESCNA), reconociendo, implementando y apoyando las medidas necesarias para la prevención de la ESCNNA.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate