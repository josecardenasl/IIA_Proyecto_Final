# Índice de Idiomas - Universidad EAFIT

EAFIT cuenta con los siguientes idiomas:

- **Agenda cultural - EAFIT** — https://www.eafit.edu.co/idiomas/agenda-cultural
- **Alemán para Jóvenes | Idiomas EAFIT** — https://www.eafit.edu.co/idiomas/aleman-jovenes
- **Clases de prueba - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/clases-prueba
- **Francés para adultos - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/frances-adultos
- **Francés para jóvenes - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/frances-jovenes
- **Global Explorers - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/global-explorers
- **Inglés para adultos - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/ingles-adultos
- **Inglés para jóvenes - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/ingles-jovenes
- **Programa de inglés para niños** — https://www.eafit.edu.co/idiomas/ingles-ninos
- **Programa de inglés para niños y niñas - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/ingles-ninos/calendario-a
- **English Stars - niños de 4 años - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/ingles-ninos/english-stars
- **Vacacionales Happy Time - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/ingles-ninos/happy-time
- **idiomas / ingles-ninos / inmersiones** — https://www.eafit.edu.co/idiomas/ingles-ninos/inmersiones
- **Inglés virtual para adultos - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/ingles-virtual-para-adultos
- **Programas de Inglés - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/ingles
- **Italiano para adultos - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/italiano-adultos
- **Otros Idiomas - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/otros-idiomas
- **idiomas / politica-lengua-extranjera** — https://www.eafit.edu.co/idiomas/politica-lengua-extranjera
- **idiomas / por-que-estudiar-idiomas-eafit** — https://www.eafit.edu.co/idiomas/por-que-estudiar-idiomas-eafit
- **Programas corporativos para empresas - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/portafolio-corporativo
- **Portugués para adultos - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/portugues-adultos
- **Spanish program - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/spanish-program
- **Testing Center - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/testing-center
- **APTIS for teachers - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/testing-center/aptis-for-teachers
- **APTIS general - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/testing-center/aptis-general
- **idiomas / testing-center / ielts** — https://www.eafit.edu.co/idiomas/testing-center/ielts
- **Oxford Test of English - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/testing-center/oxford-test-english
- **TOEFL IBT - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/testing-center/toefl-ibt
- **idiomas / testing-center / toeic-4-competencias** — https://www.eafit.edu.co/idiomas/testing-center/toeic-4-competencias
- **TOEIC - Universidad EAFIT** — https://www.eafit.edu.co/idiomas/testing-center/toeic
- **idiomas / testing-center / track-test-comprension-lectora** — https://www.eafit.edu.co/idiomas/testing-center/track-test-comprension-lectora
- **idiomas / testing-center / track-test-presencial** — https://www.eafit.edu.co/idiomas/testing-center/track-test-presencial
- **idiomas / testing-center / track-test-virtual** — https://www.eafit.edu.co/idiomas/testing-center/track-test-virtual
