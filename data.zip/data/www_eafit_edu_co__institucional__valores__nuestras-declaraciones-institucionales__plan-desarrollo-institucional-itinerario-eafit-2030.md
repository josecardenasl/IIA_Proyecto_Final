# Plan de Desarrollo Institucional: ​Itinerario EAFIT 203​​​​0​​​​ - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Itinerario EAFIT: Plan de Desarrollo Institucional

*    Valores 
*    Plan de Desarrollo Institucional: ​Itinerario EAFIT 203​​​​0​​​​ 

El **Itinerario EAFIT 2035** es el **Plan de Desarrollo Institucional** que articula el **propósito y la visión** de la Universidad con sus rutas estratégicas de transformación. Se entiende no como un listado cerrado de objetivos, sino como un**horizonte general y flexible** que ofrece dirección, inspira acciones y permite integrar aprendizajes en el tiempo.

Más que un instrumento de planeación es una mirada de futuro, una **travesía colectiva** que propone **horizontes** que orientan la marcha institucional, reconociendo que la Universidad se transforma a la par de los cambios sociales, culturales, ambientales y tecnológicos de su entorno.

Su carácter abierto y dinámico responde a la identidad de EAFIT como **comunidad de conocimiento y saberes aplicados que dialoga**con empresas consolidadas, sistemas públicos, emprendimientos de impacto, comunidades y redes globales.

Desde esa identidad, el Itinerario se concibe como un espacio de creación, innovación y aprendizaje continuo que conecta ciencia, tecnología, humanidades y cultura con las necesidades y desafíos de la sociedad.

## **Principios orientadores**

La coherencia y la vigencia del Itinerario EAFIT 2035 se sostiene en los siguientes principios:

**1. Horizontes, no destinos**

El Itinerario señala direcciones de transformación y abre posibilidades en lugar de fijar un único punto de llegada. Su fuerza está en ofrecer claridad de rumbo y, al mismo tiempo, flexibilidad para adaptarse a los cambios del entorno.

**2. Modelo orgánico de actualización permanente**

El Itinerario se concibe como un sistema en evolución continua. Sus retos de corto y mediano plazo se revisan periódicamente, incorporando aprendizajes institucionales, indicadores de impacto y nuevas tendencias que surgen del entorno.

**3. Gobernanza participativa y abierta**

La vitalidad del Itinerario depende de la voz de la comunidad universitaria y aliados de los ecosistemas de empresas consolidadas; sistemas públicos, sociales y comunitarios; y emprendimientos. Se actualiza mediante espacios de diálogo, deliberación y cocreación que garantizan diversidad de perspectivas y legitimidad en las decisiones estratégicas.

**4. Transparencia e interactividad**

La Universidad asegurará mecanismos de seguimiento abiertos y accesibles, incluyendo plataformas digitales que permitan a la comunidad conocer avances, aportar nuevas ideas y fortalecer la toma de decisiones estratégicas..

## Itinerario 2035

El **Itinerario EAFIT 2035** se estructura en **ocho itinerarios** estratégicos que expresan los grandes horizontes de la Universidad hacia el futuro. Como se dijo, cada uno recoge los aportes de la comunidad, los aprendizajes institucionales y los desafíos emergentes del entorno, en conexión con los ejes misionales de la Universidad: **aprendizaje; ciencia, tecnología e innovación; y conexión e impacto social.**

Aprendizaje transformador y flexible

##### Aprendizaje transformador y flexible

En EAFIT el aprendizaje es un proceso vivo, integral y transformador, que acompaña a las personas en todas las etapas de su vida. Se fundamenta en un modelo educativo flexible y abierto centrado en el estudiante que ofrece múltiples posibilidades para ser transitado desde la educación media y técnica hasta el posgrado y la educación continua.

El aprendizaje se concibe como experiencia crítica y situada, articulada en torno al modelo educativo y su ADN, denominado Aprendizaje E, que integra los atributos de estudiante en el centro, excelencia, experimentación y creación, emprendimiento e innovación, en conexión y ética. Se trata de un proceso que combina lo técnico y lo humanista, lo disciplinar y lo transdisciplinar, e integra con responsabilidad las tecnologías emergentes. La excelencia no se entiende como perfección, sino como compromiso permanente con la calidad, la profundidad y el sentido del aprendizaje: una búsqueda constante por dar lo mejor en cada contexto, cultivar rigor y relevancia en los procesos, y formar personas capaces de transformar con responsabilidad su entorno.

En este proceso es fundamental la labor de los profesores como agentes de inspiración para la comunidad estudiantil, y como actores decisivos en el diseño y la implementación de enfoques pedagógicos y metodologías que inciden en la calidad del aprendizaje.

Al mismo tiempo reconoce la diversidad de trayectorias y potencia las capacidades de los **estudiantes como responsables de su formación.**

Este itinerario se conecta con los otros **ejes misionales** pues incorpora la **investigación** y la creación desde etapas tempranas como parte integral de la formación; y asegura la conexión e impacto social al vincular el currículo con la empleabilidad, la innovación y la ciudadanía global.

##### Horizonte

Consolidar a EAFIT como referente nacional e internacional en modelos de aprendizaje innovadores, flexibles y de excelencia, que integren ciencia, humanidades, tecnología y cultura, y que estén en diálogo permanente con los desafíos sociales, culturales, ambientales y productivos del país y del mundo.

##### Tipos de retos estratégicos

1.   **Currículo flexible:**avanzar hacia estructuras modulares y apilables reconocidas por empleadores y redes académicas por el ofrecimiento de trayectorias diferenciadas y articuladas en todos los niveles de formación.
2.   **Aprendizaje E como ADN del modelo educativo:**consolidar el modelo de Aprendizaje E en todas las trayectorias formativas, poniendo al estudiante en el centro y reconociéndolo como protagonista activo del aprendizaje. Impulsar experiencias significativas que integren, además, excelencia, experimentación y creación, emprendimiento e innovación, en conexión y ética para que el aprendizaje sea transformador.
3.   **Ruta de excelencia para el éxito estudiantil:** asegurar la coherencia y la calidad de los procesos de aprendizaje y de bienestar, acompañando el desarrollo de competencias desde el acceso, la permanencia y la graduación, de manera que cada trayectoria formativa se viva como experiencia transformadora.
4.   **Profesores inspiradores:**fortalecer la formación pedagógica y disciplinar del profesorado; garantizar coherencia en metodologías y evaluaciones; reconocer el rol docente como guía en un modelo donde el estudiante es protagonista, resaltando la exigencia de una preparación previa rigurosa en el conocimiento y el acompañamiento al proceso de autoformación estudiantil.
5.   **Tecnologías emergentes e IA:**integrar la inteligencia artificial y los entornos digitales como dimensiones pedagógicas y humanas del aprendizaje, asegurando lineamientos de uso responsable y formación en pensamiento crítico y creativo.
6.   **Interdisciplinariedad y humanidades digitales:**fomentar programas y proyectos que crucen fronteras disciplinares, integrando humanidades, artes, ciencias y tecnologías.
7.   **Trayectorias hacia la educación superior:** articular de manera clara los procesos de formación desde la educación media hasta la universitaria, incluyendo programas técnicos y tecnológicos con mecanismos de reconocimiento de las trayectorias ya cursadas, que permitan a más jóvenes acceder y avanzar en la educación superior.
8.   **Educación avanzada y permanente:**consolidar a EAFIT como plataforma de aprendizaje a lo largo de la vida, con oferta de posgrados, microcredenciales y programas de reskilling y upskilling para organizaciones y profesionales en todas las etapas de su desarrollo.
9.   **Aseguramiento del aprendizaje:** fortalecer la implementación del modelo institucional de aseguramiento del aprendizaje, articulando indicadores, evaluaciones y analíticas que permitan evidenciar logros formativos, retroalimentar los currículos y garantizar la mejora continua de la experiencia educativa.
10.   **Núcleo de Formación Institucional:** revisar periódicamente la oferta del programa de formación humanista y científico de pregrado de la Universidad para que responda a los retos del entorno y los desafíos de la humanidad.
11.   **Educación para el Desarrollo Sostenible (EDS):**incorporar conceptos y reflexiones críticas sobre el desarrollo sostenible; fomentar competencias clave para la sostenibilidad en todos los programas de la universidad; y hacer de la conciencia ambiental un atributo de nuestros estudiantes y graduados.

Ciencia, tecnología e innovación con impacto social y territorial

##### Ciencia, tecnología e innovación con impacto social y territorial

Este itinerario reconoce a EAFIT como una **universidad de saberes aplicados** que, con base en las capacidades de investigación y colaboración de sus profesores y estudiantes, transforma el conocimiento en soluciones para la sociedad, las organizaciones y el territorio. La ciencia, la tecnología y la innovación se concibe como un **sistema vivo y en movimiento**, abierto al diálogo de saberes, a la interdisciplinariedad y a la apropiación social del conocimiento, con capacidad de incidir en el desarrollo sostenible, la equidad y los retos globales.

##### Horizonte

Potenciar a EAFIT como un nodo articulador de c**iencia, tecnología, innovación, creación y transferencia tecnológica,** reconocido por su capacidad de transformar saberes en soluciones para las organizaciones, las comunidades y el territorio. Al mismo tiempo, posicionar a la Universidad como **plataforma líder del ecosistema regional de CTeI**, articulando actores y recursos para convertir el conocimiento en innovación y desarrollo sostenible.

##### Tipos de retos estratégicos

1.   **Investigación con pertinencia e impacto:** fomentar proyectos liderados por la comunidad de profesores que resuelvan problemas sociales, ambientales y organizacionales, en alianza con organizaciones y comunidades.
2.   **Innovación y transferencia:**fortalecer spin-offs, startups, centros de transferencia tecnológica, hubs de innovación y programas de emprendimiento que conecten la investigación con las organizaciones y la sociedad.
3.   **Apropiación social del conocimiento:** promover prácticas de divulgación, participación ciudadana y uso social de los resultados de investigación, como parte esencial del impacto universitario.
4.   **Formación investigativa temprana:**integrar semilleros, laboratorios vivos y experiencias de investigación en pregrado y posgrado, como parte central de la formación.
5.   **Condiciones para el talento humano:** aplicar incentivos y rutas de carrera que respalden a profesores, investigadores y creadores.
6.   **Creación como forma de conocimiento:**reconocer la creación (científica, tecnológica y artística en su dimensión investigativa) como proceso de invención y experimentación que aporta a la innovación social y organizacional.
7.   **Interdisciplinariedad y focos estratégicos:**articular ciencia, ingeniería, humanidades, artes y ciencias sociales; y priorizar temas clave para los retos de sociedad, la región y el mundo.
8.   **Ciencia abierta y colaborativa:**promover acceso abierto, colaboración interdisciplinaria e internacionalización de la investigación.
9.   **Recursos y sostenibilidad de la investigación:** garantizar financiación diversificada (pública, privada, filantrópica e internacional), con estructuras que promuevan continuidad y excelencia en la producción científica y creativa.
10.   **Emprendimiento de base científico tecnológico:**fortalecer el emprendimiento de base científico tecnológico, como vía para transferir y escalar resultados de investigación, con programas de incubación, aceleración y acompañamiento a investigados.
11.   **Ecosistema regional de CTeI:** consolidar a EAFIT como plataforma articuladora del ecosistema regional de ciencia, tecnología, innovación, creación y transferencia tecnológica, convocando universidades, empresas, sector público, organizaciones sociales y cooperación internacional en torno a retos estratégicos del territorio y del país.

Conexión e incidencia con propósito

##### Conexión e incidencia con propósito

La conexión y el impacto social son parte del **ADN de EAFIT**. Este itinerario se entiende como un **diálogo permanente con la sociedad y los ecosistemas de organizaciones (empresas consolidadas; sistemas públicos, sociales y comunitarios; y emprendimientos)** en los que participa la Universidad. Su propósito es **convertir el conocimiento en valor público** y en transformación de realidades.

El impacto y la incidencia se concibe en tres dimensiones principales:

**Sobre las organizaciones:** al aportar conocimiento e innovaci ón, que fortalezcan sus capacidades, impulsen su transformación y mejoren su sostenibilidad.

**Territorial**: al generar valor p úblico y fortalecer capacidades locales y comunitarias que inciden en la calidad de vida, reconociendo además a la Universidad como institución que aprende de estos actores e incorpora sus saberes y experiencias territoriales.

**Conversaci****ón pública y agenda nacional:** al proponer conversaciones de valor y traer la evidencia a la discusión y al debate nacional.

##### Horizonte

Proyectar a EAFIT como universidad reconocida por su capacidad de dialogar con la sociedad y de articularse con empresas, sistemas públicos y emprendimientos de impacto, consolidándose como aliada confiable para la transformación de realidades. Los graduados, como comunidad activa, son puentes estratégicos que amplifican esta conexión e incidencia en los distintos territorios y sectores donde participan. La Universidad se posiciona como institución que aporta y aprende de los saberes territoriales, y que desde su singularidad contribuye al desarrollo regional y participa en redes nacionales e internacionales para transformar el conocimiento en valor público, confianza y soluciones sostenibles.

##### Tipos de retos estratégicos

1.   **Alianzas con propósito:** profundizar en los vínculos con empresas consolidadas, sistemas públicos, sociales y comunitarios, y emprendimientos de impacto, para cocrear soluciones que fortalezcan capacidades y generen transformación sostenible.
2.   **Impacto en el aprendizaje y la CTeI:**garantizar que los programas académicos y las iniciativas de ciencia, tecnología e innovación incorporen experiencias de conexión con comunidades, organizaciones y territorios, visibilizando el saber eafitense como valor público.
3.   **Conexión territorial:**ampliar la presencia de EAFIT en regiones e impulsar nuevos proyectos que atiendan necesidades de Medellín, Antioquia y Colombia, generando valor público, potenciando capacidades locales y regionales, y mejorando la calidad de vida de las comunidades.
4.   **Contribuir en el desarrollo del Distrito de Ciencia Tecnología e Innovación de Medellín:** liderar las iniciativas que expandan las capacidades de CTeI a proyectos de alto impacto de la ciudad.
5.   **Diálogo incidente para el impacto:**fortalecer mecanismos de diálogo y retroalimentación que permitan a estudiantes, profesores y graduados aportar visiones y propuestas a las instancias de gobierno ya existentes, enriqueciendo la toma de decisiones sobre la conexión e impacto social de la Universidad.
6.   **Graduados como red de conexión:** consolidar la comunidad de graduados como profesores que potencian el modelo educativo; y actores estratégicos en la incidencia territorial, el fortalecimiento de ecosistemas y la generación de valor público, mediante mentorías, redes profesionales y proyectos colaborativos.
7.   **Ampliar nuestra contribución en sistemas públicos y sociales a otras regiones del país**, transfiriendo conocimiento e incidiendo en la agenda pública.
8.   **Aprendizaje situado:** incorporar las actividades de conexión e incidencia en las experiencias de aprendizaje dentro y fuera del aula.

Acceso, inclusión y bienestar

##### Acceso, inclusión y bienestar

Este itinerario reconoce que el acceso a la educación superior y la permanencia en ella no dependen solo de las condiciones académicas, sino de un ecosistema integral que responda a las nuevas realidades contemporáneas. En EAFIT, el bienestar no se limita a servicios aislados, sino que constituye una cultura institucional que atiende los retos de salud mental, seguridad y confianza, diversidad, inclusión, convivencia y equidad, así como la construcción de un campus sostenible y humano, entendido como espacio vital de encuentro, hospitalidad, deporte y vida universitaria.

El cuidado abarca a toda la comunidad universitaria: estudiantes, profesores, colaboradores y graduados. Para los estudiantes, significa acompañamiento integral desde el acceso hasta la graduación, con servicios de salud, programas de deporte, arte y cultura que favorecen una vida equilibrada y plena; para los profesores y colaboradores, condiciones laborales dignas y justas, desarrollo profesional y equilibrio vida–trabajo; y para los graduados, un v ínculo perenne con la Universidad, a través de mentorías, redes y filantropía.

Este itinerario se conecta con los ejes misionales en clave de cuidado: un aprendizaje que reconoce la diversidad y potencia el talento; una ciencia, tecnología e innovación que aporta soluciones a los retos del bienestar, el cuidado, la salud, el deporte, el trabajo y la convivencia; y una conexión e impacto social que se expresa en inclusión, confianza y éxito colectivo.

##### Horizonte

Consolidar un ecosistema de acceso, **bienestar e inclusión que responda a los desafíos contemporáneos en salud integral, deporte, intergeneracionalidad, diversidad y equidad, seguridad, empleabilidad, convivencia, bienestar laboral y un campus sostenible y humano**. Este ecosistema acompaña el éxito estudiantil no solo en lo académico, sino también en la experiencia vital universitaria, fortaleciendo el sentido de pertenencia, la participación y el vínculo como comunidad eafitense.

##### Tipos de retos estratégicos

1.   **Acceso equitativo y sostenido al talento:** ampliar mecanismos de becas, apoyos económicos y modelos de financiación solidaria para que más jóvenes con diversos talentos encuentren en EAFIT una oportunidad real de transformación, reconociendo y potenciando sus capacidades.
2.   **Cuidado y bienestar para estudiantes:** fortalecer servicios de salud mental y salud física; acompañamiento psicosocial y académico; y programas de deporte, arte y cultura como parte de una vida universitaria equilibrada y plena.
3.   **Bienestar y desarrollo para profesores y colaboradores:**promover condiciones laborales que garanticen equilibrio, salud y bienestar, acompañar el desarrollo pedagógico y disciplinar de los profesores, y consolidar programas de formación, reconocimiento y participación para todos los colaboradores. Incorporar programas específicos de bienestar profesoral, deportes, salud mental, y prácticas de respeto y convivencia que fortalezcan la vida académica.
4.   **Permanencia con éxito:** desplegar estrategias de acompañamiento diferenciado para reducir deserción, atender dificultades académicas y apoyar a estudiantes en condiciones de vulnerabilidad.
5.   **Diversidad, equidad e inclusión:** asegurar un campus accesible y seguro, con protocolos efectivos contra la discriminación y el acoso, y una cultura universitaria plural y respetuosa. Este compromiso se fortalece mediante un enfoque de interseccionalidad, que permite comprender las múltiples causas de discriminación que pueden confluir en una misma persona o grupo como el género, la clase, la etnia, entre otros factores.
6.   **Campus sostenible y humano:** consolidar el campus como un espacio vital de encuentro, aprendizaje y vida universitaria, con ambientes dignos, accesibles, seguros y coherentes con la visión de Universidad-Parque.
7.   **Intergeneracionalidad en la comunidad universitaria:** responder a las necesidades y expectativas de una comunidad diversa en edades y trayectorias, fortaleciendo la convivencia y el aprendizaje mutuo entre generaciones.
8.   **Cultura del cuidado:** promover la corresponsabilidad de estudiantes, profesores, graduados, directivos y colaboradores en la creación de ambientes seguros, sostenibles y propicios para el desarrollo humano y académico.
9.   **Deporte como eje de bienestar y formación integral:** consolidar una estrategia deportiva que, además de cuidar la salud física y mental, potencie habilidades como el liderazgo, la disciplina y el trabajo en equipo. El deporte en EAFIT se concibe como parte esencial de la vida universitaria, que fomenta la inclusión, la identidad y la convivencia; y fortalece el orgullo eafitense y el sentido de pertenencia.

EAFIT global

##### EAFIT global

Este itinerario entiende la internacionalización como un proceso que conecta a EAFIT con el mundo, no solo a través de la movilidad académica, sino mediante la construcción de redes de conocimiento, cooperación institucional y una cultura que acoge e integra estudiantes y profesores de diferentes países. Implica que cada integrante de la comunidad eafitense se reconozca como un ciudadano global en un entorno global, diverso e interconectado, con acceso a experiencias, programas y proyectos de alcance internacional.

La internacionalización se concibe en cinco dimensiones complementarias:

**Acad****émica:** programas conjuntos, dobles titulaciones, movilidad presencial y virtual, formación en idiomas y currículos con perspectiva global.

**Investigaci****ón y creación:** redes internacionales de colaboración, proyectos conjuntos, ciencia abierta y circulación global del conocimiento.

**Ciudadan****ía global:** sentido de pertenencia a una comunidad y una humanidad común, intercultural y diversa, y la responsabilidad de contribuir positiva y proactivamente a su construcción con criterio ético.

**Cultura de acogida y acompa****ñamiento:** servicios de asesoría y orientación que permiten la adaptación e integración de estudiantes y profesores internacionales, incluyendo trámites, bienestar y programas de “embajadores EAFIT” para quienes llegan o viajan.

**Gesti****ón institucional y sostenibilidad:** estructuras y recursos que aseguren la consolidación de la internacionalización como proceso estratégico de largo plazo.

##### Horizonte

Consolidar a EAFIT como una **universidad global**, reconocida por su capacidad de conectar estudiantes, profesores y organizaciones con redes internacionales de conocimiento, cooperación y aprendizaje. Al mismo tiempo, ser referente regional en hospitalidad universitaria e interculturalidad, cultivando una **mentalidad global**en toda la comunidad académica y formando ciudadanos con visión internacional y compromiso local.

##### Tipos de retos estratégicos

1.   **Movilidad y experiencias internacionales:**ampliar la movilidad presencial y virtual, con becas, convenios y programas que permitan experiencias académicas globales a más estudiantes, profesores y colaboradores.
2.   **Currículo internacionalizado:**integrar la perspectiva global en todos los programas, con asignaturas en inglés, dobles titulaciones, microcredenciales internacionales y experiencias en línea.
3.   **Atracción de talento internacional:** consolidar a EAFIT como destino académico y de ciencia, tecnología e innovación para estudiantes, profesores y científicos de otros países, con un campus hospitalario y servicios de apoyo.
4.   **Redes y cooperación internacional:**fortalecer la participación en redes globales de universidades, centros de investigación, organizaciones y empresas, con proyectos de impacto compartido.
5.   **Ciudadanía global e interculturalidad:**consolidar en estudiantes y en toda la comunidad eafitense la capacidad de pensar, aprender y actuar desde una perspectiva global, abierta y diversa, que valore la interculturalidad y conecte lo local con lo internacional, con ética, responsabilidad y pensamiento crítico.
6.   **Diplomacia académica:**posicionar a EAFIT como actor reconocido en la construcción de agendas internacionales de educación, ciencia, tecnología y cultura.
7.   **Acompañamiento y hospitalidad:**ofrecer programas de orientación, salud mental, apoyo en trámites y redes de apoyo entre pares, garantizando experiencias internacionales seguras y enriquecedoras.
8.   **Visibilidad y acceso a oportunidades:**fortalecer la comunicación institucional para que toda la comunidad conozca y acceda a las múltiples oportunidades de internacionalización.
9.   **Sostenibilidad institucional:**consolidar la estructura organizacional, los sistemas de información, la gestión de alianzas y la financiación de largo plazo que permitan que la internacionalización sea un proceso continuo y estratégico.

Cultura, creación y encuentro

##### Cultura, creación y encuentro

EAFIT reconoce la **cultura** como dimensión fundamental de la vida universitaria y como parte constitutiva de su **identidad**. En ella convergen la creación, las artes, la memoria, la diversidad de expresiones humanas y la construcción de comunidad. En EAFIT, la cultura no es un complemento, sino un **lenguaje de conocimiento y transformación**, que permite cultivar la sensibilidad, la imaginación, la creatividad y el sentido de lo común.

Entre sus bases sustanciales se destacan la **música, la literatura y las artes mediales,** expresiones esenciales de la vida cultural universitaria que han proyectado a EAFIT en la región y el país, y que hoy se amplían hacia las artes, las humanidades digitales y la diversidad de formas contemporáneas de creación.

Se entiende la cultura como un **espacio de encuentro:**

**Formativo,** porque ampl ía la formación académica con experiencias estéticas, creativas y digitales.

**Comunitario,** porque teje v ínculos de identidad, pertenencia y pluralidad en el campus.

**Territorial y global,** porque dialoga con expresiones locales y universales, fortaleciendo a EAFIT como actor cultural en Medell ín, Antioquia y el mundo.

##### Horizonte

Afianzar a EAFIT como **universidad cultural y creativa**, que integra las artes, la música, la literatura, la memoria, la creación, la diversidad y las **humanidades digitales**en su proyecto educativo y social, fortaleciendo la comunidad universitaria y su proyección como referente cultural en la región y el mundo.

##### Tipos de retos estratégicos

1.   **Cultura como lenguaje de conocimiento:**reconocer las artes, la música, la literatura, las humanidades y la cultura digital como formas de conocimiento que aportan a la formación integral y al pensamiento crítico.
2.   **Diversidad y pluralidad cultural:** fortalecer la inclusión de diversas tradiciones, géneros, identidades y expresiones en la vida universitaria.
3.   **Memoria y patrimonio:** conservar, narrar y proyectar la memoria institucional y cultural de EAFIT, en diálogo con la memoria de Medellín y del país.
4.   **Campus como epicentro cultural de la ciudad y el país:**consolidar el campus como escenario de encuentro cultural y artístico, con programación permanente, asequible y de alta calidad.
5.   **Participación y comunidad:** promover la participación activa de estudiantes, profesores, graduados y colaboradores en proyectos culturales, creativos y colectivos.
6.   **Ecosistema cultural y creativo regional:**fortalecer alianzas con instituciones culturales, artísticas y educativas de la ciudad y del país, posicionando a EAFIT como referente de innovación cultural y digital.

Compromiso con el planeta

##### Compromiso con el planeta

Este itinerario reconoce la responsabilidad de EAFIT con el **cuidado de la biodiversidad**, la **acci****ón climática y la transición energética,** como parte de un compromiso ético con las generaciones presentes y futuras. Esta dimensión de la sostenibilidad se entiende como un **pacto intra e intergeneracional** que orienta el aprendizaje, la investigación, la creación y la gestión universitaria hacia modelos de vida más sostenibles (más equitativos, más circulares y regenerativos, y menos extractivos).

El **Plan Maestro EAFIT Parque** es la herramienta que permite materializar esta visión, transformando el campus en un laboratorio vivo coherente con el principio de actuación sostenible.

##### Horizonte

Consolidar a EAFIT como **universidad sostenible y comprometida con el planeta**, referente en el cuidado de la biodiversidad, la transición energética, la acción climática y la cultura ambiental, con un campus coherente con su discurso, una formación transversal en sostenibilidad y una comunidad universitaria que practique y proyecte hábitos responsables y regenerativos. Desde esta visión, la Universidad promueve un uso democrático y equitativo del territorio, donde la sostenibilidad ambiental se enlaza con el respeto por las comunidades.

##### Tipos de retos estratégicos

1.   **Educación para el Desarrollo Sostenible (EDS):** formar a la comunidad de profesores en sostenibilidad y EDS, e integrar de manera transversal la ética ambiental, la transición energética y la cultura del cuidado en los programas académicos de pregrado y posgrado.
2.   **Campus sostenible y carbono neutro:**implementar el Plan Maestro EAFIT Parque para avanzar hacia un campus carbono cero con acciones medibles en infraestructura, energía, movilidad, agua y biodiversidad.
3.   **Espacios de sostenibilidad comunitaria:** transformar áreas del campus en huertas, jardines, y espacios de encuentro y aprendizaje que integren a estudiantes y colaboradores en prácticas de cuidado compartido.
4.   **Consumo responsable y coherente:**reducir plásticos y desechables, fortalecer el reciclaje, promover economías circulares y un modelo de consumo no extractivo.
5.   **Investigación y creación para la transición:** impulsar proyectos interdisciplinarios en energía limpia, conservación ambiental, cambio climático y biodiversidad.
6.   **Ecosistema regional de sostenibilidad:** liderar alianzas con gobiernos, organizaciones y comunidades en proyectos de impacto territorial en transición energética, conservación y adaptación climática.
7.   **Territorio justo y sostenible:** promover prácticas académicas, investigativas y de gestión que aseguren un uso democrático y equitativo del territorio, integrando sostenibilidad ambiental, justicia social y participación comunitaria.
8.   **Cultura universitaria del cuidado:** promover hábitos cotidianos sostenibles en toda la comunidad universitaria (movilidad, alimentación, consumo).
9.   **Proyección internacional:**participar activamente en redes globales de universidades sostenibles y en las agendas internacionales de acción climática.

Sostenibilidad institucional con visión y confianza

##### Sostenibilidad institucional con visión y confianza

La sostenibilidad de EAFIT no se limita a lo ambiental: requiere un **modelo integral de solidez acad****émica, financiera, tecnológica y de gobierno** que garantice la vigencia y el cumplimiento de su propósito superior en el tiempo. Este itinerario convoca a fortalecer la Universidad desde adentro: asegurar su base financiera, consolidar la filantropía como motor de inclusión, desplegar una transformación digital ética y efectiva, y contar con un sistema de políticas y de gobernanza participativa que acompañe los cambios del entorno.

La sostenibilidad institucional implica también cultivar una **cultura organizacional de confianza, innovación y pertenencia.**

##### Horizonte

Consolidar a EAFIT como una **universidad sostenible, confiable y visionaria**, con un modelo financiero diversificado, un sistema de filantropía sólido, una infraestructura digital y tecnológica avanzada, un gobierno participativo y transparente, y una cultura académica y organizacional que garantice la excelencia y la pertinencia a lo largo del tiempo.

##### Tipos de retos estratégicos

1.   **Modelo financiero sostenible:**diversificar fuentes de ingreso (educación avanzada y continua, transferencia tecnológica, consultoría, coinversión, endowment), y garantizar que al menos el 50% de los estudiantes cuente con becas o apoyos económicos.
2.   **Filantropía e inversión de impacto:** consolidar el sistema de filantropía y el fondo patrimonial como pilares para financiar becas, investigación, sostenibilidad y proyectos estratégicos.
3.   **Crédito:**fortalecer los programas orientados a la financiación de la matrícula universitaria de tal suerte que potencien la disminución de las barreras de acceso a la educación universitaria.
4.   **Transformación digital y gestión con datos:** implementar un plan integral de tecnología que supere las limitaciones actuales, con una arquitectura digital unificada, campus inteligente y uso ético de la inteligencia artificial y la analítica institucional.
5.   **Gobernanza participativa y transparente:** fortalecer un modelo de dirección colegiado con mayor participación de estudiantes, profesores y graduados, procesos claros de rendición de cuentas y confianza en las decisiones estratégicas.
6.   **Sistema de políticas institucionales:** simplificar, actualizar y consolidar políticas universitarias (docencia, investigación, internacionalización, sostenibilidad, cultura, inclusión), como marco habilitador de los itinerarios.
7.   **Sistema de evaluación de impacto:**implementar un modelo integral para medir y visibilizar los efectos académicos, sociales, económicos, culturales y ambientales de la Universidad, fortaleciendo la toma de decisiones y la rendición de cuentas.
8.   **Sostenibilidad académica:**asegurar la calidad y la pertinencia de los programas, con innovación curricular permanente y atención a las demandas sociales y del mercado laboral.
9.   **Acreditación y calidad:**mantener y fortalecer acreditaciones nacionales e internacionales, con procesos de autoevaluación continua como garantía de excelencia.
10.   **Cultura institucional y pertenencia:** promover confianza, corresponsabilidad, reconocimiento al talento y orgullo eafitense como base de la sostenibilidad organizacional.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate