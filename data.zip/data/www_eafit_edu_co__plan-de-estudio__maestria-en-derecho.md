# Master of Laws - EAFIT University

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

Discover your profile at EAFIT

Are you a student, professor, graduate, or part of an organization? Explore the options and find the personalized information EAFIT has for you. Click on your profile and access resources, news, and events designed especially for you. Your EAFIT experience starts here!

**Your EAFIT experience starts here!**

Students and graduates

Employees

Teachers

Children and young people

Organizations

Close profiles

Information for you

*   That's EAFIT

Return

*   Study at EAFIT

Return

*   Science, Technology and Innovation

Return

*   Connecting with organizations

Return

*   Internationalization

Return

*   Culture and Wellbeing

Return

*   News

Return

###### **Let's transform together**

Let's make it possible for more young people to access university.

Close Menu

Accessibility

More information Activate contrast Decrease font size Standard font size Increase font size Enable or disable audio for users with visual impairments

Language

Powered by [![Image 19: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Look for 

Search

Menu

# Master of Laws Curriculum

*    Study Plan 
*    Master of Laws 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Classification of subjects

Filters

Semesters

1 

2 

3 

4 

Cores, cycles, trajectories and emphasis

- [x] Program curriculum 

Cantidad de créditos: 

Semester 1

Total credits 12

Credits 3

#### Legal Theories I

Code: DE1004

Plan de estudios del programa
## Teorías Jurídicas I

3 Créditos

3 UMES

Código: **DE1004**

Credits 3

#### In-depth study 1

Code:

Plan de estudios del programa
## ​Profundización 1

3 Créditos

UMES

Código: 

Credits 3

#### In-depth study 2

Code:

Plan de estudios del programa
## ​Profundización 2

3 Créditos

UMES

Código: 

Credits 3

#### Elective 1

Code:

Plan de estudios del programa
## Electiva 1

3 Créditos

UMES

Código: 

Semestres

1 

2 

3 

4 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

### **Lines of emphasis**

###### **​​Materias de profundización**

**Debates actuales y teoría del Estado**

1.   Identifica la problemática del concepto tradicional de Estado en el entorno de la globalización y la gobernanza global contemporánea. Esto para examinar las nuevas formas de regulación para – Estatal o a – estatal.
2.   Analiza críticamente algunos debates teóricos sobre el Estado, la administración pública y el diseño e implementación de políticas públicas.

**Derechos Humanos**

1.   Explica la conformación de un sistema internacional de protección de los Derechos Humanos como un elemento de legitimidad del mismo.
2.   Comprende la interacción de los sistemas de la protección en el conflicto, de la justicia internacional penal, de la transición y de la protección internacional de Derechos.
3.   Opera las distintas categorías de Derechos y explicarlas desde su devenir histórico y social.
4.   Analiza y actuar ante los distintos órganos del sistema internacional de protección de Derechos.​

**Derecho Internacional Humanitario**

1.   Comprende el campo de aplicación de la regulación del conflicto armado.
2.   Analiza el alcance de las normas internacionales sobre los conflictos armados en el marco de los conflictos armados no internacionales.
3.   Identifica la regulación del conflicto armado en el marco de procesos transicionales.
4.   Comprende y analiza el diseño e implementación de modelos transicionales.

**Perspectivas críticas del Derecho Internacional**

1.   Explora el desarrollo histórico y geográfico del Derecho internacional y del sistema internacional • Comprende las asimetrías del sistema internacional y la multidimensionalidad de las normas internacionales.
2.   Identifica las perspectivas de análisis crítico y postcolonial del Derecho internacional.
3.   Analiza las instituciones internacionales desde una perspectiva pluralista.

###### **Materias de profundización**

**Derecho Internacional Económico**

1.   Comprende los procesos de globalización y su impacto en el Estado, la economía y el Derecho.
2.   Analiza el funcionamiento de la financiación para el desarrollo y su diseño desde las agencias multilaterales.
3.   Examina y opera el sistema multilateral de comercio internacional.
4.   Opera los mecanismos internacionales de protección a la inversión y la defensa del Estado en los procesos de arbitraje internacional de inversiones.

**Derecho contractual**

1.   Conoce el origen histórico y justificación filosófica de las principales normas que regulan los contratos en Colombia
2.   Comprende la serie de políticas públicas que subyacen al derecho contractual como una regulación de los mercados de intercambio de bienes y servicios
3.   Analiza la forma en la que las disputas contractuales dan origen a conflictos entre los diferentes principios que regulan los contratos

**Problemas actuales de derecho laboral**

1.   Conoce y aplica las normas laborales y está en capacidad de analizar y evaluar su aplicación en problemáticas laborales particulares.
2.   Comprende las políticas públicas y privadas que hacen parte de las relaciones obrero patronales
3.   Identifica y problematiza las relaciones entre empleadores, trabajadores y estado y las diferentes formas de prestación de servicios.

**Problemas actuales de derecho económico y societario**

1.   Analiza y propone solución a los problemas relacionados con ​​el contrato social, los mecanismos para tomar decisiones y proteger la voluntad social, los órganos de administración y la responsabilidad de los socios y accionistas, y la persona jurídica y los administradores.
2.   Comprende el papel de las sociedades comerciales en el desarrollo económico y de los mercados.
3.   Analiza a profundidad los cambios se han implementado en el derecho societario, tanto desde nuevas leyes y decretos (como la Ley 1258 de 2008, la Ley 1429 de 2010, la Ley 2069 de 2021 y los decretos del estado de emergencia), como desde la doctrina, y la implicación de estos cambios para el desarrollo del sector empresarial.​

###### **Materias de profundización**

**Responsabilidad civil, imputación y sujetos**

1.   Discierne el concepto de responsabilidad civil, sus fundamentos y elementos estructurales.
2.   Ubica la responsabilidad civil como un mecanismo, entre otros, para tratar los daños que se causan en la sociedad.Identifica los diferentes sujetos que intervienen en la relación jurídica de responsabilidad.

**La responsabilidad civil contractual**

1.   Analiza cada uno de los presupuestos y efectos jurídicos de la responsabilidad civil contractual.
2.   Identifica el campo de aplicación de la responsabilidad civil contractual.
3.   Analiza con cada uno de los presupuestos de fondo para que sea procedente el remedio de la responsabilidad contractual.

**La causalidad y el daño como elementos de la responsabilidad civil**

1.   Identifica la causalidad y el daño como presupuestos de la responsabilidad civil, analizando las diferentes problemáticas prácticas asociadas a cada elemento.
2.   Analiza las diferentes problemáticas asociadas al nexo de causalidad. Profundiza las nociones de daño y perjuicio.

**La responsabilidad civil extracontractual**

1.   Reconoce el régimen legal para los diferentes hechos generadores de responsabilidad civil extracontractual.
2.   Examina el régimen legal y las tendencias jurisprudenciales y doctrinarias para cada uno de los hechos generadores de responsabilidad civil extracontractual.​

###### **Materias de profundización**

**Derecho Público y Orgánica del Estado**

Analiza críticamente las formas contemporáneas de ejercicio de la función administrativa, los controles a los servidores públicos y la distribución orgánica del poder ejecutivo a partir de la técnica de la descentralización por servicios.

**Políticas Públicas y Derechos**

1.   Entiende, analiza y cuestiona el rol que la justicia constitucional ha jugado en casos específicos de políticas públicas en materia de derechos sociales de acuerdo con el diseño institucional establecido en Colombia.
2.   Comprende el origen y justificación de las Sentencias Estructurales en el caso colombiano y revisa críticamente la transformación del rol del juez constitucional con la expedición de este tipo de fallos.
3.   Identifica el marco institucional de la intervención del juez constitucional en la protección del derecho a la salud y los derechos de la población desplazada.​

**Debates Actuales y Teoría del Estado**

1.   Identifica la problemática del concepto tradicional de Estado en el entorno de la globalización y la gobernanza global contemporánea. Esto para examinar las nuevas formas de regulación para – Estatal o a – estatal.
2.   Analiza críticamente algunos debates teóricos sobre el Estado, la administración pública y el diseño e implementación de políticas públicas.

**Problemas contemporáneos del derecho administrativo**

1.   Conoce el estatuto epistemológico y metodológico del Derecho Administrativo como herramienta que permite su estudio, interpretación y aplicación.
2.   Identifica las principales instituciones del Derecho Administrativo, tanto a nivel local, como en el Derecho comparado.

Comprende el sistema de fuentes formales del Derecho Administrativo desde una perspectiva sistemática e integradora.
3.   Problematiza el impacto de la globalización en la huida o vigencia del Derecho Público.
4.   Identifica los problemas contemporáneos del Derecho Administrativo, con una perspectiva crítica e interdisciplinaria.

> La familia es la primera institución social, que concilia las exigencias de la naturaleza con los imperativos de la razón social, ya que es la comunidad entera la que se beneficia de las virtudes que se cultivan y afirman en el interior de la célula familiar y es también la que sufre grave daño a raíz de los vicios y desórdenes que allí tengan origen.

**(Corte Constitucional SC- 577 de 2011 y ST- 278 de 1994).**

###### **Materias de profundización**

**La familia contemporánea: modelos y nuevos paradigmas familiares**

1.   Comprende los modelos y nuevos paradigmas familiares desde visiones jurídicas y otras propias de las ciencias sociales y humanas
2.   Identifica las tipologías familiares reconocidas en la legislación, la jurisprudencia y la doctrina nacionales, con ánimo de explorar los criterios y el campo de acción que las mismas tienen en los nuevos paradigmas familiares impuestos en la sociedad​.

**Derecho, familia, género y sexualidad**

1.   Establece la relación de dependencia que existe entre la familia, el género, la sexualidad y el Derecho, desde una perspectiva teórico-crítica apoyada en los desarrollos científico-analíticos que proveen las ciencias sociales y jurídicas en los tiempos actuales.
2.   ​​ Hace uso preciso, técnico y adecuado de las diferentes categorías involucradas en los estudios y desarrollos teóricos de la familia, la sexualidad humana, y el género, complementados con el reconocimiento que hace la doctrina nacional e internacional especializadas y la regulación jurídica que los adopta dentro de la normativa constitucional, legal y jurisprudencial correspondientes. Armoniza los conocimientos teóricos que tiene en el derecho de familia, y los que obtiene en los estudios de maestría con la respectiva aplicación práctica en la solución de los casos concretos que debe resolver en el ejercicio profesional (litigio, judicatura, asesorías, academia, etc.)

**Políticas públicas en familia y género**

1.   Conoce algunas políticas públicas en familia y género en Colombia, con miras a determinar la existencia, validez y operancia de las mismas en el mundo jurídico.
2.   Expresa conceptos en torno al tema de las políticas públicas en familia y género en Colombia.
3.   Resuelve problemas que se planteen, con relación a las políticas públicas en familia y género en Colombia.​

**Relaciones económicas en la familia y su régimen tributario**

1.   Analiza los mecanismos jurídicos de protección en las variadas situaciones de vulnerabilidad de sus derechos y en los contextos de desprotección en los que está inmersa la familia en los aspectos económicos.
2.   Desarrolla una visión integral y sistémica de las relaciones económicas en la familia, y de las conexiones teóricas y prácticas existentes entre los diferentes sub regímenes​ económicos familiares, que integran todos ellos un régimen económico de la familia en Colombia, como uno de los aspectos esenciales que impactan la conformación, la estabilidad y la supervivencia del grupo familiar.

**Generalidades del Énfasis**​

El énfasis en Derecho de Familia tiene como objeto principal de estudio a la familia en Colombia con una perspectiva jurídico-normativa y también socio-jurídica. Además, se propende por un diálogo con otras disciplinas sociales que permitan un saber integrado y un lenguaje colaborativo en torno a ese núcleo esencial y básico de la sociedad.

**¿De qué se trata el énfasis?**

Del estudio de las principales figuras jurídicas que trata el Derecho de familia y otros discursos afines, entre ellas, los modelos o tipologías familiares; las relaciones entre padres e hijos; las relaciones conyugales, maritales y otras convivencias; las políticas públicas en familia (sobre niñez, adolescencia, adultos mayores, minorías raciales, población LGBTIQ+); el régimen económico de la familia; el Derecho de la infancia y la adolescencia; y, el Derecho notarial aplicado al Derecho de familia.

**¿Cuál sería el campo de acción de sus egresados?**

Los egresados pueden desempeñarse laboralmente en el ejercicio liberal de la profesión jurídica en asuntos del Derecho de familia; en asesorías y acompañamiento para la solución jurídica de las crisis familiares; en el ejercicio de la judicatura y de la función pública aplicada al Derecho de familia (Juzgados de Familia, Comisarías de familia, Instituto Colombiano de Bienestar Familiar, Secretarías de la mujer, Secretarías de equidad y género, entre otras entidades públicas); en entidades privadas vinculadas a la protección de la familia; en investigación; en docencia; en conciliación y mediación en asuntos de familia, etc.

​​​

**​​​**

**¿A qué perfil va dirigido el énfasis?**

A los abogados litigantes, jueces de familia, empleados de los juzgados de familia, comisarios de familia, defensores de familia, funcionarios públicos y privados, docentes, investigadores.

**¿Hay énfasis similares en Colombia? De ser así, ¿cuál es nuestro diferenciador con los demás?**

Los temas objeto de estudio del énfasis en Derecho de familia - agrupados en las relaciones familiares y los modelos de familia, en políticas públicas de familia, y en Derecho, género y sexualidad diversa- son un sello diferenciador que le da un valor agregado al egresado eafitense que desde un tratamiento discursivo, analítico, crítico y propositivo de las realidades familiares contemporáneas propone soluciones en las que integra elementos de cada uno de los ejes temáticos señalados.

**¿Cómo complementa este énfasisel desarrollo profesional a un abogado? ​**

El egresado con énfasis en Derecho de familia de la Universidad EAFIT obtiene insumos jurídicos e investigativos, suficiencia teórica y argumentativa con rigor académico y sensibilidad social, necesarios para asumir los asuntos propios de las nuevas realidades familiares, las relaciones jurídicas y las dinámicas que ellas generan, con una visión interdisciplinaria, sistémica e integradora a la luz del Derecho de familia y de sus fuentes (ley, jurisprudencia y doctrina especializada) que lo habilitan en las competencias requeridas para proponer soluciones efectivas en cada caso.

Study at EAFIT

Connect with EAFIT

Contact us

Legal information

University with Institutional Accreditation until 2026. 

Supervised by the Ministry of Education.

Our headquarters

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National hotline: 01 8000 515 900

Customer service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Customer service line: (57) 606 3214115, 606 3214119

Email: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 office 401

Customer service line: (57) 601 6114618

Email: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks

Original text

Rate this translation

Your feedback will be used to help improve Google Translate