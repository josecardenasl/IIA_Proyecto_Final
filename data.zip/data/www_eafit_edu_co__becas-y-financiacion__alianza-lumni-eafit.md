# Alianza Lumni – EAFIT - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Alianza Lumni – EAFIT

Financia hasta el 80% de tu matrícula con un esquema de pago durante tus estudios y posterior a tu graduación, bajo condiciones contractuales definidas.

*    Alianza Lumni – EAFIT 

La Alianza Lumni es un programa de financiación administrado por Lumni, dirigido a estudiantes admitidos o activos en programas definidos en EAFIT que requieran apoyo para costear su matrícula. Permite financiar hasta el 80% del valor de la matrícula semestral, de acuerdo con la evaluación realizada por Lumni y las condiciones contractuales del programa.

Es un modelo de financiación a largo plazo administrado directamente por Lumni.

**Aplica para:**

*   Estudiantes admitidos a primer semestre.
*   Estudiantes que actualmente estén cursando en programas definidos en el convenio.

La aprobación, el porcentaje final de financiación y las condiciones específicas dependen de la evaluación realizada por Lumni.

**Durante la época de estudios:**

*   Cuotas mensuales de cultura de pago entre $100.000 COP y $200.000 COP.
*   Pago directo a la Universidad del 20% del valor de la matrícula cada semestre.

**Durante la época laboral:**

*   Cuota mensual basada en un porcentaje del salario.
*   El porcentaje máximo será del 20% del salario.
*   El número de meses se define según el monto financiado y queda pactado contractualmente desde el inicio.

**En caso de no contar con ingreso laboral:**

*   El estudiante continúa pagando la cuota de cultura de pago hasta su nueva vinculación.

**Costo máximo de la financiación:**14% efectivo anual (E.A.), definido contractualmente desde el inicio del proceso.

*   Estar admitido(a) o estar cursando en un programa habilitado.
*   Contar con el 20% de la matrícula para pago directo a la Universidad cada semestre.
*   Sustentar necesidad económica (ingresos familiares menores a 4 SMMLV).
*   No contar con reporte negativo en centrales de riesgo.
*   Presentar un Responsable Solidario que firmará contrato y pagaré junto con el estudiante.

1.   Talleres virtuales para fortalecer competencias blandas.
2.   Programa de Mentorías en últimos semestres.
3.   Periodo de gracia de 6 meses luego de finalizar estudios.
4.   Periodo de desempleo de hasta 6 meses.

La financiación aplica para programas específicos definidos en el convenio y cuenta con cupos limitados por convocatoria.

##### ¿Tienes preguntas? C​ontáctanos

###### Líneas de atención:

**Lumni – Convocatorias**

**Correo:**[convocatorias@lumni.net](mailto:convocatorias@lumni.net)

**WhatsApp:** (+57) 3113090341 **opción 1**

**Teléfono:** +57 601 552 3416 **opción 1**

**EAFIT – Segmento Colegios y Jóvenes**

**WhatsApp:** +57 321 642 0341

**Correo:**[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Becas y financiación 

¿Deseas recibir más información?

Diligencia​ el siguiente formulario y uno de nuestros asesores te estará contactando.

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Becas y financiación

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Celular*? 

Correo electrónico*? 

¿Qué relación tienes con la Universidad EAFIT?*? 

Posgrado*? 

Pregrado*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

## Utilizamos cookies en este sitio web para mejorar su experiencia de usuario.

Al hacer click en Aceptar, otorga su consentimiento para que establezcamos cookies. [Conoce la política de datos personales](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Aceptar No, gracias