*    Track Test 4 Competencias Presencial 

## Información general

Descripción del examen

En el caso del examen Track Test, que corresponde a una prueba de certificación por nivel, es el propio candidato quien selecciona el nivel que desea certificar: A1, A2, B1, B2, C1 o C2. El contenido de la prueba se ajusta exclusivamente al nivel escogido, por lo que la evaluación no contempla niveles inferiores ni superiores. Para obtener la certificación, el candidato debe alcanzar el puntaje mínimo exigido para ese nivel. En caso de no lograrlo, no se otorga certificación alguna, y el resultado no puede interpretarse como correspondiente a un nivel inferior, ya que dicho nivel no fue evaluado. De igual manera, aunque se obtenga la puntuación máxima, el resultado no reflejará un nivel superior, ya que este no hizo parte de la prueba realizada.

El examen Track Test 4 competencias certificará su nivel de inglés dentro de los niveles del **Marco Común Europeo de Referencia** en las cuatro competencias lingüísticas. Estas certificaciones están contempladas dentro de la política de lengua extranjera de la Universidad EAFIT.

Proceso de inscripción

1.   Ingrese a [https://app.eafit.edu.co/recaudos/](https://app.eafit.edu.co/recaudos/) ​con su cédula y seleccione el **“TRACK TEST 4 COMPETENCIAS PRESENCIAL"**.
2.   El pago lo puede realizar en línea haciendo clic en el botón **PAGAR**. También puede generar una liquidación con la que podrá pagar en cualquier **Bancolombia**. Para esto, debe hacer clic en el botón **GENERAR** y luego en **IMPRIMIR LIQUIDACIÓN**.
3.   Recuerde que el pago lo debe hacer **el mismo día** que hace la inscripción de tal forma que se le asegure el cupo para tomar el examen.
4.   Una vez realizado el pago, envíe una foto de este comprobante, el nivel que desea aprobar y su documento de identidad escaneado al correo [testingcenter@eafit.edu.co](mailto:testingcenter@eafit.edu.co)
5.   Al solicitar la prueba se aceptan los términos y condiciones de la misma, [consúltalos aquí.](https://universidadeafit.widen.net/s/tfv6wmrv8m/tract-test--4-competencias-presencial-04-10-2025)

Estructura

La prueba de 4 competencias, cuya duración es de 1 ½ hora, evalúa los componentes de gramática, escritura, comprensión lectora, escucha y conversación.

Especificaciones

## 1.

​La repetición de la prueba Track Test solo estará habilitada hasta 6 meses después de presentada por primera vez y debe ser por el mismo nivel ya hecho.

Para repetir su examen Track Test debe esperar mínimo 8 días calendario después de haberlo presentado por primera vez y debe ser el mismo nivel que ya presentó, en caso de cambiar de nivel no sería repetición, sería cambio de nivel, tenga en cuenta que debe repetir todas las competencias. Para presentarlo debe cancelar los derechos de repetición, los cuales tienen un valor de $165.000.​

## 2.

En caso de que se anule la prueba no habrá lugar a devoluciones bajo ninguna circunstancia. Solo podrá repetir la prueba seis meses de realizada por primera vez y cancelar al valor total de esta ($331.000).

Inversión

### Track test 4 competencias

$380.000

### Repetición

$185.000

Calendario 2026

| Fecha de examen | Hora | Fecha límite de inscripción |
| --- | --- | --- |
| Abril 28 | 2:30 p.m. | Abril 25 |
| Mayo 05 | 2:30 p.m. | Mayo 2 |
| Mayo 12 | 2:30 p.m. | Mayo 9 |
| Mayo 19 | 2:30 p.m. | Mayo 16 |
| Mayo 26 | 2:30 p.m. | Mayo 23 |

Calificación

Para aprobar el examen, es necesario obtener un **puntaje igual o superior al 65%** en el total del examen. Y que en el resultado en las competencias de speaking y writing sea de **44% mínimo en cada una**. Si tiene alguna duda le recomendamos consultar la tabla 2 de puntajes de política de lengua extranjera de la Universidad EAFIT [aquí](https://universidadeafit.widen.net/s/d6mpnwpmzw/lengua-extranjera-tabla-2-febrero-2023).​

Notificación de resultados

Los resultados estarán disponibles **10 días hábiles** después de presentado el examen, estos se enviarán por correo electrónico.

###### Preguntas frecuentes

​​​Conoce nuestros protocolos e información general sobre nuestro Testing Center.

1.   Estudiantes que desean ingresar y/o egresar en una institución de educación superior.
2.   Estudiantes en proceso de admisiones y/o egreso del programa de aprendizaje del idioma inglés.
3.   Candidatos que desean presentarse para obtención de becas y certificaciones.
4.   Alumnos de diferentes programas de aprendizaje en idiomas, que desean controlar su progreso.
5.   Estudiantes y trabajadores que solicitan visas.
6.   Empresas y/o instituciones que requieran comprobar la suficiencia en idioma durante los procesos de selección de personal, analizar y certificar el nivel de inglés de sus empleados, hacer un seguimiento de la efectividad de los programas de formación lingüística, evaluar a sus empleados con vistas a ascensos o cargos en el extranjero.​

¿Quieres o te exigen presentar un examen de nivel de inglés, pero no sabes cuál es el adecuado para ti? ¿cuál es la diferencia entre uno y otro de tantos existentes en el mercado? ¿existe algún examen que me diagnostique mi nivel antes de decidir presentar un examen oficial?

La información a continuación puede orientarte un poco y llevarte a tomar la decisión más adecuada para tus necesidades.​

​Una diferencia importante entre todos los exámenes existentes es la validez de los resultados. Dicha validez está sujeta a las políticas y reglamentos de la institución académica, empresa, embajada, etc. solicitante de la prueba. Todas las instituciones son libres de aceptar el o los exámenes que mejor se adecuen a sus reglamentos internos.

Por ejemplo, los exámenes **IELTS y TOEFL** suelen ser más convenientes para los visados, trabajos o solicitudes de admisión universitaria que tengan como requisito de aceptación la posesión de un determinado nivel de inglés.

Exámenes como el **TOEIC, APTIS, TRACK TEST y Oxford Test of English​**son exámenes de inglés cuya novedad es la flexibilidad que aporta al poder evaluar de forma independiente una, dos, tres o todas las competencias del idioma. Estos exámenes son altamente aceptados en las universidades de Colombia.​

Ten en cuenta que cada examen tiene un proceso de inscripción diferente ,el cual varía dependiendo de la casa matriz del mismo.

Los tiempos de entrega también varían dependiendo de las políticas internas del ente oficial del examen. Ten presente el tiempo para tu examen de preferencia.

APTIS

CELPE-BRAS

DELE

IELTS

OTE

PLIDA

TOEFL

TOEIC

TRACK TEST 4 COMPETENCIAS

TRACK TEST COMPRENSIÓN LECTORA

5 días hábiles

4 meses

4 meses

7 días hábiles

15 días hábiles

4 meses

7 días hábiles

15 días hábiles

8 días hábiles

8 días hábiles

| Examen | Valor |
| --- | --- |
| Track Test 4 Competencias presencial | $ 380.000 |
| Track Test 4 Competencias virtual | $ 430.000 |
| Track Test Comprensión Lectora | $ 275.000 |
| Repetición Track Test presencial | $ 185.000 |
| Repetición Track Test virtual | $ 233.000 |
| Aptis for Teachers | $ 412.500 |
| Aptis for Teachers docentes EAFIT | $ 320.000 |
| Aptis General | $ 412.500 |
| Oxford Test of English | $ 486.000 |
| Oxford Test of English una sola habilidad | $ 204.000 |
| TOEFL | $256 dólares |
| IELTS | $ 1.045.700 |
| PLIDA | $ 770.000 |
| CELPE-BRAS | $ 504.000 |

_*Ten en cuenta que estos precios pueden variar en función de tu ubicación y están sujetos a cambios._

**Valores de exámenes de otros idiomas diferentes al inglés a través de nuestra página web.**

​Días antes de presentar la prueba, te llegará un correo electrónico con la citación oficial al examen y las instrucciones que debes seguir para presentarlo.

Para todos, siempre deberás presentar tu documento de identidad ORIGINAL.

Dependiendo si tu examen es a lápiz o a computador deberás traer implementos tales como: lápiz mina # 2, borrador, sacapuntas, lapicero negro.​

**Acceso peatonal:** por la portería de Argos, Las Vegas e Idiomas.​

**Acceso vehicular:** p la portería sur sobre la Avenida las Vegas después de Macrollantas, la del Plástico y del Caucho sobre la Av. Regional y la de Idiomas.

**Acceso de motocicletas:** por la portería sur sobre la Avenida las Vegas después de Macrollantas y la de Idiomas.

Debes tener en cuenta que el pico y placa también rige dentro de la Universidad.

**Valor parqueadero carros** $ 6.000 el día

**Valor parqueadero motos** $ 3.000 el día​

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500