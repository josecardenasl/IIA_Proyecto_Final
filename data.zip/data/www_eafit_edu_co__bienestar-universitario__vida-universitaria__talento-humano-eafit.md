# Talento humano EAFIT - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Talento humano EAFIT

Descubre los beneficios y programas que EAFIT ofrece a sus empleados para su desarrollo laboral, personal y profesional. Conoce más sobre Talento Humano EAFIT.

*    Talento Humano EAFIT 

El Departamento de Talento Humano propicia las condiciones laborales, personales y profesionales para el desarrollo de estos eafitenses, a través de programas y servicios para ellos.

##### ¿Qué te ofrecemos como empleado de EAFIT?

Los siguientes son algunos de los beneficios que hacen parte de la comunidad eafitense:

Flexitrabajo

En Bici al trabajo

Ho flexible

Jornada reducida

Medias jornadas libres

Media jornada libre por el día del cumpleaños

​Consulta médica general.

Espacios para realizar actividades físicas, deportivas y de esparcimiento.

Establecimientos de comercio y servicios en las instalaciones.

Atención en primeros auxilios y servicios en atención de urgencias.

​Fondo de empleados.

Préstamos para compra de vivienda.

Deducciones de nómina.

Prima extralegal de servicios.

Reconocimiento extralegal por incapacidad.

Convenios con entidades externas.

Préstamos con entidades financieras.

Becas a nivel de educación formal y no formal para empleados y sus beneficiarios.

Becas para talleres artísticos y cursos deportivos.

​​Programas en salud y prevención de la enfermedad.

Programas de deporte, recreación y grupos de expresión artística.

Programación artística y cultural durante todo el año.

Vacaciones extralegales.

Teletrabajo.

Contacto - Talento humano EAFIT 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

DptoDlloEmpleados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Celular*? 

Correo electrónico*? 

Su comentario o solicitud*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate