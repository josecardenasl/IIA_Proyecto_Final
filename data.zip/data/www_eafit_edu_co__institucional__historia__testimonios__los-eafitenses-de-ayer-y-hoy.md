# Los eafitenses de ayer y hoy

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 5: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Los eafitenses de ayer y hoy

**​​​​​Jorge Iván Rodríguez Castaño, fundador de la Universidad y presidente del Consejo Superior, compara los primeros estudiantes de EAFIT con los actuales y resalta la importancia del reconocimiento de la Institución, de los convenios con otras universidades y del desempeño de los egresados, como garantía para quienes eligen formarse en EAFIT.**

*    Testimonios 
*    Los Eafitenses de Ayer y Hoy 

#### Historias y noticias recomendadas

###### La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

En tiempos en los que la información circula a velocidades inéditas y la inteligencia artificial transforma la manera de aprender, la figura del profesor sigue ocupando un lugar esencial. No solo por su capacidad para transmitir conocimiento, sino por algo más profundo: ayudar a interpretar el mundo, formular preguntas, acompañar procesos de transformación y construir criterio en medio de la incertidumbre.

Mayo 14, 2026

###### EAFIT logra su mejor resultado en las pruebas Saber Pro

EAFIT alcanzó en 2025 el mejor resultado de su historia reciente en las pruebas Saber Pro. La Universidad obtuvo un puntaje global de 179, seis puntos por encima de 2024 y el más alto de la serie comprendida entre 2021 y 2025. Además, se ubicó en el puesto 6 entre 274 instituciones de educación superior del país.

Mayo 13, 2026

###### Celebramos una cohorte que transforma territorios gracias a la Fundación Sura

Los retos que hoy enfrentan nuestros territorios trascienden lo técnico, y plantean nuevos desafíos relacionados con lo social, la ecología y los ecosistemas, las políticas públicas y la construcción de metodologías transdisciplinarias. Eso es lo que buscó la alianza entre la maestría en Procesos Urbanos y Ambientales de EAFIT y la Fundación Sura: generar nuevas maneras de relacionarse con los territorios y de construir estrategias colectivas para su transformación.

Mayo 12, 2026

##### Nuestros programas

_**Última actualización**_

Enero 16, 2025

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate