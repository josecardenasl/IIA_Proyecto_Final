La Universidad de los niños EAFIT es un programa de educación y comunicación de la ciencia que, desde su fundación en 2005, ha buscado contribuir a la formación de sujetos activos en la construcción de conocimiento y la transformación de la sociedad.

Para cumplir su misión, el programa desarrolla tanto actividades como contenidos que favorecen la apropiación social del conocimiento y la interlocución entre las instituciones de educación superior y públicos diferentes a los académicos. En la actualidad tiene tres frentes de trabajo: A) Rutas de formación en talleres de comunicación de la ciencia; B) Producción de contenidos de comunicación de la ciencia; C) Investigación y sistematización.

De esta manera, la Universidad de los niños EAFIT se ha posicionado como interlocutor en temas de apropiación social del conocimiento ante otras instituciones y entidades como: la Red de Popularización de la Ciencia y la Tecnología en América Latina y el Caribe; la Red Europea de Universidades de los Niños (Eucu.net); la Red de Investigación Escolar de Medellín; y la Red Interuniversitaria Buen Comienzo (para discutir políticas públicas orientadas a la primera infancia). ​

En los programas de la Universidad de los niños participan todos los niños, niñas, jóvenes y maestros, mediadores o formadores según el programa.

​Vacaciones Zoom Ciencia: (para niños y niñas entre los 3 y 10 años)

Encuentros con la Pregunta: (para niños y niñas entre los 7 y 11 años)

Retos de Ciencia (para jóvenes entre los 12 y 15 años)

Expediciones Científicas (para jóvenes entre los 16 y 18 años)

Curso Metodología Universidad de los Niños (para maestros, mediadores y formadores)

**Investigadores**

Investigadores de la Universidad EAFIT aportan los contenidos académicos que inspiran las actividades que se realizan en los talleres de Encuentros con la Pregunta, Retos de Ciencia y Expediciones Científicas, apoyan la preparación del grupo de talleristas y conversan con los niños y jóvenes del programa para compartir sus experiencias y guiarlos en la construcción de respuestas. En Expediciones Científicas, acompañan a los participantes en el desarrollo de sus trabajos de investigación. Además, asesoran y acompañan talleres externos del programa.

**Instituciones Educativos Oficiales y Privados**

Instituciones educativas oficiales y privadas de Medellín, el Área Metropolitana y municipios cercanos son invitadas a participar en los talleres de Encuentros con la pregunta. Cada institución selecciona, entre sus estudiantes, a los niños y jóvenes que participarán en el programa, y a un profesor acompañante; también asumen el compromiso de garantizar la asistencia de sus alumnos a los talleres mensuales en EAFIT. Conoce las instituciones educativas participantes.

**Estudiantes universitarios**

Un grupo de estudiantes universitarios, de distintos programas de pregrado de EAFIT, son preparados anualmente para dirigir los talleres y encuentros. Otros apoyan las actividades, como monitores, del área estratégica y de comunicaciones de la Universidad de los niños.

Puede inscribirse cualquier persona que esté dentro del rango de edad de los programas. También hijos, nietos o familiares cercanos de empleados de la Universidad EAFIT y estudiantes de las instituciones educativas oficiales y no oficiales invitadas cada año a participar en los Encuentros con la Pregunta de la Universidad de los niños.

A finales de enero se realiza una convocatoria y se programan reuniones informativas, en las que empleados universitarios e instituciones educativas solicitan cupos y conocen los requisitos para ingresar al programa.

A través del envío de una solicitud de ingreso al programa escrita por parte de las directivas de la institución educativa, y dirigida a Shirley Zuluaga, jefe del programa, al correo [uninos@eafit.edu.co](mailto:uninos@eafit.edu.co) o por correo certificado a la Carrera 49 # 7 Sur - 50. Avenida Las Vegas, Universidad EAFIT.

**Vacaciones Zoom Ciencia: (para niños y niñas entre los 3 y 10 años)**

Media jornada: $465.000

Jornada Completa: $930.000

**Encuentros con la Pregunta: (para niños y niñas entre los 7 y 11 años)**

$120.000 por taller

$457.000 tres talleres

**Retos de Ciencia (para jóvenes entre los 12 y 15 años)**

$685.000 por módulo

**Expediciones Científicas (para jóvenes entre los 16 y 18 años)**

$735.000 por módulo

**Curso Metodología Universidad de los Niños (para maestros, mediadores y formadores)**

$827.102

Encuentros con la pregunta: los niños y las niñas participan en experiencias de aprendizaje para estimular curiosidad y el asombro a partir de preguntas. Lo anterior con el acompañamiento de investigadores y con visitas a laboratorios especializados del Campus EAFIT.

Retos de Ciencia: los participantes resuelven retos basados en problemáticas actuales a partir de las diferentes áreas de la ciencia. Son 5 encuentros durante el semestre, en los cuales son guiados por investigadores y que se desarrollan en laboratorios y diferentes espacios de la universidad, incluyendo una salida de campo.

Expediciones Científicas: los participantes, durante 6 encuentros en el semestre, exploran diversas metodologías de investigación para aplicar en el desarrollo de un proyecto basado en una problemática actual. En la experiencia cuentan con el asesoramiento de investigadores y expertos, con quienes realizan además una salida de campo.

Zoom Ciencia: durante una semana los participantes experimentan un viaje basado en ciencia recreativa para estimular la curiosidad y el asombro a partir de las ciencias, el arte y el deporte. Al finalizar cada participante construye un producto que le permite dar cuenta del proceso vivido. ​

Los talleres se desarrollan a partir de la metodología del programa, basada en la pregunta, la conversación, la experimentación y el juego.

Un taller tiene diferentes momentos que aportan insumos para que el participante construya la respuesta a la pregunta del día: sesiones en grupo, aula viva y conversaciones con el investigador.

Sesiones en grupo: son vivencias de exploración sensorial, actividades teatrales y creativas, experiencias plásticas, juegos

orientados, trabajos en pequeños grupos, puestas en común y conversaciones. La intención es permitir a los niños sensibilizarse y comprender distintos aspectos del tema.

Aulas vivas: son visitas a laboratorios y espacios especializados de la Universidad EAFIT, donde se desarrollan proyectos de investigación, para realizar actividades relacionadas con la pregunta del día.

Conversaciones con el investigador: es el momento donde los niños tienen la oportunidad de relacionarse con el investigador, conocerlo, saber qué hace dentro de la Universidad, conversar acerca de conceptos relacionados con el taller, construir conclusiones y escuchar una respuesta clara y concisa a la pregunta del día.

**Proyectos externos**

En alianza con instituciones a fines a nuestra misión, el programa desarrolla proyectos dirigidos a diferentes públicos. Conozca los proyectos externos que se han realizado.

**Talleres en instituciones educativas públicas y privadas**

El programa lleva sus talleres a las instituciones educativas de la ciudad y su área metropolitana para extender a más niños y jóvenes su metodología. Conozca los talleres que se han realizado.