# Creación de nuevo conocimiento en conexión con las necesidades del entorno

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Creación de nuevo conocimiento en conexión con las necesidades del entorno

*    Creación de Nuevo Conocimiento En Conexión Con Las Necesidades del Entorno 

​​Para construir sociedad y unir saberes. Investigar para transformar, leer el entorno y brindar soluciones. Para establecer alianzas. Forjar humanidad y sociedad desde la investigación hace parte del ADN de la Universidad. Los proyectos que surgen de los 44 grupos de investigación abarcan las agendas de conocimiento que se basan en las tendencias internacionales y nacionales: industrias 4.0 y tecnologías convergentes-nano, bio, info y cogno; agrotech: transformación, mercado y producción; ciudades inteligentes; ambiente, biodiversidad y recursos naturales; estado, construcción pacífica, convivencia y posacuerdos; creación, cultura y arte; energías sostenibles; ciencias del comportamiento y cambio social. Y por supuesto en las agendas que surgen de las apuestas institucionales: ciencias del aprendizaje, estudios económicos y empresariales, y salud.

Hoy cuando es necesario fortalecer, por ejemplo, la educación virtual, investigadores del Laboratorio de Realidad Virtual y del Grupo de Investigación en Desarrollo e Innovación en Tecnologías de Información y Comunicación (Giditic), crearon aplicaciones de realidad virtual y realidad aumentada para enseñar matemáticas y física, en entornos de aprendizaje colaborativos y a distancia.

Cuando se requiere visualizar la expansión de las urbes, se avanza en un modelo que permite proyectar a futuro el crecimiento de las ciudades con una herramienta para la planificación urbana, creada desde el grupo de investigación Research in Spatial Economics (Rise). Y cuando necesitamos trabajar en equipo y cuidar el entorno, se construyen prototipos de vivienda diseñados para el consumo sostenible de energías renovables, en tres pisos térmicos de Colombia, entre investigadores de EAFIT, Universidad Nacional de Colombia, UPB, Universidad de Sucre y la empresa Convel. Los proyectos son numerosos y pertinentes, y van surgiendo de las activas mentes de los eafitenses en forma de investigaciones vivas y dinámicas.

## ​EAFIT es una de las instituciones de educación superior del país con mayor porcentaje de grupos de investigación clasificados en las máximas categorías de Colciencias: 32 de los 44 grupos, es decir, el 73 por ciento.

> Hay muchos proyectos para construir sociedad. En esencia el mensaje que puedo dar es que los modelos matemáticos, la inteligencia artificial, la asimilación de los datos en modelos matemáticos, están siendo implementados para mejorar la calidad de vida, en medicina y en el estudio de las dinámicas sociales, ciudadanas, de seguridad y defensa. Una gran premisa, y es algo que quiero popularizar, son las matemáticas centradas en el humano, un concepto en el que la matemática sirve como un catalizador de dinámicas sociales y como una inspiración para que el avance tecnológico se convierta en solución”
> 
> 
> Olga Lucía Quintero Montoya, investigadora del grupo Modelado Matemático

###### ​​Materializar la cooperación

Los proyectos de investigación están adscritos a los grupos y(o) centros de investigación de la Universidad y pueden financiarse con recursos propios, ser cofinanciados y/o cooperados. En cuanto a los proyectos cofinanciados, el principal punto, afirma Juan Carlos Muñoz-Mora, codirector del doctorado en Economía, es la posibilidad de contribuir a agendas globales de investigación que buscan el complimiento de los Objetivos de Desarrollo Sostenible. Para esto, “los proyectos cofinanciados son la materialización de la cooperación con otros investigadores e instituciones que potencian el alcance, el impacto de los resultados”.

## 3. Salud y bienestar

## 4. Educación de calidad

## 8. Trabajo decente y crecimiento ecónomico

## 9. Industria, innovación e infrraestructura

## 10. Reducción de las desigualdades

## 11. Ciudades y comunidades sostenibles

## 12. Producción y consumo responsables.

## 13. Acción por el clima.

## 15. Vidas de ecosistemas terrestres.

## 16. Paz, justicia e instituciones sólidas.

## 17. Alianzas para lograr los objetivos.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)