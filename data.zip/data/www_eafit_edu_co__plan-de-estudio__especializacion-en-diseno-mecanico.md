# Especialización en Diseño Mecánico - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 4: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

![Image 23: Pregrado en Ingeniería Mecánica, Universidad EAFIT.
Un estudiante manipula un equipo de cómputo en un laboratorio de EAFIT.](https://universidadeafit.widen.net/content/przjfb3zj5/web/pregrado-ingenieria-mecanica-2.jpg?crop=yes&k=c&w=1920&h=788&itok=rf0-wuvE)

# Plan de estudios

Especialización en Diseño Mecánico

La estructura académica de esta especialización está conformada por un primer semestre con asignaturas que ayudan a calcular, seleccionar y optimizar diferentes sistemas utilizados en líneas productivas o plantas industriales. Su segundo semestre está conformado por asignaturas que ayudan a los profesionales a obtener herramientas, estrategias o metodologías de diseño implementadas en líneas productivas.

**Las materias de esta especialización son válidas para continuar con estudios de maestría en la Universidad EAFIT.**

- El plan de estudio está conformado por doce asignaturas de dos créditos cada una. Cinco asignaturas son de formación en sistemas industriales, cinco asignaturas en metodologías de diseño y dos asignaturas de proyectos integradores.

*    Plan de Estudio 
*    Especialización En Diseño Mecánico 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas disciplinares 

Semestre 1

Créditos 

totales-

Créditos 2

#### Sistemas Hidráulicos

Código: MC6013

Asignaturas disciplinares
## Sistemas Hidráulicos

2 Créditos

2 UMES

Código: **MC6013**

Créditos 2

#### Sistemas Térmicos

Código: MC6014

Asignaturas disciplinares
## Sistemas Térmicos

2 Créditos

2 UMES

Código: **MC6014**

Créditos 2

#### Sistemas de Transporte

Código: MC6015

Asignaturas disciplinares
## Sistemas de Transporte

2 Créditos

2 UMES

Código: **MC6015**

Créditos 2

#### Sistemas Neumáticos

Código: MC6016

Asignaturas disciplinares
## Sistemas Neumáticos

2 Créditos

2 UMES

Código: **MC6016**

Créditos 2

#### Sistemas de Potencia

Código: MC6017

Asignaturas disciplinares
## Sistemas de Potencia

2 Créditos

2 UMES

Código: **MC6017**

Créditos 2

#### Proyecto Sistemas Industriales

Código: MC6018

Asignaturas disciplinares
## Proyecto Sistemas Industriales

2 Créditos

2 UMES

Código: **MC6018**

Semestres

1 

2 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas disciplinares 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate