# Portugués para adultos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Portugués para adultos

### Edad +17

Disfruta la experiencia de aprender una de las lenguas más dulces y agradables del mundo.

*    Portugués Para Adultos 

Título de la sección

### Dirigido a

mayores de 17 años

### Inversión por curso

$947.000

### Duración

36 horas por curso

## Modalidades

Información general

Aprende uno de los idiomas más hablados en el mudo y uno de los más empleados en internet. El portugués te abre puertas en el mundo laboral, te permite acceder de forma más fácil a becas. Un idioma con el que podrás viajar a 9 países y hablar su lengua oficial.

Encuentra en Idiomas EAFIT una metodología participativa con enfoque en aprendizaje experiencial, lo que te permite aprender de una forma efectiva, sin dejar la diversión de lado.

**Nota:**con el fin de ofrecer siempre cursos ajustados al verdadero ritmo de aprendizaje de nuestros estudiantes, actualizarnos y adaptarnos a las verdaderas necesidades de nuestros participantes, el programa de portugués ha sido actualizado en su malla curricular y duración. A partir de 2021 está compuesto por 9 cursos de A1 a B1. El control de política de lengua extranjera B1 para estudiantes de pregrado de EAFIT será en la finalización de curso 9.

Inversión

###### **Inversión por curso**

## Todos los cursos

$947.000

Intensivos

###### **Calendario 2025**

###### **11 cursos por año, 10 horas semanales**

**Lunes a viernes**

**​​​Sede Poblado:**6:00 a.m. a 8:00 a.m. / 9:00 a.m. a 11:00 a.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Febrero 11 | Noviembre 18 - Enero 20 |
| Febrero 16 | Marzo 11 | Enero 26 - Febrero 16 |
| Marzo 16 | Abril 16 | Febrero 23 - Marzo 16 |
| Abril 21 | Mayo 15 | Marzo 24 - Abril 21 |
| Mayo 19 | Junio 12 | Abril 27 - Mayo 19 |
| Junio 16 (vacacional) | Julio 2 | Mayo 25 - Junio 16 |
| Julio 13 | Agosto 6 | Mayo 24 - Julio 13 |
| Agosto 10 | Septiembre 3 | Julio 21 - Agosto 10 |
| Septiembre 7 | Septiembre 30 | Agosto 19 - Septiembre 7 |
| Octubre 13 | Noviembre 6 | Septiembre 15 - Octubre 13 |
| Noviembre 9 | Diciembre 3 | Octubre 14 - Noviembre 9 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos**.

***Los cursos de portugués para adultos no tienen clase durante estos días:**

Semana Santa

20 de abril

Semi intensivos

###### **Calendario 2026**

###### **6 cursos por año, 6 horas semanales**

**Lunes, miércoles y viernes**

**​​​Sede Poblado:**12:00 m a 2:00 p.m. / 2:00 p.m. a 4:00 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Febrero 27 | Noviembre 18 - Enero 19 |
| Marzo 2 | Abril 22 | Enero 26 - Marzo 2 |
| Abril 27 | Junio 12 | Marzo 9 - Abril 27 |
| Julio 13 | Agosto 28 | Mayo 25 - Julio 13 |
| Agosto 31 | Octubre 19 | Julio 21 - Agosto 31 |
| Octubre 21 | Diciembre 4 | Septiembre 7 - Octubre 21 |

**Martes y jueves**

**Sede Poblado:**2:00 p.m. a 4:00 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Febrero 26 | Noviembre 18 - Enero 20 |
| Marzo 5 | Abril 21 | Enero 26 - Marzo 5 |
| Abril 28 | Junio 4 | Marzo 9 - Abril 28 |
| Julio 14 | Agosto 20 | Mayo 25 - Julio 14 |
| Septiembre 1 | Octubre 15 | Julio 21 - Septiembre 1 |
| Octubre 27 | Diciembre 3 | Septiembre 7 - Octubre 27 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos**.

***Los cursos de portugués para adultos no tienen clase durante estos días:**

Semana Santa

20 de abril

Semana de receso escolar.

Regulares

###### **Calendario 2026**

###### **4 cursos por año, 4 horas semanales**

**Lunes y miércoles**

**​Sede Poblado:**6:30 p.m. a 8:30 p.m.

# Tabla de Fechas de Matrículas

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Marzo 18 | Noviembre 18 - Enero 19 |
| Marzo 25 | Junio 10 | Febrero 2 - Marzo 25 |
| Julio 13 | Septiembre 16 | Mayo 25 - Julio 13 |
| Septiembre 21 | Diciembre 2 | Julio 27 - Septiembre 21 |

**Martes y jueves:​**

**​Sede Poblado:**12:00 m. a 2:00 p.m. / 6:30 p.m. a 8:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Marzo 19 | Noviembre 18 - Enero 20 |
| Marzo 24 | Mayo 28 | Febrero 2 - Mayo 28 |
| Julio 14 | Septiembre 10 | Mayo 25 - Julio 14 |
| Septiembre 15 | Noviembre 19 | Julio 27 - Septiembre 15 |

**Sábado - Modalidad en línea**

**​Sede Poblado:** 8:00 a.m. a 12:00 m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 24 | Marzo 21 | Noviembre 18 - Enero 23 |
| Marzo 28 | Junio 6 | Febrero 2 - Marzo 28 |
| Julio 18 | Septiembre 19 | Mayo 25 - Julio 18 |
| Septiembre 26 | Noviembre 28 | Julio 27 - Septiembre 19 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos**.

***Los cursos de portugués para adultos no tienen clase durante estos días:**

Semana Santa

20 de abril

Semana de receso escolar.

Vacacionales​

**Lunes a viernes**

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Junio 16 | Julio 2 | Mayo 25 - Junio 16 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos**.

## ¿Por qué aprender Portugués?

Podrás adquirir mayores habilidades y competencias.

 Tendrás la posibilidad de viajar por más de 9 países y hablar su lengua.

 Tendrás oportunidades laborales y de estudio.

 Si te gusta la historia, podrás conocer una de las universidades más antiguas de Europa, la Universidad de Coimbra.

 Podrás aprender las maravillosas canciones de los géneros Fado y Bossa-nova.

 Podrás leer los textos de Luis de Camões y Fernando Pessoa en su versión original.

 Podrás maravillarte en una de las mejores islas del mundo, Madeira, y visitar la casa de Cristiano Ronaldo.

## ¿Por qué estudiar ​​​idiomas en EAFIT?

Con 30 años de experiencia en la enseñanza de idiomas, como respuesta a las exigencias mundiales, Idiomas EAFIT tiene como objetivo principal dar solución a las necesidades del entorno académico, empresarial y gubernamental.

## Portafolio corporativo

## Global Explorers

## Certifica tus conocimientos en Portugués

# Proceso de inscripción

El primer paso para inscribirte, es conocer cuál es el nivel ideal para ti. Para ello debes realizar una cita de clasificación, solicítala así:

### 1

### Ingresa

### 2

### Selecciona la edad del estudiante

Adultos + 17 años.

### 3

### Selecciona el idioma

Portugués

### 4

### En la pregunta sobre si tienes conocimiento

selecciona si o no.

### 5

### Sigue los pasos detallados en la plataforma

para programar tu cita de clasificación o realizar la inscripción según tu caso.

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

## Líneas de atención

(57) 604 2619500

## Sugerencias

## ¡Idiomas EAFIT llega a Bello!

Aprende inglés con educación de calidad y una metodología efectiva.

## Spanish program

Personalized sessions adapted to your needs

## English Stars - niños de 4 años

### Edad 4 años

Un programa para aprender inglés y fortalecer habilidades clave para el desarrollo cognitivo, social y comunicativo en la primera infancia.

## Vacacionales Happy Time

### Edad 5 a 10 años

Vacaciones en inglés para niños. Una semana perfecta para disfrutar y conocer el mundo mientras aprenden un nuevo idioma.

## Programa de inglés para niños y niñas

### Edad 4 a 11 años

Metodología participativa con resultados reales que desarrollan habilidades cognitivas y sociales.

## Programas de inglés para niños y niñas

### Edad 4 a 11 años

El programa de inglés para niños que combina el juego, la creatividad y el aprendizaje de un nuevo idioma de manera efectiva

## Inglés para jóvenes

### Edad 12 a 16 años

Conecta con el mundo y fortalece habilidades clave para tu futuro académico y profesional.

## Portugués para adultos

### Edad +17

Disfruta la experiencia de aprender una de las lenguas más dulces y agradables del mundo.

## Italiano para adultos

### Edad +17

Aprende italiano de forma divertida y expande tus horizontes con nuevos conocimientos.

## Francés para adultos

### Edad +17

Aprende una de las lenguas más fascinantes y sumérgete en una cultura artística y rica.

## Alemán para adultos

### Edad +17

Aprende con una metodología efectiva y práctica y descubre la riqueza cultural del alemán, sumérgete en su historia y tradiciones.

## Francés para jóvenes

### Edad 12 a 16 años

Domina una lengua romance fascinante y explora una cultura artística y rica.

## Alemán para Jóvenes

### Edad 12 a 16 años

Descubre la riqueza cultural del alemán y atrévete a sumergirte en su historia y tradiciones.

## Inglés virtual para adultos

### Edad +18

Vive una experiencia flexible, personalizada y con acompañamiento real

## Inglés para adultos

### Edad +17

Domina el inglés con una metodología efectiva y accede a oportunidades para crecer, viajar y destacar profesionalmente.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)