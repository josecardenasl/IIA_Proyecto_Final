# Contaduría Pública - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Pregrado

# Contaduría Pública

SNIES 1246, Medellín

Aquí aprenderás a gestionar la información de las organizaciones, que incluye aspectos contables, financieros, tributarios y estratégicos. Al graduarte como Contador Público de EAFIT, estarás en capacidad de comprender y generar valor en las organizaciones y la sociedad a través del análisis y la gestión de cifras financieras y no financieras.

El programa de Contaduría Pública de la Universidad EAFIT forma contadores con presencia internacional que acompañan y contribuyen a las organizaciones, desde una formación integral que incorpora el pensamiento crítico, la capacidad de resolver problemas y de adaptarse a las dinámicas del entorno actual.

Si te interesa ser parte de la alta gerencia de una empresa, incorporar tecnología a tus habilidades numéricas, gestionar información sensible o conocer el trasfondo íntimo de los negocios que siempre has admirado, este es tu lugar.

*    Escuela Administracion 
*    Contaduría Pública 

## Registro calificado

Resolución 21376 del 11 Noviembre de 2020 con vigencia de 7 años.

## Acreditación de alta calidad

Resolución 21376​ del 11 Noviembre de 2020. Vigencia por 6​ años.

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1246

Valor del primer semestre

$14.825.196

Valor promedio de los semestres

$14.756.550

Becas y financiación

## Sobre el programa

Calidad y excelencia

**Somos top en el mundo**

Como Institución, estamos acreditados por la AMBA (Association of MBAs) y por la AACSB (Association to Advance Collegiate Schools of Business), dos de las tres coronas internacionales a las que los programas de Administración, Economía y Finanzas pueden aspirar.

Nuestro MBA (Maestría en Administración), para el que puedes homologar créditos con nuestros programas de pregrado, tiene la máxima acreditación de la AMBA (Association of MBAs) por cinco años y es el mejor de Colombia, según el Ranking QS.

**Nos respalda la experiencia y la tradición:**

Nuestra Escuela fue la primera en América Latina en recibir la acreditación BGA (Business Graduate Association); nuestro programa de Contaduría Pública fue pionero, en su categoría, en la acreditación a nivel nacional.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

MercaLab, un espacio para enfrentar los retos de las organizaciones; Aula Makers, un escenario orientado al desarrollo del pensamiento creativo y computacional a través de actividades de aprendizaje activo; Laboratorio Visual (Eye tracker), un lugar para investigar las diferentes dinámicas de percepción visual de los consumidores; el Aula de Innovación y Creatividad, diseñada para fortalecer dinámicas de innovación, creatividad, desarrollo de productos y diseño de servicios; y la Cámara Gessell, un laboratorio para el análisis y la investigación mediante la observación no participante.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: lo mejor de la academia, la ciencia y las artes converge en EAFIT.

Como Escuela organizamos eventos institucionales como Conamerc, Simpro y Gerenciar.

**Tenemos proyección y presencia nacional**

Estamos en Bogotá con nuestros programas de maestría en: Administración Financiera (MAF), Administración (MBA), Gerencia de Proyectos y Especialización en Finanzas. También llegamos a Pereira con las maestrías en: Administración (MBA) y Administración de Riesgos. Además, ofrecemos maestrías y especializaciones en: Mercadeo, Gerencia de Proyectos, Administración Financiera y la Especialización en Finanzas. En ambas sedes, contamos con flexibilidad de clases presenciales cada quince días y cada mes, según el programa.

**Somos actor clave de una ciudad universitaria.**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de Ciudades Universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año, EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**En pregrado cada persona tiene libertad para configurar su plan de estudios con diversidad de líneas de énfasis para elegir**

Se aprende desde la experiencia con retos empresariales y con la solución de proyectos reales.

Innovación y liderazgo

**Somos innovación en educación**

Nuestro modelo de formación ha sido replicado por universidades como el Tecnológico de Monterrey.

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y a los graduados. También reciben una formación multidisciplinaria gracias a las cinco escuelas de EAFIT y a las áreas de conocimiento que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

En EAFIT, tenemos 14 grupos estudiantiles con más de 1.500 integrantes, donde se desarrollan habilidades de liderazgo desde la práctica.

Contamos con 40 grupos de investigación, 3 de ellos en categoría A1, la más alta posible, y más de 100 semilleros para el aprendizaje y crecimiento de los estudiantes.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Contamos con un centro de estudios e incidencia, Valor Público, y con un espacio de innovación y desarrollo social: EAFIT Social.

Tenemos On.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 iniciativas empresariales y emprendimientos de impacto.

Contamos con el In-sight, centro de estudios e incidencia, donde nos preocupamos por entender los problemas presentes y futuros de las organizaciones y por acompañarlas en la construcción de soluciones sostenibles. También nos enfocamos en la formación de sus líderes.

Nuestros profesores mantienen una relación permanente con las organizaciones, la investigación y las mejores universidades del mundo. Asimismo, están en contacto con los problemas que afectan a nuestra sociedad.

Brindamos consultoría a empresas del mundo, como el GOROM Institute.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio docente e investigador.

**Representamos excelencia para los empleadores**

El 98% de nuestros graduados está empleado.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrado han iniciado sus emprendimientos. Doce de ellos están en la lista de las 100 mejores startups de Colombia.

Acreditación

###### Renovación de Acreditación​

**​¿Qué es la Acreditación de Alta Calidad?​​​**

La acreditación es el reconocimiento de la alta calidad que otorga el Ministerio de Educación Nacional a los programas académicos y a las instituciones que cumplen con los más altos criterios de calidad y que realizan sus propósitos y objetivos, teniendo en cuenta la naturaleza jurídica, la identidad, la misión, la tipología, los niveles de formación y las modalidades. La acreditación en alta calidad promueve el fortalecimiento de una cultura de alta calidad en los programas académicos y en las instituciones, que se sustenta en los sistemas internos de aseguramiento de la calidad. La evaluación con fines de acreditación en alta calidad se lleva a cabo por la institución sobre sí misma y sus programas académicos, los pares académicos y el Consejo Nacional de Acreditación – CNA.

**¿Qué es el proceso de autoevaluación?​**

La autoevaluación consiste en el ejercicio permanente de revisión, reconocimiento, reflexión e intervención que lleva a cabo la institución sobre sí misma o sobre un programa académico, con una amplia participación de la comunidad institucional y con el objetivo de valorar el desarrollo de sus funciones sustantivas, en aras de lograr la alta calidad en todos sus procesos, de acuerdo con los componentes del modelo de acreditación en alta calidad establecidos en el presente acuerdo. La autoevaluación que realiza internamente la institución culmina con un informe, el cual contiene los resultados y un plan de mejoramiento.

**¿Cuáles son los requisitos para optar por la acreditación de alta calidad ante el CNA?​**

**Programa académico acreditable. ​**

Es el programa académico que se encuentra autorizado para ser ofrecido y desarrollado por la institución, y que cuenta con por lo menos ocho (8) años continuos de funcionamiento, verificables en el Sistema Nacional de Información de la Educación Superior – SNIES. Se consideran acreditables los programas académicos de los niveles de formación técnica profesional, tecnológica, universitaria, maestría, especialidad, médico-quirúrgica y doctorado.

**¿Quiénes participan de un proceso de autoevaluación y acreditación de programas académicos?**

Para llevar a cabo este proceso, se conforma un comité de autoevaluación y acreditación del programa, compuesto por el decano de la escuela, el coordinador del programa académico, representantes de profesores, estudiantes y egresados del programa de posgrado, con el fin de tener una visión holística del programa. Este grupo es responsable de la autoevaluación del programa y emite un juicio integral sobre la calidad de este, el cual debe contener argumentos respaldados por evidencias cualitativas y cuantitativas. Asimismo, está encargado de orientar el desarrollo del proceso, la redacción del informe final por parte del respectivo programa, el diagnóstico de problemas, la búsqueda de soluciones y la coordinación de estrategias para sustentar e introducir los cambios que se requieran para mejorar la calidad.

**Acreditaciones Internacion​​ales**

1.   EAFIT, es miembro de la alianza para la educación en negocios más grande del mundo, [AACSB Int​ernational - The Association to Advance Collegiate Schools of Business.](https://www.aacsb.edu/)
2.   La Escuela de Administración de EAFIT y todos sus programas de pregrado y posgrado, se encuentran acreditados por [The Business Graduates Association](https://www.businessgraduatesassociation.com/) –BGA- organismo internacional, de membresía y garantía de calidad, de escuelas de negocios, líderes en el mundo y de alto potencial que comparten el compromiso por las prácticas de gestión responsable y por el aprendizaje permanente, y además, buscan generar un impacto positivo en sus estudiantes, comunidades y la economía en su conjunto.

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Pruebas Saber Pro

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

## **Nuestras acreditaciones**

### También te puede interesar

#### Mercadeo

Duración

9 Semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 90979

Valor del primer semestre

$14.825.196

Valor promedio de los semestres

$15.168.360

Becas y financiación

#### Administración de Negocios

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1245

Valor del primer semestre

$15.442.913

Valor promedio de los semestres

$15.099.725

Becas y Financiación

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Liderar para generar impacto: decisiones que transforman personas, equipos y oportunidades

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate