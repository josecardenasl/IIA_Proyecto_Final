# Pregrado en Geología (vigente hasta 2025-2) - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Pregrado en Geología (vigente hasta 2025-2)

*    Plan de Estudio 
*    Pregrado En Geología (vigente Hasta 2025-2) 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Núcleo de Formación Institucional 

- [x] Obligatorias 

- [x] Plan de estudios del programa 

- [x] Prepráctica - Práctica 

Semestre 1

Créditos 

totales-

Créditos 4

#### Fenómenos Químicos y Laboratorio

Código: BI0230

Obligatorias
## Fenómenos Químicos y Laboratorio

4 Créditos

6 UMES

Código: **BI0230**

Créditos 2

#### Biología

Código: BI0244

Plan de estudios del programa
## Biología

2 Créditos

4 UMES

Código: **BI0244**

Créditos 0

#### Inducción

Código: BU0010

Inducción y Bienestar Universitario
## Inducción

0 Créditos

0 UMES

Código: **BU0010**

Créditos 1

#### Bienestar Universitario

Código: BU0011

Inducción y Bienestar Universitario
## Bienestar Universitario

 Cancelable 

1 Créditos

1 UMES

La asignatura Bienestar Universitario, por medio de actividades artísticas, deportivas, académicas y de reflexión, facilita la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, contribuyendo a la transición entre el colegio y la Universidad.

Código: **BU0011**

Correquisito Créditos 0

#### Taller de Salud

Código: BU0600

Créditos 0

#### Taller de Salud

Código: BU0600

Inducción y Bienestar Universitario
## Taller de Salud

0 Créditos

0 UMES

Código: **BU0600**

Créditos 3

#### Cálculo I

Código: CM0230

Obligatorias
## Cálculo I

3 Créditos

4 UMES

Código: **CM0230**

Créditos 3

#### Geociencias

Código: CT0273

Plan de estudios del programa
## Geociencias

3 Créditos

4 UMES

Código: **CT0273**

Créditos 2

#### Campo 0

Código: CT0274

Plan de estudios del programa
## Campo 0

2 Créditos

4 UMES

Código: **CT0274**

Créditos 3

#### NFI

Código: 

Núcleo de Formación Institucional
## NFI

3 Créditos

UMES

Código: 

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Núcleo de Formación Institucional 

- [x] Obligatorias 

- [x] Plan de estudios del programa 

- [x] Prepráctica - Práctica 

## Líneas de énfasis

Énfasis 1: Introducción a la Vulcanología (Código: CT0303).

Énfasis 2: Cambio Climático (Código: CT0304).

Énfasis 3: Análisis de Cuencas (Código: CT0305).

Énfasis 4: Proyecto Minero (Código: CT0306).

Preparación de Proyectos (Código: OG0260).

Evaluación Financiera de Proyectos (Código: OG0261).

Evaluación Ambiental de Proyectos (Código: OG0262).

Análisis de Riesgos (Código: OG0263).

Gestión de Proyectos (Código: OG0264).

Álgebra en Ciencias de los Datos (Código: CM0936).

Estadística en Analítica (Código: EC1800).

Proyecto especial.

Aprendizaje de Máquina Aplicado (Código: ST1631).

Estrategias de Innovación en Ecosistemas Digitales (Código: ST1632).

Diseño de la Experiencia de Usuario (Código: ST1633).

Almacenamiento y Recuperación de la Información (Código: ST1801).

Fundamentos de Ciencias de los Datos (Código: ST1804).

Estabilidad de Taludes (Código: IC0759).

Geomecánica de Rocas (Código: IC0830).

Ingeniería de Fundaciones (Código: IC0837).

Mecánica de los Medios Continuos Avanzada (Código: IC0896).

###### **Nota:**Cada asignatura tiene 3 créditos.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate