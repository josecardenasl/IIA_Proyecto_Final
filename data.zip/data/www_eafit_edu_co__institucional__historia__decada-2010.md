# Década de 2010 - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Década 2010

La Cuarta Revolución Industrial plantea los desafíos en investigación y desarrollo para el futuro. Busca poner las nuevas herramientas tecnológicas al servicio de la sociedad y como palanca de un nuevo modelo de economía.

*    Década de 2010 

### **Diez años con los indicadores positivos y en c​recimiento​**

**Dos renovaciones de la Acreditación Institucional de Alta Calidad, el 98 por ciento de sus profesores con título de maestría y doctorado; 17 programas de pregrado y 6 de posgrado acreditados por el MEN (los susceptibles de ser acreditados); más del 60 por ciento de los grupos de investigación en las principales categorías de Colciencias (A y A1); 37 patentes —cuatro de estas por fuera de Colombia—, y cerca de 300 convenios en 36 países son algunos de los hechos que hacen de la década de 2010 una de las más prolíficas de la historia eafitense.​​​**

​

2010, por ejemplo, fue el año en el que la Institución celebró su primer medio siglo de vida y, en esa misma fecha, un alto número de acontecimientos y buenas noticias se sumaron a esta conmemoración, como la firma del convenio para la creación del Instituto Confucio de Medellín, con sede en la Universidad, o el reconocimiento por parte del Instituto Cervantes para el programa de Español para Extranjeros.

La inauguración del Edificio de Ingenierías en el bloque 19; el incremento de la colección de la Sala de Patrimonio Documental con los documentos de la Fundación Antioqueña para los Estudios Sociales (Faes); y la presentación del Laboratorio Financiero, entre otros logros, hicieron parte de esta programación de aniversario, a la que se sumó otro importante logro, la renovación de la Acreditación Institucional de Alta Calidad hasta 2018.

Desde entonces, los indicadores no han evidenciado más que crecimiento, evolución, fortalecimiento y capacidad de respuesta a las demandas y desafíos de la educación superior y de la sociedad. De esta manera, en 2011, los pregrados e​n Psicología y Mercadeo, y la maestría en Derecho Penal pasaron a engrosar la oferta eafitense.

Así mismo, en este año inicia el proyecto institucional Atreverse a Pensar; se realiza la primera edición de la Escuela de Verano y la Universidad, en conjunto con el Área Metropolitana del Valle de Aburrá, impacta la movilidad de Medellín con la implementación del sistema de movilidad Encicla.

En 2012 EAFIT crea su Dirección de Docencia y recibe, de parte de la Universidad de Purdue (Estados Unidos), al supercomputador Apolo. Igualmente, se les da la bienvenida a los doctorados en Ciencias de la Tierra e Ingeniería Matemática, a los pregrados en Biología y a diferentes posgrados.

Por su parte, 2013 es un buen año para las patentes. Se obtiene la patente por modelo de utilidad con la Superficie dinámica para el tratamiento y prevención de úlceras en la piel, y patentes de invención como resultado de las investigaciones Distractor intraoral para el transporte óseo y Equipo activador detonador de artefactos explosivos radio controlados. En la actualidad la Institución ya suma 37 invenciones, cuatro de estas por fuera del país.

En este año también se firma el convenio para la creación del Centro Argos para la Innovación en EAFIT, y se materializa el primer carro solar colombiano que compite en el World Solar Challenge Australia, este último en alianza con EPM.

Con el folleto Memorias sobre diferentes masas de hierro encontradas en la cordillera oriental de los Andes (1823), EAFIT ingresa a la Biblioteca Digital Mundial en 2014. Además, la Universidad es seleccionada para el programa La Fuerza de 100.000 en las Américas, una iniciativa del Departamento de Estado de los Estados Unidos.

El Premio Biblioteca de Narrativa Colombiana y una patente de invención por la investigación Prótesis craneales en titanio también se convierten en acontecimientos importantes en 2014.

Al llegar a 2015, y a sus 55 años de existencia, EAFIT se consolida como un referente académico y arquitectónico de Medellín, idea sustentada por la creación de una sexta escuela, la de Ciencias, y por las construcciones modernas y enfocadas a la investigación y a la cultura, como el Centro Argos para la Innovación y la ampliación del escenario del Auditorio Fundadores.

La Universidad continuó reafirmado ese año su compromiso y capacidad de respuesta con los retos que impone el paso del tiempo y, para este fin, transformó su visión de marca de Abierta al mundo a Inspira, Crea y Transforma, una hoja de ruta que ha marcado la senda de la calidad y la excelencia durante los últimos tres años.

En 2016 el proyecto institucional Atreverse a Pensar evoluciona en el Centro de Integridad EAFIT, un espacio de reflexión sobre la ética y los valores que es inaugurado, un año más tarde, por la filósofa española Adela Cortina.

En 2017, en asocio con Cementos Argos la Universidad recibe su primera patente internacional en Japón, mientras que el aprendizaje de las lenguas extranjeras y la inmersión en otras culturas se ve fortalecida con la inauguración de los nuevos espacios de Idiomas EAFIT, en el Parque Los Guayabos y en el centro comercial Mayorca Megaplaza.

Finalmente, la celebración de los 58 años de vida institucional de la Universidad también ha estado marcada por importantes logros y objetivos en los que ha participado toda la comunidad eafitense. La obtención de la Acreditación de Alta Calidad por tercera vez es una muestra de ese compromiso, y ratificó a EAFIT como un testimonio de confianza ante la sociedad y otros pares.

Se trata de un aval que, en 2018, coincide con importantes cambios organizacionales como la bienvenida de tres nuevas vicerrectorías (Aprendizaje, Administrativa y de Proyección Social; y de Creación y Descubrimiento.

Este es el año en el que la Universidad culmina su Plan Estratégico 2012-2018 y comienza a formular un nuevo derrotero para los próximos años. Se trata de una hoja de ruta que le permitirá a la Universidad fijar su mirada en metas aún más retadoras y consolidar un proyecto educativo de mayor impacto, que transforme vidas y convierta el aprendizaje en una experiencia de vida.​

La Cuarta Revolución Industrial, expresión acuñada en la Feria de Hannover a comienzos de la década, inicialmente como Industria 4.0, y liderada por el Foro Económico Mundial (Davos, Suiza) a partir de 2016, plantea los desafíos en investigación y desarrollo para el futuro. Esta nueva ‘era de la máquina’ comprende, entre sus dispositivos más potentes, la inteligencia artificial, la robótica, el internet de las cosas, la impresión 3D, los implantes tecnológicos, la realidad aumentada, los vehículos autónomos, las ciudades inteligentes, y el big data y analítica, todo esto para lograr la conectividad entre el mundo virtual y los campos de lo físico y lo biológico, al buscar poner las nuevas herramientas tecnológicas al servicio de la sociedad y como palanca de un nuevo modelo de economía.

En esta década, la Universidad ha seguido dando respuesta a las necesidades de los sectores público y privado por medio de la transformación del aprendizaje y la investigación. Entre muchos otros hitos se encuentra la inauguración, en 2010, del Edificio de Ingenierías; y la puesta en marcha, en 2012, del supercomputador Apolo, gracias a una donación inicial de Purdue University. Así mismo, en 2015, se inauguró el Centro Argos para la ​Innovación en EAFIT, con un edificio sostenible y funcional. Importante noticia fue el hallazgo arqueológico de vasijas funerarias de los indígenas aburráes en el Parque los Guayabos, donde hoy se encuentra el Edificio de Idiomas (inaugurado en 2016).

El camino a la excelencia también ha sido una prioridad. EAFIT consiguió la renovación de su Acreditación Institucional por ocho años en 2010, aval que fue refrendado de nuevo en el año 2018 y que estará vigente hasta 2026. Este confirma la alta calidad de la Universidad y, a su vez, se constituye en un testimonio de confianza para sus grupos de interés.

La búsqueda de soluciones para los problemas sociales globales y locales no para, señal de esperanza que se manifiesta en actos como la Convención Marco de las Naciones Unidas sobre el Cambio Climático (París, 2015); y, en el ámbito nacional, la firma de los acuerdos de paz entre el Gobierno Nacional y la guerrilla de las Farc, fruto de un intenso lustro de negociaciones (Bogotá, 2016). EAFIT, por su parte, priorizó cinco Objetivos de Desarrollo Sostenible a partir de los 17 planteados por la ONU para mejorar la vida de la humanidad hacia 2030. Estos son: Educación de calidad, Trabajo decente y crecimiento económico, Industria, innovación e infraestructura; Reducción de las desigualdades, y Alianzas para lograr los objetivos.

a Misión Institucional de EAFIT, alineada con estos propósitos de humanidad, se refleja en el nacimiento de los pregrados en Mercadeo (2011), Psicología (2011), Biología (2012), Finanzas (2013), Literatura (2017) e Ingeniería Agronómica (2019), con el núcleo Agro 4.0. En 2011 se creó la Escuela de Economía y Finanzas y, años después, la Escuela de Ciencias (2015), con las que se completan las seis escuelas que en la actualidad tiene la Institución. Para consolidarse como una universidad del siglo XXI, además de los pregrados, EAFIT le ofrece al país una gran variedad de formación avanzada en posgrados, con 45 especializaciones, 40 maestrías y 6 doctorados. Debe resaltarse que en el año 2015 se acreditó el primer posgrado: la maestría en Ciencias de la Administración y en 2017 el doctorado en Administración. Hoy son alrededor de diez programas de este tipo los que cuentan con este aval.

Muchos hechos importantes de estos últimos años quedan por fuera, pero hay uno que vale la pena registrar: el inicio del Centro de Integridad (2016), compromiso institucional por el valor supremo de la Integridad. Los retos que ha asumido la Universidad la encaminan en la dirección de ser una institución sostenible y pertinente en la sociedad digital y la economía del conocimiento.

En el último año de esta década, y ad portas de cumplir sus 60 años, la Universidad comenzó a avanzar en el Itinerario 2030, un nuevo viaje que emprende luego de revisar en profundidad los retos del entorno y fijar su mirada en el futuro. Para esta travesía lleva en su equipaje el conocimiento, las capacidades y la experticia que le han permitido dar respuestas oportunas y pertinentes a las necesidades de las organizaciones y sus grupos de interés durante 12 lustros de trayectoria, pero también explora nuevos caminos para transformar, ser relevante y avanzar en su Propósito Superior de inspirar vidas e irradiar conocimiento para forjar humanidad y sociedad.

## Hitos de la década

2010

###### **Renovación de la Acreditación Institucional hasta 2018**

En el acto de entrega de la resolución de renovación de la Acreditación Institucional, la ministra de Educación, Cecilia María Vélez White, reiteró que EAFIT es un punto de referencia para las instituciones de educación superior del país y destacó el proceso de mejoramiento continuo y de fortalecimiento de la calidad.

###### **Otros sucesos importantes en el 2010**

Primer Encuentro de Música

El 16 de febrero se firma el convenio para la creación del Instituto Confucio de Medellín.

La Universidad es reconocida como centro asociado del Instituto Cervantes de España, para la enseñanza del idioma español.

EAFIT Pereira inaugura su sede propia.

La Fundación Antioqueña para los Estudios Sociales (Faes) le dona su colección a la Sala de Patrimonio Documental de la Biblioteca Luis Echavarría Villegas.

La Universidad recibe de parte del presidente de la República, Álvaro Uribe Vélez, la Orden de Boyacá en la celebración de sus 50 años.

El Departamento de Finanzas presenta el Laboratorio Financiero, punto de la Bolsa de Valores de Colombia.

La Universidad inaugura el Edificio de Ingenierías, un espacio que va del pensar al hacer. EAFIT presenta el Centro de Estudios Urbanos y Ambientales (Urbam).

Se crea Proyecto 50, con el objetivo de promover la innovación en los procesos de aprendizaje. La alianza Argos-EAFIT se fortalece con la creación del primer laboratorio de esta compañía en el campus.

Se realiza el primer encuentro de egresados Alcampus, como parte de la celebración de los 50 años de la Universidad.

El Departamento de Finanzas presenta el Laboratorio Financiero, punto de la Bolsa de Valores de Colombia.

La Universidad inaugura el Edificio de Ingenierías, un espacio que va del pensar al hacer.

EAFIT presenta el Centro de Estudios Urbanos y Ambientales (Urbam).

Se crea Proyecto 50, con el objetivo de promover la innovación en los procesos de aprendizaje.

La alianza Argos-EAFIT se fortalece con la creación del primer laboratorio de esta compañía en el campus.

Se realiza el primer encuentro de egresados Alcampus, como parte de la celebración de los 50 años de la Universidad.

2011

###### **Enero de 2011**

**Nacen Psicología y Mercadeo**

Dos nuevos pregrados de la Escuela de Administración inician actividades: Psicología y Mercadeo. Además comienza la maestría en Derecho Penal.

###### **Marzo de 2011**

**Se inaugura la Sala de Audiencias de EAFIT**

La Escuela de Derecho inaugura la Sala de Audiencias para que los estudiantes representen casos penales de la vida real.

###### **Mayo de 2011**

**Se cumplen 20 años de idiomas en la Universidad**

El Centro de Idiomas cumple 20 años, con cerca de 100 mil estudiantes formados en sus instalaciones.

###### **Junio de 2011**

**Se inaugura la Escuela de Verano y un nuevo programa para EAFIT Llanogrande**

La Escuela de Verano de EAFIT, la primera de su tipo en Medellín, inicia actividades académicas y culturales en época de vacaciones. Además, la maestría en Gerencia de Empresas Sociales para la Innovación Social y el Desarrollo Local inicia actividades desde la sede de EAFIT Llanogrande.

###### **Agosto de 2011**

**Atreverse a pensar, un ejemplo de excelencia e integridad**

Inicia el proyecto institucional Atreverse a Pensar que promueve la excelencia y la integridad.

###### **Octubre de 2011**

**Una quinta escuela y un programa de bicicletas para Medellín**

Se aprueba la quinta escuela de la Universidad EAFIT: Economía y Finanzas. Además, la Universidad y el Área Metropolitana impactan la movilidad de la ciudad con la implementación del programa Encicla.​

###### **Noviembre de 2011**

**Nuevos programas académicos para EAFIT**

El Ministerio de Educación Nacional aprobó el doctorado en Humanidades de EAFIT. Así mismo, la especialización en Gerencia del Desarrollo Humano es el primer programa virtual de la Universidad en iniciar actividades. Por su parte, la Spin off Utópica- EAFIT inauguró Anfibia: una solución de vivienda flotante y auto sostenible.

El Ministerio de Educación Nacional aprueba el doctorado en Humanidades.

2012

Se crea la Dirección de Docencia.

El Fondo Editorial de la Universidad EAFIT celebra 15 años de existencia.

El Ministerio de Educación aprueba el nuevo pregrado en Biología.

EAFIT recibe de parte de la Universidad de Purdue el supercomputador Apolo.

La octava patente de EAFIT es el Reactor dual asistido por plasma. Se concede como modelo de utilidad.

El archivo del expresidente colombiano Mariano Ospina Rodríguez, salvaguardado por la Sala de Patrimonio Documental de EAFIT, ingresa al Registro Regional de Memoria del Mundo de la Unesco.

El periódico estudiantil más antiguo de Colombia, Nexos, cumple 25 años de circulación.

El Departamento de Geología logra la aprobación del doctorado en Ciencias de la Tierra.

La Universidad aprueba el Plan Maestro que contempla los principales proyectos de infraestructura a 2024.

2013

###### **Marzo de 2013**

**Primavera: el carro solar eafitense**

EAFIT y EPM construyen el primer carro solar que compite, en el mes de octubre, en el World Solar Challenge Australia. Además, la Superficie dinámica para el tratamiento y la prevención de úlceras en la piel se convirtió en la novena patente de EAFIT. Es un modelo de utilidad.

###### **Abril de 2013**

**La décima patente**

La Universidad recibe su décima patente, tercera de invención: el distractor intraoral para el transporte óseo.

###### **Septiembre de 2013**

Un mes para nuevas maestrías

Cinco maestrías fueron aprobadas en Derecho, Procesos Urbanos y Ambientales, Gobierno y Políticas Públicas, Administración y Administración de Riesgos.

###### **Noviembre de 2013**

**Se gesta el Centro Argos para la Innovación en EAFIT**

Se firma el convenio para la creación del Centro Argos para la Innovación en EAFIT.

###### **Diciembre de 2013**

**Llega la undécima patente**

La Institución recibe su undécima patente, cuarta de invención: Equipo activador detonador de artefactos explosivos radio controlados.

###### **Otros sucesos importantes en el 2013**

Se obtiene la novena patente: Superficie dinámica para el tratamiento y prevención de úlceras en la piel. Es un modelo de utilidad.

El Ministerio de Educación Nacional aprueba el pregrado en Finanzas.​

2014

Con el folleto Memorias sobre diferentes masas de hierro encontradas en la cordillera oriental de los Andes (1823), EAFIT ingresa a la Biblioteca Digital Mundial.

Contaduría Pública es el primer pregrado en recibir una acreditación internacional. Fue otorgada por Consejo de Acreditación en Ciencias Sociales, Contables y Administrativas en la Educación Superior de Latinoamérica, A.C. (Cacsla), de México.

EAFIT recibe certificación internacional en Gerencia de Proyectos de parte Project Management Institute (PMI) de Pensilvania (Estados Unidos).

El Ministerio de Educación Nacional aprueba la maestría en Gerencia de la Innovación y el Conocimiento.

La Universidad es seleccionada para el programa La Fuerza de 100000 en las Américas, del Departamento de Estado de los Estados Unidos.

La Institución presenta el Premio Biblioteca de Narrativa Colombiana.

EAFIT participa en el Foro Urbano Mundial realizado en Medellín.

EAFIT y EPM ganan Premio Nacional de Ingeniería por el carro solar Primavera.

EAFIT, el Pnud, la Unidad Nacional para la Gestión del Riesgo de Desastres y la Unión Europea entregan en el corregimiento de Sempegua (Chimichagua, Cesar) el primer piloto de aulas flotantes de Latinoamérica.

EAFIT, el Pnud, la Unidad Nacional para la Gestión del Riesgo de Desastres y la Unión Europea entregan en el corregimiento de Sempegua (Chimichagua, Cesar) el primer piloto de aulas flotantes de Latinoamérica.

MBA de EAFIT recibe acreditación internacional de la Amba (Asociación de MBA).

El Encuentro de Música de EAFIT cumple 10 años de existencia.

El doctorado en Ingeniería Matemática y las maestrías en Economía Aplicada y Comunicación Transmedia, programas aprobados por el Ministerio de Educación Nacional.

Prótesis craneales en titanio se convierte en la quinta patente de invención de la Universidad EAFIT.

###### La nueva imagen eafitense y una nueva escuela

La Institución inicia 2015 con una renovación en su visión de marca con tres conceptos que ahora la definen: Inspira, Crea y Transforma. Además, la Escuela de Ciencias, aprobada en 2014 por el Consejo Superior, inicia actividades como uno de los objetivos del Plan Estratégico de Desarrollo 2012-2018.​

2015

###### **Enero de 2015**

**La nueva imagen eafitense y una nueva escuela**

Inicia el proyecto institucional Atreverse a Pensar que promueve la excelencia y la integridad.

###### **Marzo de 2015**

**Aniversario para la Universidad de los Niños**

La Universidad de los Niños cumple una década, tiempo durante en el que ha recibido a 2.890 niños universitarios.

###### **Otros logros importantes en 2015**

Se inaugura el Centro Argos para la Innovación en EAFIT.

La maestría en Ciencias de la Administración se convierte en el primer posgrado de la Universidad que es acreditado por el Ministerio de Educación Nacional, y abre el camino para que las maestrías en Ciencias de la Tierra, Finanzas y Matemática Aplicada también lograran este aval.

Nace el programa Alta Dirección, enfocado al fortalecimiento y actualización de capacidades estratégicas y de competitividad de empresarios nacionales e internacionales.

2016

###### **Se oficializa la apuesta eafitense por la Integridad académica**

Se crea el Centro de Integridad de EAFIT, dependencia que promueve el diálogo y la reflexión sobre la ética, la moral y los valores. Un año más tarde es presentado oficialmente con una conferencia a cargo de la filósofa española Adela Cortina.

2017

###### **Primera patente internacional**

En asocio con Cementos Argos la Universidad recibe su primer patente internacional en Japón. En la actualidad cuenta con 37 invenciones, cuatro de estas fuera del país.

###### **Otros logros importantes en 2017**

Idiomas EAFIT abre sus puertas desde sus nuevas instalaciones en el Parque Los Guayabos y en Mayorca Megaplaza. El bloque 1 se conecta al campus a través de un puente peatonal que se convirtió en un nuevo ícono para los eafitenses.

La institución renueva su carta organizacional con la creación de las vicerrectorías de Aprendizaje, Administrativa y de Proyección Social, y de Creación y Descubrimiento.

Con el propósito de fortalecer los ecosistemas de aprendizaje, la Universidad reforma sus aulas de clase en los bloques 31, 32 y 33; y en el cuarto piso del bloque 19 para facilitar una experiencia transformadora y de aprendizaje activo.

Se aprueba el pregrado en Literatura, el número 22 de la Universidad

2018

###### **¡EAFIT, testimonio de confianza!**

EAFIT obtiene, por tercera vez, la Acreditación de Alta Calidad por parte del Ministerio de Educación Nacional. El aval es hasta 2026.

2019

###### **Ya son 23 pregrados**

Comienza la primera cohorte del pregrado en Ingeniería Agronómica, el número 23 de la Universidad.

## Década de 2010

La nueva Misión Institucional de EAFIT, alineada con estos propósitos de la humanidad, se refleja en el nacimiento de los pregrados en Mercadeo (2011), Psicología (2011), Biología (2012), Finanzas (2013), Literatura (2017) e Ingeniería Agronómica (2019)

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)