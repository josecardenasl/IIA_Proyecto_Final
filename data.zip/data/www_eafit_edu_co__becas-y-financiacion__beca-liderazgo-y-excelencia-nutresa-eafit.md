# Beca Excelencia y Liderazgo Nutresa – EAFIT ​​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Beca Excelencia y Liderazgo Nutresa – EAFIT ​​

Si eres un estudiante talentoso, líder y con una activa participación e​n actividades extracurriculares, esta oportunidad es para ti.

**La convocatoria estará habilitada del 06 de abril al 10 de mayo de 2026.**

*    Beca Excelencia y Liderazgo Nutresa – EAFIT ​​ 

## Beca Excelencia y Liderazgo Nutresa – EAFIT ​

¿Cuándo se abre la convocatoria?

La convocatoria estará habilitada del 06 de abril al 10 de mayo de 2026. [Aplica aquí](https://eafit.qualtrics.com/jfe/form/SV_1LYLBPLYFEBJJMq)

¿Quiénes pueden aplicar?

Estudiantes de pregrado activos en 2026-1 que se destaquen por su **excelencia académica y por su participación en actividades internas o externas de liderazgo, artísticas, deportivas o de incidencia social.**

Esta beca aplica para estudiantes que, con corte al balance del 2025-2, hayan cursado mínimo 5 materias en ese semestre, obteniendo un promedio crédito acumulado (PCA) mayor o igual a 4,0 y que hayan aprobado su tercer (3) semestre en adelante. Además, no pueden haber perdido ni cancelado materias durante la carrera, ni haber cursado la práctica ni estar matriculados en prepráctica en 2026-1.

**Nota:** No podrán participar en esta convocatoria aquellos estudiantes que cuenten con una beca o beca-crédito del 100% para todo su pregrado, ya sea por parte de la Universidad, de entidades externas y/o de aliados.

¿Qué cubre la beca?

El 100% del valor de la matrícula por un semestre.

**Nota:** El beneficio lo debe utilizar el estudiante en el semestre 2026-2, de lo contrario este beneficio no se le activará y deberá postularse nuevamente.

¿Cómo es el proceso para aplicar?

Diligencia el formato de solicitud de la beca [aquí](https://eafit.qualtrics.com/jfe/form/SV_1LYLBPLYFEBJJMq) y adjunta una carta, donde incluyas la siguiente información:

Cuéntanos detalladamente sobre las acciones que lideras en la Universidad o en tu comunidad, si tienes un proyecto o si desempeñas algún papel significativo que genere un impacto social.

¿Qué relación tiene tu pregrado y lo que aprendes actualmente con el grupo empresarial Nutresa?

Es importante emplear un estilo claro y preciso en su escritura. El texto lo debe elaborar en fuente Arial, tamaño 12, extensión máxima 500 palabras. Incluya al final su nombre y documento de identidad y guarde el archivo en formato PDF.

**Notas importantes:**

En caso de ser beneficiario de la beca esta aplicará solo para un semestre y debe ser el inmediatamente siguiente. En este caso es para 2026-2.

Información adicional

Los resultados de la convocatoria serán enviados al correo electrónico registrado en el formulario máximo el **23****de junio de 2026.**

**Mayores Informes:**

**Teléfono:**604 2619500

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)