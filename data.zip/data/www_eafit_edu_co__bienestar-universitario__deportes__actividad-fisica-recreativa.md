# Actividad física recreativa - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Deporte Libre

Disfruta del deporte libre en EAFIT: ping pong, taebo, kung fu, running, voleibol y más. Actividades recreativas con horarios flexibles.

*    Actividad Física Recreativa 

##### Actividad física recreativa

Te invitamos a unirte a las actividades de uso y aprovechamiento del tiempo libre, las cuales están dirigidas por profesionales que cuidarán de tí. ​

**Todas nuestras opciones de Actividad física recreativa (Deporte Libre) son mixtas. y están dirigidas a E​studiantes de pregrado y posgrado, empleados y ​graduados**

**¡Lo único que necesitas es disposicion!**

**​Entrenador:** Maria E. Yepes Uribe

**Miércoles:** 6:00 p.m. a 8:00 p.m.

**Jueves:** 12:00 m a 2:00 p.m.

**Lugar:** Coliseo los Guayabos

**​Entrenador:** José Simón Olaya

**Lunes y viernes:** 6:00 p.m a 8:00 p.m​

**Lugar:**Coliseo Los Guayabos

**​Entrenadora:**Milena Restrepo​

**Martes:** 6:00 p.m. a 8:00 p.m.

**Jueves:** 4:00 p.m a 6:00 p.m

**Lugar:**Pista atlética

**Entrenador:**Dayan Alexis Cataño

**Lunes, miércoles y jue​​ves:** 12:00 m - 1:00 p.m.

**​Entrenadora:**Nini Johana Román Vélez

**Martes, miércoles y jue​​ves:** 5:00 p.m. - 6:00 p.m.

**Lugar:** Coliseo los Guayabos

**​Entr​​enador:**Nini Johana Román

**Martes y jueves:** 12:00 m. a 2:00 p.m.

**Lugar:** Placa cubierta

**Entrenador:** Cristian Salazar Gallego

**Martes:** 2:00 p.m. a 4:00 p.m.

**Lugar:**Cancha sintética​

**Jueves:** 2:00 p.m a 4:00 p.m

**Lugar:** Cancha sintética

**Entrenador:** Jeyson Asprilla​​​

**Lunes:**12:00 m. a 2:00 p.m.

**Miércoles:**2:00 p.m a 4:00 p.m

**Lugar:** Gimnasio al aire libre

**​Entrenador:**Jesús Alberto Blandón

**Miércoles:** 11:00 a.m - 1:00 p.m

**Jueves**: 9:00 a.m - 11:00 a.m

**Lugar:** Placa Cubierta

**Entrenador:** Andres Martinez

**Martes:** 5:00 p.m. a 7:00 p.m.

**Lugar:**Cancha de grama

**Jueves y sábado:** 9:00 a.m a 11:00 a.m

**Lugar:** Cancha sintética

**Entrenador:** Jose Simon Olaya

**Lunes:** 4:00 p.m. a 6:00 p.m.

**Jueves:** 10:00 a.m a 12:00 m.

**Lugar:** Coliseo Guayabos. Bloque 2, primer piso

**Nota: Debes llevar tus guantes.**

**Entrenador:**Sandra Lucia Lozano Gutié​rrez

**Lugar:**sede Pereira

**Martes:** Rumba

**Sábados:** Pausa activa

**Horarios:** Consultar en la sede.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate