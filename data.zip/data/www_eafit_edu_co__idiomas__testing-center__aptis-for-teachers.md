# APTIS for teachers - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# APTIS for teachers

*    APTIS For Teachers 

## Información general

Descripción del examen

El examen Aptis for Teachers es una prueba en computador que proporciona resultados rápidos calificados de manera confiable. Este examen es:

*   Específicamente desarrollado para profesores o personas en formación docente.
*   Evalúa las mismas competencias lingüísticas, pero con **preguntas contextualizadas en escenarios educativos.**
*   Útil para evaluar el nivel de inglés de docentes y garantizar que cumplan con los requisitos lingüísticos en programas educativos.

Estructura

La prueba, cuya duración es de**2,5 horas**, tiene 5 componentes: gramática y vocabulario, expresión oral, expresión escrita, comprensión auditiva y comprensión lectora.

La estructura y extensión de Aptis for Teachers es la misma que la de Aptis General. Sin embargo, el contenido de la prueba se relaciona específicamente con los profesores y las preguntas aprovechan temas y escenarios con los que se enfrentan los profesores todos los días. Como resultado, las preguntas son familiares, lo que permite que los candidatos se enfoquen puramente en el idioma y no en el contexto de las preguntas.

Proceso de inscripción

1.   Ingrese a [https://app.eafit.edu.co/recaudos/](https://app.eafit.edu.co/recaudos/ "https://app.eafit.edu.co/recaudos/") y seleccione el examen APTIS marcado con la respectiva sede y fecha de su elección.
2.   Lea atentamente las instrucciones y haga clic en continuar. En la casilla Tarifa, seleccione la opción APTIS FOR TEACHERS sede Poblado
3.   El pago lo puede realizar en línea haciendo clic en el botón PAGAR. También puede generar una liquidación con la que podrá pagar en cualquier Bancolombia. Para esto, debe hacer clic en el botón GENERAR y luego en IMPRIMIR LIQUIDACIÓN.

Recuerde que el pago lo debe hacer el mismo día que hace la inscripción de tal forma que se le asegure el cupo para tomar el examen.

1.   Una vez cancelada la inscripción, envía un correo a [testingcenter@eafit.edu.co](mailto:testingcenter@eafit.edu.co) con la siguiente información completa: Nombres completos, número de documento de identidad, dirección, ciudad, país, fecha de nacimiento, género (M o F), correo electrónico, número de celular y fecha y hora del examen.
2.   Encuentra los [Términos y condiciones del examen APTIS aquí](https://universidadeafit.widen.net/s/9rbxlxmbjq/terminos-condiciones-aptis-2025).
3.   Una vez realizado el pago, no habrá derecho a reembolso. Este saldo queda válido por el año en el que se pagó y podrá reprogramar su prueba mínimo 2 días antes de presentarla por cualquier fecha disponible del año en curso. Adjuntar comprobante de pago.

Inversión

### APTIS for teachers

$412.500 COP

### APTIS for teachers docentes EAFIT

$320.000

Calendario 2026

| Fecha del examen | Hora | Fecha límite de inscripción |
| --- | --- | --- |
| Abril 22 | 2:00 p. m. | Abril 19 |
| Abril 29 | 2:00 p. m. | Abril 26 |
| Mayo 06 | 2:00 p. m. | Mayo 03 |
| Mayo 20 | 2:00 p. m. | Mayo 17 |
| Mayo 27 | 2:00 p. m. | Mayo 24 |

**Esta prueba se ofrece todo el año. El calendario es actualizado mes a mes**

Notificación de resultados

Los resultados del examen se envían por medio de correo electrónico en 7 días hábiles después de haber presentado la prueba. ​

Es responsabilidad de cada candidato reclamar y entregar el certificado donde sea que se lo estén requiriendo. Idiomas EAFIT no reporta este resultado a nadie diferente al candidato, ni siquiera a Admisiones y Registro de la Universidad EAFIT ni conservamos copia de este.​

Observaciones

1.   Tenga en cuenta que no habrá lugar a cambios respecto a la sede de presentación del examen.

2.   Bajo ninguna circunstancia habrá devolución del dinero de inscripción o transferencia del examen a otro candidato, si por algún motivo usted no puede presentar el examen al que ya está inscrito, debe reprogramarlo.

3.   El día del examen deberá traer su documento de identidad original y una fotocopia del mismo por ambos lados, ampliada al 150%.

4.   La citación a la prueba será enviada por correo electrónico 1 día previo a la fecha del examen.

5.   La edad mínima para tomar el examen es 16 años. Documentos válidos: cédula de ciudadanía, cédula de extranjería, pasaporte, licencia de conducción y tarjeta de identidad en formato nuevo. Si no cuenta con alguno de estos documentos, debe presentar el que tenga que lo reemplace (contraseña o tarjeta de identidad en formato anterior) y otro documento con foto (como carné estudiantil o empresarial).

6.   En caso de presentar necesidades especiales (auditivas o visuales) d​ebe enviar un correo a [testingcenter@eafit.edu.co](mailto:testingcenter@eafit.edu.co) 3 meses antes de la fecha en la que aspira presentar el examen para solicitar una versión Aptis que se adapte a sus necesidades.

7.   Encuentra los Términos y condici​ones del​ examen​ APTIS [aquí.](https://universidadeafit.widen.net/s/wmjkdvdflr/teminos-y-condiciones-aptis-2025)

8.   Este examen podrá ser aplazado con tres días de anterioridad a la fecha programada. El personal de inscripciones comunicará el cambio realizado a los ​candidatos inscritos y las fechas en las que podrá tomar el examen.

###### Preguntas frecuentes

​​​Conoce nuestros protocolos e información general sobre nuestro Testing Center.

1.   Estudiantes que desean ingresar y/o egresar en una institución de educación superior.
2.   Estudiantes en proceso de admisiones y/o egreso del programa de aprendizaje del idioma inglés.
3.   Candidatos que desean presentarse para obtención de becas y certificaciones.
4.   Alumnos de diferentes programas de aprendizaje en idiomas, que desean controlar su progreso.
5.   Estudiantes y trabajadores que solicitan visas.
6.   Empresas y/o instituciones que requieran comprobar la suficiencia en idioma durante los procesos de selección de personal, analizar y certificar el nivel de inglés de sus empleados, hacer un seguimiento de la efectividad de los programas de formación lingüística, evaluar a sus empleados con vistas a ascensos o cargos en el extranjero.​

¿Quieres o te exigen presentar un examen de nivel de inglés, pero no sabes cuál es el adecuado para ti? ¿cuál es la diferencia entre uno y otro de tantos existentes en el mercado? ¿existe algún examen que me diagnostique mi nivel antes de decidir presentar un examen oficial?

La información a continuación puede orientarte un poco y llevarte a tomar la decisión más adecuada para tus necesidades.​

​Una diferencia importante entre todos los exámenes existentes es la validez de los resultados. Dicha validez está sujeta a las políticas y reglamentos de la institución académica, empresa, embajada, etc. solicitante de la prueba. Todas las instituciones son libres de aceptar el o los exámenes que mejor se adecuen a sus reglamentos internos.

Por ejemplo, los exámenes **IELTS y TOEFL** suelen ser más convenientes para los visados, trabajos o solicitudes de admisión universitaria que tengan como requisito de aceptación la posesión de un determinado nivel de inglés.

Exámenes como el **TOEIC, APTIS, TRACK TEST y Oxford Test of English​**son exámenes de inglés cuya novedad es la flexibilidad que aporta al poder evaluar de forma independiente una, dos, tres o todas las competencias del idioma. Estos exámenes son altamente aceptados en las universidades de Colombia.​

Ten en cuenta que cada examen tiene un proceso de inscripción diferente ,el cual varía dependiendo de la casa matriz del mismo.

Los tiempos de entrega también varían dependiendo de las políticas internas del ente oficial del examen. Ten presente el tiempo para tu examen de preferencia.

APTIS

CELPE-BRAS

DELE

IELTS

OTE

PLIDA

TOEFL

TOEIC

TRACK TEST 4 COMPETENCIAS

TRACK TEST COMPRENSIÓN LECTORA

5 días hábiles

4 meses

4 meses

7 días hábiles

15 días hábiles

4 meses

7 días hábiles

15 días hábiles

8 días hábiles

8 días hábiles

| Examen | Valor |
| --- | --- |
| Track Test 4 Competencias presencial | $ 380.000 |
| Track Test 4 Competencias virtual | $ 430.000 |
| Track Test Comprensión Lectora | $ 275.000 |
| Repetición Track Test presencial | $ 185.000 |
| Repetición Track Test virtual | $ 233.000 |
| Aptis for Teachers | $ 412.500 |
| Aptis for Teachers docentes EAFIT | $ 320.000 |
| Aptis General | $ 412.500 |
| Oxford Test of English | $ 486.000 |
| Oxford Test of English una sola habilidad | $ 204.000 |
| TOEFL | $256 dólares |
| IELTS | $ 1.045.700 |
| PLIDA | $ 770.000 |
| CELPE-BRAS | $ 504.000 |

_*Ten en cuenta que estos precios pueden variar en función de tu ubicación y están sujetos a cambios._

**Valores de exámenes de otros idiomas diferentes al inglés a través de nuestra página web.**

​Días antes de presentar la prueba, te llegará un correo electrónico con la citación oficial al examen y las instrucciones que debes seguir para presentarlo.

Para todos, siempre deberás presentar tu documento de identidad ORIGINAL.

Dependiendo si tu examen es a lápiz o a computador deberás traer implementos tales como: lápiz mina # 2, borrador, sacapuntas, lapicero negro.​

**Acceso peatonal:** por la portería de Argos, Las Vegas e Idiomas.​

**Acceso vehicular:** p la portería sur sobre la Avenida las Vegas después de Macrollantas, la del Plástico y del Caucho sobre la Av. Regional y la de Idiomas.

**Acceso de motocicletas:** por la portería sur sobre la Avenida las Vegas después de Macrollantas y la de Idiomas.

Debes tener en cuenta que el pico y placa también rige dentro de la Universidad.

**Valor parqueadero carros** $ 6.000 el día

**Valor parqueadero motos** $ 3.000 el día​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate