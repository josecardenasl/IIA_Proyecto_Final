# Programa de inglés para niños y niñas - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Programa de inglés para niños y niñas

### Edad 4 a 11 años

Metodología participativa con resultados reales que desarrollan habilidades cognitivas y sociales.

*    Programa de Inglés Para Niños y Niñas 

> ###### Nuestra enseñanza ha evolucionado para que​ nuestros estudiantes a través de los idiomas encuentren propósitos, se conecten con otras formas de ver el mundo y se involucren en dinámicas interculturales que les permita vivir experiencias significativas. ​

### Dirigido a

niños desde los 4 a los 11 años.​​

### Duración del programa

42.5 horas por curso

Generalidades sobr​e el curso

Con clases lúdicas, profesores altamente calificados y un método de enseñanza a través de experiencias diversidad vivimos la magia de los idiomas.

Nuestra misión, además del aprendizaje del idioma, es entregarle a los más pequeños herramientas para que construyan su futuro, se comuniquen y logren desenvolverse en un mundo intercultural.

El programa de inglés para niños está diseñado teniendo en cuenta la edad de los estudiantes, su desarrollo cognitivo y el nivel de suficiencia en el idioma objetivo.

Inversión

## Inglés para niños de 4 años

English Stars $896.000

## PreK1 y PreK2

Inglés para niños entre 5 y 6 años:

 Poblado y Sur (lunes): $1.130.000

 Sede Sur, Belén, Laureles y Poblado: $1.190.000

 Poblado (viernes- sábado): $1.330.000

 Sede Llanogrande: $1.156.000 ​

## Kids y Kids Plus

​Inglés para niños entre 6 y 10 años

 Poblado y Sur (lunes): $1.130.000​

 Sede Sur, Belén, Laureles y Poblado: $1.300.000

 Poblado (viernes- sábado) $1.428.000

 Sede Llanogrande $1.270.000 ​

1.   ​Este valor no incluye el texto.​
2.   En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando no cumpla con el número mínimo de estudiantes requeridos.

Metodología

Nuestra metodología EDC busca promover en los niños y niñas su desarrollo como individuos completos, capaces de enfrentar el mundo con curiosidad, confianza y creatividad.

Nuestro enfoque en la enseñanza a través de actividades lúdicas y apropiadas para su edad garantiza que los estudiantes no solo adquieran habilidades lingüísticas, sino que también desarrollen una relación positiva y duradera con el idioma. ​

###### Beneficios de la metodología EDC:

1.   Promover el desarrollo del pensamiento critico.
2.   Fomentar la creatividad y la imaginación.
3.   Desarrollar la resolución de problemas.
4.   Reforzar la indagación y la experimentación Impulsar las habilidades socio-afectivas y comunicativas.​​

1.   Promover el desarrollo del pensamiento critico.
2.   Fomentar la creatividad y la imaginación.
3.   Desarrollar la resolución de problemas.
4.   Reforzar la indagación y la experimentación Impulsar las habilidades socio-afectivas y comunicativas.​​

Calendario 2026

###### **2 cursos por año, 2,5 horas semanales**

**Lunes**

**Sede Sur:**4:00 p.m. a 6:30 p.m.

# Tabla de Fechas de Matrículas

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 26 | Junio 1 | Noviembre 10 - Enero 26 |
| Julio 13 | Noviembre 30 | Mayo 25 - Julio 13 |

**Martes​**

**Sede Poblado:**4:00 p.m. a 6:30 p.m. ​

**Sede Sur:**4:00 p.m. a 6:30 p.m.

**Sede Laureles:** 4:00 p.m. a 6:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Junio 2 | Noviembre 10 - Enero 20 |
| Julio 14 | Noviembre 24 | Mayo 25 - Julio 14 |

**Miércoles​**

**Sede Poblado:** 4:00 p.m. a 6:30 p.m. ​​

**Sede Sur:** 4:00 p.m. a 6:30 p.m.

**Sede Belén:**4:00 p.m. a 6:30 p.m. ​

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 21 | Junio 3 | Noviembre 10 - Enero 21 |
| Julio 15 | Noviembre 25 | Mayo 25 - Julio 15 |

**Jueves**

**Sede Poblado:**4:00 p.m. a 6:30 p.m.

**Sede Belén:** 4:00 p.m. a 6:30 p.m.​​​

**Sede Laureles:** 4:0​0 p.m. - 6:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 22 | Junio 4 | Noviembre 10 - Enero 22 |
| Julio 16 | Noviembre 26 | Mayo 25 - Julio 16 |

**Viernes**

**Sede Poblado:** 4:00 p.m. a 6:30 p.m.

**Sede Belén:** 4:00 p.m. a 6:30 p.m.

**Sede Sur:** ​4:00 p.m. a 6:30 p.m.

**Sede Laureles:** ​4:00 p.m. a 6:30 p.m. ​

**Sede Llanogrande:** ​4:00 p.m. a 6:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 23 | Junio 5 | Noviembre 10 - Enero 23 |
| Julio 17 | Noviembre 27 | Mayo 25 - Julio 17 |

**Sábados**

**Sede Poblado:** 8:00 a.m. a 10:30 a.m. / 10:30 a.m. a 1:00 p.m. / 1:30 p.m. a 4:00 p.m.

**Sede Sur:** ​8:00 a.m. a 10:30 a.m. / 10:30 a.m. a 1:00 p.m. / 1:30 p.m. a 4:00 p.m.

**Sede Belén:**8:00 a.m. a 10:30 a.m. / 10:30 a.m. a 1:00 p.m.

**Sede Laureles:** 8:00 a.m. a 10:30 a.m. / 10:30 a.m. a 1:00 p.m.

**Sede Llanogrande:** 8:00 a.m. a 10:30 a.m. / 10:30 a.m. a 1:00 p.m.​

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 24 | Junio 6 | Noviembre 10 - Enero 24 |
| Julio 18 | Noviembre 28 | Mayo 25 - Julio 18 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos.**

***Los cursos de inglés para niños no tienen clase durante estos días:**

Semana Santa

20 de abril

Semana de receso escolar.

# Políticas de Idiomas EAFIT

Lo que debes saber

Asegura tu cupo pagando la liquidación**dentro de las fechas indicadas** en la factura del curso.

En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos**.

Los materiales **no** están incluidos en la inversión por curso. Será tu compromiso adquirirlos y llevarlos a las sesiones de clase.

Si cuentas con alguna situación que limite tu movilidad en la sede o requieres adaptaciones especiales, puedes informarlo a través de [idiomas@eafit.edu.co](mailto:idiomas@eafit.edu.co)

Ten en cuenta

**Ningún descuento es acumulable** con otros descuentos, ni se reconocerá después de haber realizado el pago.

Para aplicar un descuento por primera vez **es necesario presentar el soporte del descuento a aplicar** en módulos de información y matrícula o enviar un correo a [idiomas@eafit.edu.co](mailto:idiomas@eafit.edu.co)

Políticas y reglamentos

## Política de tutoría

## Política del club de conversación

## Política de devoluciones y saldos a favor

## Política segundo calificador

## Política de descuentos y convenios

## Protocolo de asistencia

## Política de Exámenes Supletorios

Clasificaciones

**​​Prueba de clasificación para aspirantes de Idiomas EAFIT​**

El primer paso para inscribirte, es conocer cuál es el nivel ideal para ti. Para ello debes realizar una cita de clasificación, solicítala así:

1. Ingresa [aquí.](https://view.genially.com/683493012034b378cff3aed5/guide-clasificaciones)

2. Selecciona la edad del estudiante **Niños y niñas 5 a 11 años.**

3. Selecciona el idioma **inglés.**

4. Elige la **sede**donde quieres realizar la prueba de clasificación.

5. Ingresa al enlace, elige la fecha y hora de tu preferencia.

6. Diligencia tus datos en el formulario de registro.

7. Asiste a la cita de clasificación en la sede y horario seleccionado.

**Políticas de las clasificaciones**

1.   ​​​​Para el cambiar del programa de niños al de jóvenes y del programa de jóvenes al de adultos debe solicitar una cita de clasificación.
2.   Sin excepción, la clasificación es obligatoria cuando han pasado más de 6 meses calendario en los programas de adultos y 8 meses calendario en los programas de niños y jóvenes, entre la fecha de finalización del último curso en Idiomas EAFIT y la fecha de iniciación del próximo.
3.   ​Es indispensable presentar un documento de identificación original con foto.
4.   ​La solicitud de citas para realizar el examen de clasificación debe hacerse en la línea telefónica 2619500 opción 1 y luego opción 2.
5.   El examen de clasificación no es válido como control de bilingüismo.

**Prueba diagnóstica de inglés para estudiantes nuevos de EAFIT​**

Con el fin de ofrecerte el mejor inicio posible en tus estudios académicos, en Idiomas EAFIT nos hemos unido a tu proceso de inducción con el objetivo de medir de manera aproximada tu nivel de suficiencia en el idioma inglés, al momento de ingresar a tu programa de pregrado.

El examen de clasificación de Idiomas EAFIT es una prueba en inglés diseñada con el propósito de hacer un diagnóstico de tus conocimientos previos en el idioma, específicamente de vocabulario y estructura. Esta prueba podrá ser tomada en línea, de manera asincrónica y de forma individual.

La prueba está dividida en tres (3) partes. Para pasar de una parte a otra deberás obtener al menos un ochenta (80%) porciento de aciertos, de lo contrario el examen terminará automáticamente.

La duración está entre quince (15) y cuarenta (40) minutos y esto dependerá del nivel que cada uno tenga; es decir, quince (15) minutos si solo tomas la Parte 1 o cuarenta (40) minutos si avanzas hasta la Parte 3. Muy importante que por favor leas el paso a paso del instructivo para que así puedas acceder a la prueba sin inconvenientes. Finalmente, la prueba deberá ser tomada desde un computador de escritorio o portátil. No deberás utilizar celular para tomar la prueba.​

Métodos de pago y devoluciones

**Métodos de pago​​​​​**

Después de haber realizado la inscripción y contar con la factura correspondiente podrá realizar el pago en:

1.   En línea: con tarjetas crédito o débito a través del autoservicio del estudiante en [www.eafit.edu.c​o/epik](https://www.eafit.edu.co/epik)
2.   En efectivo o cheque: debe imprimir la factura en impresora láser para realizar el pago en los bancos Bancolombia, Av villas​, Banco de Occidente y Davivienda.
3.   Con tarjeta débito y crédito: en los módulos de Información y Matrículas de Idiomas EAFIT.
4.   Mixtos (efectivo-tarjeta): se deben efectuar en las oficinas de tesorería de la Universidad EAFIT en el bloque 29 piso 1.
5.   Tenga en cuenta verificar su factura antes de realizar el pago, en caso de contar con algun descuento para ver que efectivamente este aplicado en la factura. Recuerda que ningún descuento es acumulable, ni se reconocerá después de haber realizado el pago.​

**Política de devoluciones y saldos a favor**

**Devoluciones**

Es un reembolso al estudiante o a los acudientes del dinero pagado por concepto de matrícula.

1.   Se realizará devolución del 100% del valor pagado únicamente cuando el participante solicita la devolución antes del inicio del curso, se cancela el curso por no cumplir con el número mínimo de participantes por grupo, o Idiomas EAFITlo cancela por cualquier otro motivo.
2.   Se realizará devolución del 80% del valor pagado cuando la persona se retira antes de transcurrir el 20% de las horas de clase por motivos laborales, de salud o traslados de ciudad y presenta el respectivo respaldo en los cinco (5) días hábiles siguientes de que se presente la eventualidad que le impide continuar el curso.
3.   Transcurrido el 20% de las horas de clase no se realizará devolución de dinero. 

Para la solicitud de la devolución, el estudiante debe presentar el recibo de pago original. Para devoluciones originadas por solicitud del participante se descontará el valor de la comisión bancaria si el pago fue mediante tarjeta débito o crédito.

**Saldos a favor**

Corresponde al valor pagado por un curso que no se puede terminar para retomarlo posteriormente.

1.   Se generará un saldo a favor del 100% del valor pagado si el participante solicita la suspensión del curso por motivos laborales, de salud o traslados de ciudad antes de transcurrir el 20% de las horas de clase del curso y presenta el respectivo respaldo en los cinco (5) días hábiles siguientes de que se presente la eventualidad que le impide continuar el curso.
2.   Se generará un saldo a favor del 80% del valor pagado si el participante solicita la suspensión del curso por motivos laborales, de salud o traslados de ciudad después de transcurrir el 20% pero menos del 30% de las horas de clase del curso y presenta el respectivo respaldo en los cinco (5) días hábiles siguientes de que se presente la eventualidad que le impide continuar el curso.
3.   Transcurrido el 30% de las horas de clase no se otorgarán saldos a favor.

Los saldos a favor pueden transferirse a otra persona con autorización escrita del titular del mismo y tienen vigencia de dos (2) años a partir de la fecha de la aprobación y no son reembolsables.

Si al momento de hacer uso de un saldo a favor el curso a tomar tiene un valor mayor a dicho saldo, el participante debe pagar el excedente. Si por el contrario el valor del curso es menor al saldo, el valor restante se conservará como saldo a favor.

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate