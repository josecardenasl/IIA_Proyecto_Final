# Geology - EAFIT

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Accessibility

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Language

Powered by [![Image 19: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Search 

Search

Menu

Undergraduate

# Geology

SNIES 1251, Medellin

The country is your great classroom. Colombia is one of the most interesting and rich countries from the geological point of view: we have three mountain ranges, 21 active volcanoes, an average of 2500 earthquakes per month (30,000 thousand a year!), The three types of rocks that allow us to obtain different minerals and types of energy, two oceans, six glacier areas, hundreds of rivers and, as if it were little, several hundred cubic kilometers of cubic water (70% of all continental water in the country!). And all that because we are located in a tectonically active area and in the tropics. That combination makes us unique and privileged in the study of geosciences.

Here you will learn to use scientific thinking to understand our planet from an integral point of view: its material composition, its evolution, the forces that mold it, and how all that interrelates with human activities. Geology is the science that helps to understand physical, chemical and biological phenomena that occurred on Earth millions of years ago and that continue to happen. That is why it is a field of knowledge that does not stop, without borders, current and modern despite the fact that its object of study is often the most remote past.

*    Geology 

## Qualified registration

Official Resolution 010063 of June 23, 2023. Validity: 7 years.

## High-quality accreditation

Resolution 010063 of June 23, 2023. Validity: 7 years.

Duration

9 semesters

Location

Medellin

Schedule

Full-time

Language

Spanish

Modality

In Person

SNIES

SNIES: 1251

First Semester Tuition Fee

$15,513,297

Average Semester Tuition Fee

$15,640,967

Scholarships and financial aid

## About the program

Calidad y excelencia

**We are top in the world**

We are the only Geology program in Antioquia with 40 years of experience. Our faculty is comprised entirely of PhDs in various fields, including paleontology, hydrogeology, regional geology, geochemistry, oceanography, tectonics, and coastal geology.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

Nuestra Escuela cuenta con el respaldo de un gran ecosistema de laboratorios: tenemos 43 de ellos equipados con infraestructura de última generación.

Contamos con un bloque nuevo completamente equipado para las ciencias aplicadas y la ingeniería, construido con la idea de generar bajo impacto ambiental, y diseñado para ser sostenible con el uso eficiente de la energía, el cuidado del aire, la gestión de residuos y la movilidad. Todo, integrado al trabajo de investigadores, estudiantes en semilleros y jefes de laboratorio. Configurando un verdadero engranaje de investigación y aprendizaje abierto y a disposición de la comunidad estudiantil.

Nuestro campus es un espacio vivo, activo y natural y un escenario de experimentación y aprendizaje para los temas de biología, diseño, urbanismo, entre otros.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en EAFIT.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Actualmente, estamos trabajando en una reforma al plan de estudios para cada vez acercarnos un poco más a las necesidades del siglo XXI.

Además, contamos con 12 líneas de énfasis para que cada uno elija cómo complementar su desarrollo profesional, entre ellas la Geología regional, Termocronología, Ocronología, Paleomagnetismo, Geoquímica, Cartografía y Estratigrafía, Geología Ambiental, Vulcanología, Gestión del riesgo.

Este programa te ofrece salidas de campo y sesiones prácticas de laboratorio para la complementación y fortalecimiento de los aspectos teóricos que se transmiten en las aulas de clase.

Innovación y liderazgo

**Somos innovación en educación**

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de EAFIT y a las áreas de conocimiento que las componen.

El 100% de nuestros profesores de planta tienen doctorado.

**Cultivamos el liderazgo temprano y la investigación**

En EAFIT tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Como Escuela tenemos más de 20 grupos de investigación y más de 60 semilleros enfocados en la experimentación y el desarrollo de tecnologías prácticas.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Contamos con el Centro de Estudios Urbanos y Ambientales, Urbam, que promueve procesos en los que el conocimiento técnico de lo urbano se conjuga con el saber de las comunidades, transformando el paisaje y las infraestructuras a favor de la sostenibilidad. Esto les da entrada a nuestros estudiantes al conocimiento de primera mano de profesionales con experiencia y trayectoria en los temas de planeación urbana, decisión en el ámbito público e incidencia en las empresas y organizaciones privadas que tienen que ver con estos temas.

Trabajamos de la mano con NODO, el centro de formación en tecnologías de EAFIT, un espacio donde se transforma el talento y se pone al servicio de los retos reales de las organizaciones, creando procesos de aprendizaje práctico y exponencial en temas relacionados con desarrollo web.

Disponemos de una revista de Ingeniería y Ciencia que presenta y difunde trabajos de investigación básica y aplicada que contribuyen al desarrollo de la tecnología, la ciencia y la industria.

Contamos con centro de estudios e incidencia, Valor Público y con un espacio de innovación y desarrollo social: EAFIT Social.

En EAFIT tenemos una línea especial de Gerencia y empresa que presta consultoría y, también, a ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

Como graduado tendrás un campo de acción profesional amplio, desde espacios clásicos como la minería y la generación energética, hasta el campo de la mitigación y adaptación al cambio climático.

**Somos una puerta al mundo**

Este programa te ofrece salidas de campo y sesiones prácticas de aplicación científica.

Como universidad contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrados han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores start-ups de Colombia.

## Curriculum

## Teachers

## Get to know our school

## Saber Pro Tests

## Guide for undergraduate applicants

Fechas y guía de inscripción

###### Dates and registration guide

Your admission will depend on meeting the established requirements within the dates listed below. If you wish to apply for a scholarship with EAFIT, you must complete and pay your registration fee before 11:59 pm on May 9, 2025.

If you register before April 12, 2025, you will find out the admission result from April 25 onwards.

Si realizas tu inscripción antes del 9 de mayo de 2025 conocerás el resultado de admisión a partir del 16 de mayo.

Si realizas tu inscripción antes del 30 de mayo de 2025 conocerás el resultado de admisión a partir del 6 de junio.

Si realizas tu inscripción antes del 17 de junio de 2025 conocerás el resultado de admisión a partir del 3 de julio.

Conoce la guía de inscripción para que sepas cómo consultar tu horario de clase, cómo asistir a tu inducción, cómo tramitar tu carné de estudiante, entre otros procesos.

Aplica a tu pregrado

###### Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en el este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario.
3.   Realiza el pago de $212.600 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

###### Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

###### Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Begin your registration process

The process has a cost of $212.600 COP.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Civil Engineering

Duration

9 semesters

Location

Medellin

Schedule

Full-time

Language

Spanish

Modality 

In Person 

SNIES

SNIES 1247

First Semester Tuition Fee

$ 14,938,731

Average Semester Tuition Fee

$ 14,811,038

Scholarships and financial aid

#### Urban Design

Duration

9 semesters

Location

Medellin

Schedule

Full-time

Language

Spanish

Modality 

In Person 

SNIES

SNIES 109454

First Semester Tuition Fee

$ 13,789,597

Average Semester Tuition Fee

$ 13,406,543

Scholarships and financial aid

## **Nuestros graduados**

## Catalina Arroyave Restrepo

Cineasta

“Tuve profesores críticos, apasionados y rigurosos que me dieron una visión de la comunicación y el periodismo que sentó las bases de toda mi carrera profesional".

## Raquel Yepes Saldarriaga

Directora de comunicaciones y reputación en Argos

“El pregrado ofrece un enfoque multidisciplinario que me permitió tener los mejores docentes y maravillosas experiencias prácticas, al tiempo que se promueven otras actividades que van más allá del pregrado".

## Andrés Pastrana Cuartas

“Lo que más valoro es que encontré mi amor por la escritura y eso fue gracias a la diversidad de conocimientos que adquirí y que me mostraron cómo ponerla en práctica. También a que me retaron a crear un producto excelente y no solo cumplir por cumplir".

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

May 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

May 13, 2026

## Global debate with a student touch

April 7, 2026

Study at EAFIT

Connect with EAFIT

Contact us

Legal information

Institutional Accreditation until 2026. 

Supervised by Ministry of Education.

Our campuses

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National line: 01 8000 515 900

Service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Service line: (57) 606 3214115, 606 3214119

Carrera 15 #88-64 office 401

Service line: (57) 601 6114618

Km 3.5 via Don Diego – Rionegro

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks

Original text

Rate this translation

Your feedback will be used to help improve Google Translate