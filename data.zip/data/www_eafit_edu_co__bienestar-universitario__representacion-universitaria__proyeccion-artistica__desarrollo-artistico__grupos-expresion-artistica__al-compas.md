# Grupo de bailes Al Compás

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Al Compás EAFIT​

Director: Edwin Jair Granada

*    Grupo de Bailes Al Compás 

### Acerca de Al Compás

El Grupo de bailes de salón Al Compás de la Universidad EAFIT está conformado por estudiantes, empleados y egresados de la Universidad EAFIT. El repertorio del grupo hace énfasis en bailes de salón como el tango, la salsa, bachata, la milonga, el porro y el pasodoble, además de ritmos tradicionales y considerados los bailes de salón.

Los integrantes del grupo Al Compás entenderán los principales beneficios de la práctica del arte de la danza en la vida estudiantil, ante todo, exponer cómo la danza aporta al desarrollo de habilidades y destrezas las que a su vez contribuyen a la obtención de un mejor rendimiento académico.

Quienes hagan parte del grupo aprenderán sobre habilidades y destrezas aplicables no solo en una puesta en escena, sino para su vida social y en el ejercicio de las diversas profesiones. Otros beneficios serán el fortalecimiento de valores, como la tolerancia, la disciplina, la responsabilidad, la solidaridad. Además, la adquisición de habilidades como la planificación de actividades, trabajo en equipo, gestión, administración del tiempo, dirección de grupo, entre otras. Pero el bien principal que puede dejar la danza es el equilibrio de los estados anímicos y emocionales.

Este Grupo empezó sus actividades en febrero de 1998, bajo la dirección de César Orozco Castrillón y con el nombre de Grupo de baile Estilos. Desde entonces los objetivos de esta actividad apuntan a lograr la consolidación de un Grupo que pueda representar a la Universidad en diversos eventos, y, a la vez, tener un espacio para que los integrantes puedan reproducir y expresar por medio del baile sus sentimientos, vivencias y emociones.

Al Compás ha realizado diversas presentaciones en eventos culturales, académicos y especiales de la Universidad, en sus campus de Medellín y Llanogrande. En la ciudad ha participado en eventos como las Lunadas Universitarias organizadas por el INDER y en los Festivales de Danza Universitaria organizados por Ascuncultura, eventos en los que Al Compás ha obtenido logros significativos, como el primer lugar en 2017, 2018 y 2019 en el encuentro regional universitario de Salsa y Bachata.

En el año 2019 representó al Departamento en el Encuentro Nacional de danzas ofrecido por la UPTC en la ciudad de Tunja.

En 2020, llega a la dirección el bailarín Jair Granada quién continúa con el proceso adelantado por el Grupo e incorpora nuevos géneros de los bailes de salón.

En el año 2022 obtienen el segundo lugar del Encuentro Regional de Salsa y Bachata en la modalidad de salsa grupos.

Todo participante que desee ser parte de Al compás, debe pasar primero por el semillero de bailes de salón donde se realizará una evaluación de su conocimiento y desempeño para ser promovido. Una vez el grupo cuente con la posibilidad de recibir nuevos integrantes, serán tenidos en cuenta quienes tengan y demuestren un mayor avance.

###### Horario y lugar de ensayo del grupo:

Lunes y miércoles de 6:00p.m. a 9:00 p.m.

Aula de ensayo de baile: 12-201​.

###### Semillero de danza folclórica

Este espacio está creado para dar una formación en corporalidad que se alinee hacia los movimientos del baile de salón, desarrollo del oído musical y se realiza un acercamiento a los montajes coreográficos de escenario.

###### Ensayos del semillero

Viernes 2:00p.m. a 4:00 p.m. ​Aula de ensayo de baile: 12-201.

##### Requerimientos técnicos y logísticos para presentaciones:

El espacio requerido para las presentaciones del Grupo es de mínimo 8mtrs x 8 mtrs., con piso en madera o baldosa, o en su defecto una tarima. No es conveniente bailar en pisos de granito o cemento porque se pueden presentar lesiones y problemas en las rodillas de los bailarines.

Adaptar cerca del lugar de la presentación un espacio cubierto con área suficiente para 20 personas y el vestuario correspondiente de cada una de ellas.

Si la presentación es en la noche se requieren luces para el espectáculo.

Transporte ida y regreso.

Brindar refrigerio e hidratación a cada uno de los integrantes del Grupo.

Garantizar una buena amplificación de sonido que incluya mínimo dos retornos.

Debe realizarse montaje y ensayo de sonido, mínimo 30 minutos antes de la presentación del Grupo.

Empezar el programa a la hora señalada, para cumplir con el tiempo de presentación del grupo, dado que los integrantes son en su mayoría estudiantes, que deben cumplir con otros compromisos académicos.

Contar con un presentador que haga la respectiva presentación del Grupo, o posibles intervenciones a lo largo de la presentación y el cierre de la misma al finalizar.​

**Cualquier información adicional, será atendida en el correo**[dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co).

### En acción​

## Síguenos en nuestras redes sociales

### Facebook

### Instagram

### X

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate