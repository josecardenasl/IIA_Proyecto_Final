# Muestras artísticas eafitenses

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Políticas muestras de expresión artística eafitenses aficionados

*    Políticas Muestras de Expresión Artística Eafitenses Aficionados 

​Las Muestras de expresión artística son unos espacios destinados exclusivamente para trabajos de corte artístico aficionado de estudiantes de pre y posgrado, empleados administrativos, docentes, egresados de pre y posgrado y jubilados de la Universidad EAFIT.​

Los trabajos pueden ser presentados en formato suelto como pintura, dibujo, grabado, fotografía, etc., o enmarcados por el autor. En el caso de formato suelto, Desarrollo Artístico cuenta con 20 marcos temporales en formatos estándar de 30 x 50 cm. y 70 x 50 cm.

De los trabajos presentados por los eafitenses se seleccionará cada mes un máximo de 20 a criterio de los organizadores del montaje en el Bloque 12.

En caso de incurrirse en costos de empaque, transporte y reempaque de los trabajos, esto correrá por cuenta del eafitense.

La Universidad no asegurará los trabajos; en caso que el participante desee asegurar sus trabajos, este seguro correrá por su cuenta.

En caso de pérdida o daño de las obras se le notificará por escrito al eafitense.

Las obras se mostrarán bajo techo en el interior del Departamento de Desarrollo Artístico, bloque 12, que cuenta con un adecuado sistema de seguridad y vigilancia.

El participante deberá firmar un documento con el cual deja constancia de que entiende y acepta las políticas de este servicio que brinda el Departamento de Desarrollo Artístico como un apoyo a la calidad de vida de la comunidad eafitense.​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)