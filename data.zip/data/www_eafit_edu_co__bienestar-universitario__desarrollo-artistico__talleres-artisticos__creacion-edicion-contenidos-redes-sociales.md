# Creación y edición de contenidos para redes sociales

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Creación y edición de contenidos para redes sociales – 20 horas

Inscripciones primer semestre de 2026: A partir de las 8:00 a.m. del 26 de enero

*    Creación y Edición de Contenidos Para Redes Sociales – 20 Horas 

###### Taller dirigido: Estudiantes, graduados​, profesores, empleados y pensionados de la Universidad EAFIT y sus familiares (padres, hijos, hermanos y esposo o compañero permanente). ​​

Si eres estudiante, empleado, profesor o pensionado, al inscribirte en el Taller aceptas la Política de los Talleres Artísticos, por lo tanto ten en cuenta que deberás administrar tus faltas de asistencia. Al momento de incumplir con el 80% de asistencia a tu Taller, el sistema te generará una cuenta de cobro por el costo total del taller, sin descuento ninguno.

La idea de este taller es fomentar la creación de contenido de valor y promover la inmersión en la era digital con propósito, incentivando a las personas a aprender sobre edición de contenido, ADN de marca, cómo superar el bloqueo creativo e innovar materializando ideas, ya sea para una marca personal o un emprendimiento.

Presentación de contenidos sesión a sesión:

**Primera sesión:** Presentación de todos los participantes del curso. Además, se abordarán preguntas como: ¿qué los motivó a ser parte del taller?, ¿cuál es su propósito con las redes? y ¿para ser un crack en la creación de contenido se requiere motivación, constancia, disciplina o seguidores?.

Familiarización de las plataformas: Meta: facebook, instagram, threads y whatsapp. Tiktok. X. Linkedin. Youtube. Pinterest.

**Segunda sesión:**

Adn de marca:

1.   Propósitos: marca personal o empresa.
2.   Pilares.
3.   Valores.
4.   Adjetivos.
5.   Personificación.
6.   Identificar el nicho o público.
7.   Conexión con la comunidad.
8.   Tono.
9.   Parrilla de contenido.
10.   Equipos básicos

**Tercera sesión:**Apps que debes conocer para editar contenido e historias dinámicas.

VN, Insot, Edits, Instagram, entre otras.

**Cuarta sesión:**Storytelling, contar historias con propósito.

Como ser la tendencia y no ser uno más del trend.

**Quinta sesión:**Práctica, pauta y roles en la creación de contenido.

**Sexta sesión:** Cap Cut free y pro. 

Edición de video

Superposición

Subtítulos automáticos

Animación de clips

Extraer audio

Agregar texto de más, stickers o dibujos

Reducir ruido y mejorar calidad

Efectos

Nodos y curvas

Añadir sonidos y marcas de agua

Capas, ilustración y transiciones dinámica

**Séptima sesión:**Guión técnico, planos, formatos de videos, dimensiones, luces, transiciones en tiempo real, bancos de sonidos, tipografías, overlays y recursos adicionales.

Colorimetría, tipos de planos (medio, corto, gran plano, general, entre otros), detalles, ángulos de cámara, tendencias y demás. Complemento de ejemplos, videos cortos de cada ítem.

**Octava sesión: Práctica:**Configuración de cámara del teléfono para mejor calidad y explicación breve de los fotogramas. Fotografía para post e historias.

Ley de tercios y recomendación de apps para editar como Lightroom, Vasco y funciones del teléfono.

Parrilla completa y caso de una marca, estrategia, error, recomendación.

**Novena sesión:** Métricas, monetización, estadísticas en apps como instagram y tiktok.

Importancia de crear comunidad y la acción masiva imperfecta.

Tendencias, análisis de branding y creadores que han sabido destacar en redes.

Análisis, sugerencias y edición de la información en los perfiles.

**Décima sesión:** Presentación de un proyecto final en formato video con diferentes temáticas a elegir: producto, storytelling, voz en off, transiciones, entre otros.

Despedida y agradecimiento.

​Computador portátil, celular y/o tablet​

**Aula: 12-101**

**Horario​:​**

Grupo 1:

Fecha inicio: martes, 10 de febrero de 2026

Fecha fin: martes, 21 de abril de 2026

Hora: 2:00 p. m. a 4:00 p. m.

Día: Martes

Facilitador(a): María Isabel Henao

Grupo 2:

Fecha inicio: miércoles, 11 de febrero de 2026

Fecha fin: miércoles, 22 de abril de 2026

Hora: 10:00 a. m. a 12:00 m.

Día: Miércoles

Facilitador(a): María Isabel Henao

Inversión estudiantes de los programas de pregrado y posgrado, profesores y empleados de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

Inversión egresados y graduados de pregrado y posgrado de la Universidad EAFIT: $152.500

Inversión familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado, y de egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT: $152.500

Inversión participantes activos del programa Saberes de Vida: $152.500

Inversión participantes activos de Educación Continua EAFIT o Idiomas EAFIT: $244.000

Costo total del taller a pagar por inasistencia (estudiantes y empleados): $305.000

​​Si eres estudiante de pre y posgrado, profesor y empleado de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

###### Inscripciones a partir de las 8:00 a.m. del 26​ de enero de 2026

Cómo inscribirse en los Talleres Artísticos

### 1

Los talleres artísticos están dirigidos a sus estudiantes, graduados, empleados y pensionados de EAFIT y sus familiares*.

### 2

Elige del menú el taller que quieres cursar y dale clic.

### 3

Lee el contenido del programa, revisa los horarios disponibles y las políticas de los talleres artísticos.

### 4

El día y la hora señalada de inicia de inscripción, será el momento en que se habiliten las opciones de talleres artísticos. Si ingresas antes, no verás opciones de talleres a elegir.

### 5

Una vez ingreses al link de inscripciones, digita tu documento de identidad y sigue la ruta: “Matriculas – Talleres”, y allí buscas el semestre actual.

### 6

Valida que la opción del taller que quieres realizar se encuentre habilitada, la seleccionas y das clic en “Registrarse”.

### 7

Si no encuentras habilitado el taller que quieres cursar, es porque ya se agotaron los cupos.

### 8

Si eres estudiante, empleado o pensionado de EAFIT, debes generar la liquidación para quedar inscrito.

### 9

Si eres graduado o familiar de eafitense, debes generar la liquidación y realizar el pago por los canales establecidos.

*Los familiares corresponden a: padres, hijos, hermanos y esposo o compañero permanente. Tener presente las políticas de los talleres artísticos. Programar muy bien las fechas en que se cursa el taller para hacer un adecuado aprovechamiento de los beneficios que otorga la Universidad. Si al momento de realizar la inscripción no encuentras el taller de tu elección es porque este ya cuenta con cupos disponibles.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)