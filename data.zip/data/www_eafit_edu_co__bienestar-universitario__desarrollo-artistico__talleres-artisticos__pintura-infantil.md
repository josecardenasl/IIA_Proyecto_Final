# Pintura infantil

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Pintura infantil - 24 horas. A partir de 5 años de edad

Inscripciones primer semestre de 2026: A partir de las 8:00 a.m. del 26 de enero

*    Pintura Infantil - 24 Horas. A Partir de 5 Años de Edad 

###### ​​​​​​​​​​​​​​​​​​Solo para: Hijos y hermanos de estudiantes, graduados de los programas de pregrado y posgrado, y empleados de la Universidad EAFIT.

Aprovechando sobre todo la capacidad creadora del niño, quien no se limita a copiar formas y figuras pre establecidas sino que le da vuelo a su imaginación, y a la manera tan particular que tiene de entender el mundo que lo rodea, en este Taller los niños son animados a explorar al máximo su capacidad creativa, conforme van descubriendo (gracias al placer de los colores) distintos materiales de trabajo y distintas técnicas pictóricas.

En el Taller de Pintura infantil, el niño es libre de elegir por sí mismo —y desde su propia capacidad expresiva— una o varias propuestas estéticas, para hacerlas realidad con el acompañamiento del facilitador. El Taller está enfocado en el desarrollo de la conexión cerebro-mano, la cual nos permite proveer al niño de la capacidad de poder dibujar, componer y crear, así como representar desde las líneas, las texturas y formas geométricas todo aquello que ve en un principio y todo aquello que pueda imaginar. Así entonces, el contenido que aparece a continuación es, en términos generales, un paisaje de exploración por el cual andará el pequeño pintor durante sus primeros años de conocimiento interior.

​​Conocimiento de los materiales: pastel, pinceles, vinilos, acrílicos, papel.

Módulos básicos de dibujo: cómo crear un boceto, composición, encuadre y transición del dibujo al lienzo para poder ser pintado.

Cómo se mezclan los colores primarios, y el blanco y el negro. Teoría del color.

Cuáles son los diferentes planos que se manejan sobre el papel, cómo debe y en qué orden es pintado un cuadro.

Tipos de pinceles y herramientas para pintar y su uso adecuado, así como su cuidado.

Los implementos básicos que todo niño debe traer, desde el primer día, para el desarrollo del Taller son:

Un block Pinares de 35 x 50 cms., bond base 30.

Un lápiz 2B. 

Un borrador de miga de pan.

Vinilos de colores básicos (amarillo, rojo, azul, blanco y negro), en frascos de plástico.

Pinceles planos y redondos, números 10, 6, 4 y 2. 

Una brocha plana de 1.5”

Un pincel delineador 00.

Delantal

Trapo para limpiar

Paleta plástica para pintura 10 colores

Coquita plástica para el agua

**Aula: 12-102**

**Horario​:​**

**Grupo 1: Niños de 5 a 8 años**

Fecha inicio: sábado, 14 de febrero de 2026

Fecha fin: sábado, 6 de junio de 2026

Hora: 9:00 a. m. a 10:30 a. m.

Día: Sábado

Facilitador(a): Jhon Fernando Muñoz

**Grupo 2: Niños de 9 a 12 años**

Fecha inicio: sábado, 14 de febrero de 2026

Fecha fin: sábado, 6 de junio de 2026

Hora: 11:00 a. m. - 12:30 p. m.

Día: Sábado

Facilitador(a): Jhon Fernando Muñoz

Inversión hijos y hermanos de estudiantes, egresados, graduados de los programas de pregrado y posgrado, profesores, empleados de la Universidad EAFIT: $218.500

Costo total del taller: $437.000

​​Si eres estudiante de pre y posgrado, profesor y empleado de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

###### Inscripciones a partir de las 8:00 a.m. del 26​ de enero de 2026

Cómo inscribirse en los Talleres Artísticos

### 1

Los talleres artísticos están dirigidos a sus estudiantes, graduados, empleados y pensionados de EAFIT y sus familiares*.

### 2

Elige del menú el taller que quieres cursar y dale clic.

### 3

Lee el contenido del programa, revisa los horarios disponibles y las políticas de los talleres artísticos.

### 4

El día y la hora señalada de inicia de inscripción, será el momento en que se habiliten las opciones de talleres artísticos. Si ingresas antes, no verás opciones de talleres a elegir.

### 5

Una vez ingreses al link de inscripciones, digita tu documento de identidad y sigue la ruta: “Matriculas – Talleres”, y allí buscas el semestre actual.

### 6

Valida que la opción del taller que quieres realizar se encuentre habilitada, la seleccionas y das clic en “Registrarse”.

### 7

Si no encuentras habilitado el taller que quieres cursar, es porque ya se agotaron los cupos.

### 8

Si eres estudiante, empleado o pensionado de EAFIT, debes generar la liquidación para quedar inscrito.

### 9

Si eres graduado o familiar de eafitense, debes generar la liquidación y realizar el pago por los canales establecidos.

*Los familiares corresponden a: padres, hijos, hermanos y esposo o compañero permanente. Tener presente las políticas de los talleres artísticos. Programar muy bien las fechas en que se cursa el taller para hacer un adecuado aprovechamiento de los beneficios que otorga la Universidad. Si al momento de realizar la inscripción no encuentras el taller de tu elección es porque este ya cuenta con cupos disponibles.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)