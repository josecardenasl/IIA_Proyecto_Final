# En red con la media técnica

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# ​En red con la media técnica​

*    Paginas 
*    En Red Con La Media Técnica 

La Red de Media Técnica en Informática de Antioquia agrupa las instituciones educativas del departamento que poseen media técnica en áreas afines con las tecnologías de la información. Su objetivo principal es generar procesos de calidad en la formación de los estudiantes.

La Red surgió en 1995 gracias a una alianza entre la Universidad EAFIT, el Sena y tres instituciones públicas iniciales, con un sentido de proyección social y con la idea de que la educación fuera pertinente, innovadora y moderna en relación con las TI. Se llegó de forma directa a los profesores para mejorar la calidad de los procesos formativos mediante el fortalecimiento de la relación universidad-instituciones educativas, y luego, a los jóvenes como un canal para impactar en el progreso social de sus territorios.

Como parte de la Red se coordinan y ejecutan varias reuniones al año con los docentes de la media técnica; se organiza el Encuentro Pedagógico de Educación Media Técnica en Informática, en el que se muestran los mejores proyectos de los colegios; y se abren espacios como Enamórate de TIC en las regiones, que en 2019 se adelantó en Donmatías, Santafé de Antioquia y Cisneros, en alianza con Intersoftware y secretarías de educación.

#### ​​La triada

El tema de la media técnica se sigue fortaleciendo con la Alianza Futuro Digital, que integra la triada Educación-Empresa-Estado, conformada por Secretaría de Educación de Medellín, Créame, Intersoftware, Sena, Politécnico Colombiano Jaime Isaza Cadavid, Universidad de Medellín, Institución Universitaria Salazar y Herrera, Institución Universitaria Pascual Bravo y Universidad EAFIT. Desde esta se desarrollan actividades y estrategias para fortalecer los procesos formativos relacionados con la educación básica, media, técnica, tecnológica y profesional, enfocadas a la formación del sector TI.

## Alrededor de 50 Instituciones educativas se encuentran activas en la Red de Media Técnica en Informática en Antioquia.

## 4. Educación de calidad

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)