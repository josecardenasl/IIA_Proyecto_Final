# Grupo musical folclórico La Colombina EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Grupo musical folclórico La Colombina EAFIT

Director: Juan Rafael Granda Ramírez

*    Grupo Musical Folclórico La Colombina EAFIT 

### Acerca de Colombina

El Grupo musical folclórico La Colombina, está dirigido a estudiantes de pregrado y posgrado, empleados y egresados de la Universidad EAFIT. Se forja con la expectativa de representar por sí mismo a la Universidad en festivales y eencuentros dentro del territorio nacional, a la vez que aspira brindarle acompañamiento al Grupo de danza folclórica Contradanza.​

La Colombina inicia su trabajo musical a partir de 2003 y está conformado en su mayor parte por estudiantes y egresados de Música, quienes se reúnen alrededor del folclor como una experiencia complementaria a su vida académica y profesional. Con esta perspectiva, el Grupo ha representado a la Universidad en el tradicional Festival de Gaitas de Ovejas (Sucre), en el Festival del Porro de San Pelayo (Córdoba) y en los 40 años de la Universidad del Norte (Barranquilla), además de otras presentaciones en solitario por distintas instituciones culturales, y como acompañante del Grupo de danza folclórica Contradanza, en distintos eventos académicos.

###### Quienes hagan parte del musical folclórico La Colombina podrán desarrollar:

Trabajo en equipo

Estética

Expresión corporal

Pensamiento crítico

Confianza

Pertenencia

Creatividad

Tolerancia a la frustración

Empatía​

Músico formador egresado de la Epa, Escuela Popular de Artes Sofía Ospina de Navarro, ha dedicado gran parte de sus estudios a la investigación, interpretación y proyección de la música tradicional colombiana, especialmente de la música de los conjuntos de gaitas.

En al año de 1996 inicia actividades de dirección en el grupo de proyección de la Universidad Cooperativa de Colombia y a partir del año 2003 y hasta la fecha, se desempeña como director del Grupo Musical Folclórico La Colombina de la Universidad Eafit, además, se ha desempeñado como profesor de la Electiva de Música Colombiana del Departamento de Música de dicha universidad y como formador en diferentes instituciones educativas del valle de Aburrá.

Cofundador del grupo Canto Arena Gaitas y Tambores, Gaiteros de Medellín, Agua Abajo Mar y Rio, fundador y director de los grupos Gaiteros de Eafit y Gaiteros del Hato Viejo del municipio de Bello.

En el año 2013 participa como asesor del concierto “Gaita Sinfónica" en el cual se realiza una fusión de la música de Gaitas y Bailes Cantaos entre el Grupo Musical Folclórico La Colombina y la Orquesta Sinfónica de la Universidad Eafit, con arreglos del maestro Juan David Osorio y bajo la dirección de la maestra Cecilia Espinosa.

Entre los años 2015 y 2017 participó en el programa de formación del Centro de Desarrollo Cultural de Moravia, como formador de percusión tradicional colombiana. A partir del año 2018 y hasta la fecha se desempeña como director de la Escuela de Música de Moravia (litorales colombianos) del programa Red de Música de Medellín, teniendo bajo su cargo, entre otros, la dirección de la agrupación Taller Caribe y La Banda Pelayera 20 de enero de Moravia.​

Para ser parte del Grupo deberás enviar un correo a [dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co) y estar atento(a) a la respuesta pues tu ingreso dependerá de la capacidad que se tenga para recibir a más personas durante el semestre.

###### Horario y lugar de ensayo del grupo:

Jueves de 5:00 p.m. a 9:00 p.m.

Aula de ensayo musical: 12-203​.

###### Requerimientos técnicos y logísticos para presentaciones:

**Se debe garantizar una buena amplificación de sonido con:**

​​Consola de 24 canales.

Ocho micrófonos para percusión.

Seis micrófonos para voces.

Dos retornos.

Transporte ida y regreso para los integrantes y los instrumentos.

Brindar refrigerio e hidratación a cada uno de los integrantes del Grupo.

Hacer montaje y ensayo de sonido, una hora antes de la presentación del Grupo. ​​

Cinco sillas sin brazos.

Una persona que apoye en el montaje de los instrumentos y rider.

Empezar el programa a la hora señalada, para cumplir con el tiempo de presentación del Grupo, dado que los integrantes son en su mayoría estudiantes, que deben cumplir con sus compromisos académicos.

Contar con un presentador que haga la respectiva presentación del Grupo, o posibles intervenciones a lo largo de la presentación y el cierre de la misma al finalizar.

**Cualquier información adicional, será atendida en el correo**[dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co).

### En acción​

## Síguenos en nuestras redes sociales

### Facebook

### Instagram

### X

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate