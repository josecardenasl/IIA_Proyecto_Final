# Crédito educativo Sufi a corto plazo y libre educativo - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Crédito educativo Sufi a corto plazo y libre educativo

Sufi te presta para que estudies lo que te apasiona

*    Crédito Educativo Sufi A Corto Plazo y Libre Educativo 

Este crédito* te permitirá financiar programas universitarios de pregrado y posgrado, además de cursos de Educación Continua o idiomas, a través de desembolsos para cada uno de los programas académicos que desees.

###### Información general del crédito:

Plazo de pago: de 6, 12, 24 y 36 meses.

Capital que ofrece: desde 700 mil pesos hasta 25 S.M.M.L.V. (Salarios Mínimos Mensuales Legales Vigentes).

El Banco determinará al momento de la aprobación, si es necesario que tu crédito esté respaldado por una fianza a favor del Banco otorgada por un fondo de garantías. *​

Renovación sujeta a políticas de crédito de la Entidad.​

Respuesta en minutos y sin documentos *sujeta a políticas de crédito de la Entidad.​

Desembolsó en línea a la cuenta de la Universidad EAFIT *En algunos casos podrá requerirse estudio de crédito adicional.​

Vigencia créditos aprobados: hasta 15 días calendario para aceptar la oferta y después de aceptada la oferta hasta 30 días calendario para desembolsar.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)