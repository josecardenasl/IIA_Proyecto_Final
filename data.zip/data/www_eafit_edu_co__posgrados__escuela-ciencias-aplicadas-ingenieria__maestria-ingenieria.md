# Maestría en Ingeniería - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Maestría en Ingeniería

SNIES 19886, Medellín

Si tienes un problema de ingeniería en tu empresa o tu actividad profesional cotidiana, este es el programa de posgrado que te permitirá encontrar una solución. Los profesores de la Escuela de Ciencias Aplicadas e Ingeniería de la Universidad EAFIT estarán dispuestos a acompañarte en la solución de las dificultades profesionales, apoyándose en los últimos avances tecnológicos y el saber hacer que se ha construido en más de treinta años de experiencia que lleva el programa.

La Maestría en Ingeniería es un programa flexible que permite adaptar el curriculum de acuerdo con las necesidades del estudiante y el campo de la ingeniería que sea de su interés, combinando las clases magistrales con la práctica en proyectos, con un gran énfasis en el trabajo de grado y la formación básica en investigación, cuyo objetivo es llevar la solución teórica a la realidad.

Si quieres mejorar procesos y solucionar problemas en tu trabajo o en tu empresa y llevar tus negocios un paso más allá, la Maestría en Ingeniería es para ti.

*    Escuela Ciencias Aplicadas Ingenieria 
*    Maestría En Ingeniería 

## Registro calificado

Resolución​​​ 16305 del ​1 septiembre 2020.

Duración

3 semestres

Lugar

Medellín

Horario

Varía según la línea de especialización

Idioma

Español

Modalidad

Presencial

SNIES

SNIES ​19886

Precio total del programa

$55.534.466

## Sobre el programa

Calidad y excelencia

**Programa con Acreditación de Alta Calidad**

Es el reconocimiento que los pares académicos de otras instituciones de educación superior hacen sobre la calidad de nuestro programa académico, sobre nuestra organización, su funcionamiento y el cumplimiento de nuestra labor social. La Maestría en Ingeniería cuenta con acreditación de alta calidad otorgada por el Ministerio de Educación Nacional por un periodo de ocho años (Resolución 018721 del 6 de octubre de 2023)

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

Los estudiantes de la Maestría en Ingeniería cuentan con acceso al Centro de Laboratorios, que consta de seis bloques con un área construida de aproximadamente 7.500 metros cuadrados, con 43 espacios de trabajo, entre laboratorios y talleres.

**Somos actor clave de una ciudad universitaria.**

Periódicamente se hacen seminarios sobre temáticas de interés para los estudiantes del programa, a los que asisten invitados especiales y de renombre sobre cada tema.

1.   Tenemos una agenda académica, cultural y social activa 

El conocimiento es visible y permea todos los rincones de la Universidad. Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en la Universidad EAFIT. 
2.   Tenemos proyección y presencia nacional

La Maestría en Ingeniería es presencial en Medellín, pero está configurado por módulos en horarios intensivos que les permiten a los estudiantes del resto del país desplazarse para sus clases y configurar el programa de la manera que más les convenga para que no interfiera en su ejercicio profesional.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Los estudiantes de la Maestría en Ingeniería pueden seleccionar cualquiera de las ramas de la Ingeniería que alberga la Universidad para su profundización, y su posgrado se configura de acuerdo con sus intereses y necesidades.

Innovación y liderazgo

**Somos innovación en educación**

Los estudiantes de la Maestría en Ingeniería se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de la Universidad EAFIT y a las tres áreas (mercados y estrategia financiera, macroeconomía y sistemas financieros, y políticas y desarrollo) que las configuran.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Nuestros estudiantes pueden trabajar en empresas financieras y bancarias, energéticas y de recursos naturales, tecnología y consultoría, industria farmacéutica y biotecnología, telecomunicaciones y tecnologías de la información, empresas de ingeniería y construcción, gobierno y organismos internacionales, y educación y academia, enfocadas en la investigación.

​​​​​​​​​Lí​​​neas de investigación ​

Nuestros estudiantes podrán configurar su plan de estudios, de acuerdo con las siguientes líneas de profundización, asociadas a los programas de especialización de la Escuela de Ciencias Aplicadas e Ingeniería:

**Sistemas y computación**

Mecánica aplicada.

Diseño.

Producción y logística.

Procesos químicos físicos y biotecnológicos.

Mantenimiento.

**Gestión de la construcción**

Plan de transición

El Consejo Académico en sesión del 30 de noviembre de 2023, aprobó un plan de transición para los estudiantes que soliciten reintegro o reingreso a la Maestría en Ingeniería.

El plan de transición ofrece opciones de matrícula al nuevo plan académico de la Maestría en Ingeniería, ocurrido durante la última actualización del programa al decreto 1330 de 2019 del Ministerio de Educación Nacional y que fue incorporado en el registro calificado de 2023.

Matriculados en la Maestría en Ingeniería hasta hace cuatro (4) años:

Los estudiantes en retiro voluntario deberán solicitar reintegro y completar los créditos de trabajo de la siguiente manera:

Si tienen matriculados más de seis (6) créditos de trabajo de grado, podrán matricular los créditos faltantes en un proyecto especial, que deberá abordar en máximo un semestre.

Si tiene matriculados menos de seis (6) créditos de trabajo de grado, deberá matricular doce (12) créditos relacionados con el ciclo completo de trabajo de grado, distribuidos en dos (2) semestres así:

Semestre 1 – Gestión de la información (2 créditos).

Semestre 1 – Anteproyecto (1 crédito).

Semestre 1 – Integridad Académica (3 créditos).

Semestre 2 – Trabajo de grado (6 créditos).

Los estudiantes en retiro por rendimiento académico deberán solicitar reingreso y completar los créditos de trabajo de grado de la siguiente manera:

Semestre 1 – Gestión de la información (2 créditos).

Semestre 1 – Anteproyecto (1 crédito).

Semestre 1 – Integridad Académica (3 créditos).

Semestre 2 – Trabajo de grado (6 créditos).

Matriculados en la Maestría en Ingeniería entre cinc​​o (5) y diez (10) años:

Deberán solicitar el reingreso a la Maestría en Ingeniería y realizar un ciclo de actualización electiva profesional entre cuatro (4) y ocho (8) créditos académicos asociados a su línea de especialización.

Adicionalmente, deberán matricular 12 créditos relacionados con el ciclo de trabajo de grado de la siguiente manera:

Semestre 1 – Gestión de la información (2 créditos).

Semestre 1 – Anteproyecto (1 crédito).

Semestre 1 – Integridad Académica (3 créditos).

Semestre 2 – Trabajo de grado (6 créditos).

Matriculados en la Maestría en Ingeniería mayor a di​​ez (10) años:

Deberán solicitar el reingreso a la Maestría en Ingeniería y realizar un ciclo de actualización electiva profesional entre seis (6) y doce (12) créditos académicos asociados a su línea de especialización.

Adicionalmente, deberán matricular 12 créditos relacionados con el ciclo de trabajo de grado de la siguiente manera:

Semestre 1 – Gestión de la información (2 créditos).

Semestre 1 – Anteproyecto (1 crédito).

Semestre 1 – Integridad Académica (3 créditos).

Semestre 2 – Trabajo de grado (6 créditos).

Preparación del trabajo de grado

El proceso de trabajo de grado se encuentra regulado por:

[Reglamento de trabajos de investigación de maestrías](https://universidadeafit.widen.net/s/hbbtzzsdnv/reglamentotrabajoinvestigacion-maestrias-1).

[Políticas y lineamientos de la maestría en ingeniería](https://universidadeafit.widen.net/s/59rddd5xzp/politicas-lineamientos-maestria-ingenieria).

###### Trabajo de grado:

El estudiante de la Maestría en Ingeniería deberá realizar un informe escrito bajo la dirección de un profesor, alrededor de un tema o problemática de interés para un grupo de investigación o para una empresa u organización interesada en la solución de un problema.

El trabajo de grado hace parte intrínseca del curso trabajo de grado de 9 créditos (EI0852) y en tal sentido debe hacerse entrega del trabajo de grado a más tardar en al semana 20 del semestre en el que se matriculó dicho curso.

Las modalidades de trabajo de grado definidas para la Maestría en Ingeniería son:

**Elaboración de una investigación aplicada.** Se debe desarrollar acorde con las fases de un proceso investigativo.

**Elaboración de un artículo inédito publicable.** El estudiante debe escribir un artículo académico o científico que cumpla con las condiciones de calidad y exigencias mínimos de publicación y constituya aporte significativo a la investigación aplicada.

**Elaboración de caso empresarial.** El estudiante debe realizar la descripción de una situación real empresarial que envuelva un hecho o problemática y la información básica requerida para la toma de decisiones que conlleven a una solución.​

###### Pasos previos a la entrega:​​

1.   **​Tenga en cuenta el calendario académico de posgrados aprobado por el Consejo Académico:**

1.   **Defina el tipo de trabajo de grado a entregar y seleccione el formato adecuado:**

Si el trabajo de grado corresponde a la opción de **artículo inédito publicable**, el mismo debe seguir los lineamientos de la revista seleccionada para su publicación. El nombre de la revista debe ser enunciado para poder revisar el formato.

Para las opciones de **elaboración de una investigación completa y elaboración de un caso empresaria**l (estudio de caso), se debe utilizar el siguiente formato:

[Plantilla IEEE](https://repository.eafit.edu.co/items/ad77f0a3-17f6-4235-968d-25a80ec9d8cd).

1.   **La elaboración ​de citas y referencias debe seguir el formato IEEE:**

[Formato IEEE](http://hdl.handle.net/10784/32498)​​.

1.   **Anonimizar el trabajo de grado:**

Retirar del trabajo de grado cualquier mención a los nombres del estudiante y del asesor del trabajo de grado, de tal manera que los evaluadores no puedan identificar los autores del trabajo, para garantizar una evaluación objetiva.​ La amonificación debe incluir el nombre del archivo pdf.

1.   **Diligenciar el documento de coautoría:**

El asesor y el estudiante deben diligenciar el formato de coautoría, donde se delimitan los alcances de la propiedad intelectual del trabajo de grado​:

1.   **Revisión de originalidad del trabajo de grado:**

​Acceda al [Consultorio de estilos de citación y análisis de originalidad con Turnitin](https://www.eafit.edu.co/posgrados/escuela-ciencias-aplicadas-ingenieria/maestria-ingenieria/consultorio-de-estilos-de-citacion-y-analisis-de-originalidad-con-turnitin)​ del Centro Cultural Biblioteca Luis Echavarría Villegas.

Diligencie el _Formulario de solicitud servicios especializados_.

Escoja la opción: _Consultorio de estilos de citación y análisis de originalidad con Turnitin_.

Seleccione la opción de autogestión _Turnitin_.

Una vez enviado el formulario, recibirás a vuelta de correo una notificación de inscripción a un grupo de _Eafit interactiva_, desde el cual podrás revisar la originalidad de tu trabajo de grado.

Revise que su trabajo de grado obtenga un porcentaje de similitud inferior al 10% y genere el informe correspondiente en formato pdf.

En caso de el trabajo de grado reporte un porcentaje de similitud mayor al 10%, utilice la opción de _asesoría en normas y Turnitin_, y asista a las asesorías de la biblioteca hasta que el trabajo de grado alcance el % de similitud mínimo requerido.

En caso de cualquier inconveniente con el proceso de revisión de originalidad pueden contactar al señor: Julian Alberto Naranjo Alvárez (janaranj@eafit.edu.co)​ del Centro Cultural Biblioteca Luis Echavarria Villegas.​

1.   **Revisión de originalidad del trabajo de grado e Inteligencia Artificial (IA):**

​Actualmente existe una discusión global sobre la autoría de los temas producidos por IA. Algunos gobiernos atribuyen la autoría a las fuentes que nutren la IA, otros a los programas mismos y otros a los usuarios de IA.

En la Maestría en Ingeniería la construcción de un pensamiento crítico requiere la formulación de ideas propias y de encontrar la mejor manera de expresar los pensamientos en los textos escritos.

Desde septiembre de 2024 la aplicación de TURNITIN identifica los textos generados con IA. En tal sentido, se requiere que los textos de trabajo de grado cumplan con un **porcentaje máximo de similitud del 10%** de los textos generados con el apoyo de IA.​

**Apoyo en la gestión de proyectos de grado:**

**Gloria María Doria Herrera**

**Jefe de Posgrados**

Escuela de Ciencias Aplicadas e Ingeniería

**E-mail:** jefatura.pos.ecaei@eafit.edu.co

Entrega del trabajo de grado

​​​​​​​​​​La Escuela en Ciencias Aplicadas e Ingeniería cuenta con la figura de Jefe de la Maestría en Ingeniería, quien se encarga de recibir los trabajos de grado, revisar su completitud, localizar jurados y reportar los resultados finales de las evaluaciones a la oficina de Registro Académico.​

###### Proceso de entrega d​​el trabajo de Grado​

El asesor del trabajo de grado deberá hacer la entrega y suministrar toda la información en el siguiente link:

Una vez diligenciado el formulario, el asesor recibirá una notificación al correo electrónico institucional.

En caso de inconvenientes con el formulario, por favor escriba un correo electrónico a: [maestring@eafit.edu.co](mailto:maestring@eafit.edu.co) ​

Evaluación del trabajo de grado

###### ​​​Revisión de completitud

El Jefe de la Maestría en Ingeniería revisará la completitud de los documentos entregados así:

Trabajo de grado en el formato adecuado.

Documento de coautoria debidamente diligenciado.

Trabajo de grado anonimizado.

Reporte de originalidad inferior al 10%.

Completa información de jurados sugeridos.

Rubrica de evaluación del asesor, en caso de que no sea coautor.

En caso de que los documentos se encuentren acorde con lo solicitado, se procederá a la remisión del trabajo de grado a los jurados para la evaluación correspondiente.

En caso de que la documentación está incompleta, se le hará la correspondiente notificación al asesor para que entregue los documentos faltantes y el proceso se trasladará a la siguiente fecha de entrega definida en el calendario.

###### Remisión a jurados

La Jefatura de la Maestría en Ingeniería seleccionará **dos jurados**, con base en los profesionales propuestos por el asesor y con la base de datos de jurados de la Maestría en Ingeniería. Con la selección independiente de los jurados se busca una evaluación objetiva del trabajo de grado.

El trabajo de grado será enviado por conductos institucionales a cada uno de los jurados seleccionados para la evaluación correspondiente.

###### Evaluación trabajos de grado

Se procurará que el trabajo de grado sea evaluado por un asesor externo y un asesor externo. La evaluación del trabajo de grado se hará en la modalidad **doble ciego** y los evaluadores dispondrán de un plazo de cuatro semanas para entregar la rúbrica con la calificación y las observaciones pertinentes.​

El trabajo de grado será evaluado con base en una de las siguientes rúbricas dependiendo de la modalidad de trabajo de grado utilizada:

[Trabajo de Investigación](https://universidadeafit.widen.net/s/hk5qrld2wf/rubrica-de-trabajo-de-grado).

[Artículo](https://universidadeafit.widen.net/s/n5vdwtptmc/rubrica-para-articulo).

[Estudio ​de Caso](https://universidadeafit.widen.net/s/c2lhtg65sx/rubrica-estudio-de-caso).​

###### Reporte de nota

Una vez finalizada la evaluación del trabajo de grado, la jefatura de la Maestría en Ingeniería enviará al estudiante y al tutor un correo electrónico con cada uno de los conceptos de los evaluadores y la respectiva calificación. El promedio de la calificación es remitido a Admision​es y Registro, quienes proceden al ingreso de la nota en el sistema.

Es normal que pasen varios días entre el momento en el que el estudiante recibe las notas de los jurados y el momento en el que su nota se ve reflejada en el sistema. La universidad garantiza que, si el trabajo fue entregado a tiempo y el proceso de evaluación culminó en los plazos establecidos, la nota estará reportada en el sistema cumpliendo con los cronogramas declarados en el Calendario.

###### Trámites de Grado​​​​​

Para los trámites de grado se recomienda consultar la guía de Ad​​misiones y Registro, presione [aquí](https://www.eafit.edu.co/consultar-tramites-y-servicios-por-orden-alfabetico-admisiones).

###### Paz y salvo biblioteca

Es importante tener en cuenta que el trámite de entrega de la copia del trabajo de investigación en biblioteca es independiente del reporte de nota en admisiones y registro. El documento del trabajo de investigación solo puede ser sometido a evaluación por el director, dado que éste da fe de la finalización y completitud del documento y por tanto este puede ser entregado en biblioteca.

Para el trámite de entrega de la copia del trabajo de investigación en biblioteca, presione [aquí](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/entrega-tesis).

A partir del 15 de mayo de 2020, la biblioteca ha habilitado la opción de entrega digital del trabajo de investigación. En el vínculo anterior se detalla el procedimiento para que al estudiante se le habilite el ingreso al formulario web del repositorio digital de trabajos de investigación.

Es importante aclarar que el diligenciamiento del formulario del repositorio es de carácter obligatorio para todos los estudiantes de maestría en ingeniería en ambas modalidades, incluyendo aquellos que se gradúan con artículo publicado. En estos casos se diligenciará el formulario con la información del artículo, mas no se anexará el documento PDF del artículo.

Para los casos de artículo publicado o en los que sea necesario solicitar embargo del documento ya sea por estar en proceso de patente o requerimientos de confidencialidad, se deberá indicar en el formulario del repositorio que **no se autoriza la publicación del texto completo**.

Para poder ingresar al formulario del repositorio es necesario que desde la coordinación de trabajos de grado de la maestría en ingeniería se haya notificado con antelación a la biblioteca para que esta habilite el permiso de ingreso del estudiante.

Inquietudes del proceso en biblioteca se pueden resolver en los siguientes canales:

Chat en línea "Pregúntale al bibliotecario"

Telefónicamente al (57) 604 2619500 extensiones: 9255, 9264, 9263, 9765

Correo electrónico: [repositorio@eafit.edu.co](mailto:repositorio@eafit.edu.co)

Para ampliar la información del proceso de entrega de tesis, puede consultar la página Web de la Biblioteca: [entrega de tesis](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/entrega-tesis).

Calendario

**Ceremonia de grado abril 9 de 2026:**

**Fecha límite de recepción de trabajo de grado:**29 de noviembre de 2025

**Revisión de completitud:** 1 de diciembre - 12 de diciembre de 2025.

**Remisión a jurados:** 15 de diciembre - 19 de diciembre 2025.

**Evaluación trabajos de grado:** 16 de enero - 2 de febrero 2026.

**Reporte de nota a la oficina de Registro Académico:**28 de febrero de 2026.

**Solicitud de grado:** 19 de enero - 5 de marzo 2026.

**Trámite paz y salvos:** 19 de enero - 12 de marzo 2026.

**Pago derechos de grado:** 19 de enero - 17 de marzo 2026.

**Ensayo ceremonia de grado:** 7 de abril de 2026.

**Ceremonia de graduación:**9 de abril de 2026.

**Ceremonia de grado septiembre 3 de 2026:**

**Fecha límite de recepción de trabajo de grado:** 13 de junio de 2026

**Revisión de completitud:** 14 de junio - 20 de junio de 2026.

**Remisión a jurados:** 20 de junio - 4 de julio 2026.

**Evaluación trabajos de grado:** 4 de julio - 26 de julio 2026.

**Reporte de nota a la oficina de Registro Académico:** 31 de julio de 2026.

**Solicitud de grado:**1 de junio - 6 de agosto 2026.

**Trámite paz y salvos:** 1 de junio - 13 de agosto 2026.

**Pago derechos de grado:** 1 de junio - 19 de agosto 2026.

**Ensayo ceremonia de grado:** 1 de septiembre de 2026.

**Ceremonia de graduación:** 3 de septiembre de 2026.

Proyectos realizados

## Effects of Topography on 3D Seismic Ground Motion Simulation with an Application to the Valley of Aburra in Antioquia, Colombia

## ASSESSMENT OF INTENDED DEFORMATIONS AND KINEMATIC IDENTIFICATION OF PARALLEL MECHANISMS UNDER QUASI-STATIC CONDITIONS

## Non Intrusive Detection of Rotating Stall Occurring in the Turbine Quadrant of Francis Type Pump Turbines

## Computational Study of Cell Mobility and Transport Phenomena Through Textile Vascular Grafts Using a Multi-Scale Approach

## Handling heterogeneity in collaborative network virtual surgical simulators

## Computational Geometry in Medical Applications

## Implementation of the Moving Particle Semi-implicit method to predict the drag resistance coefficient on 2D

## ​​​Geometric analysis of trapezoidal hills subject to vertically incident SH waves​

## ​Implementation of user element subroutines for frequency domain analysis of wave scattering problems with commercial finite element codes

## The scattering of SH waves by a finite crack with a superposition based diffraction technique​

## THE MECHANICAL BEHAVIOR OF DENTIN: IMPORTANCE OF MICROSTRUCTURE, CHEMICAL COMPOSITION AND AGING

## Proyectos realizados / Environmental improvement of operating supply chains: A multi-objective approach for the cement industry

Reglamento de Trabajos de Investigación

**Para conocer más sobre el reglamento de Trabajos de Investigación, ingresa**[**AQUÍ**](https://universidadeafit.widen.net/view/pdf/6i0w68zxii/reglamentotrabajoinvestigacion-maestrias-1.pdf?t.download=true&u=ftfwep)

Contacto

###### Ejecutiva de promoción

**Andrea Torres Morales**

+ 57 322 678 3083

## Plan de estudios

## Profesores

## Escuela de Ciencias Aplicadas e Ingeniería

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Maestría en Ciencias de los Datos y Analítica​​​​​​

Duración

3 semestres

Lugar

Medellín

Horario

V​​iernes y sábado

Más información

Viernes de 5:00 p.m. a 9:00 p.m. y sábados de 8:00 a.m. a 12:00 m.

 En semana tenemos electivas, que cada una tendrá su propio horario.

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 107303

Valor total de los semestres

$53.545.849

#### Maestría en Matemáticas Aplicadas

Duración

4 semestres

Lugar

Medellín

Horario

Lunes a sábado

Más información

Las asignaturas se ofrecen de lunes a viernes al inicio o al final del día, y sábados en la mañana. Los horarios pueden ajustarse en común acuerdo con los estudiantes de cada línea de investigación.

Idioma

Español

Modalidad

Presencial 

Más información

Perfil: Investigación 

 Inicio de nuevas cohortes en el primer semestre del año

SNIES

SNIES 1266

Precio total del programa

$42.915.641

### **Noticias**

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Con más de 700 organizaciones aliadas, así se expande la relación de EAFIT con las empresas

Mayo 12, 2026

## Celebramos una cohorte que transforma territorios gracias a la Fundación Sura

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)