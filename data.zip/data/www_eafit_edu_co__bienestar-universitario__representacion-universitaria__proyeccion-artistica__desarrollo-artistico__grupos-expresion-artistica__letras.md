# Grupo Letras EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Grupo Letras EAFIT

Director: Daniel Bravo Andrade

*    Grupo Letras EAFIT 

### Acerca de letras

El Grupo Letras dirigido a estudiantes, profesores, empleados, egresados, amigos de la literatura, vinculados a la comunidad eafitense. Los integrantes de este Grupo se definen como hijos de las vocales, hermanos de las consonantes, padres y madres de las palabras, tejedores de frases, hiladores de párrafos, amantes de los versos, troqueladores del silencio, albañiles de textos y arquitectos de sueños, que construyen individual y colectivamente en la blanca y enigmática geografía del papel.

###### Quienes hagan parte del Grupo Letras podrán desarrollar:

Desarrollar su expresión escrita y artística mediante la escritura de textos de carácter literario.

Profundizar sus habilidades de comprensión y crítica lectora al compartir sus análisis con los demás.

Ejercitar la creatividad y construir un banco personal de ejercicios o herramientas de escritura creativa.

Ampliar su visión de la literatura al descubrir nuevos autores y lecturas​.

Daniel Bravo Andrade nació en Medellín, en 1993. Es comunicador social de la Universidad Eafit y máster en Creación literaria de la Universitat Pompeu Fabra, Barcelona. Trabaja como escritor y profesor universitario. Textos suyos han aparecido en antologías de cuento y en publicaciones literarias como Granta en español, Revista Mercurio, Universo Centro y Generación. Editó el libro Escribir es cosa de mujeres, una antología de escritoras "de acá", y publicó, junto a otros autores, Milhojas: Juegos de escritura, una serie de ejercicios de escritura/cartas del tarot/cuadernillo de microtextos.

Este Grupo se reúne semanalmente para comentar los textos leídos, criticar los escritos propios y compartir la pasión por la literatura. Además, se leen poemas, cuentos y novelas con esfuerzo y amor, así aspiran a ser maestros en lectura. Escriben y re-escriben, en ese inagotable oficio de construir con palabras sólidos universos de papel, entrelazados tras las sombras, las certezas, los olvidos, las historias y los personajes que emergen al paso de los días, el trabajo y la imaginación convocada en textos y pretextos.

Hasta la fecha el grupo cuenta con siete publicaciones: "ArcaVoces" (2003), "Ojo de agua" (2005), una novela colectiva "Todo amor termina en el Centro" (2007), "Meridiano Letras" (2010), "Dos puntos seguidos y uno aparte" (2013), "Nada es casual en esta casa" (2015) y una segunda novela colectiva, "Canto de Cigarras" (2018). Poemas, cuentos, textos cortos, ensayos, novelas, nada le es indiferente a los Letras, apasionados como son de la lectura y la escritura, acogidos en un pulido trabajo y esfuerzo silencioso.

Para el 2019 el grupo realizó una publicación llamada Letra de 12 que recoge cuentos escritos por los diferentes participantes del grupo en este año.

Para ser parte del Grupo deberás enviar un correo a [dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co) y estar atento(a) a la respuesta pues tu ingreso dependerá de la capacidad que se tenga para recibir a más personas durante el semestre.

###### Horario y lugar de ensayo del grupo:

Miércoles de 6:00 p.m. a 8:00 p.m.

Aula: 35-503 (puede variar cada semestre)​.

**Cualquier información adicional, será atendida en el correo**[dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co).

### En acción​

## Síguenos en nuestras redes sociales

### Facebook

### Instagram

### X

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)