# Ricardo Botero Mejía - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Ricardo Botero Mejía

​(Rector entre ​1971-1973)​

*    Ricardo Botero Mejía 

**Desde 1973 la figura de rector reemplazo la de director. Así, graduado como abogado en la Universidad de Antioquia en 1962, Ricardo Botero Mejía se desempeñó como rector de EAFIT entre 1971 y 1973.**

​​Su administración estuvo antecedida por un paro, que le tocó manejar a Hernán Gómez González, y culminó con otro que llevó a la interrupción de las actividades académicas por más de seis meses.

Pero el problema más delicado que tuvo que enfrentar fue el cierre de las residencias estudiantiles, debido a los desordenes y malas conductas de los alumnos, sabiendo que sus ocupantes tenían a su cargo el manejo de la única cafetería que había en esa época.

Pese a los períodos de crisis, durante su administración se dio un paso fundamental para la historia de la Institución: el 6 de mayo de 1971, el Ministerio de Educación Nacional y el Instituto Colombiano para el Fomento de la Educación (Icfes) reconocieron oficialmente a EAFIT como universidad.

Al año siguiente, se recibió una resolución proveniente del Icfes para crear la carrera de Tecnología en Programación de Computadores; además se adoptó el nombre oficial de “Escuela de Administración y Finanzas y Tecnologías, Universidad EAFIT.

Al finalizar el año de 1973, Botero Mejía presentó su renuncia definitiva ante el Consejo Superior.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate