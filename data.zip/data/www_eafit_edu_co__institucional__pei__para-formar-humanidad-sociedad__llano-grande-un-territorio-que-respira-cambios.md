# Llano Grande, un territorio que respira cambios​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Llano Grande, un territorio que respira cambios​

*    Llano Grande, un Territorio Que Respira Cambios​ 

​​Un ejemplo de reconciliación, de desarrollo comunitario y de construcción de paz, se registra en la vereda Llano Grande, de Dabeiba (Antioquia), donde EAFIT, con su capital científico para la conservación de la biodiversidad, se sumó a los esfuerzos de Postobón, Grupo Sura, Grupo Nutresa, Bancolombia, Grupo Argos, Corbeta y la Fundación Fraternidad Medellín, quienes aportaron 270 hectáreas para la reincorporación de excombatientes de las Farc.

En Dabeiba se quiere extender la experiencia de BioAnorí para evaluar la posibilidad de avanzar en una propuesta de turismo científico de naturaleza, que mejore, además, las condiciones productivas para las comunidades de forma responsable y sostenible.

En general, en esta región, ubicada a 45 minutos del casco urbano de Dabeiba la transformación ha hecho que las familias retornen al territorio, que se desarrollen varios proyectos productivos, se mejore la carretera y que haya hasta tiempo para torneos de fútbol entre excombatientes de las Farc, la fuerza pública e integrantes de la comunidad. Ellos son ahora un espacio Territorial de Capacitación y Reincorporación (ETCR).

## Según datos oficiales de este proceso en la vereda Llano Grande, de Dabeiba, un total de 30 familias habitaban esta zona durante el conflicto armado y después de los procesos de reconciliación ya son más de 200.

## 16. Paz, justicia e instituciones sólidas

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)