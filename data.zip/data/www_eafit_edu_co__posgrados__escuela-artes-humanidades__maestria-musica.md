# Maestría en Música - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Maestría en Música

SNIES 53159, Medellín

En Colombia, los músicos se enfrentan a un panorama profesional complejo y desafiante al navegar en un entorno árido y competitivo, una realidad bien comprendida en el programa de Maestría en Música de EAFIT. Nos adaptamos a las necesidades del mercado laboral, permitiéndote desarrollar habilidades para forjar tu propio camino profesional.

Los estudiantes de la maestría, a diferencia de los de pregrado, suelen tener una mayor claridad sobre su perfil profesional tras haber enfrentado el ámbito laboral. Así, el programa no solo prepara para integrar agrupaciones sinfónicas o populares, sino también para emprender proyectos personales con apoyo gubernamental o del sector privado. De este modo, la maestría proporciona el valor agregado de una formación integral que fomenta la autogestión y la adaptación a un medio profesional que, aunque difícil, ofrece oportunidades para quienes están bien preparados.

*    Escuela Artes Humanidades 
*    Maestría En Música 

## Registro calificado

Resolución 14754 del 17 de diciembre de 2019. Vigencia por 7 años a partir de la fecha de ejecutoria de la Resolución 18591 del 3 de diciembre de 2018.

## Acreditación de alta calidad

Resolución 18591 del 3 de diciembre de 2018 por 6 años.

Duración

4 semestres

Lugar

Medellín​

Horario

Clases sincrónicas

Más información

Clases de énfasis, por acordar con la/el profesor(a).

 Las clases de la línea de profundización se pueden programar entre semana, a partir de las 6:00 p. m. en modalidad híbrida.

Idioma

Español

Modalidad

Híbrido

SNIES

SNIES 53159

Precio total del programa

$58.027.282

## Sobre el programa

Continuemos nuestra historia

**Somos top en el mundo**

Los profesores, casi todos exclusivos, se dedican tiempo completo a la universidad, lo que garantiza un acompañamiento cercano y continuo a los estudiantes. Algunos docentes provienen de diversos países como México, Estados Unidos y Canadá, aportando una perspectiva internacional del conocimiento.

Campus transformador

**Nos respalda un ecosistema musical dentro del campus**

Contamos con un bloque especialmente diseñado y acondicionado para la práctica musical con aulas insonorizadas con puertas y ventanas dobles para evitar la transmisión de sonido. Además, cuenta con una oficina que gestiona la planta instrumental, ofreciendo a los estudiantes acceso a una amplia gama de instrumentos auxiliares (flautas piccolo, clarinetes bajos, saxofones, instrumentos de metal, entre otros) y equipos de audio.

Los estudiantes tienen acceso a una sala de computadoras con tecnología de última generación, una sala con clavinovas para practicar habilidades básicas y una sala-auditorio insonorizada donde ensaya la Orquesta Sinfónica Eafit y se realizan recitales y exámenes.

Áreas específicas como la de piano, dirigida por el profesor Andrés Gómez Bravo, son particularmente activas y reconocidas por sus frecuentes eventos y actividades que atraen tanto a estudiantes como a profesores invitados de otras instituciones.

El programa ofrece un encuentro anual de música dentro del campus, además de otros eventos organizados por las áreas específicas que incluyen presentaciones de los estudiantes, ofreciendo más oportunidades para exhibir su talento y mejorar sus competencias musicales.

**Visitantes destacados**

Nuestro campus es un espacio de encuentro entre estudiantes y músicos reconocidos. Algunos de ellos son:

1.   Maestra Blanca Uribe, profesora emérita, EAFIT, Colombia. 
2.   Maestro Francis Perron, Universidad de Montreal, Canadá. 
3.   Dra. Ann DuHamel, Universidad de Minnesota, Morris, Estados Unidos. 
4.   Dr. Igor Lipinski, Universidad de Oklahoma, Estados Unidos. 
5.   Dra, Rene Lecuona, Universidad de Iowa, Estados Unidos. 
6.   Dr. Gabriel Casara, Universidad Federal Saõ João dl Rei, Brasil. 
7.   MaestroLaurens Patzlaff, Universidad de Lübeck, Alemania. 
8.   Maestra Mónica Subzuk, Conservatorio de Música Julián Aguirre, Argentina. 
9.   Dra. Daria Rabotkina, Texas State University, Rusia- Estados Unidos. 
10.   Dr. Giorgio Latso, Giorgia.
11.   Dr.Jason Kwak, Texas State University, Estados Unidos. 
12.   Maestro David Greilsammer, director de la Filarmónica de Medellín. 
13.   Maestro Iván Martín, España. 
14.   Dra. Alessandra Feris. Universidad de Dakota del Sur, Brasil- Estados Unidos. 
15.   Maestra Teresa Tamez, Escuela Superior de Música y Danza de Monterrey, México. 

**El campus como escenario musical**

Como estudiante de la Maestría en Música tendrás la oportunidad de realizar conciertos dentro del campus, participar en recitales de grado, conciertos de final de semestre y sesiones de clase maestra, donde presentarás tu progreso y habilidades ante tus compañeros y profesores.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

La maestría ofrece flexibilidad en su plan de estudios, permitiendo a los estudiantes elegir asignaturas que se ajusten a sus intereses y necesidades.

Innovación y liderazgo

**Egresados destacados**

Entre los egresados de la Maestría hay mujeres destacadas en la dirección orquestal, un área dominada por hombres. Por ejemplo, la **egresada Ana María Patiño** es actualmente directora asistente de la afamada y tradicional orquesta de la Suisse Romande de Suiza.

Otras estudiantes destacadas son **Tatiana Pérez**, exdirectora asistente de la Filarmónica de Medellín y ahora directora invitada recurrente de la Orquesta Sinfónica de Eafit. Por otra parte, **Elizabeth Vergara** ha dirigido la Orquesta Sinfónica de Eafit y ha desarrollado una notable carrera en Argentina después de estudiar en el extranjero.

**Cultivamos el liderazgo temprano y la investigación**

Nuestros estudiantes pueden acceder a varios grupos de investigación. Entre ellos, el de Mujeres compositoras para chelo, que ha ganado renombre. También está el semillero de investigación MUSUX que abarca investigaciones de diversas áreas musicales.

**Pensamos en los proyectos personales**

Nos interesa que nuestros estudiantes tengan conocimientos para aprovechar las particularidades del sistema cultural colombiano, y de otros países, para incentivarlos a crear proyectos personales ante la falta de oportunidades actuales.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Nuestros estudiantes pueden trabajar (y lo hacen) en diversas agrupaciones musicales tanto públicas como privadas. Entre las instituciones públicas destacan la Filarmónica de Bogotá, la Orquesta Sinfónica Nacional, la Banda Sinfónica Nacional y el Coro Nacional. En Medellín está la Orquesta Sinfónica de Eafit que tiene oportunidades para músicos profesionales. También está la Orquesta Filarmónica de Medellín, que opera principalmente con financiación privada.

En el campo laboral existen numerosas oportunidades en docencia, como en la Red de Escuelas de Música de Medellín, y en programas de bandas en departamentos como Antioquia, Caldas, Cundinamarca, Risaralda, Quindío, Valle del Cauca y Nariño.

Finalmente, los egresados también pueden desarrollar proyectos personales con el apoyo de convocatorias de la Gobernación, la Alcaldía o el Ministerio de Cultura, lo que les permite abrirse espacio en el panorama musical de Colombia.

Perfiles

**Perfil de ingreso**

La Maestría en Música está dirigida a profesionales que buscan profundizar competencias en interpretación, composición o dirección, según la línea elegida. Además, que quieran complementar su formación para la enseñanza de la música y la gestión de proyectos artísticos musicales. El ingreso del aspirante está sujeto a la aprobación del examen de admisión.

**Perfil del egresado**

El graduado de la Maestría en Música de la Universidad EAFIT ejerce como músico profesional de alto nivel, bien sea como intérprete, compositor o director de obras musicales. Emplea teorías, corrientes de pensamiento y desarrollos actuales para la enseñanza musical. Aplica elementos para la construcción de proyectos artísticos musicales con base en los requerimientos, técnicos y operativos para su ejecución. Es un profesional ético y audaz que reconoce la diversidad de ideas y pensamientos para el trabajo en equipo.

**Perfil ocupacional**

El graduado de la Maestría en Música de la Universidad EAFIT puede desempeñarse como:

•Solista y/o intérprete en agrupaciones instrumentales y vocales.

•Director de grupos corales y orquestales.

•Compositor de creaciones musicales para distintos formatos.

•Profesor de música en diferentes contextos.

•Gestor musical en proyectos propios y/o de organizaciones artísticas públicas y privadas.

Contacto

###### Ejecutivo de promoción

**Stiven López Fernández**

+57 310 5843006

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Maestría en Literatura

Duración

3 semestres

Lugar

Medellín

Horario

Martes y jueves

Más información

Martes y jueves de 8:00 a 10:00 p.m.

Idioma

Español

Modalidad

Combinada

SNIES

SNIES 116836

Precio total del programa

$32.805.080

#### Maestría en Estudios Humanísticos

Duración

4 semestres

Lugar

Medellín​

Horario

Lunes y miércoles

Más información

Lunes y miércoles de 6:00 p.m. a 10:00 p.m. Se podrán programar algunas sesiones los martes o los sábados, de 8:00 a.m. a 12:00 m.

Idioma

Español

Modalidad

Presencial

Más información

Con algunas clases sincrónicas en línea.

SNIES

SNIES 53502

Precio total del programa

$48.947.926

## **Nuestros graduados**

## Arminda Marcial

Maestría en piano colaborativo

"La experiencia en EAFIT es organización, respeto, profesionalismo, entusiasmo, concreción en los objetivos. Gracias, lo disfruto".

## Darío Santos

Director de programas en Univalle

"Mi paso por EAFIT fue fundamental en mi desarrollo profesional. La excelencia académica, la dedicación y profesionalismo de sus docentes me brindaron las herramientas necesarias".

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)