# Beca reconocimiento a la expresión artística - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Beca reconocimiento a la expresión artística

Se otorgará una beca parcial en el valor de la matrícula del período siguiente.

*    Beca Reconocimiento A La Expresión Artística 

## Beca reconocimiento a la expresión artística

¿Cuándo se abre la convocatoria?

La convocatoria estará disponible del 10 al 21 de noviembre de 2025.

¿En qué consiste?

Es un reconocimiento a los estudiantes de pregrado, con participación activa, continua y representativa en alguno de los Grupos de Expresión Artística de la Universidad.

¿Quiénes pueden aplicar?

Pertenecer a uno de los Grupos de expresión artística, mínimo durante un año consecutivo.

Haber cursado en el semestre mínimo cinco materias.

No haber cancelado ni perdido materias en el semestre de postulación.

Haber obtenido un promedio crédito semestre o acumulado igual o superior a 3.8.

No haber sido sancionado disciplinariamente en el semestre de la postulación​.

¿Qué cubre la beca?

Al estudiante seleccionado se le otorgará una **beca parcial en el valor de la matrícula del período siguiente**, como resultado de la evaluación que se realiza cada período de acuerdo con el reglamento de la beca.

Las personas interesadas en esta beca y que cumplan con los requisitos se pueden postularse al correo dllo.artistico@eafit.edu.co.

Información adicional

Para mayor información consultar en el Departamento de Desarrollo Artístico. También puedes escribir a [contacto@eafit.edu.co​](mailto:contacto@eafit.edu.co%E2%80%8B)

Los resultados serán enviados al correo electrónico del estudiante​.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)