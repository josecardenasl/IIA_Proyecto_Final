# Sin miedo, hablemos de los ataques de pánico #Cuidémonos​​​​​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Sin miedo, hablemos de los ataques de pánico #Cuidémonos​​​​​

*    Sin Miedo, Hablemos de Los Ataques de Pánico #Cuidémonos​​​​​ 

**El miedo es una respuesta emocional perfectamente normal para todas las personas pero, en ocasiones, este p​uede escalar en diversas intensidades e incluso precipitar ataques de pánico. Algunos eafitenses pueden haberlos experimentado y, en esta nota, uno de ello​s nos comparte su experiencia.**

**De la mano de uno de los psicólogos del Departamento de Desarrollo Estudiantil conversamos sobre estos episodios, cómo manejarlos y cuáles son las opciones que la Universidad nos brinda para acompañarnos a gestionarlos.**

Lo dice la escritora Rosa Montero en la introducción de su libro El peligro de estar cuerda: “Un ataque de pánico es una dimensión desconocida, un viaje a otro planeta, la caída de un rayo súbito e inesperado que te fulmina”. La misma autora se ha descrito como parte del 25% de la humanidad que padece este tipo de situaciones y recuerda, en este mismo texto, que los ha tenido desde los 17 años y que son tan impredecibles y difíciles de entender, que solo pueden ser descritos por quienes los han vivido.

Algo parecido le ha pasado, desde 1992, a María Rocío Arango Restrepo, decana de la Escuela de Artes y Humanidades. Por eso, cuando leyó las palabras de la escritora y periodista española, se sintió totalmente identificada.

“Yo los he sentido como una sensación de miedo que va creciendo hasta convertirse en pánico, en terror. En mi caso puede tener una duración muy corta, de 15 o 30 minutos, pero ese momento es angustiante, se me acelera el pulso cardiaco, tengo la respiración agitada y, por un instante, pienso que me va a dar un infarto. Luego, cuando pasan, quedo completamente exhausta”, explica.

La directiva, quien voluntariamente quiso compartir esta experiencia a propósito de la iniciativa #Cuidémonos, recuerda que el primer episodio lo tuvo un año y medio después de la muerte de su padre, a comienzos de los noventas. En aquel entonces no pensó que existiera alguna relación entre ambos momentos, pero gracias a la terapia y el acompañamiento psicológico profesional que recibió pudo identificar porqué estaba pasando por estas situaciones.

“Desde entonces, y después de buscar ayuda, he aprendido a identificar cuándo me van a dar o cómo manejarlos. Lo primero que hago, por ejemplo, es aceptar que me está dando un ataque de pánico y saber que no es un infarto o alguna otra dolencia física; lo reconozco e intento concentrarme en una respiración consciente que me ayude a tranquilizarme hasta que pase esta situación. También evito tomar algún tipo de decisión personal o laboral durante estos momentos”, agrega María Rocío.

Se trata de una práctica que no solo le ha permitido entender estos momentos, sino también ayudar a reducirlos. Además, gracias a su pasión por la escritura, ha encontrado en esta una oportunidad para canalizar sus emociones.

“Lo más importante es entender que, aunque son situaciones difíciles, son cosas que nos pueden pasar pero que no definen nuestra identidad. Hay que reconocerlos, entender que no pueden ser un motivo de vergüenza y, cuando sea necesario, buscar ayuda para controlarlos, porque cuidarse a uno mismo -y a los otros- siempre debe ser una prioridad”.

“El acompañamiento psicológico en casos reiterados de ataques de pánico es de gran ayuda, pues nos brinda herramientas para identificarlos, saber qué los está detonando, analizar nuestras vivencias y poder mitigarlos. En mi caso yo uso el ejercicio de la escritura”, María Rocío Arango Restrepo, decana de la Escuela de Artes y Humanidades.

**Reconocer, expresar, verbalizar, exteriorizar y ocuparnos de nuestras emociones es cuidar de nuestra salud mental**

El miedo es una respuesta emocional que hace parte de la vida y todos lo sentimos en uno u otro momento, pero cuando esta respuesta aparece de manera súbita e inesperada y escala a un grado que afecta nuestras diferentes áreas de desempeño e incluso genera alteraciones en algunas funciones vitales, ahí es cuando hablamos de un ataque de pánico. Así nos lo explica Juan David Mesa Valencia, psicólogo del Departamento de Desarrollo Estudiantil.

Y como le sucedió a María Rocío, estos episodios se manifiestan de muchas maneras como las físicas (ritmo cardíaco acelerado, respiración agitada, sensaciones de cosquilleo y mareos) o las psicoemocionales (desorientación o confusión, sensación de peligro inminente, miedo intenso, cascadas de pensamiento generalmente con tintes catastróficos, entre otros). Pero lo más importante, explica el profesional en salud mental, es saber que no todos los ataques de pánico indican la presencia de un trastorno mental.

“Un ataque de pánico puede aparecer por una situación concreta, como la pérdida de un ser querido, una ruptura, un robo, un evento traumático o una fobia, pero en otras ocasiones puede ser derivado por situaciones que no logramos identificar claramente. Bajo esta lógica valdrá la pena posteriormente intentar entender que desencadenó en nosotros este episodio para así encontrar cómo ocuparse de ello”.

Ante estas respuestas emocionales podemos recurrir a estrategias como ejercicios de respiración lenta profunda y pausada; prácticas de relajación; retirarnos de situaciones desencadenantes; acudir a personas significativas que nos pueden ayudar a atravesar este momento; o buscar a alguien que nos pueda prestar primeros auxilios psicológicos.

Ahora bien, en el caso de que estos se vuelvan repetitivos y no logremos diferenciar una causa clara, o cuando comencemos a sentir el temor persistente de que en cualquier momento nos suceda un ataque de pánico y esto nos genere ansiedad, entonces hay que procurar la ayuda profesional. ​

​“Tenemos una capacidad finita de contener emociones. Reconocer, entender, expresar, verbalizar, ext​eriorizar y gestionar las emociones es una práctica preventiva para cuidar de nuestra salud mental; nos permite estar más ligeros en términos emocionales y hace menos probable que las situaciones escalen a crisis emocionales o a afecciones complejas en nuestra salud mental”, Juan David Mesa Valencia, psicólogo del Departamento de Desarrollo Estudiantil.

“El miedo, la angustia y las tensiones hacen parte de nuestra experiencia vital, en esa medida démosles lugar a estos fenómenos, entendamos a qué responden y ocupémonos de los mismos. Cuando los inhibimos, los invalidamos o no los tramitamos, no hacemos que desaparezcan; los conflictos de la vida que evadimos o postergamos en algún momento retornarán, no necesariamente como una crisis de pánico, pero quizá sí como una afección en nuestra salud mental e incluso física. Cuidar de uno mismo implica, en ocasiones, ocuparnos de aquello que nos desagrada, nos sobrepasa o de lo que postergamos”, concluye el psicólogo.

La historia de María Rocío es un referente a la hora de seguir poniendo estos temas en el centro de la conversación y entender la importancia de hablar de nuestras emociones para seguir viviendo el mutuo cuidado.​

###### La U nos cuida

Vale la pena recordar que la Universidad cuenta con diferentes rutas para el cuidado​ de la salud mental, así como el apoyo a través de la consulta psicológica para estudiantes, profesores y colaboradores, el grupo de paramédicos para brindar primeros auxilios psicológicos, El Escuchadero (en convenio con la Alcaldía de Medellín), y el Directorio de Servicios en Salud, que cuenta con un capítulo especial dedicado a la salud mental. Estos y muchos otros recursos los podemos consultar en el siguiente [enlace](http://portalqa.omega.eafit.edu.co/bienestar-universitario/salud-mental)​​.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)