# Coro Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Coro Universidad EAFIT

Director: Mauricio Balbín Pérez​​​

*    Coro Universidad EAFIT 

### Acerca del coro

El Coro de la Universidad EAFIT busca canalizar el interés por la música a capella, manifiesta en los estudiantes de las distintas carreras de la Universidad, así como en empleados y egresados. Con su actividad, el acompaña los diferentes eventos académicos y celebraciones especiales, además de proyectar a sus integrantes como una alternativa artística y cultural en el interior de la Institución y la participación en encuentros y festivales a nivel local, nacional e internacional de diferentes índoles.

###### Los participantes del coro en su desarrollo grupal conocen y profundizan varias competencias:

Empatía: el integrante del coro desarrollará la capacidad de comprender el trabajo en equipo, enfrentar el trabajo de cantar en equipo le implica escuchar al otro.

Pensamiento crítico: los integrantes del coro desarrollan la capacidad de enfrentar diferentes repertorios de manera crítica y con consistencia de razonamiento, diferenciando los repertorios desde las distintas épocas de la historia del arte, sus diversos componentes, la letra, el compositor entre otros.

Integración y reconocimiento: los participantes del coro de la universidad convierten la agrupación en un referente de vida, de encuentro no solo musical sino social, además se sienten orgullosos y reconocidos de pertenecer a una agrupación de representación de la universidad.

Interpretación: los integrantes del coro desarrollan capacidades interpretativas y de estilo acordes la época del repertorio, es decir, desarrollan la capacidad de interpretación en épocas como el renacimiento, el barroco, el clasicismo, el romanticismo y post romanticismo, música popular y folclórica entre otros.​

Es egresado del programa Licenciatura en Educación Musical de la Universidad de Antioquia, termina estudios de Música canto en la misma universidad bajo la dirección del Maestro Diver Angel Higuita. También termina estudios de especialización en Artes: dirección Coral en la Universidad de Antioquia. Es egresado de la Universidad EAFIT del programa de magister en música con énfasis en dirección coral bajo la batuta de la maestra Cecilia Espinosa Arango. Ha sido director invitado de la Orquesta Sinfónica Juvenil de Antioquia. Ha sido profesor de la Red coral Escolar de Medellín. Trabajó para la Universidad de Antioquia como coordinador académico del Programa Red de escuelas de música de Medellín y como profesor de música de la Facultad de Artes.

Actualmente trabaja para EAFIT como profesor de Cátedra del departamento de música y como director del coro institucional. Ha participado como cantante corista de destacadas agrupaciones tales como Tonos Humanos y Arcadia. Como solista ha participado de los montajes de Jesucristo super estrella y la flauta mágica, Réquiem de Mozart y Fauré. Realizó todos los cursos en el marco de la Maestría en Interpretación de música Latino Americana del siglo XX con énfasis en dirección, en la Universidad Nacional del Cuyo en Mendoza, República Argentina.

El hoy Coro Universidad EAFIT inicia actividades en 1981, pero por diferentes motivos tuvo una larga interrupción de actividades entre 1983 y 1995, año en el cual se reiniciaron los ensayos semanales. A partir de 1999 el maestro Carlos Javier Jurado toma el Grupo de su antiguo director y fundador, Jorge Alberto López Ortiz.

En el segundo semestre de 2002 se produce un nuevo relevo, y la dirección vocal queda a manos del estudiante de Música de EAFIT, Juan David López, quien presenta como propuesta imprimirle al Grupo, además del repertorio tradicional, un toque más contemporáneo con repertorio moderno y popular.

Este énfasis se afianza en la batuta del maestro Jorge Mendoza Castaño, quien le inserta al repertorio del Grupo música colombiana y latinoamericana, así como ritmos populares del agrado de la comunidad estudiantil.

Posteriormente, continúa esta labor Juan David Osorio López, a partir del segundo semestre de 2006, dándole al Grupo el sello de la juventud y de su experiencia como integrante de los Coros Tonos Humanos y Arcadia.

A partir de 2008, el Coro Universidad EAFIT incluye en sus filas como director al reconocido músico Mauricio Balbín Pérez, con quien la Institución amplía y consolida sus horizontes formativos, de la mano de una expresión vocal y musical del más alto nivel cultural.

En 2009, de la mano del maestro Mauricio Balbín Pérez, el Coro representó a Colombia en el XI Festival Internacional de Coros de Cusco-Perú, en 2010 participó en el XI Festival Mundial de Coros en la ciudad de Puebla-México y en el 2012 hizo parte del VI Festival Mundial Buenos Aires Coral (Argentina) y adicionalmente a este Festival, del V Encuentro Internacional de Coros de Saladillo. En todos estos eventos, el Coro Universidad EAFIT fue quien llevó la imagen del país, enfocándose en la música colombiana como embajadora de la cultura nacional.

El Coro Universidad EAFIT cuenta en su haber con dos grabaciones corales: el trabajo musical titulado "Entre Europa y Latinoamérica" (2010) y el disco de villancicos "Quem Pastores" (2011).

Para el año 2020 el Coro de la Universidad EAFIT participa de manera virtual en diferentes eventos nacionales e internacionales tales como: Festival Mundial Coral Buenos Aires, Argentina, Coro a la Sabana, organizado por la Universidad de la Sabana y el Encuentro Coral del Conservatorio del Tolima.

Todo participante que desee ser parte de Madriguera teatro, debe pasar primero por el semillero de teatro, donde se realizará una evaluación de su conocimiento y desempeño para ser promovido. Una vez el grupo cuente con la posibilidad de recibir nuevos integrantes, serán tenidos en cuenta quienes tengan y demuestren un mayor avance.

###### Horario y lugar de ensayo del grupo:

Martes y jueves de 6:00 a 9:00 p.m.

Bloque 30. Aula 301 (puede variar cada semestre).

###### Semillero Coral

Este espacio está creado para avivar las inquietudes de todos aquellos eafitenses que ven en el canto una posibilidad de desarrollar habilidades artísticas. Se trabaja técnica vocal, acercamiento a las melodías y metodologías del ejercicio coral.​​​

###### Ensayos del semillero

Lunes: 6:00 p.m. a 7:00 p.m.​ Bloque 30. Aula 301 (puede variar cada semestre)​.

###### Requerimientos técnicos y logísticos para presentaciones:

Transporte ida y regreso.

Espacio cubierto o concha acústica si la presentación es al aire libre.

Brindar refrigerio e hidratación a cada uno de los integrantes del Coro.

Hacer montaje y ensayo de sonido, mínimo 30 minutos antes de la presentación del grupo. ​

Empezar el programa a la hora señalada, para cumplir con el tiempo de presentación del Grupo, dado que los integrantes son en su mayoría estudiantes, que deben cumplir con otros compromisos académicos.

Contar con un presentador que haga la respectiva presentación del Grupo, o posibles intervenciones a lo largo de la presentación y el cierre de la misma al finalizar.

**Cualquier información adicional, será atendida en el correo**[dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co).

### En acción​

## Síguenos en nuestras redes sociales

### Facebook

### Instagram

### X

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate