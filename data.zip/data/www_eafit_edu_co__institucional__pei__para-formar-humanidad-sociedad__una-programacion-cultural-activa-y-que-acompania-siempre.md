# Una programación cultural activa y que acompaña siempre​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Una programación cultural activa y que acompaña siempre​

*    Una Programación Cultural Activa y Que Acompaña Siempre​ 

​​La dimensión cultural permanece palpitante en EAFIT. En ella se reconocen las diferentes formas de ver y experimentar el mundo, de recrearlo y de inspirar. Sea como punto de encuentro físico o digital, está presente para eafitenses y comunidad en general a través de la preservación de la memoria, de la promoción de nuevos talentos y de la agenda con las diferentes actividades artísticas.

Cine, danza, exposiciones, literatura, música y teatro, áreas que desde lo académico y lo estético aportan para conectarnos como sociedad y potenciar la creatividad, a través de una completa agenda a lo largo del año para públicos internos y externos. Bien desde la presencialidad o desde los medios virtuales como aliadas en épocas de confinamiento, el público en general puede disfrutar de conciertos y lecturas en voz alta. Un caso interesante es el de Conciertos memorables, espacio en los que se reviven las presentaciones con los mejores artistas que han pasado por EAFIT.

Programas como Amar y Comprender la Ópera, Mesita de Noche, Ciclo Literatura de Viajes y el Cine Club son propuestas reconocidas entre los amantes de la cultura, eafitenses o visitantes. Se trata de una agenda diversa, incluyente, que ofrece nuevos puntos de vista, que abre ventanas a nuevos universos.

## Desde Desarrollo Artístico se ofrecen talleres que proyectan la Universidad y desarrollan talentos, en áreas como fotografías, pintura y joyería.

## 4. Educación de calidad

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)