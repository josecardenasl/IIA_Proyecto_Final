# Representación estudiantil y profesoral - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Representación estudiantil y profesoral

*    Representación Estudiantil y Profesoral 

Los representantes son elegidos democráticamente por la comunidad eafitense. Ellos están atentos al cuidado de los intereses de todos.​

###### ​​​​​​​​​​​Representación estudiantil

Los representantes estudiantiles son las personas que, desde el ejercicio de la democracia, velan por los intereses de la comunidad universitaria y trabajan con convicción por el bien común.

Ellos, estudiantes de pregrado y posgrado, forman parte de los cuerpos colegiados y los comités de carrera de la Universidad.

Son elegidos por votaciones, cada año, a través de las Elecciones EAFIT, que se componen por un período de inscripción de candidatos avalados por los mismos estudiantes, un proceso de votación en línea, un escrutinio y la publicación de resultados.

Los estudiantes de pregrado pueden ser elegidos para pertenecer al Consejo Directivo, el Consejo Académico y los Consejos de Escuela. Además, integran los comités de carrera. Por su parte, los estudiantes de programas de posgrado de la Institución se pueden postular para integrar el Consejo Académico. ​

**Conozc​a más sobre los Representastes ​​estudiantiles​.**

###### Representación profesoral

En el momento de su inscripción como candidatos, los aspirantes a representantes al Consejo Directivo, al Consejo Académico, a los consejos de Escuela, al Comité de Escalafón y al Comité de Investigaciones, deberán tener una vinculación de tiempo completo con la Universidad y no estar ejerciendo cargos administrativos.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate