# ​​Participación activa en la construcción de políticas públicas - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​​Participación activa en la construcción de políticas públicas

*    ​​Participación Activa En La Construcción de Políticas Públicas 

La Universidad no está conforme con el statu quo. Por eso, como una manera de aportar a la ciudad, la región y el país también participa activamente en la formulación, el desarrollo, la actualización, la socialización y la evaluación de políticas públicas que generan soluciones y nuevas posibilidades, de la mano del Centro de Análisis Político (CAP); del Centro de Investigación Económicas y Financieras (Cief), y de algunas acciones del Centro de Estudios Urbanos y Ambientales (Urbam). El primero de estos irradia su conocimiento al entorno en temas relacionados como la equidad de género, la seguridad, la convivencia y paz; el segundo desde el aporte del conocimiento y la producción científica para la toma de decisiones; y el tercero con insumos que permitan apoyar los procesos urbanos y territoriales con enfoque sostenible.

Lo anterior se evidencia en la operación del Observatorio de Políticas Públicas del Concejo de Medellín, que EAFIT opera junto a la Universidad de Medellín desde 2008, y en la formulación de algunas políticas públicas como la de trabajo decente para Medellín (2011); de Seguridad y Convivencia (2013 y 2019); de juventud (2014); de Mujeres Urbanas y Rurales de la Secretaría de las Mujeres de Medellín (2016-2019); de Medios Alternativos, Independientes, comunitarios y ciudadanos de Bogotá y Medellín (2016 y 2017); de Desarrollo Económico de Envigado (2017); y de Cultura Ciudadana (2019), entre otras. Así mismo, la Universidad ha participado, entre otras acciones, en la construcción del Plan Director del Valle de Aburrá (Bio2030); en la intervención estratégica de Río Sur; en las estrategias y procesos para habitar las laderas de Medellín; y en la formulación de los Planes Municipales Integrales de Chigorodó, Carepa, Apartadó y Turbo.

​

​De igual manera, en los últimos años se ha realizado el acompañamiento técnico y metodológico en la formulación, seguimiento y evaluación de los procesos de política pública de Medellín; y la formulación Plan Municipal de Gestión de Riesgos de los municipios de Medellín y Rionegro. En ambos también ha participado la Institución.

El Centro de Análisis Político espera atender a unos 580 jóvenes, como parte del proyecto con la Secretaría de Juventud en el segundo semestre de 2020.

En alianza con el sector privado, el CAP acompaña a cinco municipios de la región en el fortalecimiento de instrumentos de seguridad.

El Cief se alimenta de los grupo de investigación vinculados a los departamentos de Economía y Finanzas. Estos son Economía y Empresa, Research in Spatial Economics (Rise) y Finanzas y Banca.

Los resultados y avances de esta labor de investigación se constituya en un insumo para la toma de decisiones por parte de los hacedores de política (policy makers), el sector privado, la sociedad civil, y las agencias de desarrollo, entre otros.

Desde su fundación el Centro Urbam se ha convertido en un punto de conexión entre la academia y los procesos territoriales, urbanos, medioambientales, de la ciudad, la región y el país.​

## 5. Igualdad de género

## 8. Trabajo decente y crecimiento económico

## 11. Ciudades y comunidades sostenibles

## 16. Paz, justicia e instituciones sólidas

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate