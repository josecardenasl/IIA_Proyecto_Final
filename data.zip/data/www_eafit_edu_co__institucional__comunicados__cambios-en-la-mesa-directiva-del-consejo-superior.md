# Cambios en la mesa directiva ​del Consejo Superior

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 4: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​Cambios en la mesa directiva ​del Consejo Superior

*    Comunicados 
*    Cambios En La Mesa Directiva ​del Consejo Superior 

###### David Escobar Arango

###### Juan Manuel Velasco Barrera

**​Estimados eafitenses**

Quiero compartir con ustedes que nuestro Consejo Superior, en su sesión del miércoles 26 de enero de 2022 y a través del acta 001, de acuerdo con los periodos definidos por los Estatutos Generales, designó a su nueva mesa directiva en cabeza, por primera vez, de dos egresados: David Escobar Arango, quien ejercía la vicepresidencia del máximo órgano de gobierno de la Universidad, como nuevo presidente; y Juan Manuel Velasco Barrera, integrante de este estamento, co​mo vicepresidente. Ambos eafitenses se han caracterizado por la ca​lidad de sus t​​rayectorias profesionales, y el compromiso y espíritu transformador con el que han contribuido a la Universidad desde diferentes posiciones como el liderazgo estudiantil y la docencia, así como su participación en los órganos de gobierno decisorios como el Consejo Directivo y Consejo Superior.​

###### Trayectoria de Juan Manuel Velasco Barrera, vicepresidente del Consejo Superior​.

Socio y Deputy CEO del Banco BTG Pactual en Colombia. Apasionado por las finanzas, el emprendimiento y la tecnología. Además de estar con su familia, le emociona dedicar tiempo a la lectura, la historia y los deportes. Es un convencido del aporte de los empresarios en la disponibilidad y calidad de la educación como una condición de desarrollo de la sociedad. Estudió Administración de Negocios en EAFIT y ejerció como director del periódico estudiantil Nexos. Durante 27 años ha desempeñado diferentes roles directivos en entidades financieras y de mercado de capitales. Igualmente, ha emprendido, creado y desarrollado empresas de diferentes tamaños y sectores. Es integrante del Consejo Superior de EAFIT desde diciembre de 2017 e hizo parte del Consejo Directivo como representante de los egresados. Asimismo, ha sido profesor en los pregrados en Administración de negocios, Negocios Internacionales y Economía.​​​​​

###### Trayectoria de David Escobar Arango, presidente del Consejo Sup​erior​.

​​Actual director de Comfama. Amante de la lectura, la poesía, la naturaleza, el arte y la cultura. Su propósito de vida es trabajar por los jóvenes, la educación y el desarrollo sostenible de Antioquia. Su relación con EAFIT ha sido estrecha, no solo como graduado de Ingeniería de Producción de la Universidad, sino porque también se desempeñó como representante estudiantil y vicepresidente de la Organización Estudiantil. Posteriormente recibió el título de magíster en Administración pública de la Escuela de Gobierno Kennedy de la Universidad de Harvard. Trabajó varios años en el​ sect​or público local y regional. Luego se desempeñó como director de Interactuar, entidad de fomento y apoyo al emprendimiento. Pertenece al Consejo Superior de la Universidad desde 2006. También hace parte del Consejo de Proantioquia y de la Junta de Asocajas.​​​​

En n​​ombre de toda la comunidad eafitense, le extendemos un abrazo lleno de gratitud a José Alberto Vélez Cadavid, quien se retira de la Presidencia del Conse​jo Superior tras cumplir su periodo de cinco años según lo establecido en​ los Estatutos, y quien continúa en su calidad de conseje​ro entregando sus invaluables aportes al fortalecimiento y la proyección de nuestra Universidad.​

Durante este quinquenio la Universidad ha avanzado en su propósito de consolidación de un proyecto humanista y científico riguroso, ha crecido de manera sostenible, y se ha constituido en un escenario de confianza y conversación colectiva generadora de desarrollo para toda la región y el país.

Con estos cambios propios del cumplimiento de los periodos definidos por los Estatutos Generales se continúa con el ejercicio de gobierno corporativo propi​o de la Institución.

Le expresamos a los nuevos Presidente y Vicepresidente del Consejo Superior nuestra gratitud por el compromiso que asumen con nuestra Institución para acompañar su camino y gestión. Nos comprometemos, de la mano de su experiencia y conocimientos, a trabajar juntos para que EAFIT continúe fortaleciendo su proyecto de saberes y conocimientos al servicio de la so​ciedad creando valor y desarrollo sostenibles, a través de su ADN: inspira, crea y transforma.​

**Claudia Restrepo Montoya**

**Rectora**

Comunicado No.6

Medellín, 31 de enero de 2022​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate