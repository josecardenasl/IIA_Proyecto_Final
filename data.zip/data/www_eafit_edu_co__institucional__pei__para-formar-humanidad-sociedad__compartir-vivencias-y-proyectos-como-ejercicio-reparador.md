# Compartir vivencias y proyectos como un ejercicio reparador

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Compartir vivencias y proyectos como un ejercicio reparador

*    Compartir Vivencias y Proyectos Como un Ejercicio Reparador 

El ciclo de conferencias Reincorporación que transforma vidas, promovido por EAFIT, la Agencia para la Reincorporación y la Normalización (ARN), la Misión de Verificación de la ONU en Colombia, Proantioquia y la Alianza para el Desarrollo Sostenible e Incluyente PNUD-EPM, fue, sin dudas, un aporte a la esperanza, una validación de que juntos podemos construir sociedad.

En agosto de 2019 se realizó la primera de ellas, denominada Historias de emprendimiento por la paz. Los emprendimientos que se socializaron se gestaron en algunas de las 24 áreas de reincorporación para los excombatientes y sus familias, conocidas como Espacio Territorial de Capacitación y Reincorporación (ETCR), administradas por la ARN y ubicadas en distintas regiones del país. Allí se ofrecen procesos de reconciliación e integración con la sociedad tras el conflicto y la incorporación mediante proyectos productivos y talleres formativos apoyados por cooperación internacional.

La segunda conferencia se adelantó en septiembre con el panel El turismo en la reincorporación, en la que se destacaron experiencias como el senderismo y la práctica de deportes de aventura en el río Pato, en Caquetá; las expediciones biológicas que han permitido descubrir nuevas especies para la ciencia en la selva de Anorí, en el Nordeste de Antioquia; y la creación de una agencia turística en la vereda Tierra Grata, en el departamento de Cesar.

Y la tercera, también en septiembre, se dedicó al rol del sector empresarial y la academia en la construcción de paz y contó, precisamente, con la participación de excombatientes, representantes de la sociedad civil y la fuerza pública de Llano Grande (Dabeiba, Antioquia).

En 2019 se adelantaron, adicionalmente, ocho conferencias sobre construcción de paz, migración, democracia, corrupción y política social.

Con EAFIT, como uno de los organizadores, llegó también la gira itinerante que realizó la Justicia Especial para la Paz (JEP) por siete ciudades del país, con el panel Hacia la consolidación de la paz: balance y perspectivas de la justicia transicional en Colombia.​

## 16. Paz, justicia e instituciones sólidas

## 17. Alianzas para lograr ojetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)