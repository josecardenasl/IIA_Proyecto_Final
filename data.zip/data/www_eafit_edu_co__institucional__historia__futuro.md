# Futuro

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Hacia una nueva década: 2020-2030

*    Futuro 

La curva de Stanford sugiere que, en 2020, la humanidad pasará de duplicar su acervo de conocimiento de cada cinco años a cada 23 horas. Este es solo uno de los muchos indicadores que evidencian como, de la mano de las nuevas tecnologías de la información y la comunicación, y en el contexto de la Cuarta Revolución Industrial, la sociedad está dando un salto histórico hacia la nueva década que comienza. Y, por supuesto, las instituciones de educación superior serán fundamentales para responder a dicha transformación.

Precisamente el Itinerario EAFIT 2030 plantea, para los próximos años, una ruta en la que la Institución quiere consolidarse como una Universidad para todas las generaciones, un lugar en el que además de las personas que se han decidido por un campo específico de formación, también confluyan aquellos que apenas están comenzando a asombrarse con el conocimiento, o quienes después de largas experiencias de vida desean volver a contagiarse del deleite intelectual y ponerse en sintonía con este mundo de rápidos y permanentes cambios.

En consecuencia, con ese reto, será fundamental mantener el compromiso con los altos niveles de excelencia académica e investigativa, y también materializar un nuevo modelo educativo centrado en el aprendizaje que ponga al estudiante en el centro de su proceso y le permita desarrollar las capacidades para aprender a aprender a lo largo de la vida. De la mano de este anhelo se configurará un ecosistema, que ya tiene avances importantes, en el que metodologías, entornos y ambientes de aprendizaje coexistirán de manera articulada para propiciar nuevas experiencias formativas. Al aula tradicional se sumarán, entonces, nuevos espacios presenciales y virtuales, colaborativos, investigativos, de creación y de pedagogía inversa, entre otros, para garantizar que la experiencia universitaria de todas las generaciones sea verdaderamente transformadora. Y, entre todos estos, sin duda, se destacará el nuevo Edificio de Ciencias que, articulado con los conceptos de sostenibilidad y ciencia, se erigirá como un lugar de convergencia y diálogo entre diferentes áreas del saber.

Todo esto al tener en el centro el componente humanista, porque frente a esas competencias del presente, una de las promesas seguirá siendo, además de entregar a la sociedad profesionales comprometidos con el conocimiento científico y tecnológico, la formación de ciudadanos íntegros, responsables, , conscientes y conectados con su entorno, y comprometidos con la sociedad. Así, en un mundo que con seguridad seguirá atravesando por grandes cambios, EAFIT continuará respondiendo a su reciente Misión de contribuir al desarrollo sostenible de la humanidad gracias al cúmulo de experiencias recogidas en sus 60 años de vida institucional y con la mirada siempre puesta en los desafíos del futuro.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)