# From the School of Management to the School of Sciences and Humanities

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

Discover your profile at EAFIT

Are you a student, professor, graduate, or part of an organization? Explore the options and find the personalized information EAFIT has for you. Click on your profile and access resources, news, and events designed especially for you. Your EAFIT experience starts here!

**Your EAFIT experience starts here!**

Students and graduates

Employees

Teachers

Children and young people

Organizations

Close profiles

Information for you

*   That's EAFIT

Return

*   Study at EAFIT

Return

*   Science, Technology and Innovation

Return

*   Connecting with organizations

Return

*   Internationalization

Return

*   Culture and Wellbeing

Return

*   News

Return

###### **Let's transform together**

Let's make it possible for more young people to access university.

Close Menu

Accessibility

More information Activate contrast Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Language

Powered by [![Image 20: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Look for 

Search

Menu

# From the School of Management to the School of Sciences and Humanities

**Juan Rafael Cárdenas Gutiérrez, founder of EAFIT University, explains the reasons behind the creation of a School of Management 50 years ago and the subsequent addition of Engineering and Social Sciences.**

*    Testimonials 
*    From the School of Management to the School of Sciences and Humanities 

#### Recommended stories and news

###### The relevance of the teacher and their role in times of uncertainty and transformation

En tiempos en los que la información circula a velocidades inéditas y la inteligencia artificial transforma la manera de aprender, la figura del profesor sigue ocupando un lugar esencial. No solo por su capacidad para transmitir conocimiento, sino por algo más profundo: ayudar a interpretar el mundo, formular preguntas, acompañar procesos de transformación y construir criterio en medio de la incertidumbre.

May 14, 2026

###### EAFIT achieves its best result in the Saber Pro tests

EAFIT alcanzó en 2025 el mejor resultado de su historia reciente en las pruebas Saber Pro. La Universidad obtuvo un puntaje global de 179, seis puntos por encima de 2024 y el más alto de la serie comprendida entre 2021 y 2025. Además, se ubicó en el puesto 6 entre 274 instituciones de educación superior del país.

May 13, 2026

###### We celebrate a cohort that is transforming territories thanks to the Sura Foundation

Los retos que hoy enfrentan nuestros territorios trascienden lo técnico, y plantean nuevos desafíos relacionados con lo social, la ecología y los ecosistemas, las políticas públicas y la construcción de metodologías transdisciplinarias. Eso es lo que buscó la alianza entre la maestría en Procesos Urbanos y Ambientales de EAFIT y la Fundación Sura: generar nuevas maneras de relacionarse con los territorios y de construir estrategias colectivas para su transformación.

May 12, 2026

##### Our programs

_**Latest update**_

January 16, 2025

Study at EAFIT

Connect with EAFIT

Contact us

Legal information

University with Institutional Accreditation until 2026. 

Supervised by the Ministry of Education.

Our headquarters

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National hotline: 01 8000 515 900

Customer service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Customer service line: (57) 606 3214115, 606 3214119

Email: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 office 401

Customer service line: (57) 601 6114618

Email: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks

Original text

Rate this translation

Your feedback will be used to help improve Google Translate