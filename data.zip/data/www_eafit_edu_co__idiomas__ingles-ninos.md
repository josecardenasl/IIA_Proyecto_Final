# Programa de inglés para niños

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Programas de inglés para niños y niñas

### Edad 4 a 11 años

El programa de inglés para niños que combina el juego, la creatividad y el aprendizaje de un nuevo idioma de manera efectiva

*    Programas de Inglés Para Niños y Niñas 

Aventurero bilingüe:

### ​​Explorar

Fase de indagación y exploración

### ​​​​Descubrir​

Experiencias teórico - prácticas

### Crear​​

Reflexión y evaluación

En la aventura del aprendizaje de los idiomas hemos entendido que el conocimiento es capaz de transformarlo todo, y más cuando lo hacemos desde las preguntas, las respuestas, la curiosidad y la interacción.

En esta nueva expedición bilingüe y el método EDC: Explora, Descubre & Crea, estará la creatividad para que enfrenten nuevos desafíos; el pensamiento crítico, para que analicen y tomen decisiones informadas que potencien su autonomía; la resolución de problemas para que superen obstáculos con confianza, y la indagación y experimentación, que los llevará a aprender mediante la exploración activa.

Nuestro programa de inglés para niños y niñas se renueva:

### Nuevos libros y método propio EDC

### Cursos para niños desde los 4 años

### Desarrollo integral y fortalecimiento de las habilidades del siglo XXI ​

Elige la mejor opción para tus hijos

Inglés para niños y niñas

Happy Time - vacaciones en inglés para niños

English Stars - inglés para niños de 4 años

Inmersiones - inglés para niños

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)