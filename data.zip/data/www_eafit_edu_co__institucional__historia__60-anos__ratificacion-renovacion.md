# Ratific​ación y renovación de los principios fundacionales 60 años EAFIT - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Ratific​ación y renovación de los principios fundacionales 60 años EAFIT

*    60 Anos 
*    Ratific​ación y Renovación de Los Principios Fundacionales 60 Años EAFIT 

“En la ciudad de Medellín, a las 4:30 de la tarde del 4 de mayo de 1960, en las oficinas de la Asociación Nacional de Industriales (…)” se reunió un grupo de empresarios para crear una fundación que se regiría por las siguientes disposiciones:

“Proveer los medios educacionales para hombres y mujeres; atender las necesidades de la industria, el comercio y las finanzas; crear y mantener investigación y medios experimentales en el interés y desarrollo de la ciencia administrativa; atender consultas de la empresa privada y pública; fomentar la aplicación de los principios y técnicas de la administración científica como medio de estimular el progreso económico de Colombia”.

Este texto se constituye en uno de los estatutos fundacionales de la naciente Escuela de Administración y Finanzas, definidos doce lustros atrás en una ciudad de quinientos mil habitantes y de grandes industrias, y cuyo sustento filosófico marcó el camino a seguir.

Sin embargo, con la consideración de que son el resultado de un contexto histórico preciso que requería de una educación acorde con el momento que vivía el mundo, estos mandatos han requerido de una actualización que brinde respuesta a los retos propios de los tiempos.

Por eso hoy, con base en los ideales que nos legaron nuestros precursores, la comunidad eafitense reafirma y renueva los principios fundacionales de la Universidad, a la vez que asume el compromiso de orientar sus esfuerzos a que estos adquieran un mayor alcance para responder a un nuevo momento histórico y al que la Institución entrega un mensaje de esperanza con el Itinerario EAFIT 2030, y que como eafitenses nos llama hoy 4 de mayo de 2020 en este escenario virtual a:

Orientar todos nuestros esfuerzos a nuestro Propósito Superior de inspirar vidas e irradiar conocimiento para forjar humanidad y sociedad.

Reafirmar nuestro actuar en los valores institucionales de Integridad, Excelencia, Audacia, Responsabilidad y Tolerancia.

Valorar a los profesores, respetar a los estudiantes, crecer con los empleados y acompañar a los egresados como parte de nuestros principios rectores.

Inspirar, crear y transformar a través de cada iniciativa emprendida.

Contribuir al desarrollo sostenible de la humanidad mediante la oferta de programas que estimulen el aprendizaje a lo largo de la vida, promuevan el descubrimiento y la creación, y propicien la interacción con el entorno, dentro de un espíritu de integridad, excelencia, pluralismo e inclusión.

Convertir la Universidad en un ecosistema inteligente en permanente renovación, que conecta propósitos con conocimiento.

Alinear nuestras acciones con los Objetivos de Desarrollo Sostenible.

Caminar como grupo humano hacia 2030 de la mano de los itinerarios de Aprendizaje, descubrimiento, creación y cultura con sentido humano; Ecosistema inteligente y consciente; Alianzas para construir sociedad; y Sostenibilidad que genere confianza y esperanza.

Configurar el campus como un gran escenario en el que converjan las diferentes expresiones artísticas y como un epicentro cultural en el que se contribuya a la reconstrucción de tejido social.

Posicionar a EAFIT como una universidad en la que se educa en las aulas y se forma en el campus.

Hacer del aprendizaje una experiencia integral de vida en la que el estudiante es el protagonista y el profesor es un guía que orienta y acompaña.

Proyectar la Institución como una Universidad Parque en la que la infraestructura para el aprendizaje, el descubrimiento y la creación confluye con la naturaleza.

Formar líderes que dejen huella y que enarbolen con orgullo la impronta eafitense.

Consolidar a EAFIT como una universidad para todas las generaciones en la que se respeta y privilegia el pluralismo ideológico, y la diversidad.

Fortalecer nuestra idea de Universidad y ratificar el valor de esta para la sociedad.

##### ¿​Te unes a la ratificac​​ión y renovación de los principios fundacionales de EAFIT?​​

Para unirte solo debes escribir tu nombre y dar cli​c en el botón Acepto

¡Este e​s el número de eafitenses que ya se unieron a esta invitación!

El valor de la academia, la reivindicación de la ciencia y la tecnología, y el aporte de las profesiones a la solución de problemas y a la formulación de iniciativas en beneficio de un nuevo concepto de humanidad son signos de esperanza y de confianza para una sociedad que requiere construir optimismo sobre la certeza de que se necesita una ciudadanía ética, transparente y responsable.

Hoy ratificamos nuestro compromiso con el entorno y reescribimos la promesa de futuro que suscribieron los fundadores, hace exactamente 60 años, de brindar una educación de vanguardia y con la convicción de que la renovación es una constante que no se detiene y que está en un continuo movimiento. Y en esa línea seguimos avanzado, para que la sociedad encuentre en EAFIT soluciones pertinentes, audaces y permanentes, así como seres humanos, ciudadanos y profesionales íntegros que abran puertas y que aporten en la edificación de un mundo más equitativo en el que creemos firmemente y al que esperamos servir no solo en los próximos 60 años sino en el infinito que nos señala esta conmemoración.

Atentamente,

Cuerpos de gobierno y comunidad eafitense.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate