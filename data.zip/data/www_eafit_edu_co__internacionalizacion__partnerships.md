# Partnerships - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Partnerships

Welcome to the partnerships unit of Internationalization EAFIT. Our mission is to excel in partnership engagement, connecting partner interests with the academic capacities, Centers, and Schools our University. We extend EAFIT's global connections through partnership initiation, agreement coordination and hosting delegation visits.

*    Partnerships 

## **Agreements**

Agreement request

##### **Agreement request**

The request can be made by a professor, administrative staff of EAFIT, or an international institution.

1.   **Process done by:** International Institution or professor/staff member of EAFIT.
2.   **Estimated time:** with 3 months in advance.
3.   **Required documentation:** e-mail and agreement request form.

**Email address:**agreements@eafit.edu.co

Review by EAFIT

##### **Review by Universidad EAFIT**

Review of the request, the profile of the international institution, and drafting the preliminary agreement template

1.   **Process done by:** Internacionalización EAFIT (and academic responsible if necessary).
2.   **Estimated time:**15 business days after the initial request.

Review by partner

##### **Review by international partner institution**

Review of the draft agreement by the international partner Institution

1.   **Process done by:**International Partner Institution.
2.   **Estimated time*:** Approximately 1 month after the document is submitted by EAFIT.

*This deadline depends entirely on the review process and the timing of the international institution.

[In the event that the partner proposes a new version of the document with adjustments or modifications, the process will return to Stage 2 - EAFIT Review].

Legal review

##### **Review by the legal department of Universidad EAFIT**

Review of the final version of the agreement by the University's legal department.

1.   **Process done by:** legal department of Universidad EAFIT.
2.   **Estimated time:** 5 business days after the reception of the final version of the agreement.

EAFIT's signing process

##### **EAFIT's signing process**

The signing of the agreement by the Vice-Rector for Academic Affairs, legal representative of Universidad EAFIT.

1.   **Process done by:** Internacionalization EAFIT.
2.   **Estimated time:** 15 business days after the delivery of all documents.
3.   **Documents:** The academic responsible for the agreement at EAFIT must sign both the agreement and the Approval for Agreement Signing Form.

Signing process

##### **Signing process by the partner institution**

The partner signs the agreement received from Universidad EAFIT

1.   **Process done by:** Partner Institution.
2.   **Estimated time*:**About 1 month after the signed agreement was sent.

*This deadline depends entirely on the timing of the international institution.

*   Articulation with EAFIT's Centers of Incidence and Study
*   Calendar of cultural, academic, athletic, or extension activities that have an international or second language component.
*   Incoming Study Abroad groups.
*   Intellectual production with international scope: papers, conferences, articles, book chapters, patents, co-authorships, etc.
*   International Agreements.
*   International accreditations.
*   Internationalization at home activities.
*   Internship abroad.
*   Language Center
*   Membership in International Networks and Associations.
*   Participation in cooperative international projects.
*   Policy on foreign languages and proficiency in second languages.
*   Research groups.
*   Student exchange for research activities and internships.
*   Teaching-learning methods used for internationalizing the curriculum.
*   Visiting professors.

Universidad EAFIT gives priority to alliances with institutions of significant quality and recognition. These partnerships usually involve joint programs, co-funded research, faculty, and student mobility.

As mentioned above, EAFIT establishes strategic relationships with high-quality national and international partners, with whom we share our core values and develop unique long-term partnerships that contribute to:

Fulfill both institutions' mission.

Offer students, faculty, and staff a wide range of opportunities to enhance their international competencies and reach.

Support capacity building with an institutional scope.

Our international partnerships span a diverse range of countries, languages, and objectives, established under the following principles:

1.   Reciprocity.
2.   Trust.
3.   Commitment.
4.   Sustainability.

## Contact

Global Engagement

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate