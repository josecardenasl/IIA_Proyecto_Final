# Ciencias Políticas - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Pregrado

# Ciencias Políticas

SNIES: 1​​​​​9032, Medellín

Aquí entenderás el poder y sus formas, los fenómenos políticos, así como el funcionamiento de sus sistemas. A lo largo del programa analizarás cómo los seres humanos nos ponemos reglas para vivir en sociedad. Es decir, cómo hacemos para que la cultura, economía, moral, política, religión, democracia, ética, etcétera, se ajusten a los ámbitos organizacionales, sociales y políticos.

Si te interesa liderar procesos de toma de decisiones, te preocupan la igualdad, los temas de democracia y equidad, quieres incidir y proponer soluciones a problemas públicos y privados, este pregrado es para ti.

*    Escuela Finanzas Economia Gobierno 
*    Ciencias Políticas 

## Registro calificado

Resolución 11926 del 14 de noviembre de 2019, otorgada por el Ministerio de Educación Nacional con vigencia de 8 años.

## Acreditación de alta calidad

Resolución 18592 del 3 de diciembre de 2018​, otorgada por el Ministerio de Educación Nacional con vigencia de 8 años.​

Duración

9 Semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1​​​​​9032

Valor del primer semestre

$15.442.901

Valor promedio de los semestres

$14.138.834

Becas y financiación

## Sobre el programa

Calidad y excelencia

**Somos top en el mundo**

Somos la mejor Escuela de Finanzas, Economía y Gobierno de Antioquia, según el Ranking QS.

Como pregrado estamos acreditados en alta calidad por ocho años.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

Nuestra escuela cuenta con DataPol, nuestro laboratorio de datos, métodos y análisis político; el Laboratorio y Consultorio Financiero; el Centro de Estudios e Incidencia, Valor Público y el Centro de Innovación y Desarrollo Social, EAFIT Social.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: somos epicentro de grandes debates políticos, electorales y de ciudad.

**Tenemos proyección y presencia nacional**

Tenemos sede en Pereira y ofrecemos posgrados en Bogotá, ambas con flexibilidad de clases presenciales cada quince días o cada mes, según el programa.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como la mejor ciudad universitaria a nivel regional, según el ICU (Índice de Ciudades Universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año, EAFIT recibe 240 estudiantes de más de 15 países del planeta y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Contamos con 7 líneas de énfasis para que puedas escoger cómo complementar tu desarrollo profesional entre: construcción de paz, gobierno y políticas públicas, comunicación política, derecho público, relaciones internacionales, gestión de proyectos y gerencia financiera público-privada.

Innovación y liderazgo

**Somos innovación en educación**

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinaria gracias a las cinco escuelas de EAFIT y a las tres áreas (mercados y estrategia financiera, macroeconomía y sistemas financieros, y políticas y desarrollo) que las configuran.

Contamos con metro pre, una posibilidad para homologar materias desde el pregrado para conectar con la maestría en gobierno y políticas públicas y la maestría en comunicación política.

**Cultivamos el liderazgo temprano y la investigación**

En EAFIT tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Como Escuela, tenemos 7 semilleros de investigación y 4 grupos de investigación.

Conexiones e incidencias

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo:**

Contamos con centro de estudios e incidencia, Valor Público y con un espacio de innovación y desarrollo social: EAFIT Social.

Además, trabajamos de la mano con Urbam, nuestro centro de estudios urbanos y ambientales.

Tenemos a ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

Somos miembro activo de la Asociación Colombiana de Ciencia Política (ACCPOL). También somos parte de IPSA (International Political Science Association).

Anualmente publicamos la revista de investigación Cuadernos de Ciencias Políticas, en la que nuestros estudiantes exponen sus resultados de investigación tanto desde lo teórico como desde lo aplicado hacia la solución de problemas.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

Tenemos una relación estrecha con la Universidad de Salamanca, por su tradición e incidencia en el análisis y resolución de problemas políticos y sociales.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrados han empezado sus emprendimientos. Doce de ellos están en la lista de las 100 mejores start-ups de Colombia.

## Plan de estudios

## Profesores

## Escuela de Finanzas, Economía y Gobierno

## Pruebas Saber Pro

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Derecho

Duración

10 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 7227

Valor del primer semestre

$14.825.185

Valor promedio de los semestres

$14.886.956

Becas y financiación

#### Comunicación Social

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 17691

Valor del primer semestre

$14.825.185

Valor promedio de los semestres

$14.550.644

Becas y Financiación

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate