# Testing Center - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Testing Center

Certifica tu nivel de idioma con exámenes internacionales, reconocidos a nivel académico y profesional.

*    Testing Center 

###### **Exámenes de suficiencia**

​​​El Testing Center de Idiomas EAFIT es un espacio adecuado para la administración de exámenes y certificaciones nacionales e internacionales en la ciudad. Actualmente contamos con cerca de 12 exámenes en idiomas tales como IELTS, TOEFL, CELPE entre otros. ​

Inglés

## Track Test 4 Competencias virtual

## Track Test comprensión lectora

## Track Test 4 competencias presencial

## IELTS

## TOEFL IBT

## APTIS for teachers

## APTIS general

## Oxford Test of English

Con los exámenes del Testing Center puedes cumplir la Política​ de Lengua Extranjera.

Portugués

###### **​​​​​​​​​​​​​​​​CELPE-BRAS**

El Certificado de Proficiência em Língua Portuguesa para Estrangeiros es desarrollado por el Ministerio de Educación de Brasil y es el único certificado de suficiencia en portugués reconocido oficialmente por el Gobierno de Brasil. Esta certificación está contemplada dentro de la política de lengua extranjera de la Universidad EAFIT.

**EXAMEN CELPE–BRAS EDICIÓN 2026 - I**

**Calendario Examen Celpe-Bras edición 2026 - I**

- Fechas de inscripción: 24 de febrero al 6 de marzo de 2026.

- Pago del valor de la inscripción: 24 de febrero al 6 de marzo de 2026.

- Fecha límite de pago: 06 de marzo de 2026.

- Aplicación de las pruebas (parte escrita y parte oral): 28, 29 y 30 de abril del 2026.

- Divulgación de los resultados: 30 de junio de 2026.

- Valor del examen: $504.000 pesos.

**Sitio web para la inscripción:**

**Pasos para completar la inscripción:**

1.   Complete todos los campos de la ficha de inscripción. Asegúrese de darle finalizar al registro. Si tiene dudas, comuníquese con IBRACO al correo electrónico [dudascelpebras@ibraco.org.co](mailto:dudascelpebras@ibraco.org.co)
2.   Asegúrese de ingresar su nombre y apellido tal como aparecen en su documento de identidad, inscríbase con su número de cédula y/o tarjeta de identidad ya que el certificado se expedirá con esos datos y no podrán corregirse después.
3.   Responda todo el cuestionario en portugués sin dejar ningún campo en blanco.
4.   Importante: Guarde su usuario y contraseña, ya que los necesitará para descargar e imprimir su certificado.

**Documentación física:**

1.   Formato de autorización y tratamiento de datos [(descargar documento).](https://universidadeafit.widen.net/s/tmghkzcc2j/hoja-de-registro-y-autorizacion-de-datos-celpe-2025)
2.   Copia de su documento de identidad, incluyendo los datos de correo electrónico, teléfono celular, dirección y ciudad de residencia.
3.   Comprobante de pago de la inscripción: Realice una consignación o transferencia (pantallazo impreso) a la cuenta de ahorros No. 0062 0037 9383 de DAVIVIENDA, a nombre de IBRACO Nit 830015104-4. El valor del examen para las ciudades de Bogotá y Medellín es de $504.000 pesos.
4.   Comprobante de inscripción: Puede obtenerlo en [http://celpebras.inep.gov.br/celpebras/](http://celpebras.inep.gov.br/celpebras/), en la opción Página do Participante/Coordenador. Ingrese con su correo y contraseña, luego haga clic en “inscrições” y después en la lupa. Intente imprimir o guardar en PDF, o tome un pantallazo.
5.   Cuestionario impreso: Ingrese al mismo sitio web, en la opción Página do Participante/Coordenador, y siga el mismo procedimiento para obtener el cuestionario. Haga clic en el lápiz en "Ação" y luego imprímalo o guárdelo en PDF, o tome un pantallazo.

_Una vez haya completado la inscripción, deberá enviar en físico los documentos a Bogotá – Edificio IBRACO Calle 104 #15-31 a nombre de Pilar Mora._

**Nota importante:**Recuerde enviar toda la documentación lo mas pronto posible, antes del 9 de marzo, para que sea recibida sin contratiempos y no afecte la inscripción al examen.

Es responsabilidad del candidato descargar su certificado, para obtener su certificado: [http://celpebras.inep.gov.br/celpebras/](http://celpebras.inep.gov.br/celpebras/) con su usuario y la clave creada al momento de la inscripción.

**Observaciones**

1.   Bajo ninguna circunstancia se hace devolución del dinero correspondiente a la inscripción.
2.   Los candidatos deben ser oriundos de países cuya lengua oficial no sea el portugués, ser mayores de 16 años y con escolaridad equivalente o superior al bachillerato.
3.   Cualquier duda o pregunta frente al proceso de inscripción al examen, podrá ser consultada en el correo: [dudascelpebras@ibraco.org.co](mailto:dudascelpebras@ibraco.org.co)
4.   Para mayores informaciones, consulte la página http://www.ibraco.org.co o escríbanos al correo [testingcenter@eafit.edu.co](mailto:testingcenter@eafit.edu.co)
5.   EAFIT como puesto examinador, facilita al estudiante la presentación de la prueba en sus instalaciones. Sin embargo, el proceso de inscripción-pago es directamente con Ibraco Bogotá ( [dudascelpebras@ibraco.org.co](mailto:dudascelpebras@ibraco.org.co); [celpebrasbogota@ibraco.org.co](mailto:celpebrasbogota@ibraco.org.co)) y la calificación-entrega de resultados es administrado en su totalidad por INEP ( Instituto Nacional de Estudios y Pesquisas Educacional ) [https://www.gov.br/inep/pt-br​](https://www.gov.br/inep/pt-br%E2%80%8B)

**Con los exámenes del Testing Center puedes cumplir la Política​ de Lengua Extranjera.**

**Aclaraciones finales:**

- En caso de presentarse alteraciones en la fecha, cancelación o realización del examen, IBRACO procederá a entrar en contacto con todos los inscritos e informar los pasos y acciones a seguir.

- Una vez enviada la citación al examen no se aceptarán solicitudes de devolución de dinero, solo se aceptará el aplazamiento del mismo. El proceso de inscripción es responsabilidad del candidato.

- En caso de aplazamiento entrar en contacto con la Coordinación de Procesos Académicos, Stella Miranda, [matriculas@ibraco.org.co](mailto:matriculas@ibraco.org.co)

- Para mayores informaciones, consulte la página [http://www.ibraco.org.co](http://www.ibraco.org.co/)

- Los resultados del examen demoran tres meses luego de la presentación del mismo.

- Para obtener su certificado: [http://celpebras.inep.gov.br/certificacao](http://celpebras.inep.gov.br/certificacao) con el correo electrónico y la clave creada al momento de la inscripción.

Italiano

**Certificación PLIDA**

La certificación **PLIDA (Progetto Lingua Italiana Dante Alighieri)** es un diploma expedido por la **Società Dante Alighieri di Roma** la cual es coordinadora de las Asociaciones Dante Alighieri de todo el mundo, esta característica le confiere un alto reconocimiento internacional. Esta certificación está contemplada dentro de la política de lengua extranjera de la Universidad EAFIT.

**Estructura del examen**

El examen consiste en **4 pruebas**: lectura (leggere), escucha (ascoltare), producción escrita (scrivere), y producción oral (parlare).

**Proceso de inscripción**

1.   Ingrese a la página web [www.dantebogota.com](https://www.dantebogota.com/)
2.   Diligencie el registro de inscripción en el formulario habilitado respectivamente.
3.   Una vez realizado el registro, cancele el valor del examen en el botón de PSE ubicado en el sitio web.
4.   Por último, envié el soporte de pago al correo [societadante@dantebogota.com](mailto:societadante@dantebogota.com) con sus datos personales.

**Inversión**

$815.000​

**Calendario 2026**

| Fecha del examen | Niveles | Fecha límite de inscripción |
| --- | --- | --- |
| Junio 9, 10 y 11 | B1, B2, C1 | Mayo 27 |
| Noviembre 17, 18, 19 | A2, B1 | Noviembre 4 |
| Noviembre 18, 19, 20 | B2, C1, C2 | Noviembre 4 |

***El examen se llevará a cabo si hay un mínimo de ​6 candidatos para el mismo.**

**Notificación de resultados**

Los resultados se darán a conocer **3 meses** después de presentado el examen y el certificado se entrega **5 meses** después de presentado el examen.

**Observaciones**

1.   La administración del examen está sujeta a contar con el número mínimo de candidatos inscritos establecido por Idiomas EAFIT. En caso de cancelarse la administración de la prueba, se hará devolución del dinero pagado por el candidato.
2.   El mínimo de candidatos inscritos establecido para 2025 es de 6 participantes.

Con los exámenes del Testing Center puedes cumplir la Política​ de Lengua Extranjera.

###### **Cursos de preparación**

​​​​​​​​​​​​​​​​​​​​​​​​​Los cursos de preparación para exámenes internacionales están dirigidos a participantes de 17 años en adelante y constan de 38 horas cada uno. A través de los cursos los participantes conocerán la estructura de los exámenes, las instrucciones específicas y el tipo de lenguaje que encontrarán. Además de familiarizarse con la prueba, los participantes practicarán con pruebas de simulacro y estrategias para responder las preguntas.​

Preparación TOEFL

**Prepárate para tu examen TOEFL y aprende cómo mejorar tu puntaje.**

​​​​Este curso te ayudará a comprender lo que puedes hacer para alcanzar un mejor puntaje. Un profesor calificado te guiará a través de cada sección (lectura, comprensión auditiva, expresión oral y escritura) utilizando preguntas de exámenes anteriores y de muestras de ensayos y respuestas orales de candidatos que pasaron la prueba con los que te familiarizarás con los tipos de preguntas de la prueba.

**Sobre el curso**

1.   Tiene una duración de 38 horas, dividido en 19 sesiones de 2 horas cada una.
2.   Es dictado presencial en la sede Poblado, por docentes de Idiomas EAFIT, expertos en la preparación para este tipo de exámenes.
3.   Después de una evaluación inicial, determinamos en qué partes de la prueba necesitarás mayor atención para maximizar tus resultados.
4.   La clase está diseñada para brindarte estrategias y preparándote sección a sección para tomar la prueba.
5.   Tomarás varias pruebas a lo largo del curso con las que te harás una idea más clara de qué tan cerca estás de alcanzar tu meta.

**A quién está dirigido**

1.   Estudiantes que requieren esta prueba como requisito de ingreso a un programa académico.
2.   Candidatos a becas y certificaciones profesionales.
3.   Estudiantes de inglés que quieren seguir su progreso o requieren esta prueba como requisito de grado.
4.   Estudiantes y trabajadores que solicitan visas en determinados países.
5.   Profesores de inglés que quieran prepararse para ser profesores de cursos de preparación para TOEFL.

**Inscripción**

1.   Los interesados deben tomar un examen de clasificación pues el requisito mínimo es haber aprobado el curso Intermediate 2 del programa de inglés general o clasificar en el curso Intermediate 3.​
2.   Este curso se llevará a cabo con un mínimo de 5 candidatos y un máximo de 10 candidatos.
3.   **Este curso te ayudará a identificar el estado actual de tu nivel de suficiencia, pero el objetivo principal no es mejorar tu nivel de idioma y no garantiza ningún resultado a la hora de tomar el examen.​**

**Inversión**

$947.000

**Horario**

**Sede Poblado**

**Lunes y miércoles:**6:30 p.m. a 8:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Marzo 13 | Noviembre 18 - Enero 19 |
| Marzo 25 | Junio 1 | Febrero 2 - Marzo 25 |
| Julio 13 | Septiembre 11 | Mayo 25 - Julio 13 |
| Septiembre 21 | Noviembre 27 | Julio 27 - Septiembre 21 |

* No hay clase el lunes 20 de abril por Jornada de Desarrollo Docente.

**No hay clase el lunes 5, miércoles 7, ni viernes 9 de octubre por semana de receso escolar.

Solicita tu clasificación y realiza tu inscripción a través de EPIK, ingresa haciendo [clic aquí.](https://view.genially.com/683493012034b378cff3aed5/guide-clasificaciones)

Preparación IELTS

**​​​​Prepárate para tu examen IELTS y realiza tu examen con confianza.**

​En este curso encontrarás docentes altamente calificados y una variedad de materiales y recursos que te ayudarán a mejorar tus habilidades en las cuatro áreas de la prueba: comprensión auditiva, lectura, escritura y expresión oral.

**Sobre el curso**

1.   Tiene una duración de 38 horas, dividido en 19 sesiones de 2 horas cada una.
2.   Al inicio del curso se hace un examen de diagnóstico que te ayudará a identificar las áreas en las que deberás concentrarte más.
3.   A lo largo del curso se explora en detalle cada una de las cuatro partes de la prueba; se examinan los criterios de evaluación y lo que se necesita para lograr puntuaciones en las bandas altas; se explora la variedad de tipos de tareas que se ven en todas las partes de la prueba y se comparten técnicas que te ayudarán a prepararte para el examen.
4.   Al final del curso, tomarás una prueba de salida con la que te harás una idea más clara de qué tan cerca estás de alcanzar tu meta.

**A quién está dirigido**

1.   Cualquier persona que se esté preparando para tomar el examen IELTS para propósitos académicos o fines migratorios.
2.   Estudiantes que quieren seguir su progreso de aprendizaje del inglés o requieren esta prueba como requisito de grado.
3.   Profesores de inglés que quieran prepararse para ser profesores de cursos de preparación para IELTS.

**​Inscripción**

1.   Los interesados deben tomar un examen de clasificación pues el requisito mínimo es haber aprobado el curso Intermediate 2 del programa de inglés general o clasificar en el curso Intermediate 3.​
2.   Este curso se llevará a cabo con un mínimo de 5 candidatos y un máximo de 10 candidatos.
3.   **Este curso te ayudará a identificar el estado actual de tu nivel de suficiencia, pero el objetivo principal no es mejorar tu nivel de idioma y no garantiza ningún resultado a la hora de tomar el examen.​**

**Inversión**

$947.000​

**Horario**

**Sede Poblado**

Martes y jueves​ de 6:30 p.m. a 8:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Marzo 19 | Noviembre 18 - Enero 20 |
| Marzo 24 | Mayo 28 | Febrero 2 - Mayo 28 |
| Julio 14 | Septiembre 10 | Mayo 25 - Julio 14 |
| Septiembre 15 | Noviembre 19 | Julio 27 - Septiembre 15 |

* No tienen clase el martes 6 ni el jueves 8 de octubre por semana de receso escolar.

Solicita tu clasificación y realiza tu inscripción a través de EPIK, ingresa haciendo [clic aquí](https://view.genially.com/683493012034b378cff3aed5/guide-clasificaciones).

Preparación CELPE-Bras

**Prepárate para tu examen CELPE-Bras y certifica tu nivel de portugués**

Este curso-taller te permitirá comprender a profundidad la estructura del examen **CELPE-Bras (Certificado de Proficiência em Língua Portuguesa para Estrangeiros)** y desarrollar estrategias efectivas para afrontar cada una de sus secciones con seguridad.

A través de un enfoque práctico, trabajarás en la comprensión y producción oral y escrita utilizando materiales auténticos basados en pruebas reales.

**Sobre el curso**

1.   Tiene una duración de 20 horas, divididas en 10 sesiones de 2 horas cada una.

**Durante el curso:**

*   Conocerás la estructura del examen y sus criterios de evaluación.
*   Desarrollarás habilidades de comprensión auditiva, lectura, producción oral y escrita de manera integrada.
*   Trabajarás con ejercicios contextualizados que fortalecen el uso real del idioma (componentes gramaticales, léxicos y fonéticos).
*   Realizarás simulacros de la prueba escrita y de la entrevista oral con formatos de exámenes anteriores.
*   Recibirás retroalimentación detallada basada en la escala oficial del CELPE-Bras.

**A quién está dirigido:**

*   Personas que desean certificar su nivel de portugués para fines académicos o profesionales.
*   Candidatos que requieren el CELPE-Bras para procesos migratorios o educativos en Brasil.
*   Estudiantes de portugués con nivel intermedio o avanzado que desean prepararse estratégicamente para la prueba.
*   Profesores de portugués interesados en conocer la estructura y evaluación del examen.

**Inscripción:**

*   Es requisito contar con un nivel intermedio o avanzado de portugués.
*   Este curso es de preparación para el examen, no es un curso de aprendizaje del idioma.
*   El grupo se abre con un mínimo de 5 estudiantes.

**Evaluación y práctica**

Los estudiantes realizarán:

*   Simulacros de la prueba escrita.
*   Simulación de la entrevista oral (formato real con dos evaluadores).

El facilitador brindará retroalimentación individual, identificando errores frecuentes y ofreciendo estrategias concretas para mejorar el desempeño.

**Inversión**

$550.000​

**Horario**

**Sede Poblado**

Lunes y miércoles de 6:30 p.m. a 8:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Marzo 11 | Abril 23 | Marzo 2 a marzo 10 |

**Información importante**

Este curso te permitirá identificar tu nivel actual y prepararte estratégicamente para el examen; sin embargo, no garantiza un resultado específico en la prueba oficial.

###### Preguntas frecuentes

​​​Conoce nuestros protocolos e información general sobre nuestro Testing Center.

1.   Estudiantes que desean ingresar y/o egresar en una institución de educación superior.
2.   Estudiantes en proceso de admisiones y/o egreso del programa de aprendizaje del idioma inglés.
3.   Candidatos que desean presentarse para obtención de becas y certificaciones.
4.   Alumnos de diferentes programas de aprendizaje en idiomas, que desean controlar su progreso.
5.   Estudiantes y trabajadores que solicitan visas.
6.   Empresas y/o instituciones que requieran comprobar la suficiencia en idioma durante los procesos de selección de personal, analizar y certificar el nivel de inglés de sus empleados, hacer un seguimiento de la efectividad de los programas de formación lingüística, evaluar a sus empleados con vistas a ascensos o cargos en el extranjero.​

¿Quieres o te exigen presentar un examen de nivel de inglés, pero no sabes cuál es el adecuado para ti? ¿cuál es la diferencia entre uno y otro de tantos existentes en el mercado? ¿existe algún examen que me diagnostique mi nivel antes de decidir presentar un examen oficial?

La información a continuación puede orientarte un poco y llevarte a tomar la decisión más adecuada para tus necesidades.​

​Una diferencia importante entre todos los exámenes existentes es la validez de los resultados. Dicha validez está sujeta a las políticas y reglamentos de la institución académica, empresa, embajada, etc. solicitante de la prueba. Todas las instituciones son libres de aceptar el o los exámenes que mejor se adecuen a sus reglamentos internos.

Por ejemplo, los exámenes **IELTS y TOEFL** suelen ser más convenientes para los visados, trabajos o solicitudes de admisión universitaria que tengan como requisito de aceptación la posesión de un determinado nivel de inglés.

Exámenes como el **TOEIC, APTIS, TRACK TEST y Oxford Test of English​**son exámenes de inglés cuya novedad es la flexibilidad que aporta al poder evaluar de forma independiente una, dos, tres o todas las competencias del idioma. Estos exámenes son altamente aceptados en las universidades de Colombia.​

Ten en cuenta que cada examen tiene un proceso de inscripción diferente ,el cual varía dependiendo de la casa matriz del mismo.

Los tiempos de entrega también varían dependiendo de las políticas internas del ente oficial del examen. Ten presente el tiempo para tu examen de preferencia.

APTIS

CELPE-BRAS

DELE

IELTS

OTE

PLIDA

TOEFL

TOEIC

TRACK TEST 4 COMPETENCIAS

TRACK TEST COMPRENSIÓN LECTORA

5 días hábiles

4 meses

4 meses

7 días hábiles

15 días hábiles

4 meses

7 días hábiles

15 días hábiles

8 días hábiles

8 días hábiles

| Examen | Valor |
| --- | --- |
| Track Test 4 Competencias presencial | $ 380.000 |
| Track Test 4 Competencias virtual | $ 430.000 |
| Track Test Comprensión Lectora | $ 275.000 |
| Repetición Track Test presencial | $ 185.000 |
| Repetición Track Test virtual | $ 233.000 |
| Aptis for Teachers | $ 412.500 |
| Aptis for Teachers docentes EAFIT | $ 320.000 |
| Aptis General | $ 412.500 |
| Oxford Test of English | $ 486.000 |
| Oxford Test of English una sola habilidad | $ 204.000 |
| TOEFL | $256 dólares |
| IELTS | $ 1.045.700 |
| PLIDA | $ 770.000 |
| CELPE-BRAS | $ 504.000 |

_*Ten en cuenta que estos precios pueden variar en función de tu ubicación y están sujetos a cambios._

**Valores de exámenes de otros idiomas diferentes al inglés a través de nuestra página web.**

​Días antes de presentar la prueba, te llegará un correo electrónico con la citación oficial al examen y las instrucciones que debes seguir para presentarlo.

Para todos, siempre deberás presentar tu documento de identidad ORIGINAL.

Dependiendo si tu examen es a lápiz o a computador deberás traer implementos tales como: lápiz mina # 2, borrador, sacapuntas, lapicero negro.​

**Acceso peatonal:** por la portería de Argos, Las Vegas e Idiomas.​

**Acceso vehicular:** p la portería sur sobre la Avenida las Vegas después de Macrollantas, la del Plástico y del Caucho sobre la Av. Regional y la de Idiomas.

**Acceso de motocicletas:** por la portería sur sobre la Avenida las Vegas después de Macrollantas y la de Idiomas.

Debes tener en cuenta que el pico y placa también rige dentro de la Universidad.

**Valor parqueadero carros** $ 6.000 el día

**Valor parqueadero motos** $ 3.000 el día​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)