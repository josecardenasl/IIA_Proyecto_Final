# Década de 1960 - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Década 1960

En la década de 1960, Medellín se encontraba en pleno desarrollo industrial gracias, en gran parte, al crecimiento del sector textilero.

*    Década de 1960 

**EAFIT, la de la década de 1960, graduó a los primeros administradores de negocios del país​**

En la sede del Banco Central Hip​otecario, ubicado en el centro de Medellín, se materializó el sueño d​​e 18​ empresarios, líderes de importantes organizaciones del país. Allí, el 17 de agosto de 1960 fue impartida por el docente norteamericano Bernard J. Hargadon Jr. la primera clase de la Escuela de Administración y Finanzas (EAF).​

La intención, de la entonces naciente institución de educación superior, era apoyar el rápido crecimiento industrial que enfrentaba el país para la época y formar personas idóneas que lideraran el sector empresarial.

Así, con la firma de un acta el 4 de mayo de 1960, donde participaron los precursores de la iniciativa y empresas destacadas de la industria antioqueña, EAFIT​ se hizo tangible y dio el primer paso para ser reconocida por el Ministerio de Educación Nacional el 11 de junio del mismo año.

Sus primeros cursos se dictaron en una casa alquilada, ubicada entre las calles El Palo y La Playa, en el centro de la capital antioqueña. Allí, elegidos entre 200 aspirantes, 59 estudiantes provenientes de diferentes ciudades del país se acomodaron para iniciar el camino que años más tarde les otorgaría el título de administradores de negocios, los primeros graduados en Colombia. Pero la década de 1960 no solo dejó huella por hacer realidad el sueño de capacitar, en el ámbito nacional, líderes para el sector empresarial colombiano, sino que representó grandes logros para la Institución.

La creación del Instituto Tecnológico (IT), pensado en 1961, fue uno de los más representativos, gracias al aporte económico y en infraestructura de la Fundación Whirlpool y del programa Tools for Freedom.

Este hito no solo le agregó las letras I y T a la Universidad, que de ahí en adelante se denominaría EAFIT, sino que evidenció la necesidad de conseguir un espacio propio. Así, en el año 1962, en un lote ubicado en el sector de La Aguacatala, al sur de Medellín, se inició la construcción de lo que integraría a la Escuela con el Instituto Tecnológico.

El nuevo espacio contó con aportes extranjeros y de fondos especiales de la Corporación Educativa de la Industria, y para 1963 ya todo estaba listo para el traslado de los estudiantes a la nueva sede, la misma donde hoy, medio siglo después, se continúa consolidando la Universidad.

Pero los avances no solo fueron en infraestructura. Los logros académicos estuvieron marcados por la firma de un convenio con la universidad estadounidense Syracuse, que permitió impulsar el crecimiento eafitense. ​

Gracias a este convenio, un grupo de docentes de la prestigiosa institución norteamericana viajó por primera vez para asesorar a la Universidad en cuanto a sus planes de estudio, los programas ofrecidos por las diferentes áreas de estudios, entre otros aspectos. EAFIT comenzó entonces a fortalecer lazos y se aventuró a proyectarse tanto nacional como internacionalmente.​

A finales de la década de 1950, un grupo de industriales y otros empresarios soñaron con la idea de que el país contara con una carrera universitaria que en su ADN llevara la palabra “Administración”. Agrupados en el gremio de los industriales de la ANDI, ese anhelo se hizo tangible, el 4 de mayo de 1960, a las 4:30 de la tarde, con la firma del acta con la que se formalizó la creación de la entonces Escuela de Administración y Finanzas (EAF). El 11 de junio, del mismo año, la institución especializada, constituida como fundación, fue reconocida por el Ministerio de Educación Nacional. Dos meses después, el 17 de agosto, el docente norteamericano Bernard J. Hargadon Jr. ofreció la primera clase de contabilidad en una sede prestada del Banco Central Hipotecario en Medellín, ubicada en la calle Colombia del centro de la ciudad.

En la década de 1960, Medellín se encontraba en pleno desarrollo industrial. Si bien la Escuela Nacional de Minas formaba ingenieros con un énfasis en administración, el programa de Administración de Negocios de EAF fue una iniciativa pionera que les aportó a Medellín y a Colombia profesionales dedicados exclusivamente a este campo del conocimiento y a la dirección de las empresas que lideraban el crecimiento económico de la época. El reto de la Escuela fue formar líderes que resp​ondieran a los desafíos que implicaban hacer crecer los negocios existentes, constituir nuevas industrias y dirigir a una cantidad importante de trabajadores.

El 19 de febrero de 1962, con el apoyo de la fundación Whirlpool y del programa Tools for Freedom del Gobierno de los Estados Unidos, nació el Instituto Tecnológico, entidad asociada a la Escuela que ofrecía las tecnologías Industrial, Textil y Mecánica (1965). Así, a la Escuela de Administración y Finanzas se añadió el nombre de Instituto Tecnológico, lo que complementó su nombre de EAFIT. Este fue un punto de partida para el surgimiento de las carreras tecnológicas en Colombia. De esta manera, la Institución comenzó a destacarse por proponer soluciones a las demandas socioeconómicas del país.

El modelo pedagógico de EAFIT se inspiró en el de las universidades estadounidenses. En esos años, Estados Unidos promovió en Latinoamérica el programa Alianza para el Progreso, que favoreció los estudios en economía y administración para impulsar al sector privado y apoyar el desarrollo del sector público. De manera que no es casual que varias entidades estadounidenses (Syracuse University, Drexel Institute, Burlington Mills) apoyaran a EAFIT con profesores, asesorías, becas y material bibliográfico. Con esta primera institución, se firmó un convenio, que se ha renovado en el tiempo y que ha contribuido a impulsar el crecimiento de la Universidad y avanzar con una visión internacional que permea la formación.

En la década de 1960, Medellín se encontraba en pleno desarrollo industrial. Si bien la Escuela Nacional de Minas formaba ingenieros con un énfasis en administración, el programa de Administración de Negocios de EAF fue una iniciativa pionera que les aportó a Medellín y a Colombia profesionales dedicados exclusivamente a este campo del conocimiento y a la dirección de las empresas que lideraban el crecimiento económico de la época. El reto de la Escuela fue formar líderes que resp​ondieran a los desafíos que implicaban hacer crecer los negocios existentes, constituir nuevas industrias y dirigir a una cantidad importante de trabajadores.

El 19 de febrero de 1962, con el apoyo de la fundación Whirlpool y del programa Tools for Freedom del Gobierno de los Estados Unidos, nació el Instituto Tecnológico, entidad asociada a la Escuela que ofrecía las tecnologías Industrial, Textil y Mecánica (1965). Así, a la Escuela de Administración y Finanzas se añadió el nombre de Instituto Tecnológico, lo que complementó su nombre de EAFIT. Este fue un punto de partida para el surgimiento de las carreras tecnológicas en Colombia. De esta manera, la Institución comenzó a destacarse por proponer soluciones a las demandas socioeconómicas del país.

Sus primeros cursos se dictaron en una casa alquilada, ubicada entre las calles El Palo y La Playa, en el centro de la capital antioqueña. Allí, elegidos entre 200 aspirantes, 59 estudiantes provenientes de diferentes ciudades del país se acomodaron para iniciar el camino que años más tarde les otorgaría el título de administradores de negocios, los primeros graduados en Colombia. Pero la década de 1960 no solo dejó huella por hacer realidad el sueño de capacitar, en el ámbito nacional, líderes para el sector empresarial colombiano, sino que representó grandes logros para la Institución​.

El proyecto de consolidar una universidad con diferentes programas que apoyarían el desarrollo colombiano llevó a la búsqueda de un espacio propio en el que se pudieran integrar la Escuela con el Instituto Tecnológico. En 1963 comenzaron las clases en un lote ubicado en el sector de La Aguacatala (sur de Medellín), sede desde la que EAFIT empezó su proceso de fortalecimiento y expansión.

## Hitos de la década

Firma del acta de constitución de la Escuela de Administración y Finanzas (EAF).

Los empresarios que se encontraban a las 4:30 p.m., del día 4 mayo de 1960 en una de las oficinas de la Andi, firmaron una acta por medio de la que constituyeron una fundación, sometida a la ley colombiana, denominada Escuela de Administración y Finanzas.

Los empresarios fundadores fueron: Gabriel Ángel Escobar, Luis Fernando Cano Olano, Juan Rafael Cárdenas Gutiérrez, Hernán Echavarría Olózoga, Élkin Echavarría Olózaga, Luis Echavarría Villegas, José Gutiérrez Gómez, Jorge Posada Greiffenstein, Horaci​o Ramírez Gaviria, Juan Gonzalo Restrepo Londoño, Jorge Iván Rodríguez Castaño, Peter Santamaría Álvarez, Ernesto Satizábal Azcárate, Diego Tobón Arbeláez, Alejandro Uribe Escobar, Rodrigo Uribe Echavarría y Alberto Vásquez Lalinde.

1960

###### 11 de junio de 1960

**Se autoriza el funcionamiento de la entidad educativa**

El Ministerio de Educación Nacional, mediante la resolución numero 3469, autorizó el funcionamiento como entidad educativa a EAF.

###### 28 de junio de 1960

###### ![Image 36: https://universidadeafit.widen.net/content/rhgtgctmow/jpeg/ernesto-satizabal-azcarate.jpeg](https://universidadeafit.widen.net/content/rhgtgctmow/jpeg/ernesto-satizabal-azcarate.jpeg)

**Ernesto Satizábal Azcárate es nombrado director provisional**

El ingeniero industrial Ernesto Satizábal Azcárate es nombrado director provisional de la Institución. Venía de desempeñar el cargo de director ejecutivo de Incolda.

###### 17 de agosto de 1960

**Primera clase de contabilidad**

Bernard J. Hargadon dictó la primera clase de contabilidad el 17 de agosto de 1960 a las 7:00 a.m.

###### 17 de octubre de 1960

**Javier Toro Martínez es nombrado director**

El abogado Javier Toro Martínez es nombrado primer director de la Institución.

###### Octubre de 1960

###### ![Image 39: Imagen antigua de la sede de octubre](https://universidadeafit.widen.net/content/isxxopbup9/jpeg/primera-sede.jpeg)

**Sede de la Escuela desde octubre de 1960 hasta agosto de 1963**

Casa situada en la carrera 45, entre calles 52 y 53 de la ciudad de Medellín.

1961

###### **![Image 40: Salón de clase con profesor y estudiantes durante el primer semestre](https://universidadeafit.widen.net/content/oqd9plkf4g/jpeg/primera-clase-decada-60.jpeg)**

###### **Primer semestre de clases**

Este primer semestre se inició con 60 estudiantes admitidos, 47 pasaron al segundo semestre.

###### Abril de 1961

**Se piensa en hacer la aproximación entre la Escuela y el instituto tecnológico o politécnico.**

Comienza la planeación que daría como resultado el nombre EAFIT.

###### 6 de julio de 1961

**![Image 41: Guillermo Ortega Arbeláez](https://universidadeafit.widen.net/content/lu9kmg7wiu/jpeg/guillermo-ortega-arbelaez.jpeg)**

**Guillermo Ortega Arbeláez es nombrado director**

Guillermo Ortega Arbeláez, ingeniero civil y profesor de la Escuela, es nombrado director de la Institución.

###### 30 de julio de 1961

**![Image 42: Alberto Mesa Prieto](https://universidadeafit.widen.net/content/erqwtctmtn/jpeg/alberto-mesa-prieto.jpeg)**

**Alberto Mesa Prieto es nombrado director**

El ingeniero civil Alberto Mesa Prieto es nombrado director de la Institución.

1962

###### Segundo semestre de 1962

**![Image 43: Gustavo Adolfo Escobar Isaza](https://universidadeafit.widen.net/content/oys4imddsl/jpeg/laboratorio-idiomas.jpeg)**

**Profesor Gustavo Adolfo Escobar Isaza y un grupo de estudiantes en el Laboratorio de Inglés de la Institución**

La Escuela cuenta con los laboratorios de idiomas más avanzados de esa época en el país.

###### Noviembre de 1962

**Primera piedra para la construcción de la nueva sede en la Aguacatala**

Se inicia la construcción de la nueva sede con la colocación de la primera piedra y de una placa conmemorativa como reconocimiento a las entidades asesoras y benefactoras.

###### 1962

**Creación del Instituto Tecnológico**

Contó con el apoyo de la Corporación Educativa de la Industria en representación de la Andi, la asesoría de la Fundación Whirlpool, del Instituto Tecnológico de Benton Harbor, Burlington Industries y Tools for Freedom.​

1963

###### 14 de agosto de 1963

###### ![Image 45: Imagen de archivo a blanco y negro, panorámica de la antigua sede](https://universidadeafit.widen.net/content/ysnu6koflp/jpeg/panoramica-1960.jpeg)

**Traslado de la sede**

El 14 de agosto de 1963 se produjo el traslado a las nuevas edificaciones, con una ceremonia de inauguración.

###### 13 de diciembre de 1963

**![Image 46: Imagen antigua del laboratorio textil](https://universidadeafit.widen.net/content/35k2gjo2ui/jpeg/laboratorio-algodon.jpeg)**

**Primera graduación de técnicos superiores**

Un total de 12 estudiantes obtuvieron su título en Tecnología Textil y 10 estudiantes más en Tecnología Industrial.

1964

###### Mayo de 1964

**![Image 47: Imagen antigua de estudiantes residentes](https://universidadeafit.widen.net/content/cyyiivelsf/jpeg/edificio-residencias.jpeg)**

**Residencias estudiantiles**

Se construye el edificio de residencias.

###### 14 de mayo de 1964

**Reunión extraordinaria por estudiantes en desacuerdo**

El Consejo Directivo sostuvo una reunión extraordinaria, debido a que algunos grupos de estudiantes manifestaron su descontento por la calidad de algunos de los docentes. Así mismo, se tuvieron en cuenta otros aspectos que definieron la necesidad de reconocer un Consejo Estudiantil y establecer un canal de comunicación con directivas, profesores y estudiantes.

###### Junio 12 de 1964

**![Image 48: Hernán Gómez González](https://universidadeafit.widen.net/content/ogupluskii/jpeg/hernan-gomez-gonzales.jpeg)**

**Hernán Gómez González es nombrado director**

El ingeniero químico Hernán Gómez González, con amplia trayectoria en administración académica y docencia, es nombrado director de la Institución.

1969

###### Primer semestre de 1969

**Programa nocturno de Administración de Negocios**

Por decisión del Consejo Directivo se ofreció el programa nocturno de Administración de Negocios, con el nombre de Plan de Estudios Simultáneos. Estaba dirigido a estudiantes que pudieran demostrar su vinculación efectiva a empresas durante la realización de sus estudios.

## Década de 1960

En 1963 la Universidad se trasladó al lote ubicado en el sector de La Aguacatala (sur de Medellín), sede desde la que EAFIT empezó su proceso de fortalecimiento y expansión.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate