# Inglés virtual para adultos - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 35: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Inglés virtual para adultos

### Edad +18

Vive una experiencia flexible, personalizada y con acompañamiento real

*    Inglés Virtual Para Adultos 

### Matricúlate en programas

de 6, 9 y 12 meses.

### Aprende a tu ritmo

con clases en vivo y herramientas de IA

### Avanza en tu proceso de aprendizaje

desde nivel A1 hasta el B2.

### Vive tu experiencia con componentes

sincrónico en línea y asincrónico.

Contenidos del programa

## 1.

Más de 30 años liderando el aprendizaje de idiomas. Reconocidos como el Centro de Idiomas #1 en Medellín.

## 2.

Personaliza tu inglés según tus objetivos personales, académicos o profesionales, enfocándote en dominar el inglés para negocios, viajes o en lo que tú quieras.

## 3.

Máxima flexibilidad accede a sesiones de autoestudio en cualquier momento y organiza tus sesiones sincrónicas en horarios de mañana, tarde o noche.

## 4.

Para no perderte de nada importante, reagenda tus sesiones sincrónicas si tuviste un imprevisto.

## 5.

Acompañamiento y seguimiento semana a semana con nuestros mentores para ayudarte a avanzar, resolver dudas técnicas y orientarte en tu progreso académico.

Beneficios

###### Componente asincrónico: 70%

**Plan Start+, Advance+ y Master+**

El componente asincrónico está impulsado por inteligencia artificial y plataformas internacionales que permiten estudiar a tu ritmo, desde cualquier lugar y en cualquier momento, fortaleciendo las habilidades de comprensión, lectura, escucha y escritura.

**Incluye:**

Speexx: Plataforma principal del programa, Ofrece explicaciones gramaticales completas, diccionario integrado y prácticas de pronunciación mediante un sistema de reconocimiento de voz. Además, brinda acceso a videos, ejercicios y foros interactivos con contenido auténtico de medios reconocidos como The New York Times, Harvard Business Review, Euronews, entre otros.

**OLI (Online Learning Intelligence):**Tutor conversacional con IA que ofrece acompañamiento 24/7 vía WhatsApp, con disponibilidad**24/7**y sin límites de interacción. Ofrece retroalimentación inmediata, es adaptativo al nivel del estudiante, y permite conversar por voz y texto.

**Speakology:** Plataforma de aprendizaje de idiomas diseñada para que los estudiantes practiquen conversación oral a través de simulaciones de videollamadas con instructores de inteligencia artificial. Permite mejorar la fluidez y ganar confianza en un entorno interactivo y sin presiones, ofreciendo retroalimentación instantánea sobre pronunciación y gramática.

5 características de alto impacto:

1.   Inglés general, de negocios y ESP (inglés para propósitos específicos).
2.   Corrector de errores inteligente (más allá de bien o mal, cual es el error y la corrección apropiada).
3.   Práctica de pronunciación: Sistema de reconocimiento de voz Intellispeech.
4.   Explicaciones gramaticales completas y diccionario incorporado.
5.   Videos y foros interactivos: contenidos auténticos de fuentes confiables y reconocidas mundialmente (New York Times, Harvard Business Review, Euronews, etc).

###### Componente sincrónico en línea: 30%

**Plan Start+, Advance+ y Master+**

El componente sincrónico ofrece espacios de aprendizaje en vivo guiados por **docentes certificados de EAFIT,** enfocados en fortalecer la **comunicación oral, la fluidez y la seguridad al expresarse en inglés;** a través de sesiones dinámicas y participativas, en grupos reducidos de hasta**5 participantes,**una vez por semana, lo que permite una interacción cercana y personalizada.

Durante cada sesión, el Trainer orienta el proceso de aprendizaje combinando **explicaciones claras de los contenidos**con actividades de**práctica oral guiada.** Las clases están enfocadas en el desarrollo de **conversación, vocabulario y comprensión textual,** de acuerdo con el nivel del estudiante **(A1 a B2).**

Adicionalmente, el estudiante podrá integran esta experiencia virtual con **encuentros presenciales opcionales,** como el club de conversación semanal, ampliando las oportunidades de práctica.

Planes y precios

| Start+ | Advance+ | Master+ |
| --- | --- | --- |
| $ 3.446.000 | $ 5.140.000 | $ 6.430.000 |
| Duración 6 meses | Duración 9 meses | Duración 12 meses |
| Sesiones en vivo 1 vez por semana | Sesiones en vivo 1 vez por semana | Sesiones en vivo 1 vez por semana |
| Plataforma autoestudio Ilimitado | Plataforma autoestudio Ilimitado | Plataforma autoestudio Ilimitado |
| Clases personalizadas con I.A Ilimitado | Clases personalizadas con I.A Ilimitado | Clases personalizadas con I.A Ilimitado |
| Agente WP Ilimitado | Agente WP Ilimitado | Agente WP Ilimitado |
| Experiencia presencial semanal | Experiencia presencial semanal | Experiencia presencial semanal |

## ¿Por qué estudiar inglés de manera virtual?

Vivirás la experiencia de aprender inglés interactuando con tus pares durante sesiones en línea de máximo 8 personas. La práctica es clave para que afiances tus habilidades de escucha y pronunciación.

 Tendrás acompañamiento permanente. Nuestro programa de inglés virtual se compone de un proceso 70% asincrónico (virtual) + 30% sincrónico (en línea), nuestra prioridad es garantizarte una formación más efectiva.

 Accederás a ejercicios gramaticales, refuerzos en temas puntuales y contenidos especializados en tús intereses. El programa Inglés para adultos tiene para ti un enfoque en los temas que a ti te interesa aprender.

 Recibirás calificaciones automáticas para que evalues tu progreso en gramática, pronunciación y escucha del idioma inglés.

## ¿Por qué estudiar ​​​idiomas en EAFIT?

Con 30 años de experiencia en la enseñanza de idiomas, como respuesta a las exigencias mundiales, Idiomas EAFIT tiene como objetivo principal dar solución a las necesidades del entorno académico, empresarial y gubernamental.

## Portafolio corporativo

## Global Explorers

## Certificaca tus conocimientos en inglés

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

## Líneas de atención

(57) 604 2619500

## Sugerencias

## ¡Idiomas EAFIT llega a Bello!

Aprende inglés con educación de calidad y una metodología efectiva.

## Spanish program

Personalized sessions adapted to your needs

## English Stars - niños de 4 años

### Edad 4 años

Un programa para aprender inglés y fortalecer habilidades clave para el desarrollo cognitivo, social y comunicativo en la primera infancia.

## Vacacionales Happy Time

### Edad 5 a 10 años

Vacaciones en inglés para niños. Una semana perfecta para disfrutar y conocer el mundo mientras aprenden un nuevo idioma.

## Programa de inglés para niños y niñas

### Edad 4 a 11 años

Metodología participativa con resultados reales que desarrollan habilidades cognitivas y sociales.

## Programas de inglés para niños y niñas

### Edad 4 a 11 años

El programa de inglés para niños que combina el juego, la creatividad y el aprendizaje de un nuevo idioma de manera efectiva

## Inglés para jóvenes

### Edad 12 a 16 años

Conecta con el mundo y fortalece habilidades clave para tu futuro académico y profesional.

## Portugués para adultos

### Edad +17

Disfruta la experiencia de aprender una de las lenguas más dulces y agradables del mundo.

## Italiano para adultos

### Edad +17

Aprende italiano de forma divertida y expande tus horizontes con nuevos conocimientos.

## Francés para adultos

### Edad +17

Aprende una de las lenguas más fascinantes y sumérgete en una cultura artística y rica.

## Alemán para adultos

### Edad +17

Aprende con una metodología efectiva y práctica y descubre la riqueza cultural del alemán, sumérgete en su historia y tradiciones.

## Francés para jóvenes

### Edad 12 a 16 años

Domina una lengua romance fascinante y explora una cultura artística y rica.

## Alemán para Jóvenes

### Edad 12 a 16 años

Descubre la riqueza cultural del alemán y atrévete a sumergirte en su historia y tradiciones.

## Inglés virtual para adultos

### Edad +18

Vive una experiencia flexible, personalizada y con acompañamiento real

## Inglés para adultos

### Edad +17

Domina el inglés con una metodología efectiva y accede a oportunidades para crecer, viajar y destacar profesionalmente.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate