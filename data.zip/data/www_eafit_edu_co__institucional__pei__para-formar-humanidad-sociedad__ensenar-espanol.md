# Enseñar español a los ciudadanos globales

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Enseñar español a los ciudadanos globales

*    Enseñar Español A Los Ciudadanos Globales 

​​“Realmente me gustó la atmósfera en el campus, es muy moderno, joven e inspirador. Los cursos se organizan de manera exigente y productiva, en salones equipados con lo último en tecnología. El personal docente, los profesores y los administrativos fueron muy amables, serviciales y profesionales. Lo más importante: ¡Progresé mucho en mis habilidades en español!”, expresó Andreas Fischer, de Suiza. Un testimonio que demuestra que la Universidad para todas las generaciones, también lo es para todas las nacionalidades.

El Instituto Cervantes reconocido en el mundo por promover la enseñanza y la difusión de la lengua española, ratificó en 2019 su respaldo hasta 2022, al programa Español para Extranjeros, de Idiomas EAFIT, acreditando a la institución como favorable para esta enseñanza. La primera certificación fue en 2013 y la primera renovación en 2016.

Alemania, Australia, Austria, Bélgica, Brasil, Bulgaria, Canadá, China, Corea del Sur, Dinamarca, Escocia, Estados Unidos, Filipinas, Finlandia, Francia, Holanda, Hungría, India, Inglaterra, Irlanda del sur, Italia, Japón, Madagascar, Noruega, Nueva Zelanda, Polonia, Portugal, Rusia, Sudáfrica, Suecia, Suiza, Turquía, Ucrania y Vietnam son algunos de los países de los que recientemente han llegado estudiantes que desean aprender español en EAFIT como una segunda lengua o como requisito para la carrera que cursan en sus naciones de origen. Es una experiencia que les permite estar inmersos en el ambiente cultural, académico y lingüístico.

Recibir el reconocimiento del Instituto Cervantes es muy importante, pues según lo establece este en sus estatutos generales, la Institución “cumple con unos requisitos de calidad en la enseñanza, unos requisitos legales, disponen de recursos adecuados, cuentan con un equipo de profesores con titulación y formación adecuadas, y tienen un plan de enseñanza que garantiza el progreso”.

## 4. Educación de calidad

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate