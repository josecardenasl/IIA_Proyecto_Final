# Villa Innovadora - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Villa Innovadora

*    Villa Innovadora 

###### Salva a la Villa

Desde hace algún tiempo han comenzado a desaparecer misteriosamente los dueños de las ideas nuevas; los creativos, los emprendedores. Pon a prueba tus habilidades para descubrir quiénes están amenazando el surgimiento de nuevas iniciativas en la Villa, poniendo en peligro su desarrollo y prosperidad.

Villa Innovadora es un juego de rol con identidades ocultas que tiene como fin reforzar habilidades y valores asociados al emprendimiento y la innovación, socializando de forma lúdica conceptos básicos alrededor de dichos temas.

###### ¡A jugar!

##### Te invitamos a ver el tutorial de la partida básica

##### ¿Te animas a jugar la partida completa?

##### ¿Estás listo para jugar Villa Innovadora?

Recuerda que también puedes descargar el [manual de juego](https://universidadeafit.widen.net/s/zrx6jpwddl/guia-pasos-generales-de-la-narracion) y la [guía de ayuda para el narrador](https://universidadeafit.widen.net/s/lv6mfdbwxg/manual-villa-innovadora).

###### Inspírate

¿Quieres utilizar Villa Innovadora en tu institución o empresa?

Inspírate con estos casos de éxito de diferentes organizaciones que ya probaron el juego.

###### Creadores

Durante los últimos años, el área de Innovación y emprendimiento académico de la Universidad EAFIT ha trabajado en el desarrollo de material didáctico que contribuya a la implementación de nuevas metodologías de enseñanza, con el fin de ofrecerles a los estudiantes la posibilidad de aprender de manera diferente y lograr una mayor apropiación del conocimiento. Fue así como surgió el diseño de productos y juegos encaminados a promover el espíritu emprendedor y la cultura de innovación en la Universidad.

Además de Villa Innovadora, te invitamos a conocer [Cafet](https://www.eafit.edu.co/escuela-administracion/cafet), un juego basado en la industria cafetera.

###### Contacto

### Correo

empresarismo@eafit.edu.co

### Teléfono

2619500 Ext. 9839.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)