# Maestría en Agronegocios - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 16: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Maestría en Agronegocios

SNIES 109910, Medellín

El sector agrario es fundamental para el desarrollo económico en Latinoamérica, generando empleo y recursos. Aunque la globalización presenta oportunidades, también implica desafíos que requieren profesionales capacitados. Esta maestría está diseñada para quienes desean liderar proyectos innovadores en agronegocios y modernizar el sector agrícola.

En nuestra institución formamos estudiantes capaces de desarrollar proyectos integradores y adquirir habilidades esenciales para la gestión de agronegocios, con énfasis en el emprendimiento, la innovación y la creación de valor. Nos enfocamos en fomentar competencias para el direccionamiento estratégico y en formar líderes comprometidos con la sostenibilidad, buscando un equilibrio entre los aspectos económicos, sociales y ambientales. Nuestro programa se destaca por su orientación hacia el emprendimiento, la innovación y una sólida proyección internacional, preparando a los estudiantes para sobresalir en un mercado global cada vez más competitivo.

*    Escuela Administracion 
*    Maestría En Agronegocios 

## Registro calificado

Resolución 2190 del 15 de Febrero de 2021. Vigencia de 7 años

Duración

3 semestres

Lugar

Medellín

Más información

Universidad EAFIT (Medellín - Colombia) y ​Universidad de​ Zamorano (Honduras)

Horario

Encuentros sincrónicos y asincrónicos 

Más información

Clases sincrónicas mediadas por tecnología: miércoles y jueves de 6:00 p.m. a 10:00 p.m. GMT-5, y clases presenciales una semana al semestre en EAFIT y Zamorano.

Idioma 

Español

Modalidad

Blended

Más información

Semipresencial con mediación virtual/Blended

SNIES

SNIES 109910

Precio total del programa

$63.000.000

Más información

Semestre 1: COP 22.050.000

 Semestre 2: COP 22.050.000

 Semestre 3: COP 18.900.000

 Exclusivo pago en EAFIT.

 USD: 15.000, exclusivo pago en Zamorano.

 Nota: por favor, ten en cuenta que los valores pueden tener variaciones de acuerdo con el IPC.

 Valores válidos para 2026. 

## Sobre el programa

¿Por qué estudiar la Maestría en Agronegocios?

Imagina potenciar tu visión estratégica y convertir tus ideas en proyectos que transformen el agro colombiano. En la **Maestría en Agronegocios,** cada clase te acerca a liderar con propósito, conectar con expertos del sector y abrir nuevas oportunidades internacionales.

Da hoy el paso que puede marcar tu carrera: elige formarte donde la innovación, la sostenibilidad y el liderazgo se encuentran para construir el futuro del campo. ¡Tu historia profesional puede empezar a cambiar ahora, en EAFIT!

**- Flexibilidad horaria:** modalidad virtual para estudiar desde cualquier lugar y adaptar horarios a necesidades personales y profesionales.

**- Acceso a programas de alta calidad:** Zamorano y EAFIT ofrecen un programa reconocido de alta calidad.

**- Doble titulación:** valor adicional en perfil académico y profesional, demuestra especialización y competencia en agronegocios.

**- Ampliación de oportunidades laborales:** aumenta oportunidades de empleo y potencial de ingresos, muestra compromiso educativo y conocimiento avanzado.

**- Red de contactos:** jornadas presenciales para conectar con estudiantes y profesionales globalmente, enriquece red de contactos y proporciona perspectivas globales en agronegocios.

**- Actualización de conocimientos:** mantén los conocimientos actualizados sobre tendencias y prácticas en constante evolución en agronegocios.

**- Crecimiento en el sector agrícola:** ofrece oportunidad de hacer carrera en la gestión de empresas agrícolas, comercio internacional de alimentos, sostenibilidad agrícola, y otros campos relacionados.

**- Desarrollo de habilidades de gestión:** incluye capacitación en habilidades de gestión, liderazgo y toma de decisiones para prepara para roles de liderazgo.

**- Aplicación práctica:** programas con proyectos, pasantías o estudios de casos reales para aplicar conocimientos teóricos en situaciones prácticas.

**- Contribución a la sostenibilidad:**abordas desafíos de sostenibilidad y responsabilidad social corporativa en la agricultura en los agronegocios.

Perfiles

###### **Perfil de egreso y oportunidades laborales:**

**- Director de Estrategia y Desarrollo Agroindustrial:** Lidera la transformación de cadenas productivas con visión sostenible, conectando innovación, competitividad y desarrollo rural.

**- Gerente de Proyectos Agroempresariales:** Convierte ideas en realidades tangibles, impulsando inversiones que generan impacto económico y social en el campo.

**- Consultor Internacional en Agronegocios y Sostenibilidad:**Asesora empresas y gobiernos en la toma de decisiones estratégicas que definen el futuro del agro a nivel global.

**- Director de Exportaciones o Comercio Internacional Agroalimentario:** Abre mercados, crea alianzas y posiciona productos colombianos con valor agregado en los escenarios más exigentes del mundo.

**- Gestor de Innovación y Emprendimiento Agroindustrial:** Inspira nuevas soluciones tecnológicas, modelos circulares y emprendimientos que re imaginan la manera de producir y comercializar.

**- Especialista en Finanzas y Evaluación de Proyectos Agropecuarios:**Analiza, proyecta y optimiza la rentabilidad de inversiones agrícolas, convirtiéndote en referente para la toma de decisiones estratégicas.

Conexiones e incidencia

Este programa ha sido diseñado con una visión integral de los eslabones de la cadena de valor de los agronegocios, buscando conectar a los diversos actores del ecosistema.

Nuestro objetivo es proporcionar a los empresarios del sector las herramientas necesarias para incrementar la productividad de sus negocios, siempre con un enfoque en la sostenibilidad económica y ambiental.

Nos interesa que nuestros estudiantes adquieran las habilidades necesarias para expandir sus negocios a nivel internacional. Por ello, contamos con sólidas conexiones en la región para ampliar sus horizontes. El programa incluye actividades presenciales y visitas empresariales tanto en Honduras como en Colombia.

Al tratarse de una maestría ofrecida por dos universidades, tendrás la oportunidad de aprender en entornos multiculturales. Aunque nuestro enfoque es práctico, reconocemos la importancia de la investigación. Por ello, los ecosistemas de investigación de ambas instituciones están interconectados.

Desde EAFIT, los estudiantes pueden participar en grupos de investigación de categoría A1 vinculados a la Escuela, en áreas como estudios internacionales, administración y organizaciones. También ofrecemos semilleros de investigación como el de Agroindustria y el de Aprovechamiento de Acuerdos Comerciales.

Calidad y excelencia

###### **Nos respalda la trayectoria y excelencia**

Como parte de la Universidad EAFIT, contamos con la acreditación de The Association to Advance Collegiate Schools of Business (AACSB International), la alianza educativa más grande a nivel global.

Pertenecemos a la Escuela de Administración, la primera en América Latina en recibir la acreditación de alta calidad por parte de la Business Graduates Association (BGA).

Esta maestría ha sido desarrollada en colaboración con la Universidad Zamorano de Honduras, reconocida en la región por su excelencia en las áreas agropecuarias. Gracias a este esfuerzo conjunto, nuestros estudiantes obtendrán una doble titulación.

Además, estamos acreditados a nivel nacional por el Consejo Nacional de Acreditación, lo que respalda la calidad de nuestro programa.

Nuestros docentes son expertos en las áreas gerencial y agropecuaria, lo que asegura una formación de alto nivel y relevancia en el campo de estudio.

El programa contado por quienes lo vivieron

“Para mí, la Maestría en Agronegocios EAFIT–Zamorano destaca por la sinergia entre las dos universidades, que combinan una gran experiencia en el ámbito administrativo y financiero con un fuerte enfoque en el campo agrícola. El formato semipresencial me ha permitido compatibilizar la vida laboral con la académica, conocer campus en diferentes países y enriquecerme tanto a nivel profesional como cultural. Siento que el programa integra muy bien la parte administrativa, financiera y la realidad del sector agro, lo que fortalece de manera integral mi perfil como profesional de agronegocios.” - _**Franz Grandes.**_

“Considero que la Maestría en Agronegocios EAFIT–Zamorano ofrece una formación muy completa, porque integra de manera práctica los componentes administrativos, financieros y tecnológicos aplicados al sector agro. Me parece valiosa la forma en que conecta la teoría con las necesidades reales de las empresas del campo, permitiendo tomar decisiones mejor fundamentadas y generar mayor valor en la cadena de agronegocios.” -_**Valentina Olarte**_

“Elegí la Maestría en Agronegocios con doble titulación con EAFIT y Zamorano por el prestigio que tienen estas universidades y la solidez de su propuesta académica. Considero que el programa ofrece una formación de alto nivel para el sector agro, respaldada por instituciones reconocidas que aportan calidad, rigor y proyección profesional.” - _**Carlos Gonzalez**_

Aprendizaje vivo y activo

Ofrecemos herramientas para los estudiantes interesados en emprender y liderar la creación de nuevos negocios con enfoque global.

**Enfoque disciplinar**

Integramos conocimientos y habilidades de áreas como la agricultura, la economía, la administración y la sostenibilidad en nuestro plan de estudios.

El acompañamiento a nuestros estudiantes es personalizado: reciben orientación específica para su área de interés y trabajo de grado.

Nuestra modalidad es semipresencial, con aprendizaje híbrido: 16 créditos presenciales y 24 virtuales. Los estudiantes asisten al campus dos semanas por semestre para crear interacciones con los profesores y el sector real.

Trabajos de grado

La distribución temática de los trabajos de grado evidencia una orientación diversa en torno a las dinámicas productivas y de innovación en el sector agroindustrial.

- El **40%** de los proyectos se concentra en actividades de producción primaria, destacando experiencias relacionadas con el cultivo de lechuga hidropónica en el departamento del Meta, el desarrollo de chile orgánico y el establecimiento de plantaciones de palma africana con extensiones de hasta 50 hectáreas.

- Un **20%**de los trabajos se orienta hacia la internacionalización y apertura de mercados, abordando iniciativas como la exportación de banano hacia Francia, la comercialización de frutas exóticas con destino a Europa y la promoción del sacha inchi como producto de valor agregado para nichos internacionales.

- Otro **20%** de los proyectos se enfoca en la transformación y procesamiento agroindustrial, con propuestas centradas en la elaboración de chips de papa, harina de banano y productos alternativos como la carne vegetal.

- El**13%**de los trabajos se enmarca en el ámbito de la sostenibilidad y la gestión responsable de los sistemas productivos, incluyendo estudios sobre ganadería regenerativa y modelos de comercialización flexibles adaptados a los cambios del entorno.

- Finalmente, el **7%** restante aborda la incorporación de tecnologías emergentes en la actividad agropecuaria, con proyectos que analizan el uso de drones para labores de fumigación y la implementación de sistemas fotovoltaicos en unidades de producción avícola.

Contacto

###### Ejecutiva de promoción

**Valentina Castañeda Jaramillo**

+57 3102273379

vcastanedj@eafit.edu.co

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

## **Nuestras acreditaciones**

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

### También te puede interesar

#### Maestría en Gerencia de Proyectos - Medellín

Duración

3 semestres

Más información

(Los dos primeros semestres corresponden al plan de estudios de la Especialización en Gerencia de Proyectos).

 Periodicidad de admisión: seis meses.

Lugar

Medellín​

Horario

Martes Jueves y Viernes Sábado

Más información

Opción 1: Martes y jueves de 5:00 p.m. a 9:00 p.m. 

 Opción 2: Viernes 5:00 p.m. a 9:00 p.m. y sábado 8:00 a 12:00 p.m.

 Algunas clases se dictarán los lunes y miércoles de 5:00 p.m. a 9:00 p.m. y se informará previo inicio de semestre.

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 109479

Precio total del programa

$55.440.000

#### Maestría en Café y Negocios

Duración

3 semestres

Lugar

Virtual

Más información

Con actividades en campus de EAFIT y Zamorano

Horario

Combinado

Más información

Clases virtuales y módulos presenciales intensivos en ambos países

Idioma 

Español

Más información

Con lecturas y recursos en inglés

Modalidad

Combinada

Más información

Presencial y virtual

SNIES

SNIES 

Precio total del programa

$54.600.000 COP

Más información

Incluye matrícula y estadía durante módulos presenciales; no incluye traslados

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Liderar para generar impacto: decisiones que transforman personas, equipos y oportunidades

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate