# Guillermo Ortega Arbeláez - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Guillermo Ortega Arbeláez

(Rector entre ​1961-1962)​

*    Guillermo Ortega Arbeláez 

**Graduado de la Universidad Nacional de Colombia como ingeniero de geología y petróleos, Guillermo Ortega Arbeláez llegó a la dirección de la EAF en 1961.**

Sus gestiones fueron trascendentales para el futuro de la Institución debido a que durante su administración se decidió comprar el lote de La Aguacatala y se inició el plan de construcción de esa sede donde hoy está ubicada EAFIT.​

En asuntos académicas sus contribuciones también fueron importantes. Se establecieron las bases del Instituto Tecnológico; el primer plan de capacitación para docentes; y la creación de dos categorías de profesores de tiempo completo: asistentes y titulares, basándose en la experiencia​, títulos universitarios y preparación de los mismos.

El 10 de julio de 1962, Ortega Arbeláez presentó su renuncia ante los miembros del Consejo Directivo quienes le otorgaron un puesto dentro de este estamento por un tiempo.

Datos sacados del libro Universidad EAFIT 50 Años.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)