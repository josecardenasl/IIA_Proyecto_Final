# Modelo Educativo: Educación flexible y relevante - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Modelo Educativo

Educación flexible y relevante

*    Pei 2022 
*    Modelo Educativo: Educación Flexible y Relevante 

Son cinco los atributos de nuestro modelo educativo: experiencia integral y transformadora de vida, centralidad del estudiante, contar con profesores que inspiran, el currículo vivo y el campus como laboratorio. Con este modelo respondemos a los retos del presente y del futuro con el propósito de contribuir con ideas y propuestas que permitan construir una sociedad más equitativa e incluyente. Formamos personas capaces de afrontar la complejidad del mundo social, político, económico y cultural en conexión con las organizaciones consolidadas, los sistemas públicos y los emprendimientos de impacto, y de proponer soluciones innovadoras efectivas en los ámbitos donde hayan decidido ejercer su profesión.

Nuestro Modelo Educativo, fundamentado en la formación por competencias, se despliega en una estrategia de transformación y renovación curricular congruente con las necesidades del medio, lo que nos permite responder a las nuevas tendencias y mantener la pertinencia y la conexión con el mundo.

Este acoge los lineamientos del Ministerio de Educación Nacional y se construye en consonancia con las tendencias internacionales de la educación superior.

Coincide con referentes mundiales como el proyecto Tuning, la Declaración de Bolonia, la Primera Conferencia Ministerial de los países de la Unión Europea, de América Latina y el Caribe 2000-2005, al igual que con los estudios y análisis de la Organización para la Cooperación y el Desarrollo Económico (OCDE) y con los Objetivos de Desarrollo Sostenible –ODS–. Así mismo, nuestro Modelo Educativo se despliega en los Proyectos Educativos6 de cada programa académico (PEP) y sirve de guía para los procesos y las actividades académicas. Es, además, el sustento de la gestión curricular y de los procesos de aseguramiento de la calidad académica.

Los atributos mencionados dan paso a dos asuntos cardinales: **el diseño curricular basado en competencias; y el modelo pedagógico que privilegia un aprendizaje que valora y promueve la experiencia.**

El objetivo es que estas declaraciones y descripciones propicien conversaciones y acciones fructíferas y vivificantes que redunden en el cumplimiento de nuestro propósito: inspiramos vidas, creamos conocimiento y transformamos sociedad.

### Diseño curricular

Para cumplir la promesa de un aprendizaje que valora el pensamiento crítico, la reflexión, la experiencia y la experimentación, el diseño curricular de nuestros programas se enfoca en la formación por competencias, y en la conexión con los problemas y los retos de la sociedad y las organizaciones. En este sentido, los dos conceptos rectores que fundamentan la construcción de nuestras propuestas de formación son: las competencias y los resultados de aprendizaje.

El Acuerdo 02 de 2020 del Consejo Nacional de Educación Superior (CESU) indica que las competencias: “Son conjuntos articulados de conocimientos, capacidades, habilidades, disposiciones, actitudes y aptitudes que hacen posible comprender y analizar problemas o situaciones y actuar coherente y eficazmente, individual o colectivamente, en determinados contextos” (Art. 2.2, p. 7). La gráfica 2 muestra su clasificación según el alcance de conocimientos que desarrollan.

Por su parte, el Decreto 1330 del 2019 establece que los resultados de aprendizaje son “las declaraciones expresas de lo que se espera que un estudiante conozca y demuestre en el momento de completar su programa académico” (p. 4). Estos se plantean en agrupaciones que, en el transcurso y la valoración del proceso formativo, proporcionan los indicadores del progreso y cumplimiento de las competencias.

Para dar cumplimiento a nuestro propósito superior se requiere la convergencia de estrategias pedagógicas, didácticas, administrativas, logísticas y operativas que posibiliten mantener el dinamismo de la comunidad académica. En este sentido:

Privilegiamos la flexibilidad curricular y la integración de los distintos niveles de aprendizaje. Propendemos por la formación en núcleos comunes, así como por la homologación y el reconocimiento de aprendizajes entre los distintos niveles de formación, y propiciamos el establecimiento de alianzas nacionales e internacionales que favorezcan el enriquecimiento académico y profesional de nuestros estudiantes y profesores.

Disponemos de nuestros recursos para fortalecer la relación académica entre los estudiantes y profesores.

Articulamos los procesos académicos y administrativos para potenciar y afianzar el proceso de aprendizaje.

Fortalecemos procesos de evaluación que conjugan de manera complementaria e integral las tres dimensiones de la educación: ser, saber y hacer. Los procesos evaluativos apoyan momentos reflexivos en los que nuestros estudiantes conocen su nivel de avance en el desarrollo de sus competencias y se hacen conscientes de los fallos y las necesidades de mejora. Esto implica que el estudiante tiene el deber de demostrar precisión en el manejo de conceptos y conocimientos, al igual que su capacidad para integrarlos y utilizarlos en los contextos en los que estos se requieran. Por su parte, los profesores se sirven de la evaluación para conocer el estado y la evolución de los niveles de logro de los aprendizajes.

La formación por competencias reconoce la gradualidad del proceso educativo. De manera general, los niveles de conocimiento que recorre un estudiante durante su proceso son los siguientes:

1.   Hace evidente el conocimiento previo adquirido durante la educación básica o en su experiencia vital y se hace consciente de la necesidad de someterlo a procesos rigurosos de crítica y reflexión.
2.   Es consciente de las transformaciones que el proceso de aprendizaje opera sobre sus modos de comprender el mundo y de actuar sobre él. Dicha consciencia obra como motivadora para no cesar en el esfuerzo y lograr metas más complejas.
3.   Es capaz de poner en práctica sus conocimientos de manera consciente y reflexiva. Reconoce las consecuencias de sus acciones y toma las medidas necesarias, o bien para corregir sus fallos, o para aumentar sus competencias.
4.   Establece conexiones con otras áreas de conocimiento, de tal modo que logra expandir de forma permanente su horizonte de comprensión de los distintos fenómenos sociales, económicos, políticos y culturales.
5.   Se dispone para la creación y la innovación en los distintos ámbitos de desempeño profesional mediante su capacidad para leer entornos, territorios y problemas situados.

##### Nuestro Modelo Educativo se concreta en el modelo curricular, el cual comprende tres niveles: el macro o general, el medio (meso) o académico y el micro o práctico.

###### Macrocurrículo

Es el conjunto de políticas que tiene en cuenta las directivas nacionales e institucionales con el fin de cumplir con los requisitos legales y preservar la excelencia académica de los programas 7.

El macrocurrículo contiene los lineamientos generales para gestionar el currículo de cada programa. Dichos parámetros provienen de fuentes externas e internas. Las primeras contemplan las regulaciones emitidas por el Ministerio de Educación Nacional (MEN) para la obtención y renovación de los registros calificados, así como las del Consejo Nacional de Educación Superior (CESU) para la acreditación de alta calidad de las instituciones y los programas académicos. Además, se tienen en cuenta los parámetros fijados por distintas acreditadoras internacionales a las cuales la Institución se acoge mediante las iniciativas de sus Escuelas o programas académicos. Las segundas toman en cuenta las políticas y directrices contenidas en los Estatutos, el Plan de Desarrollo Institucional (PDI) y el Proyecto Educativo Institucional (PEI).

**Además de las características expuestas en el primer apartado de este documento, la estructura macrocurricular de todos nuestros programas académicos reúne los siguientes componentes:**

**Formación humanística y científica**: desarrolla cuatro competencias básicas y generales (empatía, pensamiento crítico, pensamiento anticipatorio y pensamiento sistémico) necesarias para que nuestros graduados encaren los retos que impone el ejercicio pleno de la ciudadanía, tanto en el ámbito local como global.

**Componente disciplinar**: desarrolla las competencias específicas de cada profesión.

**Componente electivo**: fortalece las habilidades y las competencias relacionadas con el quehacer profesional o con otras temáticas de diferentes áreas del conocimiento que puedan ser de interés personal o profesional de los estudiantes.

**Componente práctico**: afianza las habilidades generales y profesionales relacionadas con el desenvolvimiento en el ambiente laboral. Comprende tanto los semestres de práctica como las pasantías, laboratorios, consultorio jurídico o intercambios profesionales.

###### Mesocurrículo

Está constituido por los elementos generales de cada programa académico: los perfiles de ingreso, egreso y ocupacional, el plan de estudios, la malla curricular y sus respectivas asignaturas 8.

El segundo nivel del currículo (meso) atiende a los procesos específicos de los programas académicos. Para su diseño se deben satisfacer las condiciones de calidad exigidas por las autoridades regulatorias nacionales e internacionales.

**El mesocurrículo de los programas lo integran los siguientes elementos:**

**Perfiles**: contiene las declaraciones que hace el programa sobre las características que han de cumplir los aspirantes (perfil de ingreso), las competencias que pretende formar (perfil de egreso) y los ámbitos de desarrollo profesional (perfil ocupacional).

**Perfil de ingreso**: declaraciones del programa con respecto a los conocimientos o cualidades que deben tener los aspirantes.

**Perfil de egreso**: declaraciones sobre el logro de las competencias en las que el programa forma a sus estudiantes.

**Perfil ocupacional**: contempla los conocimientos que permiten identificar las áreas de desempeño y los ámbitos de desarrollo profesional de los egresados del programa

**Mapa de competencias**: es la estructura de relacionamiento entre las competencias priorizadas en el perfil de egreso de cada programa académico con los resultados de aprendizaje y las asignaturas que conforman el plan de estudios.

**Plan de estudios**: concreta la propuesta formativa del respectivo programa mediante el ordenamiento de las asignaturas y sus correspondientes créditos académicos, así como la de las trayectorias que hacen posible el logro de las competencias.

**Programa de asignatura**: es un instrumento derivado del diseño meso curricular, contiene la identificación general de la asignatura, la justificación de ésta en el plan de estudios, las competencias, los resultados de aprendizaje, el contenido, la estrategia metodológica, los medios educativos, la evaluación y los recursos bibliográficos, estos elementos dan cuenta de la formación por competencias.

###### Microcurrículo

Es la propuesta institucional de organización del aprendizaje de una asignatura específica formulada por el profesor o el grupo de profesores que la tienen a su cargo. Posee una doble función: orienta las actividades académicas y cocurriculares necesarias para propiciar los aprendizajes de los estudiantes y fundamenta los procesos de aseguramiento de la calidad y el relacionamiento con las entidades regulatorias.

Por último, en el nivel microcurricular se concretan las directrices macrocurriculares y el diseño mesocurricular. Su propósito fundamental es planear lo requerido para la implementación y vivencia del currículo en los distintos espacios para el aprendizaje (aulas, laboratorios, sitios de práctica, momentos de encuentro sincrónico y el campus mismo).

Este nivel se conecta con el anterior mediante el programa de la asignatura, el cual es el insumo para el diseño y la implementación del syllabus que contiene las actividades detalladas para lograr los propósitos y el desarrollo de las competencias de cada curso. En tal virtud, el syllabus cumple una doble función: por un lado, conserva y asegura la coherencia del plan de estudios y del mapa de competencias. Por otro lado, actualiza los contenidos y dinamiza las estrategias didácticas y los medios educativos necesarios para propiciar el cumplimiento de los resultados de aprendizaje 10.

El syllabus es la base para la construcción del pacto pedagógico11 con los estudiantes. Por ello, se presenta en la primera clase y se pone a disposición de los estudiantes desde el inicio de cada período académico.

### Aprendizaje activo y experiencial

###### Aprendizaje activo

El aprendizaje activo, centro de nuestro modelo pedagógico, busca desarrollar competencias para la solución de problemas en distintos ámbitos entre los que se cuentan las organizaciones consolidadas, los sistemas públicos y los emprendimientos de impacto.

Las distintas metodologías que comprenden el aprendizaje activo consideran al estudiante en el centro del proceso de formación y buscan, además, fortalecer el saber aplicado sin abandonar la importancia del conocimiento teórico y de la reflexión sobre las consecuencias del hacer. Además, permiten que nuestros estudiantes se mantengan en permanente contacto con el entorno nacional e internacional y sepan discernir el mejor curso de acción en cada caso.

Así, situamos a los estudiantes como protagonistas de su propio proceso de aprendizaje y a los profesores en el rol de orientadores, dinamizadores y mediadores del proceso, cuyo propósito consiste en diseñar escenarios en los que los estudiantes se encuentren ante situaciones que requieran ser resueltas bajo su guía, organización y movilización de recursos didácticos y estrategias de aprendizaje. Por consiguiente, los profesores tienen la responsabilidad de propiciar un contexto que facilite una experiencia rica en estímulos de aprendizaje que incentive la curiosidad, el interés y la motivación de los estudiantes, para favorecer la capacidad de reflexión, conceptualización y aplicación del conocimiento (Romero Ariza, 2010). Es decir, el profesor es un agente que diseña las condiciones óptimas que contribuyen al desarrollo de las competencias requeridas en los procesos formativos para que los estudiantes puedan afrontar retos profesionales, económicos y sociales.

Es necesario enfatizar que este modelo educativo no excluye aquellos programas y asignaturas cuyos contenidos son predominantemente teóricos y conceptuales, en los que el desarrollo de las clases es más eficiente implementando estrategias pedagógicas tradicionales de enseñanza y aprendizaje. Sin embargo, muchas otras asignaturas permiten incorporar un nivel de actividades y estrategias de aprendizaje activo o la combinación de estas con estrategias pedagógicas tradicionales.

De este modo, esperamos que nuestros estudiantes sean capaces de aplicar sus conocimientos y habilidades para pensar de manera crítica, diseñar y proponer soluciones pertinentes y creativas y actuar de manera responsable.

En este sentido, el aprendizaje activo es un modelo propicio para enfrentar los retos a futuro que nos hemos propuesto como Institución. Se basa en las teorías constructivistas de la educación y plantea que los estudiantes tengan un rol protagónico en la construcción de su propio conocimiento a partir de las experiencias previas obtenidas de su entorno. En palabras de Bowell (1991): “[El aprendizaje activo] conlleva que los estudiantes hagan cosas y piensen sobre lo que hacen” (citado en Ferreiro, 2020, p. 5), y reflexionen acerca de las estrategias empleadas para llegar a la solución de la actividad pedagógica o evaluativa propuesta por el profesor.

De acuerdo con Ferreiro (2020), son seis las características del aprendizaje activo:

- Los estudiantes se involucran en el proceso de aprendizaje, son sujetos activos. Más allá del ejercicio de la escucha, participan y toman decisiones.

- El aprendizaje se concibe como un proceso de conocimiento y transformación, no como memorización y absorción de contenidos. Los contenidos son vehículos fundamentales para el ejercicio de la ciencia y la reflexión.

- Los estudiantes se implican en actividades que requieren el desarrollo de capacidades de orden superior como el análisis, la inferencia, la síntesis y la evaluación.

- Involucran el aprendizaje. El diseño de las actividades y de los objetivos de mediación deben proporcionarles a los estudiantes una “considerable autonomía y control sobre la dirección de las actividades de aprendizaje” (Anthony, 1996, citado en Ferreiro, 2020, p. 5).

“Se acentúa la exploración de los propios valores y actitudes” (Ferreiro, 2020, p. 5).

- La interacción es directa entre el estudiante, el objeto de estudio y el profesor como actor dinamizador necesario para el proceso de aprendizaje.

En síntesis, es un aprendizaje contextualizado, y es quizás allí donde guarda mayor proximidad con el aprendizaje experiencial, que para Kolb y Fry (1975) es el resultado de “la integración de experiencias emocionales concretas con los procesos cognitivos: análisis conceptual y comprensión” (citado en Ferreiro, 2020, p. 1).

###### Aprendizaje experiencial

El aprendizaje experiencial, como parte del aprendizaje activo, es un enfoque educativo orientado a la implicación integral de los estudiantes por medio de procesos que van desde el diálogo y la participación en contextos naturales, socioculturales y organizacionales hasta la inmersión en entornos virtuales orientados a la simulación, para propiciar el desarrollo de competencias corporales, socioemocionales y cognitivas. En este enfoque, el estudiante, su relación con los pares, la naturaleza y con el contexto son elementos centrales en la apropiación del conocimiento, acompañado por un profesor, un facilitador o una estrategia que orienta o crea las condiciones para que suceda la experiencia formativa.

David Kolb propone el ciclo del aprendizaje experiencial, que involucra el saber hacer y el saber pensar con un enfoque centrado en la interiorización de los contenidos y la práctica misma, teniendo en cuenta a los estudiantes, sus talentos y estilos de aprendizaje. Ello determina y enriquece los procesos individuales y colectivos y que conducen a la construcción de estrategias de enseñanza a partir de las necesidades del contexto y de la vida cotidiana.

A continuación, se relacionan algunas técnicas y actividades que favorecen la interacción profesor- estudiante en el aprendizaje experiencial.

Momentos del aprendizaje experiencial

**Fuentes Olavarría (2019) sintetiza así los cuatro momentos del aprendizaje experiencial:**

1.   En la experiencia concreta, el estudiante capta y percibe nueva información, a través de los sentidos, del contacto, con los aspectos tangibles de la experiencia.
2.   En la observación reflexiva el estudiante procesa la experiencia, otorgándole sentido a lo observado y reflexionando sobre la conexión entre lo que se hace y las consecuencias de las acciones. Se incluyen en esta etapa actividades como preguntas de procesamiento, lluvia de ideas y discusiones, entre otras.
3.   En la conceptualización abstracta el estudiante obtiene nueva información (percibe) pensando. Por medio del pensamiento, obtiene nuevos conceptos, ideas y teorías que orientan la acción. Se incluyen en esta etapa actividades como analogías y construcción de modelos, entre otras.
4.   Finalmente, en la experimentación activa el estudiante comprende y procesa la nueva información haciendo, implicándose en nuevas experiencias y experimentando en forma activa para comprender […] (Fuentes Olavarría, 2019, p. 835).

Al cierre del ciclo de formación en pregrado y posgrado, en EAFIT esperamos que nuestros graduados sean sensibles y conscientes de los efectos de su intervención en el medio y que actúen con la seguridad que otorga el pensamiento crítico como orientador básico de la toma de decisiones. De allí la importancia de que los estudiantes entren en contacto con experiencias de aprendizaje que los expongan al contexto, al ambiente real, a retos y a problemas situados.

Como lo expone Baena Graciá (2019), para incrementar la motivación, facilitar el acercamiento de los estudiantes a situaciones frecuentes en el mundo profesional y mejorar su comprensión de los fenómenos, las cuatro fases de aprendizaje descritas –experiencia concreta, observación reflexiva, conceptualización abstracta y experimentación activa– promueven las siguientes acciones:

**Confiar**: permite la apertura a la experiencia sin temor a la equivocación o a sentirse juzgado.

**Comunicar**: hace posible compartir con los demás un punto de vista, aprender de la experiencia de los otros y auspiciar un ambiente para la libre expresión de las ideas.

**Cooperar**: facilita el trabajo en equipo para la consecución de objetivos comunes.

**Interactuar**: aporta lo esencial en el aprendizaje experiencial, ya que, gracias a la interacción con situaciones específicas que representen un desafío, se ven favorecidos los procesos cognitivos involucrados en el aprendizaje, al igual que la consolidación de conocimientos.

El rol del profesor en el aprendizaje experiencial

​​El profesor cumple un papel crucial en el aprendizaje experiencial. Tiene a su cargo el diseño y es el facilitador de las experiencias de aprendizaje, a la vez que motiva la aplicación de los conocimientos en un contexto particular y proporciona la realimentación adecuada y oportuna encaminada a que el estudiante desarrolle las competencias requeridas.

El profesor desempeña cuatro roles en las diferentes etapas del aprendizaje experiencial: facilitador, experto, evaluador y mentor. La gráfica 8 los define y establece su alcance.

El papel del estudiante en el aprendizaje experiencial

El estudiante es un sujeto activo y participativo en el proceso de aprendizaje. Cuando decimos que es el responsable del proceso educativo significa que se hace cargo de cumplir con lo acordado en el pacto pedagógico y de disponer de sus recursos y capacidades para el logro individual y colectivo de los propósitos del aprendizaje. Además de aprehender la información que se ofrece en cada asignatura, el estudiante debe disponerse para experimentar, reflexionar, conceptualizar, crear nuevo conocimiento y acoger de manera constructiva los resultados de las evaluaciones. La gráfica 9 muestra los conocimientos o alcances que en su rol desempeñan y obtienen los estudiantes, en el modelo de aprendizaje activo y experiencial.

Por último, cabe aclarar que la clase magistral no desaparece de la escena educativa. En efecto, para un resultado apropiado y acorde con los planteamientos didácticos, toda estrategia pedagógica que responda a cualquiera de los tipos de aprendizaje centrados en la experiencia requiere de fundamentación, historicidad de los conceptos y ejemplificación, así como del intercambio entre profesores y estudiantes sobre el área de dominio o materia de estudio, lo cual refleja también la relación que el profesor ha construido en su ejercicio pedagógico.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate