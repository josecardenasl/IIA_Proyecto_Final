# Monitorías - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 4: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Monitorías

Haz parte del pr​​ogram​​a de monitorías Administrativas, académicas, investigación, contraprestación y logísticas. Potencia tu perfil profesional.

*    Monitorías 

#### ¿Qué es el programa de monitoría?

Es una estrategia de formación extracurricular que ofrece a los estudiantes de pregrado una oportunidad para desarrollar sus aptitudes, competencias y habilidades en el ámbito docente, administrativo, investigativo o logístico, con el propósito de contribuir a su formación integral.

### Tipos de monitoría

## Monitoría Administrativa

Una oportunidad para poner en práctica los conocimientos, habilidades y destrezas adquiridos en su proceso de formación, mediante el apoyo y aprendizaje activo en las dependencias de la Universidad.

## Monitoría Académica

Una oportunidad para descubrir opciones y oportunidades de exploración vocacional y aplicación de competencias, de acuerdo con los intereses hacia la docencia.

## Monitoría Investigación

Una oportunidad para estimular la participación de los estudiantes en actividades de investigación desde tareas instrumentales hasta elaboraciones conceptuales.

## Monitoría Contraprestación

Una oportunidad para poner en práctica los conocimientos, habilidades y destrezas adquiridos en su proceso de formación, mediante el apoyo de Idiomas Eafit.

## Monitoría Logística

Una oportunidad para poner en práctica los conocimientos, habilidades y destrezas adquiridos en su proceso de formación, mediante la ejecución de cursos organizados por Educación Continua.

### Postulación

Para realizar la postulación debes ingresar a la plataforma [EPIK](https://acortar.link/kx9Sfc).

La postulación al programa de monitoría es semestral. La convocatoria para el 2026-1 estará habilitada desde el 19 de enero al 29 de mayo.

#### Duración de la monitoría

Las actividades de monitoría podrán efectuarse hasta por diez (10) horas a la semana y cuarenta (40) horas al mes. Estas horas se distribuirán en horarios flexibles conforme a la disponibilidad horaria de los estudiantes, y los mismos podrán modificarse para ajustarse a sus necesidades académicas.

Para lo anterior, se exceptúan las monitorías logísticas y en contraprestación, las cuales se encuentran reguladas por el número de horas de cada curso.

Las actividades de monitorías se podrán efectuar en los periodos académicos, durante dos semanas consecutivas en las vacaciones de mitad de año de los estudiantes y hasta que comiencen las vacaciones colectivas de la Universidad.

### Preguntas​ fr​ec​​uentes

Recibirás un correo con la notificación del acuerdo de confidencialidad, debes leerlo y, posteriormente, aceptarlo.

Debes tramitar el RUT ante la DIAN y, una vez cuentes con el documento, enviarlo escaneado al correo electrónico[terceros@eafit.edu.co](mailto:terceros@eafit.edu.co), solicitando inscribir el RUT para el trámite de los apoyos económicos del programa de Monitorías.

Por favor ingresar al siguiente enlace y diligenciar este ​[formulario](https://forms.office.com/pages/responsepage.aspx?id=XrX3mb6ce0aBQ5GXgpGK-xtYXXtPa_tMoPuD8UgPJMdURVo1SlVKQzZNQThDU1RDVURSTFo4OExRUiQlQCN0PWcu).

En caso de que no tengas la cuenta bancaria personal, debes tener presente lo siguiente: debes abrir una cuenta bancaria en la entidad que prefieras de la cual debes ser titular. Puedes usar cualquier tipo de cuenta bancaria de entidades colombianas, como por ejemplo, Nequi, Daviplata, Ahorro a la Mano (Bancolombia), Dale (Banco popular).. etc.

Los documentos deben estar listos al momento de postularte a la convocatoria.

Los certificados de las monitorías los podrá solicitar a través este [formulario](https://forms.office.com/r/Ba1rkQXmhA).

La postulación se debe realizar una vez por semestre. La convocatoria se envía a inicio de cada semestre a través del correo electrónico y se publica en la página web de la Universidad.

Las actividades de monitoría, según las políticas del programa, se podrán efectuar durante los periodos académicos. Para las vacaciones de mitad de año, las personas que participen en las monitorías deben tener dos semanas consecutivas de descanso. Al final del año se podrán realizar monitorías hasta el inicio de las vacaciones colectivas de la Universidad.

El pago de las ayudas económicas se efectúa el día seis (6) del mes siguiente a la realización de la monitoría, o el día hábil antes en caso de que este día sea en fin de semana o festivo.

La Universidad realiza el pago de las ayudas económicas a través de trasferencia bancaria en la cuenta que el estudiante inscribió previamente en el área de Tesorería de la Universidad.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate