*    Política de Lenguas Extranjeras 

A través de la Política de Lengua Extranjera (PLE), la Universidad EAFIT busca fomentar la excelencia académica de sus estudiantes, ofreciéndoles la oportunidad de desarrollar las competencias en diferentes idiomas para que estén en capacidad de enfrentar las demandas del mundo actual. Hoy en día, el aprendizaje de una lengua extranjera, especialmente el inglés, se constituye en una necesidad básica para el avance de las profesiones, la investigación y las comunicaciones internacionales.​

La política de Lengua Extranjera de la Universidad EAFIT es un sistema de control para sus estudiantes de Pregrado con respecto al manejo de un segundo y tercer idioma; este último para estudiantes de Negocios Internacionales.​​​

###### **Aquí te contamos de una manera rápida y sencilla**

​La Universidad ofrece la posibilidad de cumplir con los controles de suficiencia del inglés por medio de la aprobación de los cursos en Idiomas EAFIT (certificación de todas las competencias) o la presentación de exámenes de suficiencia en los diferentes Idiomas (Ver Tabla 2). Para cumplir con los controles de suficiencia en comprensión lectora, por favor referirse a la Tabla 1 (requisitos de suficiencia por programa académico) y la Tabla 3 (exámenes de comprensión lectora).

###### Conoce los controles que debes cumplir según el pénsum

A continuación vas a encontrar las materias que tienen como pre-requisito la aprobación de cada control. Es importante que las tengas presente, porque el no aprobarlo ocasionará que no puedas inscribir esta materia que a su vez pueden ser habilitadoras de otras generando retraso para avanzar en tu plan de estudio y por ende en la graduación.

Escuela de Administración

###### **Administración de negocios**(pensum 20222)

## Control 1. Nivel A1

Semestre 3

 Organizaciones

## Control 2. Nivel A2

Semestre 5 y 6

 Ética e integridad

 Proyecto integrador

 Estrategia

## Control 3. Nivel B1

Semestre 7 y 8

 Talento II - Escuela de Administración 

 Periodo de práctica (Administración - Reforma)

###### **Contaduría Pública (pensum 20222)**

## Control 1. Nivel A1

Semestre 4

 Proyecto 3: Investigación

 contable

## Control 2. Nivel A2

Semestre 7

 Presupuestos

## Control 3. Nivel B1

Semestre 9

 Reportes integrados

###### **Mercadeo**

## Control 1. Nivel A1

Semestre 3

 Innovación y desarrollo de nuevos productos

## Control 2. Nivel A2

Semestre 5

 Métodos cuantitativos de investigación

## Control 3. Nivel B1

Semestre 9

 Estrategias de

 internacionalización

 Prepráctica

 Grados

###### **Negocios Internacionales**

## Control 1. Inglés B1

Semestre 1. 

 Matrícula para el primer semestre

## Control 2. Inglés B2

Semestre 7. 

 Prepráctica

## Control 3. Tercer Idioma B1

Semestre 7. 

 Prepráctica

Los requisitos de la política de lengua extranjera de este pregrado son diferentes a los de los demás pregrados:

1.   Como requisito para ser admitido en el programa, deberás presentar una suficiencia de B1 en inglés para el ingreso a la U.
2.   Durante tu carrera podrás certificarte de nuevo o tomar cursos para presentar suficiencia del idioma inglés de B2. Este será necesario para tu práctica y graduarte.
3.   Durante tu carrera también deberás certificarte, con los exámenes admitidos por la Universidad o tomar los cursos para alcanzar una suficiencia de B1 en una tercera lengua seleccionada por ti. Esta deberá ser registrada en tus controles de Admisiones y Registro.

Escuela de Ciencias Aplicadas e Ingeniería

###### **Biología**

## Control 1. Nivel A1

Semestre 3

 Práctica investigativa I

## Control 2. Nivel A2

Semestre 7

 Innovación científica

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Diseño Urbano y Gestión del Hábitat**

## Control 1. Nivel A1

Semestre 4

 Proyecto urbano y de paisaje

## Control 2. Nivel A2

Semestre 7

 Formulación trayectoria

## Control 3. Nivel B1

Semestre 9

 Seminario final

###### **Geología**

## Control 1. Nivel A1

Semestre 4

 Petrología

## Control 2. Nivel A2

Semestre 7

 Geología de Colombia

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Ingeniería de Producción (pensum 20251)**

## Control 1. Nivel A1

Semestre 3

 Internet de las cosas industrial

## Control 2. Nivel A2

Semestre 5

 Robótica

## Control 3. Nivel B1

Semestre 8

 Grados

###### **Ingeniería Agronómica**

## Control 1. Nivel A1

Semestre 4

 Semillas fitomejoramiento y propagación

## Control 2. Nivel A2

Semestre 7. 

 Negocios Internacionales

## Control 3. Nivel B1

Semestre 10

 Requisito de grado

###### **Ingeniería Civil (pensum 20242)**

## Control 1. Nivel A1

Semestre 3

 Dinámica

## Control 2. Nivel A2

Semestre 6

 Proyecto Ingeniería Civil

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Ingeniería de Diseño de Producto**

## Control 1. Nivel A1

Semestre 3

 Lenguaje de producto

## Control 2. Nivel A2

Semestre 5

 Sistemas de ingeniería

## Control 3. Nivel B1

Semestre 8

 Ingeniería concurrente

###### **Ingeniería de Procesos (pensum 20222)**

## Control 1. Nivel A1

Semestre 4

 Información científica

## Control 2. Nivel A2

Semestre 8

 Talento II - Escuela de Ciencias Aplicadas Ingeniería

## Control 3. Nivel B1

Semestre 10

 Grados

###### **Ingeniería de Sistemas (pensum 20242)**

## Control 1. Nivel A1

Semestre 4

 Proyectos integrados I

## Control 2. Nivel A2

Semestre 7

 Prepráctica

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Ingeniería de Sistemas (pensum 20251)**

## Control 1. Nivel A1

Semestre 4

 Sistemas operativos

 Proyecto integrador I

## Control 2. Nivel A2

Semestre 8

 Grados

## Control 3. Nivel B1

Semestre 8

 Grados

###### **Ingeniería Física**

## Control 1. Nivel A1

Semestre 4

 Física matemática 1 (Ingeniería física)

## Control 2. Nivel A2

Semestre 7

 Física estadística

 Prepráctica

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Ingeniería Matemática**

## Control 1. Nivel A1

Semestre 5

 Modelación y simulación V

## Control 2. Nivel A2

Semestre 7

 Prepráctica investigativa 2

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Ingeniería Mecánica (pensum 20232)**

## Control 1. Nivel A1

Semestre 3

 Mecánica experimental

## Control 2. Nivel A2

Semestre 5

 Ingeniería de mantenimiento

## Control 3. Nivel B1

Semestre 7

 Prepráctica

###### **Ingeniería Mecánica (pensum 20241)**

## Control 1. Nivel A1

Semestre 2

 Análisis funcional de máquinas

## Control 2. Nivel A2

Semestre 5

 Formulación de proyectos en ingeniería

## Control 3. Nivel B1

Grados.

Escuela de Humanidades

###### **Comunicación Social (pensum 2023)**

## Control 1. Nivel A1

Semestre 5

 Cibercultura

## Control 2. Nivel A2

Semestre 7

 Gestión de comunidades y estrategias de redes sociales

 Prepráctica

## Control 3. Nivel B1

Semestre 8

 Grados

###### **Comunicación Social (pensum 2024)**

## Control 1. Nivel A1

Semestre 4

 Hipertextos y convergencia

## Control 2. Nivel A2

Semestre 6

 Humanidades digitales e intermédiales

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Diseño Interactivo**

## Control 1. Nivel A1

Semestre 5 

 Tranformación digital

## Control 2. Nivel A2

Semestre 7 

 Humanidades digitales e intermediales

## Control 3. Nivel B1

Semestre 9 

 Grados

###### **Literatura**

## Control 1. Nivel A1

Semestre 5 

 Humanidades digitales

## Control 2. Nivel A2

Semestre 7 

 Emprendimiento de proyectos culturales 

 Prepráctica

## Control 3. Nivel B1

Semestre 9

 Grados

###### **Música**

## Control 1. Nivel A1

Semestre 4 

 Historia de la música 4

## Control 2. Nivel A2

Semestre 6 

 Estética de la música

## Control 3. Nivel B1

Semestre 8 

 Prepráctica 

 Grados

###### **Psicología**

## Control 1. Nivel A1

Semestre 4 

 Psicología evolutiva

## Control 2. Nivel A2

Semestre 7 

 Ética profesional

## Control 3. Nivel B1

Semestre 9 

 Prepráctica 

 Grados

Escuela de Derecho

###### **Derecho**

## Control 1. Nivel A1

Semestre 5

 Contratos

## Control 2. Nivel A2

Semestre 8

 Práctica

## Control 3. Nivel B1

Semestre 9 

 Grados

Escuela de Finanzas

###### **Ciencias Políticas**

## Control 1. Nivel A1

Semestre 4 

 Métodos cuantitativos

## Control 2. Nivel A2

Semestre 6

 Gobernanza local

## Control 3. Nivel B1

Semestre 9 

 Grados

###### **Economía (pensum 20222)**

## Control 1. Nivel A1

Semestre 5 

 Econometría 2

## Control 2. Nivel A2

Semestre 7 

 Talento II - Escuela de Finanzas, Economía y Gobierno

## Control 3. Nivel B1

Semestre 9 

 Grados

###### **Finanzas**

## Control 1. Nivel A1

Semestre 3 

 Análisis financiero

## Control 2. Nivel A2

Semestre 5 

 Instrumentos financieros de renta fija

## Control 3. Nivel B1

Semestre 7 

 Prepráctica

En las siguientes tablas puede verse el número de controles y niveles de suficiencia exigidos por la Universidad: ​

## Pregrados en general

Idioma: Certificable

 Control 1: A1

 Control 2: A2

 Control 3: B1

## Pregrados Negocios Internacionales - Primera lengua

Idioma: Inglés

 Entrada: B1

 Salida: B2

## Pregrados Negocios Internacionales - Segunda lengua

Idioma: Certificable

 Control 1: B1

Aquí vemos una correspondencia de los niveles con categorías que son más conocidas:

​​La Universidad Eafit ha estipulado que el nivel de suficiencia requerido para graduarse de pregrado es B1. Este es un nivel suficiente para interactuar con hablantes de inglés sobre temas familiares, para leer informes simples sobre temas familiares y escribir sobre temas sencillos en su campo de estudio.

Para certificar los controles, la universidad acepta:​

1. El certificado de uno de los exámenes internacionales correspondientes al nivel exigido según el Marco Común Europeo de referencia para las lenguas y que pueden encontrar en la [TABLA 2](https://universidadeafit.widen.net/s/rpxs7tzmrq/tabla-2-politica-lengua-extranjera). Este certificado es válido por doce (12) meses a partir de la fecha de presentación del examen para los estudiantes del programa de pregrado de negocios internacionales y por dos (2) años a partir de la fecha de presentación del examen para los estudiantes de los demás programas.

2. El certificado emitido por Idiomas EAFIT en el que constan los cursos aprobados y correspondientes al nivel a certificar según la [TABLA 2](https://universidadeafit.widen.net/s/rpxs7tzmrq/tabla-2-politica-lengua-extranjera). PUNTAJES POR NIVELES. Este certificado es válido por dos años a partir de la fecha de culminación del último curso tomado en Idiomas EAFIT, y por doce (12) meses a partir de la fecha de culminación del último curso tomado en Idiomas EAFIT, para los estudiantes del programa de pregrado de negocios internacionales, o los demás programas.

3. El diploma de grado de una institución de educación formal (bachillerato o educación superior) localizada en un país cuyo idioma nativo es el que se certificará como Lengua Extranjera y donde los estudios se realicen en la lengua extranjera. Este diploma debe ser el mismo que se presenta para admisión a los programas de pregrado o posgrado en la Universidad EAFIT.