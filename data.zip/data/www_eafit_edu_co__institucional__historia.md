# Historia de EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Historia de EAFIT

​EAFIT, una histo​​ria que tejem​​os con nuestra comunidad de talento y organizaciones aliadas​.

*    Historia de EAFIT 

Un grupo de visionarios, líderes de empresas, se reunieron en las oficinas de la Asociación Nacional de Industriales, en el centro de esa Medellín industrial que experimentaba un crecimiento inusitado en varios frentes. Con los Estatutos de la Fundación, diligenciados en máquina de escribir el 4 de mayo de 1960, comenzó la historia de la entonces Escuela de Administración y Finanzas, hoy Universidad EAFIT.​​​

##### Los primeros protagonistas y quienes siguieron su legado de liderazgo​

## Funda​dores

Desde grandes empresarios, preocupados por el avance de la educación en Medellín, nace la idea de una escuela para la formación de los administradores del patrimonio público y económico del país y de la región antioqueña.​

## Rect​ores

Detrás de cada hecho en la historia de la Universidad hay 11 hombres y 1 una mujer que han liderado la Institución para cumplir nuestro propósito de inspirar vidas, crear conocimiento y transformar sociedad.​

### Un álbum para nun​​​ca olvidar​

### Década de 1960

### Década de 1970

### Década de 1980

### Década de 1990

### Década de 2000

### Década de 2010

### Década de 2020

#### ...Y se vive en el territorio

En 2020, cuando conmemoramos 60 años, hicimos un recorrido por la transformación urbana que ha tenido el sector de La Aguacatala, en el sur de Medellín, durante las seis primeras décadas de historia de la Universidad. Este camino, que se reconstruyó con el tesroro documental y el trabajo la Sala de Patrimonio Documental de la Biblioteca, Urbam y el Departamento de Comunicación, inicia en la configuración del municipio de Medellín y recorre los momentos en los que EAFIT nace y teje un territorio lleno de vidas e historias.​

###### Conmemoración de nuestros aniversarios

## ​En 2015 celebramos nuestros 55 años

## En 2020 celebramos nuestros 60 años

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)