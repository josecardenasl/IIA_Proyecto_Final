# Deportes - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 11: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Deportes

Descubre los programas deportivos y recreativos de la Universidad EAFIT: cursos, clubes y reservas de instalaciones para toda la comunidad eafitense.

*    Deportes 

Infraestructura

Consu​​​lta los diferentes escenarios deportivos

Club de Caminantes

Dirigido para todo el público que desee conocer nuevos lugares en Antioquía.

 A partir del 1 de febrero de 2026

Cursos deportivos

Natación, Hidroaeróbicos y Tenis de Campo.

 Dirigido a todo el público.

 Inscripciones a partir del 16 de febrero de 2026 a las 8:00 a.m.

Deportes representativos competitivos

Dirigido a estudiantes de pregrado y posgrado, empleados y graduados.

 A partir del 9 de febrero de 2026

Deporte Libre

Dirigido a estudiantes de pregrado y posgrado, empleados y graduados.

 A partir del 9 de febrero de 2026

Bañista libre

Solo se permite el ingreso para estudiantes de pregrado / posgrado, empleados y graduados

Reserva de escenarios deportivos

Dirigido a para estudiantes de pregrado / posgrado, empleados.

##### Galería de imágenes

###### Galería de videos

##### Fútbol femenino EAFIT 2024 1

##### Voleibol - Torneo TDA EAFIT/2024-1

##### Disco Volador

##### Atletismo EAFIT

##### Tenis de mesa

##### Karate

Contacto - Deportes 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Deportes

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Celular*? 

Correo electrónico*? 

Su comentario o solicitud*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate