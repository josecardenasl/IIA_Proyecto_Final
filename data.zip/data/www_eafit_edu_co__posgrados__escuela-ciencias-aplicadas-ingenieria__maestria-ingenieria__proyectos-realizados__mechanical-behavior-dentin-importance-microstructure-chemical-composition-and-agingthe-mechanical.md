# THE MECHANICAL BEHAVIOR OF DENTIN: IMPORTANCE OF MICROSTRUCTURE, CHEMICAL COMPOSITION AND AGINGTHE MECHANICAL BEHAVIOR OF DENTIN: IMPORTANCE OF MICROSTRUCTURE, CHEMICAL COMPOSITION AND AGING - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 18: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# THE MECHANICAL BEHAVIOR OF DENTIN: IMPORTANCE OF MICROSTRUCTURE, CHEMICAL COMPOSITION AND AGING

*    Escuela Ciencias Aplicadas Ingenieria 
*    THE MECHANICAL BEHAVIOR OF DENTIN: IMPORTANCE OF MICROSTRUCTURE, CHEMICAL COMPOSITION AND AGINGTHE MECHANICAL BEHAVIOR OF DENTIN: IMPORTANCE OF MICROSTRUCTURE, CHEMICAL COMPOSITION AND AGING 

###### Carolina Montoya Mesa

**February 2017Abstract**

Dental fracture is one of the three most common forms of failure of restored teeth and the most common cause of tooth loss or extraction in elderly patients. Previous investigations conducted on aging of hard tissues have identified that there is a considerable reduction in the mechanical properties (i.e. fracture toughness, fatigue and flexural resistance) of dentin with aging and that may predispose tooth racture. These declines in properties have been attributed to microstructural and chemical composition changes over time. However, these aging processes have not been really quantified and related with the changes in mechanical properties. Accordingly, the aim of this work is to evaluate the aging process of coronal dentin in terms of the evolution of microstructure, changes in chemical composition and mechanical properties from selected age groups (young and old donors). The changes in these properties were evaluated in three different regions (outer, middle and inner) in order to identify spatial variations within the crown.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate