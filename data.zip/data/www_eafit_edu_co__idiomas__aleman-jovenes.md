# Alemán para Jóvenes | Idiomas EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Alemán para Jóvenes

### Edad 12 a 16 años

Descubre la riqueza cultural del alemán y atrévete a sumergirte en su historia y tradiciones.

*    Alemán Para Jóvenes 

### Dirigido a

Jóvenes de 12 a 16 años

### Inversión por curso

$1​.215.000

*No incluye costo del libro

### Duración

42.5 horas por curso

## Modalidades

Información general

Aprende uno de los idiomas más hablados en el mundo.

En Idiomas EAFIT aprendes con una metodología innovadora y efectiva todo lo necesario para comunicarte en un contexto real.

*   Profesores capacitados.
*   Clases prácticas y didácticas diferentes a lo convencional.

Nuestro enfoque te facilita el **aprendizaje significativo de los idiomas** a través de actividades entretenidas, constante interacción en el idioma y secciones prácticas. Esto permite que las clases sean dinámicas, promoviendo el **desarrollo de tus habilidades comunicativas** y el conocimiento que te serán útiles en diferentes ámbitos.

Los programas de idiomas diferentes a inglés: alemán, español para extranjeros, francés, italiano y portugués, tienen un texto guía que será uno de los recursos empleados por nuestros docentes durante las clases. Si bien no existe obligatoriedad para adquirirlo, está la posibilidad de hacerlo en la librería de la Universidad. En este momento están en proceso de importación. Una vez estén disponibles, los profesores lo comunicarán.

Curso 1 3U

Curso 2 3U

Curso 3 2U

Curso 4 3U

Curso 5 3U

Curso 6 3U

Curso 7 3U

Curso 8 3U

Curso 9 3U

Curso 10 3U

Curso 11 2U

Curso 12 3U

Inversión

###### **Inversión por curso**

## Sede Poblado

1.215.000

 Cada curso

 *No incluye costo del libro

## Sede Belén

1.130.000

 Cada curso

 *No incluye costo del libro

Regulares

###### Calendario 2026

**Martes:**

**Sede Poblado:** 4:00 p.m. a 6:30 p.m.

# Tabla de Fechas de Matrículas

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Junio 2 | Noviembre 10 - Enero 20 |
| Julio 14 | Noviembre 24 | Mayo 25 - Julio 14 |

**Miércoles**

**Sede Belén:**4:00 p.m. a 6:00 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 21 | Junio 3 | Noviembre 10 - Enero 21 |
| Julio 15 | Noviembre 25 | Mayo 25 - Julio 15 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos.**

***Los cursos de alemán para jóvenes no tienen clase durante estos días:**

Semana Santa

20 de abril

Semana de receso escolar.

## ¿Por qué aprender Alemán?

Porque ofrecen educación gratuita en excelentes Universidades.

 Alemania es una de las potencias más importantes en ciencia y tecnología.

 Viajarás sin problema y harás nuevos amigos.

 Aprenderás las palabras más largas que existen.

 Sabrás que dice Rammstein en sus canciones.

 Podrás obtener más fácil trabajo al saber hablar varios idiomas.

 Aprenderás el idioma de Goethe, Kafka, Mozart, Bach y Beethoven.

 Tendrás un perfil diferente a los demás y eso te abrirá muchas puertas.

## ¿Por qué estudiar ​​​idiomas en EAFIT?

Con 30 años de experiencia en la enseñanza de idiomas, como respuesta a las exigencias mundiales, Idiomas EAFIT tiene como objetivo principal dar solución a las necesidades del entorno académico, empresarial y gubernamental.

## Portafolio corporativo

## Global Explorers

# Proceso de inscripción

El primer paso para inscribirte, es conocer cuál es el nivel ideal para ti. Para ello debes realizar una cita de clasificación, solicítala así:

### 1

### Ingresa

### 2

### Selecciona la edad del estudiante

Jóvenes 12 a 16 años

### 3

### Selecciona el idioma

Alemán

### 4

### En la pregunta sobre si tienes conocimiento

selecciona si o no.

### 5

### Sigue los pasos detallados en la plataforma

para programar tu cita de clasificación o realizar la inscripción según tu caso.

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

## Líneas de atención

(57) 604 2619500

## Sugerencias

## ¡Idiomas EAFIT llega a Bello!

Aprende inglés con educación de calidad y una metodología efectiva.

## Spanish program

Personalized sessions adapted to your needs

## English Stars - niños de 4 años

### Edad 4 años

Un programa para aprender inglés y fortalecer habilidades clave para el desarrollo cognitivo, social y comunicativo en la primera infancia.

## Vacacionales Happy Time

### Edad 5 a 10 años

Vacaciones en inglés para niños. Una semana perfecta para disfrutar y conocer el mundo mientras aprenden un nuevo idioma.

## Programa de inglés para niños y niñas

### Edad 4 a 11 años

Metodología participativa con resultados reales que desarrollan habilidades cognitivas y sociales.

## Programas de inglés para niños y niñas

### Edad 4 a 11 años

El programa de inglés para niños que combina el juego, la creatividad y el aprendizaje de un nuevo idioma de manera efectiva

## Inglés para jóvenes

### Edad 12 a 16 años

Conecta con el mundo y fortalece habilidades clave para tu futuro académico y profesional.

## Portugués para adultos

### Edad +17

Disfruta la experiencia de aprender una de las lenguas más dulces y agradables del mundo.

## Italiano para adultos

### Edad +17

Aprende italiano de forma divertida y expande tus horizontes con nuevos conocimientos.

## Francés para adultos

### Edad +17

Aprende una de las lenguas más fascinantes y sumérgete en una cultura artística y rica.

## Alemán para adultos

### Edad +17

Aprende con una metodología efectiva y práctica y descubre la riqueza cultural del alemán, sumérgete en su historia y tradiciones.

## Francés para jóvenes

### Edad 12 a 16 años

Domina una lengua romance fascinante y explora una cultura artística y rica.

## Alemán para Jóvenes

### Edad 12 a 16 años

Descubre la riqueza cultural del alemán y atrévete a sumergirte en su historia y tradiciones.

## Inglés virtual para adultos

### Edad +18

Vive una experiencia flexible, personalizada y con acompañamiento real

## Inglés para adultos

### Edad +17

Domina el inglés con una metodología efectiva y accede a oportunidades para crecer, viajar y destacar profesionalmente.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)