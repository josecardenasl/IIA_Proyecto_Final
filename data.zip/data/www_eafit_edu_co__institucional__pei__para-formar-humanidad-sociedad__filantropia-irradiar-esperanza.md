# Filantropía para irradiar esperanza

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Filantropía para irradiar esperanza

*    Filantropía Para Irradiar Esperanza 

​​El sector educativo, por su mismo papel como agente transformador, es uno de los terrenos abonados para sembrar y fomentar la filantropía. Por eso, en febrero de 2019, la Universidad presentó de manera oficial a la comunidad el Centro de Filantropía de EAFIT, que forja humanidad y sociedad conectando agentes, personas, instituciones, fundaciones y empresas que quieran aportar a la sociedad a través de la educación.

Este Centro interpela a la sociedad para que más jóvenes de muchas potencialidades tengan acceso a la educación superior y al desarrollo científico y social, a través de las siguientes causas: estudiantes (becas y apoyos académicos), ciencia, tecnología e innovación (apalancando proyectos para beneficio de la humanidad), desafíos institucionales (apoyando la cultura, el deporte y los proyectos de infraestructura) y voluntariado (conectando talento para lograr un mayor impacto).

​En septiembre de 2019 se realizó el primer Giving Day, en el que participaron más de 590 personas que hicieron sus donaciones para ampliar los beneficios que se otorgan a través del Centro.

## ​​Para los jóvenes de la ruralidad

​La Beca Fundadores se creó en 2019 coordinada por el Centro de Filantropía específicamente para el pregrado de Ingeniería Agronómica, con el apoyo de distintas instituciones que se han vinculado a la formación profesional de los jóvenes rurales. Las fundaciones Aurelio Llano Posada, Bancolombia, Fraternidad Medellín, Sofía Pérez de Soto y el Grupo Bios han sido las entidades acompañantes desde el comienzo. Bachilleres recién graduados o que estén a punto de hacerlo, pobladores de las regiones rurales de Colombia en los estratos 1, 2 y 3, tienen​ la oportunidad de aspirar a ella.

## Educación de calidad

## Reducción de las desigualdades

## Alianzas para lograr objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate