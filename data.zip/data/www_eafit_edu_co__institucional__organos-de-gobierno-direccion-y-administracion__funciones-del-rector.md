# Funciones del Rector​​​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Funciones del Rector​​​

*    Funciones del Rector​​​ 

###### Funciones del Rector​​​

Dirigir el funcionamiento general de la Universidad, trabajar por su engrandecimiento y disponer o proponer a las instancias correspondientes, las acciones necesarias para lograr los objetivos institucionales. Cada año debe presentar un informe de su gestión ante el Consejo Directivo.

Adoptar y orientar procedimientos apropiados de planeación, programación, dirección, ejecución, evaluación y control de las actividades de la Institución.

Adoptar los sistemas de información científica, información estadística, admisiones, registro y control académico, presupuesto, contabilidad, administración de personal, adquisiciones y suministros; almacenes, inventarios y administración de planta física, necesarios para el adecuado funcionamiento de la Universidad.

Presentar al Consejo Directivo, para su ratificación, el nombramiento de los vicerrectores, de los decanos y del secretario general junto con las calidades y la trayectoria académica y/o administrativa que acreditan para ejercer dichos cargos.

Nombrar y remover a los directivos y al personal de la Universidad con arreglo a las disposiciones legales y reglamentarias vigentes y adoptar todas las decisiones concernientes a la administración de esas personas.

Presentar la estrategia para discusión y aprobación del Consejo Superior, al igual que sus seguimientos.

Presentar los planes o acciones asociados al incremento del patrimonio y endowment de la Universidad para aprobación del Consejo Superior, al igual que sus seguimientos.

Presentar el seguimiento al Plan de Desarrollo Institucional al Consejo Superior.

Presentar la propuesta de reforma de los Estatutos Generales para aprobación del Consejo Superior.

Presentar la propuesta de representantes legales suplentes para su designación por parte del Consejo Superior.

Presentar al Consejo Superior los Planes Maestros de la Universidad.

Ejecutar los procedimientos asociados para que el Consejo Superior otorgue las distinciones y los grados Honoris Causa.

Proponer al Consejo Directivo la creación, fusión y supresión de la estructura del primer nivel administrativo y académico, entendiendo como tal los cargos que dependen directamente del rector.

Someter el proyecto de presupuesto de ingresos y egresos de la Institución a consideración del Consejo Directivo.

Presentar al Consejo Directivo el proyecto de asignación de excedentes para ser sometido a aprobación del Consejo Superior.

Presentar al Consejo Directivo los estados financieros, junto con el informe de Revisoría Fiscal para ser sometido a aprobación del Consejo Superior.

Presentar al Consejo Directivo, cuando sea necesario, estudios sobre las tarifas de matrículas y demás derechos pecuniarios que pueda cobrar la Institución, y fijar el valor de los servicios de extensión y de investigación.

Velar por la conservación y el acrecentamiento del patrimonio económico, científico, pedagógico, cultural y artístico de la Universidad.

Dirigir y fomentar las relaciones nacionales e internacionales de la Institución.

Aprobar la política salarial para todo el personal vinculado laboralmente a la Universidad, excepto la de aquellos colaboradores que este asignado a otro órgano.

Representar judicial y extrajudicialmente a la Universidad, defender sus derechos y nombrar apoderados.

Aceptar donaciones y legados, celebrar operaciones de crédito y contratos, realizar actividades comerciales hasta la cuantía que el Consejo Superior establezca.

Enajenar o adquirir toda clase de bienes inmuebles hasta la cuantía que el Consejo Superior establezca.

Enajenar o adquirir toda clase de bienes muebles.

Alterar la forma de los bienes y darlos en hipoteca o prenda, o gravarlos o limitarlos, previa autorización del Consejo Directivo.

Celebrar contratos en que la Universidad entre como socia o accionista de una sociedad, previa autorización del Consejo Directivo.

Firmar letras, pagarés, cheques, giros, libranzas y cualesquiera otros títulos valores, así como endosarlos, negociarlos, cobrarlos, pagarlos, compensarlos, descargarlos, etc.; abrir, manejar y cancelar cuentas corrientes en las entidades bancarias.

Fijar los cupos máximos y mínimos de admisión de estudiantes para cada carrera y para cada período académico, de conformidad con las disposiciones legales que rijan sobre la materia.

Reglamentar la elección de profesores, estudiantes, egresados y demás miembros que, de conformidad con las normas legales y estatutarias, deban hacer parte de los organismos colegiados de la Universidad, y efectuar oportunamente la convocatoria cuando se produzca la vacante o se termine el período de alguno de ellos.

Recomendar al Consejo Directivo los estímulos y distinciones para los profesores.

Ejercer la función disciplinaria según lo previsto en los Estatutos y los Reglamentos de la Institución, con potestad para imponer a los integrantes del personal universitario las sanciones de suspensión, expulsión y destitución reservadas a él. Mientras se desarrolla el proceso disciplinario, y cuando las circunstancias y la falta lo ameriten, puede suspender a quien es objeto de investigación. Contra esta decisión solo cabe el recurso de reposición.

Designar a los decanos encargados mientras se hace el procedimiento de nombramiento en propiedad de los decanos.

Firmar los títulos que la Universidad otorgue y las correspondientes actas de grado.

Expedir y firmar las resoluciones rectorales mediante las cuales se documentan las decisiones propias del rector.

Cumplir y hacer cumplir las normas constitucionales, legales, estatutarias y reglamentarias vigentes; así como los principios de la Universidad.

Las demás que le señalen las leyes, los Estatutos y los Reglamentos de la Universidad.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)