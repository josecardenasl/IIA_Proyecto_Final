# Frente a la depresión, buscar ayuda a tiempo puede hacer la diferencia​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Frente a la depresión, buscar ayuda a tiempo puede hacer la diferencia​

*    Frente A La Depresión, Buscar Ayuda A Tiempo Puede Hacer La Diferencia​ 

Para este artículo una eafitense quiso compartir su testimonio de vida con la depresión. Cambiamos su nombre para proteger su identidad.

“Hoy amanecí con la depre”, es una frase muy popular que, con seguridad, hemos escuchado en varias ocasiones. Sin e​mbargo, ¿sabemos realmente qué es la depresión y cuáles son sus síntomas? E​n este artículo conversamos con una de las psicólogas de Desarrollo Estudiantil para conocer más sobre este trastorno mental.

Y para abordar la depresión también tenemos que hablar, primero de la tristeza, reconocerla y validarla como una emoción necesaria, y aprender a gestionarla y tramitarla para evitar llegar a una situación más grave.

El primer episodio de depresión que vivió Sofía* en su vida fue a los 14 años, cuando sus papás tuvieron que trasladarla de colegio. En ese momento decidió aislarse de su familia y amigos, y solo salía de su cuarto para lo que era estrictamente necesario, como ir al baño o a la cocina.

Ese momento fue leve en comparación al que vivió cuando tenía 19 años y, por razones que se salían de sus manos, tuvo que aplazar un semestre de la Universidad.

​​​​​​

No me paraba de la cama, no prendía la luz, duraba semanas enteras sin bañarme y tenía trastocados mis horarios de sueño al punto de no saber cuándo era de día o cuándo era de noche. Además, comía muy poco y llegué a perder hasta 10 kilos de peso”, recuerda esta eafitense, quien se desempeña como practicante de la U, y a quien le cambiamos el nombre para proteger su identidad.

Fue su mamá quien insistió en que buscara ayuda psicológica, una decisión que tomó, finalmente, porque se sintió sobrepasada por el sentimiento permanente de tristeza y vacío que experimentaba todos los días.

​​​​​​

“Empecé las consultas en mi ciudad natal. No fue necesario que tomara medicamentos, pero sí fueron varios meses de terapia en los que la psicóloga me dejaba varias tareas, como llevar un diario sobre lo que sentía todos los días. También conversamos mucho y fue gracias a esto que pude identificar que la raíz de mis episodios de depresión eran los cambios muy bruscos, porque estos me desestabilizaban”, agrega.

Pero además de su diagnóstico, Sofía* también se llevó varias lecciones importantes para su vida. La primera, que es muy importante buscar ayuda porque no se puede tener el control de todo, levantar la mano y acudir a los profesionales adecuados que puedan brindar herramientas y recursos para hacer frente a estas situaciones.

​​​​​​

“La segunda, y quizás la más importante, es que la tristeza existe, es normal y hace parte de la vida. Lo que nosotros podemos hacer, además de sentirla, es tener las herramientas necesarias para gestionarla y no dejar que interfiera en nuestras vidas”, concluye

Para hablar de depresión,

primero hay que hablar d​​e tristeza​

Nadie está más de acuerdo con esta última frase que Eugenia Flórez Zapata, psicóloga del Departamento de Desarrollo Estudiantil. Para esta profesional, como en el caso de Sofía*, antes de hablar de depresión, el primer paso es reconocer la tristeza como una emoción válida y necesaria.

“La tristeza tiene muy ‘mala prensa´, por así decirlo, pero hace parte de la vida como la alegría o el miedo. Si no sintiéramos miedo, por ejemplo, no sabríamos identificar una situación de amenaza. Lo mismo sucede con la tristeza: es totalmente normal sentirla cuando se tiene una pérdida, del tipo que sea, y hay que permitirse vivirla para poder gestionarla y tramitarla”, puntualiza Eugenia, quien agrega que no toda tristeza es sinónimo de depresión.

​​​​​​

“A veces nos levantamos y decimos expresiones como ‘ay, es que estoy con la depre’, pero puede ser que simplemente estamos desanimados, y eso es normal”.

Sin embargo, cuando ese estado emocional se mantiene disminuido y se presentan situaciones como llanto aparentemente inmotivado, hipersomnia, dificultad para dormir o tristeza permanente; cuando se ven afectadas nuestras actividades cotidianas o perdemos la capacidad o el interés por disfrutar las cosas, y son síntomas que permanecen al menos por dos semanas, entonces se puede estar configurando un cuadro depresivo, y ahí es donde hay que estar alertas.

Se trata de unos síntomas que, si no tratan a tiempo, pueden agravarse y llevar a las personas a perder su capacidad de autogestión. De ahí la importancia de buscar ayuda a tiempo, porque el tipo de atención depende, en gran medida, del nivel en el que se esté.

​​​​​​

“En un primer nivel, por ejemplo, funciona la psicoterapia. En otros niveles moderados o graves es necesaria la medicación, especialmente para controlar los síntomas Hay que evitar llegar a un nivel grave por el riesgo de aparición de la ideación suicida”, explica.

Por eso, para Eugenia es fundamental tener en cuenta las siguientes recomendaciones:

Reconocer y validar todas las emociones que sentimos, incluida la tristeza. “No podemos estar felices todo el tiempo. La vida, como muchas cosas, tiene su balance y la tristeza también aporta a ese equilibrio”.

En caso de estar experimentando esta emoción, la segunda recomendación es identificar el o los factores que nos ayudan a gestionarlos. “A algunas personas les funciona hacerlo de manera individual, a otros el ejercicio, la lectura, la música u otra actividad que sea de su interés, o también están los que prefieren buscar un amigo, a un par o la familia. De ahí la importancia de cultivar buenos vínculos afectivos”.

Finalmente, y quizás la más importante, es desmitificar la búsqueda de ayuda. “Hay que saber pedirla y hacerlo a tiempo. Eso puede hacer una gran diferencia ante la emergencia de los síntomas”, concluye.

Recordemos que la Universidad cuenta con distintas rutas para el cuidado de la salud mental, así como el apoyo a través de la consulta psicológica para estudiantes de pregrado y posgrado, y el servicio de atención psicológica a empleados, la línea 24/7, el grupo de paramédicos para brindar primeros auxilios psicológicos, El Escuchadero (en convenio con la Alcaldía de Medellín), y el Directorio de Servicios en Salud Mental.

Así mismo, los profesores y colaboradores también cuentan con el apoyo de una línea especializada.

Estos y muchos otros recursos los podemos consultar en el siguiente enlace​.​​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)