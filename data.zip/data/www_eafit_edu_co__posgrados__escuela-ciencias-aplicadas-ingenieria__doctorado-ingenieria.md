# Doctorado en Ingeniería - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Doctorado en Ingeniería

SNIES 52668, Medellín

Conocer la topografía submarina de la costa Caribe colombiana, para el aprovechamiento de sus recursos, o identificar la vulnerabilidad física en edificaciones tradicionales colombianas, durante los diferentes tipos de fenómenos naturales, son algunos de los temas que han trabajado los estudiantes del Doctorado en Ingeniería.

La Escuela de Ciencias Aplicadas e Ingeniería de la Universidad EAFIT cuenta con aproximadamente 120 profesores doctorados que están en capacidad de apoyar el proceso de formación de un estudiante de doctorado en el área en la que se especializan. 120 campos potenciales de profundización en investigación que pueden llevar a innovaciones que generen cambios tangibles para el futuro del planeta.

*    Escuela Ciencias Aplicadas Ingenieria 
*    Doctorado En Ingeniería 

## Registro calificado

Resolución​ de oficio 15217 del 18 de diciembre de 2019.

## Acreditación de alta calidad

Resolución 00​6100 del 12 de Junio de 2019​​. Vigencia: 8 años.

Duración

6 semestres

Lugar

Medellín

Horario

De acuerdo con el número de créditos por semestre

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 52668

Precio total del programa

$158.407.364

## Sobre el programa

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

El Centro de Laboratorios de la Universidad EAFIT consta de seis bloques con un área construida de aproximadamente 7.500 metros cuadrados. Cuenta actualmente con 43 espacios de trabajo, entre laboratorios y talleres, y administra aproximadamente 7.500 millones de pesos en equipos, dispositivos, herramientas y colecciones en áreas como computación científica, ciencias físicas, ciencias de la tierra y ciencias biológicas.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en EAFIT.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

En acuerdo con su asesor de tesis, el aspirante a doctorado puede manejar sus créditos de clases y pensar en intercambios internacionales para complementar su investigación.

Innovación y liderazgo

**Somos innovación en educación**

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de EAFIT. ​

**Cultivamos la investigación**

La Escuela de Ciencias Aplicadas e Ingeniería cuenta con 26 grupos de investigación, 10 de los cuales se encuentran en la categoría A1 del Ministerio de Ciencia, Tecnología e Innovación de Colombia, y 10 más en la categoría A de este escalafón.

También tiene 20 semilleros de investigación en ciencias matemáticas, físicas, de la tierra, y ciencias biológicas y bioprocesos.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

**Somos una puerta al mundo**

Tenemos convenios internacionales con más de 80 instituciones aliadas en 30 países del mundo. Desde 2019 hemos recibido a cientos de estudiantes del exterior y enviado a los nuestros al mundo. Además, contamos con programas de intercambio profesoral e investigativo. 

Tenemos una relación estrecha con la Brandeis University, Carlos III de Madrid y la Universidad Pompeu Fabra, la Universidad Católica de Lovaina y la Universidad La Salle Ramón Llull, para salidas profesionales, proyectos investigativos conjuntos y prácticas remuneradas.

Graduados

**​Fecha de grado:** 2021-2

**Título de tesis:** Wave Propagation in Generalized Continua

**Grupo de investigación:**Mecánica Aplicada

**Director de tesis:**Juan David Gómez Cataño

Resumen: The development in the field of architected materials have renewedthe interest in generalized continuum mechanics theories. We canidentify  popular  examples  in  the  area  of  phononic  crystals  andmetamaterials.  These  are  materials  that,  due  to  its  designedmicrostructure, present mechanical properties that are unexpectedat a macro-level, such as negative refraction, negative bulk modulusor negative effective-mass. From a wave propagation perspective,these materials are appealing since they present some phenomenasuch as dispersion, filtering, and directionality in some frequencyranges. From a physics point of view, these phenomena result fromthe interaction between the incident field with the microstructuralelements that produce local dispersion and diffraction. This workstudies two generalized continuum mechanics models. One of themis based in the inclusion of additional degrees of freedom to thematerial point, while the other considers higher-order gradients inthe deformation energy. Additionally, we present the finite elementformulation for these models in the context of periodic materials.This  is  done  through  the  Bloch-Floquet  theorem—that  allows  toconsider the periodicity of the material considering a single unit cell.

**​​Fecha de grado:** 2021-1

**Título de tesis:** Politiques d’exploitation et de maintenance intégrées pour l’optimisation économique, sociétale et environnementale des systèmes de transports urbains interconnectés

**Grupo de investigación:**Estudios de Mantenimiento Industrial (GEMI)

**Director de tesis:** Leonel Francisco Castañeda Heredia

**Resumen:** Tesis en cotutela con Université de Lorraine

**​Fecha de grado:** 2021-1

**Título de tesis:** Improving DFT-based approaches to study CO2 electroreduction on transition metals

**Grupo de investigación:** Desarrollo y Diseño de Procesos

**Director de tesis:** Santiago Builes Toro

**Resumen:** The industrial-scale conversion of electricity obtained from renewable sources is crucial to achieve an economy based on renewable energy. In that scenario, the electrochemical reduction of CO2, offers the possibility of producing some of the most demanded fuels and chemicals in a sustainable way. However, its efficient implementation on industrial scale is limited by factors as the high energy requirements for the product formation, the low selectivity and efficiency of electrolyzers, and the long-term deactivation of the catalysts. Understanding the many aspects that influence the reaction behavior is a challenging task because, apart from solvent and electrolyte effects, there are multiple intermediates, pathways, and products possible under similar operating conditions. In the recent decades this research field has been highly active in theory and experiments, and many studies have focused on finding the main factors that enhance the reaction performance. In this thesis, the electrochemical CO2 reduction is studied using state-of-the-art density functional theory (DFT) simulations, incorporating solvation effects as a crucial factor for improving thermodynamic predictions. To this end, a systematic micro-solvation method was developed to determine the number of hydrogen-bonded water molecules in the first solvation shell and the energetic stabilization granted by those hydrogen bonds. The reduction of CO2 to CO, CH4 and CH3OH on Cu, was considered to test this method, finding very good agreement with experiments without the need to include calculations of reaction kinetics. The estimation of solvation contributions for the CO2 reduction to CO has been extended to other transition metals such as Ag, Au, and Zn, finding significant variations between solvation corrections for the same adsorbates on different metals and finding very good agreement with experimental results. The increase in accuracy of the predictions make possible the development of a semiempirical method to explain the deactivation evidenced experimentally on Cu electrodes during CO2RR to CH4.

The industrial-scale conversion of electricity obtained from renewable sources is crucial to achieve an economy based on renewable energy. In that scenario, the electrochemical reduction of CO2, offers the possibility of producing some of the most demanded fuels and chemicals in a sustainable way. However, its efficient implementation on industrial scale is limited by factors as the high energy requirements for the product formation, the low selectivity and efficiency of electrolyzers, and the long-term deactivation of the catalysts. Understanding the many aspects that influence the reaction behavior is a challenging task because, apart from solvent and electrolyte effects, there are multiple intermediates, pathways, and products possible under similar operating conditions. In the recent decades this research field has been highly active in theory and experiments, and many studies have focused on finding the main factors that enhance the reaction performance. In this thesis, the electrochemical CO2 reduction is studied using state-of-the-art density functional theory (DFT) simulations, incorporating solvation effects as a crucial factor for improving thermodynamic predictions. To this end, a systematic micro-solvation method was developed to determine the number of hydrogen-bonded water molecules in the first solvation shell and the energetic stabilization granted by those hydrogen bonds. The reduction of CO2 to CO, CH4 and CH3OH on Cu, was considered to test this method, finding very good agreement with experiments without the need to include calculations of reaction kinetics. The estimation of solvation contributions for the CO2 reduction to CO has been extended to other transition metals such as Ag, Au, and Zn, finding significant variations between solvation corrections for the same adsorbates on different metals and finding very good agreement with experimental results. The increase in accuracy of the predictions make possible the development of a semiempirical method to explain the deactivation evidenced experimentally on Cu electrodes during CO2RR to CH4.

**Fecha de grado:** 2020-2

**Título de tesis:** Freeze casted porous ceramics​

**Grupo de investigación:** Materiales de Ingeniería

**Director de tesis:** Édgar Alexander Ossa Henao

​

**Resumen:** Scientists have explored different manufacturing methods aiming at obtaining synthetic materials with controlled porosity, among them, Freeze Casting allows a control of the pore characteristics formed within the material by setting process variables like type of medium, particle size, solid content, inclusion of additives, freezing rate, etc. Despite of all the knowledge obtained about freeze casting, there still remain some questions to solve regarding processing-structure relationships, specifically the relations between cooling patterns during freezing and physical characteristics of the final material. The aim of this doctoral work is to understand the relations between cooling patterns during freezing and the structure at the macro and micro levels of the final freeze casted part. The current work comprises the development of a heat transfer model to efficiently and reliably predict the temperature evolution during freezing. In this way, it will be possible to recognize which are the process variables affecting the final pore morphology. The results of this work improved the fundamental knowledge of the process, serving as a tool to predict and control the microstructure obtained in the Freeze Casting process. The problem definition and goals of this work are presented in chapter 1. A brief description of the main literature on freeze casting is presented in chapter 2. The development of a numerical model that calculates the temperature distribution within the experiment domain was carried out in chapter 3. In chapter 4, an alumina tile was produced by freeze casting process in order to test the freezing device, coloidal suspension characteristics and sintering temperature of the sample. Additionally, an analytical model was proposed for predicting the thermal conductivity of the material. Chapter 5 evaluates the effect of solid content and freezing temperature on pore morphology and evaluates how these variables affect the temperature distribution within the experiment domain. Chapter 6 compares the steady solution of the numerical model and the pore morphology obtained experimentally under different process parameters. Finally, conclusions and future work for the study are presented in chapter 7.

**Fecha de grado:** 2020-2

**Título de Tesis:** Insertion of random spaces in time domain for frequency hopping sequences for RF systems

**Grupo de investigación:** Electromagnetismo Aplicado (GEMA)

**Director de tesis:** Jose Ignacio Marulanda Bernal

**Resumen:** FFH es un método de acceso al canal con amplias aplicaciones pasadas y presentes, dentro de este método los códigos ortogonales usados en SFH-CDMA son de especial interés en amplias áreas de la tecnología. El presente trabajo implementa códigos ortogonales un coin-cidentes (1dOC) con restricciones en componentes espectrales adyacentes para el diseño de detectores auto correlacionados en RF que usan arreglos de sensores planos. La inclusión de retrasos temporales entre resonadores adyacentes es un método que permite disminuir la interferencia entre los usuarios (MAI), en contraposición a la disminución de la velocidad de transmisión y finalmente el ancho de banda del protocolo. La selección aleatoria de re-trasos entre símbolos adyacentes reduce los máximos en la correlación cruzada, aumentando el rango dinámico del detector asíncrono y por ende el número de usuarios que comparten el canal de comunicaciones.

Improvements over the communications protocols are always a continuous research. Fast Frequency Hopping is an important method still in use and orthogonal codes used in SFH-CDMA are the special interest in several areas of technology. This research uses one coincident orthogonal code with restrictive adjacent spectral distance for the design of RF correlation detectors based on planar resonators arrays. Inclusion of uniform time delays sections between adjacent resonators is a well-known method to improve the MAI, at expenses of decrease the data rate and finally the bandwidth of protocol. Another strategy is selecting random delays between symbols in the way of adjacent peaks in cross correlation function vanishes, improving the dynamic range of asynchronous detector and accordingly the user number sharing the channel of communications.

**Fecha de grado:** 2020-2

**Título de tesis:** Order Truncated Imaginary Algebra for Computation of Multivariable High-order Derivatives in Finite Element Analysis

**Grupo de investigación:**Mecánica Aplicada

**Director de tesis:** Manuel Julio García Ruiz

**Resumen:** Computation  of  sensitivities  in  engineering  problems  has become a necessity in many areas, including mechanical, chemical and biomedical engineering. Recently, the use of hypercomplex  algebras,  like  multicomplex  and  multidual numbers, has increased in the context of derivative computation as they are machine error accurate and easy to implement. However, current hypercomplex implementations suffer from a doubling  process  where  the  amount  data  required  for  a computation doubles each time a new order of derivative is required. In this work, Cayley-Dickson algebras like quaternions and octonions were used as a first step to optimize computation of multiple first order derivatives, in finite element analyses. While significant performance improvements were achieved, steps toward a more efficient algebra were found. In this dissertation a new hypercomplex algebra named Order Truncated Imaginary (OTI) numbers is proposed to tackle the excessive growth of current algebras when computing high-order  derivatives  of  multivariable  functions.  The  algebra truncates imaginary directions whose order exceeds a specified value 𝑛. As a consequence, when a function is evaluated using a particular OTI number, the result is another OTI number that contains all derivatives up to order 𝑛within its imaginary directions.  The  OTI  Finite  Element  Method  (OTIFEM)  is proposed in order to integrate OTI capabilities into Finite Element analysis. This allows computation of high order multivariable derivatives efficiently. The key ingredient to this integration is the developed OTI matrix form, that seamlessly integrate the OTI numbers with real-algebra linear algebra procedures. Computation of up to 30th order derivatives were performed in heat transfer, linear elasticity and fluid dynamics analyses and were used to generate reduced order modelsthat approximated the finite element solutions. Results show that derivatives  with  respect  to  shape,  material  and  loading parameters are accurate, and can be computed effortlessly and efficiently; and higher truncation orders increase the region of validity of the reduced models obtained with OTIFEM solutions.

**Fecha de grado:** 2020-1

**Título de tesis:** Impact tolerant bioinspired materials.

**Grupo de investigación:** Materiales de Ingeniería

**Director de tesis:** Édgar Alexander Ossa Henao

**Resumen:** En aplicaciones como equipo deportivo o blindaje personal, hay una demanda creciente de materiales livianos, flexibles y con capacidad de absorber energía de impacto. Esta combinación de requerimientos es generalmente atípica en materiales de ingeniería, sin embargo, la naturaleza ha logrado superar esta dicotomía a través de procesos evolutivos que han tomado miles de millones de años. Este trabajo describe algunos de los principios funcionales que subyacen el extraordinario desempeño de los sistemas de protección natural, incluyéndolos en la fabricación de materiales resistentes al impacto. Notablemente, los materiales bioinspirados resultantes exhiben un aumento significativo en la protección y la flexibilidad con un mínimo de aumento en el costo y el peso. Por lo tanto, se visiona que los materiales bioinspirados descritos aquí pueden implementarse para desarrollar la próxima generación de materiales de alto rendimiento resistentes al impacto.

In highly demanding applications, such as sports protective gear and personal body armor, there is a growing demand for lightweight materials able to absorb impact energy while being flexible to allow easy movement to the user. These requirements are generally challenging for typical engineered materials since increased mechanical strength is usually associated with reduced flexibility and increased weight. Fortunately, this dichotomy has been successfully surpassed by natural armor through millions of years of evolution. Through biomimetics, this dissertation sought to introduce the functional principles of segmented natural armor into synthetic devices obtaining a family of cost-efficient materials with enhanced protection and flexibility. Remarkably, these bioinspired materials exhibited a minimum increase of weight enabling its implementation in personal protection applications.

**Fecha de grado:** 2020-1

**Título de tesis:** Compendium of publications on: Differential operators on manifolds for CAD/CAM/CAE and computer graphics.

**Grupo de investigación:** Laboratorio CAD/CAM/CAE

**​**

**Director de tesis:** Óscar Eduardo Ruiz Salguero

**Resumen:** This Doctoral Thesis develops novel articulations of Differential Operators on Manifolds for applications on Computer Aided Design, Manufacture and Computer Graphics, as follows: (1) Mesh Parameterization and Segmentation. Development and application of Laplace-Beltrami, Hessian, Geodesic and Curvature operators for topology and geometry – driven segmentations and parameterizations of 2-manifold triangular meshes. Applications in Reverse Engineering, Manufacturing and Medicine. (2) Computing of Laser-driven Temperature Maps in thin plates. Spectral domain - based analytic solutions of the transient, non-homogeneous heat equation for simulation of temperature maps in multi-laser heated thin plates, modeled as 2-manifolds plus thickness. (3) Real-time estimation of dimensional compliance of hot out-of-forge workpieces. A Special Orthogonal SO(3) transformation between 2-manifolds is found, which enables a distance operator between 2-manifolds in R^3 (or m-manifolds in R^n). This process instruments the real-time assessment of dimensional compliance of hot workpieces, in the factory floor shop. (4) Slicing or Level-Set computation for 2-manifold triangular meshes in Additive Manufacturing. Development of a classification of non-degenerate (i.e. non-singular Hessian) and degenerate (i.e. singular Hessian) critical points of non-Morse functions on 2-manifold objects, followed by computation of level sets for Additive Manufacturing. Most of the aforementioned contributions have been screened and accepted by the international scientific community (and published). Non-published material corresponds to confidential developments which are commercially exploited by the sponsors and therefore banned from dissemination.

**​​Fecha de grado:**2019-2

**Título de tesis:** Wave propagation in 2D elastic periodic materials: Theorical and computational analysis.

**Grupo de investigación:** Mecánica Aplicada

**​**

**Director de tesis:**Juan David Gómez Cataño

**Resumen:** During the past 20 years the material science community has seen a tremendous growth in the development of metamaterials. These correspond to man-made designed materials which, by virtue of its micro-structure, exhibit exotic effective properties and apparently not available in nature. The common feature, and at the heart of a metamaterial design, is the spatial repetition of a motif which eventually controls its effective behavior. Such spatial periodicity immediately brings Bloch’s theorem from solid state physics as the fundamental analysis tool. The application of this theorem allows, in a very economic way, the identification of the potential wave propagation modes and directional behavior of the material at the macro-scale. Unfortunately, the false power behind modern numerical methods has promoted an indiscriminate use of computational techniques in the study of periodic materials thus slowing down the development of new designs as new and more difficult challenges arise. This work reviews the fundamental theoretical aspects of Bloch analysis, and with the aid of in-house numerical tools, develops conceptual understanding regarding the response of periodic cellular materials in order to facilitate its future application in emerging fields. To show the effectiveness behind this rational approach these concepts are applied in the study of a novel multi-stable periodic material available in the literature. The work concludes with some ideas, rooted in the simple beam theory from strength of materials which are intended to pave the way to the future study of wave propagation in periodic materials.

**​Fecha de grado:** 2019-2

**Título de tesis:**On efficient methods for sensitivity analysis of FEM problems using hypercomplex numbers.

**Grupo de investigación:** Mecánica Aplicada

​

**Director de tesis:** Manuel Julio García Ruiz

**Resumen:** Ensitivity analysis plays a critical role in numerical optimization and reliability analysis. It determines how the variation of an independent  variable  affects  the  overall  performance  or  a dependent variable of a computational model. The complex finite element method, ZFEM, is one of the simplest first-order methods for sensitivity analysis of real-valued FEM problems. A small imaginary perturbation is added to the independent variable, and the FEM discrete system is obtained using complex variables and functions. Once the system is solved, the sensitivity is obtained from the imaginary part of the state variable.The high-order generalization of ZFEM, the hypercomplex finite element  method,  has  limitations  that  hinder  its  widespread adoption. First, hypercomplex algebras, such as multicomplex and multidual, are not usually included in programming languages. Its implementation requires the use of efficient third-party or in-house object-oriented libraries. Second, standard linear algebra libraries are not compatible with the hypercomplex systems of equations. The conversion of these systems to real-valued involves the use of duplicate information of the real and imaginary parts that causes a considerable increase in memory usage and runtime relative to the original FEM solution. This doctoral work addresses the limitations of the hypercomplex finite element method to improve its ease of implementation, memory usage, and efficiency.This dissertation addresses these limitations in different ways. i) A unified  hypercomplex  library  for  high  order  derivatives  was developed. ii) A local strategy to compute the sensitivities of a functional was developed. The concept was applied to calculate the energy release rate. iii) A general block matrix decomposition of the hypercomplex system of equations to reduce the redundancy in variables and solution times was developed.The achievements presented in this dissertation include an easy to use library that allows an easy and efficient implementation of ZFEM from existing Python or Fortran FEM codes, a local strategy for the computation of the strain energy release rate using ZFEM that is as accurate and efficient as the state-of-the-art methodology but easier to implement, and a solution method for ZFEM thatreduces the time to compute first-order derivatives to 5-20 % of the solution of the traditional FEM, and 4th order derivatives in less than 2.5 timesthe solution of the traditional FEM, using at most 20% of additional memory.

**Fecha de grado:** 2019-2

**Título de tesis:** Desarrollo de un proceso continuo para medicamentos antiinflamatorios con ingredientes activos de baja solubilidad que garanticen mayor eficacia y mejor solubilidad en excipientes poliméricos.

**Grupo de investigación:**Grupo de Investigación Aplicada en Polímeros (ICIPC)

​

**Director de tesis:** María del Pilar Noriega Escobar

**Resumen:** La disolución de un ingrediente activo farmacéutico (API por sus siglas en inglés: Active Pharmaceutical Ingredient) en un fundido polimérico juega un papel muy importante en el diseño, desarrollo y manufactura de medicamentos que usan polímeros como excipientes. La disolución del API es difícil de predecir, sin embargo, la comprensión de dicho fenómeno es esencial para el diseño de equipos de procesamiento, por ejemplo, la determinación de las condiciones de operación en la extrusión (temperatura, velocidad de rotación de los husillos, configuración o geometría de los husillos, factor de llenado de la extrusora, entre otras) y la caracterización de las propiedades fisicoquímicas de los materiales necesaria para la selección de los sistemas de API-excipientes poliméricos. Los parámetros mencionados son importantes porque determinan la ventana de operación del proceso, como extrusión farmacéutica o extrusión por fusión en caliente (HME por sus siglas en inglés: Hot Melt Extrusion), proceso que ha crecido en la industria farmacéutica y de la salud, ya que puede ser aplicado para obtener diferentes perfiles de disolución de medicamentos [1], incrementar la biodisponibilidad del API [2], operar en modo continuo sin el uso de solventes y poder ser implementado para el desarrollo de diferentes sistemas de liberación de fármacos, tales como, los pellets, gránulos, tabletas, cápsulas blandas y duras, insertos oftálmicos, supositorios, endoprótesis vasculares (stents), y parches transdérmicos y transmucosos [3] [4]. HME puede ser empleado para el desarrollo de nuevos medicamentos con biodisponibilidad mejorada, ya que incrementa la solubilidad de los ingredientes activos poco solubles en agua, al disolverlos en excipientes poliméricos solubles en agua o hidrofílicos, en una combinación de excipientes poliméricos hidrofílicos e hidrofóbicos, o en excipientes poliméricos anfifílicos. Sin embargo, la aplicación de HME está limitada a dos problemas técnicos: (1) el API o los excipientes poliméricos pueden degradarse a las altas temperaturas de procesamiento de los polímeros. Para evitar este problema y obtener una dispersión sólida homogénea y estable, el proceso de HME debe ser llevado a cabo bajo condiciones de extrusión mejoradas, (la temperatura de proceso, configuración o geometría de los husillos, velocidad de rotación de los husillos, entre otras) para evitar la degradación del API o excipiente polimérico y lograr la disolución del API en el excipiente polimérico, y (2) la estabilidad fisicoquímica del extruido durante su vida útil. El objetivo general de la investigación fue desarrollar un proceso continuo de extrusión farmacéutica para un medicamento antiinflamatorio, con un ingrediente activo de baja solubilidad, que garantizara una mayor eficacia in vitro del medicamento y una mejor solubilidad del ingrediente activo en excipientes poliméricos. Con este fin, la pregunta de investigación fue ¿Cómo se afecta la disolución de un ingrediente activo antiinflamatorio de baja solubilidad con dos excipientes poliméricos, al variar la configuración de los husillos y los parámetros de procesamiento, de tal manera que se garantice una mayor eficacia in vitro del medicamento y una mejor solubilidad del ingrediente activo en los excipientes? Se implementó una metodología por etapas, principalmente cuantitativa, así como de método científico para responder a la pregunta de investigación. En cada etapa se usaron técnicas de caracterización y se eliminaron muestras que no cumplieron los criterios establecidos de cada etapa. Para las formulaciones farmacéuticas, se empleó el ingrediente activo antiinflamatorio, Ketoprofeno (KTO), y una combinación de Soluplus® y Kollidon® SR como excipientes poliméricos, se procesaron por medio de una extrusora doble husillo, Leistritz Nano 16, siguiendo un diseño de experimentos (DoE) en el que se determinaron 3 temperaturas de masa fundida, tres velocidades de rotación de los husillos, y tres factores de llenado. El DoE se corrió con dos configuraciones de los husillos. Las muestras se caracterizaron por Prueba de Película Delgada o Film Casting, Calorimetría Diferencia de Barrido (DSC), Análisis Termogravimétrico (TGA), Microscopía Óptica y de Luz Polarizada, Microscopía de Placa Caliente, Difracción de Rayos X (XRD), Microscopía Electrónica de Barrido (SEM), Cromatografía Líquida de Alta Eficacia (HPLC), y se determinaron los Perfiles de Disolución siguiendo los parámetros de la Monografía USP 41 específica de KTO. Como técnica de verificación se usó Resonancia Magnética Nuclear en estado sólido (ss-NMR). Los resultados de DSC y XRD mostraron una solución sólida amorfa, con una sola temperatura de transición vítrea (Tg) alrededor de los 33°C. La solución sólida amorfa indica que el KTO se encuentra molecularmente disperso en la matriz polimérica de Soluplus® y Kollidon® SR y que se encuentra en estado amorfo. La caracterización por perfil de disolución mostró una liberación extendida de KTO donde se cumplió con los rangos establecidos en la Monografía USP 41: entre el 10 y el 25% en la primera hora, entre el 55 y 80% en la cuarta hora y más del 80% deliberación en la octava hora. La caracterización por ss-NMR indicó que el KTO podría interactuar con los excipientes poliméricos por medio de puentes de hidrógeno y fuerzas de Van der Waals. Las fuerzas de Van der Waals podrían originarse entre el grupo metilo de KTO, cargado parcialmente positivo, con moléculas cargadas parcialmente negativas de los excipientes poliméricos. El KTO también podría interactuar con los excipientes poliméricos por medio del grupo carboxilo creando puentes de hidrógeno entre el OH de KTO con un oxígeno de los excipientes, o entre el oxígeno del KTO y un grupo OH de los excipientes poliméricos. Adicionalmente, se realizó un análisis estadístico para determinar cómo las condiciones de procesamiento afectaban el perfil de liberación de KTO, donde se encontró una ventana óptima de procesamiento para cada configuración de husillo. Se concluyó que HME es la tecnología adecuada para ser utilizada con excipientes poliméricos hidrofílicos, hidrofóbicos y anfifílicos para el procesamiento de medicamentos de liberación extendida de KTO, de tal manera que se lograra una mayor eficacia in vitro del medicamento y una mejor solubilidad del API en los excipientes poliméricos.

**Fecha de grado:** 2019-2

**Título de tesis:** Development of electrospun Polyimide membranes for oil-water separation

**Grupo de investigación:** Ingeniería de Diseño (GRID)

​

**Director de tesis:** Mónica Lucía Álvarez Láinez

**Resumen:**The main objective of this study was to develop hydrophobic and oleophilic electrospun PI membranes with a good mechanical performance reliable for oil-water separation applications. Four different types of PIs were evaluated to determine the influence of their chemical structure on the electrospinning process parameters and the morphological and hydrophobic characteristics of the electrospun membranes.

**Fecha de grado:** 2019-2

**Título de tesis:** Methodological approach for interactive preliminary-design

**Grupo de investigación:**Ingeniería de Diseño (GRID)

​

**Director de tesis:** Ricardo Mejía Gutiérrez

**Resumen:** Los procesos de toma de decisiones en el diseño preliminar están relacionados con la priorización de las especificaciones y variables de diseño para desarrollar soluciones que estén más cerca de los requisitos del producto. Sin embargo, el tamaño de la información suele ser grande y difícil de entender. Mantener un seguimiento de la lista de variables dependientes, variables independientes y objetivos de diseño es una tarea difícil, con un posible reprocesamiento y pérdida de tiempo, especialmente cuando es necesario identificar como una modificación en una variable podría afectar el rendimiento del producto. El objetivo de esta tesis es generar un método interactivo que pueda obtener un trade-off entre la deseabilidad de los objetivos. Este proceso de trade-off se apoya en dos aspectos: i) el desarrollo de un modelo de trazabilidad, que gestiona la información desde los requerimientos de entrada (en el campo lingüístico) hasta la definición de las variables (en el campo de los números reales). ii) un marco de mejora del diseño, basado en la definición de las funciones de deseabilidad de los objetivos de diseño: la propagación de estas funciones hasta que las variables de diseño permiten calcular las combinaciones de valores que maximizan la deseabilidad global de la solución. El resultado de ésta tesis pretende desarrollarse en entornos de diseño multidisciplinario, enfrentándose a problemas convexos y no convexos.

Preliminary design decision-making processes are related to the prioritisation of design specifications and variables in order to develop solutions that are closer to product’s requirements. Nevertheless, the size of the information is often large and hard to understand: keeping in track the list of dependent variables, independent variables and design objectives is a challenging task, with potentially reprocessing and loss of time, especially when it is necessary to identify how a modification on a variable might impact the performance of the product. The objective of this thesis is to generate an interactive method that can obtain a trade-off among the design objectives desirability. This trade-off process is supported on two aspects: i) the development of a traceability model, managing information from the input requirements (in the linguistic field) up to the variables definition (in the real numbers field). ii) A design amelioration framework, based on the definition of the design objectives desirability functions; the propagation of these functions until design variables allow calculating the combinations of values that maximise the global desirability of the solution. The goal of this trade-off process is to perform on a multidisciplinary design environment, facing convex and non-convex problems as well. The proposal of the thesis can be understood as a hybrid approach, including an interactive exploratory part and an inductive interactive part. On the exploratory part, designers can modify the variables using visual tools in order to understand in real time how these modifications have an impact on the design objectives. On the inductive part, designers make use a proposed pre-sizing method that calculates the values of the variables that maximise the desirability of the design objectives.

**​Fecha de grado:** 2019-1

**Título de tesis:** On object recognition for industrial augmented reality

**Grupo de investigación:** Ingeniería de Diseño (GRID)

​

**Director de tesis:** Gilberto Osorio Gómez

**Resumen:** Tesis en cotutela con Politecnico di Milano

**​Fecha de grado:** 2018-1

**Título de tesis:** Development of a mathematical model for redesing and optimization of a solar race car and its competition strategy.

**Grupo de investigación:** Ingeniería de Diseño (GRID)

​

**Director de tesis:** Gilberto Osorio Gómez

**Resumen:** This thesis describes the energy management strategy for racing solar cars, the racing strategy is treated as an optimal control problem with random variables and uncertain predictions. A computational model is developed for estimating the vehicle performance under speciﬁc circumstances. Two evolutionary heuristic optimization methods are implemented and tested for this case, their eﬀectiveness, convergence and eﬃciency is measured and compared to exhaustive search approaches. The dependency on solar radiation is validated using the computational model with diﬀerent test cases. In order to reduce the uncertainties on the solar radiation estimation, satellite images are used as inputs to image processing and machine learning techniques, their eﬃcacy is compared. Finally, a validation case is executed and diﬀerent scenarios are evaluated with the inclusion of the proposed methods, the experimental performance of a vehicle obtained using the strategy in the World Solar Challenge 2015 is exposed and compared to the predicted results from the simulation.

**​Fecha de grado:** 2018-2

**Título de tesis:** TAG: Modelo teórico de valoración del nivel de ubicuidad de las funciones misionales de una Institución de Educación Superior (IES).

**Grupo de investigación:** I+D+I en TIC (GIDITIC)

**​**

**Director de tesis:** Juan Guillermo Lalinde Pulido

**Resumen:** Este documento presenta el proceso de investigación para la construcción de un modelo teórico que permite establecer el nivel de ubicuidad en los procesos que se desarrollan en el marco de las funciones misionales de una Institución de Educación Superior (IES), desde tres (3) dimensiones específicas: Tecnología (T), Aprendizaje (A) y Gestión (G) -- De ahí, el modelo que se presenta toma el nombre de “Modelo TAG” -- Para lograr este propósito se propuso realizar una combinación entre los fundamentos de la investigación documental y la revisión de los estudios descriptivos, en aras de construir una base de referentes teóricos y de medición que permitiese formular el modelo que se desarrolla en este documento -- Los principales resultados de esta investigación se relacionan con: i) Definición de las dimensiones de Tecnología, Aprendizaje y Gestión como soportes para la construcción de un modelo que permita valorar el nivel de ubicuidad en los procesos de una IES -- ii) Análisis y escogencia de categorías, propiedades e indicadores para valorar cada una de las dimensiones mencionadas -- iii) El modelo TAG propiamente dicho, compuesto por sus instrumentos y sistema de indicadores -- iv) La documentación del proceso investigativo -- v) La aplicación del modelo TAG en dos Instituciones de Educación Superior en Colombia -- vi) El modelo TAG como soporte para la construcción del modelo UbiTAG y su influencia en la generación de bases para la construcción de política pública local, en el municipio de Itagüí (Antioquia), tal como se evidencia en el acuerdo 010 del año 20151, del Concejo municipal de este ente territorial -- La presente disertación constituye una herramienta para diagnosticar, en general, los procesos de una IES desde las dimensiones de Tecnología, Aprendizaje y Gestión permitiendo a los tomadores de decisiones generar acciones que mejoren el desarrollo de sus funciones misionales

**​Fecha de grado:** 2018-2

**Título de tesis:** Processing and characterization of PEI/PBT and PEI/PBT/PTFE high performance polymer blends.

**Grupo de investigación:**Ingeniería de Diseño (GRID)

**​**

**Director de tesis:** Mónica Lucía Álvarez Láinez

**Resumen:** Polymer blending emerged as an attractive strategy to obtain new materials with tailored properties from already existing ones. It has focused mainly on the development of blends from commercial polymers. Fewer works have studied in depth the fabrication of blends from high-performance polymers, since fundamental studies in polymer-polymer interactions are not usually performed with these challenging materials. This work aim to study blends obtained from three high-performance polymers with good flammability characteristics: poly(ether imide) (PEI), poly(butylene terephthalate) (PBT) filled with a flame retardant compound, and poly(tetrafluoroethylene) (PTFE); and presents for the first time, the relationship between processing conditions, viscoelastic properties, interfacial tension, and composition with the morphology and final performance for this kind of systems. Two sets of blends, binary PEI/PBT and ternary (PEI/PBT)/PTFE blend, are prepared by melt processing in an internal mixer. A complete miscibility study is performed from thermal analysis using MDSC and DMA, accompanied by a theoretical approach of the interfacial tension by using the harmonic mean equation. In relation to ternary blends, phase’s interaction is predicted from the Harkin’s spreading coefficient model. Morphological study is contrasted to miscibility results and the distribution of blends constituents is evaluated by SEM and TEM analyses. As blends resulted being partially miscible, the use of selective extraction technique allows us to better evidence the PEI and PBT distribution in binary blends. To evaluate the mechanical performance, tensile tests are performed to Type V samples obtained by injection molding. The thermal stability is studied by TGA and DTG techniques, and flammability tests from a horizon tal burning tests according to the UL-94 standard. The first set of blends is obtained between PEI and PBT, which have notable differences in their processing characteristics. Previous works were found on PEI/PBT blends that mix simultaneously PEI and PBT phases by different solution and melt processing methods. In this work a novel two-step melt processing method to fabricate binary PEI/PBT blends in an internal mixer is proposed. The main processing parameters are defined after the thermal and rheological characterization of pure materials, to obtain binary PEI/PBT blends within the entire compo sition range using the same processing conditions. The second set of blends is obtained with the aim of modify the mechanical properties of PEI/PBT blends by adding PTFE concentrations of 5 wt%, 10 wt%, and 15 wt%. The same two-step melt processing method proposed for binary PEI/PBT blends is used for (PEI/PBT)/PTFE blends fabrication. It is found that PTFE must be added during step 1 in order to enhance phases’ integration during mixing. Ternary blends are obtained for PEI concentrations higher than 50 wt% for the same reason. A complete miscibility study provided information about the phases’ heterogeneity in both, binary and ternary blends. The binary PEI/PBT blends resulted being partially miscible depending on PEI composition, and two groups of blends are identified: PBT-rich blends and PEI-rich blends. Miscibility evaluation by MDSC and DMA reveals that PBT-rich blends are immiscible, since it is no noticed any shift in the glass transition temperatures (Tg) of the pure components. PEI-rich blends on the other hand, exhibit a significant displacements of Tg to higher temperatures suggesting miscibility between PEI and PBT. The study of miscibility in ternary blends, reveals that PTFE does not interfere with the miscibility behavior of PEI and PBT, since there are noticed the same thermal transitions as those for binary blends. Interfacial tension values reveal that all phases are highly immiscible for all possible polymer pairs, due to the no table differences between their polar components. Prediction of phase’s distribution in ternary blends by the spreading coefficient model, reveals there is favored the encapsulation of PTFE phase by PEI when PBT is the matrix. Morphological evaluation of binary PEI/PBT blends is in good agreement to blends microrheology theory proposed by Taylor and Grace. PBT-rich blends exhibit coarse droplets distribution of highly viscous PEI phase, with sub-inclusions of small droplets of low viscous PBT phase. By using the Soxhlet selective extraction technique together with SEM and TEM, it is presented new evidence on the morphological evolution of PBT-rich blends, and we noticed that PBT-rich and PEI-rich blends are separated by an intermediate cocontinuous morphology at even PEI and PBT compositions. PEI-rich blends on the other hand, exhibited tiny droplets of PBT (as small as 120 nm) bonded to PEI matrix through a fibrillar interface, and a new morphology denominated spore-like morphology is presented. In order to validate the addition of PTFE to the PEI phase during step 1 in ternary blends fabrication, we evaluate the morphology formed between PEI/PTFE blends. It is noticed that under these conditions it is favored the distribution of PTFE phase in two major fashions: well-embedded PTFE nano-sized droplets, and debonded PTFE spheres of 1.5 μm of average diameter. SEM and TEM analysis of ternary blends confirm the miscibility study results, and encapsulation of PTFE droplets by PEI phase in ternary blends when PBT is the matrix, is predicted by the spreading coefficient model. Mechanical, thermal, and flame resistance performance is strongly influenced by miscibility and the morphologies obtained in both, binary and ternary blends. The experimental results are discussed in terms of theoretical additivity approaches. In binary bends, the tensile modulus reveal a positive deviation from additivity, and even a synergic contribution is obtained for blends containing 50 wt% and 80 wt% of PEI. The yield strength on the other hand, is strongly affected by phase’s immiscibility and the interfacial adherence between constituents, and a combinatorial deviation from additivity is obtained: negative for PBT rich-blends and positive for PEI-rich blends. In addition, the elongation at break for all blends is compromised by the morphology of PBT-rich blends, and by the densification of PEI-rich blends. The blend with 50 wt% of PEI exhibits the best elongational at break result due to its co-continuous morpholo gy. PTFE phase does not affect PEI/PBT stiffness since any significant variation in tensile modulus values is observed. On the other hand, a progressive decrease in tensile strength with in creasing PTFE concentration caused by the low yielding strength characteristic of PTFE is noticed. The results of elongation at break show that PTFE addition decreases even more the ductility of binary PEI/PBT blends. However, surprising results are found when only 5 wt% of PTFE phase is added to the blends containing 80 wt% of PEI. It is noticed a considerable improve ment of blends ductility due to the highly crystalline PTFE phase inhibits the densification of PEI/PBT blends. On the contrary, PTFE improves substantially PEI/PBT blends thermal stability and flammability, since it enhances blends charring formation.

**Fecha de grado:** 2018-1

**Título de tesis:** Exploring the role of system operation modes in failure analysis in the context of first generation cyber-physical systems

**Grupo de investigación:** Ingeniería de Diseño (GRID)

​

**Director de tesis:** Ricardo Mejía Gutiérrez

**Resumen:** Typically, emerging system failures have a strong impact on the performance of industrial systems as well as on the efficiency of their operational and servicing processes. Being aware of these, maintenance and repair researchers have developed multiple failure detection and diagnosis techniques that allow early recognition of system or component failures and maintaining continuous system operation in a cost-effective way. However, these techniques have many deficiencies in the case of self-tuning first generation cyber-physical systems (1G-CPSs). The reason is that these systems compensate for the effects of emerging system failures until their resources are exhausted, and the compensatory actions not only mask the failures, but also make their recognition difficult. Late recognition of failures is however in contrast with the principles of preventive maintenance. Therefore, the promotion research concentrated on the issue of recognizing and forecasting failures under dynamic and adaptive behavior of 1G-CPSs.

CPSs are enabled to compensate for failure symptoms by changing their system operation modes (SOMs). It was also observed that transitions of SOMs reduce the reliability of a signal-based failure diagnosis. It was hypothesized that the frequency and the duration of the changes of the operational states of the 1G-CPS may be strong indicators of the failure emergence phenomenon and that investigation of SOMs facilitates early detection of failures. Therefore, the completed exploratory studies were aimed at exploring how the frequency and duration of transitions of SOMs can be brought into correlation with specific types of failures, and how they can be computed as measures of failure occurrence. The obtained results revealed that system failures tend to induce unusual system operation modes that can be used as basis for failure characterization, and even for failure forecasting. The empirical research made use of a cyber-physical greenhouse testbed to get experimental data and was completed by the development of computational model. A failure injection strategy was implemented in order to induce failure occurrence in a controlled manner. The proposed approach can be applied as a basis of forecasting system failures of 1G-CPSs, but additional research seems to be necessary.

**​Fecha de grado:** 2018-1

**Título de tesis:** Baccillus sp. strains and their inducible in vitro antagonism: A biochemical and molecular study

**Grupo de investigación:** Valeska Villegas Escobar

​

**Director de tesis:** María del Pilar Noriega Escobar

**Resumen:**Following the WHO urgent call for new antibiotics discovery, an induced antagonistic behavior, not previously observed in Bacillus sp. strains, has been characterized with biochemical, molecular and metabolomic studies. When growing on solid media, at a sub-inhibitory concentration of the colorimetric redox indicator triphenyl tetrazolium chloride (TTC), several species of the genus Bacillus (B. subtilis, B. pumilus, B. cereus, B. thurigiensis, B. megaterium, among others) produced large inhibition zones against the plant pathogen Ralstonia solanacearum EAP09 and moderate inhibition of other Gram-negative strains. During biochemical characterization assays, several traits of this inducible antagonism were revealed: other tetrazolium salts did not induce antagonistic activity; the addition of antioxidant compounds did not reduce the inducible antagonistic activity; siderophores, oxidative-stress derived substances and lipopeptides were not over produced when TTC was present in the medium; R. solanacearum sensitivity to antibiotics was not increased by the addition of TTC and the inducible activity was not dependent on the presence of the sensitive strain. Transcriptomic analysis through total RNA-sequencing and nano-String techniques, suggested that nitrogen metabolism was highly up regulated in B. subtilis NCIB 3610 strain growing in TTC supplemented media. Specifically, genes from the L-histidine biosynthetic pathway (hisB, hisD, hisI, hisF, hisH) and from the pyrimidine nucleotides de novo synthesis (pyrC and pyrP) and salvage and interconversion route (xpt), were upregulated 2 to 5 fold. These results strongly imply an increased production of nitrogenous compounds, as these two biosynthetic routes are themselves intimately related with amino acids metabolism. Metabolomics, through spectral networking analysis using UPLC-MS obtained data, followed by Global Natural Product Social Molecular Networking (GNPS) and Cytoscape bioinformatic treatment and analysis, revealed precursor ions which were uniquely produced and overproduced compounds in B. subtilis NCIB 3610 cells when TTC was present. These compounds were subjected to data mining in chemical databases, suggesting that the inducible compounds belong to chemical families of carbamates, imidazoles, pyrrolidines, pyrimidinediones and oligopeptides, all of them closely related to nucleotides, aminoacids and general nitrogen metabolism. Overall results support the hypothesis of active compounds being involved with these biosynthetic routes. Advances so far suggest that Bacillus cells reduction of TTC into triphenyl formazan (TPF) and its further accumulation inside the cells , induces the production of nitrogen derived compounds , either by activation of nitrogen metabolism biosynthetic pathways or by a biotransformation of TPF into derivatives. Once produced, the compounds are secreted into the medium and act as antimicr obials against other bacteria.

**​Fecha de grado:** 2017-1

**Título de tesis:** The mechanical behavior of dentin: importance of microstructure, chemical composition and aging.

**Grupo de investigación:** Materiales de Ingeniería

​

**Director de tesis:** Édgar Alexander Ossa Henao

**Resumen:** Dental fracture is one of the three most common forms of failure of restored teeth and the most common cause of tooth loss or extraction in elderly patients -- Previous investigations conducted on aging of hard tissues have identified that there is a considerable reduction in the mechanical properties (i.e. fracture toughness, fatigue and flexural resistance) of dentin with aging and that may predispose tooth fracture -- These declines in properties have been attributed to microstructural and chemical composition changes over time -- However, these aging processes have not been really quantified and related with the changes in mechanical properties -- Accordingly, the aim of this work is to evaluate the aging process of coronal dentin in terms of the evolution of microstructure, changes in chemical composition and mechanical properties from selected age groups (young and old donors) -- The changes in these properties were evaluated in three different regions (outer, middle and inner) in order to identify spatial variations within the crown -- A brief description of the main literature on composition, microstructure and mechanical behavior of dentin is presented in chapter 2 -- An extensive experimental study was carried out in chapter 3 to identify the changes in microstructure of dentin with aging by means of optical and electron microscopy; while changes in chemical composition were analyzed using Raman Spectroscopy to calculate the mineral-to-collagen ratio -- Changes in mechanical properties were measured using Vickers micro-hardness -- Chapter 4 describes the importance of tubule density to the fracture toughness of dentin for young and old donor’s groups -- An approach previously proposed to study the mechanical behavior of porous materials was used to model the fracture toughness of coronal dentin in terms of the tubule characteristics -- Results were then compared with published results from previous studies -- The time-dependent deformation response of dentin was analyzed via spherical indentation experiments at different indentation loads in Chapter 5 -- From the experimental observations was proposed a simple model to describe the time dependent deformation behavior of dentin -- This model was based on previously proposed theories for indentation of time dependent materials, showing that the effective strain rate of dentin depends on its chemical composition (i.e. mineral-to-collagen ratio) and microstructure (i.e. lumen area fraction) -- The descriptions of the model were compared with the experimental results showing good agreement -- The same model was validated with experimental results of aged dentin, finding a low change in the deformation response of dentin with aging, as presented in chapter 6 -- Finally, preliminary results made on the mechanical properties of dentin have shown that the microstructure of aged human dentin can vary depending on the ethnic background of the donor and that this quality is critically important to the mechanical properties of the tissue -- In chapter 7 preliminary results on the comparison between the microstructure, chemical composition and mechanical properties of Colombian, Chinese and American donors is presented -- Finally, conclusions for the study are presented in chapter 8.

**Fecha de grado:** 2017-1

**Título de tesis:** Environmental improvement of operating supply chains: a multi-objective approach for the cement industry.

**Grupo de investigación:** Gestión de Producción y Logística

​

**Director de tesis:** Mario César Vélez Gallego

**Resumen:** Nowadays companies worldwide face a growing pressure to reduce the environmental impact of their manufacturing activities -- However, the strategies used to achieve this goal are not clearly defined because of their conflicting relations with financial outcomes -- In parallel, globalization trends imply that as companies grow, usually through mergers and acquisitions, their supply chains become more complex -- The environmental improvement of these supply chains imply not only technical retrofit decisions aiming at adopting cleaner production technologies but also decisions regarding the structure of the supply chain itself -- Making these decisions becomes a difficult task because of the large number of variables involved, and the diversity of the interactions among them -- To tackle this problem, this research aims at providing a multi-objective solution approach for making technological retrofit decisions within an operating supply chain, so that both environmental and financial goals are best met -- The proposed solution approach is applied to the case of an operating cement supply chain in Colombia -- Several computational experiments were conducted, obtained results demonstrates that the proposed model is an e effective tool for multi-objective improvement decisions making, towards a more sustainable production process​.

**​​Fecha de grado:** 2016-2

**Título de tesis:** Aide à la décision en conception préliminaire par l'estimation des impacts environnementaux.

**Grupo de investigación:**Ingeniería de Diseño (GRID)

​

**Director de tesis:** Ricardo Mejía Gutiérrez

**Resumen:** "L'objectif de la thèse est le développement d'une méthode d'éco-conception et d'aide à la décision à parti r de l'estimation d’indicateurs environnementaux mais aussi d’autres indicateurs au stade de la conception préliminaire dans le développement de nouveaux produits.

**Fecha de grado:** 2016-1

**Título de tesis:** Handling Heterogeneity in Collaborative Networked Surgical Simulators.

**Grupo de investigación:** Ingeniería de Diseño (GRID)

​

**Director de tesis:** Helmuth Trefftz Gómez

**Resumen:** Stand-alone and networked surgical virtual reality based simulators have been proposed as means to train surgical skills with or without a supervisor nearby the student or trainee -- However, surgical skills teaching in medicine schools and hospitals is changing, requiring the development of new tools to focus on: (i) importance of mentors role, (ii) teamwork skills and (iii) remote training support -- For these reasons, a surgical simulator should not only allow the training involving a student and an instructor that are located remotely, but also the collaborative training of users adopting different medical roles during the training sesión -- Collaborative Networked Virtual Surgical Simulators (CNVSS) allow collaborative training of surgical procedures where remotely located users with different surgical roles can take part in the training session -- To provide successful training involving good collaborative performance, CNVSS should handle heterogeneity factors such as users’ machine capabilities and network conditions, among others -- Several systems for collaborative training of surgical procedures have been developed as research projects -- To the best of our knowledge none has focused on handling heterogeneity in CNVSS -- Handling heterogeneity in this type of collaborative sessions is important because not all remotely located users have homogeneous internet connections, nor the same interaction devices and displays, nor the same computational resources, among other factors -- Additionally, if heterogeneity is not handled properly, it will have an adverse impact on the performance of each user during the collaborative sesión -- In this document, the development of a context-aware architecture for collaborative networked virtual surgical simulators, in order to handle the heterogeneity involved in the collaboration session, is proposed -- To achieve this, the following main contributions are accomplished in this thesis: (i) Which and how infrastructure heterogeneity factors affect the collaboration of two users performing a virtual surgical procedure were determined and analyzed through a set of experiments involving users collaborating, (ii) a context-aware software architecture for a CNVSS was proposed and implemented -- The architecture handles heterogeneity factors affecting collaboration, applying various adaptation mechanisms and finally, (iii) A mechanism for handling heterogeneity factors involved in a CNVSS is described, implemented and validated in a set of testing scenarios.

**​Fecha de grado:** 2016-1

**Título de tesis:** Implementation of the Moving Particle Semi-implicit method to predict the drag resistance coefficient on 2D.

**Grupo de investigación:** Mecánica Aplicada

​

**Director de tesis:** Manuel Julio García Ruiz

​

**Resumen:** A dam break problem and the flow around a 2D submerged body on different scenarios were solved with the original Moving Particle Semi-implicit (MPS) method proposed by Koshizuka and Oka in 1996 -- The results of this study showed that although the original method reproduces the free surface of the fluid on the dam break computation, it can not accurately compute the pressure distribution over the submerged bodies -- It was found that the free surface was inaccurate when negative pressures were present in the particle domain -- Also, when modelling the interaction of a solid immersed in a fluid, the simulation exhibited stability issues and solid penetration -- Several modifications of the original MPS were studied, implemented and tested -- This thesis proposes a modified Moving Particle Semi-implicit (MPS)method for modelling immerse bodies in an free surface flow -- The MPS method is based on the prediction-correction calculation of the velocity field based on the Helmhotz-Hodge decomposition -- Initially the predicted velocity is calculated based on the viscous and external forces terms and then corrected by the gradient of the pressure which is obtained by the solution of the Poisson Pressure’s equation – This thesis shows how small variations in the source term of the Poisson Pressure’s equation can destabilise or stabilise simulations -- One of the main result of this research is an improved stability by means of a reformulation of the Poisson Pressure equation and the aid of relaxation factors -- Also, the pressure gradient was computed for non free surface particles only -- The results show that, although pressure fluctuations were still present, good results were obtained when compared the drag coefficient to the reported values in the literature.

**​Fecha de grado:** 2016-1

**Título de tesis:** Computational Geometry in Medical Applications.

**Grupo de investigación:** Laboratorio CAD/CAM/CAE

​

**Director de tesis:** Óscar Eduardo Ruiz Salguero

**Resumen:** This doctoral thesis develops novel techniques in Computational Geometry and applies them to Medical Imaging, Image-Guided Surgery and Motor Neurorehabilitation. In Medical Imaging, this Thesis contributes with: (a) optimization of parametric forms applicable to image segmentation and organic shape synthesis, and (b) simplification of topology and geometry of porous materials, which enables mechanical computations (previously intractable) while faithfully representing local pore geometry. In Image-Guided Surgery, this Thesis addresses surgical patient registration, including: (c) a robotic research platform for the controlled acquisition of intraoperative medical images, (d) intraoperative registration of Computer Tomography and Ultrasound medical images of the patient spine, and (e) homologated and public Ultrasound Image dataset with ground-truth to test 2D-3D or 3D-3D image registration algorithms. In Motor Neurorehabilitation this Thesis addresses the patient posture estimation in exoskeleton-based therapy. Its contributions include: (f) enhanced estimation of upper limb joint angles, significantly improving exoskeleton - based estimations, and (g) enhanced estimation of shoulder angles using low-cost marker-based optical systems along with the rehabilitation exoskeleton. All the aforementioned contributions have been submitted to the screening and critique of the international relevant scientific communities, achieving publication, homologation and/or favorable appraisal by experts. The developed systems, data sets and algorithms are currently applied in the National Hospital for Spinal Cord Injury (Toledo, Spain) and Surgical Robotics Project ORXXI (Basque Country, Spain).

**​Fecha de grado:** 2015-2

**Título de tesis:** Computational Study of Cell Mobility and Transport Phenomena through Textile Vascular Grafts using Multi-scale Approach.

**Grupo de investigación:** Mecánica Aplicada

**Director de tesis:** Manuel Julio García Ruiz

**Resumen:** Textile vascular grafts are biomedical devices that serve as partial replacement of damaged arterial vessels, prevent aneurysms rupture and restore normal blood flow -- It is believed that the success of a textile vascular graft, in the healing process after implantation, is due to the porous micro-structure of the wall -- Among the key properties that take part in the tissue repair process are the type of fabric and degree of porosity and permeability, defining the ability of a well-controlled environment for the neovascularization, nutrient supply, and cellular transport -- Although the transport of fluids through textiles is of great technical interest in biomedical applications, little is known about predicting the micro-flow pattern and the transport and deposition of individual platelets, related with the graft occlusion -- Often, this information is difficult to obtain experimentally both in vivo and in vitro, representing a great deal of research efforts -- The aim of this work is to investigate how the type of fabric, permeability and porosity affect both the local fluid dynamics at several scales and the fluid-particle interaction among platelets in textile grafts with an anastomosis of end-to-end configuration -- Two types of samples were analyzed: woven and electrospun, this last one has been manufactured -- This study involves both experimental and computational tests -- The experimental tests were performed to characterize the permeability and porosity under static conditions -- The computational tests are based on a multiscale approach where the fluid flow was solved with the Finite Element Method and the discrete particles were solved with the Molecular Dynamic Method -- The fluid-particle interaction was accomplished in one-, two-, and four-ways, where the blood was considered as a suspension of platelets in plasma -- The textile wall was considered as a porous media with two scales of length: straight tubular structure with porous walls for the macro-domain and representative unit cells of fabric for the micro-domain. Additionally, it presents the implementation of a numerical case that includes one of the main applications of textile vascular grafts to repair Abdominal Aortic Aneurysms (AAA) -- The results have shown that the type of fabric in textile vascular grafts and the degree of porosity and permeability affect the local fluid dynamics and the level of penetration of platelet particles through the graft wall at several length scales, thus indicating their importance as design parameters -- It was found that the permeability is strongly depends on the micro-structure of the fabric, changing the local fluid dynamics and the time of residence of platelets inside the wall -- Moreover, the porous walls cause deviations from Poiseuille flow due to leakage flow through the wall from a macroscopic viewpoint -- Lastly, it was possible to observe that the textile wall with different porosities, acting like a barrier between the blood and an aneurysmal zone, affects the flow pattern, the number of platelets adhered to the artificial surface and the time of residence of platelets into the aneurysmal zone -- In conclusion, predicting the flow pattern and the mobility of blood cells through the textile wall before the graft is manufactured, the development of new textile grafts can be improved

**Fecha de grado:** 2014-2

**Título de tesis:** Effects of topography on 3D seismic ground motion simulation with an application to the Valley of Aburrá in Antioquia, Colombia

**Grupo de investigación:** Mecánica Aplicada

​

**Director de tesis:**Juan Diego Jaramillo

**Resumen:** This dissertation presents a numerical scheme based upon the finite element framework for the numerical modeling of earthquake-induced ground motion in the presence of realistic topographic variations of the Earth’s crust -- We show that by adopting a non-conforming meshing scheme for the numerical representation of the surficial topography we can obtain very accurate representations of earthquake induced ground motion in mountainous regions -- From the computational point of view, our methodology proves to be accurate, efficient, and more importantly, it allows us to preserve the salient features of multi-resolution cubic finite elements -- We implemented the non-conforming scheme for the treatment of realistic topographies into Hercules, the octree-based finite-element earthquake simulator developed by the Quake Group at Carnegie Mellon University -- We tested the benefits of the strategy by benchmarking its results against reference examples, and by means of convergence analyses -- Our qualitative and quantitative comparisons showed an excellent agreement between results -- Moreover, this agreement was obtained using the same mesh refinement as in traditional flat-free simulations -- Our approach was tested under realistic conditions by conducting a comprehensive set of deterministic 3D ground motion numerical simulations in an earthquake-prone region exhibiting moderate-to-strong surficial irregularities known as the Aburr´a Valley in Antioquia-Colombia -- We proposed a 50 50 25 km3 volume to perform our simulations, and four Mw = 5 rupture scenarios along a segment of the Romeral fault; a significant source of seismic activity of Colombia -- We created and used the Initial Velocity Model of the Aburr´a Valley region (IVM-AbV) which takes geology as a proxy for shear-wave velocity -- Each earthquake model was simulated using three different models: (i) realistic 3D structure with realistic topography; (ii) realistic 3D structure without topography; and (iii) homogeneous half space with realistic topography. Our results show how topographic irregularities greatly modify the ground response -- In particular, they highlight the importance of the combined interaction between source-effects, focusing, soft-soil conditions, and 3D topography -- We provide quantitative evidence of this interaction and show that topographic amplification factors at some locations can be as high as 500 percent, while some other areas experience reductions -- These are smaller than the amplifications, on the order of up to 100 percent.

**Fecha de grado:** 2013-1

**Título de tesis:** Geometry and topology extraction and visualization from scalar and vector fields.

**Grupo de investigación:** Laboratorio CAD/CAM/CAE

**​**

**Director de tesis:**Óscar Eduardo Ruiz Salguero

**Resumen:** This doctoral work contributes in several major aspects: (1) Extraction of geometrical and topological information of 1- and 2-manifolds present in static and video imaging. This endeavor includes several variants of Marching Cubes algorithm, including enhanced precision iso-surfaces for non-negative scalar fields. (2) Hybrid visualization of scalar and vector fields, along with simplex geometry and topology, underlying in medical, geo-sciences and entertainment data. (3) Optimization of parallel visualization algorithms and usage of texture - optimized hardware as a means of efficient scientific computation and visualization. (4) Definition of WEB ISOstandards for interactive homogeneous visualization of simplex, scalar and vector field data in mobile devices (smart cell phones, pads, tablets, etc.). (5) A novel technique for volume rendering in low-level mobile devices, along with practical, feasible solutions for overcoming current architecture limitations. This doctoral work has been thoroughly screened by the international academic community in the scenario of a vigorous publication activity of the doctoral team, scrutinized by world top experts in the relevant fields.

**​Fecha de grado:** 2012-1

**Título de tesis:** Non-Intrusive Detection of Rotating-Stall Occurring in the Turbine Quadrant of Francis-Type Pump-Turbines.​

**Grupo de investigación:** Mecánica Aplicada

**Director de tesis:**Manuel Julio García Ruiz

**Resumen:** El estancamiento rotativo (RS, por sus siglas en inglés: rotating-stall) es un fenómeno de natu-raleza hidrodinámica que ocurre en las bombas-turbina tipo Francis, puede representar grandes pérdidas económicas y un elevado riesgo de sufrir daños catastróficos. En el pasado, se restó importancia a este fenómeno y se utilizaron tratamientos paliativos que permitieron convivir con el problema. Hoy, sin embargo, el interés por las mejorar el funcio-namiento de la bomba-turbina se ha visto renovado. La bomba-turbina, reconocida actualmente como un actor importante en el escenario ecológico mundial, favorece a la implementación de una industria de generación eléctrica más limpia y segura. Últimamente, los logros en materia de predicción no han alcanzado los desarrollos deseados y por eso las opciones experimenta-les siguen siendo las más aceptadas entre los científicos. En general, las propuestas de instr u-mentación y montajes experimentales son complejas y se conciben sólo para pruebas de labo-ratorio en modelos a escala y no para ser implementados en prototipos. Las falencias reseñadas se constituyen en motivación para presentar tres métodos de detección del RS, basados en un número reducido de sensores y sobretodo en procedimientos de montaje y medición no intrusivos. De hecho, las vibraciones mecánicas y el ruido generado por la má-quina, en ocasiones indeseados, se aprovechan para diagnosticar las manifestaciones del RS. Además, para validar tales métodos, se prueba un modelo a escala de  una bomba-turbina tipo Francis que padece de RS. Se instalan acelerómetros, micrófonos, sensores de presión y pr o-ximidad; también, se utilizan hilos fluorescentes que se alinean con las líneas de corriente y fotografía de alta velocidad para captar detalles hidrodinámicos del flujo. El modelo se hace funcionar como turbina. Primero se exploran las condiciones normales de operación; es decir, alto rendimiento y libre de RS. Luego, se aumenta la velocidad de la má-quina hasta el embalamiento (runaway) para buscar el inicio del fenómeno. Finalmente, se busca un RS completamente desarrollado en la franja de operación conocida como freno-turbina (turbine-break). Los sensores de presión y la visualización de los hilos sirven para de-tectar con precisión la manifestación del fenómeno, e incluso suministrar detalles hidrodinámi-cos de su desarrollo; los acelerómetros, micrófonos y sensores de proximidad se utilizan al mismo tiempo, para detectar el RS desde el exterior de la máquina y de manera no intrusiva.

**​Fecha de grado:** 2011-1

**Título de tesis:** Compendium on "assessment of intended deformations and kinematic identification of parallel mechanisms under quasi-static condictions".

**Grupo de investigación:** Laboratorio CAD/CAM/CAE

​

**Director de tesis:** Óscar Eduardo Ruiz Salguero

**Resumen:** This doctoral work contributes in two main aspects: (i) closed from (anlytical) force-deformation models for complaint mechanism, and (ii) assessment of permanent deformations and / or manufacturing errors in mechanisms and manipulatorws (i.e kinematic identification).

## Plan de estudios

## Profesores

Los investigadores habilitados para dirigir tesis doctoral en el programa del Doctorado en Ingeniería son profesores y/o investigadores vinculados a la Universidad EAFIT, vinculados a una institución de educación superior, o a un centro o instituto de investigación nacional o extranjero. Vea el artículo 20 del reglamento para consultar los criterios de habilitación del director de tesis y codirector de tesis. ​​​​

## Escuela de Ciencias Aplicadas e Ingeniería

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Doctorado en Ingeniería Matemática

Duración

8 semestres

Lugar

Medellín

Horario

Dedicación completa

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES ​103604

Precio total del programa

$139.684.028

#### Doctorado en Ciencias de la Tierra

Duración

6 semestres

Lugar

Medellín

Horario

Tiempo completo

Más información

Lunes a viernes 8:00 a.m. a 6:00 p.m. y sábados 8:00 a.m. a 12:00 a.m.

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 102140

Precio total del programa:

$112.431.620

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Con más de 700 organizaciones aliadas, así se expande la relación de EAFIT con las empresas

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate