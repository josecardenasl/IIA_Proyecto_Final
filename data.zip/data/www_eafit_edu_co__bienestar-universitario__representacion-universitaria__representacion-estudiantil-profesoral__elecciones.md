# Elecciones - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Repres

Resultados 2026

*    Elecciones 

### Elecciones de representantes estudiantiles y profesorales 2026- Resultados

### Representantes pregrado

### Acta de escrutinio de pregrado

### Representantes de posgrado

### Acta de escrutinio de posgrado

### Representantes profesorales

### Acta de escrutinio profesorales

### Conoce los representantes elegidos en las elecciones 2025-2

###### Representantes de los estudiantes de pregrado

Periodo 26/08/2025 - 30/06/2026

###### Representantes de los profesores

Periodo 26/08/2025 - 30/06/2027

###### Representantes de los estudiantes de posgrado

Periodo 26/08/2025 - 30/06/2026

### Resultados elecciones 2025 / 2024

###### Representantes de los estudiantes de pregrado

Periodo 01/07/2025 - 30/06/2026

###### Representantes de los profesores

Periodo 01/07/2025 - 30/06/2027

###### Representantes de los profesores

Periodo 01/07/2024 - 30/06/2026

## Reglamento de Elecciones

## Contacto

​Para enviar comentarios, quejas, reclamos, sugerencias, denuncias y felicitaciones sobre el proceso debes contactar al Comité Electoral Universitario, máxima autoridad del proceso de elecciones, a través del correo electrónico elecciones@​eafit.edu.co​ adjuntando, si es pertinente, información que complemente el mensaje.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)