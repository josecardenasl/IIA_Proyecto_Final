# Apoyo psicosocial - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Apoyo psicosocial

Buscan acompañar la transición colegio-universidad, la integración social y académica, y la salud mental de los estudiantes.​

*    Apoyo Psicosocial 

###### Asesoría en orientación vocacional

Espacio ofrecido a estudiantes de pregrado de EAFIT, estudiantes de colegio o bachilleres, empleados que van a cursar algún pregrado y aspirantes a beca en EAFIT, para favorecer la toma de decisiones en relación con la elección profesional, considerando sus aptitudes, limitaciones, intereses, rasgos de personalidad y proyección. Las citas se solicitan en el bloque 3 oficina 135 o escribiendo a [​​dllo.estudiantil@eafit.edu.co​](https://www.eafit.edu.co/bienestar-universitario/desarrollo-estudiantil/%E2%80%8B%E2%80%8Bdllo.estudiantil@eafit.edu.co%E2%80%8B)

###### Asignatura Inducción​

Busca que los estudiantes de primer semestre identifiquen recursos personales, institucionales y académicos que faciliten su integración a la vida universitaria, por medio de información y acompañamiento para comenzar esta nueva etapa y así promover un vínculo con la institución que favorezca la permanencia.

**Se realiza en dos fases:**

Evento de bienvenida.

Curso vida universitaria.

**Línea 24/7 de salud mental 018000521021 y WhatsApp**[**3166011106**](https://api.whatsapp.com/send?phone=573166011106)

Servicio disponible para los estudiantes de pregrado y posgrado que ofrece contención ante urgencias en salud mental, orientación a rutas de atención, educación en salud mental y asesoría psicológica las 24 horas del día durante los 7 días de la semana. Es atendida por APH, tele psicología y tele psiquiatría.

## Directorio de servicios en salud en convenio

Recurso que reúne a un grupo de profesionales en salud mental e instituciones que ofrecen tarifas especiales para la comunidad universitaria.

 ​Aplica para: 

 Empleados (administrativos, docentes de planta y de cátedra, empleados temporales y por prestación de servicios). 

 Estudiantes (pregrado, posgrado, idiomas, educación permanente y UniNiños). 

 Egresados.

 Familiares en primer grado de consanguinidad.

## Atención psicológica

Habilitada como un servicio de salud mental de baja complejidad, que a partir de psicoterapia breve, asesoría psicológica e intervención en crisis facilita la reflexión individual de los estudiantes de pregrado y posgrado sobre su vida psico-afectiva, académica y social. Las citas se solicitan en el bloque 3 oficina 135 o escribiendo a​ ​dllo.estudiantil@eafit.edu.co.​ 

 Las condiciones del servicio son: 

 Se solicitan por el interesado y son intransferibles. 

 Se asignan de acuerdo con la disponibilidad en las agendas.

 La cantidad de citas por estudiante es máximo 7.

 En caso de presentarse situaciones de grave peligro para el estudiante o algún miembro de ​la comunidad, se contactará al acudiente y/o se derivará a las rutas de atención.

## Asignatura BU

Los Departamentos de Deportes, Desarrollo Artístico, Desarrollo Estudiantil y Servicio Médico, ofrecen cursos y talleres sobre temas acordes a cada área, que buscan crear una cultura reflexiva, lúdica y creativa que conlleve a la formación integral del estudiante y a su responsabilización en el devenir académico, con el fin de facilitar la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, y contribuir a la transición entre el colegio y la Universidad. 

 Las opciones de Desarrollo Estudiantil son: 

 Liderazgo y gestión emocional. 

 Pensamiento crítico.

 Amor y redes sociales. 

 Desarrollo de la creatividad.​

## Asignatura Metodología del Aprendizaje

Materia dirigida a los estudiantes en reingreso, previamente retirados por rendimiento académico (según el Reglamento Académico de pregrado), con el objetivo de que el estudiante logre discernir su posición como estudiante universitario, construya un método de estudio ajustado a sus particularidades y a las exigencias académicas, identifique e intervenga los elementos personales que facilitan u obstaculizan su proceso de aprendizaje e indague sobre el valor que le otorga al conocimiento.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)