# Pregrado en Ingeniería Física (vigente hasta 2025-2) - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Pregrado en Ingeniería Física (vigente hasta 2025-2)

*    Plan de Estudio 
*    Pregrado En Ingeniería Física (vigente Hasta 2025-2) 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

10 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas de ciencias básicas 

- [x] Asignaturas disciplinares 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Núcleo de Formación Institucional 

- [x] Prepráctica - Práctica 

Semestre 1

Créditos 

totales-

Créditos 0

#### Inducción

Código: BU0010

Inducción y Bienestar Universitario
## Inducción

0 Créditos

0 UMES

Código: **BU0010**

Créditos 1

#### Bienestar Universitario

Código: BU0011

Inducción y Bienestar Universitario
## Bienestar Universitario

 Cancelable 

1 Créditos

1 UMES

La asignatura Bienestar Universitario, por medio de actividades artísticas, deportivas, académicas y de reflexión, facilita la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, contribuyendo a la transición entre el colegio y la Universidad.

Código: **BU0011**

Correquisito Créditos 0

#### Taller de Salud

Código: BU0600

Créditos 0

#### Taller de Salud

Código: BU0600

Inducción y Bienestar Universitario
## Taller de Salud

0 Créditos

0 UMES

Código: **BU0600**

Créditos 3

#### Cálculo I

Código: CM0230

Asignaturas de ciencias básicas
## Cálculo I

3 Créditos

4 UMES

Código: **CM0230**

Créditos 4

#### Geometría en Contexto

Código: CM0446

Asignaturas de ciencias básicas
## Geometría en Contexto

4 Créditos

6 UMES

Código: **CM0446**

Créditos 3

#### Introducción a la Física

Código: DF0447

Asignaturas disciplinares
## Introducción a la Física

3 Créditos

4 UMES

Código: **DF0447**

Créditos 2

#### Introducción a la Ingeniería Física

Código: DF0448

Asignaturas disciplinares
## Introducción a la Ingeniería Física

2 Créditos

2 UMES

Código: **DF0448**

Créditos 2

#### Taller Procesos Manufactureros

Código: IP0288

Asignaturas disciplinares
## Taller Procesos Manufactureros

2 Créditos

3 UMES

Código: **IP0288**

Créditos 3

#### NFI - Pensamiento Computacional

Código: FH1002

Núcleo de Formación Institucional
## NFI - Pensamiento Computacional

3 Créditos

UMES

Código: **FH1002**

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

10 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas de ciencias básicas 

- [x] Asignaturas disciplinares 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Núcleo de Formación Institucional 

- [x] Prepráctica - Práctica 

### **Líneas de énfasis**

​El estudiante del programa de Ingeniería Física de la Universidad EAFIT puede tomar cuatro cursos de libre configuración y uno complementario dentro de una extensa oferta de cursos ofrecidos en la Universidad EAFIT, incluyendo cursos de posgrado. El estudiante puede también proponer los cursos que desea tomar en la Universidad o fuera de ella (en el caso de realizar un semestre en otra universidad del país o del exterior en el marco de alguno de los convenios que ha suscrito la Universidad EAFIT), siempre bajo la asesoría del jefe de carrera, quien se basa en la información entregada por los directores de los grupos de investigación de la Universidad y de la oferta académica de otras carreras. Es recomendable que estos cursos tengan relación con el trabajo en los grupos de investigación por medio de las prácticas investigativas.

Aunque los cursos pueden no estar relacionados entre sí, la recomendación es que el estudiante los tome dentro de un área específica. Esto conlleva a generar una líneas estructuradas que ayudan al estudiante en el momento decidir sus materias de libre configuración. Dichas líneas reciben los siguientes nombres:

Óptica Aplicada.

Mecánica Cuántica Computacional.

Microingeniería.

Procesamiento de Materiales por Plasma.

Nanotecnología.

En caso que el estudiante del mismo programa de Ingeniería Física de EAFIT o de otro programa de la Universidad deseara realizar su línea de énfasis con cursos que sean propios de la Maestría de Física Aplicada, y los cuales puedan ser posteriormente homologables en el mismo posgrado, se recomiendan las siguientes líneas de énfasis:

Instrumentación.

Mecánica Cuántica Computacional.

Microingeniería.

Holografía y Procesamiento Óptico.

Procesamiento de Materiales por Plasma.

Seguridad Electromagnética.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate