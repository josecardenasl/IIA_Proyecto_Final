# Convenios Internacionales - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Convenios

Bienvenido a la sección de convenios de Internacionalización EAFIT. Nuestra misión es fortalecer los vínculos institucionales, conectando los intereses de nuestros aliados con las capacidades académicas, Centros y Escuelas de la Universidad. Por medio de la exploración de alianzas estratégicas, la gestión de convenios y la recepción de visitas, conectamos a la Universidad EAFIT con el mundo.

*    Convenios 

## **Convenios**

Solicitud inicial

Puede ser una solicitud interna por parte de alguna dependencia/profesor de EAFIT, o una solicitud externa por parte de una institución internacional.

1.   **Responsable:** Institución externa o interesado académico/administrativo por parte de EAFIT.
2.   **Plazo estimado:** 3 meses de anticipación a la fecha esperada de entrada en vigor.
3.   **Documentación requerida:** Formato de solicitud de convenio diligenciado.
4.   **Correo de contacto:** agreements@eafit.edu.co

Revisión por la Universidad

**Revisión por parte de la Universidad EAFIT**

Revisión de la solicitud y del perfil de la institución internacional. Al igual que se realiza la elaboración y ajuste del modelo preliminar del convenio.

1.   **Responsable:**Internacionalización EAFIT (y responsable académico de ser necesario)
2.   **Plazo estimado**:15 días hábiles a partir de la solicitud o la entrega del Formato de Solicitud diligenciado.

Revisión por la Institución

**Revisión por parte de la institución internacional**

Revisión del borrador del convenio por parte aliado.

1.   **Responsable:** Institución internacional
2.   **Plazo estimado*:** Aproximadamente 1 mes a partir del envío del documento revisado por EAFIT.

*Este plazo depende totalmente del proceso de revisión y los tiempos de la institución internacional.

[Dado el caso de que el aliado proponga una nueva versión del documento con ajustes o modificaciones, el proceso regresará a la Etapa 2 - Revisión EAFIT].

Revisión de Secretaría

**Revisión de Secretaría General (EAFIT)de la versión final del convenio**

1.   **Responsable:** Secretaría General.
2.   **Plazo estimado:** 5 días hábiles a partir de la recepción de la versión final del convenio.

[En caso de que Secretaría General requiera una nueva versión del documento con ajustes o modificaciones, el proceso regresará a la Etapa 3 - Revisión del aliado].

Firma por EAFIT

**Firma por parte de la Universidad EAFIT**

Firma del convenio por parte de la Vicerrectora de Aprendizaje, representante legal de la Universidad EAFIT.

1.   **Responsable:**Internacionalización EAFIT.
2.   **Plazo estimado:** 15 días hábiles a partir de la entrega de todos los documentos.
3.   **Documentos:** El responsable académico del convenio (EAFIT) debe firmar el convenio y el formato de "Aprobaciones para firmas de convenios VRA".

**Responsable académico**

**¿Quién es el responsable académico del convenio?**

En algunos casos, se trata de la persona que lidera el relacionamiento con la institución aliada, mientras que en otros, es quien avala la suscripción del mismo y que promueve su aplicación dentro del ámbito académico dentro de las Escuelas y los programas.

**¿Qué significa ser responsable del convenio?**

Como requisito de la Vicerrectoría de Aprendizaje, todos los convenios deben tener la firma de un responsable académico, que respalde la gestión del convenio. Lo que responde a la estrategia de la universidad de firmar únicamente convenios que tengan un propósito y beneficio claro para las Escuelas, Centros y la comunidad eafitense, en general.

Firma por el Aliado

**Firma por el Aliado**

El aliado recibe el convenio firmado por la Universidad EAFIT y procede con la firma del documento por su parte.

1.   **Responsable:**Institución aliada.
2.   **Plazo estimado*:**Aproximadamente 1 mes a partir del envío del convenio firmado.

_*Este plazo depende totalmente de los tiempos de la institución internacional._

*   Acreditaciones internacionales.
*   Actividades culturales, académicas, deportivas o de extensión que tengan un componente internacional o de segunda lengua.
*   Actividades de Internacionalización en casa.
*   Articulación con los Centros de Incidencia y Estudio de EAFIT.
*   Centro de Idiomas.
*   Convenios internacionales.
*   Grupos de investigación.
*   Grupos entrantes de Study Abroad.
*   Métodos de enseñanza-aprendizaje utilizados para la internacionalización del currículo.
*   Pasantías de investigación.
*   Participación en proyectos de cooperación internacional.
*   Política de Lengua Extranjera.
*   Prácticas en el extranjero.
*   Producción intelectual de alcance internacional: ponencias, conferencias, artículos, capítulos de libros, patentes, coautorías, etc.
*   Profesores visitantes.
*   Redes y asociaciones internacionales.

La Universidad EAFIT tiene como prioridad alianzas con instituciones de alta calidad y reconocimiento. Estas asociaciones suelen implicar investigación cofinanciada, movilidad de profesores y estudiantes y programas conjuntos.

Como se ha mencionado anteriormente, EAFIT establece relaciones estratégicas con socios nacionales e internacionales de alta calidad, con los que compartimos nuestros valores fundamentales y desarrollamos asociaciones únicas a largo plazo que contribuyen a:

1.   Cumplir la misión de ambas instituciones.
2.   Ofrecer a estudiantes, profesores y personal una amplia gama de oportunidades para mejorar sus competencias y alcance internacionales.
3.   Apoyar el desarrollo de capacidades de alcance institucional.

**Nuestras asociaciones internacionales abarcan un amplio espectro de países, idiomas y propósitos, y se desarrollan bajo las premisas de:**

1.   Reciprocidad.
2.   Confianza.
3.   Compromiso.
4.   Sostenibilidad.

## Contact

Global Engagement

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)