# Década de 1970 - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Década 1970

En un ambiente de agitación social comenzaron los años setenta. Todavía se sentían los ecos del famoso Mayo del 68 francés.

*    Década de 1970 

##### **​​​¡Adiós a la Escuela, bienvenida la Universidad! ​**

**Desde sus inicios se perfiló como una institución dispuesta al cambio. Por eso, no fue extraño que al finalizar la década de 1970 ya contara con dos grandes logros: abrir sus puertas a nuevos campos del saber y dejar atrás la idea de escuela para darse a conocer como universidad.​​​​​​​​**

La segunda fase de EAFIT inició con una nueva dirección. El ingeniero químico Hernán Gómez González, quien lideró la Institución durante seis años, entregó su cargo al docente Hernando Bedoya. Este último asumió el puesto solo por un año.

Después de Bedoya, otros tres líderes formados en diferentes disciplinas se sumaron a la lista de 11 rectores, que, hasta hoy, han pasado por el campus: el abogado Ricardo Botero Mejía; Darío Monsalve Uribe, administrador y egresado eafitense; y el economista Héctor Ochoa Díaz.

Sin duda, el hito más significativo para la Institución en la década de 1970 fue un sueño que tenían sus fundadores desde sus primeros años, y que con todos los trámites en orden se convirtió en realidad.

Gracias a la aprobación del Gobierno Nacional, la entonces Escuela fue reconocida como universidad y, posteriormente, recibió un nuevo nombre: Escuela de Administración y Finanzas y Tecnologías, EAFIT. Además, inició su proceso de expansión.

Por iniciativa de la Dirección Académica, se fusionaron algunas áreas de conocimiento como administración y mercadeo, economía y contaduría, matemáticas y ciencias, y humanidades y lenguas. Además, fue instaurado el Plan Máster, adscrito directamente a la Rectoría y que sería el primer MBA en el país. El plan de estudios de este programa fue diseñado con el apoyo de la Universidad de Georgia.

También se abrió la maestría en Matemáticas Aplicadas, en convenio con la Universidad de Antioquia, y se le dio la bienvenida a las ingenierías y, por ende, a una segunda escuela. Así pues, a mediados de esta década comenzaron a dictarse las carreras de Ingeniería de Sistemas y de Ingeniería de Producción.

El decenio cerró una época de grandes cambios despidiéndose de los programas tecnológicos, formalizando así la oferta de pregrados, y realizando ajustes importantes en infraestructura: adquirió el primer computador y creó un centro de computo, laboratorios, espacios de estudio y más aulas.​

En un ambiente de agitación social comenzaron los años setenta. Todavía se sentían los ecos del famoso Mayo del 68 francés. El malestar también era expresión de problemas de interés público, como la Guerra de Vietnam (1955-1975) o la crisis del petróleo (1973). EAFIT no fue ajena a este contexto mundial. Sin embargo, y tras seis meses de suspensión de actividades académicas, con diálogo y reflexión se resolvieron las inquietudes que también habían surgido por parte de los estudiantes de la Institución.

El 6 de mayo de 1971, el Gobierno Nacional aprobó el reconocimiento como Universidad (antes era institución especializada), hecho que impulsó nuevos desarrollos, como el Plan Máster, en 1973, que se constituiría en una de las primeras maestrías en Administración (MBA) del país, y que contó con la asesoría de la Universidad de Georgia. Así, EAFIT avanzó en otro hito: la formación avanzada, es decir, los posgrados.

Para generar conciencia sobre la preservación y el buen uso de los recursos naturales, la Institución ofreció un curso de capacitación pionero en Colombia: Eco-administración (1975), que introducía la perspectiva ambiental en la administración. La preocupación de EAFIT por estos temas se dio como parte del temprano ecologismo contemporáneo: en 1970 comenzó a celebrarse el Día de la Tierra (1970), en 1972 se instauró el Programa de las Naciones Unidas para el Medio Ambiente y el mundo comenzaba a preocuparse por Los límites del crecimiento, título de un famoso documento producido por El Club de Roma (1972).

En la década del setenta se popularizaron dispositivos tecnológicos que cambiaron la vida cotidiana, laboral y científica, como la televisión en color y el computador. IBM se encontraba en el mercado desde principios del siglo XX, pero en los setenta aparecieron otras empresas líderes, como Microsoft (1975) y Apple (1976) que apalancados en la revolución de los microchips (Intel) revolucionaron el mundo del computador personal o PC. La necesidad de miniaturizar los computadores para la llegada del hombre a la Luna (1969) dio impulso a una nueva era de los computadores. EAFIT, en sintonía con las tendencias del progreso tecnológico y como una de las pioneras en este campo en el país, aprobó la compra de un computador IBM 370/115 (1975) y la instalación del Centro de Cómputo (1977), que aparte del equipo central prepararía la llegada de los nuevos aparatos.

A mediados de la década, en 1976, se suspendieron las tecnologías. No obstante, surgieron nuevos pregrados como Contaduría Pública (1977); y, con las ingenierías de Sistemas (1976) y de Producción (1979), nació la Escuela de Ingeniería, la segunda en la Institución. Estos hitos reflejaron el propósito de expansión del Plan Quinquenal de 1979-1983 que seguía respondiendo a las demandas del sector productivo. La Universidad iniciaba una nueva fase que enriquecía su perspectiva inicial de Business School, con la apuesta por el desarrollo empresarial y económico desde la ciencia y la tecnología.

Esta fue la epoca del neoliberalismo, el fin de la llamad​​a Guerra Fría y la caída del muro de Berlín en 1989. Se presentaba un contexto en el que era fundamental conocer y acercarse al ámbito internacional.​

## Hitos de la década

1970

###### **Programa académico de Administración Textil**

Se decide abrir un programa académico denominado Administración Textil, que pretendía vincular los perfiles de Administración de Negocios y Tecnología Textil. Este programa no alcanzó a graduar a ningún estudiante, pues para la época no se proyectaba la industria textil en el país. Estos estudiantes se transfirieron a Administración de Negocios.

###### **Modificación de la estructura orgánica**

Los nombres y las funciones de los principales organismos de la Institución fueron modificados. El Consejo Directivo pasó a ser el Consejo Superior. El director pasó a ser nombrado como rector y se posesionaron un representante de los profesores y un representante de los estudiantes.

1971

###### **12 de febrero**

###### **Se autoriza el funcionamiento de la entidad educativa**

El Ministerio de Educación Nacional, mediante la resolución numero 3469, autorizó el funcionamiento como entidad educativa a EAF.

###### **Marzo de 1971**

Suspensión de las residencias estudiantiles

**Se decidió que, poco a poco, el bloque de las residencias sería adecuado para aulas.**

1973

###### 4 de septiembre

###### **Darío Monsalve Uribe es nombrado rector**

Darío Monsalve Uribe es el nuevo rector de la Institución.

###### **Apertura del primer Máster en Administración, conocido en la actualidad como MBA**

Este programa se creó en acuerdo con la Universidad de Georgia y la asesoría de profesores del medio y de EAFIT, como el célebre Allen B. Dickerman, vinculado en ese momento a la universidad norteamericana, pero que venía desde la Misión Syracuse. 1974-1975 Planeación de los pregrados en Ingeniería de Sistemas, Ingeniería de Producción y Contaduría Pública A finales del segundo semestre de 1974 y durante el primer semestre de 1975 se realizó un arduo trabajo en la planeación de estas carreras.

1974-1975

###### **Planeación de los pregrados en Ingeniería de Sistemas, Ingeniería de Producción y Contaduría Pública**

A finales del segundo semestre de 1974 y durante el primer semestre de 1975 se realizó un arduo trabajo en la planeación de estas carreras.

1975

###### **23 de abril**

###### **Hector Ochoa Díaz es nombrado rector**

Héctor Ochoa Díaz es nombrado rector de la Institución.

###### **Primer computador y creación del Centro de Cómputo**

El 9 de julio se aprobó la adquisición del computador IBM 370/115. Día de gran importancia pues ma​rcó la entrada de la Institución al mundo de la computación.

###### **Suspensión del ofrecimiento de las tecnologías**

En octubre se realizó un estudio del futuro que le vendría a las carreras tecnológicas de la Institución. Como resultado, se decidió suspender este tipo de programas y se formalizó el ofrecimiento de carreras de duración extensa.​

Noviembre de 1976

###### **Creación del programa de Contaduría Pública**

Un nuevo pregrado se suma a la oferta de la Institución: Contaduría Pública.

Octubre de 1977

###### **Inauguración del Centro de Cómputo**

Con este centro, la Universidad EAFIT comenzó una trayectoria como pionera en el mundo de las tecnologías en el país.

1979

###### **Creación del programa de Ingeniería de Producción**

Este programa nació bajo el patrocinio y monitoreo de la República Federal Alemana de la época.​

###### **Instalación de las escuelas de Administración e Ingeniería**

Las dos nuevas escuelas afianzaron el título de Universidad otorgado a EAFIT en la década de 1970

###### **Creación del programa de Ingeniería Civil**

Este nuevo programa fortaleció la oferta de la Escuela de Ingeniería de EAFIT.

## Década de 1970

EAFIT, en sintonía con las tendencias del progreso tecnológico y como una de las pioneras en este campo en el país,

 aprobó la compra de un computador IBM 370/115 (1975) y la instalación del Centro de Cómputo (1977).

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)