# Índice de Becas y Financiación - Universidad EAFIT

EAFIT cuenta con los siguientes becas y financiación:

- **Alianza Lumni – EAFIT - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/alianza-lumni-eafit
- **becas-y-financiacion / beca-andi-eafit** — https://www.eafit.edu.co/becas-y-financiacion/beca-andi-eafit
- **Beca crédito al Talento Fundación Bolívar Davivienda – EAFIT - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/beca-credito-talento-fundacion-bolivar-davivienda
- **becas-y-financiacion / beca-fundacion-educacion-suiza-eafit** — https://www.eafit.edu.co/becas-y-financiacion/beca-fundacion-educacion-suiza-eafit
- **Beca Fundación Fraternidad - EAFIT - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/beca-fundacion-fraternidad-eafit
- **Beca Excelencia y Liderazgo Nutresa – EAFIT ​​ - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/beca-liderazgo-y-excelencia-nutresa-eafit
- **becas-y-financiacion / beca-mas-global** — https://www.eafit.edu.co/becas-y-financiacion/beca-mas-global
- **becas-y-financiacion / beca-sapiencia-mejores-bachilleres-medellin** — https://www.eafit.edu.co/becas-y-financiacion/beca-sapiencia-mejores-bachilleres-medellin
- **Becas estudiantes deportistas - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/becas-estudiantes-deportistas
- **Becas Talento y Aliados pregrado (Nutresa, Santa Ana, F.E. Suiza y Aurelio Llano) - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit
- **Crédito educativo Sufi a corto plazo y libre educativo - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/credito-educativo-sufi-corto-plazo
- **becas-y-financiacion / eafit-a-tu-alcance** — https://www.eafit.edu.co/becas-y-financiacion/eafit-a-tu-alcance
- **Fondo Futuro - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/fondo-futuro
- **becas-y-financiacion / fondo-sapiencia-con-recursos-de-epm** — https://www.eafit.edu.co/becas-y-financiacion/fondo-sapiencia-con-recursos-de-epm
- **Fondo Sapiencia Posgrados Nacionales​ - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/fondo-sapiencia-posgrados-nacionales
- **Matrícula de Honor - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/matriculas-de-honor
- **Mención de Honor por Promedio Crédito Acumulado - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/mencion-de-honor-por-promedio-credito-acumulado
- **Préstamo beca condonable posgrados - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/prestamo-beca-condonable-posgrados
- **Beca reconocimiento a la expresión artística - Universidad EAFIT** — https://www.eafit.edu.co/becas-y-financiacion/reconocimiento-expresion-artistica
