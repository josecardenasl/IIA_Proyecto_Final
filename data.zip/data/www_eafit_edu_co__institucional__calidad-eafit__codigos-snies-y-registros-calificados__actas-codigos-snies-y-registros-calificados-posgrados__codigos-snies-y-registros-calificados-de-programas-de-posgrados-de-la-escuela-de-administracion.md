# Códigos Snies y Registros Calificados de programas de Posgrados de la Escuela de Administración - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Códigos Snies y Registros Calificados

##### de programas de Posgrados de la Escuela de Administración

*    Códigos Snies y Registros Calificados de Programas de Posgrados de La Escuela de Administración 

**Programa**

**Doctorado en Administración**

Registro Calificado: [Resolución de oficio 017715 del 27 de septiembre de 2023](https://universidadeafit.widen.net/s/wmxsbshlmj/res-017715-27092023)

Modificado por la [Resolución 001280 del 4 de febrero de 2019](https://universidadeafit.widen.net/s/xflkjgvphb/rc-2019-doctorado-administracion)

**Número y fecha del acta**

171 del 26 de febrero de 2003

**Consejo**

Superior

**Código SNIES**

20820

**No. Créditos**

86

**Duración**

8 semestres

**Periodicidad de Admisión**

Anual

**Programa**

**Maestría en Administración de Instituciones de la Salud**

**Número y fecha del acta**

3 del 20 de febrero de 2020

**Consejo**

Académico

**Código SNIES**

110244

**No. Créditos**

40

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Maestría en Agronegocios**

**Número y fecha del acta**

765 del 25 de septiembre de 2019

**Consejo**

Académico

**Código SNIES**

109910

**No. Créditos**

40

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Maestría en Administración**

**Número y fecha del acta**

21 del 11 de mayo de 1973

**Consejo**

Superior

**Código SNIES**

1265

**No. Créditos**

49

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Ciencias de la Administración**

**Número y fecha del acta**

147 del 17 de marzo de 1999

**Consejo**

Directivo

**Código SNIES**

14912

**No. Créditos**

45

**Modalidad**

Investigación

**Duración semestres**

4

**Periodicidad Admisión**

Anual

**Programa**

**Maestría en Ciencias de los Datos y Analítica**

**Número y fecha del acta**

292 del 30 de agosto de 2017

**Consejo**

Superior

**Código SNIES**

107303

**No. Créditos**

13 (Profundización) / 12 (Investigación)

**Duración semestres**

3 (Profundización) / 4 (Investigación)

**Periodicidad Admisión**

Semestral

**Programa**

**Master of International Business (MIB)**

**Número y fecha del acta**

225 del 24 de febrero de 2010

**Consejo**

Superior

**Código SNIES**

106533

**No. Créditos**

40

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Desarrollo Humano Organizacional**

**Número y fecha del acta**

238 del 28 de septiembre de 2011

**Consejo**

Superior

**Código SNIES**

101456

**No. Créditos**

45

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Desarrollo Humano Organizacional - Virtual**

**Número y fecha del acta**

268 del 25 de marzo de 2015

**Consejo**

Superior

**Código SNIES**

104963

**No. Créditos**

47

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Trimestral

**Programa**

**Maestría en Mercadeo**

**Número y fecha del acta**

240 del 30 de noviembre de 2011

**Consejo**

Superior

**Código SNIES**

102017

**No. Créditos**

41

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Gerencia de Proyectos**

**Número y fecha del acta**

240 del 30 de noviembre de 2011

**Consejo**

Superior

**Código SNIES**

102161

**No. Créditos**

43

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Gerencia de la Innovación y el Conocimiento (Presencial y Virtual)**

**Número y fecha del acta**

253 del 31 de julio de 2013

**Consejo**

Superior

**Código SNIES**

103100

**No. Créditos**

45

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Administración de Riesgos**

**Número y fecha del acta**

253 del 31 de julio de 2013

**Consejo**

Superior

**Código SNIES**

102967

**No. Créditos**

43

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría Gerencia Integral por Procesos**

**Número y fecha del acta**

473 del 29 de marzo de 2017

**Consejo**

Directivo

**Código SNIES**

107471

**No. Créditos**

38

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Sostenibilidad - Virtual**

**Número y fecha del acta**

010 del 25 de noviembre de 2020

**Consejo**

Directivo

**Código SNIES**

111160

**No. Créditos**

40

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Dirección Estratégica para el Turismo**

**Número y fecha del acta**

010 del 25 de noviembre de 2020

**Consejo**

Directivo

**Código SNIES**

023341

**No. Créditos**

39

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Administración**

**Número y fecha del acta**

630 del 24 de enero de 2008

**Consejo**

Académico

**Código SNIES**

53696

**No. Créditos**

29

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Administración de Riesgos y Seguros**

**Número y fecha del acta**

441 del 4 de abril de 1996

**Consejo**

Académico

**Código SNIES**

4836

**No. Créditos**

30

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Auditoría de Sistemas**

**Número y fecha del acta**

169 del 21 de marzo de 1983

**Consejo**

Directivo

**Código SNIES**

1260

**No. Créditos**

33

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Control Organizacional**

**Número y fecha del acta**

4 del 13 de abril de 1994

**Consejo**

Directivo

**Código SNIES**

3233

**No. Créditos**

24

**Duración semestres**

2

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Gerencia de Proyectos**

**Número y fecha del acta**

4 del 16 de noviembre de 1994

**Consejo**

Superior

**Código SNIES**

3806

**No. Créditos**

31

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Gerencia del Desarrollo Humano**

**Número y fecha del acta**

416 del 8 de marzo de 1996

**Consejo**

Académico

**Código SNIES**

1256

**No. Créditos**

33

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Gerencia Estratégica de Costos**

**Número y fecha del acta**

387 del 29 de agosto de 2001

**Consejo**

Directivo

**Código SNIES**

1421

**No. Créditos**

30

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Mercadeo**

**Número y fecha del acta**

39 del 10 de marzo de 1976

**Consejo**

Superior

**Código SNIES**

1254

**No. Créditos**

29

**Duración semestres**

2

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Gerencia de Negocios Internacionales**

**Número y fecha del acta**

445 del 30 de enero de 2013

**Consejo**

Directivo

**Código SNIES**

102670

**No. Créditos**

22

**Duración semestres**

2

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Gerencia del Desarrollo Humano (Virtual)**

**Número y fecha del acta**

434 del 24 de noviembre de 2010

**Consejo**

Directivo

**Código SNIES**

91262

**No. Créditos**

33

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Gerencia de Instituciones de la Salud**

**Número y fecha del acta**

438 del 28 de septiembre de 2011

**Consejo**

Directivo

**Código SNIES**

101586

**No. Créditos**

24

**Duración semestres**

2

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Control Organizacional (Virtual)**

**Número y fecha del acta**

438 del 28 de septiembre de 2011

**Consejo**

Directivo

**Código SNIES**

101788

**No. Créditos**

33

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Gestión Tributaria Internacional**

**Número y fecha del acta**

446 del 3 de abril de 2013

**Consejo**

Directivo

**Código SNIES**

102966

**No. Créditos**

22

**Duración semestres**

2

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Administración**

**Número y fecha del acta**

438 del 28 de septiembre de 2011

**Consejo**

Directivo

**Código SNIES**

102035

**No. Créditos**

49

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Maestría en Gerencia de Proyectos**

**Número y fecha del acta**

758 del 4 de abril de 2019

**Consejo**

Académico

**Código SNIES**

109479

**No. Créditos**

43

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Gerencia de la Innovación y el Conocimiento**

**Número y fecha del acta**

4 del 28 de abril de 2021

**Consejo**

Superior

**Código SNIES**

111717

**No. Créditos**

45

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Administración**

**Número y fecha del acta**

406 del 2 de marzo de 2006

**Consejo**

Directivo

**Código SNIES**

53520

**No. Créditos**

29

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Mercadeo**

**Número y fecha del acta**

397 del 9 de marzo de 2004

**Consejo**

Directivo

**Código SNIES**

20397

**No. Créditos**

33

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Maestría en Mercadeo**

**Número y fecha del acta**

277 del 2 de marzo de 2016

**Consejo**

Superior

**Código SNIES**

107285

**No. Créditos**

42

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Gerencia de Proyectos**

**Número y fecha del acta**

240 del 30 de noviembre de 2011

**Consejo**

Superior

**Código SNIES**

106704

**No. Créditos**

43

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Administración**

**Número y fecha del acta**

438 del 28 de septiembre de 2011

**Consejo**

Directivo

**Código SNIES**

102034

**No. Créditos**

49

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Administración de Riesgos**

**Número y fecha del acta**

771 del 5 de diciembre de 2019

**Consejo**

Académico

**Código SNIES**

111276

**No. Créditos**

43

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Gerencia de la Innovación y el Conocimiento**

**Número y fecha del acta**

4 del 28 de abril de 2021

**Consejo**

Superior

**Código SNIES**

111717

**No. Créditos**

45

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Administración**

**Número y fecha del acta**

188 del 27 de julio de 2005

**Consejo**

Superior

**Código SNIES**

51997

**No. Créditos**

29

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Gerencia de Proyectos**

**Número y fecha del acta**

1615 del 20 de febrero de 2002

**Consejo**

Superior

**Código SNIES**

16054

**No. Créditos**

31

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Mercadeo**

**Número y fecha del acta**

397 del 9 de marzo de 2004

**Consejo**

Directivo

**Código SNIES**

52431

**No. Créditos**

29

**Duración semestres**

2

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Administración (Armenia)**

**Número y fecha del acta**

438 del 28 de septiembre de 2011

**Consejo**

Directivo

**Código SNIES**

102590

**No. Créditos**

67

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Anual

**Programa**

**Maestría en Mercadeo (Cali)**

**Número y fecha del acta**

277 del 2 de marzo de 2017

**Consejo**

Superior

**Código SNIES**

107872

**No. Créditos**

41

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Gerencia de la Innovación y el Conocimiento (Popayán)**

**Número y fecha del acta**

005 del 25 de mayo de 2022

**Consejo**

Directivo

**Código SNIES**

(No especificado)

**No. Créditos**

45

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Maestría en Gerencia de Proyectos (Popayán)**

**Número y fecha del acta**

005 del 25 de mayo de 2022

**Consejo**

Directivo

**Código SNIES**

(No especificado)

**No. Créditos**

43

**Modalidad**

Profundización

**Duración semestres**

4

**Periodicidad Admisión**

Semestral

**Programa**

**Maestría en Administración - MBA (Popayán)**

**Número y fecha del acta**

005 del 25 de mayo de 2022

**Consejo**

Directivo

**Código SNIES**

(No especificado)

**No. Créditos**

49

**Modalidad**

Profundización

**Duración semestres**

3

**Periodicidad Admisión**

Semestral

**Programa**

**Esp. en Administración de Riesgos y Seguros (Cali)**

**Número y fecha del acta**

408 del 27 de septiembre de 2006

**Consejo**

Directivo

**Código SNIES**

91521

**No. Créditos**

30

**Duración semestres**

3

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Mercadeo (Cali)**

**Número y fecha del acta**

188 del 27 de julio de 2005

**Consejo**

Superior

**Código SNIES**

52901

**No. Créditos**

29

**Duración semestres**

2

**Periodicidad Admisión**

Anual

**Programa**

**Esp. en Control Organizacional (Quibdó)**

**Número y fecha del acta**

458 del 26 de noviembre de 2014

**Consejo**

Directivo

**Código SNIES**

104300

**No. Créditos**

24

**Duración semestres**

2

**Periodicidad Admisión**

Semestral

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate