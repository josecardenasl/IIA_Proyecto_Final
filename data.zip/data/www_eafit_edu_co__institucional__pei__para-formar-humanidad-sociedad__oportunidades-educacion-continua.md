# ​​Oportunidades de educación continua

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Oportunidades de educación continua

*    ​​Oportunidades de Educación Continua 

​​Desde su Itinerario 2030, la Universidad EAFIT se concibe como un campus abierto para aprender a lo largo de la vida, como se puede evidenciar con ideas tan inspiradoras como la Universidad de los Niños y Saberes de Vida. Conscientes de que el conocimiento y el mundo se encuentran en constante evolución, la Institución acompaña cada etapa del ser humano desde Educación Continua, otra de las unidades de la Dirección de Educación Permanente, con un portafolio que alcanza los 500 cursos.

Sus diplomaturas, congresos, seminarios, encuentros y diferentes programas parten de un perfil, de un deseo, de una necesidad, de personas y empresas. En una sesión pueden encontrarse estudiantes de diferentes generaciones que se complementan, y así, enriquecen sus visiones del mundo.

Un curso de ascenso para oficiales superiores de la Policía Nacional, con 1.184 horas de aprendizaje; y el programa BIOS, en el que la Universidad en cocreación con este grupo empresarial diseñó una formación para los empleados de alto potencial con 32 estudiantes, fueron dos iniciativas de 2019 que se destacaron entre sus programas corporativos.

40 años de experiencia en educación continua, con conocimiento pertinente y aplicado.

18.692 estudiantes matriculados en 2019.​

> Elegí a EAFIT porque allí realicé mi posgrado y quedé muy contenta con la planta docente y por la calidad en la educación. El diplomado sobre costos que hice me gustó por su contenido, aplicado a casos de la vida real. Aprendí mucho y me parece excelente que uno encuentre gente de todas las edades en un programa de la Universidad, dado que de este modo se enriquece la experiencia y se diversifica el conocimiento”
> 
> 
> Johanna Andrea Penagos Botero, ingeniera financiera.

## 4. Educación de calidad

## 8. Trabajo decente y crecimiento ecónomico

## 10. Reducción de las desigualdades

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate