# ​Laboratorio de Metrología ​​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​Laboratorio de Metrología ​​

*    ​Laboratorio de Metrología ​​ 

#### **Servicios​​**

El laboratorio cuenta con recursos tecnológicos, locativos y humanos para realizar la calibración de instrumentos de medición de diferentes magnitudes físicas tales como longitud, fuerza, presión y realizar mediciones ​​dimensionales y geométricas complejas a partes fabricadas o prototipos, así como, evaluar tolerancias geométricas y de posición.

Con sus recursos el Laboratorio de Metrología brinda apoyo docente en las áreas de taller industrial, procesos de manufactura, dibujo técnico, sistemas de producción, especialización en turbomáquinas. También se aporta a los cursos de e​ducación continua relacionados con Metrología y Calidad, en temas como calibración, vocabulario, magnitudes físicas e incertidumbre de medición y otros a necesidad de la industria.

## Acreditación ISO/IEC 17025: 2017

En el Laboratorio de Metrología de la Universidad EAFIT contamos con acreditación ONAC vigente a la fecha, con código de acreditación 15-LAC-005, bajo la norma ISO/IEC 17025: 2017 – Requisitos generales para la competencia de los laboratorios de ensayo y calibración, para sistemas de medición de fuerza de máquinas de ensayo (según NTC-ISO 7500-1) e instrumentos de medición de fuerza de uso general con indicación directa en unidades de fuerza tales como celdas de carga y dinamómetros (según ABNT NBR 8197).

#### **Recursos​**

## Escáner laser 3D

## Máquina de medición por coordenadas (CMM)

## Microscopio digital de medición

## Rugosímetro portátil

## Patrones de Longitud, Fuerza, Presión y Masa

## Calibrador de comparadores de caratula y palpadores de alta exactitud

## Transductores de fuerza clase 0 y 0.5

## Mármol de planitud

## Alineador láser para máquinas rotativas

## Calibrador de presión automático hasta 300 psi

## Contacto

Julián Andrés Duque Orrego, coordinador.

**Correo:**[jduque3@eafit.edu.co​](mailto:jduque3@eafit.edu.co%E2%80%8B)

**Teléfono:** (57) (604) 26193​86​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate