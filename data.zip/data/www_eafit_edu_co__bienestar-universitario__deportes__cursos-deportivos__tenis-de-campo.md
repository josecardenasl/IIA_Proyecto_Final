# Tenis de campo - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Tenis de campo

Aprende y disfruta del tenis de campo en EAFIT. Inscríbete en nuestros cursos.

*    Tenis de Campo 

##### Inscripciones entre el 16 y 26 de febrero de 2026

**Inversion:** Estudiantes, empleados administrativos y docentes EAFIT: Beca del 100%. Antes de inscribirte asegúrate que puedes cumplir con los horarios y políticas.

**Inversion familiares:** (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado y graduados de los programas de pregrado y posgrado de la Universidad EAFIT. Descuento del 50%  $149.000

**Inversión particulares:** $298.000

**Importante:** Si el participante (menor o mayor de edad) no es un usuario registrado en las bases de datos de la Universidad de [clic aquí](https://app.eafit.edu.co/crm-jsp/clientes/rch_registro.htm) para registrarse y de nuevo haga la inscripción.

###### Para Eafitenses: Empleados, estudiantes de programas de pregrado, posgrado, profesores, y graduados de pre y posgrado.

Digitar tipo de documento del participante

Matriculas

Talleres

Semestre

Consultar

Seleccionar curso

Registrarse

Le debe aparecer: “La inscripción del taller ha terminado exitosamente y posterior escoger la opción pagar” (graduados, familiares y público en general)

###### Para familia de eafitenses y particulares: Padres, hijos, hermanos y esposo o compañero permanente y particulares.

Digitar tipo de documento del participante

Matriculas

Talleres

Semestre

Consultar

Seleccionar curso

Registrarse

Le debe aparecer: La inscripción del taller ha terminado exitosamente y posterior escoger la opción pagar (graduados, familiares y público en general)

###### Tener en cuenta

No hacemos nivelaciones. Las personas de acuerdo con la descripción del nivel se inscriben.

Luego de inscribirse y realizar pago, no se hace devolución de dinero. Salvo en casos justificados.

Para la comunidad que tiene apoyo del 100%, deben asistir al 80% de las clases, de lo contrario el curso debe ser pagado en su totalidad.

Las clases que se pierden por lluvia no se reponen, pero existe la posibilidad de asistir en otros horarios.

Las inscripciones se abren para todo el público en general (comunidad, familiares, egresados y particulares).

###### Principiantes​

Familiarización con el implemento y el escenario.

Posiciones y movimientos básicos.

**Adultos (16 horas):**

**Horario:** Martes / 5:00 p.m.

**Inicio:** 03 de Marzo

**Finaliza:**23 de Junio

**Entrenador:**​ Juan Santiago Cuesta​

**Adultos (16 horas):**

**Horario:** Sábado / 9:00 a.m.

**Inicio:** 07 de Marzo

**Finaliza:**27 de Junio

**Entrenador:** Juan Santiago Cuesta

**Niños 9-12 años (16 horas):**

**Horario:** Sábado / 10:00 a.m.

**Inicio:** 07 de Marzo

**Finaliza:**27 de Junio

**Entrenador:** Catalina Ramirez

###### Iniciados I

​​Mejoramiento de posiciones básicas y de la técnica.

Desarrollo de los golpes básicos como el saque, el revés, la derecha y volea.

Repeticiones para sostener un corto intercambio de golpe a fondo y a un ritmo lento.

**Adultos (16 horas):**

**Horario:** Viernes / 11:00 a.m.

**Inicio:** 06 de Marzo

**Finaliza:** 26 de Junio

**Entrenador:** Catalina Ramirez

**​Niños de 6-8 años (16 horas):**

**Horario:** Sábado / 10:00 a.m.

**Inicio:** 07 de Marzo

**Finaliza:** 27 de Junio

**Entrenador:** Catalina Ramirez

**Niños de 9-12 años (16 horas):**

**Horario:** Sábado / 11:00 a.m.

**Inicio:** 07 de Marzo

**Finaliza:** 27 de Junio

**Entrenador:** Juan Santiago Cuesta

###### Iniciados II

​​Perfeccionamiento desde el inicio hasta la terminación, en todos los golpes, mejorando la ​consistencia y control de la pelota en el fondo.

Mejoramiento en el direccionamiento de golpes con técnica y táctica en cancha; anticipando los movimientos del oponente y adoptando una posición efectiva para devolver los golpes.

Ejercicios de introducción a la táctica de juego de red, incluyendo el saque y volea, y cómo cerrar puntos en la red.​

**Adultos (16 horas):**

**Horario:** Lunes 3:00 p.m.

**Inicio:** 02 de Marzo

**Finaliza:** 22 de Junio

**Entrenador:** Catalina Ramirez

**Adultos (16 horas):**

**Horario:** Martes / 6:00 p.m.

**Inicio:**03 de Marzo

**Finaliza:** 23 de Junio

**Entrenador:** Juan Santiago Cuesta

**​Adultos (16 horas):**

**Horario:** Sábado / 10:00 a.m.

**Inicio:** 07 de Marzo

**Finaliza:** 27 de Junio

**Entrenador:** Juan Santiago Cuesta​​

###### Avanzados

Perfeccionamiento de los desplazamientos y golpes.

Desarrollo de situaciones que permitan el conocimiento básico de la estrategia de juego tales como, controlar el ritmo del partido, identificar debilidades en el oponente y adaptar el juego según las circunstancias.

Partidos de práctica para que se apliquen habilidades y estrategias aprendidas en situaciones de juego real.

**Adultos (16 horas):**

**Horario:** Sábado / 11:00 a.m.

**Inicio:** 07 de Marzo

**Finaliza:** 27 de Junio

**Entrenador:** Catalina Ramirez

​

**Adultos (16 horas):**

**Horario:** Miércoles / 5:00 p.m.

**Inicio:** 04 de Marzo

**Finaliza:**24 de Junio

**Entrenador:** Catalina Ramirez

##### Generalidad​es

**IMPLEMENTOS**

Raqueta de tenis de campo (en caso de no tenerlo, la Institucion dispondra del implemento para el optimo desarrollo)

La Institución sumistra las bolas.

Ropa cómoda

**​ESCENARIOS**

Cancha en piso de material sintético.

Camerinos con lockers para uso exclusivo durante la practica. Es necesario llevar candado.

Si llegas en vehiculo. Es necesario pago de parqueadero

El ingreso a la Institucion se autoriza con el documento de identidad

Duchas con dispensador de jabon y secador de cabello en el camerino de mujeres.

En las clases no se cuenta con caddie

**​Nota:​**Los dias en los que no se tenga clase en alguno de nuestros cursos, estas no se reponen. Los usuarios podrán asistir a otros horarios y reponer dicho tiempo, si así lo desean.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate