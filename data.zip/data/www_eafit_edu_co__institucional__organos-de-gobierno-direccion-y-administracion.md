*    Órganos de Gobierno, Dirección y Administración 

### **Consejo Superior**

El Consejo Superior es el máximo órgano de gobierno de la Universidad. Es el custodio del patrimonio y de la estrategia de la misma. Le compete igualmente preservar los principios y la filosofía de los fundadores de la Institución. Sus miembros no ejercerán actividades de dirección ni administración.

El Consejo Superior está compuesto por el número de personas que él mismo determine por mayoría absoluta de sus miembros, teniendo máximo 25 miembros y mínimo 16, elegidos por el mecanismo de cooptación, previo cumplimiento del procedimiento de nominación y elección definido por el propio Consejo. Serán elegidos para períodos personales de cuatro años, con posibilidad de reelección hasta por dos períodos más, con excepción de los miembros activos que suscribieron el Acta de Fundación de la Universidad.

###### Integrantes

###### Juan Manuel Velasco Barrera

Es administrador de negocios de la Universidad EAFIT y cuenta con una amplia trayectoria en el sector financiero. Ha trabajado en entidades como Asset Management de Bolsa y Renta, la administradora de fondos Nación SAI, Inversionistas de Colombia y Suvalor (hoy Valores Bancolombia).

Además, ha sido emprendedor, creando y desarrollando empresas en distintos sectores. Actualmente se desempeña como socio y Deputy CEO de BTG Pactual en Colombia. En EAFIT, además de ejercer como profesor, integró el Consejo Directivo en calidad de representante de los graduados.

###### Andrés Aguirre Martínez

Integra el Consejo Superior desde el 30 de noviembre de 2022.

Es especialista en Gerencia Hospitalaria de la Universidad EAFIT y cuenta con una destacada trayectoria en el sector salud. Durante 22 años se desempeñó como director general del Hospital Pablo Tobón Uribe.

Actualmente es presidente de la Junta Directiva de la Asociación Colombiana de Hospitales y Clínicas (ACHC) y conferencista en eventos nacionales e internacionales sobre seguridad social, servicio, gestión de la calidad y liderazgo.

###### Jorge Iván Rodríguez Castaño

Este ingeniero químico de la Universidad Pontificia Bolivariana hizo parte del grupo de visionarios que, en 1960, fundaron la Universidad EAFIT. Desde entonces, ha acompañado a la Institución como integrante de su Consejo Superior.

Su trayectoria profesional inició en Fabricato y continuó como subgerente de Locería Colombiana, gerente de Tejidos Única de Manizales y gerente de Corona. Además, fue presidente de la Junta Directiva y de la Gerencia de la Industria de Variedades Textiles (Invatex).

###### Integrantes activos

###### Josefina María Agudelo Trujillo

Integra el Consejo Superior desde el 29 de julio de 2015.

Es administradora de negocios de la Universidad EAFIT y actualmente se desempeña como presidenta del Grupo TCC, organización en la que previamente ocupó el cargo de gerente general.

A lo largo de su trayectoria profesional ha sido integrante de las juntas directivas de Leonisa S.A., Leasing Bancolombia y TCC Inversiones S.A.

###### Carlos Ignacio Gallego Palacio

Integra el Consejo Superior desde el 29 de julio de 2015.

Es ingeniero civil y magíster en Administración de la Universidad EAFIT, con estudios en Logística y Estrategia en el MIT, en Gerencia Social en la Universidad de Harvard y en Administración y Mercadeo en la Universidad de Kellogg.

En su trayectoria profesional se ha desempeñado como presidente de Servicios de la Compañía Nacional de Chocolates y director general de la Fundación Nutresa.

###### Cipriano López González

Integra el Consejo Superior desde el 29 de julio de 2015.

Es ingeniero mecánico de la Universidad Pontificia Bolivariana y magíster en Administración de Negocios de la Escuela de Negocios de Burdeos. Además, cuenta con estudios en Pensamiento de Diseño y el Arte de la Innovación del Programa Ejecutivo TEP Tuck en Dartmouth College, y en Marketing Estratégico Esencial en la Universidad de Notre Dame.

A lo largo de su trayectoria se ha desempeñado como jefe de operaciones de Imusa, director de Negociación de Bavaria, gerente general de Industrias Haceb y vicepresidente de Innovación y Sostenibilidad de Bancolombia. Actualmente es el CEO de Nequi.

###### María Clara Aristizábal Restrepo

Es economista y especialista en Finanzas de la Universidad EAFIT, y especialista en Finanzas y Derecho, y magíster en Administración de New York University. Durante su recorrido laboral ha sido analista de Investigaciones Económicas en Valores Bancolombia, directora de Investigaciones Económicas en Bolsa y Renta, asistente de Presidencia y gerente de Estrategia Corporativa en Cementos Argos y en la actualidad es gerente de Negocio Desarrollo Urbano en la misma organización.

###### Luz María Correa Vargas

Integra el Consejo Superior desde el 25 de enero de 2017.

Es administradora de negocios y especialista en Finanzas de la Universidad EAFIT.

A lo largo de su trayectoria profesional ha ocupado cargos como asistente administrativa, gerente administrativa y financiera, y directora general en Construcciones El Cóndor S.A., organización en la que actualmente se desempeña como presidenta corporativa.

###### Santiago Londoño Uribe

Integra el Consejo Superior desde el 25 de enero de 2017.

Es abogado de la Universidad de los Andes y magíster en Procesos Urbanos y Ambientales de la Universidad EAFIT, así como magíster en Derecho de la Escuela de Economía de Londres (LSE).

Ha sido profesor de la Universidad EAFIT, concejal de Medellín, secretario de Gobierno de Antioquia, gerente político de diversas campañas a la Gobernación de Antioquia y gerente general de Energías y Potencias S.A.S.

###### Magda Restrepo Arango

Integra el Consejo Superior desde el 25 de enero de 2017.

Es ingeniera geológica de la Universidad EIA y cuenta con una amplia trayectoria en los sectores público y privado.

Se ha desempeñado como secretaria de Hacienda de Medellín, gerente de Logística de Suramericana, gerente administrativa y financiera de ARL Sura, directora de Mercados de la Bolsa de Valores de Medellín, gerente de Tesorería de Corfinsura y directora general de la Fundación Fraternidad Medellín, cargo que ocupa actualmente.

###### Lina Mejía Correa

Integra el Consejo Superior desde el 29 de abril de 2020.

Es economista y especialista en Economía Internacional de la Universidad de Medellín. Además, cursó un posgrado en Bibliotecas Escolares, Cultura Escrita y Sociedad en Red, y una especialización en Libros Infantiles y Juveniles: producción, mediación y recepción, ambos en la Universidad Autónoma de Barcelona.

A lo largo de su trayectoria profesional ha estado vinculada a Colombiana de Comercio – Alkosto, donde se ha desempeñado como vicepresidenta, integrante del Consejo Directivo y gerente. Actualmente es presidenta del Consejo Directivo de la Fundación Secretos para Contar.

###### Ana Cristina Abad Restrepo

Integra el Consejo Superior desde el 29 de abril de 2020.

Es comunicadora social y periodista de la Universidad Pontificia Bolivariana, especialista en Semiótica de la Universidad EAFIT y magíster en Comunicación con énfasis en Divulgación Científica de la Universidad Pompeu Fabra.

A lo largo de su trayectoria profesional ha ocupado diversos cargos en entidades educativas y culturales, entre ellos el de gerente de la Corporación Orquesta Filarmónica de Medellín, jefa del Departamento de Comunicación y Cultura de EAFIT, directora de la Universidad de los Niños y profesora de cátedra en la misma Institución. Actualmente se desempeña como gerente de Gestión del Entorno e Identidad de Suramericana.

###### Verónica Londoño Schnitzius

Integra el Consejo Superior desde el 30 de noviembre de 2022.

Es ingeniera de producción de la Universidad EAFIT y actualmente se desempeña como presidenta de American Leather, una de las compañías más importantes del sector de muebles en los Estados Unidos. Inició su trayectoria en esta organización como practicante y, tras ocupar diversos cargos, asumió su liderazgo.

Hace parte de la Young Presidents’ Organization (YPO), comunidad global de liderazgo que reúne a directores ejecutivos de todo el mundo, y lidera distintos programas de becas. En 2021 fue reconocida con el premio Graduados que Inspiran, en la categoría Liderazgo Empresarial.

###### Paula Moreno Zapata

Integra el Consejo Superior desde el 30 de noviembre de 2022.

Es ingeniera industrial y diplomada en Lengua y Cultura Italiana, además de MPhil en Gestión de la Universidad de Cambridge. Fue ministra de Cultura de Colombia entre 2007 y 2010, convirtiéndose en la primera mujer afrocolombiana en ocupar un cargo ministerial en el país.

Ha sido gerente, coordinadora y consultora para diversas agencias internacionales, entre ellas el Banco Interamericano de Desarrollo (BID), la Unión Europea, la Unesco y el Banco Mundial. Actualmente es presidenta de la Corporación Manos Visibles, organización cuyo impacto alcanza a más de 18.000 líderes y estudiantes de comunidades étnicas en el país y en el ámbito internacional. Asimismo, preside el Comité Programático de la Junta Directiva de la Fundación Ford.

###### Carlos Miguel Correa Tobón

Integra el Consejo Superior desde el 30 de noviembre de 2022.

Es un emprendedor y líder social reconocido por su pasión por el emprendimiento y el fortalecimiento de los ecosistemas emprendedores.

Es cofundador de Breakfast Club y de Rappi, donde se desempeñó durante cuatro años como líder de comunicaciones estratégicas de Rappi Latam. Además, es cofundador de Mystic Foods y actualmente director comercial y de expansión de Olivia y Clap Burgers.

Ha sido consultor en crecimiento y estrategia digital para Home Capital, KeyBe, Seeri, Mis Aliados y Enerbit, e integrante de la junta directiva de Iluma Alliance. También hizo parte de la primera cohorte del proyecto Liderario.

###### Pedro Miguel Echavarría

Es economista y politólogo formado en Tufts University, en Boston (Estados Unidos).

Es fundador de Café Pergamino, empresa con la que ha logrado consolidar una conexión integral que abarca desde la producción en sus propias fincas y las de productores aliados, hasta la experiencia en tiendas especializadas, operadas directamente o por sus clientes en decenas de países.

Estudioso de los asuntos públicos, ha participado en distintos procesos de voluntariado, entre ellos el del Clúster de Café de Antioquia. Actualmente, recién afiliado a Proantioquia, hace parte del Comité de Valor Público.

###### Eulalia Sanín

Es economista de la Universidad de los Andes y magíster en Relaciones Internacionales y Economía Internacional de la School of Advanced International Studies (SAIS) de la Universidad Johns Hopkins en Washington D. C.

Ha sido integrante de juntas directivas de empresas y organizaciones líderes en la región, y cuenta con más de 25 años de experiencia en consultoría, con énfasis en estrategia y gobierno corporativo, evaluación de directorios, estrategia internacional, promoción de inversión extranjera, competitividad y políticas públicas.

A lo largo de su trayectoria ha liderado y participado en proyectos relacionados con estrategias de entrada a nuevos mercados, planeación estratégica, gobierno corporativo y evaluación de directorios en compañías de Latinoamérica y Estados Unidos.

En el ámbito académico, se destaca como fundadora de la Liga de Directores —programa ejecutivo de formación para miembros de junta de empresas líderes de América Latina—, integrante del International Advisory Board de la Facultad de Administración de la Universidad de los Andes, y profesora de cátedra de esta misma institución.

###### Miguel Piedrahíta

Es administrador de negocios de la Universidad EAFIT, magíster en Administración del IE Business School (España) y cuenta con estudios en el Programa de Liderazgo Ejecutivo de la Escuela de Negocios de Stanford. Desde 2020 se desempeña como director general de NoName.

A lo largo de su trayectoria profesional ha ocupado cargos como líder de Estrategia de Transformación Digital y director de Banca de Inversión en Bancolombia, además de destacarse como empresario y emprendedor, reconocido por su participación en Shark Tank Colombia.

Actualmente hace parte de las juntas directivas de Celsia, Odinsa y Protección, y participa activamente en el Comité de Valor Social de Proantioquia. También se desempeña como consejero del programa Liderario de EAFIT, Comfama y Proantioquia, y es miembro de la red de emprendimiento Endeavor Medellín.

En la Universidad ha sido profesor de cátedra en la Escuela de Administración, Empresario Residente y panelista frecuente en espacios estudiantiles como Gerenciar y Conamerc.

###### Ignacio Calle Cuartas

Desde 2016 se desempeña como CEO de Sura Asset Management, compañía que administra 180 BUSD para más de 23 millones de clientes en América Latina. En su trayectoria profesional ha ocupado cargos como vicepresidente financiero de Grupo Sura y director financiero internacional de Groupe Casino (Francia), con responsabilidad sobre Asia, el océano Índico y Latinoamérica.

Es ingeniero de producción de la Universidad EAFIT y magíster en Economía y Finanzas de la State University of New York. Además, cuenta con estudios en Crecimiento Empresarial de la Universidad de Kellogg y en Tecnologías Exponenciales de Singularity University.

Actualmente hace parte de las juntas directivas del World Pension Fund (La Haya, Holanda) y de la Fundación Sura, y ha participado en proyectos de direccionamiento estratégico para Antioquia. En el ámbito académico, ha sido profesor en las universidades EAFIT, UPB y EIA, en cursos de estrategia financiera, finanzas corporativas y economía internacional.

###### María Clara Aristizábal Restrepo

Integra el Consejo Superior desde Noviembre de 2016.

Es economista y especialista en Finanzas de la Universidad EAFIT, además de especialista en Finanzas y Derecho y magíster en Administración de la New York University.

A lo largo de su trayectoria profesional se ha desempeñado como analista de Investigaciones Económicas en Valores Bancolombia, directora de Investigaciones Económicas en Bolsa y Renta, asistente de Presidencia y gerente de Estrategia Corporativa en Cementos Argos, organización en la que actualmente ocupa el cargo de gerente de Negocio de Desarrollo Urbano.

###### Consejo Directivo

El Consejo Directivo es el máximo órgano de dirección y administración de la Universidad. En la Institución este estamento está conformado por 9 miembros con voz y voto:

El presidente del Consejo Superior, quien preside también el Consejo Directivo.

El vicepresidente del Consejo Superior, quien también actúa como vicepresidente del Consejo Directivo.

Cinco miembros elegidos por el Consejo Superior, entre sus integrantes, para un período de 4 años, con posibilidad de una única reelección. Al menos uno debe ser egresado de la Universidad.

Un profesor, elegido conforme lo establece el Reglamento de Elecciones, el cual es expedido por el rector.

Un estudiante elegido conforme lo establece el Reglamento de Elecciones, el cual es expedido por el rector.

###### Integrantes

###### Juan Manuel Velasco Barrera

Presidente del Consejo Superior

Es administrador de negocios de la Universidad EAFIT y cuenta con una amplia trayectoria en el sector financiero. Ha trabajado en entidades como Asset Management de Bolsa y Renta, la administradora de fondos Nación SAI, Inversionistas de Colombia y Suvalor (hoy Valores Bancolombia).

Además, ha sido emprendedor, creando y desarrollando empresas en distintos sectores. Actualmente se desempeña como socio y Deputy CEO de BTG Pactual en Colombia. En EAFIT, además de ejercer como profesor, integró el Consejo Directivo en calidad de representante de los graduados.

###### Andrés Aguirre Martínez

Vicepresidente del Consejo Superior

Es especialista en Gerencia Hospitalaria de la Universidad EAFIT y cuenta con una destacada trayectoria en el sector salud. Durante 22 años se desempeñó como director general del Hospital Pablo Tobón Uribe.

Actualmente es presidente de la Junta Directiva de la Asociación Colombiana de Hospitales y Clínicas (ACHC) y conferencista en eventos nacionales e internacionales sobre seguridad social, servicio, gestión de la calidad y liderazgo.

###### Lina Mejía Correa

Representante del Consejo Superior

Es economista y especialista en Economía Internacional de la Universidad de Medellín. Además, cursó un posgrado en Bibliotecas Escolares, Cultura Escrita y Sociedad en Red, y una especialización en Libros Infantiles y Juveniles: producción, mediación y recepción, ambos en la Universidad Autónoma de Barcelona.

A lo largo de su trayectoria profesional ha estado vinculada a Colombiana de Comercio – Alkosto, donde se ha desempeñado como vicepresidenta, integrante del Consejo Directivo y gerente. Actualmente es presidenta del Consejo Directivo de la Fundación Secretos para Contar.

###### Santiago Londoño Uribe

Representante del Consejo Superior

Es abogado de la Universidad de los Andes y magíster en Procesos Urbanos y Ambientales de la Universidad EAFIT, así como magíster en Derecho de la Escuela de Economía de Londres (LSE).

Ha sido profesor de la Universidad EAFIT, concejal de Medellín, secretario de Gobierno de Antioquia, gerente político de diversas campañas a la Gobernación de Antioquia y gerente general de Energías y Potencias S.A.S.

###### Magda Restrepo Arango

Representante del Consejo Superior

Es ingeniera geológica de la Universidad EIA y cuenta con una amplia trayectoria en los sectores público y privado.

Se ha desempeñado como secretaria de Hacienda de Medellín, gerente de Logística de Suramericana, gerente administrativa y financiera de ARL Sura, directora de Mercados de la Bolsa de Valores de Medellín, gerente de Tesorería de Corfinsura y directora general de la Fundación Fraternidad Medellín, cargo que ocupa actualmente.

###### María Clara Aristizábal Restrepo

Representante del Consejo Superior.

Integra el Consejo Superior desde Noviembre de 2024.

Es economista y especialista en Finanzas de la Universidad EAFIT, además de especialista en Finanzas y Derecho y magíster en Administración de la New York University.

A lo largo de su trayectoria profesional se ha desempeñado como analista de Investigaciones Económicas en Valores Bancolombia, directora de Investigaciones Económicas en Bolsa y Renta, asistente de Presidencia y gerente de Estrategia Corporativa en Cementos Argos, organización en la que actualmente ocupa el cargo de gerente de Negocio de Desarrollo Urbano.

###### Pedro Miguel Echavarría

Es economista y politólogo formado en Tufts University, en Boston (Estados Unidos).

Es fundador de Café Pergamino, empresa con la que ha logrado consolidar una conexión integral que abarca desde la producción en sus propias fincas y las de productores aliados, hasta la experiencia en tiendas especializadas, operadas directamente o por sus clientes en decenas de países.

Estudioso de los asuntos públicos, ha participado en distintos procesos de voluntariado, entre ellos el del Clúster de Café de Antioquia. Actualmente, recién afiliado a Proantioquia, hace parte del Comité de Valor Público.

###### Nataly Montoya Restrepo

Representante principal de los profesores

Abogada y especialista en Derecho Público de la Universidad EAFIT, magíster en Estudios Urbano-Regionales de la Universidad Nacional de Colombia, sede Medellín. Actualmente se encuentra realizando sus estudios de Doctorado en Geografía de la Pontificia Universidad Católica de Chile, Santiago de Chile.

###### ​​Alejandro Álvarez Vanegas

Representante suplente de los profesores​

Ingeniero de procesos de la Universidad EAFIT, magíster en Ciencias de la Sostenibilidad de la Universidad de Leuphana (Lüneburg, Alemania) y Ph. D. en Educación Superior para el Desarrollo Sostenible por la Universidad de Maastricht y la Universidad de las Naciones Unidas - MERIT.

Desde 2015 es profesor de tiempo completo en el área de Sistemas Naturales y Sostenibilidad de EAFIT. Su investigación se enfoca en la educación para el desarrollo sostenible, con énfasis en el aprendizaje transformador y experiencial, orientado al fortalecimiento de competencias en sostenibilidad en estudiantes y educadores.

###### Daniel Esteban Alvarez Leyton

Representante principal de los estudiantes

Es estudiante de Ciencias Políticas

Es estudiante de Ciencias Políticas y actualmente cursa el séptimo semestre. Entre los periodos 2024-2 y 2025-1 se desempeñó como representante estudiantil ante la Escuela de Finanzas, Economía y Gobierno, y desde inicios de 2025 hace parte del Observatorio Antioquia Visible.

El 1 de julio de 2025 asumió como integrante del Consejo Directivo, reafirmando su compromiso con la participación estudiantil y con el fortalecimiento institucional de la Universidad.

###### Jerónimo Torres Orozco

Representante suplente de los estudiantes

Es estudiante de Comunicación Social

Estudiante de Comunicación Social desde 2022. Ganador del Premio a la Mejor Crónica o Reportaje Audiovisual y del Premio a la Mejor Entrevista o Perfil Radial en Periodistas en la Carrera.

Ha sido monitor de Comunicaciones y de Ecolabs en la Escuela de Artes y Humanidades, además de codirector de Mercadeo de la Copa Repres. Actualmente es practicante de comunicaciones internas en el Metro de Medellín y, desde 2024, integra el Consejo Directivo de la Universidad como representante estudiantil.

###### Laura Cardona Bolívar

Representante suplente de los estudiantes

Es estudiante de Ciencias Políticas

Estudiante de octavo semestre de Ciencias Políticas. Su línea de énfasis es Gobierno y Políticas Públicas, y ha orientado su formación hacia temas como equidad de género, justicia social y acción colectiva. Desde julio de 2025 integra el Consejo Directivo, donde aporta su experiencia, liderazgo y compromiso con la participación estudiantil.

###### Claudia Restrepo Montoya

Rectora

Doctora en Filosofía | Rectora de la Universidad EAFIT | Profesora de Dirección y Liderazgo | Columnista de El País América

Filósofa, educadora y líder universitaria, Claudia Patricia Restrepo Montoya ha dedicado su trayectoria a integrar el pensamiento humanista con la acción pública y la transformación educativa. Su formación en administración, estudios políticos y filosofía le ha permitido construir una mirada interdisciplinaria sobre el liderazgo, la educación y el desarrollo social.

Ha ocupado diversos cargos de liderazgo en el sector público y académico, entre ellos gerente del Metro de Medellín, secretaria de Educación de Antioquia y vicealcaldesa de Educación, Cultura, Participación, Recreación y Deporte de Medellín. Desde esos roles, impulsó políticas y proyectos orientados al fortalecimiento institucional, la equidad educativa y la integración entre cultura, conocimiento y ciudadanía.

Su gestión se ha caracterizado por un liderazgo ético, sensible y transformador, enfocado en el desarrollo humano, la confianza social y la promoción de comunidades de aprendizaje.

En el ámbito académico, es profesora del curso Dirección y Liderazgo, donde promueve una comprensión del poder, la imaginación y la presencia como dimensiones esenciales del liderazgo. Además, es columnista de El País América, medio en el que reflexiona sobre filosofía cotidiana, educación y democracia, tendiendo puentes entre la reflexión y la experiencia.

###### Consejo Académico

El Consejo Académico es la autoridad académica que vela por el cumplimiento e implementación del Proyecto Educativo Institucional de la Universidad EAFIT. Está compuesto por las siguientes personas con voz y voto:

El rector, quien lo preside.

El vicerrector de aprendizaje, o quien haga sus veces.

Los decanos de las Escuelas.

Dos profesores, elegidos conforme lo establece el Reglamento de Elecciones, el cual es expedido por el rector.

Dos estudiantes de los programas de pregrado, elegidos conforme lo establece el Reglamento de Elecciones, el cual es expedido por el rector.

Un estudiante de posgrado, elegido conforme lo establece el Reglamento de Elecciones, el cual es expedido por el rector.

###### Integrantes

###### Claudia Restrepo Montoya

Rectora

Doctora en Filosofía | Rectora de la Universidad EAFIT | Profesora de Dirección y Liderazgo | Columnista de El País América

Filósofa, educadora y líder universitaria, Claudia Patricia Restrepo Montoya ha dedicado su trayectoria a integrar el pensamiento humanista con la acción pública y la transformación educativa. Su formación en administración, estudios políticos y filosofía le ha permitido construir una mirada interdisciplinaria sobre el liderazgo, la educación y el desarrollo social.

Ha ocupado diversos cargos de liderazgo en el sector público y académico, entre ellos gerente del Metro de Medellín, secretaria de Educación de Antioquia y vicealcaldesa de Educación, Cultura, Participación, Recreación y Deporte de Medellín. Desde esos roles, impulsó políticas y proyectos orientados al fortalecimiento institucional, la equidad educativa y la integración entre cultura, conocimiento y ciudadanía.

Su gestión se ha caracterizado por un liderazgo ético, sensible y transformador, enfocado en el desarrollo humano, la confianza social y la promoción de comunidades de aprendizaje.

En el ámbito académico, es profesora del curso Dirección y Liderazgo, donde promueve una comprensión del poder, la imaginación y la presencia como dimensiones esenciales del liderazgo. Además, es columnista de El País América, medio en el que reflexiona sobre filosofía cotidiana, educación y democracia, tendiendo puentes entre la reflexión y la experiencia.

###### Paola Podestá Correa

Vicerrectora de Aprendizaje

Magíster en Ciencias de la Administración y administradora de negocios. Además, está cursando un doctorado en Ciencias Económicas y Administrativas.

Durante su trayectoria en EAFIT, se ha desempeñado como jefa del Departamento de Negocios Internacionales, directora de Inteligencia de la spin off Laboratorio de Entretenimiento Inteligente, coordinadora de la especialización en Gerencia de Negocios Internacionales, directora académica de Innovación y coordinadora académica de Emprendimiento.

Fuera de la academia, ha trabajado para organizaciones como Citibank Colombia, la Orquesta Sinfónica de Antioquia y la aerolínea Aces. En la actualidad también hace parte del Grupo de Investigación en Innovación, Empresarismo y Sostenibilidad.​

###### María Andrea De Villa Correa

Decana

Decana de la Escuela de Administración

María Andrea cuenta con una trayectoria académica de más de dos décadas dedicada a la docencia, la investigación, la gestión institucional, la consultoría y la cocreación de proyectos con el sector empresarial. Es doctora en Administración con énfasis en Estrategia de Cranfield University (Reino Unido); y magíster en Administración, especialista en Mercadeo y negociadora internacional de la Universidad EAFIT. Además, tiene estudios adicionales en formación ejecutiva en Global Strategic Management de Harvard University (Estados Unidos), y en Strategic Performance Management de University of Cambridge (Inglaterra).

Desde 2004, ha consolidado una destacada trayectoria en la Escuela de Administración de EAFIT, desempeñando roles directivos en programas de posgrado y liderando procesos de acreditación internacional. Su perfil académico tiene un fuerte componente global, habiendo sido profesora e investigadora visitante en instituciones de renombre en Estados Unidos, Inglaterra, Finlandia y Francia, lo que culminó en su nombramiento como profesora distinguida en 2024.

Como investigadora, es experta en estrategia de no-mercado y gestión de riesgos socio-políticos, con publicaciones en las revistas científicas más prestigiosas del campo de la administración. Su liderazgo internacional se refleja en su rol como editora y representante en organizaciones como la Strategic Management Society, además de haber sido galardonada con el Premio Ciencia, Tecnología e Innovación 2025 por su trayectoria de excelencia.

###### Ricardo Taborda Ríos

Decano de la Escuela de Ciencias Aplicadas e Ingeniería

Doctor en Ingeniería Civil y Ambiental, magíster en Ingeniería Civil y Estructural, magíster en Mecánica Estructural e ingeniero civil.

Su trayectoria académica y profesional se ha desarrollado en México y Estados Unidos, en instituciones de gran reconocimiento internacional. Ha trabajado en la División de Ingeniería Estructural del Instituto de Ingeniería de la Universidad Nacional Autónoma de México (UNAM), en el Strong Motion Research Group de la Universidad del Sur de California, en el Quake Group de la Universidad Carnegie Mellon, y en el Center for Earthquake Research and Information de la Universidad de Memphis.

Actualmente, hace parte del comité científico del Southern California Earthquake Center y se desempeña como editor asociado del Bulletin of the Seismological Society of America.

###### Verónica Uribe Hanabergh

Decana de la Artes y Humanidades

Doctora en Humanidades de la Universidad Pompeu Fabra de Barcelona (Summa Cum Laude) y posee un Diploma de Estudios Avanzados- Máster Europeo en Humanidades de la misma institución. Además, es licenciada en Artes con honores en Pintura y Bachelor of Arts de la Australian National University (Australia).

Trabajó como directora del Departamento de Historia del Arte de la Universidad de Los Andes y como profesora asociada por más de diez años de la misma universidad. Durante su trayectoria ha sido reconocida con distinciones como el Premio Julio González Gómez y el Golden Key International Honour Society de la Universidad Nacional de Australia.

Es autora de libros, capítulos, artículos y textos de divulgación sobre temas como el arte de la modernidad tardía, la historia del paisaje, la ecocrítica, el patrimonio cultural y el pensamiento estético. Se destaca por su participación como integrante de los comités científicos de las revistas: Pensamiento Estético e Historia del Arte, de la Universidad Nacional de Colombia en Medellín; Art in Translation, de la Universidad de Edinburgo (Escocia); Minius: Historia, Arte y Geografía, de la Universidad de Vigo, (España); y H-ART: Revista de historia, teoría y crítica de arte, de la Universidad de los Andes; y como integrante de diversas juntas directivas de instituciones reconocidas de artes y ciencias tanto nacionales como internacionales.

###### Esteban Hoyos Ceballos

Decano de la Escuela de Derecho

Doctor (J.S.D.) y magíster en Derecho (LL.M.) de la Universidad de Cornell, y abogado de la Universidad de los Andes.

En EAFIT ha ocupado diversos roles académicos y de liderazgo, entre ellos profesor, coordinador académico de la Maestría en Derecho, coordinador del grupo de investigación en Derecho y Poder, y cofundador y coordinador del semillero de investigación en Derecho Constitucional.

También ha sido profesor invitado en diferentes universidades nacionales y en instituciones académicas de España, México y Chile. Antes de vincularse a EAFIT, se desempeñó como auxiliar judicial de la Corte Constitucional Colombiana.

Sus principales áreas de interés incluyen el derecho y la teoría constitucional, los derechos económicos, sociales y culturales, la enseñanza del Derecho en América Latina, la educación jurídica clínica y el derecho de interés público, entre otros.

###### César Eduardo Tamayo Tobón

Decano de la Escuela de Finanzas, Economía y Gobierno

Doctor en Economía, magíster en Economía Internacional y economista.

Su trayectoria profesional incluye una amplia experiencia en organismos internacionales y entidades financieras. Estuvo vinculado al Banco Interamericano de Desarrollo (BID) como economista e investigador en diferentes divisiones y departamentos, y al Banco de la Reserva Federal de Estados Unidos.

También, se desempeñó como investigador en la Asociación Nacional de Instituciones Financieras (ANIF) y en el Departamento de Investigaciones y Estrategias de Bancolombia. Asimismo, ha sido profesor en la Universidad de Rutgers y en la Universidad de los Andes.

###### María Virginia Gaviria Gil

Representante principal de los profesores​​

Profesora e investigadora del área de Teorías del Derecho en la Escuela de Derecho de la Universidad EAFIT, donde también se desempeña como Coordinadora de Posgrados.

Es magíster en Historia de la Universidad Nacional de Colombia y especialista en Derecho Administrativo de la Universidad Pontificia Bolivariana, institución en la que también cursó sus estudios de Derecho y Ciencias Políticas.

Su trayectoria académica combina la formación en el ámbito jurídico con la perspectiva histórica, lo que le ha permitido consolidar una visión interdisciplinaria aplicada tanto a la enseñanza como a la investigación en derecho.

###### María Cecilia Henao Arango

Representante suplente de los profesores

Es ingeniera civil, magíster en Administración (MBA), Project Management Professional (PMP®) y doctora en Ciencias Económicas y Administrativas. Desde hace varios años se desempeña como par académico de CONACES del Ministerio de Educación Nacional.

Es profesora de planta en programas de pregrado y posgrado en EAFIT, donde orienta asignaturas relacionadas con estándares internacionales para la gestión de proyectos, preparación y evaluación ambiental de proyectos, y gestión de proyectos. Actualmente es jefe del pregrado en Administración de Negocios y profesora en la Especialización y Maestría en Gerencia de Proyectos, así como en la Maestría en Administración.

Su experiencia profesional incluye la asesoría a las constructoras Calle 3 y Gestora LTDA, la dirección administrativa y gerencia de la Sociedad MAR S.A., y su paso por Integral S.A., donde trabajó en el Departamento de Estudios Ambientales y en el grupo de Gerencia de Proyectos.

###### Juan Esteban Vélez Villegas

Representante principal de los profesores​​

###### Carlos Miguel Cadena Gaitán

Representante suplente de los profesores

###### ​Raquel Jaramillo Correa

Representante principal de los estudiantes de pregrado

Es estudiante de Ciencias Políticas

###### María Teresa Hincapié Pérez

Representante suplente de los estudiantes de pregrado

Es estudiante de Psicología

###### ​Catalina Marulanda Diaz

Representante principal de los estudiantes de pregrado

Es estudiante de Negocios Internacionales

###### Kelly Tatiana Orozco Garcia

Representante suplente de los estudiantes de pregrado

Es estudiante de Negocios Internacionales

###### Comité de Ciencia, Tecnología e Innovación

Aprobado mediante la Resolución Rectoral N.° 002 del 4 de diciembre de 2023. Este Comité es un órgano permanente, consultivo, representativo y decisorio que acompaña al Sistema de CTeI y a la Vicerrectoría de Ciencia, Tecnología e Innovación en el direccionamiento estratégico en esta materia. De manera complementaria, cada Escuela cuenta con un Comité de Ciencia, Tecnología e Innovación de Escuela como un órgano consultivo y decisorio, que tiene por finalidad orientar y propender por la mejor toma de decisiones frente a las actividades de ciencia, tecnología e innovación. Es importante precisar que el Comité de Ciencia, Tecnología e Innovación de Escuela sirve como instancia previa al Comité de Ciencia, Tecnología e Innovación de la Universidad.

###### Integrantes

###### Claudia Restrepo Montoya

Rectora

Doctora en Filosofía | Rectora de la Universidad EAFIT | Profesora de Dirección y Liderazgo | Columnista de El País América

Filósofa, educadora y líder universitaria, Claudia Patricia Restrepo Montoya ha dedicado su trayectoria a integrar el pensamiento humanista con la acción pública y la transformación educativa. Su formación en administración, estudios políticos y filosofía le ha permitido construir una mirada interdisciplinaria sobre el liderazgo, la educación y el desarrollo social.

Ha ocupado diversos cargos de liderazgo en el sector público y académico, entre ellos gerente del Metro de Medellín, secretaria de Educación de Antioquia y vicealcaldesa de Educación, Cultura, Participación, Recreación y Deporte de Medellín. Desde esos roles, impulsó políticas y proyectos orientados al fortalecimiento institucional, la equidad educativa y la integración entre cultura, conocimiento y ciudadanía.

Su gestión se ha caracterizado por un liderazgo ético, sensible y transformador, enfocado en el desarrollo humano, la confianza social y la promoción de comunidades de aprendizaje.

En el ámbito académico, es profesora del curso Dirección y Liderazgo, donde promueve una comprensión del poder, la imaginación y la presencia como dimensiones esenciales del liderazgo. Además, es columnista de El País América, medio en el que reflexiona sobre filosofía cotidiana, educación y democracia, tendiendo puentes entre la reflexión y la experiencia.

###### Antonio Julio Copete Villa

Vicerrector de Ciencia, Tecnología e Innovación​

Doctor y magíster en Física, especialista en Astrofísica de Altas Energía y físico.

Durante su recorrido profesional ha sido profesor asistente e investigador postdoctoral del Harvard-Smithsonian Center for Astrophysics y tutor del Laboratorio de Física Nuclear del MIT. Así mismo, es cofundador y director de Relaciones Institucionales de Clubes de Ciencia Colombia, y fundador y director de la iniciativa Latin America on Steam.

Fue integrante de la Misión Internacional de Sabios en 2019 y también se desempeñó como director de Capacidades y Divulgación de la Ciencia, la Tecnología y la Innovación del Ministerio de Ciencia, Tec​​nología e Innovación.

###### María Andrea De Villa Correa

Decana

Decana de la Escuela de Administración

María Andrea cuenta con una trayectoria académica de más de dos décadas dedicada a la docencia, la investigación, la gestión institucional, la consultoría y la cocreación de proyectos con el sector empresarial. Es doctora en Administración con énfasis en Estrategia de Cranfield University (Reino Unido); y magíster en Administración, especialista en Mercadeo y negociadora internacional de la Universidad EAFIT. Además, tiene estudios adicionales en formación ejecutiva en Global Strategic Management de Harvard University (Estados Unidos), y en Strategic Performance Management de University of Cambridge (Inglaterra).

Desde 2004, ha consolidado una destacada trayectoria en la Escuela de Administración de EAFIT, desempeñando roles directivos en programas de posgrado y liderando procesos de acreditación internacional. Su perfil académico tiene un fuerte componente global, habiendo sido profesora e investigadora visitante en instituciones de renombre en Estados Unidos, Inglaterra, Finlandia y Francia, lo que culminó en su nombramiento como profesora distinguida en 2024.

Como investigadora, es experta en estrategia de no-mercado y gestión de riesgos socio-políticos, con publicaciones en las revistas científicas más prestigiosas del campo de la administración. Su liderazgo internacional se refleja en su rol como editora y representante en organizaciones como la Strategic Management Society, además de haber sido galardonada con el Premio Ciencia, Tecnología e Innovación 2025 por su trayectoria de excelencia.

###### Ricardo Taborda Ríos

Decano de la Escuela de Ciencias Aplicadas e Ingeniería

El decano de la Escuela de Ciencia Aplicadas e Ingeniería es doctor en Ingeniería Civil y Ambiental, magíster en Ingeniería Civil y Estructural y en Mecánica Estructural, e ingeniero civil.

Su trayectoria y experiencia profesional se desarrolló en México y Estados Unidos, en la División de Ingeniería Estructural del Instituto de Ingeniería de la Universidad Nacional Autónoma de México, en el Strong Motion Research Group de la Universidad del Sur de California, en el Quake Group de la Universidad Carnegie Mellon, y en el Center for Earthquake Research and Information de la Universidad de Memphis.

En la actualidad hace parte del comité científico del Southern California Earthquake Center y es editor asociado del Bulletin of the Seismological Society of America.

###### Verónica Uribe Hanabergh

Decana de la Escuela de Artes y Humanidades

Doctora en Humanidades de la Universidad Pompeu Fabra de Barcelona (Summa Cum Laude) y posee un Diploma de Estudios Avanzados- Máster Europeo en Humanidades de la misma institución. Además, es licenciada en Artes con honores en Pintura y Bachelor of Arts de la Australian National University (Australia).

Trabajó como directora del Departamento de Historia del Arte de la Universidad de Los Andes y como profesora asociada por más de diez años de la misma universidad. Durante su trayectoria ha sido reconocida con distinciones como el Premio Julio González Gómez y el Golden Key International Honour Society de la Universidad Nacional de Australia.

Es autora de libros, capítulos, artículos y textos de divulgación sobre temas como el arte de la modernidad tardía, la historia del paisaje, la ecocrítica, el patrimonio cultural y el pensamiento estético. Se destaca por su participación como integrante de los comités científicos de las revistas: Pensamiento Estético e Historia del Arte, de la Universidad Nacional de Colombia en Medellín; Art in Translation, de la Universidad de Edinburgo (Escocia); Minius: Historia, Arte y Geografía, de la Universidad de Vigo, (España); y H-ART: Revista de historia, teoría y crítica de arte, de la Universidad de los Andes; y como integrante de diversas juntas directivas de instituciones reconocidas de artes y ciencias tanto nacionales como internacionales.

###### Esteban Hoyos Ceballos

Decano de la Escuela de Derecho

Doctor (J.S.D.) y magíster en Derecho (LL.M.) de la Universidad de Cornell, y abogado de la Universidad de los Andes.

En EAFIT ha ocupado diversos roles académicos y de liderazgo, entre ellos profesor, coordinador académico de la Maestría en Derecho, coordinador del grupo de investigación en Derecho y Poder, y cofundador y coordinador del semillero de investigación en Derecho Constitucional.

También ha sido profesor invitado en diferentes universidades nacionales y en instituciones académicas de España, México y Chile. Antes de vincularse a EAFIT, se desempeñó como auxiliar judicial de la Corte Constitucional Colombiana.

Sus principales áreas de interés incluyen el derecho y la teoría constitucional, los derechos económicos, sociales y culturales, la enseñanza del Derecho en América Latina, la educación jurídica clínica y el derecho de interés público, entre otros.

###### César Eduardo Tamayo Tobón

Decano de la Escuela de Finanzas, Economía y Gobierno

Doctor en Economía, magíster en Economía Internacional y economista.

Su trayectoria profesional incluye una amplia experiencia en organismos internacionales y entidades financieras. Estuvo vinculado al Banco Interamericano de Desarrollo (BID) como economista e investigador en diferentes divisiones y departamentos, y al Banco de la Reserva Federal de Estados Unidos.

También, se desempeñó como investigador en la Asociación Nacional de Instituciones Financieras (ANIF) y en el Departamento de Investigaciones y Estrategias de Bancolombia. Asimismo, ha sido profesor en la Universidad de Rutgers y en la Universidad de los Andes.

###### Nicolás Guarín Zapata

Representante profesoral principal​​

Doctor en Ingeniería Computacional, magister en Ciencias Computacionales, especialista en Mecánica Computacional e Ingeniero Físico. Su trayectoria académica y profesional se ha consolidado en la intersección entre las matemáticas aplicadas, la ingeniería y las ciencias, ámbitos en los que ha desarrollado investigación y aportes significativos.

Sus intereses se enfocan en el análisis de territorios y ciudades, así como en el diseño de aplicaciones matemáticas para la ciencia y la ingeniería, contribuyendo al entendimiento y a la solución de problemáticas complejas mediante enfoques interdisciplinarios.​​​

###### Ana María Ortega Álvarez

Representante profesoral principal

Negociadora Internacional con énfasis en Mercadeo de la Universidad EAFIT, especialista en Mercadeo y magíster en Marketing Gerencial de la Universidad de Viña del Mar. Actualmente, cursa un doctorado en Administración Estratégica de Empresas en Centrum Business School.

En la Universidad EAFIT, ha sido jefa del pregrado en Mercadeo, coordinadora del área de Métodos de Investigación Cuantitativos y docente en los cursos de Métodos Cuantitativos, Investigación de Mercados Cuantitativa, Métodos de Investigación Cuantitativos, Investigación Cualitativa, Estadística (MBA) y Comportamiento del Consumidor de Moda (Mercadeo Estratégico de la Moda).

###### Alejandro Maya Maya

Representante estudiantil principal pregrado

"Estudiante de administración de negocios, en noveno semestre, y de Finanzas, en sexto semestre en la Universidad EAFIT. Durante su formación ha combinado el interés por la gestión empresarial y el análisis financiero con la participación activa en espacios de investigación y liderazgo estudiantil.

Fue miembro y coordinador del semillero de investigación en Innovación y Emprendimiento, y ha participado en grupos estudiantiles vinculados a congresos, voluntariado y redes internacionales, lo que le ha permitido fortalecer sus competencias académicas, de liderazgo y de trabajo en equipo.

Actualmente es Representante Estudiantil ante el Comité de Ciencia, Tecnología e Innovación (CTeI) desde el periodo 2024-2, cargo en el que contribuye al diálogo académico y a la articulación de iniciativas que fomentan la investigación y la innovación en la Universidad."

###### Santiago Arias Higuita

Representante estudiantil suplente pregrado

Estudiante de Ingeniería de Sistemas en la Universidad EAFIT, con énfasis en Gerencia de Proyectos. Participó en el Proyecto de Innovación EAFIT, enfocado en la transferencia de tecnología y conocimiento, donde fortaleció su interés por la aplicación práctica de la ciencia y la innovación.

Desde julio de 2024, se desempeña como Representante Estudiantil de Pregrado ante el Comité de Ciencia, Tecnología e Innovación, cargo en el que contribuye a promover la participación estudiantil y a impulsar propuestas que articulan la investigación y la innovación con el desarrollo institucional."

###### María Camila Álvarez Bedoya

Representante estudiantil suplente pregrado

###### Danilo Andrés Suárez Higuita

Representante estudiantil principal posgrado

Maestría en Matemáticas Aplicadas

###### Manuela Ramos Ospina

Representante estudiantil suplente posgrado

Maestría en Ciencias de los Datos y Analítica

###### Rectoría

Por definición en los Estatutos Generales, el Rector es el representante legal de la Universidad, como persona jurídica. Es el encargado de orientar y dirigir académica y administrativamente a la Institución de acuerdo con los lineamientos trazados por los Consejos Superior y Directivo. El Rector es designado por un perioro de 5 años y puede ser reelegido por una única vez.

Comités asesores de la Rectoría: El Rector podrá conformar Comités Asesores, de carácter permanente o temporal, responsables de analizar, proponer y desarrollar políticas académicas y administrativas en los campos de la docencia, la investigación, la proyección social, entre otros.

###### Claudia Restrepo Montoya

Doctora en Filosofía | Rectora de la Universidad EAFIT | Profesora de Dirección y Liderazgo | Columnista de El País América

Filósofa, educadora y líder universitaria, Claudia Patricia Restrepo Montoya ha dedicado su trayectoria a integrar el pensamiento humanista con la acción pública y la transformación educativa. Su formación en administración, estudios políticos y filosofía le ha permitido construir una mirada interdisciplinaria sobre el liderazgo, la educación y el desarrollo social.

Ha ocupado diversos cargos de liderazgo en el sector público y académico, entre ellos gerente del Metro de Medellín, secretaria de Educación de Antioquia y vicealcaldesa de Educación, Cultura, Participación, Recreación y Deporte de Medellín. Desde esos roles, impulsó políticas y proyectos orientados al fortalecimiento institucional, la equidad educativa y la integración entre cultura, conocimiento y ciudadanía.

Su gestión se ha caracterizado por un liderazgo ético, sensible y transformador, enfocado en el desarrollo humano, la confianza social y la promoción de comunidades de aprendizaje.

En el ámbito académico, es profesora del curso Dirección y Liderazgo, donde promueve una comprensión del poder, la imaginación y la presencia como dimensiones esenciales del liderazgo. Además, es columnista de El País América, medio en el que reflexiona sobre filosofía cotidiana, educación y democracia, tendiendo puentes entre la reflexión y la experiencia.

Contacto:[rectoria@eafit.edu.co](mailto:rectoria@eafit.edu.co)

###### Comité Rectoral

**Se trata de un comité asesor de la Rectoría integrado por los siguientes directivos:**

###### Claudia Restrepo Montoya​

Rectora

Doctora en Filosofía | Rectora de la Universidad EAFIT | Profesora de Dirección y Liderazgo | Columnista de El País América

Filósofa, educadora y líder universitaria, Claudia Patricia Restrepo Montoya ha dedicado su trayectoria a integrar el pensamiento humanista con la acción pública y la transformación educativa. Su formación en administración, estudios políticos y filosofía le ha permitido construir una mirada interdisciplinaria sobre el liderazgo, la educación y el desarrollo social.

Ha ocupado diversos cargos de liderazgo en el sector público y académico, entre ellos gerente del Metro de Medellín, secretaria de Educación de Antioquia y vicealcaldesa de Educación, Cultura, Participación, Recreación y Deporte de Medellín. Desde esos roles, impulsó políticas y proyectos orientados al fortalecimiento institucional, la equidad educativa y la integración entre cultura, conocimiento y ciudadanía.

Su gestión se ha caracterizado por un liderazgo ético, sensible y transformador, enfocado en el desarrollo humano, la confianza social y la promoción de comunidades de aprendizaje.

En el ámbito académico, es profesora del curso Dirección y Liderazgo, donde promueve una comprensión del poder, la imaginación y la presencia como dimensiones esenciales del liderazgo. Además, es columnista de El País América, medio en el que reflexiona sobre filosofía cotidiana, educación y democracia, tendiendo puentes entre la reflexión y la experiencia.

###### Paola Podestá Correa

Vicerrectora de Aprendizaje

Magíster en Ciencias de la Administración y administradora de negocios. Además, está cursando un doctorado en Ciencias Económicas y Administrativas.

Durante su trayectoria en EAFIT, se ha desempeñado como jefa del Departamento de Negocios Internacionales, directora de Inteligencia de la spin off Laboratorio de Entretenimiento Inteligente, coordinadora de la especialización en Gerencia de Negocios Internacionales, directora académica de Innovación y coordinadora académica de Emprendimiento.

Fuera de la academia, ha trabajado para organizaciones como Citibank Colombia, la Orquesta Sinfónica de Antioquia y la aerolínea Aces. En la actualidad también hace parte del Grupo de Investigación en Innovación, Empresarismo y Sostenibilidad.​

###### Antonio Julio Copete Villa

Vicerrector de Ciencia, Tecnología e Innovación​

Doctor y magíster en Física, especialista en Astrofísica de Altas Energía y físico.

Durante su recorrido profesional ha sido profesor asistente e investigador postdoctoral del Harvard-Smithsonian Center for Astrophysics y tutor del Laboratorio de Física Nuclear del MIT. Así mismo, es cofundador y director de Relaciones Institucionales de Clubes de Ciencia Colombia, y fundador y director de la iniciativa Latin America on Steam.

Fue integrante de la Misión Internacional de Sabios en 2019 y también se desempeñó como director de Capacidades y Divulgación de la Ciencia, la Tecnología y la Innovación del Ministerio de Ciencia, Tec​​nología e Innovación.

###### María Andrea De Villa Correa

Decana de la Escuela de Administración

María Andrea cuenta con una trayectoria académica de más de dos décadas dedicada a la docencia, la investigación, la gestión institucional, la consultoría y la cocreación de proyectos con el sector empresarial. Es doctora en Administración con énfasis en Estrategia de Cranfield University (Reino Unido); y magíster en Administración, especialista en Mercadeo y negociadora internacional de la Universidad EAFIT. Además, tiene estudios adicionales en formación ejecutiva en Global Strategic Management de Harvard University (Estados Unidos), y en Strategic Performance Management de University of Cambridge (Inglaterra).

Desde 2004, ha consolidado una destacada trayectoria en la Escuela de Administración de EAFIT, desempeñando roles directivos en programas de posgrado y liderando procesos de acreditación internacional. Su perfil académico tiene un fuerte componente global, habiendo sido profesora e investigadora visitante en instituciones de renombre en Estados Unidos, Inglaterra, Finlandia y Francia, lo que culminó en su nombramiento como profesora distinguida en 2024.

Como investigadora, es experta en estrategia de no-mercado y gestión de riesgos socio-políticos, con publicaciones en las revistas científicas más prestigiosas del campo de la administración. Su liderazgo internacional se refleja en su rol como editora y representante en organizaciones como la Strategic Management Society, además de haber sido galardonada con el Premio Ciencia, Tecnología e Innovación 2025 por su trayectoria de excelencia.

###### Ricardo Taborda Ríos

Decano de la Escu​ela de Ciencias Aplicadas e Ingeniería

Doctor en Ingeniería Civil y Ambiental, magíster en Ingeniería Civil y Estructural, magíster en Mecánica Estructural e ingeniero civil.

Su trayectoria académica y profesional se ha desarrollado en México y Estados Unidos, en instituciones de gran reconocimiento internacional. Ha trabajado en la División de Ingeniería Estructural del Instituto de Ingeniería de la Universidad Nacional Autónoma de México (UNAM), en el Strong Motion Research Group de la Universidad del Sur de California, en el Quake Group de la Universidad Carnegie Mellon, y en el Center for Earthquake Research and Information de la Universidad de Memphis.

Actualmente, hace parte del comité científico del Southern California Earthquake Center y se desempeña como editor asociado del Bulletin of the Seismological Society of America.

###### Verónica Uribe Hanabergh

Decana de la Escuela de Artes y Humanidades​

Doctora en Humanidades de la Universidad Pompeu Fabra de Barcelona (Summa Cum Laude) y posee un Diploma de Estudios Avanzados- Máster Europeo en Humanidades de la misma institución. Además, es licenciada en Artes con honores en Pintura y Bachelor of Arts de la Australian National University (Australia).

Trabajó como directora del Departamento de Historia del Arte de la Universidad de Los Andes y como profesora asociada por más de diez años de la misma universidad. Durante su trayectoria ha sido reconocida con distinciones como el Premio Julio González Gómez y el Golden Key International Honour Society de la Universidad Nacional de Australia.

Es autora de libros, capítulos, artículos y textos de divulgación sobre temas como el arte de la modernidad tardía, la historia del paisaje, la ecocrítica, el patrimonio cultural y el pensamiento estético. Se destaca por su participación como integrante de los comités científicos de las revistas: Pensamiento Estético e Historia del Arte, de la Universidad Nacional de Colombia en Medellín; Art in Translation, de la Universidad de Edinburgo (Escocia); Minius: Historia, Arte y Geografía, de la Universidad de Vigo, (España); y H-ART: Revista de historia, teoría y crítica de arte, de la Universidad de los Andes; y como integrante de diversas juntas directivas de instituciones reconocidas de artes y ciencias tanto nacionales como internacionales.

###### Esteban Hoyos Ceballos

Decano de la Escuela de Derecho

Doctor (J.S.D.) y magíster en Derecho (LL.M.) de la Universidad de Cornell, y abogado de la Universidad de los Andes.

En EAFIT ha ocupado diversos roles académicos y de liderazgo, entre ellos profesor, coordinador académico de la Maestría en Derecho, coordinador del grupo de investigación en Derecho y Poder, y cofundador y coordinador del semillero de investigación en Derecho Constitucional.

También ha sido profesor invitado en diferentes universidades nacionales y en instituciones académicas de España, México y Chile. Antes de vincularse a EAFIT, se desempeñó como auxiliar judicial de la Corte Constitucional Colombiana.

Sus principales áreas de interés incluyen el derecho y la teoría constitucional, los derechos económicos, sociales y culturales, la enseñanza del Derecho en América Latina, la educación jurídica clínica y el derecho de interés público, entre otros.

###### César Eduardo Tamayo Tobón

Decano de la Escuela de Finanzas, Economía y Gobierno

Doctor en Economía, magíster en Economía Internacional y economista.

Su trayectoria profesional incluye una amplia experiencia en organismos internacionales y entidades financieras. Estuvo vinculado al Banco Interamericano de Desarrollo (BID) como economista e investigador en diferentes divisiones y departamentos, y al Banco de la Reserva Federal de Estados Unidos.

También, se desempeñó como investigador en la Asociación Nacional de Instituciones Financieras (ANIF) y en el Departamento de Investigaciones y Estrategias de Bancolombia. Asimismo, ha sido profesor en la Universidad de Rutgers y en la Universidad de los Andes.

###### Maria Claudia Gómez Cabana

Secretaria General

La secretaria general encargada es abogada y magíster en Derecho, con énfasis en derecho admi​nistrativo, de la Universidad de Antioquia, y especialista en Derecho Comercial de la Universidad Externado de Colombia. Además, ha realizado varios cursos en estrategia, derecho adm​inistrativo y metodología de la investigación jurídica.​

En su recorrido profesional ha sido especialista y líder de procesos y actuaciones administrativas de Comfama, abogada senior de la Vicepresidencia Legal de UNE EPM Telecomunicaciones; así como oficial mayor de la Sala Cuarta de Decisión y oficial mayor de la Sala Tercera de Decisión del Tribunal Administrativo de Antioquia.

En el campo de la investigación hizo parte de un proyecto sobre el estudio de la fundamentalización del acceso al agua potable en Colombia, adscrita al Centro de Investigaciones Jurídicas de la Facultad de Derecho y Ciencias Políticas de la Universidad de Antioquia.​

###### Isabel Gutiérrez Ramírez

Directora de Estrategia

Graduada en Derecho y en Ciencias Políticas de la Universidad EAFIT, especialista en Derecho Laboral y Seguridad Social de la Universidad Pontificia Bolivariana, y magíster en Estudios Latinoamericanos del Instituto Ortega y Gasset de Madrid, España y magíster en Estudios del Comportamiento.

En su trayectoria profesional ha sido directora de EAFIT Bogotá, investigadora del Área de Seguridad y Defensa de la Fundación Ideas para la Paz, coordinadora de Seguridad Ciudadana y Justicia Juvenil en la Oficina de Naciones Unidas contra la Droga y el Delito (UNODC), coordinadora del Programa de Atención a Víctimas de la Gobernación de Antioquia, asesora de la Decanatura de Humanidades de EAFIT y directora delegada de Rectoría. Actualmente, es la directora de Estrategia, dependencia que busca contribuir a la transformación y crecimiento territorial de EAFIT.

###### Ricardo Uribe Marín

Director de Desarrollo Humano-Bienestar Universitario

Magíster en Ingeniería Industrial e ingeniero de Producción. Actualmente cursa un doctorado en Administración.

Está vinculado a la Universidad desde 2001, periodo en el que ha ejercido como jefe del pregrado en Administración de Negocios y del Departamento de Organización y Gerencia. Asimismo, fue representante principal de los profesores ante el Consejo de la Escuela de Administración.

A lo largo de su trayectoria académica ha recibido varios reconocimientos, entre ellos, el de mejor profesor de Contaduría Pública en 2012 y el de Docente que Inspira en 2018. Sus áreas de conocimiento se centran en la administración de operaciones, la gerencia estratégica de costos y el aprendizaje experiencial.

###### ​Luis​​Eduardo Martínez Flórez​

Director de Finanzas y Servicios Corporativos

Es MBA de la Escuela de Negocios HEC de Montreal (Canadá), economista y negociador internacional de la Universidad EAFIT, además de especialista en Finanzas. Complementó su formación con estudios en Gerencia Administrativa en la Universidad del Rosario-CES, en estrategia y liderazgo en McGill, en gestión de riesgos en Harvard y en estrategia corporativa en Chicago Booth.

A lo largo de su trayectoria profesional, ha trabajado en compañías como Grupo Éxito, Lucca Capital y Grupo SURA, liderando áreas de finanzas, riesgos, relación con inversionistas, planeación, estrategia, nuevos negocios, proyectos e innovación. En Grupo SURA fue responsable de la creación del programa de Venture Corporativo y del programa de innovación, que impulsaron el nacimiento de nuevos negocios como Nubloq y ViliV.

Su experiencia incluye también una destacada participación en el gobierno corporativo, como miembro de juntas directivas en Sodexo Colombia, Hábitat (negocio de arrendamientos de Coninsa) y en la plataforma de pagos de eventos La Tiquetera.

###### Isabel Cristina Gómez Yepes

Directora de Desarrollo Institucional y Vínculos

Comunicadora y Relacionista Corporativa de la Universidad de Medellín, especialista en Estudios Políticos, y magíster en Administración y en Estudios del Comportamiento de la Universidad EAFIT.

En su trayectoria laboral en EAFIT ha creado y coordinado la Escuela de Verano, además de liderar el Centro de Graduados. En el sector público se desempeñó como comunicadora de proyectos estratégicos en la Alcaldía de Medellín. Actualmente, es la directora de Desarrollo Institucional y Vínculos de la Universidad.

###### Tomás Ríos Múnera

Director del Centro de Emprendimiento de Impacto On.goin​g

Administrador de negocios y especialista en Mercadeo de EAFIT.

Su trayectoria laboral le ha permitido liderar empresas como Agrilink, Starter Company, Stap Antioquia, El Cielo cocina creativa y desarrollar plataformas de conexiones presenciales y virtuales como StartCo Medellín y Caribe, Start TV. Además, creó en alianza con Innpulsa Colombia, el programa Las 51 Starter.

También ha sido cofundador de diferentes emprendimientos como STAP Antioquia, Línea de Aseo y Starter Company, además acompaña y mentorea emprendedores en estructuración de modelos de negocio, escalabilidad y conexiones de valor, lo que le ha permitido invertir en algunos de estos.

Actualmente es el director del Centro de Emprendimiento On.going.

###### ​Felipe Estrada Prada

Director d​e Atracción y Experiencia​​

Es magíster en Administración y administrador de empresas de la Universidad de los Andes; máster en Tecnología, Innovación y Educación de Harvard Graduate School of Education; y cuenta con más de 22 años de experiencia en temas de estrategia, tecnología, educación y transformación de desafíos empresariales en oportunidades tecnológicas.

En su recorrido profesional se ha desempeñado como consultor país en edtech para RTI International para Jacobs Foundation (2023-2024); líder de producto en CoSchool (2024) y de diseño de experiencias de aprendizaje en Platzi.com (2023); tecnólogo senior de​​ aprendizaje del Laboratorio de Enseñanza y Aprendizaje de Harvard Graduate School of Education (2020-2023); director del Centro de Emprendimiento de la Universidad de los Andes (2011-2019); y analista senior de investigaciones de C3 Comunicaciones Ltda (2005-2009).

También es fundador de la compañía TradAcademy, especializada en traducciones académicas; se ha destacado por sus labores como conferencista, voluntario en temas de estrategia para CoSchool; instructor de Coursera; y obtuvo reconocimiento como profesor innovador de la Universidad de los Andes.

###### Catalina Suárez Restrepo

Jefa del Departamento de Comunicación

Magíster en Gerencia de la Innovación y el Conocimiento, especialista en Comunicación Política de EAFIT y comunicadora social-periodista de la Universidad Pontificia Bolivariana.

Su trayectoria laboral comenzó en el periódico El Colombiano, en el cubrimiento de las elecciones presidenciales de 2002, y posteriormente en el área de Informes Comerciales. Durante cuatro años se desempeñó como periodista de educación superior en este medio.

En enero de 2008 inició su recorrido en EAFIT como coordinadora del Área de Información y Prensa del entonces Departamento de Comunicación y Cultura, cargo en el que permaneció hasta 2013, año en el que asumió la jefatura del Departamento de Comunicación hasta la actualidad. Desde esta posición ha liderado la consolidación del sistema de medios de la Universidad, ha fortalecido la reputación institucional y el proyecto de sostenibilidad de EAFIT, ha estrechado los vínculos con los diferentes grupos de interés y ha acompañado, desde la comunicación, los procesos de transformación de la Institución.

###### Shirley Zuluaga Cosme

Jefa del Departamento de Cultura

Magíster en Administración, especialista en Mercadeo Gerencial y comunicadora y relacionista corporativa de la Universidad de Medellín.

Cuenta con una sólida trayectoria en la gestión cultural, patrimonial y educativa, que incluye roles como directora de la Biblioteca Pública Piloto de Medellín para América Latina; subsecretaria de Bibliotecas, Lectura y Patrimonio de Medellín; directora de la Red de Escuelas de Música; jefa de producción de la VI Fiesta del Libro y la Cultura; subdirectora de Patrimonio y Fomento Artístico y Cultural del Instituto de Cultura y Patrimonio de Antioquia; y directora del Teatro Gabriel Obregón Botero de la Universidad de Medellín.

###### Nora Quiceno Metaute

Coordinadora de proyectos rectoría

Administradora de Empresas con Especialización en Gerencia Educativa y Maestría en Administración de Empresas. Cuenta con sólida experiencia en el sector público y en la gestión de proyectos en contextos educativos, administrativos y sociales. Se ha desempeñado en entidades como Comfama, el Metro de Medellín y la Alcaldía de Medellín, liderando procesos de planificación, ejecución y seguimiento de proyectos, coordinación presupuestal y articulación interinstitucional.

Su enfoque estratégico y habilidades interpersonales le han permitido generar soluciones efectivas orientadas al cumplimiento de metas institucionales y al desarrollo organizacional.

###### Vicerrecto​​rías

Según los Estatutos Generales la Universidad tendrá las Vicerrectorías que, en su momento, considere necesarias y apruebe su creación el Consejo Superior, con base en propuesta que presente la Rectoría. ​

**En la actualidad EAFIT cuenta con dos vicerrectorías:**

###### Antonio Julio Copete Villa

Vicerrector de Ciencia, Tecnología e Innovación

Doctor y magíster en Física, especialista en Astrofísica de Altas Energía y físico.

Durante su recorrido profesional ha sido profesor asistente e investigador postdoctoral del Harvard-Smithsonian Center for Astrophysics y tutor del Laboratorio de Física Nuclear del MIT. Así mismo, es cofundador y director de Relaciones Institucionales de Clubes de Ciencia Colombia, y fundador y director de la iniciativa Latin America on Steam.

Fue integrante de la Misión Internacional de Sabios en 2019 y también se desempeñó como director de Capacidades y Divulgación de la Ciencia, la Tecnología y la Innovación del Ministerio de Ciencia, Tec​​nología e Innovación.

##### Líderes de la Vicerrectoría

**Innovación y Desarrollo Tecnológico**

**Oficina de Inteligencia ​en CTeI**

Germán Augusto Tabares Pozos

Coordinador [gtabare2@eafit.edu.co​​](mailto:gtabare2@eafit.edu.co%E2%80%8B%E2%80%8B)

**Universidad de los N​iños**

###### Paola Podestá Correa

Vicerrectora de Aprendizaje

La vicerrectora de aprendizaje, es magíster en Ciencias de la Administración y administradora de negocios. Además, está cursando un doctorado en Ciencias Económicas y Administrativas.

Durante su trayectoria en la Universidad, se ha desempeñado como jefa del Departamento de Negocios Internacionales, directora de Inteligencia de la spin off Laboratorio de Entretenimiento Inteligente, coordinadora de la especialización en Gerencia de Negocios Internacionales, directora académica de Innovación y coordinadora académica de Emprendimiento.

Fuera de la academia, ha trabajado para organizaciones como Citibank Colombia, la Orquesta Sinfónica de Antioquia y la aerolínea Aces. En la actualidad también hace parte del Grupo de Investigación en Innovación, Empresarismo y Sostenibilidad.​

##### Líderes de la Vicerrectoría

###### Escu​​elas​

Son unidades de carácter académico-administrativo, organizadas alrededor de áreas de conocimiento afines entre sí, y responsables de la gestión administrativa de las áreas académicas adscritas y de la orientación académica de los programas de pregrado y de posgrado que ofrecen.

**​EAFIT cuenta con cinco escuelas:**

###### María Andrea De Villa Correa

Decana de la Escuela de ​Administración

###### Ricardo Taborda Ríos

Decano de la Escuela de Ciencias Aplicadas e Ingeniería

###### Verónica Uribe Hanabergh

Decana​ de la Escuela de Artes y Humanidades

###### Esteban Hoyos Ceballos

Decano de la Escuela de Derecho

###### César Eduardo Tamayo Tobón

Decano de la Escuela de Finanzas, Economía y Gobierno

###### Secretaría General

Tiene como propósito garantizar la transparencia en la Institución y el buen funcionamiento de todos sus procesos. Brinda a las dependencias académicas y administrativas un acompañamiento integral en gobierno corporativo y en los asuntos contractuales y procesales.​

###### María Claudia Gómez Cabana

Secretaria general

Abogada y magíster en Derecho con énfasis en Derecho Administrativo de la Universidad de Antioquia, y especialista en Derecho Comercial de la Universidad Externado de Colombia. Además, ha realizado cursos en estrategia, derecho administrativo y metodología de la investigación jurídica.

En su recorrido profesional se ha desempeñado como especialista y líder de procesos y actuaciones administrativas en Comfama, abogada senior de la Vicepresidencia Legal de UNE EPM Telecomunicaciones, y oficial mayor de la Sala Cuarta de Decisión y de la Sala Tercera de Decisión del Tribunal Administrativo de Antioquia.

En el ámbito académico y de investigación, participó en un proyecto sobre la fundamentalización del acceso al agua potable en Colombia, adscrito al Centro de Investigaciones Jurídicas de la Facultad de Derecho y Ciencias Políticas de la Universidad de Antioquia.

Actualmente, es la Secretaria General de EAFIT.

###### Direcciones​​​ y departamentos

Son dependencias responsables del diseño, la planeación, la programación, la ejecución y el control de distintos procesos de naturaleza académica o administrativa de la Universidad.

**EAFIT cuenta en la actualidad con las siguientes direcciones y departamentos:**

###### Director d​e Atracción y Experiencia​​​

Felipe Estrada Prada

Es magíster en Administración y administrador de empresas de la Universidad de los Andes; máster en Tecnología, Innovación y Educación de Harvard Graduate School of Education; y cuenta con más de 22 años de experiencia en temas de estrategia, tecnología, educación y transformación de desafíos empresariales en oportunidades tecnológicas.

En su recorrido profesional se ha desempeñado como consultor país en edtech para RTI International para Jacobs Foundation (2023-2024); líder de producto en CoSchool (2024) y de diseño de experiencias de aprendizaje en Platzi.com (2023); tecnólogo senior de​​ aprendizaje del Laboratorio de Enseñanza y Aprendizaje de Harvard Graduate School of Education (2020-2023); director del Centro de Emprendimiento de la Universidad de los Andes (2011-2019); y analista senior de investigaciones de C3 Comunicaciones Ltda (2005-2009).

También es fundador de la compañía TradAcademy, especializada en traducciones académicas; se ha destacado por sus labores como conferencista, voluntario en temas de estrategia para CoSchool; instructor de Coursera; y obtuvo reconocimiento como profesor innovador de la Universidad de los Andes.

###### Jefa del Departamento de Comunicación

Catalina Suárez Restrepo

Magíster en Gerencia de la Innovación y el Conocimiento, especialista en Comunicación Política de EAFIT y comunicadora social-periodista de la Universidad Pontificia Bolivariana.

Su trayectoria laboral comenzó en el periódico El Colombiano, en el cubrimiento de las elecciones presidenciales de 2002, y posteriormente en el área de Informes Comerciales. Durante cuatro años se desempeñó como periodista de educación superior en este medio.

En enero de 2008 inició su recorrido en EAFIT como coordinadora del Área de Información y Prensa del entonces Departamento de Comunicación y Cultura, cargo en el que permaneció hasta 2013, año en el que asumió la jefatura del Departamento de Comunicación hasta la actualidad. Desde esta posición ha liderado la consolidación del sistema de medios de la Universidad, ha fortalecido la reputación institucional y el proyecto de sostenibilidad de EAFIT, ha estrechado los vínculos con los diferentes grupos de interés y ha acompañado, desde la comunicación, los procesos de transformación de la Institución.

###### Jefa del Departamento de Cultura

Shirley Zuluaga Cosme

Magíster en Administración, especialista en Mercadeo Gerencial y comunicadora y relacionista corporativa de la Universidad de Medellín.

Cuenta con una sólida trayectoria en la gestión cultural, patrimonial y educativa, que incluye roles como directora de la Biblioteca Pública Piloto de Medellín para América Latina; subsecretaria de Bibliotecas, Lectura y Patrimonio de Medellín; directora de la Red de Escuelas de Música; jefa de producción de la VI Fiesta del Libro y la Cultura; subdirectora de Patrimonio y Fomento Artístico y Cultural del Instituto de Cultura y Patrimonio de Antioquia; y directora del Teatro Gabriel Obregón Botero de la Universidad de Medellín.