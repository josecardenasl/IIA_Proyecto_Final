# Doble titulación con Universidad Carlos III

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Convenio de doble titulación – Universidad Carlos III de Madrid

###### ​​Jesus David Moreno Muñoz - D​​​irector de la Maestría en Finanzas​​​​ de la Universidad Carlos III de Madrid​​​​​​​​​

Con este convenio los alumnos recibirán tanto el título de MAF EAFIT como el de MIF de la Universidad Carlos III de Madrid.

A continuación compartimos algunas características de este convenio:

###### El convenio:

Establecer una doble titulación entre la Maestría en Administración Financiera (MAF) de EAFIT y el Master in Finance (MIF) de la Universidad Carlos III de Madrid en España.

El estudiante iniciará sus estudios en la Especialización en Finanzas y luego de dos (2) semestres se podrán matricular, una vez admitidos, en el Master in Finance de la Universidad Carlos III de Madrid para la segunda parte del programa de doble titulación, donde tomarán dos (2) semi-cuatrimestres adicionales.

Los estudiantes deben tomar un total de 27 créditos ECTS así como el Trabajo Final de la Maestría (TFM) con 6 créditos.

La Universidad EAFIT hará una selección previa de los estudiantes.

Se aceptarán un máximo de dos (2) estudiantes por año académico siempre y cuando cumplan con los requisitos generales establecidos.

###### Beneficios:

La UC3M aplicará una bonificación de 10% del coste total de la matrícula.

Los estudiantes de la EAFIT mientras dure su estancia en la UC3M serán titulares de todos los derechos correspondientes a su condición de estudiantes de la misma, tales como acceso a biblioteca, instalaciones deportivas, y demás servicios comunes, quedando igualmente sometidos a las normas de permanencia aplicables al resto de alumnos de la MIF.

###### Testimonio:

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)