# Doctorado en Administración - EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Search 

Búsqueda

Menú

Posgrado

# Doctorate Degree in Business Administration

SNIES 20820, Medellin

If your vocation is to create knowledge, understand how organizations are administered and deepen their operation and in the new challenges in the ways of administering, and you also have passion to study, learn, focus on a research, read and reflect question, this doctorate is the one indicated for you.

*    Doctorate Degree In Business Administration 

## Registro califica​do

Resolución 09002 del 5 de junio de 2018. Vigencia por 7 años. Modificado por la resolución 8221 del ​18 de mayo de 2021​.

Duration

4 years

Location

Medellin

Schedule

Exclusive dedication. Three days every two weeks from 8:00 a.m. at 12:00 m.

Language

Spanish

Modality 

In Person 

SNIES

SNIES 20820

Total Program Cost

$ 142.894.285

## Sobre el programa

Calidad y excelencia

**Los de más experiencia**

Fuimos el primer Doctorado en Administración de Colombia, creado hace 20 años en cooperación con la École des Hautes Études Commerciales (HEC) Canadá. Contamos con la reacreditación de Alta Calidad: solo tres programas similares, de más de veinte, cuentan con este sello en el país.

Somos uno de los doctorados en Administración más grandes del país, con más de 50 estudiantes activos y más de 40 graduados.

Todos nuestros profesores son investigadores con reconocida trayectoria internacional, con gran experiencia en investigación, editores en revistas de prestigio y con buenas conexiones internacionales que ponen al servicio de los estudiantes.

Conexiones e incidencia

**Buenas conexiones internacionales**

Hacemos parte de la European Doctoral Programs Association in Management & Business Administration, EDAMBA, una red europea de doctorados en la que solo cuatro programas en Latinoamérica han sido aceptados.

Como parte de la Universidad EAFIT, estamos acreditados por The Association to Advance Collegiate Schools of Business (AACSB International), la alianza más grande para la educación.

Hacemos parte de la Escuela de Administración de EAFIT, reconocida como la primera escuela de negocios en recibir acreditación de alta calidad en Latinoamérica por parte de The Business Graduates Association (BGA).

Aprendizaje vivo y activo

**Un Doctorado en conversación con otros**

Nuestros estudiantes y profesores vienen de diferentes lugares del país, y también de países como Chile, Perú, España y EE.UU.

Es un Doctorado que busca crear comunidad y conversación académica a través de coloquios internos, eventos internacionales y otras actividades organizadas en EAFIT. Contamos con buenas redes con otros eventos y universidades en el mundo para compartir nuestro quehacer investigativo.

Innovación y liderazgo

**Cultivamos la investigación de talla global**

Te formarás como un investigador autónomo de alta calidad, teniendo en cuenta el contexto específico y las particularidades de América Latina para generar nuevo conocimiento de alcance mundial, relevante para impactar a nuestra sociedad y nuestras organizaciones.

Nuestros estudiantes desarrollan una caja de herramientas amplia y confiable con competencias y técnicas de investigación, y de comunicación de la ciencia. Evidencia de ello es que, en los últimos años, duplicamos la producción académica de los estudiantes del programa, que a pesar de su corto tiempo de publicación, tienen más de siete citas en promedio. Contamos con el respaldo de grupos de investigación de alta calidad: cuatro en categoría A1 y dos en categoría A en Colciencias.

**El centro es el estudiante**

La dedicación al Doctorado es de tiempo completo, para que los estudiantes puedan dedicarse a su investigación doctoral y atender los compromisos del programa. Para ello, cuentan con becas y opciones de financiación interna para realizar pasantías, electivas y seminarios a nivel internacional.

Este Doctorado está enfocado en el estudiante y en potenciar y apoyar su desarrollo de forma flexible, sin importar el área de investigación escogida: administración, contaduría, mercadeo, negocios internacionales, estrategia, estudios organizacionales, u otros.

Acreditaciones

###### Importante

La Universidad se reserva el derecho de iniciar las cohortes de formación avanzada solo en tanto se haya matriculado el número de aspirantes necesarios. En caso de no dar inicio a una cohorte, EAFIT reintegrará el 100% de los derechos académicos que el aspirante haya cancelado.

EAFIT es acreditada por AACSB International - The Association to Advance Collegiate Schools of Business, [www.aacsb.edu](https://www.aacsb.edu/)

El Doctorado en Administración de EAFIT es miembro de European Doctoral programs Association in Management & Business Administration, [EDAMBA](https://edamba.eu/).

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Becas y financiación

## **Guía de aspirantes posgrados**

Registration

###### Register and make the payment

**Registration dates: August 26 to November 29, 2024.**

###### a. Registration process

Any professional who has completed bachelor level studies or a program at a national or foreign university recognized by competent state educational authorities may apply for admission to postgraduate programs, while technicians, technologists or specialized technologists are not eligible. If you have been enrolled in a higher education institution, other than EAFIT, in a postgraduate program, you must apply for **External Transfer** admission, regardless of whether you wish to request subject recognition. First time applicants should select **First time studies** in type of applicant box, in [**EPIK self-service**](https://www.eafit.edu.co/epik), module **"Undergraduate and Postgraduate Registration"**.

If you have been enrolled in an undergraduate or graduate program at EAFIT, the system will provide you with a list of the types of admission that will apply, depending on the program selected. If the system does not show you any type of admission, please contact us via email ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) with your full name, identification document type and number, and indicate the program of interest, the city where you are going to study and the name of the program you will be taking at EAFIT.

To register, enter the **Registration** module by clicking [**here**](https://www.eafit.edu.co/inscripciones), press the P.I button. Start your registration here, and proceed to fill out the form. Enter all the required data.

Enter [**here**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), click on the button **Learn about our Postgraduate offering and learn about our programs available** for the **2025-1** semester.

###### b. Registration payment

**Registration fee:****$341.700** (approximately $82 USD).

After successfully submitting your registration request, go to the end of the form and proceed to make your payment. If you filled out the form and are going to make the registration payment later, enter the [**EPIK self-service**](https://www.eafit.edu.co/epik), **"My Finances"** module, **"Payment Center"** option, where the system shows the payment document. Select it and activate the **Pay Online** button.

You can pay the registration fee online, with a credit or debit card through one of the banks registered in PSE. Do not close the page until the bank reports that your transaction was successful. Afterwards, look for the return option.

If you cannot pay online, click on Download PDF, print receipt on a laser printer and and make an in-person payment at any authorized bank nationwide: Bancolombia, Davivienda, Banco de Bogotá, AV Villas and Banco de Occidente.

If you have difficulty generating the payment document, send an email to [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

If you have trouble making the payment, send an email to [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

Payments abroad can be made through bank transfer; to obtain the University account information, contact the Support area, contact the finance department at [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co).

Once the payment is made, the system will send it to the email registered to the dilig. Send your registration form, a notification informing you of the confirmation of registration and the procedures you must follow to continue with your admission process.

Requirements

###### Attach your documents with your registration form

###### a. List of documents

If you have made your registration payment, attach your documents online through the [**EPIK self-service**](https://www.eafit.edu.co/epik), in the **"Document Annex"** module. The system will show you the documents that you must attach, depending on the program and type of admission; files should be JPG, TIF or PDF type, with a size is between 1 Kb and 12 Mb.

**Document****First time applicant****External Transfer****EAFIT University Graduate**
Original or scanned Undergraduate degree certificate issued by the University with the corresponding signatures. If your degree is from abroad, attach your diploma as well, and its translation into Spanish.Yes. It is required  for admission.Yes. It is required  for admission.No.
Photocopy of both sides of identification document amended vertically at 150% on the same page or sides or on the digital document.Yes. It is required  for admission.Yes. It is required  for admission.Only if you do not already have it updated in Admissions and Records.
For external transfer request: Personal letter addressed to Admissions and Records that clearly states the reasons why you wish to make the external transfer and indicates if you are requesting subject recognition. In case of recognition, list the subjects you wish to be recognized.No.Yes. It can be attached online in the module Annex of documents. Required for admission.No

###### b. Additional requirements

Click [**here**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), click on the button **Learn about our Graduate Programs** and learn about the available programs for the 2025-1 semester, schedules and additional requirements if applicable.

###### c. External transfers with subject recognition

For the recognition of subjects, applicants for external transfer must bring the certificates listed below to the interview; and attach the following to the registration form:

**Document****External Transfer**
Certificate from the university of origin, with letterhead and corresponding signatures, indicating the subjects taken with their grade and time intensity.Yes. Attached to the Registration.
Syllabus with detailed contents of the subjects to be recognized by EAFIT, duly certified with the signature and seal of the university of origin.Yes. To be handed in person to the interviewer.
For recognition of subjects currently being studied, a duly certified letter from the university of origin, on letterhead with the corresponding signatures must be attached, indicating hour intensity, syllabus with detailed contents. Recognition is conditional on the final grade obtained in the course, which must be attached with the certificate of qualifications.Yes. Attached to the registration form To. be submitted by January 10, 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Interview

###### Select your interview appointment (if applicable for the program)

Once we receive your registration payment, schedule your interview. To do this, enter the Self-service [**here**](https://www.eafit.edu.co/epik), go to the **"Services and certificates"** module, enter the **"Request for services"** option, and in the **"Requests Made"** section, access the **"Admission interview appointment"** service, select it and request your interview appointment.

**Important: please check both in-person and online availability.**

If no appointments are available, select the option **"I did not find an appointment"**, so we can proceed to create new spaces for you to later come and select one.

**If the program does not require an interview, the system will not present you with the "Admission Interview Appointment" service for selection.**

Admission

###### Check your admission result

The admission process begins on September 19, 2024, after which you will be notified regarding your admission status to the email provided in registration form.

You can also check your status by entering the [**EPIK Self-service**](https://www.eafit.edu.co/epik), **"Undergraduate Graduate Registration"** module and clicking on the **"Status"** field.

To be admitted, it is an essential requirement to have submitted all the required documentation and, if applicable, to have submitted your admission interview.

**Note:**foreign applicants who are admitted, must present their student visa that is valid for the academic period to which they will enroll.

Credit recognition

###### Credit recognition(if applicable for your type of admission)

For information regarding recognition of subjects in graduate programs, consult [**here**](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) the Graduate Academic Regulations of EAFIT University or with the director of the program to which you are applying.

Class Schedule

###### Check your class schedule and receipt

Once you are admitted and submit the required documentation, you will be registered based on the information provided by the program to which you were admitted.

Check your schedule through the EPIK Self-Service, by clicking [**here**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) and entering the "My Registration" module and then entering the "My Certificates" option.

Schedules will be assigned beginning May, based on the syllabus of each postgraduate program.

Tuition

###### Pay your tuition

Once you have registered for classes and generated the payment document, verify payment dates.

###### Check your payment document

Enter the EPIK Self-Service by clicking [**here**](https://www.eafit.edu.co/epik), select the **"My Finances"** module, go to **"Payment Center"**option and select the document under registration payment document.

If you have any difficulty with the payment, write to email [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Online payment

Verify in your bank if your debit or credit cards are authorized for online transactions as well the amounts allowed to prevent the transaction from being rejected.

To make the payment of your registration, enter through the [**EPIK Self-service**](https://www.eafit.edu.co/epik) with username and password; in the **"My finances"** module, go to the **"Payment Center"**option and in the **"Online payment"** button, go directly to the PlacetoPay platform which allows payment with multiple credit and/or debit cards.

Full payment must be made to conclude the process successfully and be registered as an active student.

Do not close the page after the bank confirms your transaction, and return to the University website to confirm your payment, otherwise, the information will not be recorded in our database.

###### Payment in banks

In person payment can be made at the following authorized banks nationwide: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas and Banco de Occidente.**

A laser printed copy of the payment document that allows barcodes to be scanned must be presented at Banco de Bogotá offices, or a digital registration copy on your cell phone or tablet.

Banks receive payment in cash and/or checks made payable to EAFIT University.

If payments are made with checks, student identification number, phone number and the amount to be payed must be written on the reverse side of the check.

Banks will only accept payments for the total tuition fee stipulated on the document.

Tuition must be paid in full in order to acquire the status of active student.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

For additional information, call our service line (604) 2619500 or write to: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Payment of invoices by a Company

If payment is made a Company that requires an invoice in its name, keep in mind the types of invoices that can be issued to a Company:

**Cash:**in this case, the Company must make the payment immediately.

**Credit:**the company requires a 30-day term to pay prior to a credit approval.

The company invoicing process must be carried out here.

Los documentos que se deben de anexar son:

1.   Letter on company stationery with letterhead in which the Company authorizes  EAFIT University to send them an invoice for tuition, readjustments, additional enrollment, inter-semestral course or internship validation signed by the **Legal Representative** or the head of **Human Resources**, and in no case, by the student.
2.   RUT (Tax Registración Number).
3.   Certificate of existence of the Company issued by the Chamber of Commerce.
4.   The letter must contain information such as Tax identification number (NIT), Company name, address, email where they receive electronic invoice, amount to be billed, and indicate if invoice is to be paid by cash or credit.

Under no circumstances, should payments be made in a personal capacity, that is, in the name of the student, In such cases we will not be able to issue a receipt or register the payment in the name of the Company.

To learn about other payment methods, click [**here**](https://www.eafit.edu.co/becas-y-financiacion).

If you need support with any payment method, please write to [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co).

###### Payment at the cash teller - EAFIT Treasury

Mixed Payments that include cards and checks can be made at the Treasury Offices as follows:

1.   Credit Card + Check.
2.   Credit Card + Cash.

###### Educational financial aid 'EAFIT at your fingertips'

Applicants admitted who financial aid may apply for short and long-term loans.

This initiative also contemplates a semester quota in which priority will be given to those with the best academic merits.

For more information on financial aid, write to [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co), contact our customer service line (604) 2619500 or consult the following website [**here**](https://www.eafit.edu.co/becas-y-financiacion).

Student ID

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Begin your registration process

The process has a cost of $341.700 COP.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

## Nuestras acreditaciones

### También te puede interesar

#### Master's Degree in Financial Management- MAF - Cali

Duration

3 semesters

Location

Cali

Schedule

Friday and Saturday

Más información

Friday from 5:00 p.m. at 9:00 p.m. and Saturdays from 8:00 a.m. at 12:00 m

Language

Spanish

Modality 

In Person 

Más información

Face -to -face at the San Buenaventura University.

SNIES

SNIES 101293

Total Program Cost

$ 47,522,385

#### Master's Degree in Agricultural Business - Medellin

Duration

3 semesters

Location

Medellin

Más información

EAFIT University (Medellín - Colombia) and University of Zamorano (Honduras)

Schedule

Synchronous and asynchronous meetings

Language

Spanish

Modality 

Mixed

SNIES

SNIES 109910

Total Program Cost

$63.000.000

### **Noticias**

## Liderar para generar impacto: decisiones que transforman personas, equipos y oportunidades

May 12, 2026

## Debate global con sello estudiantil

April 7, 2026

## De una inspiración a la competencia internacional

March 16, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Institutional Accreditation until 2026.

Supervised by Ministry of Education.

Our campuses

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National line: 01 8000 515 900

Service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Service line: (57) 606 3214115, 606 3214119

Carrera 15 #88-64 oficina 401

Service line: (57) 601 6114618

Km 3.5 vía Don Diego – Rionegro

## Utilizamos cookies en este sitio web para mejorar su experiencia de usuario.

Al hacer click en Aceptar, otorga su consentimiento para que establezcamos cookies. [Conoce la política de datos personales](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Aceptar No, gracias