# Declaración por la Integridad y e​l Resp​​eto - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Declaración por la Integridad y e​l Resp​​eto

Una reflexión sobre las relaciones interpersonales en pro ​de una comunidad segura, a partir de lazos de confianza.

*    Declaración Por La Integridad y E​l Resp​​eto 

Han sido meses complejos y retadores para todos. En muy poco tiempo, nos vimos llamados a repensarnos como Universidad. Así, para dar continuidad a los proyectos académicos, investigativos y de proyección social necesitamos -cada uno desde el rol que desempeñamos- adaptarnos a nuevas formas de trabajo, de comunicación y de enseñanza-aprendizaje, con el fin de que se lograran los objetivos trazados por la Institución al inicio de 2020.

Con las lecciones de los últimos meses hemos enfrentado un nuevo reto, donde aún nos acompaña la incertidumbre, pero también la esperanza de que juntos continuaremos avanzando en el proyecto de Universidad EAFIT, con el compromiso, la responsabilidad y la integridad como faro.

En ese contexto, abordaremos las siguientes reflexiones a lo largo de los próximos meses, con la convicción de que se trata de un trabajo en construcción que permitirá complementarse y enriquecerse en el tiempo. Este trabajo implicará volver la mirada sobre la manera de relacionarnos y de trabajar colectivamente con base en la confianza en el otro (a) y en la Institución, con la finalidad de contribuir a convivir en un espacio seguro, donde el respeto sea el eje a partir del cual nos aproximemos a los otros.

## Relación profesor-alumno

Retos y lecciones aprendidas. Guía y recomendaciones relación profesor-estudiante.

## Relación entre estudiantes

Retos y lecciones aprendidas. Gu​ía y recomendaciones relación entre estudiantes

## Relación entre compañeros de trabajo

Retos y lecciones aprendidas. Guía y recomendaciones entre compañeros de trabajo.

En la Universidad nos mueve el deseo de generar un ambiente confiable y seguro en el que todos nos sintamos respetados y en el que ninguna persona de la comunidad eafitense sienta temor o exclusión por motivos asociados al género, la orientación sexual, la raza, la ideología, las creencias o cualquier tipo de opción personal. Para lograr un ambiente de armonía y sana convivencia es fundamental que desde el rol que desempeñemos nos comprometamos a garantizar la tranquilidad de cada uno de los integrantes de la Institución. Una transformación cultural requiere del compromiso de cada un​o. Confiamos en que juntos lograremos aportar desde EAFIT a la construcción de una sociedad más respetuosa, justa e incluyente.

###### Referencias

CORTINA, A., (1986), Ética mínima, introducción a la filosofía práctica, Madrid, España: Tecnos.

​Pontificia Universidad Católica de Chile. [Lineamientos y recomendaciones a la planta académica para la prevención de hechos de violencia sexual en la relación con estudiantes](https://universidadeafit.widen.net/s/hczkpnxtdb/lineamientos-planta-academica-03092018).

Universidad Tecnológico de Monterrey. [Protocolo de actuación para la prevención y atención de violencia de género en el Instituto Tecnológico y de Estudios Superiores de Monterrey](https://universidadeafit.widen.net/s/cf9chtfmxr/protocolo-violencia-de-genero).

Universidad EAFIT. Protocolo para la Equidad de Género y Sexualidad Diversa.

​Universidad de Harvard. [Sexual and Gender Based Harrasment Policy](https://universidadeafit.widen.net/s/nmrmgwxs5j/fas-p-and-p-combined-2014-2020).

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)