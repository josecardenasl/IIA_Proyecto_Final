# Requisitos de los candidatos como representantes estudi​​​antiles de pregrado a los cuerpos colegiados - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Requisitos de los candidatos

###### como representantes estudi​​​antiles de pregrado a los cuerpos colegiados

*    Requisitos de Los Candidatos Como Representantes Estudi​​​antiles de Pregrado A Los Cuerpos Colegiados 

Los estudiantes que cumplan con los siguientes requisitos podrán inscribir sus candidaturas como representantes estudiantiles a los cuerpos colegiados.

1.   Estar matriculados en un programa de pregrado de la Universidad EAFIT.
2.   Acreditar un promedio crédito acumulado igual o superior a tres punto siete (3.7).
3.   No haber sido sancionado disciplinariamente por haber cometido una falta clasificada como grave, de acuerdo con el procedimiento consagrado en el Reglamento Académico de Pregrado de la Institución.
4.   No tener la condición de empleado ni de contratista vinculado por medio de contrato de prestación de servicios con la Universidad EAFIT. Se exceptúa el período de práctica y el contrato de auxiliar de investigación.
5.   Haber aprobado al menos treinta (30) créditos académicos del respectivo plan académico. En el caso de los estudiantes que hayan estado en convenio de intercambio o movilidad independiente, la homologación de los créditos deberá estar dispuesta en el sistema de Registro Académico para su validación.
6.   No tener asiento en la junta directiva de algún Grupo Estudiantil.
7.   No haber sido inhabilitado por el Comité Electoral Universitario.

Para inscribir su candidatura como representante estudiantil al Consejo Directivo o al Consejo Académico, los estudiantes interesados, además de los anteriores requisitos, deberán haber cursado y aprobado más de treinta por ciento (30%) de los créditos de su programa de pregrado.

Para inscribir su candidatura como representante estudiantil al Comité de Ciencia, Tecnología e Innovación, los estudiantes interesados, además de los anteriores requisitos, deberán ser integrantes activos de un semillero o grupo de investigación de la Universidad EAFIT, con al menos un (1) año de permanencia y deberán haber cursado y aprobado más de treinta por ciento (30%) de los créditos de su programa de pregrado.

El candidato principal y el(los) suplente(s) deben asegurarse de que sus compromisos derivados de movilidades académicas o semestre de práctica no coincidan en el mismo semestre durante la época en la cual se ejercería la representación, con el fin de evitar que el cuerpo colegiado respectivo quede sin representación.

##### Procedimiento para realizar el proceso de inscripción de los candidatos

Los interesados en postularse como candidatos a los diferentes cuerpos colegiados, deberán solicitar la inscripción de su candidatura entre el 20 de marzo y el 12 de abril de 2026, de lunes a viernes entre las 8:00 a.m. y las 3:00 p.m. a través del formulario dispuesto en el siguiente [enlace](https://forms.office.com/r/Ngbzb8x3B6), el cual debe ser diligenciado por uno de los candidatos:

Solo serán analizadas aquellas postulaciones presentadas a través del enlace mencionado y que sean diligenciadas de manera completa.

La solicitud de la inscripción de la candidatura deberá contener los siguiente:

1.   Nombres y apellidos completos de los candidatos, indicando quién será el principal y quién será el suplente. Para el caso de los estamentos que tienen dos suplentes, se deberá indicar quien será el suplente uno (1) y el suplente dos (2).
2.   Programa de pregrado o posgrado al que pertenecen.
3.   Cuerpo colegiado al que se postulan.
4.   Un plan de trabajo en el cual se detallen las propuestas, con el fin de informarlo al público estudiantil, y el cual será publicado en los canales institucionales avalados e informados por el Comité Electoral Universitario.
5.   Firma del candidato principal y el suplente en el plan de trabajo.
6.   Los candidatos al Comité de Ciencia, Tecnología e Innovación, deberán anexar hoja de vida o currículo vitae del candidato y del suplente, que contenga:

•Fecha de vinculación a grupo y/o semillero de investigación.

•Participación en semilleros o grupos de investigación.

•Participación en proyectos de ciencia, tecnología e innovación.

•Producción de nuevo conocimiento, desarrollo tecnológico e innovación y/o apropiación social de conocimiento.

Ningún candidato podrá postularse simultáneamente para dos o más cuerpos colegiados.

Los representantes de los estudiantes y profesores podrán ser reelegidos en cualquier tiempo, hasta por un período más.

Todo candidato a representante, antes de inscribirse, deberá tener conocimiento tanto de la composición como de las funciones que tiene cada cuerpo colegiado al que se postula, y que se encuentran establecidas en los Estatutos Generales de la Universidad EAFIT, Estatuto Profesoral, Reglamentos Académicos de los Programas de Pregrado y Posgrado, y demás normas internas de la Universidad EAFIT.

Cada candidatura deberá estar conformada por el candidato principal y el suplente o los suplentes, según el cuerpo colegiado al cual se postulen de acuerdo con lo contemplado en el Reglamento de elección y representación estudiantil y profesoral ante los cuerpos colegiados.

En ningún caso la candidatura constituye o podrá asociarse a un partido o

movimiento político.

Cada candidatura será identificada con un número y no se permitirá utilizar en la inscripción alguna denominación asociada a un colectivo; sin embargo, será posible asociarse entre candidatos para promover la campaña y el ejercicio comunicacional de la misma.

Nota: El plan de trabajo con las firmas del candidato principal y suplente(s) se debe adjuntar en el enlace del formulario de **inscripción en un archivo pdf, usando el formato disponible en**[www.eafit.edu.co/elecciones](https://www.eafit.edu.co/bienestar-universitario/representacion-universitaria/representacion-estudiantil-profesoral/elecciones).

##### Umbral elecciones representantes estudiantiles de pregrado

**Consejo Directivo y Consejo Académico:** veinte por ciento (20%) más uno de los estudiantes de pregrado con matrícula vigente al día de las votaciones.

**Consejo de Escuela:**veinte por ciento (20%) más uno de los estudiantes de pregrado de la escuela correspondiente con matrícula vigente al día de las votaciones.

**Comité de Programa de Pregrado:** veinte por ciento (20%) más uno de los estudiantes del programa de pregrado al cual pertenecen, con matrícula vigente al día de las votaciones.

**Comité de Ciencia, Tecnología e Innovación:** diez por ciento (10%) más uno de los estudiantes de pregrado con matrícula vigente al día de las votaciones.

La elección de los representantes estudiantiles y profesorales a los diferentes cuerpos colegiados se hará por mayoría de votos. En aquellos cuerpos colegiados que no se alcance el umbral mínimo establecido, el Comité Electoral Universitario designará como representantes estudiantiles o profesorales a la(s) candidatura(s) más votadas, salvo en aquellos casos en que el voto en blanco haya obtenido la mayoría de los votos. En este caso el Comité Electoral Universitario convocará una vez más a Elecciones para el estamento correspondiente, y deberán postularse candidatos diferentes.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate