# Inglés para jóvenes - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Inglés para jóvenes

### Edad 12 a 16 años

Conecta con el mundo y fortalece habilidades clave para tu futuro académico y profesional.

*    Inglés Para Jóvenes 

Título de la sección

### Dirigido a

Jóvenes de 12 a 16 años

### Inversión desde

$1'130.000

### Duración

42,5 horas por curso

## Modalidades

Información general

Aprende con una metodología participativa y un enfoque que facilita el aprendizaje significativo del idioma a través de actividades entretenidas, constante interacción con el idioma y sesiones prácticas.

Esto permite que las clases sean dinámicas y el desarrollo de las habilidades comunicativas de los estudiantes y el conocimiento de aspectos útiles en diferentes ámbitos.

Inversión

###### **Inversión por curso**

**Sedes: Poblado, Sur (Centro Comercial Mayorca), Belén, Laureles y Llanogrande.**

## ​​Del preparatorio al 2

Sede Poblado y Sur (lunes)

 $1'130.000

 Sede Poblado (viernes y sábados)

 $1.330.000

 Sede Belén y Laureles (todos los horarios)

 Sedes Poblado ​(martes a jueves)

 Sede Sur (martes a sábado)

 $1.190.000

 Sede Llanogrande

 $1.156.000

## Cursos del 3 al 16​

Sede Poblado y Sur (lunes)

 $1.130.000

 Sede Poblado (viernes y sábado) 

 1.395.000

 Sede Belén y Laureles (todos los horarios)

 Sedes Poblado ​(martes a jueves)

 Sede Sur (martes a sábado)

 $1.300.000

 Sede Llanogrande

 $1.270.000

**Sedes Llanogrande**

## ​​Del preparatorio al 2

$1.156.000

## Cursos del 3 al 16​

$1.270.000​

Regulares

###### **Calendario 2026**

###### **2 cursos por año, 2.5 horas semanales**

**Lunes**

​**Sede Sur:** 4:00 p.m. a 6:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 26 | Junio 1 | Noviembre 10 - Enero 26 |
| Julio 13 | Noviembre 30 | Mayo 25 - Julio 13 |

**Martes**

**​Sede Poblado:** 4:00 p.m. a 6:30 p.m.

**Sede Sur:** 4:00 p.m. a 6:30 p.m.​

**Sede Laureles:**4:00 p.m. a 6:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Junio 2 | Noviembre 10 - Enero 20 |
| Julio 14 | Noviembre 24 | Mayo 25 - Julio 14 |

**Miércoles**

**Sede Poblado:** 4:00 p.m. a 6:30 p.m.

**Sede Sur:** 4:00 p.m. a 6:30 p.m.

**Sede Belén:** 4:00 p.m. a 6:30 p.m.​

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 21 | Junio 3 | Noviembre 10 - Enero 21 |
| Julio 15 | Noviembre 25 | Mayo 25 - Julio 15 |

**Jueves**

**Sede Poblado:**4:00 p.m. a 6:30 p.m.

**Sede Sur:** 4:00 p.m. a 6:30 p.m.

**Sede Belén:**4:00 p.m. a 6:30 p.m.

**Sede Laureles:**4:00 p.m. a 6:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 22 | Junio 4 | Noviembre 10 - Enero 22 |
| Julio 16 | Noviembre 26 | Mayo 25 - Julio 16 |

**Viernes**

**Sede Poblado:** 4:00 p.m. a 6:30 p.m.

**Sede Belén:** 4:00 p.m. a 6:30 p.m.

**Sede Sur:** 4:00 p.m. a 6:30 p.m.

**Sede Laureles:**4:00 p.m. a 6:30 p.m.​

**Sede Llanogrande:** 4:00 p.m. a 6:30 p.m.​ **¡Nuevo!**

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 23 | Junio 5 | Noviembre 10 - Enero 23 |
| Julio 17 | Noviembre 27 | Mayo 25 - Julio 17 |

**Sábado**

**Sede Poblado:**8:00 a.m. a 10:30 a.m./ 10:30 a.m. a 1:00 p.m./ 1:30 p.m. a 4:00 p.m.

**Sede Sur:** 8:00 a.m. a 10:30 a.m.​ / 10:30 a.m. a 1:00 p.m./ 1:30 p.m. a 4:00 p.m.​

**Sede Belén:**8:00 a.m. a 10:30 a.m./ 10:30 a.m. a 1:00 p.m.

**Sede Laureles:**8:00 a.m. a 10:30 a.m. / 10:30 a.m. a 1:00 p.m.

**Sede Llanogrande:** 8:00 a.m. a 10:30 a.m./ 10:30 a.m. a 1:00 p.m.​

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 24 | Junio 6 | Noviembre 10 - Enero 24 |
| Julio 18 | Noviembre 28 | Mayo 25 - Julio 18 |

_***Los cursos de inglés para jóvenes no tienen clase los durante estos días:**_

Semana Santa

20 de abril

Semana de receso escolar.

Intensivos

###### **4 cursos por año, 5 horas semanales**

**Martes y jueves**

**​Sede Poblado:**4:00 p.m. a 6:30 p.m.​

**Sede Sur:**4:00 p.m. a 6:30 p.m.

**Sede Laureles:**4:00 p.m. a 6:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Marzo 24 | Noviembre 10 - Enero 20 |
| Abril 7 | Junio 9 | Febrero 2 - Abril 7 |
| Julio 14 | Septiembre 15 | Mayo 25 - Julio 14 |
| Septiembre 22 | Diciembre 1 | Julio 27 - Septiembre 22 |

**Miércoles y viernes**

**Sede Belén:** 4:00 p.m. a 6:30 p.m.​ ¡Nuevo!​​

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 21 | Marzo 25 | Noviembre 10 - Enero 21 |
| Abril 8 | Junio 10 | Febrero 2 - Abril 8 |
| Julio 15 | Septiembre 18 | Mayo 25 - Julio 15 |
| Septiembre 23 | Diciembre 2 | Julio 27 - Septiembre 23 |

_***Los cursos de inglés para jóvenes no tienen clase los durante estos días:**_

_**Semana Santa**_

_**20 de abril**_

_**Semana de receso escolar.**_

Cursos vacacionales

**Lunes a viernes**

**Sede Poblado:**8:15 a.m. a 12:00 m.

**Sede Sur:**8:15 a.m. a 12:00 m.​

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Junio 16 | Julio 4 | Mayo 5 - Junio 16 |

## ¿Por qué aprender Inglés?

Podrás estudiar en cualquier lugar del mundo cuando termines el colegio.

 Cantarás inglés y entenderás todo lo que estás diciendo.

 Sabrás defenderte y pedir una hamburguesa cuando viajes.

 Dejarás de utilizar Google Translate.

 Abrirás puertas para tu futuro.

 Podrás aprender otros idiomas cuando crezcas porque ya tienes el idioma básico.

 Podrás ver Stranger Things sin subtítulos.

## ¿Por qué estudiar ​​​idiomas en EAFIT?

Con 30 años de experiencia en la enseñanza de idiomas, como respuesta a las exigencias mundiales, Idiomas EAFIT tiene como objetivo principal dar solución a las necesidades del entorno académico, empresarial y gubernamental.

## Portafolio corporativo

## Global Explorers

## Certifica tus conocimientos en Inglés

# Proceso de inscripción

Para autogestionar tu inscripción en Idiomas, primero debemos conocer cuál es el nivel ideal para ti. Para ello debes realizar una cita de clasificación, solicítala así:

### 1

### 2

### Selecciona la edad del estudiante

Jóvenes 12 a 16 años

### 3

### Selecciona el idioma inglés.

### 4

### Elige la sede donde quieres realizar la prueba de clasificación.

### 5

### Ingresa al enlace

Elige la fecha y hora de tu preferencia.

### 6

### Diligencia tus datos en el formulario de registro.

### 7

### Asiste a la cita de clasificación

En la sede y horario seleccionados

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

## Líneas de atención

(57) 604 2619500

## Sugerencias

## ¡Idiomas EAFIT llega a Bello!

Aprende inglés con educación de calidad y una metodología efectiva.

## Spanish program

Personalized sessions adapted to your needs

## English Stars - niños de 4 años

### Edad 4 años

Un programa para aprender inglés y fortalecer habilidades clave para el desarrollo cognitivo, social y comunicativo en la primera infancia.

## Vacacionales Happy Time

### Edad 5 a 10 años

Vacaciones en inglés para niños. Una semana perfecta para disfrutar y conocer el mundo mientras aprenden un nuevo idioma.

## Programa de inglés para niños y niñas

### Edad 4 a 11 años

Metodología participativa con resultados reales que desarrollan habilidades cognitivas y sociales.

## Programas de inglés para niños y niñas

### Edad 4 a 11 años

El programa de inglés para niños que combina el juego, la creatividad y el aprendizaje de un nuevo idioma de manera efectiva

## Inglés para jóvenes

### Edad 12 a 16 años

Conecta con el mundo y fortalece habilidades clave para tu futuro académico y profesional.

## Portugués para adultos

### Edad +17

Disfruta la experiencia de aprender una de las lenguas más dulces y agradables del mundo.

## Italiano para adultos

### Edad +17

Aprende italiano de forma divertida y expande tus horizontes con nuevos conocimientos.

## Francés para adultos

### Edad +17

Aprende una de las lenguas más fascinantes y sumérgete en una cultura artística y rica.

## Alemán para adultos

### Edad +17

Aprende con una metodología efectiva y práctica y descubre la riqueza cultural del alemán, sumérgete en su historia y tradiciones.

## Francés para jóvenes

### Edad 12 a 16 años

Domina una lengua romance fascinante y explora una cultura artística y rica.

## Alemán para Jóvenes

### Edad 12 a 16 años

Descubre la riqueza cultural del alemán y atrévete a sumergirte en su historia y tradiciones.

## Inglés virtual para adultos

### Edad +18

Vive una experiencia flexible, personalizada y con acompañamiento real

## Inglés para adultos

### Edad +17

Domina el inglés con una metodología efectiva y accede a oportunidades para crecer, viajar y destacar profesionalmente.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate