# Laboratorio Fina​​nciero - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# **Laboratorio Financiero**

Accedemos a información en tiempo real en los mercados financieros usando diferentes plataformas de información.

*    Laboratorio Fina​​nciero 

###### ​​​¿​​Qué es Bloomberg?

​​Es un sistema que brinda información en timepo real de los mercados financieros​​ del mundo, tales como noticias, analisis,​ etc. Opera de manera totalmente integral.

En el siguiente archivo enco​​​ntrarás el paso a paso para crear tu cuenta en Bloomberg​.

###### Ho​rario de​ atención​

1.   Lunes a viernes de 8:00 a.m. a 12:00 m y de 2:00 p.m. a 6:00 p.m.​​
2.   Síguenos en nuestras redes sociale​s para mantenerte al día con los cambios en nuestro horario.

## ¡Sígueno​​​s y conoce nuestra agenda​!​​

### Instagram

### WhatsApp

###### Contacto

​​​​​​​​​Escríbanos para solicitar más información sobre el laboratorio:​

​**Alejandra María​​ Luján Jaramillo**

Coordinadora Laboratorio Financiero Universidad EA​FIT

Carrera 49 N° 7 Sur - 50. Bloque 17, primer piso

Medellín, Colombia​

Correo electrónico: [laboratoriofinanciero@eafit.edu.co](mailto:laboratoriofinanciero@eafit.edu.co)

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)