# ​​​​Configur​​ación organizacional

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# **​​​​Configur​​ación organizacional**

La estructura organizacional de la Universidad se ha configurado para hacer tangible la transformación del modelo educativo, y dar respuesta a las transformaciones y los retos de la educación superior.

*    ​​​​Configur​​ación Organizacional 

La configuración organizacional es presidida por el Consejo Superior y el Consejo Directivo. El prim​ero es el máximo órgano de Gobierno de la Universidad, custodio del patrimonio y la estrategia de la Institución, y el encargado de preservar los principios y la filosofía de los fundadores de la Institución.

El Consejo Directivo, por su parte, se configura como un subconjunto del Consejo Superior y es el órgano de dirección y administración de la Universidad del que también participan los estamentos de los profesores, los estudiantes y los graduados.

De la estructura, de igual forma hace parte el Consejo Académico, que vela por el cumplimiento e implementación del proyecto educativo; el Comité de Ciencia, Tecnología e Innovación, que orienta y fortalece el funcionamiento del Sistema de Ciencia, Tecnología e Innovación de la Universidad.

Así mismo, el gobierno está integrado por el Comité de Desarrollo Profesoral, que decide sobre los procesos de ascenso, apoyos en procesos de formación y reglamenta el Estatuto Profesoral; el Comité Rectoral, que acompaña la gestión del rector de cara a la materialización de la operación y el funcionamiento de EAFIT; y los Consejos de Escuela, que asesoran a los decanos en las decisiones académicas.

###### La configuración de EAFIT está estructurada en tres capacidades:

Capacidades de **conocimiento:** a través de l​as cinco escuelas (Administración; Ciencias Aplicadas e Ingeniería; Finanzas, Economía y Gobierno; Artes y Humanidades; y Derecho); con sus respectivos centros.

Capacidades de **soporte académico y articulación**: sistema de aprendizaje; y ​sistema de ciencia, tecnología e innovación (dos vicerrectorías); **y soporte corporativo** (Secretaría General, 5 direcciones y 2 departamentos).

Capacidades de **conexión** con tres ecosistemas: empresas consolidadas, sistemas públicos y emprendimientos de impacto.​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)