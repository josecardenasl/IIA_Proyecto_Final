# Finanzas - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Pregrado

# Finanzas

SNIES 102816, Medellín

¿Quién consigue los recursos para hacer despegar a un emprendimiento y estructurar su futuro sostenible? Un profesional en finanzas. De ahí que las grandes compañías de tecnología que hace pocos años eran pequeñas tengan centenares de financistas en sus esquemas. En suma, a pesar de estar concentrado en números, estudiarás la teoría financiera, micro y macroeconomía y modelos aplicados. Además, te preguntarás cómo generar rentabilidad, cómo invertir estudiando de cerca los riesgos, todo esto teniendo en cuenta el contexto, el entorno y la realidad de la sociedad. Tu verdadero tema de estudio serán el desarrollo y la generación de valor.

Si tienes una inclinación natural hacia los números y lo financiero, los mercados, pero también te interesan la sostenibilidad, el desarrollo y las teorías económicas, este pregrado es para ti**.**

*    Escuela Finanzas Economia Gobierno 
*    Finanzas 

## Registro calificado

Resolución 24327 del 27 de diciembre de 2021, otorgada por el Ministerio de Educación Nacional con vigencia de 7 años.

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 102816

Valor del primer semestre

$16.678.333

Valor promedio de los semestres

$15.031.090

Becas y Financiación

## Sobre el programa

Calidad y excelencia

**Somos top en el mundo**

Somos el segundo pregrado en Colombia reconocido por el CFA Institute (Chartered Financial Analyst)

Como institución estamos acreditados por AACSB (Association to Advance Collegiate Schools of Business), lo que nos convierte en la primera universidad en Antioquia en obtener este reconocimiento, la sexta en Colombia y nos hace parte del menos del 6% de las escuelas de negocios del mundo que cuentan con ella.

Nuestra MAF (Maestría en Administración Financiera), para la que puedes homologar créditos con nuestros pregrados, lleva cinco años siendo socia del CFA (Chartered Financial Analyst), y es la única con este reconocimiento en Colombia. Además, hacemos parte de la GARP, la asociación de expertos en las áreas de riesgos, siendo los únicos en el país con esta acreditación en pregrado y posgrado.

Y somos la mejor Escuela de Finanzas, Economía y Gobierno de Antioquia, según el Ranking QS.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

Nuestra Escuela cuenta con el respaldo de un gran ecosistema de laboratorios: Laboratorio y Consultorio Financiero ; DataPol; el centro de estudios e incidencia, Valor Público y el centro de innovación y desarrollo social, EAFIT Social.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en EAFIT.

**Tenemos proyección y presencia nacional**

Estamos en Bogotá con nuestros programas de Maestría en Administración (MBA), Maestría en Administración Financiera (MAF), Maestría en Gerencia de Proyectos y Especialización en Finanzas en Bogotá. Llegamos a Pereira con la Maestría en Administración (MBA), Maestría en Administración de Riesgos, Maestría y Especialización en Mercadeo, Maestría y Especialización en Gerencia de Proyectos, Maestría en Administración Financiera y Especialización en Finanzas. En ambas sedes con flexibilidad de clases presenciales cada quince días y cada mes, según el programa.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe 240 estudiantes de más de 15 países del planeta y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Dos líneas de énfasis, finanzas corporativas y gestión de riesgos financieros, para que puedas escoger cómo complementar tu desarrollo profesional.

Podrás enfocar tu carrera en temas como: Finanzas Corporativas, Gestión de Riesgos Financieros.

Innovación y liderazgo

**Somos innovación en educación**

Contamos con herramientas de alto nivel utilizadas por las bancas de inversión, comisionistas y grandes aseguradoras del mundo: Bloomberg, un software especializado al que nuestros estudiantes tienen acceso y por medio del que se pueden certificar. Y Refinitiv, software de la bolsa de Londres.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de EAFIT y a las tres áreas (mercados y estrategia financiera, macroeconomía y sistemas financieros, y políticas y desarrollo) que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

Tenemos 3 semilleros de investigación y 4 grupos de investigación.

En EAFIT tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Contamos con centro de estudios e incidencia, Valor Público y con un espacio de innovación y desarrollo social: EAFIT Social.

Contamos con una línea especial de Gerencia y empresa que presta consultoría, y también, con ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

La banca nacional e internacional, y en general el sistema financiero, valoran altamente a los graduados de EAFIT. Muchos de ellos ocupan cargos estratégicos en el país y en el mundo tanto en el sector público como en el privado.

La huella de nuestro programa hoy es relevante en organizaciones como Bancolombia, el BID, el Banco Mundial, JP Morgan.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

Tenemos una relación estrecha con la Brandeis University, Carlos III de Madrid y la Universidad Pompeu Fabra, la Universidad Católica de Lovaina y la Universidad La Salle Ramón Llull, para salidas profesionales, proyectos investigativos conjuntos y prácticas remuneradas.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrados han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores start-ups de Colombia.

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Pruebas Saber Pro

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Negocios Internacionales

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Inglés

Más información

Más del 80 % de los cursos se imparten en inglés, con asignaturas complementarias en español y un tercer idioma certificado por los estudiantes.

Modalidad

Presencial

SNIES

SNIES 1244

Valor del primer semestre

$15.442.913

Valor promedio de los semestres

$15.236.996

Becas y Financiación

#### Economía

Duración

9 Semestres

Lugar

Medellín

Tiempo

Tiempo completo

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 3182

Valor del primer semestre

$12.972.037

Valor promedio de los semestres

$13.383.847

Becas y financiación

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)