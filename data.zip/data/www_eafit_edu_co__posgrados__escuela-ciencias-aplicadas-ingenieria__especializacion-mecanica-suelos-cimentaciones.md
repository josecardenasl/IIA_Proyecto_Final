# Especialización en Mecánica de Suelos y Cimentaciones - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 16: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Especialización en Mecánica de Suelos y Cimentaciones

SNIES 10703​​​​​, Medellín

Colombia con su topografía compleja, clima tropical y amenaza sísmica, requiere de ingenieros geotécnicos capaces de solucionar problemas asociados a las características y comportamientos del suelo. La normativa colombiana de construcción de edificaciones sismorresistentes (NSR) enfatiza como requisito la realización de estudios de suelo previos a la realización de los proyectos. Además, sobre el suelo reposa la infraestructura de la región y el país, por lo que su comprensión resulta esencial antes de ejecutar cualquier proyecto. En este contexto, la especialización en Mecánica de Suelos y Cimentaciones se convierte en un componente fundamental para garantizar la seguridad, la sostenibilidad y la eficiencia en la ingeniería geotécnica.

El programa se actualiza de manera permanente en función de los avances tecnológicos y normativos, y es impartido por profesores que, además de su formación académica, cuentan con una amplia experiencia profesional en proyectos de infraestructura compleja en diversos sectores.

El o la especialista en Mecánica de Suelos y Cimentaciones estará en capacidad de desempeñarse como consultor o revisor en proyectos de gran magnitud, y de aportar valor en firmas de ingeniería, constructoras y entidades públicas. Asimismo, contará con las herramientas necesarias para emprender de manera independiente y liderar empresas de consultoría o de servicios especializados en geotecnia, contribuyendo de forma directa al desarrollo de la infraestructura del país.

*    Escuela Ciencias Aplicadas Ingenieria 
*    Especialización En Mecánica de Suelos y Cimentaciones 

## Registro calificado

Resolución​​​ 014489 del 13 de diciembre de 2019.

Duración

2 semestres

Más información

Nota: el tiempo real puede variar según la carga académica que elija el estudiante.

Lugar

Medellín

Horario

Viernes y sábados

Más información

Viernes: 2:00 p.m. a 8:00 p.m.

 Sábados: 8:00 a.m. a 2:00 p.m. 

Idioma

Español

Modalidad

Presencial

SNIES

SNIES ​10703​​​​​

Precio total del programa

$32.336.015

## Sobre el programa

Generalidad del programa

La Especialización en Mecánica de Suelos y Cimentaciones forma profesionales que asumen la responsabilidad geotécnica de proyectos de infraestructura: estudios de suelo, diseño de cimentaciones, estabilidad de taludes y otras estructuras geotécnicas urbanas y regionales.

El programa combina exploración e instrumentación en campo, ensayos avanzados de laboratorio y modelación geotécnica, lo que permite integrar información geotécnica con las demás disciplinas de un proyecto y responder a las exigencias normativas actuales.

Con más de 20 años de trayectoria, sus egresadas y egresados participan en firmas de consultoría y construcción, proyectos viales, mineros y ferroviarios, túneles, obras de edificaciones y desarrollos para la transición energética (parques solares, eólicos y grandes plataformas de servicios).

Perfiles

**Perfil de Ingreso**: La especialización en Mecánica de Suelos y Cimentaciones de la Universidad EAFIT está dirigida a **profesionales de ingeniería civil, ingeniería geológica, geología, ingeniería de minas y áreas afines** con interés en diseño de cimentaciones, estructuras de contención y otros proyectos geotécnicos.

**Perfil de Egreso**: El/la egresado/a de la especialización en Mecánica de Suelos y Cimentaciones de la Universidad EAFIT **soluciona problemáticas asociadas a las características y comportamiento del suelo**, aplicando fundamentos de geomecánica, cimentaciones y estabilización, así como herramientas de exploración, experimentación, modelación e instrumentación en estudios y proyectos geotécnicos. Además, cuenta con una formación integral y ética profesional; asimismo, que se caracteriza por sus habilidades comunicativas y su capacidad para el trabajo en equipo.

**Perfil Ocupacional**: La persona especialista en Mecánica de Suelos y Cimentaciones de la Universidad EAFIT podrá desempeñarse como**diseñadora, interventora, y asesora** en proyectos geotécnicos. Podrá ejercer su labor en empresas de consultoría y construcción de estructuras, entidades regulatorias, o entidades promotoras de proyectos de infraestructura en los sectores público o privado.​

Campus transformador

El campus de la Universidad EAFIT es también conocido como “Universidad Parque”, lo cual hace distinción a un modelo de institución donde conviven en armonía lo académico, lo cultural y lo ambiental. Los estudiantes de la especialización tienen acceso a espacios de recreación, deporte, intercambio cultural, desarrollo artístico, entre otros, que contribuyen al bienestar y desarrollo integral.

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

La Especialización ofrece a sus estudiantes y graduados el Centro de Laboratorios con más de 34 talleres y laboratorios. Entre éstos, el Laboratorio de Suelos, Concretos y Pavimentos acreditado por la Superintendencia de Industria y Comercio (SIC) con equipos de tecnología de vanguardia escasa en Colombia para la evaluación y modelación del comportamiento de suelo y rocas como el triaxial cíclico, la columna resonante, los elementos Bender y la caja laminar.

Además, la universidad cuenta con más de 50 aulas de informática con programas especializados y múltiples espacios de estudio en el Centro Cultural Biblioteca Luis Echavarría Villegas.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad. Contamos con una agenda de conocimiento y cultura viva: lo mejor de la academia, la ciencia y las artes converge en EAFIT (talleres, ferias, conciertos, etc.).

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje Vivo y Activo

La especialización apuesta por una educación flexible y relevante, soportada en el aprendizaje activo y experiencial, bajo modelos basados en proyectos, en retos y problemas con casos reales, que construyen competencias claras, llevando lo conceptual a lo práctico. Este aprendizaje se construye bajo estos cinco atributos:

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Fomentar la participación de los estudiantes a través de discusión, y actividades colaborativas, promoviendo un ambiente de aprendizaje interactivo y centrado en sus necesidades.

**Currículo Vivo**

La oferta constante del programa y su flexibilidad curricular permite que el/la estudiante pueda hacerlo a su tiempo. El 50% de los créditos del programa son materias electivas donde el/la estudiante puede cursar las de otros programas afines como el de la especialización en Ingeniería Sismo-resistente, en Diseño Vial e Ingeniería de Pavimentos, y en Gestión de la Construcción. De esta forma, se mantiene el currículo actualizado con las últimas tendencias y avances en el campo de estudio, incorporando contenidos relacionados con las tendencias y retos del sector y el mercado laboral.

La Universidad EAFIT, privilegia la integración de los distintos niveles de aprendizaje, bajo el sistema metro, que promueve el tránsito de los estudiantes de pregrado a la especialización y de ésta a programas de maestría y doctorado. De esta manera, el 100% de los créditos de la especialización podrían ser homologables en la Maestría en Ingeniería.

Además, la especialización fomenta la participación de profesionales del campo en eventos y charlas donde conferencistas invitados proporcionan perspectivas actualizadas y casos de éxito.

**El campus como laboratorio**

La especialización promueve la utilización de los espacios de aprendizaje de la universidad como los laboratorios y talleres en el quehacer académico.

Además, establece y fortalece las alianzas con empresas y organizaciones del sector para brindar a los estudiantes oportunidades de proyectos colaborativos o estudios de caso.

**Experiencia integral y transformadora de vida**

Implementar proyectos y actividades prácticas que permitan a los estudiantes aplicar los conceptos en situaciones reales, fomentando así el aprendizaje experiencial y su transformación como profesionales.

Facilitar espacios de reflexión y discusión sobre el impacto de las decisiones, no solo a nivel técnico, sino también en el entorno social y ambiental.

**Profesores que inspiran**

Los profesores de la especialización tienen formación a nivel de maestría y doctorado, y compartan experiencias relevantes del sector y casos de estudio que ilustran la aplicación práctica de los conceptos abordados en el Programa. Además, promueven la interacción y retroalimentación constante.

La modalidad de esta especialización es **100% presencial.**

Innovación y liderazgo

**Somos innovación en educación.**

Nuestro plan de estudios y profesores están en constante actualización para incluir las últimas novedades tecnológicas y normativas.

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar, donde se cultiva el liderazgo y la investigación.

Además, pueden participar en los semilleros y/o grupos de investigación como el de Grupo de Investigación en Geociencias y Biodiversidad (GEBI) y en Naturaleza y Ciudad. Además de tener acceso a softwares especializado como Rocscience y plataformas de uso libre.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Nuestros estudiantes pueden trabajar en empresas del sector privado, como: Conconcreto, Integral, Sedic, Arquitectura y Concreto, Inteinsa y Solingral. O empresas del sector público como EPM, Área Metropolitana o secretarías de obras públicas y planeación. También pueden ser consultores independientes o crear sus propias empresas.

La Universidad cuenta con ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto. 

Además, nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo.

Contacto

###### Ejecutiva de promoción

**Andrea Torres Morales**

+ 57 322 678 3083

## Plan de estudios

## Profesores

## Escuela de Ciencias Aplicadas e Ingeniería

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Especialización en Diseño Vial e Ingeniería de Pavimentos

Duración

2 semestres

Lugar

Medellín

Horario

Viernes y sábados

Más información

Viernes de 3:00 p.m. a 9:00 p.m. y sábados de 8:00 a.m. a 2:00 p.m.

Idioma

Español

Modalidad

Presencial

SNIES

SNIES ​91073

Precio total del programa

$33.901.787

#### Especialización en Ingeniería Sismo-Resistente

Duración

2 semestres

Lugar

Medellín

Horario

Martes a viernes

Más información

Martes a viernes de 6:00 a. m. a 9:00 a. m. (7 de las 8 materias) 

 Durante el primer semestre una materia se dictará los viernes de 2:00 p. m. a 8:00 p.m.

 * El horario está sujeto a la programación y se informará previo al inicio de cada semestre.

Idioma

Español

Modalidad

Presencial

SNIES

​1264​​​​​

Precio total del programa

$34.874.500

### **Noticias**

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Con más de 700 organizaciones aliadas, así se expande la relación de EAFIT con las empresas

Mayo 12, 2026

## Celebramos una cohorte que transforma territorios gracias a la Fundación Sura

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate