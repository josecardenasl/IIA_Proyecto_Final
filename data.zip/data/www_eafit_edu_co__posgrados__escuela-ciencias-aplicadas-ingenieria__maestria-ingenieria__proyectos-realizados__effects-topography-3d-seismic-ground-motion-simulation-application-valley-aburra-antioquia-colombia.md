# Effects of Topography on 3D Seismic Ground Motion Simulation with an Application to the Valley of Aburra in Antioquia, Colombia - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Effects of Topography on 3D Seismic Ground Motion Simulation with an Application to the Valley of Aburra in Antioquia, Colombia

*    Escuela Ciencias Aplicadas Ingenieria 
*    Effects Of Topography On 3D Seismic Ground Motion Simulation With An Application To The Valley Of Aburra In Antioquia, Colombia 

###### Doriam L Restrepo

​**2013**

This dissertation presents a numerical scheme based upon the finite element framework for the numerical modeling of earthquake-induced ground motion in the presence of realistic topographic variations of the Earth’s crust. We show that by adopting a non-conforming meshing scheme for the numerical representation of the surficial topography we can obtain very accurate representations of earthquake induced ground motion in mountainous regions. From the computational point of view, our methodology proves to be accurate, efficient, and more importantly, it allows us to preserve the salient features of multi-resolution cubic finite elements. We implemented the non-conforming scheme for the treatment of realistic topographies into Hercules, the octree-based finite-element earthquake simulator developed by the Quake Group at Carnegie Mellon University.  We tested the benefits of the strategy by benchmarking its results against reference examples, and by means of convergence analyses. Our qualitative and quantitative comparisons showed an excellent agreement between results. Moreover, this agreement was obtained using the same mesh refinement as in traditional flat-free simulations.

Our approach was tested under realistic conditions by conducting a comprehensive set of deterministic 3D ground motion numerical simulations in an earthquake-prone region ex-hibiting moderate-to-strong surficial irregularities known as the Aburra Valley in Antioquia- Colombia. We proposed a 50×50×25km3 volume to perform our simulations, and four Mw= 5 rupture scenarios along a segment of the Romeral fault; a significant source of seismic activity of Colombia. We created and used the Initial Velocity Model of the Aburra, Valley region (IVM-AbV) which takes geology as a proxy for shear-wave velocity. Each earthquake model was simulated using three different models: (i) realistic 3D structure with realistic topography; (ii) realistic 3D structure without topography; and (iii) homogeneous half space with realistic topography. Our results show how topographic irregularities greatly modify the ground response.  In particular, they highlight the importance of the combined interaction between source-effects, focusing, soft-soil conditions, and 3D topography. We provide quantitative evidence of this interaction and show that topographic amplification factors at some locations can be as high as 500 percent, while some other areas experience reductions. These are smaller than the amplifications, on the order of up to 100 percent.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate