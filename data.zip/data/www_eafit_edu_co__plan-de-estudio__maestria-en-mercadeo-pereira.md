# Maestría en Mercadeo - Pereira - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Plan de estudios

Maestría en Mercadeo - Pereira

*    Plan de Estudio 
*    Maestría En Mercadeo - Pereira 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

Cantidad de créditos: 

Semestre 1

Créditos 

totales 14

Créditos 2

#### Marketing y Estrategia

Código: MI7001

Plan de estudios del programa
## Marketing y Estrategia

2 Créditos

2 UMES

Código: **MI7001**

Créditos 2

#### Comportamiento del Consumidor

Código: MI7002

Plan de estudios del programa
## Comportamiento del Consumidor

2 Créditos

2 UMES

Código: **MI7002**

Créditos 2

#### Fundamentos e Investigación Cualitativa

Código: MI7003

Plan de estudios del programa
## Fundamentos e Investigación Cualitativa

2 Créditos

2 UMES

Código: **MI7003**

Créditos 2

#### Investigación y Métodos Cuantitativa

Código: MI7004

Plan de estudios del programa
## Investigación y Métodos Cuantitativa

2 Créditos

2 UMES

Código: **MI7004**

Créditos 2

#### Business Analytics

Código: MI7005

Plan de estudios del programa
## Business Analytics

2 Créditos

2 UMES

Código: **MI7005**

Créditos 2

#### Mercadeo y Sostenibilidad

Código: MI7006

Plan de estudios del programa
## Mercadeo y Sostenibilidad

2 Créditos

2 UMES

Código: **MI7006**

Créditos 2

#### Proyecto Integrador 1

Código: MI7007

Plan de estudios del programa
## Proyecto Integrador 1

2 Créditos

2 UMES

Código: **MI7007**

Semestres

1 

2 

3 

Núcleos, ciclos, trayectorias y énfasis

- [x] Plan de estudios del programa 

## Líneas de énfasis

Marca y Comunicaciones 1

Marca y Comunicaciones 2

Marca y Comunicaciones 3

Marketing Digital 1

Marketing Digital 2

Marketing Digital 3

Estrategia Comercial 1

Estrategia Comercial 2

Estrategia Comercial 3

Innovación y Emprendimiento 1

Innovación y Emprendimiento 2

Innovación y Emprendimiento 3

Servicio y Experiencia 1

Servicio y Experiencia 2

Servicio y Experiencia 3

Ciencias del Comportamiento 1

Ciencias del Comportamiento 2

Ciencias del Comportamiento 3

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate

## Utilizamos cookies en este sitio web para mejorar su experiencia de usuario.

Al hacer click en Aceptar, otorga su consentimiento para que establezcamos cookies. [Conoce la política de datos personales](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Aceptar No, gracias