# Darío Monsalve Uribe - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Darío Monsalve Uribe

​​​​​​​​(Rector entre ​1973-1975)

*    Darío Monsalve Uribe 

Tras la renuncia de Ricardo Botero Mejía, comenzó gestiones el rector más joven que ha tenido la Universidad en toda su historia: Darío Monsalve Uribe, de 31 años, quien rápidamente se convirtió en el primer y único egresado de EAFIT en ocupar este cargo de tan alta distinción.

​

Este administrador empezó como rector encargado en medio de una de las mayores crisis de la historia de EAFIT. Al principio de su administración se logró dar inicio a las actividades académicas de la maestría en Administración (MBA), pero en una sede diferente a la de La Aguacatala.

Durante sus dos años en la Rectoría se analizaron puntos como el costo del programa especial para personas activas en el mundo laboral, llamado “el simultáneo”, la composición del cuerpo docente, entro otros aspectos de gran importancia para el funcionamiento de la Univers​idad.

Luego de haber superado la crisis estudiantil por la que pasó la Institución y al reconocer los avances en la parte académica y administrativa como la restructuración del Plan Máster, el Consejo Superior lo designó como rector titular.

El 8 de abril de 1975 Monsalve Uribe presentó su renuncia ante el Consejo Superior, que se hizo efectiva el 10 de mayo de ese mismo año.

Datos sacados del libro Universidad EAFIT 50 Años.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate