# Especialización en Desarrollo de software - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Especialización en Desarrollo de software

*    Plan de Estudio 
*    Especialización En Desarrollo de Software 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

Núcleos, ciclos, trayectorias y énfasis

- [x] Créditos electivos Área Computacional Avanzada 

- [x] Créditos electivos Área Computacional Básica 

- [x] Obligatorias 

Semestre 1

Créditos 

totales-

Créditos 2

#### Procesos Modernos de Desarrollo de Software

Código: ST1605

Obligatorias
## Procesos Modernos de Desarrollo de Software

2 Créditos

2 UMES

Explora diversas metodologías que permiten desarrollar software de calidad, con plazos y costos predecibles. Aprenderás a seleccionar procesos adecuados según el tipo de solución. Esta asignatura proporciona una base sólida para liderar proyectos de desarrollo con enfoque estructurado, adaptable y eficiente.

Código: **ST1605**

Créditos 2

#### Integración y Entrega Continua de Software

Código: ST1606

Obligatorias
## Integración y Entrega Continua de Software

2 Créditos

2 UMES

Conoce cómo garantizar la integridad de los artefactos generados durante el desarrollo, a través de buenas prácticas de configuración, integración y despliegue. Esta asignatura te prepara para implementar procesos automatizados que permiten entregar software de forma ágil, confiable y alineada con las necesidades del usuario final.

Código: **ST1606**

Créditos 2

#### Arquitecturas Avanzadas de Software

Código: ST1607

Obligatorias
## Arquitecturas Avanzadas de Software

2 Créditos

2 UMES

Adquiere conocimientos clave sobre diseño y evaluación de arquitecturas de software, tradicionales y modernas. Estudiarás los principales patrones, procesos y criterios de calidad que permiten construir sistemas escalables, mantenibles y alineados con los objetivos del negocio.

Código: **ST1607**

Créditos 2

#### Desarrollo de Sistemas Seguros

Código: ST1608

Obligatorias
## Desarrollo de Sistemas Seguros

2 Créditos

2 UMES

Aprende a integrar principios y buenas prácticas de seguridad desde las etapas tempranas del ciclo de vida del software. Esta asignatura te prepara para construir soluciones robustas que protejan los datos, garanticen la disponibilidad del sistema y reduzcan los riesgos frente a amenazas emergentes.

Código: **ST1608**

Créditos 2

#### Electiva I Área Computacional Básica

Código: 

Créditos electivos Área Computacional Básica
## Electiva I Área Computacional Básica

2 Créditos

2 UMES

Podrás elegir entre las siguientes asignaturas:

- Aprendizaje de Máquina Aplicado

- Estrategias de Innovación en Ecosistemas Digitales

- Diseño de la Experiencia de Usuario

Nota: La apertura de las asignaturas puede variar según la disponibilidad académica.

Código: 

Créditos 2

#### Electiva II Área Computacional Básica

Código: 

Créditos electivos Área Computacional Básica
## Electiva II Área Computacional Básica

2 Créditos

2 UMES

Podrás elegir entre las siguientes asignaturas:

- Aprendizaje de Máquina Aplicado

- Estrategias de Innovación en Ecosistemas Digitales

- Diseño de la Experiencia de Usuario

Nota: La apertura de las asignaturas puede variar según la disponibilidad académica.

Código: 

Semestres

1 

2 

Núcleos, ciclos, trayectorias y énfasis

- [x] Créditos electivos Área Computacional Avanzada 

- [x] Créditos electivos Área Computacional Básica 

- [x] Obligatorias 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate