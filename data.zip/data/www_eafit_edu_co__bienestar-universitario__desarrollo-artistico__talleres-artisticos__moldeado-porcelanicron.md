# Modelado en Porcelanicrón

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Modelado en Porcelanicron - 20 horas

Inscripciones primer semestre de 2026: A partir de las 8:00 a.m. del 26 de enero

*    Modelado En Porcelanicrón 

###### Taller dirigido: Estudiantes, graduados​, profesores, empleados y pensionados de la Universidad EAFIT y sus familiares (padres, hijos, hermanos y esposo o compañero permanente). ​​

Si eres estudiante, empleado, profesor o pensionado, al inscribirte en el Taller aceptas la Política de los Talleres Artísticos, por lo tanto ten en cuenta que deberás administrar tus faltas de asistencia. Al momento de incumplir con el 80% de asistencia a tu Taller, el sistema te generará una cuenta de cobro por el costo total del taller, sin descuento ninguno.

En este taller podrás tener un acercamiento al modelado de la cerámica feria como herramienta de estimulación motriz, estimulación creativa, meditativa e incluso como herramienta de emprendimiento artesanal y artístico. Realizaremos accesorios y elementos decorativos.

​​​Sesión 1:

presentación del curso.

¿Qué es el porcelanicron y como se hace?

aprenderemos a colorear el material: los colores secundarios.

Sesión 2:

Realizamos un banco de texturas y posibles usos del material.

Hacemos un primer ejercicio sencillo: llavero de emoticón.

Sesión 3:

Aprendemos a cubrir y forrar objetos.

realizamos un jarrón con flores o frutas.

Sesión 4:

Haremos diferentes figuras de dulces con la intención de convertirlas en imanes para la nevera.

Veremos la importancia de un buen secado y pegado para el porcelanicrón.

Sesión 5:

Para esta sesión necesitamos un poema o frase que le guste para realizar un separador de libros.

Haremos dos o tres tipos de separadores: en papel, palitos de paleta o cadena.

Sesión 6:

En esta ocasión haremos algo más decorativo.

Trabajaremos el intaglio y el grabado como parte de la composición.

El resultado dependerá de la creatividad y experimentación de cada participante.

Sesión: 7:

El docente llevará al aula espejos pequeños para cada uno. Espejos que personalizamos.

Retomaremos el forrado y decorado de objetos.

Sesión 8:

Realizaremos diferentes accesorios.

Aprenderemos a hacer aretes.

Personaliza tus clips.

Haremos un par de dijes.

Sesión 9:

Usaremos toda nuestra creatividad para hacer un porta pinceles.

Usaremos la pintura y el alambre para dar forma a nuestras ideas.

Usaremos las piezas de nuestro banco de textura.

Sesión 10:

Realizaremos un porta velas con la forma de nuestro animal favorito.

Usaremos las piezas de nuestro banco de texturas.

Daremos cuenta de la importancia de los palillos para la estabilidad de nuestras figuras.​

Porcelanicrón: amarillo, azul, rojo, blanco y negro.

pintura acrílica caja x 12 colores (marca marión)

Figuras geométricas pequeñas en icopor. cuadro,círculo, triángulo…

Punzones o herramientas para modelar (plásticas).

Aceite johnsons o vaselina.

Pincel delineador. (puede ser para uñas).

Cutters.

Colbón o silicona líquida.

Palillos de dientes.

alambre dulce delgado o alpaca.​

**Aula: 12-102**

**Horario​:​**

Grupo 1

Fecha inicio: miércoles, 11 de febrero de 2026

Fecha fin: miércoles, 22 de abril de 2026

Hora: 12:00 m. - 2:00 p. m.

Día: Miércoles

Facilitador(a): Jhon Fernando Muñoz Isaza

Inversión estudiantes de los programas de pregrado y posgrado, profesores y empleados de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

Inversión egresados y graduados de pregrado y posgrado de la Universidad EAFIT: $183.000

Inversión familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado, y de egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT: $183.000

Inversión participantes activos del programa Saberes de Vida: $183.000

Inversión participantes activos de Educación Continua EAFIT o Idiomas EAFIT: $292.800

Costo total del taller a pagar por inasistencia (estudiantes y empleados): $366.000

​​Si eres estudiante de pre y posgrado, profesor y empleado de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

###### Inscripciones a partir de las 8:00 a.m. del 26​ de enero de 2026

Cómo inscribirse en los Talleres Artísticos

### 1

Los talleres artísticos están dirigidos a sus estudiantes, graduados, empleados y pensionados de EAFIT y sus familiares*.

### 2

Elige del menú el taller que quieres cursar y dale clic.

### 3

Lee el contenido del programa, revisa los horarios disponibles y las políticas de los talleres artísticos.

### 4

El día y la hora señalada de inicia de inscripción, será el momento en que se habiliten las opciones de talleres artísticos. Si ingresas antes, no verás opciones de talleres a elegir.

### 5

Una vez ingreses al link de inscripciones, digita tu documento de identidad y sigue la ruta: “Matriculas – Talleres”, y allí buscas el semestre actual.

### 6

Valida que la opción del taller que quieres realizar se encuentre habilitada, la seleccionas y das clic en “Registrarse”.

### 7

Si no encuentras habilitado el taller que quieres cursar, es porque ya se agotaron los cupos.

### 8

Si eres estudiante, empleado o pensionado de EAFIT, debes generar la liquidación para quedar inscrito.

### 9

Si eres graduado o familiar de eafitense, debes generar la liquidación y realizar el pago por los canales establecidos.

*Los familiares corresponden a: padres, hijos, hermanos y esposo o compañero permanente. Tener presente las políticas de los talleres artísticos. Programar muy bien las fechas en que se cursa el taller para hacer un adecuado aprovechamiento de los beneficios que otorga la Universidad. Si al momento de realizar la inscripción no encuentras el taller de tu elección es porque este ya cuenta con cupos disponibles.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate