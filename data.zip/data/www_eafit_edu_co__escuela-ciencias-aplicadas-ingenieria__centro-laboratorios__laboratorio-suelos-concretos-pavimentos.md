# Laboratorio de Suelos, Concretos y Pavimentos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​Laboratorio de Suelos, Concretos y Pavimentos

*    Laboratorio de Suelos, Concretos y Pavimentos 

#### **Servicios​​**

El Laboratorio presta los servicios para el control de calidad y determinación de propiedades físicas, mecánicas y dinámicas de los materiales utilizados en la construcción de obras civiles, para los programas académicos de Ingeniería Civil, Procesos, Producción, Agronómica, Geología, Diseño Urbano y Gestión del hábitat.

El Laboratorio de Civil se divide en 3 áreas de trabajo: Suelos, Concretos y Pavimentos, Construcción e Investigación en Ingeniería Sísmica.

## Mesa Vibratoria y Muro de Reacción

El laboratorio cuenta con capacidades para la investigación y estudio de la respuesta sísmica de diferentes sistemas estructurales utilizados en la construcción de obras civiles y otros productos no estructurales. ​

 El Laboratorio de Construcción se creó para propiciar un espacio para el uso de técnicas y herramientas necesarias en los procesos constructivos de los sistemas estructurales y no estructurales. Cuenta con un muro de reacción y una losa de 9 x 9 metros, donde se realizan pruebas de estructuras ante cargas repetidas mediante 5 actuadores dinámicos de 1000 kN y 100 kN que pueden imprimir cargas laterales y verticales, para ver el comportamiento de ciclos de carga y descarga.​

 En esta estructura se realizan pruebas de fatiga a elementos de gran tamaño a escala real con sistemas de adquisición de datos de desplazamientos, deformaciones y aceleraciones.

 Se cuenta con un marco metálico de carga vertical de 7 metros de altura y 100 toneladas de capacidad para ensayar principalmente muros de mampostería a compresión, cizalladura y flexo tracción; con el apoyo de un puente grúa de capacidad de 10 toneladas y 30 metros de recorrido, que permiten el movimiento de cargas entre las áreas de trabajo del laboratorio de construcción y el laboratorio de Investigación Sísmica.

#### **Recursos​**

## Triaxial dinámico

## Columna resonante

## Triaxial estático

## Triaxial para rocas

## Corte directo

## Consolidómetros

## Cuarto húmedo

## Geogauge

## Prensas multiensayos ​

## Viscosímetro rotacional

## Ductilómetro

## Muro de reacción

## Mesa vibratoria

## Máquina universal de ensayos

## Unidad de adquisición de datos

## Otros equipos para suelos, rocas, asfaltos, mezclas asfálticas, cementos, concretos y morteros​

## Contacto

​​Bladimir Rodríguez Useche, coordinador.

**Correo:**[vrodrig@eafit.edu.co](https://vrodrig@eafit.edu.co/)

**Teléfono:** (57) (604) 2619379

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)