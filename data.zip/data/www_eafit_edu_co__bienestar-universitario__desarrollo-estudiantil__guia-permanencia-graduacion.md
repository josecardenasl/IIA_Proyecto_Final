# Guía de apoyos para la permanencia y la graduación - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 19: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Guía de apoyos para la permanencia y la graduación

Conoce los apoyos, recursos, contenidos y contactos con los que la Universidad EAFIT acompaña la permanencia y graduación de los estudiantes de pregrado

*    Guía de Apoyos Para La Permanencia y La Graduación 

### Acompañamiento integral a estudiantes

**Apoyo Académico**

**Apoyo en recursos**

**Apoyo Psicosocial**

Asignatura BU - Primer semestre

Asesoría en orientación vocacional

Atención psicológica

**Apoyo en salud**

### Otros apoyos

**Apoyo a profesoras y profesores**

**Apoyos para todos y todas**

**Apoyo a estudiantes**

Qué tener en cuenta al momento de presentar un examen

Guía para gestionar tu tiempo y concentrarte

Guía de apoyo para estudiantes foráneos

Concentración durante los exámenes finales

Material sobre orientación profesional

Guía: Un camino para afrontar la adversidad

Guía para el proceso de duelo

### Orientación vocacional profesional

##### Orientación Vocacional

##### Orientación vocacional: orientadores de vida

##### Orientación vocacional: padres de familia

##### ¿Cómo alinear tu propósito de vida con un posgrado?

##### Orientación vocacional: conocerse

##### Orientación vocacional: gestionarse

##### Orientación vocacional: conectarse

##### Desafío de la reorientación profesional: nuevas posibilidades

### ¡Contáctanos!

## Departamento de Desarrollo Estudiantil

## Paola Gaviria Meléndez

Jefe Desarrollo Estudiantil

## Ana María Vargas Betancur

Permanencia estudiantil

## Sara Moreno Osorio

Apoyo psicosocial y psicopedagógico

## Carolina Mejía Henao

Estímulos Estudiantiles

## Diego Osorio Suárez

Grupos y Representantes Estudiantiles

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate