# ​​​​La curiosidad, el origen del descubrir

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# ​​​​La curiosidad, el origen del descubrir

*    ​​​​La Curiosidad, El Origen del Descubrir 

​​Como los más de 3.800 niños que han pasado por sus encuentros, expediciones y talleres, la Universidad de los Niños tiene la capacidad de hacerse preguntas, de abrir los sentidos, de abordar la ciencia desde miradas sorprendentes, curiosas, inspiradoras.

Desde su fundación en 2005, promueve la apropiación social del conocimiento científico en niños, jóvenes y mediadores a través de estrategias de educación y comunicación de las ciencias, basadas en sus principios pedagógicos: el juego, la pregunta, la conversación y la experimentación. Y sus integrantes, como sujetos activos, que gozan con el conocimiento, desarrollan pensamiento crítico, en un ambiente de equidad y consciencia social.

​Este programa se ha articulado con el ecosistema de ciencia y tecnología regional, nacional e internacional, logrando que sus fronteras se amplíen y abriendo nuevos campos de acción. Precisamente, a través de diversas alianzas, la Universidad de los Niños ha venido motivando nuevas preguntas que permean los espacios de aprendizaje no solo de la educación básica y media, sino de las universidades.

## ​​La Universidad de los Niños inició con unos 200 participantes y hoy han pasado por el programa más de 3.800, estableciendo contacto con alrededor de 350​ instituciones educativas públicas y privadas.

> Al principio, cuando ingresé al programa, esperaba clases tipo universidad, pero para niños. Después me di cuenta de que a través del juego y de lo interactivo podía aprender sobre ciencia. Fue algo fascinante. Ahora, en mis últimos años de colegio, veo que estar en la Universidad de los Niños me ayudó a familiarizarme con los conceptos de cómo investigar, que aplico con mucha facilidad. Puedo fluir con ellos y eso para mí es importante”
> 
> 
> José Fernando Zapata Molina, 17 años, estudiante del Colegio Soleira.

## 4 Educación de calidad

## 10 Redución de desigualdades

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate