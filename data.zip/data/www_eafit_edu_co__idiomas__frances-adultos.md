# Francés para adultos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Francés para adultos

### Edad +17

Aprende una de las lenguas más fascinantes y sumérgete en una cultura artística y rica.

*    Francés Para Adultos 

Título de la sección

### Dirigido a

Mayores de 17 años

### Inversión por curso

$947.000

No incluye costo del libro

### Duración

38 horas por curso

## Modalidades

Información general

En Idiomas EAFIT aprendes con una metodología innovadora y efectiva todo lo necesario para comunicarte en un contexto real.

*   Profesores capacitados.
*   Clases prácticas y didácticas diferentes a lo convencional.

Nuestro enfoque te facilita el **aprendizaje significativo de los idiomas** a través de actividades entretenidas, constante interacción en el idioma y secciones prácticas. Esto permite que las clases sean dinámicas, promoviendo el **desarrollo de tus habilidades comunicativas** y el conocimiento que te serán útiles en diferentes ámbitos.

En el programa de francés adultos, tenemos un texto guía que es uno de los recursos empleados por nuestros docentes durante las clases. Si bien no existe obligatoriedad para adquirirlo, está la posibilidad de hacerlo en la librería de la Universidad. ​​

Curso 1

Curso 2

Curso 3

Curso 4

Curso 5

Curso 6

Curso 7

Curso 8

Curso 9

Curso 10

Curso 11

Inversión

###### **​Inversión por curso**

## Todos los cursos

$947.000

Intensivos

###### **Calendario 2026**

###### **11 cursos por año, 10 horas semanales**

**Lunes a viernes**

**​​​Sede Poblado:**6:00 a.m. a 8:00 a.m. / 9:00 a.m. a 11:00 a.m.

# Tabla de Fechas de Matrículas

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Febrero 11 | Noviembre 18 - Enero 20 |
| Febrero 16 | Marzo 11 | Enero 26 - Febrero 16 |
| Marzo 16 | Abril 16 | Febrero 23 - Marzo 16 |
| Abril 21 | Mayo 15 | Marzo 24 - Abril 21 |
| Mayo 19 | Junio 12 | Abril 27 - Mayo 19 |
| Junio 16 (vacacional) | Julio 2 | Mayo 25 - Junio 16 |
| Julio 13 | Agosto 6 | Mayo 24 - Julio 13 |
| Agosto 10 | Septiembre 3 | Julio 21 - Agosto 10 |
| Septiembre 7 | Septiembre 30 | Agosto 19 - Septiembre 7 |
| Octubre 13 | Noviembre 6 | Septiembre 15 - Octubre 13 |
| Noviembre 9 | Diciembre 3 | Octubre 14 - Noviembre 9 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos.**

***Los cursos de****intensivos de francés para adultos****no tienen clase durante estos días:**

Semana Santa

20 de abril

Semi intensivos

###### **6 cursos por año, 6 horas semanales**

**Lunes, miércoles y viernes:​**

**​​​Sede Poblado:**12:00 m a 2:00 p.m.

# Tabla de Fechas de Matrículas

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Febrero 27 | Noviembre 18 - Enero 19 |
| Marzo 2 | Abril 22 | Enero 26 - Marzo 2 |
| Abril 27 | Junio 12 | Marzo 9 - Abril 27 |
| Julio 13 | Agosto 28 | Mayo 25 - Julio 13 |
| Agosto 31 | Octubre 19 | Julio 21 - Agosto 31 |
| Octubre 21 | Diciembre 4 | Septiembre 7 - Octubre 21 |

**Martes y jueves:​**

**Sede Poblado:**6:00 a.m. a 9:00 a.m. /9:00 a.m. a 12:00 m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Febrero 26 | Noviembre 18 - Enero 20 |
| Marzo 5 | Abril 21 | Enero 26 - Marzo 5 |
| Abril 28 | Junio 4 | Marzo 9 - Abril 28 |
| Julio 14 | Agosto 20 | Mayo 25 - Julio 14 |
| Septiembre 1 | Octubre 15 | Julio 21 - Septiembre 1 |
| Octubre 27 | Diciembre 3 | Septiembre 7 - Octubre 27 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos.**

***Los cursos de****francés para adultos****no tienen clase durante estos días:**

Semana Santa

20 de abril

Semana de receso escolar.

Regulares

###### **4 cursos por año, 4 horas semanales**

**Lunes y miércoles**

**Sede Poblado:**6:30 p.m. a 8:30 p.m.

# Tabla de Fechas de Matrículas

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 19 | Marzo 18 | Noviembre 18 - Enero 19 |
| Marzo 25 | Junio 10 | Febrero 2 - Marzo 25 |
| Julio 13 | Septiembre 16 | Mayo 25 - Julio 13 |
| Septiembre 21 | Diciembre 2 | Julio 27 - Septiembre 21 |

**Martes y jueves:​**

**​Sede Poblado:** 12:00 m. a 2:00 p.m. / 2:00 p.m. a 4:00 p.m. / 6:30 p.m. a 8:30 p.m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 20 | Marzo 19 | Noviembre 18 - Enero 20 |
| Marzo 24 | Mayo 28 | Febrero 2 - Mayo 28 |
| Julio 14 | Septiembre 10 | Mayo 25 - Julio 14 |
| Septiembre 15 | Noviembre 19 | Julio 27 - Septiembre 15 |

**Sábado - Modalidad en línea**

**​Sede Poblado:** 8:00 a.m. a 12:00 m.

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Enero 24 | Marzo 21 | Noviembre 18 - Enero 23 |
| Marzo 28 | Junio 6 | Febrero 2 - Marzo 28 |
| Julio 18 | Septiembre 19 | Mayo 25 - Julio 18 |
| Septiembre 26 | Noviembre 28 | Julio 27 - Septiembre 19 |

*En Idiomas EAFIT nos reservamos el derecho de cancelar un grupo cuando**no cumpla con el número mínimo de estudiantes requeridos.**

***Los cursos de****francés para adultos****no tienen clase durante estos días:**

Semana Santa

20 de abril

Semana de receso escolar.

Vacacionales

**Lunes a viernes**

**Sede Poblado**

| Inicia | Finaliza | Matrículas |
| --- | --- | --- |
| Junio 16 | Julio 2 | Mayo 25 - Junio 16 |

## ¿Por qué aprender Francés?

Aumentarás tu confianza y creatividad.

 Mejorarás tus posibilidades de encontrar empleo.

 Descubrirás un universo cultural incomparable.

 Podrás viajar y hablar el idioma en 33 países diferentes.

 Tendrás acceso a las mejores universidades del mundo.

 ¿Qué tal pedir correctamente un croissant en un café de París?.

 Entenderás clásicos del cine como Amélie y La vie en Rose o Léon Le Professionnel.

 Podrás leer Le Petit Prince (El principito), Les Misérables y Madame Bovary en su idioma original.

## ¿Por qué estudiar ​​​idiomas en EAFIT?

Con 30 años de experiencia en la enseñanza de idiomas, como respuesta a las exigencias mundiales, Idiomas EAFIT tiene como objetivo principal dar solución a las necesidades del entorno académico, empresarial y gubernamental.

## Portafolio corporativo

## Global Explorers

# Proceso de inscripción

El primer paso para inscribirte, es conocer cuál es el nivel ideal para ti. Para ello debes realizar una cita de clasificación, solicítala así:

### 1

### 2

### Selecciona la edad del estudiante

Adultos + 17 años.

### 3

### Selecciona el idioma

Francés

### 4

### En la pregunta sobre si tienes conocimiento

selecciona si o no.

### 5

### Sigue los pasos detallados en la plataforma

para programar tu cita de clasificación o realizar la inscripción según tu caso.

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

## Líneas de atención

(57) 604 2619500

## Sugerencias

## ¡Idiomas EAFIT llega a Bello!

Aprende inglés con educación de calidad y una metodología efectiva.

## Spanish program

Personalized sessions adapted to your needs

## English Stars - niños de 4 años

### Edad 4 años

Un programa para aprender inglés y fortalecer habilidades clave para el desarrollo cognitivo, social y comunicativo en la primera infancia.

## Vacacionales Happy Time

### Edad 5 a 10 años

Vacaciones en inglés para niños. Una semana perfecta para disfrutar y conocer el mundo mientras aprenden un nuevo idioma.

## Programa de inglés para niños y niñas

### Edad 4 a 11 años

Metodología participativa con resultados reales que desarrollan habilidades cognitivas y sociales.

## Programas de inglés para niños y niñas

### Edad 4 a 11 años

El programa de inglés para niños que combina el juego, la creatividad y el aprendizaje de un nuevo idioma de manera efectiva

## Inglés para jóvenes

### Edad 12 a 16 años

Conecta con el mundo y fortalece habilidades clave para tu futuro académico y profesional.

## Portugués para adultos

### Edad +17

Disfruta la experiencia de aprender una de las lenguas más dulces y agradables del mundo.

## Italiano para adultos

### Edad +17

Aprende italiano de forma divertida y expande tus horizontes con nuevos conocimientos.

## Francés para adultos

### Edad +17

Aprende una de las lenguas más fascinantes y sumérgete en una cultura artística y rica.

## Alemán para adultos

### Edad +17

Aprende con una metodología efectiva y práctica y descubre la riqueza cultural del alemán, sumérgete en su historia y tradiciones.

## Francés para jóvenes

### Edad 12 a 16 años

Domina una lengua romance fascinante y explora una cultura artística y rica.

## Alemán para Jóvenes

### Edad 12 a 16 años

Descubre la riqueza cultural del alemán y atrévete a sumergirte en su historia y tradiciones.

## Inglés virtual para adultos

### Edad +18

Vive una experiencia flexible, personalizada y con acompañamiento real

## Inglés para adultos

### Edad +17

Domina el inglés con una metodología efectiva y accede a oportunidades para crecer, viajar y destacar profesionalmente.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)