###### Estatutos Generales

###### Reglam​​e​​ntos académicos

###### Estat​uto Pr​​ofesoral

###### Declaraci​​ones de nu​​estra Universidad

###### Reglamento​​​s y polí​​​ticas generales

###### Reglame​ntos y polít​​icas sobre espacios y recursos

###### Políticas, reglam​entos y prot​​ocolos de Ciencia Tecnología e Innovación​​

###### Reglam​entos y prot​​ocolos específicos de programas académicos

[Protocolo de salidas de campo](https://www.eafit.edu.co/protocolo-de-salidas-de-campo)​

###### Reglamentos y pol​​ítica​​s de asuntos estudiantiles​

###### Reglamentos para estudiantes de pregrado​

###### Prot​​ocolos

###### Ecosistema de gobierno de datos e información