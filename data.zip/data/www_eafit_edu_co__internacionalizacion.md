# Internacionalización - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Internacionalización

Como parte de la Vicerrectoría de Aprendizaje, Internacionalización EAFIT desarrolla relaciones internacionales y construye capacidades transversales en la Universidad, generando experiencias para la comunidad eafitense. Dichas experiencias tienen como objetivo el desarrollo de una visión global y competencias interculturales que faciliten su inserción en contextos nacionales e internacionales, y su participación propositiva como profesionales y ciudadanos del mundo.

*    Internacionalización 

# Experiencias

Para quienes ya son eafitenses

## Intercambio académico internacional

## Intercambio académico nacional

## Convenios

## Oportunidades para profesores

## Prácticas en el exterior

## Pasantías de investigación

## Misiones – programas a la medida

## Aprendizaje global

## Cooperación Internacional en CteI

Para quienes quieren venir a EAFIT

## Intercambio académico internacional / Exchange

## Intercambio académico nacional

## Convenios / Partnerships

## Spanish program

## Oportunidades para profesores / Opportunities for faculty

## Pasantías de investigación / Research internships

## Misiones – programas a la medida / Tailor-made programs

## Aprendizaje global / Global Learning

## Cooperación Internacional en CteI / International Cooperation STI

## EAFIT, tu próximo destino / EAFIT, your next destination

Nuestras capacidades

Campus

Conoce nuestra Universidad Parque.

CTeI

Promover la investigación y generamos proyectos dinámicos e interdisciplinarios para responder a los desafíos de la sociedad.

Nuestras escuelas y programas

Centros de estudio e incidencia

## Convenios

## Para estudiantes eafitenses

Encuentra aquí los convenios disponibles para realizar intercambios o dobles titulaciones a nivel nacional e internacional.

## Para usuarios externos

Conoce nuestros aliados nacionales e internacionales.

## Aprendizaje global

Promovemos la formación de los eafitenses como ciudadanos del mundo, con competencias globales e interculturales.

Casos y experiencias

La noche internacional

Un espacio para vivir la cultura y la gastronomía del mundo de la mano de nuestros estudiantes internacionales.

Harvard Business School – FIELD Global Immersion Course

EAFIT

Conoce los testimonios de nuestros estudiantes de intercambio nacional e internacional y elige EAFIT como tu próximo destino.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)