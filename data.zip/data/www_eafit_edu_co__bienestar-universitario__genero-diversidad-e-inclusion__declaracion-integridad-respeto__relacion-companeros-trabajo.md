# Relación entre compañeros de trabajo - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Relación entre compañeros de trabajo

*    Relación Entre Compañeros de Trabajo 

Pensarnos como comunidad universitaria a la luz de estas reflexiones implica abordar la relación entre compañeros de trabajo y, en este contexto, la relación entre pares y la relación entre jefes y colaboradores, ambas construidas con base en el respeto.

###### Retos y lecciones aprendidas

Teniendo en cuenta la clara distinción entre la relación de verticalidad que existe entre un jefe y un colaborador, y entre dos compañeros (a) de trabajo, habría que decir que, en el primer caso, el o la jefe tiene un poder directo sobre la persona subordinada. En ese orden de ideas, estas reclaman un mayor cuidado en la manera como se construyen estas relaciones. Por , lo anterior, asuntos como el lenguaje verbal y corporal, el espacio vital entre las personas, los horarios de comunicación y los encuentros por fuera de la Institución deben ser muy cuidados para evitar malos entendidos, extralimitaciones y situaciones que puedan generar incomodidad en cualquiera de las partes.​

###### Guía y recomendaciones entre compañeros de trabajo​​

Las siguientes recomendaciones tiene origen en los casos conocidos por el Comité de Inclusión y Equidad, y su pretensión no es otra que concientizar sobre la importancia de tener en cuenta las siguientes situaciones que pudieran afectar la relación laboral y, por ende, el desempeño de las personas involucradas. ​

Comunicaciones y contenido en redes sociales

Si bien es importante construir una relación laboral cercana y abierta, también lo es ser muy conscientes de los límites y las implicaciones de cualquier actuación, aproximación y expresión con las cuales se pueda afectar la dignidad del subordinado o compañero de trabajo. Por ello, es prudente tener claro la pertinencia de lo que se comparte en redes sociales y, en general, en cualquier tipo de comunicación.

​Reuniones sociales

En una cultura como la nuestra puede ser frecuente compartir en algunos espacios sociales dentro y fuera de la Universidad, lo cual puede generar un clima laboral favorable. Sin embargo, es importante señalar que la presencia del licor y/o de sustancias psicoactivas podrían generar situaciones que se salgan de control y que pueden terminar afectando a otras personas. Con el fin de evitar desenlaces desafortunados, conviene que se evalúe muy bien el tipo de encuentros que se propician y las condiciones en que estos se desarrollan​.

Relación con estudiante en semestre de práctica profesional dentro y fuera ​de la Universidad

Cuando un estudiante está en su semestre de práctica profesional se inicia una relación de aprendizaje, pero también subordinada, en el marco de una realidad laboral. Por ello, cobra relevancia tener presente que, en esa verticalidad, existen unas obligaciones a cargo del practicante y del jefe que siempre deben observarse en el marco del respeto. No obstante, entre los casos que ha conocido el Comité de Inclusión y Equidad se presentan situaciones derivadas de aproximaciones inapropiadas: chistes sexistas, roces o tocamientos innecesarios, llamadas a horas no laborales, invitaciones a salir, entre otros, que generan profunda incomodidad en el estudiante en práctica. De esta manera, tanto los (as) jefes en la Universidad que tengan estudiantes en práctica, como los externos, deben estar muy atentos y cuidadosos en la manera de desarrollar esa relación laboral, siempre guiada por el respeto. ​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate