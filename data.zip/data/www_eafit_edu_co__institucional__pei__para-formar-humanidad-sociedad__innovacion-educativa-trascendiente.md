# Innovación educativa sin fronteras

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​​​Innovación educativa que trasciende las fronteras institucionales​

*    ​​Innovación Educativa Que Trasciende Las Fronteras Institucionales 

​​Va mucho más allá de un trabajo instrumental, del uso de una herramienta. Los proyectos tienen que ver con el fortalecimiento de sus habilidades como seres humanos, de su compromiso con sus instituciones, con sus compañeros, con su comunidad, con el medio ambiente, con la convivencia, con el mundo que habitan. Y si bien se diseñan unas acciones permeadas por el uso de las tecnologías, en el núcleo se encuentra el desarrollo del ser.

En el componente de transformación del ecosistema local y nacional, la Universidad, a través de EXA-el Ce​ntro para la Excelencia en el Aprendizaje, cuenta con experiencia en el desarrollo de proyectos de investigación e innovación con el uso de tecnologías digitales en los niveles de educación básica y media, a través del Modelo UbiTAG, la incidencia en el diseño y ejecución de políticas públicas en educación, y la consolidación de convenios colaborativos en los ámbitos nacional e internacional.

Aprender Digital, Plan Saber Digital y Plan Digital de Itagüí se encuentran entre los programas que buscan generar una cultura de innovación en el aprendizaje escolar, transformar prácticas institucionales y lograr la madurez digital, gracias a la implementación del modelo UbiTAG que ha venido fortaleciéndose en el país durante varios años, generando un impacto positivo. No solo permite que la institución, como eje de la transformación, sea quien irradie los cambios, sino que los resultados se notan en los diferentes actores que hacen parte del ecosistema educativo territorial.

El modelo UbiTAG fue desarrollado por una de las líneas de investigación del grupo de investigación de EAFIT I+D+I en Tecnologías de la Información y las Comunicaciones (Giditic), que desde el año 1987 se dedica a la innovación de este tipo de soluciones.

En el desarrollo de la alianza con el Ministerio de Educación, la Dirección de Innovación y EXA lideran la ejecución del proyecto Transformación Digital de la Educación en Colombia.

También se avanza en el Laboratorio Digital de Innovación Educativa en Educación Superior, que hace parte del proyecto con el Ministerio.

## Plan Digital Itagüí

Es un proyecto socioeducativo que acompaña a los establecimientos educativos oficiales de este municipio en el desarrollo de capacidades para la integración de las TIC, la gestión del cambio y la innovación en los procesos institucionales.

 En convenio con la Alcaldía de Itagüí se convirtió en política pública por el interés de dicha administración en generar un plan que vinculara aliados del territorio, regionales y nacionales. EAFIT, a través de su experiencia, implementó el modelo UbiTAG y acompañó con un grupo de investigadores que aportaron conocimientos, prácticas y metodologías.

 Se ha llegado a unos 1.160 docentes, 33 mil estudiantes y 92 directivos, de 24 instituciones educativas. Gracias a esa unión de fuerzas se lograron transformaciones importantes en los diferentes contextos de la gestión institucional e inversión en infraestructura y en formación de los docentes. Este “micro ecosistema” de innovación fue referente para el Plan Saber Digital en Bogotá.

## Plan Saber Digital

Lo conseguido en Itagüí y en otros proyectos con el Ministerio de Educación, llamó la atención de la Secretaría de Educación de Bogotá. Así, la Universidad llegó al distrito para realizar un acompañamiento escalonado a las instituciones educativas, para, en la misma línea de las propuestas anteriores, fortalecer los ambientes de aprendizaje a través del uso de tecnología.

 Bogotá contaba con actores y aliados importantes que hacían parte del proceso de transformación; además, en general, disponían de dotaciones y equipos adecuados, comparativamente con otras zonas del país. La idea era aprovechar esos recursos con los que ya se contaban para fortalecer ambientes de aprendizaje. Se empezaron a diseñar nuevos escenarios y experiencias con uso de tecnología, reconociendo el contexto, caracterizando las instituciones e identificando cuáles eran las necesidades.

 Esto, precisamente, permitió construir unos planes de trabajo que derivaron en el Plan Saber Digital. De 2016 a 2019 se impactó casi la totalidad de las instituciones educativas distritales oficiales. En este 2020, debido a las circunstancias especiales, se denomina Aprende en Casa con Saber Digital.

## Plan Aprender Digital

Es un modelo de acompañamiento pedagógico a comunidades educativas, que busca fomentar la innovación educativa y transformar los ambientes de aprendizaje por medio del uso y apropiación de las TIC.

 Esta transformación digital implica un cambio en la manera en que estudiantes, docentes, directivos y padres de familia comparten, aprenden, comprenden y habitan el escenario escolar. Para ello se trabaja en la incorporación y apropiación de herramientas digitales, en la gestión institucional, en las prácticas pedagógicas, en la cualificación de los procesos de aprendizaje y en la movilización social.

 En 2019, Aprender Digital llegó a unas 200 instituciones educativas en el país, con resultados muy interesantes, logrando un trabajo articulado con el programa Todos a Aprender (PTA) del Ministerio de Educación, a través de los tutores PTA, que contribuyen a mejorar las prácticas pedagógicas. Ese acompañamiento fortaleció el uso de tecnología, pero también las diferentes áreas del conocimiento.

## 4. Educación de calidad

## 8. Trabajo decente y crecimiento ecónomico

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)