# ​​Líderes del presente y del futuro

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​​Líderes del presente y del futuro

*    ​​Líderes del Presente y del Futuro 

​​Hay iniciativas que se quedan en el alma, que permanecen, porque reflejan esos sueños de forjar humanidad y sociedad. Una de ellas fue Jóvenes 20/20, que, en 2019, formó líderes para el presente y el futuro, agentes de cambio para una ciudad educadora.

Esta plataforma de liderazgo fue una alianza público-privada de EAFIT, la Alcaldía de Medellín, Comfama y la fundación empresarial Proantioquia, a cuya convocatoria se presentaron más de 650 aspirantes, entre los 16 y 26 años, con iniciativas de transformación social desde distintos territorios. Fueron 40 los seleccionados, líderes juveniles en arte y cultura, educación, derechos humanos, medio ambiente, deporte, convivencia y emprendimiento, entre otros asuntos, que aportaron visiones desde sus distintos niveles de formación, y ahora multiplican su experiencia y proyectos en sus entornos.

###### Ecos de su participación:

> Mi mayor aprendizaje fue encontrar personas con las que puedo construir una ciudad a la medida de nuestros sueños; escuchar y construir desde la diversidad. Somos más los que creemos que el cambio es posible y que aún hay tiempo de hacer acciones concretas que construyan una gran transformación”
> 
> 
> Surany Gómez Mesa, estudiante de Trabajo Social

> Soy un líder al compartir mi semilla que me aferra a mis sueños, a mis metas, pero más aún a lograrlas, soy un líder al apoyar y realizar diferentes proyectos en busca de un desarrollo humano. Soy un líder al escuchar las diversas semillas y al pensar, cómo en equipo, lograremos vencer. (…) Acá es donde me considero líder, por no quedarme quieto, al saber que puedo hacer más por mi ciudad”
> 
> 
> Camilo Andrés Rojas Sarria, estudiante de ingeniería de sonido y director de la emisora de la Corporación Ciudad para Todos

## 4. Educación de calidad

## 10. Reducción de las desigualdades

## 17. Alianzas para lograr objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)