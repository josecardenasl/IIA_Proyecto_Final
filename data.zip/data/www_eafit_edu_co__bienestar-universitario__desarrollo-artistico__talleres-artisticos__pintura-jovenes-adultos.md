# Pintura para jóvenes y adultos

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Pintura para jóvenes y adultos - 30 horas

Inscripciones primer semestre de 2026: A partir de las 8:00 a.m. del 26 de enero

*    Pintura Para Jóvenes y Adultos - 30 Horas 

###### Taller dirigido: Estudiantes, graduados​, profesores, empleados y pensionados de la Universidad EAFIT y sus familiares (padres, hijos, hermanos y esposo o compañero permanente). ​​

Si eres estudiante, empleado, profesor o pensionado, al inscribirte en el Taller aceptas la Política de los Talleres Artísticos, por lo tanto ten en cuenta que deberás administrar tus faltas de asistencia. Al momento de incumplir con el 80% de asistencia a tu Taller, el sistema te generará una cuenta de cobro por el costo total del taller, sin descuento ninguno.

Este taller busca que los participantes obtengan conocimientos básicos del dibujo y la pintura conociendo algunas técnicas pictóricas, el uso de los colores primarios y secundarios, la perspectiva, iluminación, luces y sombras. La pintura es un reflejo de nuestro interior, entonces, al poner sobre el papel o la tela los colores que imaginamos y sentimos, estamos reconociéndonos a nosotros mismos y al mismo tiempo proporcionándonos una alegría que nos acompaña durante largo rato, sobre todo cuando vemos la obra terminada: una experiencia que repetiremos una y otra vez. 

Sesión 1: Las proporciones del rostro, medidas perfectas, en niños y adultos.

Sesión 2: Se trabaja sobre el ejercicio que hicieron, se aclaran dudas y refuerza el conocimiento.

Sesión 3: Proporciones del cuerpo humano en niños y adultos. Se dejan ejercicios para la práctica. 

Sesión 4: Seguimos con el cuerpo humano, diferentes posturas, manos y pies.

Sesión 5: Teoría del color, escala cromática, ejercicios. 

Sesión 6: Se trabaja sobre el tema visto, los colores primarios, secundarios y la escala cromática.

Sesión 7: Conceptos básicos de perspectiva, qué es un punto de fuga, cómo dibujar diferentes objetos midiendo su altura y proporciones. 

Sesión 8: Vamos a pintar un bodegón para aplicar las proporciones, la perspectiva, las luces y sombras. Se deja un ejercicio para la práctica.

Sesión 9: Conocimientos básicos de la acuarela, ejercicios para aprender diferentes texturas. Se dejan ejercicios para practicar. 

Sesión 10: Seguir explorando en la técnica de la acuarela. Haciendo un pequeño paisaje sobre acuarela húmeda.

Sesión 11: Pintar hojas, flores y árboles en acuarela para reforzar la técnica y ver lo versátil que es; trabajo con la acuarela más seca.

Sesión 12: Pintando nubes con acuarela. Sobre húmedo y utilizando un algodón para dar efectos.

Sesión 13: Pintura básica de óleo, estilo clásico de pintar esta técnica.

Sesión 14: Cómo dibujar un ojo con óleos, cómo hacer los diferentes tonos de piel. Se deja el ejercicio para practicar.

Sesión 15: Pintar una fruta, la que quieran, con óleo, poniendo en práctica los conocimientos usando el estilo clásico de hacerlo.

A la primera clase solo debes traer hojas blancas de papel bond, lápiz y borrador. En esta clase el facilitador te explicará la lista de materiales necesaria para el resto de las clases y te dará sugerencias para conseguirlos.

**Aula: 12-102**

**Horario​:​**

**Grupo 1**

Fecha inicio: lunes, 9 de febrero de 2026

Fecha fin: lunes, 1 de junio de 2026

Hora: 12:00 m. a 2:00 p. m.

Día: Lunes

Facilitador(a): Daniel Echeverry Arango

**Grupo 2**

Fecha inicio: martes, 10 de febrero de 2026

Fecha fin: martes, 26 de mayo de 2026

Hora: 12:00 m. a 2:00 p. m.

Día: Martes

Facilitador(a): María Teresa Bravo

**Grupo 3**

Fecha inicio: martes, 10 de febrero de 2026

Fecha fin: martes, 26 de mayo de 2026

Hora: 6:00 p. m. a 8:00 p. m.

Día: Martes

Facilitador(a): Jhon Fernando Muñoz Isaza

**Grupo 4**

Fecha inicio: jueves, 12 de febrero de 2026

Fecha fin: jueves, 28 de mayo de 2026

Hora: 12:00 m. a 2:00 p. m.

Día: Jueves

Facilitador(a): María Teresa Bravo

**Grupo 5**

Fecha inicio: jueves, 12 de febrero de 2026

Fecha fin: jueves, 28 de mayo de 2026

Hora: 6:00 p. m. a 8:00 p. m.

Día: Jueves

Facilitador(a): Jhon Fernando Muñoz

**Grupo 6**

Fecha inicio: viernes, 13 de febrero de 2026

Fecha fin: viernes, 5 de junio de 2026

Hora: 12:00 m. a 2:00 p. m. 

Día: Viernes

Facilitador(a): Daniel Echeverry Arango

Inversión estudiantes de los programas de pregrado y posgrado, profesores y empleados de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

Inversión egresados y graduados de pregrado y posgrado de la Universidad EAFIT: $289.000

Inversión familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado, y de egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT: $289.000

Inversión participantes activos del programa Saberes de Vida: $289.000

Inversión participantes activos de Educación Continua EAFIT o Idiomas EAFIT: $462.400

Costo total del taller a pagar por inasistencia (estudiantes y empleados): $578.000

​​Si eres estudiante de pre y posgrado, profesor y empleado de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

###### Inscripciones a partir de las 8:00 a.m. del 21 de julio​ de 2025​

Cómo inscribirse en los Talleres Artísticos

### 1

Los talleres artísticos están dirigidos a sus estudiantes, graduados, empleados y pensionados de EAFIT y sus familiares*.

### 2

Elige del menú el taller que quieres cursar y dale clic.

### 3

Lee el contenido del programa, revisa los horarios disponibles y las políticas de los talleres artísticos.

### 4

El día y la hora señalada de inicia de inscripción, será el momento en que se habiliten las opciones de talleres artísticos. Si ingresas antes, no verás opciones de talleres a elegir.

### 5

Una vez ingreses al link de inscripciones, digita tu documento de identidad y sigue la ruta: “Matriculas – Talleres”, y allí buscas el semestre actual.

### 6

Valida que la opción del taller que quieres realizar se encuentre habilitada, la seleccionas y das clic en “Registrarse”.

### 7

Si no encuentras habilitado el taller que quieres cursar, es porque ya se agotaron los cupos.

### 8

Si eres estudiante, empleado o pensionado de EAFIT, debes generar la liquidación para quedar inscrito.

### 9

Si eres graduado o familiar de eafitense, debes generar la liquidación y realizar el pago por los canales establecidos.

*Los familiares corresponden a: padres, hijos, hermanos y esposo o compañero permanente. Tener presente las políticas de los talleres artísticos. Programar muy bien las fechas en que se cursa el taller para hacer un adecuado aprovechamiento de los beneficios que otorga la Universidad. Si al momento de realizar la inscripción no encuentras el taller de tu elección es porque este ya cuenta con cupos disponibles.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate