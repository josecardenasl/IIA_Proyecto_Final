# Computational Study of Cell Mobility and Transport Phenomena Through Textile Vascular Grafts Using a Multi-Scale Approach - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Computational Study of Cell Mobility and Transport Phenomena Through Textile Vascular Grafts Using a Multi-Scale Approach

*    Escuela Ciencias Aplicadas Ingenieria 
*    Computational Study Of Cell Mobility And Transport Phenomena Through Textile Vascular Grafts Using A Multi-Scale Approach 

###### Raúl A. Valencia

**Abstract**

Textile vascular grafts are biomedical devices that serve as partial replacement of damaged arterial vessels, prevent aneurysms rupture and restore normal blood flow. It is believed that the success of a textile vascular graft, in the healing process after implantation, is due to the porous micro-structure of the wall. Among the key properties that take part in the tissue repair process are the type of fabric and degree of porosity and permeability, defining the ability of a well-controlled environment for the neovascularization, nutrient supply, and cellular transport. Although the transport of fluids through textiles is of great technical interest in biomedical applications, little is known about predicting the micro-flow pattern and the transport and deposition of individual platelets, related with the graft occlusion. Often, this information is difficult to obtain experimentally both in vivo and in vitro, representing a great deal of research efforts.

The aim of this work is to investigate how the type of fabric, permeability and porosity affect both the local fluid dynamics at several scales and the fluid-particle interaction among platelets in textile grafts with an anastomosis of end-to-end configuration. Two types of samples were analyzed: woven and electrospun, this last one has been manufactured.  This study involves both experimental and computational tests. The experimental tests were performed to characterize the permeability and porosity under static conditions. The computational tests are based on a multi-scale approach where the fluid flow was solved with the Finite Element Method and the discrete particles were solved with the Molecular Dynamic Method.  The fluid-particle interaction was accomplished in one-, two-, and four-ways, where the blood was considered as a suspension of platelets in plasma. The textile wall was considered as a porous media with two scales of length: straight tubular structure with porous walls for the macro-domain and representative unit cells of fabric for the micro-domain.  Additionally, it presents the implementation of a numerical case that includes one of the main applications of textile vascular grafts to repair Abdominal Aortic Aneurysms (AAA).

The results have shown that the type of fabric in textile vascular grafts and the degree of porosity and permeability affect the local fluid dynamics and the level of penetration of platelet particles through the graft wall at several length scales, thus indicating their importance as design parameters. It was found that the permeability is strongly depends on the micro-structure of the fabric, changing the local fluid dynamics and the time of residence of platelets inside the wall. Moreover he porous walls cause deviations from Poiseuille flow due to leakage flow through the wall from a macroscopic viewpoint. Lastly, it was possible to observe that the textile wall with different porosities, acting like a barrier between the blood and an aneurysmal zone, affects the flow pattern, the number of platelets adhered to the artificial surface and the time of residence of platelets into the aneurysmal zone.

In conclusion, predicting the flow pattern and the mobility of blood cells through the textile wall before the graft is manufactured, the development of new textile grafts can be improved.

**Keywords:** textile vascular grafts, porous media, local fluid dynamics, fluid-particle interaction, multi-scale approach.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)