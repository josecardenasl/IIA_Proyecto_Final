# Diálogos de integridad - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Diálogos de integridad

*    Diálogos de Integridad 

Ciudadanía íntegra digital ¿Para qué la ética en entornos digitales?

**Diálogo de Integridad Ciudadanía íntegra digital: ¿Para qué la ética en entornos digitales?**

**Participantes:**

Perla Toro Castaño, Responsable de Comunicaciones de Comfama.

Jonathan Echeverri, profesor de psicología de la Universidad EAFIT e investigador del Centro de Integridad.

**Modera:** Camilo Guzmán, consultor del Centro de Integridad.

Integridad y Género: Hacia la construcción de nuevas masculinidades.

**Diálogo de integridad y Género: Hacia la construcción de nuevas masculinidades.**

**Conversación entre:**

Andrés Olaya, profesor de la Universidad de Antioquia, la Universidad EAFIT y Universidad del Norte.

Pablo Bedoya, profesor de la Universidad de Antioquia.

**Mo​dera:** Nathalia Franco Pérez, Jefe del Centro de Integridad, Universidad EAFIT.

Marzo 16 de 2021​

¿Generamos un ambiente de respeto en el campus?

**¿Generamos un ambiente de respeto en el campus?:**

**Fecha:** 1 de octubre de 2018.

De la mano de Tatiana Romero Acevedo, coordinadora del grupo de justicia, y Ana Cristina Restrepo Jiménez, periodista y docente de cátedra en EAFIT, se habló sobre el nuevo proyecto de #RespetoEnEafit que busca desnaturalizar ciertas conductas que fomentan el irrespeto, además de abrir un canal de contacto para los casos y protocolo para la equidad de género y la sexualidad diversa.

La integridad en la tecnología

**La integridad en la tecnología: construyendo una ciudadanía digital**

**Fecha:**5 de abril de 2019.

De la mano de Juan Cristóbal Cobo, director de la Fundación Ceibal, y Diego Ernesto Leal, director del Centro de Excelencia en EAFIT, se habló sobre la incidencia de la tecnología en los procesos de aprendizaje y en las relaciones humanas.

Respeto y tolerancia ¿Qué tanto aceptamos la sexualidad diversa en Colombia?

De la mano de Mauricio Albarracín, investigador de Dejusticia y activista LGTBI , y de Carlos Julio Benjumea, profesor de Derecho de la Universidad EAFIT, se conversó sobre la manera como se vive en Colombia la tolerancia y el respeto por la sexualidad diversa, a nivel político, social, histórico y jurídico.

Integridad vs Fraude Académico

De la mano de Jean Guerrero, director del Centro de Integridad de la Universidad de Monterrey, y Pablo Andrés Estrada, estudiante de Ciencias Políticas y Economía, y representante estudiantil de pregrado ante el COnsejo Académico. Conversaron sobre el fraude académico y los efectos de la virtualidad en el proceso formativo.

¿Por qué hablar de acoso sexual en universidades?

**Diálogo de integridad ¿Por qué hablar de acoso sexual en universidades?**

Miradas desde Chile, México y Colombia. Con: Karla Urriola, Oficina Nacional de Género y Comunidad Segura del TEC de Monterrey . Cecilia Rosales, Consejo de Prevención y Apoyo a Víctimas de Violencia Sexual, Pontificia Universidad Católica de Chile. María Ximena Dávila, investigadora de Dejusticia Colombia. Nathalia Franco, jefa del Centro de Integridad de EAFIT. Universidad EAFIT. Octubre 21 de 2020.

La Universidad EAFIT tiene la Misión de Contribuir al desarrollo sostenible de la humanidad mediante la oferta de programas que estimulen el aprendizaje a lo largo de la vida, promuevan el descubrimiento y la creación y propicien la interacción con el entorno, dentro de un espíritu de integridad, excelencia, pluralismo e inclusión.​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate