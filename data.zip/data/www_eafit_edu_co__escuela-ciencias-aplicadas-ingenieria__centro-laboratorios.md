# Centro de Laboratorios - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Centro de Laboratorios

*    Centro de Laboratorios 

​​​​​​​​​​​​El Centro de Laboratorios (CLAB) es una unidad de servicios de apoyo académico, que gestiona, planifica e integra recursos tecnológicos y personal calificado para ofrecer actividades de aprendizaje experiencial a la Escuela de Ciencias Aplicadas e Ingeniería.

Está situado al extremo sur del campus universitario, ocupando parcialmente los bloques 13, 19, 20, ​21 y 22. Cuenta con espacios para el desarrollo de las prácticas de laboratorio de los programas académicos, facilitando asesoría técnica para garantizar que docentes y estudiantes conozcan y comprendan el manejo de los equipos, softwares y los sistemas disponibles. También apoya el trabajo académico independiente de los estudiantes resultante de las diferentes materias y los proyectos de grado.

​Adicionalmente, provee recursos tecnológicos para el desarrollo de investigaciones en diversos campos de la ciencia y la ingeniería lideradas por nuestros docentes y en colaboración con otras Instituciones.

El CLAB mantiene una relación fuerte con la industria y el sector productivo e igualmente con una red de laboratorios nacionales, a través de colaboraciones, de servicios de análisis, ensayos, calibraciones y fabricación de piezas.

> ​​​​​​Ser desde la Universidad EAFIT, un referente generador e integrador de talento, tecnologías y servicios de laboratorios y talleres, que avanza en el desarrollo sostenible y evoluciona con la comunidad académica y la sociedad”.

​​​Laboratorios y talleres​

## Laboratorio de Suelos, Concretos y Pavimentos

Laboratorios de suelos, concretos y pavimentos, donde se hace caracterización físico-mecánica y dinámica de materiales para la construcción de obras civiles.

## Talleres de Diseño

Construcción de modelos y prototipos en materiales blandos, moldeables tales como: maderas naturales y prefabricadas, acrílicos, espumas y acabados con pinturas nitrocelulosas, catalizadas y poliuretanos.

## Laboratorios de Ciencias Biológicas

Procesos evolutivos, ecológicos, moleculares y químicos que dan origen a la vida de microrganismos y macroorganismos para la generación de nuevo conocimiento y sus aplicaciones.

## Laboratorios de Procesos

Técnicas instrumentales como cromatografía líquida, cromatografía de gases, polarimetría y técnicas de absorción como espectrometría UV visible y espectrometría infrarroja. Además de equipos de operaciones unitarias.

## Laboratorios de Ciencias de la Tierra

Servicios de apoyo desde las áreas de petrología, sedimentología, paleontología, geología física, tectónica, geología ambiental y manejo de colecciones de rocas.

## Laboratorios de Ciencias Físicas

Apoyo desde áreas de física general, óptica, microingeniería, materiales cerámicos, materiales ferrosos y en desarrollos de materiales por recubrimiento por plasma, microscopia electrónica de barrido SEM con identificación elemental EDX y espectroscopía.

## Taller de Proyectos Metalmecánicos

Taller de procesos de manufactura de modelos y prototipos metalmecánicos, mediante la técnica de la unión y ensamble por laminado, corte y soldadura.

## Laboratorio de Control Digital

Capacitaciones en áreas de electrónica, programación, redes, IoT y técnicas usadas en almacenamiento. Diseño de equipos electrónicos y didácticos para la enseñanza del control.

## Laboratorio de Hidráulica

Asesoría técnica en las magnitudes presión y flujo, ensayos de caracterización y pruebas hidrostáticas de máquinas y elementos hidráulicos como bombas centrífugas, válvulas de compuerta y medidores de presión y flujo, entre otros.

## Laboratorio de Materiales

Caracterización y medición de propiedades mecánicas en materiales de ingeniería para clientes internos y externos y procesamiento de polímeros para docencia e investigación.

## Laboratorio de Metrología

Calibración de instrumentos de medición de las magnitudes longitud, fuerza, presión y mediciones dimensionales y geométricas en 2 y 3 dimensiones a piezas mecánicas o elementos terminados.

## Laboratorio de Mecatrónica

Capacitaciones en áreas de electrónica mecánica experimental y medición de deformación a través de galgas. Diseño de equipos electrónicos y didácticos con alto componente mecánico.

## Taller de Máquinas Herramienta

Maquinado de piezas y moldes para docencia e investigación. Capacitación en manejo de máquinas y herramientas convencionales y de control numérico.

### **Diferenciales**

## + 18.000

millones de pesos invertidos en equipos, dispositivos y herramientas​

## + 10.000

m2 área construida

## 103

espacios de trabajo

## + 3.000

equipos

## + 70

investigaciones

## 65

colaboradores

## 2.501

especímenes en la colección bioló​gica

## 152

materiales en la Materioteca

## + 5.200

piezas en la colección de minerales y rocas

​​Puedes reportar tus peticiones, quejas, reclamos, sugerencias y felicitaciones en [nuestro portal](https://www.eafit.edu.co/pqrsf)​.

Si quieres conocer cómo es el tratamiento de tus PQRSF en nuestro Centro de Laboratorios, [haz clic aquí​](https://universidadeafit.widen.net/s/sjcrmlww9w/tratamiento-de-quejas-centro-laboratorios).

## Contacto

Patricia Atehortúa Bustamante, Jefa Centro de Laboratorios.

**Correo:**[patehortub@eafit.edu.co​](mailto:patehortub@eafit.edu.co%E2%80%8B)

## Contacto

​Orfilia Gallego López, Auxiliar Centro de Laboratorios.

**Correo:**[ogallego@eafit.edu.co​](https://ogallego@eafit.edu.co/)

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)