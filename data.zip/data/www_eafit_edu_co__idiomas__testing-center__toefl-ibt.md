# TOEFL IBT - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# TOEFL IBT

*    TOEFL IBT 

## Información general

Descripción del examen

El TOEFL es una certificación internacional utilizada con fines académicos, laborales y de migración aceptada en gran parte de las universidades y países del mundo que mide la habilidad para usar y entender el idioma inglés. Esta certificación está contemplada dentro de la política de lengua extranjera de la Universidad EAFIT.

Estructura

La prueba tiene una duración de **2,5 horas** y se compone de 4 componentes; escritura, comprensión lectora, escucha y conversación los cuales son evaluados en computador.​

Proceso de inscripción

Hay dos formas de hacer el proceso de inscripción, una es directamente a través de ETS www.ets.org/toefl pagando en dólares con tarjeta de crédito. La otra es a través de Corprefer toefl@corprefer.com pagando en pesos colombianos y obteniendo un **10%** de descuento en la tarifa.

Estos serían los pasos a seguir haciéndolo directamente con **ETS**:

Ingresa a la página [www.ets.org/toefl](https://www.ets.org/toefl.html) y realiza el pago únicamente con tarjeta de crédito ( la Universidad EAFIT **no recibe pagos bajo ninguna modalidad** ya que la tarifa que estás cancelando es directamente generada por ETS, ente oficial del examen).

1.   Registro telefónico en EEUU: (1) 443 751 4995 Fax: (1) 443 751 4980.
2.   El cupo es **limitado**, por lo tanto, se recomienda realizar la inscripción con mínimo tres semanas de anticipación a la fecha del examen.
3.   **Inversión:** USD $240

Realizando la inscripción por Corprefer obtendrás un 10% de descuento en la tarifa del examen. Por este medio, recibirás asesoría en la inscripción con una persona de Corprefer y puedes hacer el pago en pesos colombianos. Solo deberás enviar un mensaje a [toefl@corprefer.com](mailto:toefl@corprefer.com) mostrando interés en participar en la sesión del TOEFL de la Universidad EAFIT de cierta fecha de acuerdo a nuestro calendario. El valor a pagar dependerá de la TRM y puede ser con tarjeta débito, transferencia o efectivo en bancos.

Inversión

### TOEFL IBT

USD $256

Calendario 2026

| Fechas |
| --- |
| Mayo 30 |

Notificación de resultados

Los resultados se carga **8 días hábiles** después de presentado en la cuenta de ETS que haya creado para presentar el examen.

Observaciones

1.   La citación oficial al examen la recibirá directamente a su correo electrónico y es enviada por ETS.org. Favor revisar su bandeja de entrada y/o spam con 3 días de anticipación al examen, allí encontrará la información relacionada al lugar, hora exacta, documentos de identidad válidos, número de registro y toda la información relevante que usted debe conocer antes de presentar la prueba.
2.   Ejercicios de práctica para el TOEFL iBT: [http://toeflpractice.ets.org/](http://toeflpractice.ets.org/)
3.   Antes de inscribirse para el examen verificar con la institución que lo solicita la validez de este, así como el puntaje exigido. **La Universidad EAFIT no se hace responsable si presenta un examen no válido.**
4.   La Universidad EAFIT **no emite certificados físicos**, en caso de requerirlos debe solicitarlo directamente en la plataforma ETS al momento de realizar la inscripción.

###### Preguntas frecuentes

​​​Conoce nuestros protocolos e información general sobre nuestro Testing Center.

1.   Estudiantes que desean ingresar y/o egresar en una institución de educación superior.
2.   Estudiantes en proceso de admisiones y/o egreso del programa de aprendizaje del idioma inglés.
3.   Candidatos que desean presentarse para obtención de becas y certificaciones.
4.   Alumnos de diferentes programas de aprendizaje en idiomas, que desean controlar su progreso.
5.   Estudiantes y trabajadores que solicitan visas.
6.   Empresas y/o instituciones que requieran comprobar la suficiencia en idioma durante los procesos de selección de personal, analizar y certificar el nivel de inglés de sus empleados, hacer un seguimiento de la efectividad de los programas de formación lingüística, evaluar a sus empleados con vistas a ascensos o cargos en el extranjero.​

¿Quieres o te exigen presentar un examen de nivel de inglés, pero no sabes cuál es el adecuado para ti? ¿cuál es la diferencia entre uno y otro de tantos existentes en el mercado? ¿existe algún examen que me diagnostique mi nivel antes de decidir presentar un examen oficial?

La información a continuación puede orientarte un poco y llevarte a tomar la decisión más adecuada para tus necesidades.​

​Una diferencia importante entre todos los exámenes existentes es la validez de los resultados. Dicha validez está sujeta a las políticas y reglamentos de la institución académica, empresa, embajada, etc. solicitante de la prueba. Todas las instituciones son libres de aceptar el o los exámenes que mejor se adecuen a sus reglamentos internos.

Por ejemplo, los exámenes **IELTS y TOEFL** suelen ser más convenientes para los visados, trabajos o solicitudes de admisión universitaria que tengan como requisito de aceptación la posesión de un determinado nivel de inglés.

Exámenes como el **TOEIC, APTIS, TRACK TEST y Oxford Test of English​**son exámenes de inglés cuya novedad es la flexibilidad que aporta al poder evaluar de forma independiente una, dos, tres o todas las competencias del idioma. Estos exámenes son altamente aceptados en las universidades de Colombia.​

Ten en cuenta que cada examen tiene un proceso de inscripción diferente ,el cual varía dependiendo de la casa matriz del mismo.

Los tiempos de entrega también varían dependiendo de las políticas internas del ente oficial del examen. Ten presente el tiempo para tu examen de preferencia.

APTIS

CELPE-BRAS

DELE

IELTS

OTE

PLIDA

TOEFL

TOEIC

TRACK TEST 4 COMPETENCIAS

TRACK TEST COMPRENSIÓN LECTORA

5 días hábiles

4 meses

4 meses

7 días hábiles

15 días hábiles

4 meses

7 días hábiles

15 días hábiles

8 días hábiles

8 días hábiles

| Examen | Valor |
| --- | --- |
| Track Test 4 Competencias presencial | $ 380.000 |
| Track Test 4 Competencias virtual | $ 430.000 |
| Track Test Comprensión Lectora | $ 275.000 |
| Repetición Track Test presencial | $ 185.000 |
| Repetición Track Test virtual | $ 233.000 |
| Aptis for Teachers | $ 412.500 |
| Aptis for Teachers docentes EAFIT | $ 320.000 |
| Aptis General | $ 412.500 |
| Oxford Test of English | $ 486.000 |
| Oxford Test of English una sola habilidad | $ 204.000 |
| TOEFL | $256 dólares |
| IELTS | $ 1.045.700 |
| PLIDA | $ 770.000 |
| CELPE-BRAS | $ 504.000 |

_*Ten en cuenta que estos precios pueden variar en función de tu ubicación y están sujetos a cambios._

**Valores de exámenes de otros idiomas diferentes al inglés a través de nuestra página web.**

​Días antes de presentar la prueba, te llegará un correo electrónico con la citación oficial al examen y las instrucciones que debes seguir para presentarlo.

Para todos, siempre deberás presentar tu documento de identidad ORIGINAL.

Dependiendo si tu examen es a lápiz o a computador deberás traer implementos tales como: lápiz mina # 2, borrador, sacapuntas, lapicero negro.​

**Acceso peatonal:** por la portería de Argos, Las Vegas e Idiomas.​

**Acceso vehicular:** p la portería sur sobre la Avenida las Vegas después de Macrollantas, la del Plástico y del Caucho sobre la Av. Regional y la de Idiomas.

**Acceso de motocicletas:** por la portería sur sobre la Avenida las Vegas después de Macrollantas y la de Idiomas.

Debes tener en cuenta que el pico y placa también rige dentro de la Universidad.

**Valor parqueadero carros** $ 6.000 el día

**Valor parqueadero motos** $ 3.000 el día​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate