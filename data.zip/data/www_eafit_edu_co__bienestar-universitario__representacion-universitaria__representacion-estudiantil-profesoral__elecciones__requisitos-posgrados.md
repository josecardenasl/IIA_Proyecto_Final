# Requisitos de los candidatos como representantes profesorales a los cuerpos colegiados - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Requisitos de los candidatos

###### como representantes profesorales a los cuerpos colegiados

*    Requisitos de Los Candidatos Como Representantes Profesorales A Los Cuerpos Colegiados 

Los profesores y las profesoras que cumplan con los siguientes requisitos podrán inscribir sus candidaturas a:

##### Representantes profesorales al Consejo Académico

1.   Ser profesor de tiempo completo de la Universidad EAFIT y no tener el carácter de decano de Escuela, decano asociado para programas académicos, director de área o jefe de programa académico de pregrado.
2.   Haber prestado sus servicios a la Universidad EAFIT por un tiempo no menor a tres (3) años de manera continua e ininterrumpida.
3.   No haber sido sancionado disciplinariamente, según el Reglamento Interno de Trabajo.
4.   No haber sido inhabilitado por el Comité Electoral Universitario.

El candidato principal y su suplente al Consejo Académico deberán pertenecer a escuelas diferentes.

El candidato principal y el suplente deben asegurarse de que sus compromisos derivados de movilidades o período sabático no coincidan en el mismo semestre durante la época en la cual se ejercería la representación, con el fin de evitar que el cuerpo colegiado respectivo quede sin representación.

##### Procedimiento para realizar el proceso de inscripción de los candidatos

Los y las interesadas en postularse como candidatos a los diferentes cuerpos colegiados, deberán solicitar la inscripción de su candidatura entre el 20 de marzo y el 12 de abril de 2026, de lunes a viernes entre las 8:00 a.m. y las 3:00 p.m. a través del formulario dispuesto en el siguiente [enlace](https://forms.office.com/r/nzHhHiHibY), el cual debe ser diligenciado por uno de los candidatos.

Solo serán analizadas aquellas postulaciones presentadas a través del enlace mencionado y que sean diligenciadas de manera completa.

##### La solicitud de la inscripción de la candidatura deberá contener los siguiente:

1.   Nombres y apellidos completos de los candidatos, indicando quién será el principal y quién será el suplente.
2.   Escuela a la que se encuentran adscritos.
3.   Área a la que pertenecen.
4.   Cuerpo colegiado al que se postulan.
5.   Un plan de trabajo en el cual se detallen las propuestas, con el fin de informarlo al público profesoral, y el cual será publicado en los canales institucionales avalados e informados por el Comité Electoral Universitario.
6.   Firma del candidato principal y el suplente en el plan de trabajo.

Ningún candidato podrá postularse simultáneamente para dos o más cuerpos colegiados.

Los representantes de los estudiantes y profesores podrán ser reelegidos en cualquier tiempo, hasta por un período más.

Todo candidato a representante, antes de inscribirse, deberá tener conocimiento tanto de la composición como de las funciones que tiene cada cuerpo colegiado al que se postula, y que se encuentran establecidas en los Estatutos Generales de la Universidad EAFIT, Estatuto Profesoral, Reglamentos Académicos de los Programas de Pregrado y Posgrado, y demás normas internas de la Universidad EAFIT.

Cada candidatura deberá estar conformada por el candidato principal y el suplente o los suplentes, según el cuerpo colegiado al cual se postulen de acuerdo con lo contemplado en el Reglamento de elección y representación estudiantil y profesoral ante los cuerpos colegiados.

En ningún caso la candidatura constituye o podrá asociarse a un partido o

movimiento político.

Cada candidatura será identificada con un número y no se permitirá utilizar en la inscripción alguna denominación asociada a un colectivo; sin embargo, será posible asociarse entre candidatos para promover la campaña y el ejercicio comunicacional de la misma.

**Nota:** El plan de trabajo con las firmas del candidato o candidata principal y suplente(s) se debe adjuntar en el enlace del **formulario de inscripción en un archivo pdf, usando el formato disponible** en [www.eafit.edu.co/elecciones](https://www.eafit.edu.co/bienestar-universitario/representacion-universitaria/representacion-estudiantil-profesoral/elecciones).

##### Umbral elecciones representantes profesorales.

**Consejo Académico:** veinte por ciento (20%) más uno de los profesores de planta.

Para los profesores de cátedra pregrado no se requiere cumplir un umbral mínimo.

La elección de los representantes estudiantiles y profesorales a los diferentes cuerpos colegiados se hará por mayoría de votos. En aquellos cuerpos colegiados que no se alcance el umbral mínimo establecido, el Comité Electoral Universitario designará como representantes estudiantiles o profesorales a la(s) candidatura(s) más votadas, salvo en aquellos casos en que el voto en blanco haya obtenido la mayoría de los votos. En este caso el Comité Electoral Universitario convocará una vez más a Elecciones para el estamento correspondiente, y deberán postularse candidatos diferentes.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)