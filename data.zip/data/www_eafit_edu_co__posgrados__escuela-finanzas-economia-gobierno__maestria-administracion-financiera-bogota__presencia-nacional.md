# Presencia Nacional - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Presencia Nacional

###### Conoce las diferentes ciudades de las cuales tiene convenio el programa

Los aspirantes a la Especialización en Finanzas y a la Maestría en Administración Financiera tienen la posibilidad de realizar su programa en Medellín, Bogotá, Pereira y Cali. Esta oferta del programa en otras ciudades del país posibilita mayor flexibilidad del programa y movilidad de los estudiantes. De esta forma, los estudiantes que sean trasladados por motivo de trabajo entre estas ciudades pueden continuar cursando el programa con los mismos contenidos y sin sacrificar la calidad. ​

###### Especialización en Finanzas

**SNIES:** Medellín 1252 – Bogotá 20398 – Pereira 15610 – Cali 16052.

**Título que oto​​rga:** Especialista en Finanzas.

**Sedes**

1.   **Medellín**

**Duración​​​:** 2 semestres.

**Horario:** viernes de 6:00 p.m. a 9:00 p.m., y sábados de 7:00 a.m. a 12:00 m.

Lunes y miércoles de 6:00 p.m a 10:00 p.m.

1.   **EAFIT Bogotá**

**Duración​​​:** 2 semestres.

**Horario:** viernes de 6:30 p.m. a 9:30 p.m., y sábados de 8:00 a.m. a 1:00 p.m.

1.   **EAFIT Pereira​**

**Duración​​​:** 2 semestres.

**Horario:**viernes de 5:00 p.m. a 9:00 p.m., y sábados de 8:00 a.m. a 12:00 m.

1.   **Cali – Universidad de San Buenaventura**

**Duración​​​:** 2 semestres.

**Horario:** viernes de 5:00 p.m. a 9:00 p.m. y ​sábados de 8:00 a.m. a 12:00 m.​

###### Maestría en Adm​inistración Financiera

**SNIES:** Medellín 54957 – Bogotá 101605 – Pereira 101545 – Cali 101293.

**Títul​o que otorga:** Magíster en Administración Financiera.

**Se​​des**

1.   **Medellín**

​​​**Duración:** 3​​ semestres.

**Horarios:** viernes de 6:00 p.m. a 9:00 p.m., y sábados de 7:00 a.m. a 12:00 m.

Lunes y miércoles de 6:00 p.m. a 10:00 p.m.

1.   **EAFIT Bogotá**

**Duración:** 4 semestres.

**Horario:** viernes de 6:30 p.m. a 9:30 p.m., y sábados de 8:00 a.m. a 1:00 p.m.

1.   **EAFIT Pereira**

**Duración:** 4 semestres​.

**Horario:** viernes de 5:00 p.m. a 9:00 p.m., y sábados de 8:00 a.m. a 12:00 m.

1.   **Cali – Universidad de San Buenaventura**

**​​​Duración:** 3​​ semestres​.

Horario: viernes de 5:00 p.m. a 9:00 p.m. y sábados de 8:00 a.m. a 12:00 m.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)