# Doctorado en ingeniería - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Doctorado en ingeniería

*    Plan de Estudio 
*    Doctorado En Ingeniería 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

4 

5 

6 

Núcleos, ciclos, trayectorias y énfasis

- [x] Ciclo de formación doctoral 

- [x] Ciclo propedéutico 

Semestre 1

Créditos 

totales-

Créditos 12

#### Desarrollo de la tesis doctoral

Código: 

Se debe tener 72 créditos aprobados de desarrollo de la tesis doctoral.

Ciclo de formación doctoral
## Desarrollo de la tesis doctoral

12 Créditos

UMES

Código: 

Créditos 3

#### Complementaria

Código: 

Se debe tener 18 créditos aprobados de asignaturas complementarias.

Ciclo propedéutico
## Complementaria

3 Créditos

UMES

Código: 

Semestres

1 

2 

3 

4 

5 

6 

Núcleos, ciclos, trayectorias y énfasis

- [x] Ciclo de formación doctoral 

- [x] Ciclo propedéutico 

### **Líneas de investigación**

Conozca a las líneas de énfasis que contiene este programa.​​​​​​​​​​​​​

###### Diseño

Diseño integrado de sistemas técnicos.

Rediseño de productos.

###### Gestión

Proyectos.

Gestión de la Construcción.

Ingeniería de Software.

Sistemas de Información.

###### Mantenimiento

Mantenimiento Industrial.

###### Mecánica Aplicada

Diseño de Materiales.

Diseño Mecánico.

Ingeniería Sismorresistente.

Mecánica Computacional.

Mecánica Experimental.

Mecánica de Suelos y Cimentaciones.

###### Procesos Químicos, Físicos y Bioquímicos

Procesamiento de Polímeros.

Procesos Biotecnológicos.

Procesos Químico.

###### Producción

Dirección de Operaciones y Logística.

###### Sistemas y Computación

Ingeniería en software.

Sistemas de información.

Tecnologías de información para la educación.

Teleinformática.​​​

###### AgroTech

Agricultura de Precisión.

Modelación de cultivos​.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)