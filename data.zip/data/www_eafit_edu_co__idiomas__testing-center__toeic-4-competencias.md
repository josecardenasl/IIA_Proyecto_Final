*    TOEIC 4 Competencias 

## Información general

Descripción del examen

Mide las habilidades y conocimientos en las 4 destrezas de la lengua inglesa: Listening & Reading + Speaking & Writing.

Estructura

TOEIC 4 Skills (Listening + Reading + Speaking + Writing) es una evaluación válida y fiable reconocida internacionalmente, con una duración aproximada de **cuatro horas y media**. La parte del examen Listening and Reading se realiza en lápiz y papel a través de un formato tipo test, y la parte del examen Speaking and Writing se realiza a través de un computador, con auriculares y micrófono.

El objetivo de este examen es evaluar las destrezas que las personas necesitan para interactuar eficazmente utilizando la lengua inglesa.

Las respuestas se envían a través de un sistema de puntuación en línea seguro.

Proceso de inscripción

1.   Ingrese a [https://app.eafit.edu.co/recaudos/](https://app.eafit.edu.co/recaudos/) y seleccione el examen TOEIC marcado con la respectiva sede y fecha de su elección.
2.   Lea atentamente las instrucciones y haga clic en continuar. En la casilla Tarifa, seleccione la opción TOEIC 4 COMPETENCIAS Sede Poblado.
3.   El pago lo puede realizar en línea haciendo clic en el botón PAGAR. También puede generar una liquidación con la que podrá pagar en cualquier Bancolombia. Para esto, debe hacer clic en el botón GENERAR y luego en IMPRIMIR LIQUIDACIÓN.

Recuerde que el pago lo debe hacer el mismo día que hace la inscripción, de tal forma que se le asegure el cupo para tomar el examen.

1.   Una vez realizado el pago, envíe el comprobante de este y su documento de identidad escaneado al correo [testingcenter@eafit.edu.co](mailto:testingcenter@eafit.edu.co)
2.   Una vez realizado el pago, tendrá derecho a solicitar un reembolso. Este saldo será válido por un periodo de 6 meses y en caso de que el costo del examen incremente en ese lapso de tiempo, deberá asumir la diferencia. Pasados 6 meses no tendrá derecho a presentar el examen.

Inversión

### TOEIC 4 competencias

$808.000 COP

Calendario 2024

**Fecha del examen:** octubre 23.

**Hora:** 10:30 a.m.

**Fecha límite de inscripción:**octubre 19.

Notificación de resultados

Los resultados se dan a conocer aproximadamente 15 días hábiles después de presentado el examen: se envía una notificación por correo electrónico cuando estos estén disponibles para ser reclamados. Se entrega un resultado original impreso que cada candidato debe reclamar en persona en información y matrículas de Idiomas EAFIT.

Es responsabilidad de cada candidato reclamar y entregar el certificado donde sea que se lo estén requiriendo. Idiomas EAFIT no reporta este resultado a nadie diferente al candidato ni a ninguna otra institución, ni siquiera a Admisiones y Registro de la Universidad EAFIT ni conservamos copia de este.

Observaciones

1.   Tenga en cuenta que **no habrá lugar a cambios respecto a la sede de presentación del examen**.
2.   El día del examen deberá traer su documento de identidad original y una fotocopia del mismo por ambos lados, ampliada al 150%. Adicionalmente, deberá traer lápiz negro #2, lapicero, borrador y sacapuntas.
3.   La citación a la prueba será enviada por correo electrónico el **viernes inmediatamente anterior a la fecha del examen**.
4.   Lea el reglamento del examen disponible en: [http://www.ets.org/](http://www.ets.org/)
5.   La edad mínima para tomar el examen es **15 años**. Documentos válidos: cédula de ciudadanía, cédula de extranjería, pasaporte, licencia de conducción y tarjeta de identidad en formato nuevo. Si no cuenta con alguno de estos documentos, debe presentar el que tenga que lo reemplace (contraseña o tarjeta de identidad en formato anterior) y otro documento con foto (como carné estudiantil o empresarial).
6.   Encuentra los [Términos y condiciones del examen TOEIC](https://universidadeafit.widen.net/s/zrjvhcxflb/terminos-y-condiciones-toeic-2024).
7.   En caso de pérdida o requerir copia del certificado original, debe escribir un correo a [testingcenter@eafit.edu.co](mailto:testingcenter@eafit.edu.co)
8.   Este examen **podrá ser aplazado con tres días de anterioridad a la fecha programada**. En ambos casos el personal de inscripciones comunicará el cambio realizado a los candidatos inscritos y las fechas en las que podrá tomar el examen.

###### Preguntas frecuentes

​​​Conoce nuestros protocolos e información general sobre nuestro Testing Center.

1.   Estudiantes que desean ingresar y/o egresar en una institución de educación superior.
2.   Estudiantes en proceso de admisiones y/o egreso del programa de aprendizaje del idioma inglés.
3.   Candidatos que desean presentarse para obtención de becas y certificaciones.
4.   Alumnos de diferentes programas de aprendizaje en idiomas, que desean controlar su progreso.
5.   Estudiantes y trabajadores que solicitan visas.
6.   Empresas y/o instituciones que requieran comprobar la suficiencia en idioma durante los procesos de selección de personal, analizar y certificar el nivel de inglés de sus empleados, hacer un seguimiento de la efectividad de los programas de formación lingüística, evaluar a sus empleados con vistas a ascensos o cargos en el extranjero.​

¿Quieres o te exigen presentar un examen de nivel de inglés, pero no sabes cuál es el adecuado para ti? ¿cuál es la diferencia entre uno y otro de tantos existentes en el mercado? ¿existe algún examen que me diagnostique mi nivel antes de decidir presentar un examen oficial?

La información a continuación puede orientarte un poco y llevarte a tomar la decisión más adecuada para tus necesidades.​

​Una diferencia importante entre todos los exámenes existentes es la validez de los resultados. Dicha validez está sujeta a las políticas y reglamentos de la institución académica, empresa, embajada, etc. solicitante de la prueba. Todas las instituciones son libres de aceptar el o los exámenes que mejor se adecuen a sus reglamentos internos.

Por ejemplo, los exámenes **IELTS y TOEFL** suelen ser más convenientes para los visados, trabajos o solicitudes de admisión universitaria que tengan como requisito de aceptación la posesión de un determinado nivel de inglés.

Exámenes como el **TOEIC, APTIS, TRACK TEST y Oxford Test of English​**son exámenes de inglés cuya novedad es la flexibilidad que aporta al poder evaluar de forma independiente una, dos, tres o todas las competencias del idioma. Estos exámenes son altamente aceptados en las universidades de Colombia.​

Ten en cuenta que cada examen tiene un proceso de inscripción diferente ,el cual varía dependiendo de la casa matriz del mismo.

Los tiempos de entrega también varían dependiendo de las políticas internas del ente oficial del examen. Ten presente el tiempo para tu examen de preferencia.

APTIS

CELPE-BRAS

DELE

IELTS

OTE

PLIDA

TOEFL

TOEIC

TRACK TEST 4 COMPETENCIAS

TRACK TEST COMPRENSIÓN LECTORA

5 días hábiles

4 meses

4 meses

7 días hábiles

15 días hábiles

4 meses

7 días hábiles

15 días hábiles

8 días hábiles

8 días hábiles

| Examen | Valor |
| --- | --- |
| Track Test 4 Competencias presencial | $ 380.000 |
| Track Test 4 Competencias virtual | $ 430.000 |
| Track Test Comprensión Lectora | $ 275.000 |
| Repetición Track Test presencial | $ 185.000 |
| Repetición Track Test virtual | $ 233.000 |
| Aptis for Teachers | $ 412.500 |
| Aptis for Teachers docentes EAFIT | $ 320.000 |
| Aptis General | $ 412.500 |
| Oxford Test of English | $ 486.000 |
| Oxford Test of English una sola habilidad | $ 204.000 |
| TOEFL | $256 dólares |
| IELTS | $ 1.045.700 |
| PLIDA | $ 770.000 |
| CELPE-BRAS | $ 504.000 |

_*Ten en cuenta que estos precios pueden variar en función de tu ubicación y están sujetos a cambios._

**Valores de exámenes de otros idiomas diferentes al inglés a través de nuestra página web.**

​Días antes de presentar la prueba, te llegará un correo electrónico con la citación oficial al examen y las instrucciones que debes seguir para presentarlo.

Para todos, siempre deberás presentar tu documento de identidad ORIGINAL.

Dependiendo si tu examen es a lápiz o a computador deberás traer implementos tales como: lápiz mina # 2, borrador, sacapuntas, lapicero negro.​

**Acceso peatonal:** por la portería de Argos, Las Vegas e Idiomas.​

**Acceso vehicular:** p la portería sur sobre la Avenida las Vegas después de Macrollantas, la del Plástico y del Caucho sobre la Av. Regional y la de Idiomas.

**Acceso de motocicletas:** por la portería sur sobre la Avenida las Vegas después de Macrollantas y la de Idiomas.

Debes tener en cuenta que el pico y placa también rige dentro de la Universidad.

**Valor parqueadero carros** $ 6.000 el día

**Valor parqueadero motos** $ 3.000 el día​

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500