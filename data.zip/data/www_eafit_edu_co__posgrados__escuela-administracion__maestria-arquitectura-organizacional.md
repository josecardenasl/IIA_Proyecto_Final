# Maestría en Arquitectura Organizacional - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Maestría en Arquitectura Organizacional

SNIES 117520, Medellín

Las organizaciones actuales operan en entornos dinámicos que exigen la reinvención de su arquitectura y procesos. Ante ecosistemas digitales complejos y el auge de la IA generativa, es imperativo trascender hacia modelos que respondan con agilidad a las tendencias y necesidades de cambio. El reto es tanto cultural como estratégico: desarrollar la capacidad de gestionar transformaciones efectivas, evitando esfuerzos desenfocados y garantizando que la evolución digital sea sostenible, global y coherente con la visión de negocio.

Nuestro programa responde a la necesidad de coordinar equipos escalables y resolver conflictos estructurales, formando líderes capaces de alcanzar resultados tangibles. Potenciamos la gestión de arquitecturas que habiliten la estrategia y el diseño de procesos centrados en el cliente, superando barreras técnicas y culturales para liderar la arquitectura organizacional en contextos globales y altamente competitivos.

*    Escuela Administracion 
*    Maestría En Arquitectura Organizacional 

## Registro calificado

Resolución 024804 del 16 de Diciembre de 2024 Vigencia de 7 años.

Duración

3 Semestres

Lugar

Medellín

Horario

Martes a viernes y Sábados

Más información

Presencial una semana al mes. Martes a viernes de 5:00 p.m. a 9:00 p.m. y sábados de 8:00 a.m. a 12:00 p.m.

 Es importante destacar que la modalidad del programa es híbrida. Algunas asignaturas se ofrecen en modalidad combinada (con sesiones virtuales y presenciales), y cuatro de ellas son completamente virtuales (asincrónicas).

Idioma 

Español

Modalidad

Híbrida

SNIES

107471

Precio total del programa

$43.092.413

## Sobre el programa

¿Por qué estudiar la Maestría en Arquitectura Organizacional?

Dominar la Arquitectura Organizacional que integra marcos de **Arquitectura Empresarial (EAM)** y la**Gestión por Procesos** es hoy una necesidad estratégica. Nuestra maestría prepara a los profesionales para liderar la transformación corporativa y la digitalización bajo cinco pilares fundamentales:

**1. El puente entre la estrategia y la ejecución real**

Las organizaciones suelen fallar al convertir sus metas en resultados. En este programa, aprenderás a aterrizar los modelos de negocio en acciones tangibles, construyendo una base para la ejecución que garantiza procesos eficientes y una mayor rentabilidad.

**2. Gestión de la complejidad y fin del caos digital**

Evita que el ecosistema tecnológico de tu empresa se convierta en una red inmanejable de redundancias y altos costos. Te entregamos herramientas de estándar global (como TOGAF) para armonizar sistemas, resolver la "paradoja de la prevención" y generar economías que eviten costos exponenciales a largo plazo.

**3. Ruptura de silos y transformación estructural**

Superamos el modelo tradicional de áreas funcionales aisladas que generan lentitud y alienación. Esta disciplina te enseña a estructurar la organización de forma transversal y centrada en procesos, eliminando jerarquías innecesarias y empoderando a los equipos para generar valor real y una experiencia al cliente.

**4. Liderazgo del cambio sociotécnico (Personas + Tecnología)**

La transformación no es solo tecnológica, es humana. Aprenderás a navegar la resistencia organizacional, integrando conocimientos de diseño organizacional, liderazgo y gestión del cambio para asegurar que la adopción de nuevas tecnologías y mejoras de procesos sea armónica y sostenible.

**5. Roles de alto impacto y cercanía a la alta dirección**

El mercado demanda expertos que hablen el lenguaje de los negocios y de la tecnología simultáneamente. Te preparamos para destacar como arquitecto organizacional, Líder de procesos o asesor de transformación, posicionándote como un líder o asesor de confianza para roles de nivel gerencial en la toma de decisiones estratégicas.

Perfiles

**Perfil de ingreso**

La Maestría en Arquitectura Organizacional de la Universidad EAFIT está dirigida a profesionales de todas las áreas del conocimiento con interés en crear valor en las organizaciones alineando la estrategia, los procesos y las tendencias tecnológicas para contribuir de manera significativa a su sostenibilidad y competitividad.

**Perfil ocupacional**

El graduado de la Maestría en Arquitectura Organizacional de la Universidad EAFIT podrá desarrollarse profesionalmente en el ámbito del liderazgo en procesos de arquitectura de organizacional o consultoría, en los sectores público y privado, en roles afines a la arquitectura entre los cuales se encuentran:

- Arquitecto Organizacional - Empresarial – de Negocios - de Procesos

- Consultor Estratégico

- Investigador y Académico

- Líder de Proyectos de Transformación Digital

- Analista de Negocios y Reingeniería de Procesos

- Director de Innovación y Desarrollo Organizacional

Diferenciales

**Propuesta única en el país:** La Maestría en Arquitectura Organizacional se centra en diseñar y gestionar estructuras organizacionales flexibles y sostenibles, con un **enfoque integral que combina estrategia, procesos, personas y tecnología.**

**Temas Relevantes:** El programa incorpora tendencias relacionadas a arquitectura tecnológica incorporando temas de transformación digital, big data, inteligencia artificial y sostenibilidad. Los estudiantes desarrollan competencias para liderar proyectos de cambio estratégico y adoptar modelos adaptables en organizaciones.

**Metodología:** Modalidad híbrida que mezcla la presencialidad y lo virtual, con actividades sincrónicas y asincrónicas que promueven el aprendizaje práctico.

**Trabajo de grado aplicado**para solución de un problema organizacional.

**Internacionalización:** Contamos con una experiencia internacional **opcional**, en la cual se reciben clases, talleres, visitas a empresas y salidas turísticas. Tiene una duración de una y la temática de la pasantía es de acuerdo con las tendencias organizacionales del momento.

Aprendizaje vivo y activo

Nuestra maestría se fundamenta en un modelo de **aprendizaje activo y vivo**, diseñado para integrarse de manera armónica con la realidad profesional de nuestros estudiantes. El programa facilita un equilibrio excepcional entre la formación de alto nivel y la carga laboral, gracias a un esquema de clases programadas presenciales intensivas de una semana con apoyo de componentes virtuales y con algunas clases completamente virtuales.

Esta flexibilidad permite que profesionales de diversas regiones del país converjan en nuestras aulas, enriqueciendo el proceso educativo con una **experiencia multicultural**y una visión diversa de los retos organizacionales en distintos contextos. Además, el aprendizaje trasciende la teoría: el **trabajo de grado tiene un enfoque práctico**, orientado a la resolución de problemas reales y aplicado directamente al contexto empresarial, garantizando que el conocimiento generado retorne como valor para las organizaciones.

Revive nuestros momentos

###### **Diseña y gestiona estructuras organizacionales flexibles:**

Un recorrido estratégico por el lanzamiento de nuestra maestría, donde exploramos cómo las organizaciones líderes están rediseñando su mentalidad y procesos para navegar la incertidumbre. Descubre la importancia de federar capacidades técnicas y humanas para construir estructuras ágiles que mitiguen el caos y potencien la adaptación en la era digital.

Da clic en la imagen y descubre cómo fue el lanzamiento de nuestro programa.

###### **Arquitectura de Soluciones con Propósito:**

En esta masterclass, el profesor Felipe Mejía nos enseña a diseñar soluciones que aporten valor real mediante la conexión intencional entre el negocio y la tecnología. El contenido profundiza en cómo garantizar que cada inversión o implementación tecnológica responda directamente a un objetivo estratégico y resuelva problemas reales de la organización.

A través del análisis de frameworks clave como TOGAF, Zachman, SAFe y ArchiMate, se destaca que el éxito no radica en elegir el marco "perfecto", sino en construir una arquitectura coherente con el propósito organizacional. Además, se establecen las diferencias críticas entre una arquitectura robusta y la improvisación digital, enfatizando prácticas como:

- Alineamiento estratégico y visión holística de capas (negocio, datos, aplicaciones y tecnología).

- Gobernanza activa y gestión del cambio para evitar el "caos documentado".

- Liderazgo en la era de la IA, donde el arquitecto moderno potencia sus capacidades con tecnología para guiar cambios con intención, ética y sostenibilidad.

- "En un mundo lleno de tecnología, el propósito es la nueva arquitectura".

Da clic en la imagen para ver el contenido completo

###### **Charla informativa del programa:**

Conoce más sobre nuestro programa.

Da clic en la imagen y accede a nuestra charla informativa, donde podrás descubrir el enfoque de la maestría, sus objetivos y cómo está diseñada para formar líderes capaces de transformar las organizaciones.

Calidad y excelencia

**El cuerpo docente**

Nuestros profesores son referentes en el ámbito académico e investigativo, y muchos ocupan cargos importantes en reconocidas empresas nacionales e internacionales.

**Escuela referente nacional e internacional**

Como parte de la Universidad EAFIT, estamos acreditados por The Association to Advance Collegiate Schools of Business (AACSB International), la alianza más grande para la educación.Nuestro programa es parte de la Escuela de Administración, la primera en Latinoamérica en recibir una acreditación de alta calidad de la Business Graduate Association (BGA).

Contacto

###### Ejecutiva de promoción

**Valentina Castañeda Jaramillo**

+57 310 2273379

vcastanedj@eafit.edu.co

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Becas y Financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

## Nuestras acreditaciones

### También te puede interesar

#### Maestría en Administración Financiera – Medellín

Duración

3 semestres

Lugar

Medellín

Horario

Lunes y miércoles, martes y jueves, viernes y sábado

Más información

Opciones de horarios: 

 Lunes y Miércoles 6:00 p.m. a 10:00 p.m.

 Martes y jueves 6:00 p.m. a 10:00 p.m.

 Viernes 5:00 a 8:00 p.m. y sábado 8:00 a.m. a 1:00 p.m.

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 54957

Precio total del programa

$55.988.829

#### Maestría en Sostenibilidad

Duración

3 semestres

Lugar

Medellín

Horario

Por definir

Idioma 

Español

Modalidad

Virtual

SNIES

SNIES 111160

Precio total del programa

$33.390.915 

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Liderar para generar impacto: decisiones que transforman personas, equipos y oportunidades

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate