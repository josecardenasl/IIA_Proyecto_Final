# Talleres Artísticos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Talleres Artísticos

*    Talleres Artísticos 

La estimulación de competencias blandas por medio de experiencias artísticas dirigidas a la comunidad eafitense, es el propósito fundamental de los talleres del Departamento de Desarrollo Artístico, para lo cual propicia espacios que permiten darle lugar a distintas expresiones de las artes, con la cercanía necesaria para que todos los participantes se involucren activamente como realizadores de su propia creación.

Solo para: Estudiantes, egresados, graduados de los programas de pregrado y posgrado, profesores, empleados y pensionados de la Universidad EAFIT y sus familiares. Los familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de los programas de pregrado y posgrado, y de egresados y graduados de los programas de pregrado y posgrado, de la Universidad EAFIT, deben diligenciar el Formulario Talleres Artísticos No Eafitenses, no por la página web del Departamento. Los cupos para familiares están sujetos a disponibilidad. Este último procedimiento aplica también para Saberes de Vida y participantes de Idiomas EAFIT y Educación Continua.

Ver Política de los Talleres artísticos. Si eres estudiante, empleado, profesor o pensionado, al inscribirte en el Taller aceptas la Política de los Talleres artísticos, por lo tanto ten en cuenta que deberás administrar tus faltas de asistencia. Al momento de incumplir con el 80% de asistencia, el sistema te generará una cuenta de cobro por el costo total del taller, sin descuento ninguno.

#### Inscripciones a partir de las 8:00 a.m. del 26​ de enero de 2026

Cómo inscribirse en los Talleres Artísticos

### 1

Los talleres artísticos están dirigidos a sus estudiantes, graduados, empleados y pensionados de EAFIT y sus familiares*.

### 2

Elige del menú el taller que quieres cursar y dale clic.

### 3

Lee el contenido del programa, revisa los horarios disponibles y las políticas de los talleres artísticos.

### 4

El día y la hora señalada de inicia de inscripción, será el momento en que se habiliten las opciones de talleres artísticos. Si ingresas antes, no verás opciones de talleres a elegir.

### 5

Una vez ingreses al link de inscripciones, digita tu documento de identidad y sigue la ruta: “Matriculas – Talleres”, y allí buscas el semestre actual.

### 6

Valida que la opción del taller que quieres realizar se encuentre habilitada, la seleccionas y das clic en “Registrarse”.

### 7

Si no encuentras habilitado el taller que quieres cursar, es porque ya se agotaron los cupos.

### 8

Si eres estudiante, empleado o pensionado de EAFIT, debes generar la liquidación para quedar inscrito.

### 9

Si eres graduado o familiar de eafitense, debes generar la liquidación y realizar el pago por los canales establecidos.

*Los familiares corresponden a: padres, hijos, hermanos y esposo o compañero permanente. Tener presente las políticas de los talleres artísticos. Programar muy bien las fechas en que se cursa el taller para hacer un adecuado aprovechamiento de los beneficios que otorga la Universidad. Si al momento de realizar la inscripción no encuentras el taller de tu elección es porque este ya cuenta con cupos disponibles.

Talleres Artísticos

## Accesorios tejidos con cuentas y abalorios - 20 horas

## Amigurumis - 20 horas

## Baile - 20 horas

## Cocina - 20 horas

## Creación y edición de contenidos para redes sociales

## Creando con palabras: Escritura creativa - 20 horas

## Feng Shui - 20 horas

## Fotografía de producto con celular - 14 horas

## Fotografía: Cámara digital - 20 horas

## Guitarra - 20 horas

## Ilustración Análoga - 30 horas

## Ilustración digital - 30 horas

## Joyería - 42 horas

## Lettering - 20 horas

## Macramé - 20 horas

## Modelado en Porcelanicrón

## Percusión eco de tambores – 30 horas

## Pintura infantil - 24 horas. A partir de 5 años de edad

## Pintura para jóvenes y adultos - 32 horas

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)