# Década de 1990 - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Década 1990

En la década de 1960, Medellín se encontraba en pleno desarrollo industrial gracias, en gran parte, al crecimiento del sector textilero.

*    Década de 1990 

###### **La década del salto humanístico​**

**La llegada de internet, nuevos espacios y equipos tecnológicos, así como la apertura al estudio de las humanidades fueron hechos que marcaron los últimos 10 años del siglo XX para EAFIT.​​​**

​La década comienza con un gran aniversario: los 30 años de una Universidad que, gracias a sus esfuerzos en pro de la educación en Medellín, Antioquia y Colombia, recibió para esta fecha especial la Medalla al Mérito Educativo Pedro Justo Berrío entregada por la Gobernación de Antioquia.

Aunque con este reconocimiento no finalizaría la celebración. La construcción del bloque 18 y las gestiones para dotar con modernos equipos de cómputo a la Universidad, que en 1993 posibilitarían la llegada de internet al país, contribuyeron a este aniversario repleto de cambios positivos.

Para 1991 se inaugura el Centro de Idiomas que, en las primeras semanas de inicio de clases, recibió 50 personas más de las esperadas en las aulas, confirmando un éxito rotundo que con calidad ha alimentado hasta el presente.

Fueron 1993 y 1994 los años para el nacimiento de los pregrados en Negocios Internacionales y Economía, respectivamente; y 1995 marca la entrada definitiva de la Universidad al Eje Cafetero, con la inauguración de la sede EAFIT Pereira.

Otro paso clave en la historia eafitense ocurrió entre 1997 y 1998, con la apertura de la Escuela de Ciencias y Humanidades, un punto de quiebre ocurrido en la rectoría de Juan Felipe Gaviria.

Pregrados como Música, inaugurado en 1998, fueron pioneros en la idea de que la Universidad entrara en una nueva dinámica, en la que aparte de administradores y profesionales inmiscuidos en el mundo de las finanzas, la ingeniería y la economía, se contaría con personas dedicadas a las ciencias sociales.

El último año de la década 1990 consolidaría la propuesta de apertura a una variedad de saberes y disciplinas en la que se había embarcado la Universidad: nacen el pregrado en Ingeniería de Diseño de Producto, la Escuela de Derecho y el Centro Cultural Biblioteca Luis Echavarría Villegas con su Centro de Artes.​

La década de 1990 supuso grandes retos para Colombia, donde prevalecía un ambiente de inestabilidad política y económica en un contexto mundial que favorecía la apertura de los mercados y la implementación del modelo neoliberal. Aunque el fantasma del comunismo parecía acabado con la disolución de la Unión Soviética, nuevos conflictos, como el del Golfo Pérsico, la desintegración de Yugoslavia, las pugnas violentas en varios países africanos, sin ahondar en la violencia de la conflagración nacional, demandaban una transformación sustancial de la sociedad global. Colombia comenzó por la Constitución de 1991, que trató de definir un camino hacia la paz, la democracia y los derechos humanos.

Entre tanto, en EAFIT se configuraban hitos importantes que respondían, precisamente, a esas transformaciones imperantes del momento: una concepción pedagógica centrada en los aspectos cualitativos de los grupos humanos (Calidad Total: el trabajo en equipo, flexibilidad dinámica, y la dimensión social y humana del desarrollo empresarial). Comenzó, además, la reforma curricular que implicaba una flexibilización que permitió a los alumnos escoger diferentes opciones en su currículo con la idea de que cursaran asignaturas de diferentes núcleos del saber y se involucraran de forma activa en su propio proceso de formación.

No obstante, la Institución ya no solo se adaptaba a las necesidades del país, sino que se repensaba para llegar a ser la conciencia crítica de la sociedad. Esto fue posible, en gran parte, a uno de sus hitos más importantes: la llegada de las humanidades con la creación del pregrado en Música, en 1997, y con este de la Escuela de Ciencias y Humanidades, la tercera en EAFIT, unidad académica que enriqueció el concepto de Universidad por la diversidad de saberes.

Con el avance de esta década la oferta académica siguió consolidándose no solo en Medellín, sino en otros territorios. En 1993 surgió el pregrado en Negocios Internacionales, en 1995 el pregrado Economía, en 1996 Ingeniería de Procesos y en 1999 Ingeniería de Diseño de Producto. Estas carreras nacieron en un momento clave de la economía colombiana, dado que la apertura económica implicaba la internacionalización y el desarrollo tecnológico con conocimiento propio. En este primer quinquenio, específicamente en 1995, inició actividades la nueva sede de EAFIT Pereira y un año después la sede de EAFIT Llanogrande; y la Universidad, junto con otras instituciones de educación superior del país, fue una de las primeras en conectarse a internet a comienzos de la década, con otras universidades del país.

La alta calidad siguió siendo un propósito. Por eso, en 1997, la Universidad se inscribió con siete pregrados al Sistema Nacional de Acreditación, que se había puesto en marcha en Colombia en 1995. De esta manera, fue la primera institución que se presentó con más de un programa. Ingeniería Civil, Ingeniería de Producción, Contaduría Pública, Ingeniería Mecánica, Geología, Ingeniería de Sistemas y Administración de Negocios fueron las primeras carreras en recibir este reconocimiento público a la alta calidad. En ese mismo año, EAFIT declaró su primera Misión Institucional, que estuvo vigente hasta 2008: “Formar personas comprometidas con el desarrollo integral de su comunidad, por medio de programas de pregrado y de posgrado, dentro de un ambiente de pluralismo ideológico y de excelencia académica, competentes internacionalmente en sus áreas del conocimiento”.

El camino de la Universidad de docencia siguió en marcha. De esta manera, en 1999, comenzó actividades la Escuela de Derecho, con el pregrado en Derecho, la cuarta Escuela de EAFIT. A este hito se sumó, el mismo año, la inauguración del edificio del Centro Cultural Biblioteca Luis Echavarría Villegas, y su Centro de Artes, símbolo del encuentro entre la investigación, la cultura y la academia. Esta infraestructura se ubicó en el corazón del campus universitario de Medellín y fue el eje a partir del que se comenzó a desarrollar la transformación arquitectónica de la Institución.

## Hitos de la década

1990

###### **Reforma curricular en la Escuela de Administración**

En este año se dieron los primeros pasos para esta reforma curricular.

**Julio de 1990**

###### **La Universidad recibió la Medalla al mérito educativo Pedro Justo Berrío**

La Gobernación de Antioquia concedió a la Universidad la medalla al mérito educativo Pedro Justo Berrío, en reconocimiento a los permanentes servicios que EAFIT prestó a la educación sus 30 años de funcionamiento.

1993

###### **Surgió el pregrado en Negocios Internacionales**

1993 fue un año para la internacionalización de la Universidad: se crea el pregrado en Negocios Internacionales y se le abren puertas a la tecnología de internet.

1994

###### **Se creó el pregrado en Economía**

Esta gesta fue catalogada por los profesores de mayor trayectoria de Antioquia en área económica como uno de los logros más significativos del Departamento de Economía de EAFIT desde su creación en 1974.

1996

**Enero de 1996**

###### **Juan Felipe Gaviria Gutiérrez es nombrado rector**

Juan Felipe Gaviria Gutiérrez fue nombrado por el Consejo Superior de la Universidad EAFIT como rector. Gestionó la aprobación de los nuevos estatutos de la Universidad.

###### **Reforma curricular en la Escuela de Administración**

Una de sus banderas fue la apertura de una serie de materias que los estudiantes podían escoger: las electivas.

###### **Se creó el pregrado en Ingeniería de Procesos**

Con este programa se estrecha aún más la relación entre la Universidad EAFIT, las ciencias básicas y naturales, y la ingeniería.

1997

###### **Nació la Escuela de Ciencias y Humanidades**

Un salto significativo hacia un corte humanista fue la creación de la Escuela de Ciencias y Humanidades para EAFIT.

1999

###### **Enero de 1999**

**Surgió el pregrado en Ingeniería de Diseño de Producto**

Este nuevo pregrado introduce la disciplina del diseño a la oferta curricular de la Institución.​​

## Década de 1990

En 1999 se inauguró el edificio del Centro Cultural Biblioteca Luis Echavarría Villegas, y su Centro de Artes, símbolo del encuentro entre la investigación, la cultura y la academia.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate