# ¡Llegan las Asambleas de Carrera 2023-2!​ - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ¡Llegan las Asambleas de Carrera 2023-2!​

*    Repres 
*    ¡Llegan Las Asambleas de Carrera 2023-2!​ 

Estimados estudiantes y profesores eafitenses,

El Departamento de Desarrollo Estudiantil les informa que, el jueves 7 de septiembre de 2023, se realizarán las Asambleas de Carrera de acuerdo con el calendario de actividades que aprobó, de manera previa, el Consejo Académico.

Con el propósito de garantizar la realización de esta jornada, en dicha fecha no se podrán programar evaluaciones, y las clases se suspenderán entre las 10:00 de la mañana y las 2:00 de la tarde.

Extendemos la invitación a todos los estudiantes de pregrado de la Universidad para que se sumen a estos espacios que permiten escuchar, compartir, canalizar, hacer propuestas; y recibir y consolidar todas las inquietudes que contribuyan a la transformación permanente de la Universidad.

Así mismo, les reiteramos a los profesores la importancia de motivar a los estudiantes para que participen activamente en las Asambleas de Carrera, y fortalezcan estos ambientes de aprendizaje, debate, liderazgo, inclusión, pluralismo y construcción colectiva.

Atentamente,

**Paola Gaviria Meléndez**

Jefa de Desarrollo Estudiantil

**Comunicado n° 26**

Medellín, 31 de agosto de 2023

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate