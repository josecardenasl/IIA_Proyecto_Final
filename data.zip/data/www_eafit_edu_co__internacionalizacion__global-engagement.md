# Global Engagement

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 18: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Global Engagement

Connect globally with EAFIT: strategic alliances, international agreements, and academic exchange opportunities for students and faculty.

*    Global Engagement 

Welcome to the Global Engagement unit of Internationalization EAFIT. Our mission is to excel in partnership engagement, connecting partner interests with the academic capacities, Centers, and Schools our​ University. We extend EAFIT's global connections through partnership initiation, agreement coordination and hosting delegation visits.​

##### Agreements​

The agreement management process at Universidad EAFIT is outlined below.​

a. International accreditations.

b. Internationalization at home activities.​

c. Policy on foreign languages an​d proficiency in second languages.

d. Participation in coop​erative international projects.

e. Calendar of cultural, academic, athletic, or extension activities that have an international or second language component.​

f. ​Articulation with EAFIT's Centers of Incidence and Study

g. Incoming Study Abroad groups. ​

h. Visiting professors.​

i. Internship abroad.​

​j. Language Center

k. Intellectual production with international scope: papers, conferences, articles, book chapters, patents, co-authorships, etc.​

l. Teaching-learning methods used for internationalizing the curriculum.

m. International Agreements​.​

n. Student exchange for research activities and internships.

o. Research groups.

p. Membership in International Networks and Associations.​

Universidad EAFIT focuses its partnerships on a smaller number of key institutions for closer collaboration. These partnerships usually involve joint programs, co-funded research, faculty, and student mobility.​

As mentioned above, EAFIT establishes strategic relationships with high-quality national and international partners, with whom we share our core values and develop unique long-term partnerships that contribute to:

Fulfill both institutions' mission. ​

Offer students, faculty, and staff a wide range of opportunities to enhance their international competencies and reach.

Support capacity building with an institutional scope.​

Our international partnerships span a diverse range of countries, languages, and objectives, established under the following principles:​

Reciprocity​

Trust

Commitment

Sustainability

###### Contacto

**Global Engagement**

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate