# Spanish program - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Spanish program

Personalized sessions adapted to your needs

*    Spanish Program 

### **Spanish for you**

We adjust the course according to your time, needs, level, and interests.

### Target

Everybody

### Investment per tuiton

COP 167,000

per hour.

### Schedule

Your choice!

###### **About the course**

This course offers maximum flexibility and individualized attention.

*   Flexible Schedule: Choose the number of hours, days, and times that best suit you.
*   Personalized Instruction: Each session is adapted to your interests, needs, and language objectives.
*   Tuition: COP 167.000 per hour.

**No additional fees apply. The total investment depends on the number of hours you select.**

##### **Travel to Colombia and live the language!**

###### Take our Spanish classes in-person at EAFIT University

If you have any question or queries a member of our team we are willing to help. Feel free to contact us by email

spanish@eafit.edu.co​

### Why EAFIT?

**More Than 60 Years of History.**Universidad EAFIT was born in a decade marked by constant change. It was the dawn of the 1960s when a group of 19 regional business leaders – in tune with the cultural, social, and economic transformations on the horizon globally – founded an institution to serve as a training ground for their companies' future managers and administrators.

Spanish program 

Here you will find the form you must complete. Please keep the following in mind:

Fields marked with an asterisk (*) are mandatory.

Fill in the information according to the instructions provided in each field.

Before submitting the information, authorize the processing of personal data and accept the terms and conditions.

Idiomas

Name*? 

Last name*? 

Type of ID*? 

ID number*? 

E-mail*? 

Phone number*? 

What program are you interested in? 

Where did you hear about us?? 

How would you prefer to be contacted?? 

What would you like to know?? 

Inicio del programa 

Canal origen 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)