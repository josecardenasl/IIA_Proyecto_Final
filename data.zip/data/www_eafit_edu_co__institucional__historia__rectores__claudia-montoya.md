# Claudia Restrepo Montoya - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Claudia Restrepo Montoya

​​(Rectora desde 2021​)​​​

*    Claudia Restrepo Montoya 

Con más de 20 años de experiencia en el diseño y gerencia de programas y proyectos de alcance social en las áreas de educación, cultura, ciudadanía y hábitat, en enero de 2021 Claudia Restrepo Montoya llegó a EAFIT para asumir el cargo de rectora, convirtiéndose en la primera mujer en asumir este rol en las más de seis décadas de trayectoria de la Institución.

Su gestión, en estos cuatro años, ha estado concentrada, principalmente, en liderar la transformación de la Universidad EAFIT, en coherencia con los desafíos actuales de la educación, los cambios en el mundo del trabajo, la evolución de las relaciones sociales y colectivas, y la pregunta permanente por los temas de sostenibilidad.

Justamente, en respuesta a estas demandas, se destaca su liderazgo en el retorno seguro y responsable a la presencialidad, después de superar la coyuntura derivada de la pandemia por covid-19. Se trató de un proceso escalonado en el que el cuidado y el aprendizaje fueron las consignas principales, acatando las medidas que continuaban vigentes por parte de las autoridades locales y nacionales, y fortaleciendo el desarrollo de dinámicas híbridas entre tecnología y presencialidad para garantizar la realización de las actividades académicas, investigativas y administrativas.

También se continuó avanzando en la consolidación de un modelo educativo y relevante centrado en el aprendizaje activo. Es decir, que pone al estudiante en el centro y le permite, a través de un currículo vivo, trayectorias dinámicas basadas en competencias, y el acompañamiento de profesores inspiradores, convertirse en protagonista de su proceso de formación.

En coherencia con el ADN fundacional se priorizó el conexón con las empresas, los sistemas públicos y los emprendimientos, y se hizo explícito el compromiso de participar en el diseño y construcción de soluciones que atendieran a los desafíos más retadores de la humanidad en el presente y el futuro, especialmente en los asuntos relacionados con la sociedad, el humanismo y la cultura; el desarrollo sostenible; el cuidado y el bienestar; la innovación educativa y las miradas de futuro; y los temas de ciencia, tecnología e innovación.

Con esta ruta en mente y su visión se crearon nuevas unidades como On.going, Centro de Emprendimiento de Impacto y los centros Humanista, de Valor Público y de Gerencia y Empresa; Nodo EAFIT, y el Área de Ciencias del Cuidado y de la Vida, entre otras.

Así mismo, con el ánimo de hacer tangible esta transformación, se adelantó un proceso de reconfiguración organizacional interna estructurada en tres capacidades: capacidades de conocimiento, capacidades de soporte académico y articulación, y capacidades de conexión. Estos cambios buscaban desarrollar aún más las fortalezas de los profesores y colaboradores, evitar la duplicidad de esfuerzos, tener áreas con interacciones más potentes y promover una estructura más dinámica, ágil, flexible, efectiva y sostenible, priorizando el trabajo en equipo, la interdisciplinariedad, la confianza, las conversaciones y el liderazgo.

Finalmente, con la integración de los Valores Institucionales de la Inclusión y el Pluralismo, en 2022, los esfuerzos de Claudia Restrepo también se han enfocado, en los últimos dos años, en fortalecer el programa de Becas Talento EAFIT, con el que se busca que más jóvenes de excelencia puedan hacer realidad sus sueños de acceder a la educación superior. Las acciones decididas por los temas de diversidad y equidad de género, el cuidado del medio ambiente, y la participación en debates de coyuntura nacional centrados en las reformas a la educación y la salud también han hecho parte de las prioridades de la Rectora durante su administración.

La historia de Claudia como rectora de EAFIT continúa escribiéndose, todos los días, de la mano de la comunidad de talento que lidera en la actualidad y con la que espera alcanzar importantes hitos como la renovación -por tercera vez- de la Acreditación Institucional de Alta Calidad.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)