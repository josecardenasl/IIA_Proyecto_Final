# Internacionalización en el campus - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Internacionalización en el campus

​​Mediante la Internacionalización en casa ideamos, difundimos y creamos experiencias de aprendizaje global en el campus universitario para contribuir al desarrollo de competencias globales e interculturales​ en la comunidad eafitense.​

*    Internacionalización En El Campus 

Buddy Program

Programa realizado por el grupo estudiantil Partners Campus e Internacionalización EAFIT, para el acompañamiento a los estudiantes de intercambio internacional ​en su inmersión cultural y vida universitaria.

 Los estudiantes que hacen parte del Buddy Program son asesorados y formados ​por Internacionalización EAFIT. Al finalizar su experiencia en cada semestre, reciben una insignia de voluntariado otorgada por Filantropía EAFIT.

 Si eres un estudiante internacional que está cursando a​signaturas en nuestra universidad, recibirás información de tu Buddy por medio de tu correo de EAFIT.

La Noche Internacional

Un espacio para vivir la cultura y la gastronomía del mundo de la mano de nuestros estudiantes internacionales.

Go Global

Go Global, nuestra iniciativa para impulsar la internacionalización en el campus, se destaca por promover la multiculturalidad y el uso de un segundo idioma, así como por fomentar la excelencia y los intercambios académicos. 

 Al destacar siempre una región o país diferente, Go Global facilita la conexión de la comunidad EAFIT con el escenario internacional, convirtiéndose en una estrategia integral para fortalecer nuestra presencia global y enriquecer nuestra experiencia educativa.

Concurso de iniciativas para la internacionalización del campus

En la Universidad EAFIT nos enorgullece ser una institución abierta al mundo y queremos seguir creciendo como un referente internacional. A través de este concurso, te invitamos a compartir tus ideas innovadoras para aportar a su internacionalización. 

 Si deseas participar del concurso consulta los detalles por medio del correo: ​practicanteinter@eafit.edu.co

 Lo realizamos una vez al año y abrimos la convocatoria en agosto.

Experiencia internacional en el campus

Participa en una experiencia internacional en el campus con actividades académicas, salidas culturales y visitas empresariales vinculándote a una de nuestras misiones académicas entrantes. Podrás interactuar con estudiantes internacionales, enriquecer tu conocimiento intercultural y obtener un certificado y un apoyo económico por tu vinculación. 

 El primer mes de cada semestre abrimos la convocatoria y te enterarás por nuestro Instagram.

Convocatorias y oportunidades

Para participar en actividades que ofrecen nuestros aliados internacionales, virtuales o presenciales, síguenos en Instagram, en @internacionalización.eafit, y conoce las convocatorias disponibles y el proceso de postulación.​

Internacionalización 

Si te interesa profundizar en la internacionalización en el campus o del currículo, o si deseas que creemos juntos una estrategia de Aprendizaje Global, déjanos tus datos:

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Internacionalización

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Rol/programa académico? 

Actividad de interés*? 

Experiencia? 

O escríbenos al correo: agonzalez1@​eafit.edu.co

- [x] 

- [x] 

## Contacto

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)