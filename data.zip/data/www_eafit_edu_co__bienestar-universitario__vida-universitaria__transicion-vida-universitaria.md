# Transición a la vida universitaria - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Transición a la vida universitaria

Facilita tu integración a la vida universitaria en EAFIT con nuestra asignatura de inducción y orientación vocacional. Descubre recursos para una transición exitosa.

*    Transición A La Vida Universitaria 

En este servicio los estudiantes eafitenses encontrar una guía que les facilitará su tránsito de la secundaria a la Universidad, al aportar a su integración al medio universitario y formación integral.

##### Actividades

Esta asignatura pretende que los estudiantes de primer semestre identifiquen alternativas personales, institucionales y académicas que faciliten su integración a la vida universitaria, por medio de la información y el acompañamiento adecuado para comenzar esta nueva etapa y así promover un vínculo con compañeros, docentes y la institución que favorezca la experiencia de aprendizaje.

Consulta ofrecida a estudiantes de pregrado de EAFIT, estudiante de colegio o bachilleres, empleados que van a cursar algún pregrado y aspirantes a beca en EAFIT, para favorecer la toma de decisiones en relación con la educación superior y la elección laboral- ocupacional considerando sus aptitudes, intereses, rasgos de personalidad, proyección y contexto.

###### Más información

Conoce más de Desarrollo Estudiantil [aquí](https://www.eafit.edu.co/bienestar-universitario/desarrollo-estudiantil)

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)