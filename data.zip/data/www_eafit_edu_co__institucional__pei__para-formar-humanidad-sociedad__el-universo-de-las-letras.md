# El universo de las letras​

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# El universo de las letras​

*    El Universo de Las Letras​ 

​​La Editorial EAFIT celebra las letras y los autores, contribuyendo a la sostenibilidad de la cadena del libro y brindando un espacio vital para escritores e investigadores. Acoge y desarrolla todos aquellos proyectos editoriales que tengan como misión apoyar y fortalecer la producción intelectual, científica y literaria que se genera en la Universidad, y contribuye a la divulgación y circulación de obras significativas para el desenvolvimiento social y cultural de la comunidad.

Es de destacar que 2019, con 37 libros escritos y editados por docentes y científicos eafitenses adscritos a las diferentes escuelas y centros de estudios de la Institución, se convirtió en uno de los años más prolíficos. Estos 37 nuevos volúmenes se suman a los 140 que ya hacían parte de la colección Académica, así como a los más de 600 títulos y 400 autores que ha publicado la Editorial EAFIT en 22 años de existencia.

Las palabras son una manera de dejar un legado a la sociedad y, además, de su colección Académica, la Editorial cuenta con otras muy reconocidas como Literatura, Cuadernos Viajeros, Rescates, Biblioteca Fernando González y Biblioteca Gonzalo Arango.

## En 2019, la Editorial EAFIT participó de tres ferias internacionales y nueve nacionales. Su presencia en la Fiesta del Libro y la Cultura es muy relevante.

## 4. Educación de calidad

## 17. Alianza para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate