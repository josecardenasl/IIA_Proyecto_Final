# Programas corporativos para empresas - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Programas corporativos para empresas

Los acompañaremos en la necesidad de formación de sus ​empleados en el desarrollo de las competencias de una lengua extranjera.

*    Programas Corporativos Para Empresas 

###### ¡Programas a la medida de tu empresa!​

## Programa para empresas

1. Cursos a la medida y propósitos específicos.

 2. Talleres complementarios.

 3. Asesorías en políticas internas de bilingüismo. 

 4. Clases presenciales, combinadas y en línea en nuestras sedes o en las instalaciones de la empresa.

 5. Cobertura nacional e internacional.

 6. Certificados de finalización.

 7. Acompañamiento permanente al proceso de aprendizaje.

 8. Programas en co-creación.

 9. Grupos conversacionales para todos los niveles​.​

###### **Experiencia de inmersión, un espacio dedicado a las actividades de entretenimiento, networking, conversación y práctica del idioma inglés**

## 1. Acompañamos la estrategia de tu empresa en espacios de aprendizaje diferentes.

## 2. Propiciamos el desarrollo de habilidades profesionales.

## 3. Diseñamos el contenido de la experiencia de acuerdo a las necesidades.

## 4. Contamos con expertos y docentes con conocimientos afines a los ámbitos empresariales.

## 5. Nos adaptamos a las definiciones que la empresa demande tales como duración, intensidad e inversión. Inmersión en español para extranjeros.

## +800

Estudiantes nuevos cada año

## 90%

de efectividad

Idiomas que puedes aprender con nosotros

## Inglés

## Francés

## Italiano

## Alemán

## Portugués

## Español para extranjeros

#### **¡Contáctanos!**

## Keli Jhojana Villa Carvajal

321 844 8881

 kvilla@eafit.edu.co

## Diana Vanessa Valencia

304 461 8136

 dvvalencic@eafit.edu.co

###### **Nuestros aliados:**

Contacto 

¿Quieres saber más?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono de contacto*? 

Correo electrónico*? 

Ciudad de residencia*? 

Contenido de interés 

Cuéntanos, ¿Qué deseas saber?*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)