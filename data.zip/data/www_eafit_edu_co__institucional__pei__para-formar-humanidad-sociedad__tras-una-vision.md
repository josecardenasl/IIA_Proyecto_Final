# Tras una visión integral de los territorios - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Tras una visión integral de los territorios

*    Tras Una Visión Integral de Los Territorios 

​​Desarrollar un Sistema de Alerta Temprana (SAT) de bajo costo y adaptado al contexto local, de tal manera que esté cultural y espacialmente adaptado a las complejas condiciones de territorios densamente urbanizados, es el objetivo del proyecto Inform@risk: hacia un territorio más seguro, desde el que se adelantan estudios geológicos, evaluación del riesgo y diseño de una red de sensores para anticipar los movimientos de tierra.

Inform@risk surge de la cooperación internacional liderada por el Centro de Estudios Urbanos y Ambientales (Urbam) y la Universidad Leibniz de Hannover (Alemania), a través de la financiación del Ministerio Federal para la Educación e Investigación (BMBF-Alemania), y cuenta con la participación de actores del gobierno, la academia, la sociedad civil y la comunidad en riesgo. El piloto se desarrolla en el sector Bello Oriente (comuna tres-Manrique), acompañado del diseño de rutas de evacuación y espacios de encuentro comunitario que ayuden a reducir los riesgos por eventos naturales.

Pero no solo Medellín está en la mirada de estos proyectos e investigaciones de Urbam que vinculan territorios, planeación y urbanismo. El Suroeste antioqueño como zona estratégica por su tendencia de transformación asociada a una nueva infraestructura vial, requiere de visiones integrales y espacios de conversación. Otros países como Costa Rica se abrieron a la experiencia de la Universidad para el desarrollo de acciones y diseño urbano para prevenir el crimen y el narcotráfico en las municipalidades.

Los proyectos activos del Centro de Estudios Urbanos y Ambientales Urbam involucran diferentes temáticas como hábitat, espacio público y equipamientos, planeación estratégica y renovación urbana sostenible. Pensando en que haya proyección social, trabajan en zonas que enfrentan conflictos (y buscan entenderlos), pero también con oportunidades para alcanzar un desarrollo sostenible.

## 11. Ciudades y comunidades sostenibles

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)