# Aprendizaje ​Experiencial - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Aprendizaje ​Experiencial

El aprendizaje activo, específicamente el aprendizaje experiencial, se ubica en el corazón del modelo educativo de la Universidad EAFIT, situando a los estudiantes como protagonistas de su propio proceso de aprendizaje, buscando fortalecer el saber aplicado sin abandonar la importancia del conocimiento teórico y de la reflexión sobre las consecuencias del hacer, a la vez que les permite mantener un contacto permanente con el entorno nacional e internacional.​ ​​

*    Aprendizaje ​Experiencial 

###### En EAFIT valoramos y promovemos el aprendizaje a través de la experiencia.

**Definición de Aprendizaje Experiencial en EAFIT:**“El aprendizaje experiencial, como parte del aprendizaje activo, es un enfoque educativo orientado a la implicación integral de los estudiantes por medio de procesos que van desde el diálogo y la participación en contextos académicos, naturales, socioculturales y organizacionales, hasta la inmersión en entornos virtuales orientados a la simulación, para propiciar el desarrollo de competencias corporales, socioemocionales y cognitivas. En este enfoque, el estudiante, su relación con los pares, la naturaleza y con el contexto son elementos centrales de la apropiación del conocimiento, acompañado por un profesor, un facilitador o una estrategia que orienta o crea las condiciones para que suceda la experiencia formativa”.

Desplegar menú

#### Así se vive el Aprendizaje Experiencial ​

En la Universidad se vive el Aprendizaje Experiencial en todos los ámbitos académicos curriculares y extracurriculares, esta metodología se evidencia en las prácticas profesionales, en los laboratorios de las distintas Escuelas, en los Consultorios, en la participación en competencias, en la resolución de retos, en los centros de estudio e incidencia, en los grupos estudiantiles, en los diferentes semilleros y grupos de investigación, solo por mencionar algunos.

#### Servicios​

En el 2023 inicia oficialmente el área de Aprendizaje Experiencia, adscrita​ a la Dirección de Desarrollo Académico, siendo este un hito que posiciona a la universidad como líder del tema a nivel nacional.

El área, materializa lo declarado en el modelo educativo, agregando valor a través de servicios, tales como: divulgación del modelo educativo, asesoría meso y micro curricular, unificación de criterios relacionados con aprendizaje experiencial, identificación de buenas prácticas y oportunidades de sinergias, fomento de trabajo colaborativo entre áreas, difusión de actividades relevantes, formación a profesores en metodologías didácticas, entre otros.​​

## ​Asesoría en diseño Mesocurricular

Asesoramos a las Escuelas, en la etapa de diseño curricular de los programas de pregrado y posgrado, en la identificación de asignaturas estrategias que se desarrollarán bajo un enfoque de aprendizaje experiencial, en articulación con los procesos de registro calificado liderado por el área de calidad académica.

## ​​​Asesoría en diseño Microcurricular​

Asesoramos a las escuelas en la formulación de las experiencias de aprendizaje bajo un enfoque de aprendizaje experiencial en las asignaturas estrategias que fueron declaradas durante el diseño curricular del programa de pregrado o posgrado.

## ​​Ciclo de formación en Aprendizaje Experiencial​

Definimos y dinamizamos, junto con EXA, el ciclo de formación en las metodologías de aprendizaje experiencial, tales como:​​

 Fundamentos de aprendizaje experiencial

 Aprendizaje basado en proyectos​

 Aprendizaje basado en retos​

 Aprendizaje basado en juegos​​​​​

 Aprendizaje basado en problemas

 Aprendizaje basado en caso​s

 Aprendizaje basado en servicio (en construcción)​​​

## Fondo de Aprendizaje Experiencial

Fondo de Aprendizaje Experiencial: El Fondo de Aprendizaje Experiencial está diseñado para apoyar y fortalecer iniciativas académicas que incorporen metodologías basadas en la experiencia directa. Su propósito es impulsar actividades curriculares y extracurriculares que transformen el proceso formativo de los estudiantes, promoviendo la innovación pedagógica, el desarrollo de competencias y la implementación de proyectos con alto impacto educativo.

##### Muestra de Iniciativas de Aprendizaje Experiencial

Escenario en el que se evidencia cómo el aprendizaje experiencial es acción que moviliza retos, propone soluciones y conecta el talento de nuestros estudiantes a través de iniciativas que dan vida al modelo educativo eafitense; en un mismo escenario se socializan con la comunidad educativa (estudiantes, profesores y empleados) iniciativas de aprendizaje experiencial que fueron desarrolladas por escuelas y áreas de apoyo a la academia, propiciando en los asistentes una comprensión del aprender haciendo.

#### 2023-1

#### 2024-1

## Tablero seguimiento Aprendizaje Experiencial

Tablero de consulta dirigido a coordinadores, jefes de programa y decanos, diseñado para identificar las asignaturas de pregrado y posgrado declaradas bajo la metodología de Aprendizaje Experiencial, así como para consultar la ejecución de los recursos asociados a las iniciativas financiadas por el fondo.

 Este tablero permite visualizar de manera consolidada la información académica y presupuestal, facilitando el seguimiento, el análisis y la toma de decisiones relacionadas con la implementación del Aprendizaje Experiencial.

##### Embajadores

Los embajadores representan las escuelas y áreas que incorporan el aprendizaje experiencial en la universidad, como parte de su estrategia pedagógica; ellos son los encargados de dinamizar el tema en sus áreas facilitando el flujo de información y canalizando las necesidades​.

​​Escuela de Administración ​

Katherine Nieto Lopez 

 Profesional

 knietolo@eafit.edu.co

​​Escuela de Finanzas Economía y Gobierno

​​Alejandra Maria Lujan Jaramillo

 Jefe de Programa​​​​​

 alujanj@eafit.edu.co

Escuela de Ciencias Aplicadas e Ingeniería

Agueda Lucia Valencia Deossa

 Coordinador

 alvalencid@eafit.edu.co

​​Escuela de Artes y Humanidades​

Carolina Usuga Arcila

 Coordinador

 gusugaa@eafit.edu.co

​​Escuela de Derecho

​​Adelaida Acosta Posada​

 Profesor​

 ​​​​​aacostap@eafit.edu.co​

​​Biblioteca

​​Claudia Vélez ​Pereira

 Coordinadora​

 cvelezpe@eafit.edu.co

Idiomas

Rubén Darío Agudelo Arango 

 Jefe

 ragude10@eafit.edu.co

Nodo

Maria Angelica Rocha Vasquez

 Analista de Producto

 marochav@eafit.edu.co

​​Formacion ​CTeI-Investigación​​

Catalina López Otálvaro

 Jefe Oficina Posgrados​​​​

 clopezot@eafit.edu.co

​​Talento EAFIT​

​​Camilo Álvarez ​Lince

 Líder de Desarrollo de Talento​​​​

 calvar18@eafit.edu.co

​​Universidad de los Niños ​

Cristina Ospina Villa

 Analista

 cospinav1@eafit.edu.co

On.going

Juan Pablo Medina Rendón​

 Formador Académico​​​​

 jmedin15@eafit.edu.co

Kratos

​​Maria Alexandra Montoya Bernal​

 Coordinador​​​​

 mmontoy4@eafit.edu.co

EXA

​​​Maryory Yarce​​​

 Líder De Formación

 ​​​​​​​​​​eyarce@eafit.edu.co

##### Noticias

##### ​​Experiencia que transforma

##### Competencia nacional de vehículos de atracción eléctrica

Gracias a quienes hacen posible cada meta. [**Ver vídeo**](https://eafit-my.sharepoint.com/personal/wcanacue_eafit_edu_co/_layouts/15/stream.aspx?id=%2Fpersonal%2Fwcanacue%5Feafit%5Fedu%5Fco%2FDocuments%2FGracias%20a%20quienes%20hacen%20posible%20cada%20meta%2E%20%F0%9F%8F%81Desde%20Kratos%20queremos%20agradecer%20profundamente%20a%20las%2Emp4&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJPbmVEcml2ZUZvckJ1c2luZXNzIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXciLCJyZWZlcnJhbFZpZXciOiJNeUZpbGVzTGlua0NvcHkifX0&ga=1&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E89187faa%2Dfaff%2D4b9a%2D856e%2D14fb003ddc57)

Para más información consultar [**aquí**](https://universidadeafit.widen.net/s/vxscslsktg/informe-kratos-vte-2025)

##### ​Contacto

Coordinación de Aprendizaje Experiencial​.

Bloque 18 - 514

2619500 Ext 9458​.

**​​Willy Henao Zea​**

Coordinador Aprendizaje Experiencial

whenaoze@eafit.edu.co​

**​​Wilver Canacue Tique​**

Auxiliar administrativo​

wcanacue@eafit.edu.co ​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate