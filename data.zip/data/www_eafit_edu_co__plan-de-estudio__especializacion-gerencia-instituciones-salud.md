# Especialización en Gerencia de Instituciones de la Salud​​​​​ - Medellín - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Especialización en Gerencia de Instituciones de la Salud​​​​​ - Medellín

*    Plan de Estudio 
*    Especialización En Gerencia de Instituciones de La Salud​​​​​ - Medellín 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

Núcleos, ciclos, trayectorias y énfasis

- [x] Obligatorias 

- [x] Plan de estudios del programa 

Semestre 1

Créditos 

totales-

Créditos 2

#### Administración y Organizaciones

Código: OG0718

Obligatorias
## Administración y Organizaciones

2 Créditos

UMES

La asignatura introduce al estudiante en la comprensión de las organizaciones como órdenes sociales deliberadamente diseñados para un fin, diferenciándolas de agregados sociales como la familia, la comunidad o la sociedad. Explora las características que hacen a las organizaciones susceptibles de formalización, estandarización y estructuración, así como las dinámicas de poder, coordinación y conflicto que emergen en su funcionamiento.

El curso analiza las configuraciones organizacionales, los estilos de dirección y las formas de intervención frente al conflicto, integrando dimensiones como la personalidad, la autoridad y el liderazgo. A través de este enfoque, el estudiante identifica fenómenos visibles y subyacentes de la vida organizacional, comprende cómo operan los órdenes formales e informales y reconoce los factores que inciden en la conducción de grupos y en el desempeño institucional.

La asignatura emplea metodologías activas (casos, talleres, ejercicios de simulación y actividades experienciales) que permiten al estudiante relacionar los conceptos teóricos con su contexto profesional, reflexionar sobre su propio perfil gerencial y fortalecer competencias como el pensamiento crítico, la comprensión del contexto organizacional y la toma de decisiones con integridad.

Código: **OG0718**

Créditos 2

#### Marco Constitucional y Políticas Públicas en Salud

Código: OG0715

Obligatorias
## Marco Constitucional y Políticas Públicas en Salud

2 Créditos

UMES

Esta asignatura ofrece una comprensión profunda del derecho a la salud en Colombia desde su fundamento constitucional y su desarrollo como derecho fundamental. Examina la evolución normativa, jurisprudencial y política que ha configurado el sistema de salud colombiano, con especial atención al papel del Estado Social de Derecho y los principios de equidad, participación, universalidad y protección de libertades que sustentan la acción pública en salud.

La asignatura aborda la formulación, implementación y evaluación de políticas públicas en salud, analizando los procesos, actores y decisiones que orientan la respuesta estatal frente a las necesidades de la población. A partir del estudio comparado de sistemas de salud y marcos constitucionales, el estudiante identifica oportunidades y limitaciones para el diseño de políticas efectivas, así como su impacto en la gestión de instituciones del sector.

Mediante metodologías activas basadas en problemas, casos y análisis de situaciones reales, la asignatura fortalece la capacidad para relacionar elementos jurídicos, institucionales y estratégicos con los procesos de administración en salud. Esto permite comprender cómo las políticas públicas y el marco constitucional inciden en la operación, regulación y orientación de las organizaciones, promoviendo decisiones fundamentadas que favorecen la equidad, la calidad y el acceso a los servicios de salud.

Código: **OG0715**

Créditos 2

#### Entorno Económico

Código: OG1102

Obligatorias
## Entorno Económico

2 Créditos

UMES

Esta asignatura introduce al estudiante en el análisis del marco macroeconómico y microeconómico que condiciona el desempeño del sector salud y de sus organizaciones. Revisa las principales variables agregadas (producción, ingreso, empleo, ahorro, inversión, precios) y su relación con los ciclos económicos, destacando cómo estos factores (externos al control gerencial) inciden en la sostenibilidad y en la toma de decisiones estratégicas de las instituciones de salud.

La asignatura aborda cinco bloques: entorno macroeconómico (contabilidad nacional, mercados de bienes/servicios y financiero), política económica (monetaria y fiscal, en horizontes de corto y largo plazo), entorno internacional (sector externo), entorno coyuntural (seguimiento a informes del Banco de la República, marco fiscal y competitividad) y entorno microeconómico (oferta y demanda, tipos de bienes y mercados, elasticidades). Esta estructura dota al estudiante de herramientas teóricas y aplicadas para comprender variables del contexto de la salud y valorar su impacto sobre la gestión institucional.

Código: **OG1102**

Créditos 2

#### Información Financiera para La Toma de Decisiones

Código: OG1104

Obligatorias
## Información Financiera para La Toma de Decisiones

2 Créditos

UMES

Esta asignatura aborda el papel de la información financiera como base para la toma de decisiones estratégicas en las organizaciones de salud. Se enfoca en comprender cómo los sistemas de información contable, los estados financieros y el análisis de indicadores permiten evaluar el desempeño, la sostenibilidad y la creación de valor dentro de las instituciones.

La asignatura analiza elementos esenciales de la administración financiera: lectura e interpretación de estados financieros, uso de herramientas de análisis (liquidez, endeudamiento, eficiencia, rentabilidad), clasificación de egresos y componentes del costo de prestación de servicios. Esta estructura permite entender cómo las decisiones gerenciales afectan el cumplimiento de objetivos, la asignación de recursos y la permanencia de la organización en el largo plazo.

La metodología combina exposición conceptual, resolución de talleres y estudio de casos, fortaleciendo la capacidad de evaluar lineamientos estratégicos y su impacto financiero. Con ello, el estudiante adquiere criterios técnicos y una visión integral que articula información, análisis y decisiones de gestión dentro del sector salud.

Código: **OG1104**

Créditos 2

#### Dirección Estratégica

Código: OG1103

Obligatorias
## Dirección Estratégica

2 Créditos

UMES

Esta asignatura introduce al estudiante en los fundamentos y procesos de la dirección estratégica, entendida como la capacidad de definir el rumbo de una organización en entornos dinámicos y competitivos. Desde una mirada integral, el curso analiza cómo las instituciones (incluidas las del sector salud) formulan, evalúan y ejecutan estrategias para alcanzar sus objetivos, responder al entorno y generar valor sostenible.

El contenido se estructura en tres fases: una fase filosófica, centrada en la misión, visión, principios, valores y propósito superior de la organización; una fase analítica, que examina el entorno externo (PESTEL, fuerzas competitivas) y el entorno interno (cadena de valor, capacidades, procesos) para identificar fortalezas, oportunidades y riesgos; y una fase operativa, donde se diseñan e implementan estrategias mediante herramientas como el Balanced Scorecard, los KPI, los tableros de control y la definición de propuestas de valor.

A través de clases magistrales, proyectos aplicados y análisis de casos, la asignatura fortalece la capacidad de los estudiantes para comprender lineamientos estratégicos, definir cursos de acción y tomar decisiones coherentes con el contexto organizacional. Esto permite desarrollar una visión holística y crítica sobre cómo competir, crecer y responder a los cambios del entorno en las instituciones de salud y en otros sectores.

Código: **OG1103**

Créditos 2

#### Gerencia de Mercadeo en Salud

Código: 

Obligatorias
## Gerencia de Mercadeo en Salud

2 Créditos

UMES

Esta asignatura aborda los fundamentos y estrategias de mercadeo aplicados al sector salud, reconociendo la dinámica competitiva, los cambios tecnológicos, la transformación de la demanda y la necesidad de generar propuestas de valor diferenciadas en mercados cada vez más exigentes. Desde esta perspectiva, el curso desarrolla criterios para comprender cómo las acciones de mercadeo influyen en la sostenibilidad, crecimiento y posicionamiento de las organizaciones de salud.

El contenido integra la conceptualización de variables como producto, marca, precio, valor, segmentación, análisis de mercado, marketing digital y experiencia del cliente. También profundiza en herramientas para analizar portafolios, construir identidades de marca, formular estrategias competitivas y gestionar relaciones con usuarios y segmentos clave. Esto permite comprender la relación entre mercado, estrategia y desempeño organizacional, así como anticipar oportunidades y amenazas en entornos locales y globales.

A través de metodologías activas como el aprendizaje basado en retos, el análisis de casos y la construcción colectiva, los estudiantes aplican los conceptos del curso en situaciones reales de organizaciones de salud. Con ello fortalecen su capacidad para diseñar estrategias de mercadeo, interpretar comportamientos del mercado y proponer acciones que aporten a la creación de valor y al desarrollo institucional.

Código: 

Créditos 

#### Conferencia 1

Código: 

Plan de estudios del programa
## Conferencia 1

Créditos

UMES

Optativo

Código: 

Semestres

1 

2 

Núcleos, ciclos, trayectorias y énfasis

- [x] Obligatorias 

- [x] Plan de estudios del programa 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate