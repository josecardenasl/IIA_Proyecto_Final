# Macrame

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

Discover your profile at EAFIT

Are you a student, professor, graduate, or part of an organization? Explore the options and find the personalized information EAFIT has for you. Click on your profile and access resources, news, and events designed especially for you. Your EAFIT experience starts here!

**Your EAFIT experience starts here!**

Students and graduates

Employees

Teachers

Children and young people

Organizations

Close profiles

Information for you

*   That's EAFIT

Return

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Accessibility

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Language

Powered by [![Image 18: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Look for 

Search

Menu

# Macrame - 20 hours

Registrations for the first semester of 2026: Starting at 8:00 am on January 26th

*    Macrame - 20 Hours 

###### Workshop aimed at: Students, graduates, professors, employees and retirees of EAFIT University and their families (parents, children, siblings and spouse or partner).

If you are a student, employee, teacher, or retiree, by registering for the Workshop you agree to the Artistic Workshops Policy. Therefore, please be aware that you will need to manage your absences. If you fail to meet the 80% attendance requirement for your Workshop, the system will generate an invoice for the full cost of the workshop, without any discount.

En este taller nos sumergiremos en el arte milenario del tejido en Macramé, cuyo origen se remonta a los antiguos persas (2.500 A.C.). Estas técnicas ancestrales nos reunirán para la aplicación moderna de su esencia utilitaria como un elemento de alto valor simbólico para el hogar y uso de las participantes. A través de un recorrido por las texturas, nudos, formas y destrezas vamos a llevar a cabo piezas hermosas y funcionales. 

Además, experimentaremos el tejido como una fuente de bienestar y calma, una labor meditativa que puede servir como “terapia” para aliviar las sobrecargas mentales a las que estamos todos expuestos hoy en día, pues a través de la actividad de tejer se prepara un estado mental de apertura y relajamiento, que influye en un estilo de vida de mayor realización y menos dispersión.

​

Aprendizaje de la correcta utilización y disposición de los materiales y accesorios para el tejido.

Aprendizaje y práctica de los nudos básicos y sus diferentes variaciones y combinaciones.

Realización de diferentes proyectos de iniciación: Colgante portamacetas doble, tapiz de pared o camino de mesa y bolso. ​

​La lista de materiales será entregada por la facilitadora en la primera sesión

Nota: Después de la primera clase se pedirán materiales adicionales de bajo costo. ​

**Aula: 12-202**

**Horario​:​**

**Grupo 1**

Fecha inicio: miércoles, 11 de febrero de 2026

Fecha fin: miércoles, 22 de abril de 2026

Hora: 4:00 p. m. - 6:00 p. m.

Día: Miércoles

Facilitador(a): Natalia Iñiguez

**Grupo 2**

Fecha inicio: viernes, 13 de febrero de 2026

Fecha fin: viernes, 24 de abril de 2026

Hora: 12:00 m. - 2:00 p. m.

Día: Viernes

Facilitador(a): Natalia Iñiguez

Inversión estudiantes de los programas de pregrado y posgrado, profesores y empleados de la Universidad EAFIT: ¡SIN COSTO! Antes de realizar la inscripción, asegúrate de que puedes cumplir con los horarios del Taller y las condiciones de la Política de los Talleres artísticos.

Inversión egresados y graduados de pregrado y posgrado de la Universidad EAFIT: $152.500

Inversión familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado, y de egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT: $152.500

Inversión participantes activos del programa Saberes de Vida: $152.500

Inversión participantes activos de Educación Continua EAFIT o Idiomas EAFIT: $244.000

Costo total del taller a pagar por inasistencia (estudiantes y empleados): $305.000

If you are an undergraduate or graduate student, professor, or employee of EAFIT University: FREE OF CHARGE! Before registering, please ensure you can meet the Workshop schedule and the conditions of the Artistic Workshops Policy.

###### Registration begins at 8:00 am on January 26, 2026

How to register for the Art Workshops

### 1

The art workshops are aimed at EAFIT students, graduates, employees and pensioners and their families*.

### 2

Choose the workshop you want to take from the menu and click on it.

### 3

Read the program content, check the available schedules and the policies of the art workshops.

### 4

The art workshop options will be available on the scheduled registration date and time. If you log in before then, you won't see any workshop options to choose from.

### 5

Once you access the registration link, enter your ID number and follow the path: “Registrations – Workshops”, and there you will find the current semester.

### 6

Verify that the workshop option you want to take is enabled, select it and click on “Register”.

### 7

If you cannot find the workshop you want to take, it is because all places are already filled.

### 8

If you are an EAFIT student, employee, or pensioner, you must generate the settlement to be registered.

### 9

If you are an EAFIT graduate or family member, you must generate the settlement and make the payment through the established channels.

*Family members include: parents, children, siblings, and spouse or partner. Please be aware of the art workshop policies. Carefully plan your workshop dates to take full advantage of the benefits offered by the University. If you cannot find your chosen workshop when registering, it is because it is already full.

Study at EAFIT

Connect with EAFIT

Contact us

Legal information

University with Institutional Accreditation until 2026. 

Supervised by the Ministry of Education.

Our headquarters

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National hotline: 01 8000 515 900

Customer service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Customer service line: (57) 606 3214115, 606 3214119

Email: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 office 401

Customer service line: (57) 601 6114618

Email: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks