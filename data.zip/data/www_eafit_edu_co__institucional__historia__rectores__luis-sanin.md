# Luis Guillermo Sanín Arango - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Luis Guillermo Sanín Arango

(Rector entre ​1983-1995)

*    Luis Guillermo Sanín Arango 

**Un ingeniero químico de la Universidad de Antioquia llegó a la Rectoría de EAFIT en 1983. Sin embargo, su presencia en las aulas eafitenses se remonta al año 1970, donde comenzó su labor como docente.**

De manera posterior fue nombrado director de Planeación Académica desde donde aumentó la eficiencia del trabajo académico interno. Luego ocupó varios cargos, volviendo a la docencia y pasando por la Decanatura de la Escuela de Ingenierías, entre otros.

Durante el periodo de administración de Sanín Arango se vivió una de las mayores crisis que ha tenido EAFIT: un paro de docentes que desató la crisis financiera de la Universidad, pues el Consejo Superior había decidido suspender por un año las disposiciones del escalafón docente.

Ante esta situación, el Rector y los demás directivos enviaron una carta al Consejo Superior para ayudar a superar la crisis; pero luego de la solución hubo un despido masivo de profesores sindicalizados quienes a través de una demanda pidieron un reintegro.

Pero a pesar de estas dificultades hubo logros importantes, como la creación de las carreras de Negocios Internacionales, Economía e Ingeniería de Procesos, donde se sentaron las bases para la creación de Ingeniería de Diseño de Producto.

También se fundó el Instituto de Investigación y Capacitación del Plástico y del Caucho, se abrió la sede de EAFIT Bogotá, se decidió que había que construir un nuevo bloque para la Biblioteca, se consolidó el Centro de Laboratorios y se inició el proceso de Autoevaluación Institucional, entre otros avances.

Su rectoría, que hasta el momento ha sido la más prolongada en la historia de EAFIT, culminó en 1995. Luego de su administración, Guillermo Sanín se desempeñó como profesor en Ingeniería de Procesos y director de EAFIT Llanogrande.

Datos sacados del libro Universidad EAFIT 50 Años.​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)