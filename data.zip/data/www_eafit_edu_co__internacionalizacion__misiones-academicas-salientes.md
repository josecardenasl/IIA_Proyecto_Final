# Misiones académicas internacionales - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Misiones académicas salientes

Experiencias para eafitenses.

 En la Universidad EAFIT existe una gran variedad de experiencias internacionales de corta duración para toda la comunidad eafitense.​

*    Misiones Académicas Salientes 

## Nuestras experiencias

## Pasantías como parte del currículo

## Programas de educación continua

## Salidas académicas

## Programas conjuntos

## Nuestras misiones cuentan con cuatro componentes clave integrados a través del Aprendizaje Experiencial:

Académico

Unidos al conocimiento de nuestras Escuelas y centros de incidencia, ofrecemos cursos de alta calidad en relación con el tema de interés de la misión.

Cultural

Promovemos experiencias inmersivas para que los participantes conozcan las culturas de la ciudad y la región.

Empresarial

Propiciamos el contacto con los saberes aplicados de las organizaciones pues somos reconocidos como un actor clave en temas relacionados con la transformación urbana y social de la ciudad.​

Networking

Impulsamos la posibilidad de desarrollar una red de contactos internacionales y de enriquecer las perspectivas a través de encuentros con personas clave.​​

### ¿Te interesa explorar estas oportunidades?

Te recomendamos contactarte con el o la jefe de tu programa en cada una de nuestras escuelas.

Administración

Ciencias Aplicadas e Ingeniería

Artes y Humanidades

Derecho

Finanzas, Economía y Gobierno

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)