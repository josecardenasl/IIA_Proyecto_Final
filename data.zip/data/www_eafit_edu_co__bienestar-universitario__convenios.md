# Convenios - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Convenios

*    Convenios 

###### ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Convenios que ofrec​​en beneficios para empleados, estudiantes de Pregrado, estudiantes de Idiomas, pensionados y Egresados de EAFIT.

## Pensionados

## Egresados

## Estudiantes de idiomas

## Estudiantes

## Empleados temporales

## Empleados cátedra

## Empleados planta

Para acceder a estos convenios se deberá presentar el carné vigente y/o demás documentos que los acrediten como beneficiarios del mismo y actuaran en todo momento a título personal.

 Por favor tener presente las condiciones de cada oferta, las restricciones propias del convenio y el procedimiento de acceso al beneficio.

**La Universidad EAFIT a través de la Dirección de Desarrollo Humano y Bienestar​ ha celebrado convenios con Entidades Externas para el otorgamiento de beneficios, los cuales podrán abarcar descuentos o una propuesta de valor, entre otros, dependiendo de la campaña que se active de manera diferencial para los beneficiarios de cada uno de ellos, a los cuales les aplican las siguientes condiciones y restricciones:**

1.   Los beneficiarios de los convenios deberán validar los términos propios de los mismos y los procedimientos establecidos para el acceso a los beneficios; adicionalmente, deberán tener presente que para adquirir dichos beneficios deberán presentar el original del carnet y/o demás documentos que den cuenta del vínculo exigido.
2.   Será la respectiva Entidad Externa la que le facturará directamente a los beneficiarios, y estos últimos deberán cancelar las sumas debidas al momento de la facturación o cuando así lo determine la mencionada Entidad. Por lo anterior, la Universidad EAFIT no asumirá la responsabilidad por los pagos realizados.
3.   La Universidad EAFIT no se hará responsable por el cumplimiento de las obligaciones asumidas por los beneficiarios, ya que se precisa que éstos actuarán en todo momento a título personal y en ningún caso bajo representación de la Universidad EAFIT.
4.   Si la Universidad EAFIT llegare a recibir un reclamo de los beneficiarios, con ocasión de los convenios aquí relacionados, direccionará el mismo a la correspondiente Entidad Externa, quien será el responsable directo de atenderlo y darle una oportuna respuesta.
5.   La Universidad EAFIT no adquiere obligación alguna por la prestación de los servicios por parte de las Entidades Externas aquí mencionadas. En caso de presentarse algún daño, deficiencia o perjuicio a los beneficiarios, durante o después de la prestación del servicio, será responsabilidad únicamente de la respectiva Entidad Externa el resarcimiento del mismo.
6.   Para el caso de los beneficiarios que ostenten la condición de empleados de la Universidad EAFIT, se advierte que los beneficios derivados de los convenios aquí mencionados, son de carácter discrecional, los cuales no constituyen salario en tanto no están retribuyendo el servicio que prestan los empleados a la Institución.La Universidad EAFIT y las Entidades Externas aquí mencionadas, declaran que rechazan todas las clases de Explotación Sexual Comercial de Niños y Adolescentes (ESCNA), reconociendo, implementando y apoyando las medidas necesarias para la prevención de la ESCNNA.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)