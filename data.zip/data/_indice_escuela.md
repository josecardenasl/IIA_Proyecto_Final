# Índice de Escuelas - Universidad EAFIT

EAFIT cuenta con los siguientes escuelas:

- **Cafet - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/cafet
- **escuela-administracion / convenios-administracion** — https://www.eafit.edu.co/escuela-administracion/convenios-administracion
- **LAPSS - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/lapss
- **MercaLAB - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab
- **Aula de Innovación y Creatividad - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab/aula-innovacion-creatividad
- **Cámara de Gesell - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab/camara-gesell
- **​Face Reader - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab/face-reader
- **Laboratorio Visual/ Eye Tracker - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab/laboratorio-visual
- **Manilla Electro Galvánica - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab/manilla-electro-galvanica
- **Sala de Entrevistas a Profundidad - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab/sala-entrevistas-profundidad
- **Sala Makers - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/mercalab/sala-makers
- **Villa Innovadora - Universidad EAFIT** — https://www.eafit.edu.co/escuela-administracion/villa-innovadora
- **Becas y convocatorias​​​ - Esc​ue​​la de Cienc​​ias Aplic​​​adas ​​​e Ingeniería ​ - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/becas-y-convocatorias
- **Centro de Laboratorios - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios
- **Laboratorios de Ciencias Biológicas​​​​ - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-ciencias-biologicas
- **Laboratorios de Ciencias Físicas - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-ciencias-fisicas
- **Laboratorios de Ciencias de la Tierra - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-ciencias-tierra
- **​Laboratorio de Control Digital - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-control-digital
- **​Laboratorio de Hidráulica - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-hidraulica
- **​Laboratorio de Metrología ​​ - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-metrologia
- **​Laboratorios de Procesos - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-procesos
- **Laboratorio de Suelos, Concretos y Pavimentos - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/laboratorio-suelos-concretos-pavimentos
- **Taller de Máquinas Herrami​enta​​​​ - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/taller-maquinas-herramienta
- **​Taller de Proyectos Metalmecánicos - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/taller-proyectos-metalmecanicos
- **​​Talleres de Diseño​​​​​ - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios/talleres-diseno
- **escuela-ciencias-aplicadas-ingenieria / convocatorias-de-profesores** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/convocatorias-de-profesores
- **Línea I+D en Informática Educativa - Universidad EAFIT** — https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/informatica-educativa
- **Consultorio financiero - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/consultorio-financiero
- **DataPOL - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/datapol
- **Acerca del laboratorio - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/datapol/acerca-del-laboratorio
- **Recursos DataPol - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/datapol/recursos
- **escuela-finanzas-economia-gobierno / datapol / reserva-de-espacios-y-recursos** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/datapol/reserva-de-espacios-y-recursos
- **Servicios Datapol - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/datapol/servicios
- **Laboratorio Fina​​nciero - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/laboratorio-financiero
- **Infraestructura - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/laboratorio-financiero/infraestructura
- **Semilleros de investigación - Finanzas, Economía y Gobierno - Universidad EAFIT** — https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/semilleros-de-investigacion
