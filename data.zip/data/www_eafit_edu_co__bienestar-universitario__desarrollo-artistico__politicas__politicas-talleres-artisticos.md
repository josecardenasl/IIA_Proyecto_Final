**​​​​​​Al realizar la inscripción en cualquiera de los Talleres artísticos, el participante acepta dar cumplimiento a los reglamentos universitarios y especialmente a la presente política:**

**​1. Objetivo.**

Con el propósito de contar con un instrumento que permita definir pautas claras para el desarrollo de los talleres artísticos y para potencializar los mismos con el fin de brindarles a sus usuarios un beneficio que repercuta en un alto impacto sobre su calidad de vida, se establece la siguiente política.

**2. Usuarios.**

La política aquí plasmada aplica a:

Los estudiantes de los programas de pregrado y posgrado de la Universidad EAFIT.

Los profesores de la Universidad EAFIT con contrato laboral.

Los empleados de la Universidad EAFIT con contrato laboral.

Los egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT.

Los familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados y profesores con contrato laboral, estudiantes de los programas de pregrado y posgrado, y egresados y graduados de los programas de pregrado y posgrado, de la Universidad EAFIT.

Los usuarios activos del programa Saberes de Vida.

Los usuarios activos de Educación Continua EAFIT o Idiomas EAFIT.

Los empleados de las empresas landing ubicadas en el campus de la Universidad EAFIT ​

**3. Inscripciones.**

Todas las inscripciones a los talleres artísticos se harán por medio de un sistema que la Universidad EAFIT ha asignado para tales efectos. Cada taller tiene un cupo mínimo de usuarios el cual garantizará la apertura del mismo, y a su vez, un cupo máximo de usuarios que determinará el cierre de las inscripciones.

Los estudiantes, egresados, graduados de los programas de pregrado y posgrado, profesores, empleados de la Universidad EAFIT (con contrato laboral) y sus familias (padres, hijos, hermanos y esposo o compañero permanente), tendrán prelación en las inscripciones a los talleres artísticos, en fechas establecidas por el Departamento de Desarrollo Artístico, y una vez finalizado este período, y en caso de que queden cupos disponibles, el sistema se habilitará para los demás usuarios.

Los estudiantes de los programas de pregrado y posgrado, los profesores y empleados, de la Universidad EAFIT (con contrato laboral), y en general los usuarios de los Talleres, solo podrán inscribirse a un taller o grupo de taller por semestre. El Departamento de Desarrollo Artístico hará revisión de las inscripciones y decidirá, en caso de doble inscripción, en cual taller o grupo conserva la inscripción.

**4. Becas.**

El Departamento de Desarrollo Artístico ofrece becas del Cien por ciento (100%) para estudiantes de programas de pregrado y posgrado, profesores y empleados, de la Universidad EAFIT (con contrato laboral), como un beneficio que, desde el marco del mutuo cuidado, promueve la calidad de vida, la formación integral y el aprovechamiento del tiempo libre.

Para recibir este beneficio, Los usuarios a los que se hizo mención en el párrafo anterior, deberán inscribirse en las fechas estipuladas por el Departamento de Desarrollo Artístico y cumplir con el siguiente requisito:

Asistir por lo menos al ochenta por ciento (80%) de la totalidad de las sesiones del taller en el cual está inscrito. De no cumplirse este requisito, el estudiante, profesor o empleado deberá pagar el valor total del taller.

En caso de inasistencia por enfermedad de un estudiante, debe presentar en Desarrollo Artístico una incapacidad médica validada por el Departamento de Servicio Médico y Salud Ocupacional de la Universidad EAFIT. Los requisitos para la validación de incapacidades médicas se encuentran en: [validación de excusas médicas](https://www.eafit.edu.co/bienestar-universitario/desarrollo-artistico/talleres-artisticos/politicas/validacion-excusas-medicas).

Para el caso de los empleados, deben presentar una copia de la incapacidad que entrega su EPS.

**5. Descuentos.**

El Departamento de Desarrollo Artístico ofrece descuentos para los usuarios que se indican en el presente numeral, y de acuerdo a los porcentajes que se enuncian a continuación:

Para los egresados y graduados de los programas de pregrado y posgrado de la Universidad EAFIT: cincuenta por ciento (50%).

Para los familiares (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de los programas de pregrado y posgrado, y egresados y graduados de los programas de pregrado y posgrado, de la Universidad EAFIT: cincuenta por ciento (50%).

Para los usuarios activos del programa Saberes de Vida: cincuenta por ciento (50%).

Para los usuarios activos Educación Continua EAFIT, Idiomas EAFIT o empleados de las empresas landing con asiento en la Universidad: veinte por ciento (20%).

**6. Devoluciones.**

Al usuario inscrito que no pueda tomar el taller se le aplicarán los parámetros de devolución de dinero descritos a continuación:

Los estudiantes de programas de pregrado y posgrado, profesores y empleados, de la Universidad EAFIT que cuentan con la beca del 100%:

Tendrán plazo hasta tres días antes de iniciar las clases del taller para cancelarlo. De no ser así, deberá pagar el valor total del taller.

Los demás usuarios:

Hasta un día antes de iniciar las clases del taller: 100%.

Durante la primera semana de clases: 90%.

Durante la segunda y tercera semana de clases: 75%.

Una vez iniciada la cuarta semana de clase: No hay devolución.

**7. Generalidades.**

**a.** Las becas y descuentos para el empleado y su familia en educación formal y no formal son beneficios, de carácter discrecional, que la Universidad EAFIT otorga a empleados y a sus beneficiarios, los cuales no constituyen salario en tanto no están retribuyendo el servicio que prestan los empleados.

**b.** El usuario se obliga a dar un uso adecuado de las instalaciones donde se desarrolla el Taller, así como de los utensilios y herramientas de trabajo utilizados. La pérdida de las herramientas de propiedad del usuario no es responsabilidad de la Universidad.

**c.** El usuario se obliga a respetar los derechos de propiedad intelectual de terceros y, por consiguiente, deberá contar con las autorizaciones de sus titulares para reproducir o adaptar las obras cuando así sea requerido por la normatividad legal vigente.

**d.** La seguridad es prioritaria, por consiguiente, el usuario deberá seguir las instrucciones o indicaciones suministradas por el facilitador del taller artístico. Si tiene alguna inquietud sobre un procedimiento, deberá preguntarle al facilitador. Igualmente, si observa que se presenta cualquier situación que pueda exponer o lesionar su salud o integridad personal, o la de los demás usuarios, deberá reportarla inmediatamente.

**e.** Se establece una edad mínima de participación en lo talleres artísticos de 16 años teniendo en cuenta la seguridad integral del mismo, así como el desarrollo normal de las actividades propuestas en los contenidos de los programas. Se exceptúa el taller de pintura infantil el cual se tiene establecido una edad entre 5 y 12 años de edad. ​

**​f.** El Departamento de Desarrollo Artístico ofrece solo para el taller de pintura un espacio acondicionado para el cuidado de los trabajos durante su realización en el semestre. Una vez finalizados los talleres artísticos, los trabajos deberán ser retirados por los usuarios en un plazo máximo de 20 días calendario contados a partir de la fecha de terminación del taller, transcurrido el cual se entenderá que el propietario abandona sus trabajos y la Universidad podrá disponer de ellos. En caso de pérdida o daño de los trabajos durante el desarrollo de los talleres, y después de transcurrido el término de 20 días, esto no generará derecho a indemnización alguna y sólo se notificará por escrito al usuario.

**g.** El Departamento de Desarrollo Artístico realiza al final de cada periodo una feria de las artes con los trabajos de los usuarios que deseen hacer parte de la misma. La autorización necesaria para la exhibición se solicitará verbalmente por el facilitador de cada taller. Las obras se expondrán bajo un adecuado sistema de seguridad y vigilancia. En caso de pérdida o daño de las obras, la Universidad no será responsable por el valor patrimonial de las mismas, y el incidente no generará derecho a indemnización alguna y sólo se notificará por escrito al usuario. Una vez finalizada la feria de las artes, los trabajos deberán ser recogidos por los usuarios en un plazo máximo de 20 días calendario, transcurrido el cual se entenderá que el propietario abandona los trabajos y la Universidad podrá disponer de ellos.

**h.** El taller de joyería dispondrá de un espacio en el clóset de herramientas en donde se ubicarán las herramientas olvidadas por los usuarios: la pérdida de las herramientas de los usuarios no es responsabilidad de la Universidad.

**8. Competencia.**

Desarrollo Artístico es la Dependencia de la Universidad EAFIT encargada de liderar y gestionar todo lo relacionado con los talleres artísticos.

Cualquier situación no prevista en el presente documento será resuelta, en primera instancia, por el Departamento de Desarrollo Artístico de la Universidad EAFIT, y en segunda instancia, por la Dirección de Desarrollo Humano y Bienestar.

**9. Efectos.**

Desde la fecha en que entra en vigencia el presente documento, quedan sin efecto las políticas, disposiciones, reglamentos o manuales que se hubiesen podido adoptar con anterioridad sobre el mismo objeto.

**10. Vigencia.**

La política aquí establecida rige a partir de enero de 2025​.