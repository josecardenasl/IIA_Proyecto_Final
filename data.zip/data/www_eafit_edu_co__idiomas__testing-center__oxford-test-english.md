# Oxford Test of English - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Oxford Test of English

*    Oxford Test Of English 

## Información general

Descripción del examen

El Oxford Test of English es examen certificado por la Universidad de Oxford que evalúa las cuatro habilidades del lenguaje y reporta resultados enmarcados en los niveles B2, B1 y A2 del Marco Común Europeo de Referencia (MCER).

**A partir del 1 de febrero de 2023, esta certificación está contemplada dentro de la Política de Lengua Extranjera de la Universidad EAFIT.​ ​**

Estructura

La prueba, cuya duración es de 2 horas, tiene 4 componentes; escritura, comprensión lectora, escucha y conversación.

Proceso de inscripción para la prueba completa

1.   Ingrese a [https://app.eafit.edu.co/recaudos/](https://app.eafit.edu.co/recaudos/ "https://app.eafit.edu.co/recaudos/") y seleccione el examen OXFORD TEST OF ENGLISH marcado con la respectiva sede y fecha de su elección.
2.   Lea atentamente las instrucciones y haga clic en **continuar**. En la casilla **Tarifa**, seleccione la opción **Derechos de Inscripción OXFORD TEST OF ENGLISH**.
3.   El pago lo puede realizar en línea haciendo clic en el botón **PAGAR**. También puede generar una liquidación con la que podrá pagar en cualquier Bancolombia. Para esto, debe hacer clic en el botón **GENERAR** y luego en **IMPRIMIR LIQUIDACIÓN**.
4.   Recuerde que el pago lo debe hacer el mismo día que hace la inscripción de tal forma que se le asegure el cupo para tomar el examen.
5.   Una vez realizado el pago, envíe una foto de su comprobante de pago y su documento de identidad escaneado al correo [testingcenter@eafit.edu.co](mailto:testingcenter@eafit.edu.co)
6.   Al solicitar la prueba se aceptan los términos y condiciones de la misma.​ [Consúltalos aq​uí](https://universidadeafit.widen.net/s/zkbqtlffwg/terminos-condiciones-ote-2025).

Inversión

### Oxford Test of English

$486​.000 COP

### Inversión por una habilidad

$204.000 COP

Este examen da la opción de solo presentar o repetir una habilidad. Aclaramos que la prueba se puede hacer máximo 4 veces en un año y que hacer de nuevo una habilidad cuenta como repetición.

Escucha, lectura, producción oral o producción escrita.

Calendario 2026

| Fecha | Hora | Fecha límite de inscripción |
| --- | --- | --- |
| Abril 30 | 1:30 p.m. | Abril 27 |
| Mayo 07 | 1:30 p.m. | Mayo 3 |
| Mayo 14 | 1:30 p.m. | Mayo 11 |
| Mayo 21 | 1:30 p.m. | Mayo 18 |
| Mayo 28 | 1:30 p.m. | Mayo 25 |

**Esta prueba se ofrece todo el año. El calendario es actualizado mes a mes.**

Notificación de resultados

El candidato debe ingresar a la plataforma del Oxford Test of English con el usuario y la contraseña que ya crearon y revisar el resultado 14 días hábiles después de presentado.​

Observaciones

1.   Tenga en cuenta que no habrá lugar a cambios respecto a la sede de presentación del examen.
2.   El día del examen deberá traer su documento de identidad original y una fotocopia del mismo por ambos lados, ampliada al 150%.
3.   La citación a la prueba será enviada por correo electrónico 2 días previos a la fecha del examen.
4.   La edad mínima para tomar el examen es 16 años. Documentos válidos: cédula de ciudadanía, cédula de extranjería, pasaporte, licencia de conducción y tarjeta de identidad en formato nuevo. Si no cuenta con alguno de estos documentos, debe presentar el que tenga que lo reemplace (contraseña o tarjeta de identidad en formato anterior) y otro documento con foto (como carné estudiantil o empresarial).
5.   Encuentra los [términos y condiciones del Oxford Test of English aquí](https://universidadeafit.widen.net/s/w6blh96lhm/terminos-y-condiciones-ote-2025).​
6.   Este examen podrá ser aplazado con tres días de anterioridad a la fecha programada. En ambos casos el personal de inscripciones comunicará el cambio realizado a los candidatos inscritos y las fechas en las que podrá tomar el examen.

###### Preguntas frecuentes

​​​Conoce nuestros protocolos e información general sobre nuestro Testing Center.

1.   Estudiantes que desean ingresar y/o egresar en una institución de educación superior.
2.   Estudiantes en proceso de admisiones y/o egreso del programa de aprendizaje del idioma inglés.
3.   Candidatos que desean presentarse para obtención de becas y certificaciones.
4.   Alumnos de diferentes programas de aprendizaje en idiomas, que desean controlar su progreso.
5.   Estudiantes y trabajadores que solicitan visas.
6.   Empresas y/o instituciones que requieran comprobar la suficiencia en idioma durante los procesos de selección de personal, analizar y certificar el nivel de inglés de sus empleados, hacer un seguimiento de la efectividad de los programas de formación lingüística, evaluar a sus empleados con vistas a ascensos o cargos en el extranjero.​

¿Quieres o te exigen presentar un examen de nivel de inglés, pero no sabes cuál es el adecuado para ti? ¿cuál es la diferencia entre uno y otro de tantos existentes en el mercado? ¿existe algún examen que me diagnostique mi nivel antes de decidir presentar un examen oficial?

La información a continuación puede orientarte un poco y llevarte a tomar la decisión más adecuada para tus necesidades.​

​Una diferencia importante entre todos los exámenes existentes es la validez de los resultados. Dicha validez está sujeta a las políticas y reglamentos de la institución académica, empresa, embajada, etc. solicitante de la prueba. Todas las instituciones son libres de aceptar el o los exámenes que mejor se adecuen a sus reglamentos internos.

Por ejemplo, los exámenes **IELTS y TOEFL** suelen ser más convenientes para los visados, trabajos o solicitudes de admisión universitaria que tengan como requisito de aceptación la posesión de un determinado nivel de inglés.

Exámenes como el **TOEIC, APTIS, TRACK TEST y Oxford Test of English​**son exámenes de inglés cuya novedad es la flexibilidad que aporta al poder evaluar de forma independiente una, dos, tres o todas las competencias del idioma. Estos exámenes son altamente aceptados en las universidades de Colombia.​

Ten en cuenta que cada examen tiene un proceso de inscripción diferente ,el cual varía dependiendo de la casa matriz del mismo.

Los tiempos de entrega también varían dependiendo de las políticas internas del ente oficial del examen. Ten presente el tiempo para tu examen de preferencia.

APTIS

CELPE-BRAS

DELE

IELTS

OTE

PLIDA

TOEFL

TOEIC

TRACK TEST 4 COMPETENCIAS

TRACK TEST COMPRENSIÓN LECTORA

5 días hábiles

4 meses

4 meses

7 días hábiles

15 días hábiles

4 meses

7 días hábiles

15 días hábiles

8 días hábiles

8 días hábiles

| Examen | Valor |
| --- | --- |
| Track Test 4 Competencias presencial | $ 380.000 |
| Track Test 4 Competencias virtual | $ 430.000 |
| Track Test Comprensión Lectora | $ 275.000 |
| Repetición Track Test presencial | $ 185.000 |
| Repetición Track Test virtual | $ 233.000 |
| Aptis for Teachers | $ 412.500 |
| Aptis for Teachers docentes EAFIT | $ 320.000 |
| Aptis General | $ 412.500 |
| Oxford Test of English | $ 486.000 |
| Oxford Test of English una sola habilidad | $ 204.000 |
| TOEFL | $256 dólares |
| IELTS | $ 1.045.700 |
| PLIDA | $ 770.000 |
| CELPE-BRAS | $ 504.000 |

_*Ten en cuenta que estos precios pueden variar en función de tu ubicación y están sujetos a cambios._

**Valores de exámenes de otros idiomas diferentes al inglés a través de nuestra página web.**

​Días antes de presentar la prueba, te llegará un correo electrónico con la citación oficial al examen y las instrucciones que debes seguir para presentarlo.

Para todos, siempre deberás presentar tu documento de identidad ORIGINAL.

Dependiendo si tu examen es a lápiz o a computador deberás traer implementos tales como: lápiz mina # 2, borrador, sacapuntas, lapicero negro.​

**Acceso peatonal:** por la portería de Argos, Las Vegas e Idiomas.​

**Acceso vehicular:** p la portería sur sobre la Avenida las Vegas después de Macrollantas, la del Plástico y del Caucho sobre la Av. Regional y la de Idiomas.

**Acceso de motocicletas:** por la portería sur sobre la Avenida las Vegas después de Macrollantas y la de Idiomas.

Debes tener en cuenta que el pico y placa también rige dentro de la Universidad.

**Valor parqueadero carros** $ 6.000 el día

**Valor parqueadero motos** $ 3.000 el día​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)