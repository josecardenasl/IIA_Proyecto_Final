# Laboratorio Visual/ Eye Tracker - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Laboratorio Visual/ Eye Tracker

*    Laboratorio Visual/ Eye Tracker 

​​​​​​​​​​​​​Es un espacio dedicado a la investigación y análisis de las dinámicas de percepción visual de los consumidores, mediante el uso de sistemas de seguimiento de la mirada, que permiten registrar y analizar cómo las personas miran y procesan información visual en diversas situaciones. ​

###### Herramientas del laboratorio visual:

**Eye tracker fijo:** Permite el análisis detallado de cómo las personas miran y procesan elementos visuales en imágenes, videos y la usabilidad de sitios web. Esto puede ser valioso para optimizar el diseño y la presentación de productos y servicios.

**Eye tracker Móvil:** Esta herramienta se utiliza en situaciones como puntos de venta, y ubicaciones de productos en estanterías o góndolas. Permite estudiar cómo los consumidores interactúan con productos y cómo se orientan visualmente en entornos comerciales. También es útil para evaluar la usabilidad de productos y la percepción del consumidor en el mundo real.​

###### Acerca del laboratorio visual

###### Gal​ería

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)