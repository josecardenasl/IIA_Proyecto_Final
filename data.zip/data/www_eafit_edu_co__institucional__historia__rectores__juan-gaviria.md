# Juan Felipe Gaviria Gutiérrez - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Juan Felipe Gaviria Gutiérrez

(Rector entre ​1996​-2003)​

*    Juan Felipe Gaviria Gutiérrez 

**En enero de 1996, Juan Felipe Gaviria Gutiérrez, ingeniero civil de la Universidad Nacional, fue nombrado como rector. Y, desde ese momento, propuso varias transformaciones, empezando por la aprobación de nuevos estatutos en el Consejo Superior.​**

Amplió, además, la oferta académica de la Universidad, no sólo en el número de programas, sino en la incursión a nuevas áreas del conocimiento. Así surgieron, entonces, los pregrados en Música, Derecho, Ingeniería Matemática, Ingeniería Física, Comunicación Social y Ciencias Políticas.​

Y esa diversificación también se hizo palpable en el área de posgrados con la creación de programas como la maestría en Ciencias de la Administración que se creó en convenio con la Escuela de Altos Estudios Comerciales (HEC) de Montreal. A su vez, esta alianza sirvió de preámbulo para la creación del doctorado en Administración, que fue el primero en el país.

Entre otros logros de su rectoría están la creación de la Escuela de Ciencias y Humanidades y el impulso a la investigación con la inclusión de los grupos existentes en el escalafón creado por Colciencias.

Para continuar con procesos anteriores, asumió la tarea de seguir con la consolidación de la política de autoevaluación de programas que condujo a EAFIT a obtener, no solo la acreditación de sus pregrados, sino la Acreditación Institucional en 2003.

Por otro lado, se dio a la tarea de convertir EAFIT en una “universidad pública”, esto bajo la premisa de “una Universidad de todos: una Universidad que encuentra su razón de ser en la comunidad”, así se le dieron continuidad a los procesos de creación de becas para estudiantes de bajos recursos económicos.

En el campo cultural los avances también fueron evidentes con la creación de la Orquesta Sinfónica y el Fondo Editorial, todo esto con el fin de abrir aún más las puertas de la EAFIT a la comunidad y convertir su campus en un espacio para la propagación de diversas posiciones ideológicas y culturales.

Luego de hacer realidad muchos de sus proyectos, Juan Felipe Gaviria Gutiérrez presentó su renuncia en 2003 para ocupar la gerencia de las Empresas Públicas de Medellín.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)