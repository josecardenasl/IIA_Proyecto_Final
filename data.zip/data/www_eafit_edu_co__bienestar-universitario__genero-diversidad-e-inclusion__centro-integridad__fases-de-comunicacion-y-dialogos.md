# Fases de comunicación y diálogos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Fases de comunicación y diálogos

*    Fases de Comunicación y Diálogos 

## ​Primera fase: Culto a la viveza ​

​​​​​​​​​​​​​​​​​​​El culto a la viveza es un fenómeno con el que conviven los colombianos día a día. Se manifiesta en diversos contextos: la manera agresiva al conducir para pasarse al otro, la compra y venta de películas piratas, la evasión de impuestos por parte de personas naturales y jurídicas, la actitud ventajosa en los negocios, la compra y venta de artículos de contrabando, el tratar de meterse en una fila, la utilización de influencias para conseguir permisos, contratos o puestos de trabajo, el soborno en sus múltiples formas: dinero, en especie, cambio de favores, entre muchos otros.

##### Conferencia central: Culto al avispado

##### Opiniones de algunos estudiantes y profesores​

###### Glosario a la viveza​

Sonia López Franco y Fernando Mora Meléndez, docentes del Departamento de Humanidades de la Universidad, reconocen que el culto a la viveza también se evidencia en expresiones que se han enquistado en la cultura colombiana y antioqueña.

“Son consignas sociales que se van imponiendo con el uso, se vuelven normales y con el paso del tiempo van reflejando una ideología”, afirma Sonia. A esas palabras, en lingüística, se les da el nombre de superordenadores.

Ambos académicos definen algunas de estas expresiones.​

Abeja

​Persona minuciosa para hacer la trampa, se toma el tiempo de pensarla y es cautelosa, precisa y perspicaz para cumplir su cometido. Ejemplo: que man tan abeja.

Avión

​Aunque no siempre es un término negativo, el avión es como un avispa’o, pero en algo más específico. Ejemplo: es un avión para los negocios.

Avispa’o

​Podría considerarse un sinónimo de vivo, con la salvedad de que está aceptado socialmente. Es aquel que logra salir adelante, pero no tiene límites morales. Ejemplo: una madre le puede decir a su hijo: “Tienes que ser más avispa’o”.

Bajar

​Robar descaradamente y sin vergüenza. La persona que lo comete no tiene escrúpulos y se siente con derecho a robar porque cree que el que tiene le sobra. Ejemplo: le bajé el celular.

Banquiar

​Quitar o desplazar a alguien de un puesto o lugar. El que banquea generalmente es más fuerte, pero usa su fuerza de manera irrespetuosa. Dentro de las empresas es un término asociado con una práctica de hipocresía. Ejemplo: estoy detrás de ese cargo, lo quiero banquiar.​

Cañero

​El cañero abusa de las máximas de cantidad y calidad en las conversaciones. Habla más de la cuenta y no todo lo que dice es cierto. Es un presumido.

Comer cuento

​Hace referencia a la ingenuidad social, a dejarse engatusar con las palabras y prestarle más atención a la persona que está hablando que a lo que realmente está diciendo.​

Coronar

​Puede tener ambas connotaciones, tanto positiva como negativa. Pues podría usarse para decir que se alcanzó un objetivo muy difícil, o para referirse a un hecho delictivo. Ejemplos: coroné la tesis o coroné ese robó.

Cruce o catorce

​Aunque inicialmente se le dio un uso negativo para referirse a un favor ilícito del que nadie podía enterarse, en la actualidad se ha vuelto tan cotidiano que muchos adolescentes lo usan simplemente para solicitar una ayuda.

CVY (Cómo voy yo)

​Término usado por el cómplice de algún hecho, o una persona que no hizo un gran esfuerzo en determinada situación y quiere reclamar una parte. Ejemplo: ¿cómo voy yo en ese trabajo de la Universidad?, ¿me va a anotar?

Dar papaya

​Es ofrecerle la posibilidad de ser engañado o traicionado a alguien que tiene habilidad para estafar o causar perjuicios.

Flecha

Es un contacto. Una persona que consigue cualquier cosa que alguien necesite, viola las normas institucionales y morales, y por supuesto, cobra por ese tipo de favores. Ejemplo: tengo una flecha en esa oficina para que no tengamos que pagar la multa.

Gato

​Tiene un significado negativo. Se utiliza generalmente para referirse a un ladrón muy astuto.

Guardado

​Sinónimo de ‘tapa’o’. Un dato que no se puede hacer público y que obliga a los que lo conocen a convertirse en cómplices.

La tajada

​Es un beneficio, la parte del botín con la que se queda uno de los involucrados. Por lo general este término es asociado al terreno de la política.

Liga

​Soborno o dinero que se le suministra a alguien para ocultar algún hecho, situación o dato que no debe ser conocido. Ejemplo: le di la liga al guarda para que no me partiera

Llevarse el mundo por delante

​Expresión común entre los más jóvenes que refleja cierto grado de terquedad. El individuo no se da cuenta de lo que pasa y sigue avanzando hacia su meta sin importarle los daños que causa a su alrededor.

Marrano

​Se usa para definir a una persona ingenua y que se deja engañar fácilmente. Existen un sinnúmero de expresiones para identificar a esta persona como: “Es el bobo del paseo”, “el que lleva del bulto de la rume”, “el tumba’o”, “el que siempre da papaya”.

Meter cuento

​Hacer uso del lenguaje y sus habilidades comunicativas para conseguir objetivos personales o persuadir a alguien de manera negativa.

Meter un gol

​Lograr un cometido sin mucho esfuerzo. Ejemplo: gané el parcial y ni siquiera estudié. ¡Metí un golazo!

Paisa

​El mismo gentilicio de los antioqueños se ha convertido en ocasiones, en sinónimo de viveza, de robo o de sacar ventaja, y eso se refleja en los chistes y comentarios cotidianos.

Rosca

​Generalmente es una palabra asociada al dicho “es mejor estar en la rosca”, que hace alusión a conseguir beneficios sin haber hecho nada para merecerlos. Ejemplo: no hice la fila porque tengo rosca.

Sapo

​Es un delator. Algunos lo hacen con buenas intenciones y otros, en cambio, para sacar beneficios o quedar bien ante alguien.

Tapa’o

Algo que debe mantenerse oculto entre cómplices, y que al evitar que no salga a la luz, beneficia a las partes involucrados. Su uso casi siempre es negativo. Ejemplo: entre esos dos hay un tapa’o.

Torcido

​Es un traidor. Una persona que traiciona al resto de cómplices en determinado asunto ilícito, se ganaría el calificativo de ‘torcido’.

Tumbar

​Engañar, estafar o robar con inventos y artimañas ingeniosas, como el “paquete chileno”.

Ventajoso

​Es el que saca partida de todo, se aprovecha de las situaciones y tiene una habilidad clara para sacar beneficios en momentos de crisis.

Vivo

​Es aquel que con astucia logra lo que se propone, sin importarle el medio o los fines, solo su beneficio propio. Ejemplo: tan vivo que se robó ese dinero y nadie se dio cuenta.

#### ​Segunda fase: Ética y academia ​

#### Ética y academia, una relación indisoluble

Con el dicho popular “el vivo vive del bobo” y la frase pronunciada por Miguel Nule “la corrupción es inherente al ser humano” comenzó el 18 de julio de 2011 la primera fase del proyecto Atreverse a Pensar, liderado por el Departamento de Comunicación y Cultura de la Universidad EAFIT y dedicada al culto a la viveza.

A continuación prosiguieron frases como “las cosas no son del dueño sino del que las necesita“, “es mejor estar en la rosca que no estar en ella“, “yo no lo tumbé, él se cayó solo” y “ah…es que dio papaya“. Ahí inició la reflexión sobre un sistema de creencias y unos valores arraigados en los colombianos que la Universidad EAFIT considera le han hecho mucho daño a la sociedad y por eso quiere invitar a que nos preguntemos si valdría la pena replantear esos paradigmas y, a lo mejor, proponer unos nuevos basados en la ética, la responsabilidad y la integridad.

En cafeterías, en aulas de clase, en los cines foros y en algunos medios de comunicación se inició la reflexión sobre temas grandes como la corrupción, la deshonestidad y la llamada malicia indígena, entre otros, que han justificado tantos negocios turbios, contratos ilícitos y comportamientos inmorales a todos los niveles. El no seguir indiferentes ante tantas realidades que nos deberían avergonzar como sociedad fue el objetivo de esta primera fase del proyecto, y con satisfacción la Universidad ve cómo, en efecto, nos atrevimos a pensar.

La Universidad EAFIT es la primera universidad colombiana y la segunda en Latinoamérica, luego del Tecnológico de Monterrey, en ser miembro del Centro Internacional de Integridad Académica, que reúne alrededor de 200 universidades de todo el mundo.

##### Conferencia central: ¿Por qué hacemos trampa?

##### ​​​​Opiniones de algunos estudiantes y profesores​​

#### ​Ética y academia, una relación indisoluble​

Con el dicho popular “el vivo vive del bobo” y la frase pronunciada por Miguel Nule “la corrupción es inherente al ser humano” comenzó el 18 de julio de 2011 la primera fase del proyecto Atreverse a Pensar, liderado por el Departamento de Comunicación y Cultura de la Universidad EAFIT y dedicada al culto a la viveza.

A continuación prosiguieron frases como “las cosas no son del dueño sino del que las necesita“, “es mejor estar en la rosca que no estar en ella“, “yo no lo tumbé, él se cayó solo” y “ah…es que dio papaya“. Ahí inició la reflexión sobre un sistema de creencias y unos valores arraigados en los colombianos que la Universidad EAFIT considera le han hecho mucho daño a la sociedad y por eso quiere invitar a que nos preguntemos si valdría la pena replantear esos paradigmas y, a lo mejor, proponer unos nuevos basados en la ética, la responsabilidad y la integridad.

En cafeterías, en aulas de clase, en los cines foros y en algunos medios de comunicación se inició la reflexión sobre temas grandes como la corrupción, la deshonestidad y la llamada malicia indígena, entre otros, que han justificado tantos negocios turbios, contratos ilícitos y comportamientos inmorales a todos los niveles. El no seguir indiferentes ante tantas realidades que nos deberían avergonzar como sociedad fue el objetivo de esta primera fase del proyecto, y con satisfacción la Universidad ve cómo, en efecto, nos atrevimos a pensar.

Fue en septiembre de 2011, que inició una nueva etapa que se concentró en la ética y la academia, una relación que por la naturaleza y la responsabilidad del acto educativo en la universidad debería ser armoniosa pero que, lamentablemente, se rompe con bastante frecuencia. Ahora, ¿qué tiene que ver el culto a la viveza con el fraude académico? Todo.

Atreverse a Pensar parte desde su concepción de que quien es capaz de quebrantar la norma en lo pequeño se verá más fácilmente tentado a quebrantar la norma en lo grande. Cuando el individuo no tiene una moral sólida que respalde la importancia del cumplimiento a la norma, ya sea por el mero placer de actuar rectamente (profunda conciencia sobre lo ético), por el temor a sentirse mal después (la culpa) o por temor a las consecuencias legales (relación con la autoridad), es muy factible que cometa actos que irán en contra de lo moral, cultural o legalmente aceptable.

En ese sentido, la deshonestidad mirada desde el ámbito universitario se presenta con el fraude académico, práctica que infortunadamente ha venido en franco crecimiento en el mundo. Por ejemplo, el fraude académico se ha venido estudiando con gran interés en Estados Unidos en las últimas dos décadas. Como lo plantea Deborah Meizlish (i), consultora de la Universidad de Michigan, “nacionalmente ha habido gran atención pública sobre la integridad académica y profesional. Casos de plagio de alto nivel en la academia y el periodismo han atraído la atención de los medios de comunicación al igual que las investigaciones realizadas en varios campus que revelan que muchos estudiantes reportan comportamiento académico deshonesto".

En diversos estudios realizados en ese país del Norte se concluye que mientras un 23 por ciento de los estudiantes cometía fraude en sus universidades en 1941, estudios de 2006 mostraban un ascenso al 80 por ciento.

Colombia, por supuesto, no es la excepción a esta problemática mundial. En el libro Normas de papel editado por Mauricio García Villegas (ii), se afirma que “la cultura del fraude académico sigue estando profundamente arraigada en la mentalidad de los estudiantes colombianos, desde el bachillerato. Esto se debe, en parte, a que las instituciones educativas han visto este tema como una simple violación del reglamento académico, y no como una práctica con hondas raíces pedagógicas y culturales”.

También coinciden los expertos en que el acceso a las tecnologías de la información ha agravado el problema del fraude, específicamente en lo concerniente al plagio académico. En este caso, las prácticas más frecuentes son copiar y pegar párrafos enteros de Internet sin citar la fuente, parafrasear lo que otro dijo sin dar el crédito a quien produjo ese conocimiento y bajar trabajos enteros de la web y firmarlos como propios. En estudios realizados en más de 30 universidades en Estados Unidos entre 1984 y 1998 se concluye que entre un 75 y un 98 por ciento de los estudiantes ha incurrido, por lo menos, una vez en fraude académico (García Villegas).

En cuanto a las otras prácticas de fraude en las universidades, las más comunes son copiar y dejar que le copien en exámenes, incluir o que lo incluyan en un trabajo en el que la persona no participó y prestar un trabajo. Aunque menos común, también se encuentran la presentación de certificados médicos falsos y la suplantación en pruebas.

¿Qué hacer frente a este grave fenómeno del que, por lo visto, no se escapa ninguna universidad?, ¿cómo seguir graduando estudiantes que mienten sobre su conocimiento?, ¿cuál es el papel de la institución, del docente y del estudiante en el fraude académico?, ¿debe ser esta una reflexión moral o legal?, ¿se podrán encontrar soluciones desde la transformación de la cultura o se tratará de aumentar las sanciones? Son todas estas preguntas difíciles de responder.

**Atrevámonos a pensar. La discusión está abierta.**

(i) Meizlish, Debora. 2005 “Promoting Academic Integrity in the classroom”, en CRTL Occasional Papers, University of Michigan, No. 20.

(ii) García, Villegas Mauricio. 2009. Normas de papel. Bogotá: Siglo del Hombre Editores.​

#### ​Segunda fase: Ética y academia ​

El proyecto Atreverse a Pensar llega a su tercera fase: cultura ciudadana, entendida esta como el conjunto de costumbres, acciones y reglas mínimas compartidas que generan sentido de pertenencia, facilitan la convivencia urbana y conducen al respeto del patrimonio común, y al reconocimiento de los derechos y deberes ciudadanos.

En su primera fase, Atreverse a Pensar abordó el tema del culto a la viveza, que se fundamenta en ese sistema de creencias y valores que premia el camino fácil, la actitud ventajosa y la costumbre de ganar a costa de lo que sea. En esa fase, se expusieron mensajes que, a través de dichos populares, abrieron la reflexión entre la comunidad eafitense.

#### ¿Pueden las sociedades realmente transformarse?

#### Conferencia central: ¿Pueden las sociedades realmente transformarse?

#### Eso de ser ciudadano es algo que se puede aprender​

#### Cultura ciudadana

​

El proyecto Atreverse a Pensar llegó a su tercera fase: cultura ciudadana, entendida esta como el conjunto de costumbres, acciones y reglas mínimas compartidas que generan sentido de pertenencia, facilitan la convivencia urbana y conducen al respeto del patrimonio común, y al reconocimiento de los derechos y deberes ciudadanos.

En su primera fase, Atreverse a Pensar abordó el tema del culto a la viveza, que se fundamenta en ese sistema de creencias y valores que premia el camino fácil, la actitud ventajosa y la costumbre de ganar a costa de lo que sea. En esa fase, se expusieron mensajes que, a través de dichos populares, abrieron la reflexión entre la comunidad eafitense.

Más adelante, el proyecto mostró cómo esos actos contrarios a la ética y a la integridad se manifiestan en el ámbito universitario con la deshonestidad académica. Copiar en un examen, bajar un trabajo de internet, presentar una excusa médica falsa o, incluso, pagarle a alguien para que presente una prueba (suplantación), son algunas de las modalidades que, lamentablemente, se ven en la mayoría de las universidades del mundo. Sobre todos estos asuntos, estudiantes y docentes se atrevieron a pensar.

La tercera fase, que se realizó de marzo a junio de 2012, se enfocó en la cultura ciudadana. Una vez reconocido el discurso dominante del culto a la viveza e identificada la manera en que puede hacer daño a una sociedad, se encontró el modo en que esas pequeñas o grandes faltas éticas en el ámbito académico hacen parte de ese mismo sistema donde se incumple la norma con mucha frecuencia, sin que en muchos casos haya consecuencias graves, precisamente por la astucia con la que las partes involucradas actúan.

El modelo de cultura ciudadana, mirado desde la perspectiva del matemático y filósofo Antanas Mockus (i), es la vía que Atreverse a Pensar propone para promover el cumplimiento de reglas, en este caso de integridad académica, pero también de convivencia y de ética en todas las áreas en las que se desenvuelve el ser humano.

Los resultados contundentes de las dos administraciones de Mockus en Bogotá en disminución de muertes violentas en accidentes de tránsito, el ahorro voluntario de agua en tiempos de racionamiento, el incremento en la recaudación de impuestos y un mayor sentido de pertenencia con la ciudad, entre otros asuntos, dan cuenta de que el modelo de cultura ciudadana puede funcionar.

Según el artículo 7 de su plan de desarrollo (ii), cuyo eje transversal fue la cultura ciudadana, la estrategia consistió en “desencadenar y coordinar acciones públicas y privadas que incidieran directamente sobre la manera como los ciudadanos perciben, reconocen y usan los entornos sociales y urbanos y cómo se relacionan entre ellos en cada entorno. Pertenecer a una ciudad es reconocer contextos y en cada uno de estos respetar las reglas correspondientes. Apropiarse de la ciudad es aprender a usarla valorando y respetando su ordenamiento y su carácter de patrimonio común”.

Si se hace el ejercicio de trasladar esta estrategia, no ya a la ciudad sino a la Universidad, tiene sentido pensar que se podría llegar a un estadio de respeto de normas que constituiría un gana-gana para los diferentes actores involucrados: la Universidad cumpliría con su objetivo de garantizar una formación académica y humana de excelencia en sus estudiantes; los docentes sentirían el respaldo de un sistema que promueve la rectitud y el justo reconocimiento del logro; y finalmente, los estudiantes, por un lado, tendrían más legitimidad para exigir ambientes de aprendizaje propicios y excelentes, y por el otro, se desenvolverían en un espacio de respeto y cooperación en el campus universitario.

Antes de examinar en detalle el modelo de cultura ciudadana, conviene examinar también qué es lo que lleva a una persona a elegir el camino de lo virtuoso y no de lo vicioso para poder comprender el reto a que estamos enfrentados.

La filósofa Adela Cortina, una de las mayores estudiosas contemporáneas de la ética y la moral, afirma que debe haber un impulsor que lleve a que el individuo opte por el bien o la acción correcta o ética desde una profunda convicción. “El sentido profundo de la moral civil descansa, pues, en unos valores compartidos, que por verdaderos hemos aceptado explícitamente un buen número de sociedades, sin dejar un resquicio de posible acierto al hipotético contrario… La moral civil descansa en la convicción de que es verdad que los hombres son seres auto legisladores, que es verdad que por ello tienen dignidad y no precio, que es verdad que la fuente de normas morales solo puede ser un consenso en el que los hombres reconozcan recíprocamente sus derechos, que es verdad, por último, que el mecanismo consensual no es lo único importante en la vida moral, porque las normas constituyen un marco indispensable, pero no dan la felicidad. Y los hombres — esto también es verdad— tienden a la felicidad” (iii), sostiene Cortina.

De esta manera, Cortina hace una diferenciación entre los mínimos éticos y los máximos éticos, que servirán como punto de referencia para no perderse en la mirada del problema: “Lo moral abarca, ciertamente, el terreno de las normas de la moral civil, pero estas —no lo olvidemos— tienden a ser positivadas y a convertirse en derecho. Así se va constituyendo, poco a poco, ese cuerpo de normas acordadas, ese mínimo de leyes consensuadas, plasmadas en normas positivas, que constituyen las reglas de juego de la vida ciudadana. Pero los proyectos morales, las concepciones de hombre, son propuestas de máximos: bosquejan ideales de hombre y de felicidad desde el arte, las ciencias y la religión; desde esa trama —en suma— de tradiciones que configuran la vida cotidiana” (iv).

Teniendo en cuenta lo anterior, la pregunta clave es cómo lograr que las personas, en este caso quienes componen la comunidad eafitense, cumplan las normas (de todo tipo: académicas, administrativas, de convivencia, etc.) y lo hagan con convicción. Y es ahí donde el modelo de cultura ciudadana puede darnos unas pistas.

El modelo de cultura ciudadana parte de la base de que lo que genera una verdadera transformación cultural es la armonía entre lo legal, lo social y lo moral. Es decir, para que haya un fructífero acatamiento de normas que redunde en una sociedad más desarrollada, equitativa y próspera debe haber, primero, un sistema que vele por el cumplimiento de la ley; segundo, un entorno donde las acciones rectas se estimulen y se reconozcan y las equívocas se sancionen socialmente; y por último, un nivel de consciencia lo suficientemente crítico que le permita al individuo tener claro cuando actúa correcta o incorrectamente, y sentir gratificación o vergüenza, según sea el caso.

Específicamente, en el ámbito universitario, se podría aplicar el concepto de cultura ciudadana a las dos realidades abordadas por el proyecto: la del sistema de creencias que desencadena unas actitudes y unas acciones del individuo como ciudadano, que se viven tanto fuera como dentro del campus universitario. En un segundo sentido, esa armonía entre los sistemas legal, social y moral también puede ser la salida a la deshonestidad académica. Así, por ejemplo, quien incurra en fraude se enfrentaría a tres realidades: la de un reglamento académico (lo legal) que lo sanciona académica y/o disciplinariamente, dependiendo de la falta; a una sanción social (lo cultural) por parte no solo de su profesor sino de sus compañeros; y a una culpa (lo moral) que le hace sentir avergonzado por haber tomado el camino del menor esfuerzo.

El modelo de cultura ciudadana requiere de una decisión institucional y de una convicción de un grupo de individuos que promuevan la autorregulación en quienes integran una comunidad, en este caso la eafitense. También, es necesario el conocimiento por parte de todos los grupos de interés (profesores, estudiantes, empleados administrativos, proveedores, egresados, etc.) de las normas administrativas y académicas que rigen la Institución: es difícil cumplir lo que se desconoce.

Por supuesto, es inminente un trabajo de comunicación y sensibilización permanente, para que se vaya instaurando en los eafitenses un nuevo relato dominante (sistema de creencias y valores), que reemplace al del culto a la viveza. Un sistema en el que el esfuerzo sea premiado, la participación promovida, el pluralismo celebrado, la excelencia reconocida y la integridad apreciada. Un sistema en el que los mediocres y los vivos se sientan incómodos, y los dedicados y honestos encuentren su espacio. Un lugar para aprender, para crecer, para enseñar, para ganar con esfuerzo, para participar abierta y respetuosamente, para innovar, para lograr un desarrollo académico y ético tan sólido que le permita al individuo destacarse por su responsabilidad, tolerancia, integridad, audacia y excelencia donde quiera que se desempeñe como estudiante, como docente, como profesional. Una sumatoria de esos individuos necesariamente redundará en una sociedad más justa y desarrollada.

--------------------------------------------------------------------------------------------------

**(i). Alcalde de Bogotá D.C Periodos 1995-1998 y 2001-2003.**

**(ii) Decreto 295 de 1995. Título II. Capítulo I Cultura Ciudadana. Artículo 7 Estrategia para la Cultura Ciudadana. Bogotá, Distrito Capital.**

**(iii) Cortina, Adela. Ética mínima, introducción a la filosofía práctica. Sexta edición, 2000.**

**(iv) Ibídem.​**

#### ​Segunda fase: Ética y academia ​

La Universidad EAFIT, en 2012, decidió apostar por la transformación cultural de la comunidad universitaria a través de la definición de Atreverse a Pensar como un programa institucional permanente “orientado a la prevención y erradicación de cualquier forma de fraude académico o administrativo, y a garantizar el pleno respeto de los derechos de autor por parte de estudiantes y profesores, en todas las actividades académicas” (i)

Como programa permanente, Atreverse a Pensar apuesta por la reflexión sobre la ética a una nueva generación de profesionales íntegros que sean capaces de preguntarse y auto cuestionarse por la realidad que enfrenta la sociedad, en la que priman antivalores como la apatía, la ley del menor esfuerzo, la mentira o el desprestigio.

Ramin Jahanbegloo, filósofo político iraní 25 de septiembre de 2013

#### Conferencia ¿Una vida ideal, perfecta o mediocre? Ser mejor un camino de excelencia moral

#### La invitación es a ser mejor

La Universidad EAFIT, en 2012, decidió apostar por la transformación cultural de la comunidad universitaria a través de la definición de Atreverse a Pensar como un programa institucional permanente “orientado a la prevención y erradicación de cualquier forma de fraude académico o administrativo, y a garantizar el pleno respeto de los derechos de autor por parte de estudiantes y profesores, en todas las actividades académicas” (i)

Como programa permanente, Atreverse a Pensar apuesta por la reflexión sobre la ética a una nueva generación de profesionales íntegros que sean capaces de preguntarse y auto cuestionarse por la realidad que enfrenta la sociedad, en la que priman antivalores como la apatía, la ley del menor esfuerzo, la mentira o el desprestigio.

El debate que propone el programa, a partir del segundo semestre de 2013, debe trascender de los escenarios comunes como los son las aulas de clase o los lugares de trabajo, para dar cabida a exhortaciones más profundas. Las actitudes y posiciones frente a vicios sociales como la deshonestidad, el fraude o la corrupción deberían ser la consecuencia de un conjunto de preguntas internas sobre el hacer, el ser y el deber ser.

El actuar mal en la empresa, cometer fraude en el examen o aceptar un soborno es, solamente, el resultado de una concepción preconcebida e interiorizada. Mirar al compañero en un examen, hablar mal de alguien en un grupo o preferir el dinero fácil responde a comportamientos que se han validado internamente y que, aunque en ocasiones las personas reconocen que son éticamente incorrectos, se prefiere el resultado al proceso, la nota al aprendizaje o el negocio a la organización.

La realidad muestra constantemente que saltarse la norma trae más beneficios que consecuencias. En un país como Colombia, donde el gran delincuente siempre tendrá la posibilidad de cambiar el sistema a su favor mientras que el ciudadano que se pasa un semáforo en rojo tiene una pena ejemplarizante, la ilegalidad se va interiorizando a una esfera personal en la que la reflexión sobre el individuo como ser ético, queda rezagada.

Sin embargo, el problema no radica en el sistema. En parte no lo es. El problema nace cuando los seres humanos se acostumbran a esta constante social. Las personas se han dedicado a la creación y validación de espacios donde el que hace trampa sobresale frente al que es honesto; en la sociedad se critica al ciudadano cuando hace una reflexión ética, pero se enaltece al que se salta la norma porque va en contra de los políticos corruptos, por ejemplo cuando no paga impuestos.

En este sentido, el dilema ético que propone Atreverse a Pensar es una invitación a reflexionar sobre la excelencia y la perfección. Este objetivo se aborda a partir de la nueva fase del componente comunicacional denominada: Ser Mejor.

En esta fase se propone que los miembros de la comunidad universitaria busquen no ser solo buenos trabajadores para tener una mejor condición económica o ser los mejores estudiantes con un alto promedio académico, sino que sean mejores: mejores profesionales, mejores ciudadanos, mejores seres humanos.

El 12 de marzo de 2013 en el periódico El País, de España, el columnista iraní Ramin Jahanbegloo (ii) plantea que para ser felices debe existir un equilibrio entre excelencia, moral y rectitud. Es claro que la felicidad no radica en tener un gobierno transparente o en tener acceso económico a una gran variedad de posibilidades, sino a la capacidad de retarse personalmente para ser mejores, lo demás será una consecuencia de ese ideal propio, de esa lucha personal por ser mejor.

Esa condición superior no es discriminatoria, sino alentadora. Ser mejor no es tener mejores calificaciones, ni mucho menos tener un cargo de director en una empresa multinacional. Ser mejor es una condición ambiciosa para el mundo en el que se vive, pero no imposible. Es un compromiso a la integridad, a la excelencia, a la disciplina. Pero no es un compromiso con el otro, sino un compromiso propio como resultado de una convicción que vuelque la reflexión a la individualidad de cada persona.

Esta es la propuesta del programa Atreverse a Pensar para 2013. Atreverse a pensar en la concepción personal sobre el actuar con excelencia en el papel como ciudadano, como estudiante, como miembro de una familia, como docente o, simplemente, como ser humano. La invitación es que con esta reflexión, la comunidad universitaria logre repensarse frente a su actuar en comunidad, en un compromiso propio con la excelencia, en la que la integridad académica y el mejoramiento en los procesos ciudadanos y académicos sean la consecuencia de una nueva percepción individual.

--------------------------------------------------------------------------------------------------

**(i) Universidad EAFIT, Consejo Superior. Declaración De Principios de Gobernabilidad y Administración. 2012**

**(ii) http://elpais.com/elpais/2013/02/21/opinion/1361472926_244956.html. Consultado el 12 de junio de 2013.**

#### ​Segunda fase: Ética y academia ​

Durante más de tres años el Programa Atreverse a Pensar ha venido generando una serie de reflexiones en torno al tema de la integridad: cuestionando el culto a la viveza, analizando la relación entre ética y academia, abordando temas sobre cultura ciudadana y pensando cómo podemos ser mejores.

En esta quinta fase abordamos la Integridad Académica, definida por el Centro Internacional de Integridad Académica (1999: 4), al cual la Universidad pertenece, como un compromiso constante frente a la honestidad, la confianza, la justicia, el respeto y la responsabilidad; aún en momentos de adversidad.

En Atreverse a Pensar, estamos convencidos de que desde la academia podemos romper el círculo vicioso que empieza con la deshonestidad académica y desemboca en la ilegalidad. Proponemos una alternativa constructiva, que nos permita la transformación cultural que tanto anhelamos.​

###### Conferencia Construir confianza: construir integridad ​

Tracey Bretag, académica especialista en Integridad en el ámbito educativo y profesora asociada a la Universidad de South Australia.

30 de septiembre de 2014 ​

##### En español

##### En inglés

#### Sexta Fase: Atreverse a Pensar​​

​Ya se puso en marcha la sexta fase de este programa que, desde 2010, promueve las buenas prácticas académicas, la ética, la Integridad y los valores institucionales.

Esta etapa lleva el mismo nombre del programa y está acompañada de seis mensajes dirigidos a toda la comunidad académica que se pueden leer en diferentes puntos del campus.

Una invitación a ser honesto, decir la verdad, cuestionarse, estudiar, esforzarse y abrir los ojos. Esas son las frases que acompañan la nueva fase comunicacional del programa Atreverse a Pensar, que se puso en marcha desde el 22 de julio.

Y es que hay situaciones que se presentan en la vida cotidiana de quienes adelantan algún tipo de estudios que se convierten en dilemas que ponen en riesgo uno de los valores más importantes: la Integridad.

"En esta fase se busca una reflexión para mostrar que esas situaciones que tienen un tinte problemático para la ética académica hay que saberlas resolver, pues muchas veces no nos tocan como estudiantes, sino como amigos y consejeros de otros que pueden estar enfrentándolas", comenta Juan Rafael Peláez Arango, analista de Atreverse a Pensar.

Este año, en el campus de Medellín y en los lugares donde tiene presencia EAFIT se pueden apreciar vallas, carteleras, afiches en los ascensores y rompetráficos con seis mensajes que invitan a reflexionar sobre temas de integridad académica.

Las frases evidencian dilemas morales que se convierten en la oportunidad de crear una conversación, un diálogo consigo mismo o con otros que viven el día a día en la Institución.

Entre estas se encuentran: Poné que dominás el inglés que allá se lo creen; En mi casa ni saben que cancelé esa materia; ¡Ey!, pásame el trabajo que hiciste para esa clase el semestre pasado; Copiá rápido antes de que vuelva a entrar (el profesor); Presentá el examen por mí; y ¡Paguemos para que nos hagan ese trabajo y listo!

"A partir de estas reflexiones, el programa busca generar una discusión y un debate que lleve a que la integridad sea lo que prime, que cada uno analice la importancia de pensar, de atreverse a reflexionar y cuestionar si las decisiones que se toman cada día reflejan lo que queremos ser como individuos", asegura Nathalia Franco Pérez, directora del programa y jefa del Fondo Editorial.

#### ​Ya se puso en marcha la sexta fase de este programa que, desde 2010, promueve las buenas prácticas académicas, la ética, la Integridad y los valores institucionales. Esta etapa lleva el mismo nombre del programa y está acompañada de seis mensajes dirigidos a toda la comunidad académica que se pueden leer en diferentes puntos del campus. Una invitación a ser honesto, decir la verdad, cuestionarse, estudiar, esforzarse y abrir los ojos. Esas son las frases que acompañan la nueva fase comunicacional del programa Atreverse a Pensar, que se puso en marcha desde el 22 de julio. Y es que hay situaciones que se presentan en la vida cotidiana de quienes adelantan algún tipo de estudios que se convierten en dilemas que ponen en riesgo uno de los valores más importantes: la Integridad. "En esta fase se busca una reflexión para mostrar que esas situaciones que tienen un tinte problemático para la ética académica hay que saberlas resolver, pues muchas veces no nos tocan como estudiantes, sino como amigos y consejeros de otros que pueden estar enfrentándolas", comenta Juan Rafael Peláez Arango, analista de Atreverse a Pensar. Este año, en el campus de Medellín y en los lugares donde tiene presencia EAFIT se pueden apreciar vallas, carteleras, afiches en los ascensores y rompetráficos con seis mensajes que invitan a reflexionar sobre temas de integridad académica. Las frases evidencian dilemas morales que se convierten en la oportunidad de crear una conversación, un diálogo consigo mismo o con otros que viven el día a día en la Institución. Entre estas se encuentran: Poné que dominás el inglés que allá se lo creen; En mi casa ni saben que cancelé esa materia; ¡Ey!, pásame el trabajo que hiciste para esa clase el semestre pasado; Copiá rápido antes de que vuelva a entrar (el profesor); Presentá el examen por mí; y ¡Paguemos para que nos hagan ese trabajo y listo! "A partir de estas reflexiones, el programa busca generar una discusión y un debate que lleve a que la integridad sea lo que prime, que cada uno analice la importancia de pensar, de atreverse a reflexionar y cuestionar si las decisiones que se toman cada día reflejan lo que queremos ser como individuos", asegura Nathalia Franco Pérez, directora del programa y jefa del Fondo Editorial.

#### Los eafitenses se atreven a pensar

###### Actividades para todo el semestre

Nathalia también explica que durante el resto del año se desarrollarán algunos encuentros que apoyan esta estrategia.

Uno de estos tendrá ocasión el 7 de octubre con una conversación entre varias personas que tienen conocimientos en diferentes áreas del saber y que harán un debate abierto respondiendo la pregunta ¿Por qué tenemos doble moral?

Así mismo, se hará un concurso en el que estudiantes de pregrado y posgrado realizarán un video de un minuto para resolver esa misma inquietud. Los premios serán bonos de la Librería Acentos y el Fondo

Editorial.

Por su parte, los primíparos tendrán talleres que imparten estudiantes de otros semestres relacionados con este tema. Por último, habrá un espacio audiovisual en el que se proyectará un capítulo de una serie donde se manifiesten dilemas éticos y se hará un foro de discusión en ese sentido.

"Este es un debate que es para nosotros pero que también debe generar un eco y un impacto por fuera de la Institución, para crear una corriente de opinión publica en la ciudad y que el tema coja fuerza. Por eso, la invitación es a que todos hagan uso de estas buenas prácticas desde sus hogares", concluye Juan Rafael.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)