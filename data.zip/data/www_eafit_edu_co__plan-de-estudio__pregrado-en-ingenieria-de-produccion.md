# Pregrado en Ingeniería de Producción - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

![Image 20: Pregrado en Ingeniería de Diseño de Producto, Escuela de Ciencias Aplicadas e Ingeniería.
Estudiantes hacen tareas en talleres de la Universidad.](https://universidadeafit.widen.net/content/dbwfb9rz9c/web/pregrado-ingenieria-dise%C3%B1o-producto%20(2).jpg?crop=yes&k=c&w=1920&h=788&itok=NHk7zfFq)

# Plan de estudios

Pregrado en Ingeniería de Producción

*    Plan de Estudio 
*    Pregrado En Ingeniería de Producción 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas de ciencias básicas 

- [x] Asignaturas disciplinares 

- [x] Básicas en Ingeniería (ECAI) 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Línea de Proyectos 

- [x] Matemáticas y Ciencias Básicas 

- [x] Núcleo de Formación Institucional 

- [x] Prepráctica - Práctica 

- [x] Trayectorias flexibles 

- [x] Trayectorias profesionalizantes 

Semestre 1

Créditos 

totales-

Créditos 0

#### Inducción

Código: BU0010

Inducción y Bienestar Universitario
## Inducción

0 Créditos

0 UMES

Código: **BU0010**

Créditos 1

#### Bienestar Universitario

Código: BU0011

Inducción y Bienestar Universitario
## Bienestar Universitario

 Cancelable 

1 Créditos

1 UMES

La asignatura Bienestar Universitario, por medio de actividades artísticas, deportivas, académicas y de reflexión, facilita la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, contribuyendo a la transición entre el colegio y la Universidad.

Código: **BU0011**

Correquisito Créditos 0

#### Taller de Salud

Código: BU0600

Créditos 0

#### Taller de Salud

Código: BU0600

Inducción y Bienestar Universitario
## Taller de Salud

0 Créditos

0 UMES

Código: **BU0600**

Créditos 3

#### Expresión Gráfica

Código: CI1001

Básicas en Ingeniería (ECAI)
## Expresión Gráfica

3 Créditos

4 UMES

Código: **CI1001**

Créditos 3

#### Proyecto Escuela

Código: CI1002

Básicas en Ingeniería (ECAI)
## Proyecto Escuela

3 Créditos

4 UMES

Código: **CI1002**

Créditos 3

#### Física 1

Código: NC1001

Asignaturas de ciencias básicas
## Física 1

3 Créditos

5 UMES

Código: **NC1001**

Créditos 3

#### Cálculo 1

Código: NM1001

Asignaturas de ciencias básicas
## Cálculo 1

3 Créditos

4 UMES

Código: **NM1001**

Créditos 3

#### NFI - Pensamiento Computacional

Código: FH1002

Núcleo de Formación Institucional
## NFI - Pensamiento Computacional

3 Créditos

UMES

Código: **FH1002**

Créditos 3

#### NFI - Ciudadanía y Democracia

Código: FH1001

Núcleo de Formación Institucional
## NFI - Ciudadanía y Democracia

3 Créditos

UMES

Código: **FH1001**

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas de ciencias básicas 

- [x] Asignaturas disciplinares 

- [x] Básicas en Ingeniería (ECAI) 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Línea de Proyectos 

- [x] Matemáticas y Ciencias Básicas 

- [x] Núcleo de Formación Institucional 

- [x] Prepráctica - Práctica 

- [x] Trayectorias flexibles 

- [x] Trayectorias profesionalizantes 

### **Líneas de énfasis**

Forma profesionales con capacidad para diseñar, mejorar y dirigir las actividades relacionadas con la producción y el flujo de bienes y servicios, a través de la integración de los conocimientos en las áreas de dirección de operaciones y logística en las empresas.

**Las materias que se ven en esta línea de énfasis son:**

**Código:** IP0705

**Nombre de la materia:** Gestión de almacenes

**Créditos:** 2

**UMES:** 3

**Código:** IP0704

**Nombre de la materia:** Gestión de inventarios

**Créditos:** 2

**UMES:** 3

**Código:** IP0702

**Nombre de la materia:** Estrategia de operaciones y logística

**Créditos:** 2

**UMES:** 3

**Código:** IP0703

**Nombre de la materia:** Planeación de ventas y operaciones

**Créditos:** 2

**UMES:** 3

**Código:** IP0706

**Nombre de la materia:** Compras, proveedores y negociación

**Créditos:** 2

**UMES:** 3

**Código:** IP0707

**Nombre de la materia:** Gerencia de proyectos

**Créditos:** 2

**UMES:** 3

​Los estudiantes de pregrado que deseen continuar con el sistema metro y terminar la especialización en Dirección de Operaciones y Logística tendrán la capacidad de desempeñarse dentro de una empresa en:

​Dirección de operaciones.

Dirección logística.

Planeación, programación y control de las operaciones.

Diseño y administración de centro de distribución.

Transporte y distribución.

Abastecimiento y control de inventarios.

**​​​Coordinador**

Sergio Ramirez Echeverri.

Teléfono: (57) (4) 2619500 - Ext. 9545 – 9621​​

Correo: [espoyl@eafit.edu.co](mailto:espoyl@eafit.edu.co)

Debido a la dinámica cambiante de los mercados de productos nacionales e internacionales, que incluye a los fabricantes que crean y manufacturan productos para ciclo de vida más corto, hasta los consumidores que buscan productos de mayor calidad a menor costo; se ven las empresas en la necesidad de estudiar sus procesos y estrategias de concepción de nuevos productos y evaluar los existentes, desde la noción misma del producto, la manufactura, ensamble, la distribución y las ventas del mismo.

**Las materias que se ven en esta línea de énfasis son:**

**Código:** IP0670

**Nombre de la materia:** Diseño para el ambiente

**Créditos:** 2

**UMES:** 2

**Código:** IP0671

**Nombre de la materia:** Diseño para el ensamble

**Créditos:** 2

**UMES:** 3

**Código:** IP0672

**Nombre de la materia:** Diseño para la manufactura

**Créditos:** 2

**UMES:** 3

**Código:** IP0674

**Nombre de la materia:** Proyecto I - proyecto artefacto físico

**Créditos:** 4

**UMES:** 4

**Código:** IP0694

**Nombre de la materia:** Diseño colaborativo y globalizado

**Créditos:** 2

**UMES:** 2

​Los estudiantes de pregrado que deseen continuar con el sistema metro y terminar la especialización en Rediseño de Productos tendrán la capacidad de desempeñarse dentro de una empresa en:

​

​Gerente de diseño.

Directores de departamento de Ingeniería de ingeniería y desarrollo.

Jefes de planta.

Consultores.

Asesores y profesionales de pequeñas, medianas y grandes empresas.

**Coordinador**

Álvaro Guarín Grisales

Teléfono: (57) (4) 2619500 - Ext. 9203

Correo: aguarin@eafit.edu.co

Busca formar profesionales con capacidad de analizar, identificar, caracterizar e innovar con materiales tanto tradicionales como de última generación para las diferentes aplicaciones de ingeniería relacionadas con los materiales metálicos, poliméricos, cerámicos, construcción y compuestos. De esta manera se logrará el desarrollo de diseños de materiales de acuerdo con las necesidades específicas de cada aplicación.

**Las materias que se ven en esta línea de énfasis son:**

**Código:** IP0682

**Nombre de la materia:** Mecánica de los medios continuos avanzada

**Créditos:** 3

**UMES:** 4

**Código:** IP0680

**Nombre de la materia:** Técnicas de caracterización de materiales

**Créditos:** 3

**UMES:** 4

**Código:** IP0682

**Nombre de la materia:** Selección de materiales

**Créditos:** 3

**UMES:** 3

**Código:** IP0683

**Nombre de la materia:** Estructura de los materiales

**Créditos:** 3

**UMES:** 3

​Los estudiantes de pregrado que deseen continuar con el sistema metro y terminar la especialización en Diseño de Materiales tendrán la capacidad de desempeñarse dentro de una empresa en:

​

​Gerente de diseño.

Directores de departamento de Ingeniería de ingeniería y desarrollo.

Jefes de planta.

Consultores.

Asesores y profesionales de pequeñas, medianas y grandes empresas.

**Coordinador**

E. Alexander Ossa H

Correo: [eossa@eafit.edu.co](mailto:eossa@eafit.edu.co)

Tel. 2619500 Ext.9603 – 9545

​El desarrollo de posgrados en esta área se ha constituido por las relaciones entre el Instituto de capacitación e investigación de plásticos y del caucho ICIPC y la Universidad EAFIT, para profesionales que estén interesados en el manejo y los procesos de transformación de los materiales poliméricos.

**Las materias que se ven en esta línea de énfasis son:**

**Código:** IP0661

**Nombre de la materia:** Procesamiento de elastómeros

**Créditos:** 3

**UMES:** 4

**Código:** IP0662

**Nombre de la materia:** Inyección

**Créditos:** 3

**UMES:** 4

**Código:** IP0663

**Nombre de la materia:** Reciclaje de materiales plásticos

**Créditos:** 3

**UMES:** 4

**Código:** IP0664

**Nombre de la materia:** Diseño de piezas de materiales plásticos

**Créditos:** 3

**UMES:** 4

**Código:** IP066

**Nombre de la materia:** Extrusión

**Créditos:** 3

**UMES:** 3

Los estudiantes de pregrado que deseen continuar con el sistema metro y terminar la Especialización Procesos de Transformación del Plástico y el Caucho tendrán la capacidad de desempeñarse dentro de una empresa en:

Departamento de producción.

Departamento gestión de calidad.

Equipos de Investigación, innovación y desarrollo de plímeros.

Consultoría / asesor externo de la empresa, en el área técnica del plástico y caucho.

**​Coordinador**

Luis Santiago Paris L.

Teléfono: 2619500 Ext.9362

Correo: posgrado.polimeros@eafit.edu.co

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)