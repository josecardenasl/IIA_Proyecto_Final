# ​Laboratorio de Control Digital - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​Laboratorio de Control Digital

*    ​Laboratorio de Control Digital 

#### **Servicios​​**

El Laboratorio presta servicios a los programas de Ingeniería de producción, Sistemas y Diseño de Producto. También atiende prácticas para ingeniería Física de manera esporádica.

Las áreas de conocimiento que apoya el​ Laboratorio son Control digital, control análogo, sistemas embebidos, programación de PLCs, Internet de las Cosas (IoT), administración de Datacenter académico, diseño de circuitos impresos y diseño de equipos académicos en el área de control.​

## ​Laboratorio de Almacena​​miento (WareHousing Lab)

En él​​ se investiga, analiza y mejora los procesos de almacenamiento en las organizaciones mediante la creación de tecnología y la transferencia de conocimiento.

###### **Más información**

El **“Warehousing Lab”** es un espacio de la Universidad EAFIT que permite acercar la industria y la academia para generar conocimiento y mejorar los procesos a partir del análisis. Este fue creado en el año 2017 como un centro de investigación y aprendizaje en operaciones de almacenamiento. En el laboratorio se trabaja en el desarrollo y aplicación de nuevas tecnologías que puedan ser adaptadas a las necesidades de la industria, para la toma de decisiones en el marco de la **logística 4.0**.

###### **Los desarrollos tecnológicos**

_**Pick-to-light:**_ Es un sistema de iluminación conformado por un conjunto de etiquetas (tags), que por medio de una luz y una pantalla led indican al usuario la ubicación de los productos solicitados y el número de unidades requeridas. Cada tag está asociado a una única posición de almacenamiento y al iniciar el proceso de consolidación de un pedido se iluminan indicando la ubicación donde el usuario puede recolectar los productos. El sistema facilita la consolidación de pedidos en un centro de distribución, obteniendo como beneficios la recolección de información en tiempo real, la eliminación de papel en la operación y una mejor calidad de los pedidos.

**Vehículo autónomo liviano:** El modelo desarrollado para el Warehousing Lab tiene una capacidad de carga de 15 kilogramos. Asiste en la recolección de pedidos, uno o varios, de manera simultánea. Se desplaza con ayuda de perfiles metálicos ubicados en el suelo, recorriendo los pasillos del almacén y deteniéndose en las diferentes posiciones asociadas a los productos que tiene asignados.

Un operario acompaña el recorrido para verificar la información, recolectar los productos en las posiciones y depositarlos en sus respectivos medios para continuar los recorridos. La información la puede visualizar en una tableta electrónica que muestra los datos necesarios para la recolección de pedidos.

**Vehículo autónomo robusto:** Este modelo fue desarrollado para uso industrial y tiene una capacidad de transportar 80 kilogramos. Consiste en una plataforma móvil que asiste en las diferentes estrategias de picking y se desplaza de manera autónoma. Funciona, inicialmente, con un reconocimiento de la zona de trabajo para moverse libremente, lo que le permite recorrer el almacén deteniéndose en las posiciones de los pedidos que tiene asignado recolectar.

Un operario acompaña el recorrido, verificando la información, recolectando los productos y depositándolos en sus respectivos medios hasta consolidar todos los pedidos. Luego avanza sin ningún operario hasta los puntos de descarga.

**Manillas lectoras de radiofrecuencia:**Con el uso de la manilla no es necesaria la lectura de códigos de barra, esto debido a que trabaja por lectura de RFID. Está diseñada para agilizar las operaciones dentro de los almacenes y reducir los errores de lectura de ubicación, permitiendo verificar el producto que se toma. Además de monitorear las actividades de los operarios en tiempo real, bajo ciertos sistemas de picking permite productividades más altas que el mismo uso de terminales lectoras de códigos de barras.

**Warehouse Managment System (WMS):** Este sistema permite administrar toda la información del laboratorio. Recolecta, genera y procesa datos de los dispositivos electrónicos conectados vía wifi para generar información que facilite la toma de decisiones cuando la operación está en ejecución. Contiene aplicaciones que integran algoritmos de optimización e inteligencia artificial para mejorar el proceso de preparación de pedidos.

**Reconocimiento de imágenes:** el sistema permite utilizar el reconocimiento de imágenes, eliminando las marcaciones de los sistemas con códigos de barras. La operación se realiza por medio de una fotografía del objeto, la cual entrega el tipo de objeto y la posición en la cual debe ubicarse. También permite lectura de texto, facilitando las operaciones de picking en los procesos que no puedan utilizarse códigos de barra.

#### **Recursos​**

## Equipos didácticos a escala: Ascensor, puente grúa, invernadero y banda.

## Módulo de control ​de nivel y caudal

## Módulo de control de temperatura y humedad

## Datacenter académico

## Bancos de Electrotecnia

## PLCs

## ​Arjetas de adquisición de datos

## Banco neumático

## Minisecuenciador neumático

## Equipos de medición de variables eléctricas y herramientas

## Contacto

Hugo Alberto Murillo Hoyos, coordinador.

**Correo:**[hmurillo@eafit.edu.co​](mailto:hmurillo@eafit.edu.co%E2%80%8B)

**Teléfono:** (57) (604) 2619500 ext 9397

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)