# Un concurso que impulsa las iniciativas empresariales

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# Un concurso que impulsa las iniciativas empresariales

*    Un Concurso Que Impulsa Las Iniciativas Empresariales 

PrideCo Supply es una marca de bolsos, maletines, cosmetiqueras, gorras y accesorios con diseños versátiles que, a través del E-commerce, busca convertirse en una propuesta aspiracional para las personas de estratos 4, 5 y 6. El valor diferencial se encuentra en el hecho de que todas las telas y materiales son nacionales y cuentan con certificado de origen, lo que disminuye la huella de carbono por transporte, y garantiza el impacto positivo de esta iniciativa en temas ambientales y sociales.

Next Energy Utility (Neu) es una comercializadora ciento por ciento digital de energía eléctrica. Se trata de una opción que aumenta la interacción entre los consumidores y prosumidores con su propia electricidad y que, soportada en tecnologías como la infraestructura de medición avanzada, internet de las cosas, blockchain, ingeniería de datos e inteligencia artificial, se convierte en la primera en su tipo en el país.

Una mezcla de pasión, conocimientos y tecnología es lo que se nota en el proyecto Inseminación artificial de abejas vírgenes Apis Mellifera, en el que más allá del hecho de importar abejas vírgenes que no estén contaminadas de especies africanizadas, presenta una innovación y es que realiza la trazabilidad de los zánganos en colmenas de alta producción, capturando los mejores para luego realizar el proceso de inseminación, todo esto a través de un aplicativo tecnológico.

Estos proyectos en los que participaron egresados son un ejemplo del espíritu emprendedor que siempre ha caracterizado a los eafitenses y fueron reconocidos en la edición número 14, realizada en 2019, del Concurso de Iniciativas Empresariales, liderado por el programa de Empresarismo de Innovación EAFIT.

## A lo largo de los años, más de 2 mil propuestas han pasado por el Concurso de Iniciativas Empresariales.

> Tengo mucho que agradecerle a EAFIT por sacar adelante este proyecto, porque la Universidad marcó en mí el espíritu emprendedor. Desde el momento que empecé mi carrera sentí eso. La Universidad nos da bases, nos impulsa, nos motiva a ser capaces, a dar lo mejor y, sobre todo, a crear y creer en tus propias ideas”
> 
> 
> Laura Martínez Alzate, ganadora en la categoría creativa/cultural con PrideCo Supply

## 4. Educación de calidad

## 8. Trabajo decente y crecimiento ecónomico

## 9. Industria, innovación e infraestructura

## Emprendimiento

###### **Creemos en la nueva generación de empresarios y emprendedores audaces**

###### ​que fortalecen el tejido económico y social de la región y del país.

Inspiramos a los emprendedores a convertir en realidad sus ideas y a transformarlas en negocios productivos, rentables y sostenibles mediante un acompañamiento personalizado basado en la experiencia académica, investigativa y empresarial de la Universidad EAFIT y su Dirección de Innovación.

**Contacto**

**emprender@eafit.edu.co**

dgonza49@eafit.edu.co – icgomezs@eafit.edu.co

Teléfono: (57) 604 261 9500, extensión 9879

###### Emprendimientoeafit​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate