# Proyecto educativo institucional 2020

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Hacia un nuevo proyecto educativo institucional

" No somos, vamos siendo.." 2020

*    Proyecto Educativo Institucional 2020 

### ¿Qué es educar para EAFIT?

### Video institucional Universidad EAFIT 2020

### Una construcción colectiva y permanente de nuestra idea de Universidad

Educar como una acción dinámica que evoluciona, como un acto que transforma vidas, como una siembra incesante de esperanza… Educar es un verbo que EAFIT conjuga cada jornada y que engrandece gracias a su construcción colectiva y permanente de idea de Universidad, tal como lo propone Umberto Eco en su Obra abierta, en la que cada lector reescribe el texto y que, en el caso de nuestra Institución, se labra gracias a los integrantes de nuestra comunidad académica y de nuestros aliados.

Este Proyecto Educativo Institucional (PEI) acompaña en un recorrido de conceptos que dota de sentido e identidad a nuestros tres ejes misionales de aprendizaje, descubrimiento y creación, y proyección social, así como a los procesos institucionales transversales que hacen posible la existencia de EAFIT. En este también nos preguntamos y planteamos una lectura crítica y reflexiva a quien reescribe todos los días este relato, y es para qué existe y qué abarca este proyecto de Universidad que, en más de 60 años de transformación constante, responde a los retos de cada momento de la historia sin olvidarse de un sello en particular: su impronta, testimonio de un legado que se afianza en los valores institucionales con la integridad como virtud principal.

En ese acto de construir y reescribir, y por ende de continuar conjugando el verbo educar, EAFIT se vislumbra como una gran conversación que responde con humanidad a los desafíos de una época de aceleraciones, en la que será una ciudadanía ética y con criterio la que asuma decisiones en beneficio de la sostenibilidad. En esta construcción toman parte desde los niños hasta los adultos mayores, quienes le dan vida a esta Universidad para todas las generaciones; la que educa en los espacios de aprendizaje y forma en el campus; la de impacto regional y local; la de los programas relevantes y pertinentes; la del conocimiento en conexión con el entorno; la que es coherente entre lo que es, dice y hace; la que propende por brindar nuevas oportunidades de inclusión.

la del campus donde naturaleza e infraestructura conviven en armonía; la que tiene en su ADN la alta calidad; la que se fortalece gracias a su capacidad relacional; y la que cree firmemente en la importancia de la dimensión cultural y la diversidad de saberes y pensamientos para consolidarse como una verdadera universidad .

En conjunto viajamos en una embarcación hacia la próxima década. ¿Su nombre? Itinerario EAFIT 2030, que nos señala un horizonte de incertidumbres y de posibilidades en un escenario que exige de un liderazgo acorde con esta era de modificaciones estructurales. Esta hoja de ruta se soporta en un Propósito Superior: Inspiramos vidas e irradiamos conocimiento para forjar humanidad y sociedad.

Esta declaración es la que motiva la estructura de este PEI, expresión de un modelo educativo en transformación en el que educar adquiere una relevancia que trasciende la sola capacitación y que también es la oportunidad para ratificar lo que en distintos escenarios reafirmamos: existimos para servir a la educación, no para servimos de esta, convicción propia de una institución de educación superior sin ánimo de lucro comprometida con el desarrollo sostenible de la humanidad.

Con este Proyecto Educativo Institucional continuamos la construcción colectiva y permanente de nuestra idea de universidad, esa en la que no somos, sino que vamos siendo…

##### Juan Luis Mejía Arango

Rector 2004-2020

## I. Inspiramos vidas

Nuestra historia, convicciones y las personas que son nuestra razón de ser

## II. Irradiamos conocimiento

Los conceptos identitarios de nuestro Proyecto

 Educativo Institucional.

## III. Para forjar humanidad y sociedad

Inventario de experiencias

###### Hacia un nuevo

###### Proyecto Educativo Insitucional

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate