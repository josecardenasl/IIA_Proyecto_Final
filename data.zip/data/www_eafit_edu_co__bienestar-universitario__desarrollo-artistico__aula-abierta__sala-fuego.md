# Sala Fuego - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Sala Fuego

*    Sala Fuego 

###### ​Protocolo para el uso de la Sala de Ensayo Musical​ Fuego

La Sala de Ensayo Musical es un espacio acondicionado para los encuentros tanto de los grupos artísticos adscritos al Departamento de Desarrollo Artístico como para las iniciativas particulares y espontáneas que surjan entre la comunidad universitaria como una actividad de bienestar.

La sala cuenta con una batería musical, una guitarra eléctrica, una guitarra acústica, un bajo eléctrico con sus soportes, amplificadores de guitarra y de bajo, un teclado, un micrófono de voz, un cable de micrófono con su base, tres líneas y un convertidor 2x1. Además, la Sala de Ensayo Musical tiene un diseño acústico apropiado para ensayos musicales y cuenta con sistema de aire acondicionado.

1.   **Uso de la Sala de Ensayo Musical:**

Al momento de ingresar a la sala, el responsable de la reserva solicitará la apertura de la sala, para esto deberá entregar su carné universitario, el cual se devolverá una vez termine su hora de ensayo.

Al responsable de la reserva se le entregará una tarjeta con un código QR, allí deberá escanear el código y diligenciar el formulario de uso de la Sala de Ensayo Musical.

1.   **Diligenciamiento del Formulario:**

El responsable de la reserva deberá diligenciar el formulario digital una vez termine el tiempo del ensayo.

1.   **Validación y Devolución del Carné:**

Al terminar la sesión, el responsable de la reserva se dirigirá a las oficinas del Departamento de Desarrollo Artístico para reclamar su carné.

El personal del Departamento de Desarrollo Artístico verificará que el formulario haya sido diligenciado correctamente.

De presentarse anomalías en el uso del aula o en el formulario, se iniciará el debido seguimiento.

1.   **Consideraciones generales de la Sala de Ensayo Musical**

Podrán hacer uso de la Sala de Ensayo Musical estudiantes, docentes, empleados y egresados de la Universidad EAFIT, ya sea con otros miembros de la comunidad universitaria o con miembros externos a ella.

Para la reserva de la Sala se requiere que por lo menos uno de los integrantes del grupo sea eafitense, el cual quedará inscrito como responsable del buen uso de la Sala, instrumentos y equipos.

El responsable de la reserva deberá estar siempre presente para la entrega del espacio, en caso de no estar presente, el resto del grupo no podrá hacer uso de la Sala.

Todos los usuarios (estudiantes, profesores, egresados) tendrán como responsabilidad diligenciar el formulario de control al final de cada sesión. El no cumplimiento podrá acarrear la suspensión temporal del uso de la Sala.

Los usuarios son responsables de reportar cualquier anomalía encontrada en el estado inicial de los instrumentos, equipos o espacio.

El usuario deberá finalizar su ensayo 5 minutos antes de la hora establecida, con el fin de organizar los equipos y dejar la sala en óptimas condiciones para la siguiente reserva.

Las reservas se darán máximo dos horas por semana en bloque, dependiendo de la disponibilidad de la Sala y bajo las fechas y horarios estipulados por el Departamento.

La Sala debe dejarse en condiciones óptimas (limpia y ordenada).

La tarjeta QR entregada al inicio del ensayo es de uso exclusivo para el responsable del grupo.

En caso de que la reserva no vaya a ser usada, el responsable deberá avisar con mínimo 24 horas de anticipación, enviando correo a [dllo.artisrtico@eafit.edu.co](mailto:dllo.artisrtico@eafit.edu.co).

La acumulación de tres inasistencias sin avisar dará como resultado la cancelación del préstamo de la Sala.

El Departamento de Desarrollo Artístico se reserva el derecho de cancelar las reservas para atender eventos especiales como el Festival de la Canción, mantenimiento de la sala, instrumentos y equipos que pudieran surgir en un momento dado. Dicha cancelación se avisará por lo menos con 36 horas antes de la reserva y se enviará por correo electrónico al eafitense responsable de la reserva.

Se prohíbe el consumo de alimentos y bebidas dentro de la Sala.

**Nota: de identificarse incumplimientos en alguno de estos items, el responsable de la reserva podrá recibir desde un llamado de atención hasta la cancelación de la reserva.**

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate