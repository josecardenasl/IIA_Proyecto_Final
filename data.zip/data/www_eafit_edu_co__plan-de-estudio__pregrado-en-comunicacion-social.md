# Pregrado en Comunicación Social - 2023 - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Pregrado en Comunicación Social - 2023

*    Plan de Estudio 
*    Pregrado En Comunicación Social - 2023 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Inducción y Bienestar Universitario 

- [x] Plan de estudios del programa 

Semestre 1

Créditos 

totales-

Créditos 0

#### Inducción

Código: BU0010

Inducción y Bienestar Universitario
## Inducción

0 Créditos

0 UMES

Código: **BU0010**

Créditos 1

#### Bienestar Universitario

Código: BU0011

Inducción y Bienestar Universitario
## Bienestar Universitario

 Cancelable 

1 Créditos

1 UMES

La asignatura Bienestar Universitario, por medio de actividades artísticas, deportivas, académicas y de reflexión, facilita la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, contribuyendo a la transición entre el colegio y la Universidad.

Código: **BU0011**

Correquisito Créditos 0

#### Taller de Salud

Código: BU0600

Créditos 0

#### Taller de Salud

Código: BU0600

Inducción y Bienestar Universitario
## Taller de Salud

0 Créditos

0 UMES

Código: **BU0600**

Créditos 3

#### Teoría de la Imagen

Código: CS0091

Plan de estudios del programa
## Teoría de la Imagen

3 Créditos

4 UMES

Código: **CS0091**

Créditos 3

#### Expresión Escrita

Código: CS0229

Plan de estudios del programa
## Expresión Escrita

3 Créditos

4 UMES

Código: **CS0229**

Créditos 2

#### Expresión Oral

Código: CS0230

Plan de estudios del programa
## Expresión Oral

2 Créditos

3 UMES

Código: **CS0230**

Créditos 3

#### Lenguaje Sonoro

Código: CS0231

Plan de estudios del programa
## Lenguaje Sonoro

3 Créditos

4 UMES

Código: **CS0231**

Créditos 2

#### Historia Contemporanea

Código: HL0354

Plan de estudios del programa
## Historia Contemporanea

2 Créditos

3 UMES

Código: **HL0354**

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Inducción y Bienestar Universitario 

- [x] Plan de estudios del programa 

## Líneas de énfasis

Este énfasis forma comunicadores capaces de producir, gestionar y posicionar contenidos periodísticos y narrativos en múltiples plataformas, integrando creatividad, análisis de audiencias y estrategias digitales. Combina el desarrollo de habilidades narrativas con competencias en marketing de contenidos, optimización para entornos digitales, experimentación en laboratorios creativos y análisis de tendencias, preparando a los estudiantes para liderar proyectos innovadores en medios, organizaciones y emprendimientos propios.

Asignaturas

1.**Estrategia y marketing de contenidos:** enseña a diseñar y aplicar estrategias de marketing de contenidos basadas en análisis de audiencias, narrativas transmedia y objetivos de marca.

2.**Gestión y posicionamiento de contenidos:** proporciona herramientas para optimizar, distribuir y posicionar contenidos en entornos digitales, aplicando analítica, SEO y gestión de audiencias.

3.**Laboratorio de creación de contenidos:** espacio práctico para producir contenidos periodísticos y narrativos de no ficción con estrategias transmedia y enfoque en el usuario.

4.**Tendencias en periodismo, información y contenidos:** analiza los cambios y oportunidades en la industria informativa, de contenidos y del periodismo incorporando formatos innovadores y tecnologías emergentes.

5.**Emprendimientos creativos y culturales:** desarrolla habilidades para crear y gestionar proyectos culturales y artísticos con impacto social y potencial transformador.

El énfasis en Comunicación Pública forma profesionales capaces de analizar, diseñar y ejecutar proyectos comunicativos que respondan a problemáticas sociales, éticas y políticas, fortaleciendo la democracia y la participación ciudadana. Integra conocimientos teóricos, metodológicos y creativos para intervenir en la esfera pública, articulando investigación, estrategia, ética, arte y emprendimiento cultural como herramientas de transformación social.

Asignaturas

1.**Comunicación y cambio social:** analiza y diseña proyectos comunicativos que promueven la participación, el diálogo y la movilización frente a problemáticas sociales contemporáneas.

2.**Ética y cultura ciudadana:** examina los valores y principios que orientan la esfera pública para diseñar proyectos, estrategias, contenidos y emprendimientos de comunicación útiles a la sociedad y a la democracia.

3.**Métodos empíricos:** aplica herramientas de investigación cualitativa y cuantitativa para identificar problemas públicos y sustentar estrategias con base en evidencia.

4.**Soluciones artísticas de problemas sociales:** diseña proyectos comunicativos que integran elementos estéticos y artísticos para generar impacto y movilización social.

5.**Emprendimientos creativos y culturales:**desarrolla habilidades para crear y gestionar proyectos culturales y artísticos con impacto social y potencial transformador.

La línea de énfasis en Comunicación Transmedia prepara a los estudiantes para diseñar, producir y analizar narrativas y estrategias comunicativas que se desarrollan de forma coherente y complementaria a través de múltiples plataformas y medios. Integra fundamentos teóricos, metodológicos y prácticos que permiten comprender el fenómeno de la transmedialidad desde perspectivas narrativas, tecnológicas, mediáticas y de mercadeo digital, con el fin de crear experiencias de comunicación innovadoras y significativas para diferentes públicos y contextos.

Asignaturas

1.**Seminario de investigación en narrativas transmedia:** explora teorías, debates y casos de narrativas transmedia en diversos sectores, para comprender y aplicar estrategias multiplataforma.

2.**Laboratorio de contenidos digitales:** desarrolla proyectos multiplataforma y transmedia, aplicando diseño de experiencias, creatividad y prototipado con enfoque en la interacción del usuario.

3.**Ecologías mediáticas:** analiza las relaciones entre sociedad, tecnología y comunicación, comprendiendo los entornos mediáticos desde una perspectiva sistémica e interdisciplinaria.

4.**Fundamentos de mercadeo digital y estrategia transmedia:** enseña metodologías para diseñar, operar y medir estrategias digitales y transmedia, integrando objetivos de marca, negocio y contenido.

5.**Emprendimientos creativos y culturales:** desarrolla habilidades para crear y gestionar proyectos culturales y artísticos con impacto social y potencial transformador.

La línea de énfasis en Mercadeo y Comunicación Digital forma profesionales capaces de diseñar, implementar y liderar estrategias de comunicación y mercadeo en entornos digitales, integrando conocimientos de publicidad, marketing de contenidos, redes sociales, posicionamiento en buscadores y gestión de canales web. Este énfasis combina la planeación estratégica con el uso creativo y técnico de herramientas digitales, preparando a los estudiantes para responder a las demandas del mercado y conectar de manera efectiva marcas, productos y consumidores en un ecosistema digital en constante evolución.

Asignaturas:

1.**Comunicación integrada de mercadeo:** profundiza en las estrategias de promoción dentro de la mezcla de mercadeo, abordando instrumentos y variables utilizadas por anunciantes, agencias y medios.

2.**Estrategias de mercadeo digital:** desarrolla la capacidad de planear y liderar proyectos web, comprendiendo la relación entre el canal digital y la estrategia global de marca.

3.**Comunicaciones digitales de mercadeo:** enseña principios y prácticas de publicidad digital, SEM, campañas en Google Ads y Facebook Ads, junto con el análisis de datos para la toma de decisiones.

4.**Medios sociales y mercadeo electrónico:** introduce al marketing de contenidos como herramienta para atraer y fidelizar clientes, con enfoque en estrategias virales y de alto valor para el consumidor.

5.**Emprendimientos creativos y culturales:** desarrolla habilidades para crear y gestionar proyectos culturales y artísticos con impacto social y potencial transformador.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate