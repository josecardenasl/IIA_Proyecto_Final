# Pintura - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Pintura

*    Pintura 

###### ​Presentación

Aprender a ver, aprender a componer, aprender a sintetizar y a reinterpretar, son las claves del mundo de la pintura. Hay fórmulas específicas para aprender a utilizar una técnica: hay que enfrentarse con ellas y aprender del seguimiento del propio trabajo. Mediante la observación atenta del entorno, de ti mismo y de los otros, así como de las composiciones de tus compañeros, te enfrentarás con el desarrollo de las diferentes técnicas, de acuerdo con tus propios gustos.

###### Evaluación

70% Seguimiento.

30% Final.

###### Contenido

Ejercicios simples de dibujo sobre papel.

Diálogo con los estudiantes para la escogencia de técnica pictórica entre: óleo, acrílico, acuarela, pastel, carboncillo, lápiz, tinta china con pincel o plumilla, para trabajar sobre madera, lienzo o papel.

Cada estudiante deberá traer a partir de la segunda sesión una imagen que quiera reproducir. A esto se le conoce como “Modelo a seguir”. Así mismo deberá traer los materiales para su trabajo, de acuerdo con la escogencia de la técnica y el “Modelo a seguir”.

Comienzo del trabajo pictórico, con la técnica que cada estudiante escogió. Dimensión mínima del trabajo: 30 x 50.

Durante el desarrollo del Taller, habrá aproximaciones a temas de la pintura como: planos, perspectiva, preparación de colores a partir de los colores primarios, proporción a escala, sombras, iluminación, texturas, volumen, etc., de acuerdo con cada uno de los trabajos que se van realizando, y de manera personal. ​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate