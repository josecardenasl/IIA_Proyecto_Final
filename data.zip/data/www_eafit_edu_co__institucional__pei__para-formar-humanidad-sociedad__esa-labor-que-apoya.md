# Esa labor que apoya a las personas en​ situación de discapacidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Esa labor que apoya a las personas en​ situación de discapacidad

*    Esa Labor Que Apoya A Las Personas En​ Situación de Discapacidad 

​​Reconocernos en la diversidad y propiciar espacios y herramientas para que la comunidad participe en igualdad de condiciones, es un objetivo prioritario en el Consultorio Jurídico y Centro de Conciliación. Más allá de abordar la discapacidad desde la protección y la ley, que es vital, se trata también de reconocer al otro y de eliminar las barreras que les impiden desarrollarse y ser parte de la sociedad.

Es necesario entender que en el centro de todo proceso se encuentra la persona. Por eso, con el propósito de prestar un servicio accesible, en igualdad de condiciones, en los últimos años, esta dependencia ha trabajado con el Ministerio de Justicia en programas de capacitación, internos y externos, para fortalecer el modelo de discapacidad y para profundizar acerca de las acciones que se requieren para garantizar el acceso a la justicia y el reconocimiento de los derechos de esta población.

Se abrió el diálogo hacia la comunidad, a través de conversatorios y foros, para brindar orientación jurídica oportuna. Inclusive, en su sede, reformaron puntos estratégicos como la recepción, con el fin de facilitar el ingreso de personas con discapacidad física e implementaron señalización en braille.

Entre 2018 y el primer semestre de 2020, se atendieron 114 personas con discapacidad en el Consultorio Jurídico y Centro de Conciliación.

## ​​Lenguaje de señas

Con el liderazgo del Consultorio Jurídico y el apoyo de la Dirección de Desarrollo Humano-Bienestar Universitario, 15 empleados de diferentes áreas participaron en un curso de lengua de señas, con una duración de 60 horas, con el fin de disminuir las barreras de comunicac​ión con la población sorda eafitense o visitante.

 También como parte de esa mirada de inclusión consignada en el Itinerario 2030, Idiomas EAFIT ofreció en 2019 lengua de señas colombiana. ​

## 1. Fin de la pobreza

## 10. Reducción de las desigualdades

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate