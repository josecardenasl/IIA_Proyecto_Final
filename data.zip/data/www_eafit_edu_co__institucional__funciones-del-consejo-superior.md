# Funciones del Consejo Superior - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Funciones del Consejo Superior

*    Funciones del Consejo Superior 

### **​Funciones del Consejo Superior**

1.   ​Aprobar, reformar, promulgar e interpretar los Estatutos Generales de la Universidad.
2.   ​Dictar el reglamento interno que garantice un buen funcionamiento del Consejo Superior y las políticas que lo rigen.
3.   Nombrar o remover al rector de la Universidad y aprobar su remuneración. El nombramiento se efectuará de acuerdo con el proceso de selección definido por el Consejo Superior.
4.   Nombrar a los representantes legales suplentes que considere necesarios, quienes podrán actuar sin necesidad de existir ausencia temporal o permanente del representante legal principal, y sin orden de prevalencia. Dichos representantes podrán representar judicial y extrajudicialmente a la Universidad y nombrar apoderados.
5.   Elegir a los miembros del Consejo Superior.
6.   Elegir a los miembros del Consejo Directivo que le correspondan, según lo previsto en estos mismos Estatutos.
7.   Nombrar y remover al revisor fiscal para períodos de un año y determinar sus honorarios.
8.   Otorgar distinciones propias de la Universidad a las personas o instituciones que el Consejo Superior elija.
9.   Otorgar los grados Honoris Causa, de acuerdo con el procedimiento establecido para el efecto.
10.   Aprobar y velar por el cumplimiento del propósito y la estrategia de la Universidad.
11.   Aprobar los Planes Maestros de la Universidad.
12.   Hacer seguimiento al Plan de Desarrollo de la Universidad.
13.   Colaborar de forma activa en la obtención de donaciones orientadas al cumplimiento de los fines de la Institución a través de las áreas dispuestas por la Universidad para tal fin.
14.   Aprobar la fusión, extinción, disolución y liquidación de la Universidad, según lo previsto en estos mismos Estatutos y nombrar liquidador, en caso de que se requiera.
15.   Definir la cuantía hasta la cual el rector podrá enajenar o adquirir bienes inmuebles. Por encima de dicha cuantía la competencia será del Consejo Superior, para lo cual deberá sujetarse a los mismos requisitos exigidos para las reformas estatutarias.
16.   Custodiar los activos tangibles e intangibles de la Universidad.
17.   Definir las cuantías sobre las cuales el rector puede aceptar donaciones y legados, celebrar operaciones de crédito y contratos, realizar actividades comerciales en nombre de la Institución, de manera autónoma.
18.   Ordenar las reservas que estime necesarias para la defensa del patrimonio de la Institución y autorizar las inversiones especiales que a su juicio deban hacerse.
19.   Aprobar la asignación de excedentes para el año siguiente, previa recomendación del Consejo Directivo.
20.   Examinar y aprobar anualmente, previa recomendación del Consejo Directivo y junto con el informe del rector y del revisor fiscal, los estados financieros de la Institución.
21.   Aprobar el informe de gestión de la Universidad, presentado por el Consejo Directivo.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)