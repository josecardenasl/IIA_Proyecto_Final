Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar

## ​​Inscripciones abiertas

Pregrados y posgrado​s.

*    ​​Inscripc​iones ​pregrados y Posgrado​s ​ 

### **Inicia tu proceso de inscripción a pregrado​ y posgrado ​2026-2**

## Aquí inicia tu ingreso a la Universidad

## Línea WhatsApp para información de pregrado

## Línea WhatsApp para infor​mación de posgrado

#### **Acompañamos​ tu proyec​​​to profesional**

**Conoce cómo comen​​zar tu vida ​​en EAFIT**

## Conoce nuestros programas de pregra​do

## Conoce nuestros programas de posgrado​

## Guía para aspirantes a programas de pregrado

## Guía para aspirantes a programas de posgr​ado

## Conoce los servicios que tenemos para tu bienestar​

## Conoce cómo será tu ind​uc​c​ión

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)