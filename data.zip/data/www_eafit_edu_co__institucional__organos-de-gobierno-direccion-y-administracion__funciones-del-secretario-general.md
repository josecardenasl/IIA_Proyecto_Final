# ​Funciones del Secretario General​​​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Funciones del Secretario General​​​

*    ​Funciones del Secretario General​​​ 

​Garantizar la legalidad de todas las actuaciones académicas y administrativas de la Universidad.

Velar por el respeto del debido proceso en todas las decisiones disciplinarias, administrativas y académicas de la Institución.

Conservar en condiciones adecuadas y custodiar debidamente los archivos correspondientes a los Consejos Superior, Directivo y Académico, y a las Resoluciones Rectorales.

Publicar, comunicar y notificar en los términos legales y reglamentarios las decisiones de los Consejos Superior, Directivo y Académico, y del Rector.

Refrendar, con el respectivo presidente, las Resoluciones y demás decisiones de los Consejos Superior, Directivo y Académico.

Elaborar oportunamente las actas correspondientes a las sesiones de los Consejos Superior, Directivo y Académico, y otros comités en los que actúe como secretario, y firmarlas con el respectivo presidente.

Firmar las Resoluciones del Rector.

Suscribir los títulos otorgados por la Universidad, las actas de grado y los demás certificados que lo requieran.

Autenticar la copia de los actos emanados de los Consejos Superior, Directivo y Académico, y del Rector.

Acreditar a los miembros elegidos o designados ante los Consejos Superior, Directivo y Académico.

​Las demás que le asigne el Rector y las que le correspondan por la naturaleza de su cargo, de acuerdo con las normas estatutarias y reglamentarias.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)