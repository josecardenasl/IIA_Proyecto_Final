# ​El deleite por el saber​

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​El deleite por el saber​

*    ​El Deleite Por El Saber​ 

​​En 2001, cuando Saberes de Vida comenzó, 14 personas aceptaron la invitación a habitar el campus de EAFIT y a dar rienda suelta a su pasión por el conocimiento, sin importar la edad. Saberes de Vida es un espacio diseñado para que los adultos mayores continúen con el deleite del saber y el desarrollo intelectual.

En EAFIT acceden a una experiencia integral y a hacer parte de una Universidad para todas las generaciones en la que el aprendizaje se vive a lo largo de la vida. Su amplio portafolio académico incluye programas en ciencias políticas, filosofía, economía, historia, geopolítica, música, sociología, ciencias naturales y físicas. Inclusive, cuentan con un grupo estudiantil, oficializado en julio de 2013, desde donde aportan su experiencia y conocimientos.

​Este programa, que se hace parte de la Dirección de Educación Permanente, se instaló en el alma universitaria, pues como lo expresa Fabio Zuluaga, uno de los estudiantes pioneros de Saberes de Vida, hoy son naturales en la Institución y poder seguir cultivando sus pasiones y relacionarse con estudiantes de todas las edades, “aumenta las ganas de vivir, fortalece la salud. Nos sentimos como uno más y la disfrutamos toda. Las canas con ganas se tomaron la universidad”.

En 19 años de labores, Saberes de Vida ha tenido un total de 9.135 matriculados en sus diversos programas.

Esta unidad de la Dirección de Educación Permanente renovó su portafolio con más de 40 programas en línea y cursos cortos en modalidad remota y semipresencial para el segundo semestre de 2020.

## 4 Educación de calidad

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)