# Intercambio en el exterior - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Intercambio en el exterior

*    Intercambio En El Exterior 

Etapa 1

###### **Convocatorias**

Si deseas realizar un intercambio o doble titulación, debes participar de las convocatorias que realiza Internacionalización EAFIT​, las cuales son dos al año:

**Primera convocatoria:** 25 de julio al 1 de septiembre para quienes desean irse de intercambio en el primer semestre del año.

**Segunda convocatoria:** 30 de enero al 1 de marzo para quienes desean irse de intercambio en el segundo semestre del año. ​

Una vez conozcas las convocatorias, puedes avanzar a la etapa 2 con el fin de conocer si cumples los requisitos. ​

Etapa 2

###### Requisitos para estudiantes

**Pregrado​**

1.   ​​Ser ​estudiante activo de EAFIT. ​
2.   Tener un promedio acumulado ​mínimo de 3.8.
3.   Haber cursado 4 semestres​ como mínimo, o estar en el cuarto (4) semestre. ​
4.   No tener sanciones académicas ni cuentas pendientes con la Universidad.
5.   Hoja de vida actualizada.
6.   Certificado de idioma de acuerdo con el país de interés, debes verificar según a la universidad a la que desees viajar cuál es el examen de ingles que te solicitan, (Ej. IELTS, TOEFL, etc.).
7.   Pagar el Convenio 5 UMES (Descuento aproximado del 80% en el semestre de intercambio).

**Posgrado**

1.   Ser ​estudiante activo de EAFIT. ​
2.   ​​​Haber cursado mínimo un semestre de posgrado.​
3.   Tener un promedio crédito acumulado de 4.0 o superior​.
4.   Presentar hoja de vida actualizada​.
5.   No tener sanciones disciplinarias ni cuentas pendientes con la universidad.​
6.   Prueba internacional del idioma de acuerdo con el país que se elija (vigente)​.

Pagar Convenio 5 UMES.​

Etapa 3

###### Proceso general del intercambio

Aquí podrás conocer el proceso general de toda la experiencia de un intercambio internacional con EAFIT:

**A. Conocer los requisitos**

**Pregrado:**

1.   Ser estudiante activo de EAFIT.
2.   Tener un promedio acumulado mínimo de 3.8.
3.   Haber cursado 4 semestres como mínimo, o estar en el cuarto (4) semestre.
4.   No tener sanciones ni pendientes con la universidad.
5.   Hoja de vida actualizada.
6.   Certificado de idioma de acuerdo al país de interés.
7.   Pagar el Convenio 5 UMES (Descuento aproximado del 20% en el semestre de intercambio).

**Posgrado:**

1.   Ser estudiante activo de EAFIT.
2.   Tener un promedio mínimo de 4.0.
3.   Haber cursado mínimo un (1) semestre de posgrado.
4.   No tener sanciones ni pendientes con la universidad.
5.   Hoja de vida actualizada.
6.   Certificado de idioma de acuerdo al país de interés.
7.   Pagar el Convenio 5 UMES (Descuento aproximado del 20% en el semestre de intercambio).

**B. Aplicar a la convocatoria en curso**

1.   Convocatoria desde la cuarta semana de enero hasta la cuarta semana de febrero para quienes desean viajar en el segundo semestre del año.
2.   Convocatoria desde la cuarta semana de julio hasta la primera semana de septiembre para quienes desean viajar en el primer semestre del año.

**Nota:** Para doble titulación solo se puede aplicar en las convocatorias de agosto-septiembre.

**C. Ser uno de los receptores de las plazas internacionales**

1.   Cada universidad extranjera tiene cupos limitados, por lo tanto, debes ser uno de los receptores de las plazas disponibles en la convocatoria.

**D. Elaboración del acuerdo académico**

1.   Realizar el acuerdo académico con tu jefe de programa para la homologación de materias en el exterior.

**E. Nominación ante la universidad extranjera**

1.   Después de ser seleccionado, Internacionalización te nominará ante la universidad extranjera.

**F. Aplicación a la universidad extranjera**

1.   Después de ser nominado, la universidad extranjera te contactará para solicitarte información específica.

**G. Recibimiento de la carta de aceptación**

1.   Cuando entregas todo lo que la universidad extranjera te pide, te entregarán una carta de admisión en caso de ser aceptado.

**H. Visado, tiquetes y seguro**

1.   Con la carta de aceptación, podrás tramitar visado, comprar tiquetes y seguro médico internacional.

**I. Intercambio y regreso**

1.   Ya con lo anterior listo, viajarás a tu intercambio, culminarás tu proceso y, al regresar, se realizará la homologación de materias.

**Recuerda:** Sin un acuerdo académico firmado, no podrán ser homologadas tus materias.

#### Proceso de aplicación

Paso 1

###### Conoce el listado de convenios.

En esta opción puedes conocer las universidades con las que EAFIT sostiene un convenio de intercambio o doble titulación vigente.

Para acceder recuerda usar tu usuario y contraseña institucional.

Paso 2

###### Verificar la viabilidad del proceso.

**Académica:**Tener materias suficientes para homologar en tu carrera. En este caso, hacer un intercambio en un cuarto o quinto semestre, será más factible que hacerlo en un octavo o noveno semestre.

**Financiera:**Contar con los recursos para manutención y vivienda en el país extranjero de tu interés.

**De tiempo:**Entre más temprano planifiques tu movilidad, mejores oportunidades de homologación vas a tener. 

Vigencia de pasaporte (si no lo tienes tramítalo).

Paso 3

###### Pensar en tus opciones de intercambio

Debes considerar al menos 3 opciones en tres países distintos para tu intercambio. El comité de selección de plazas tendrá en cuenta tu primera opción y, de no ser posible, evaluará tus otras opciones. Si no puedes ser ubicado en ninguna de las 3, la Oficina de Internacionalización se contactará contigo para evaluar las opciones viables que aún te apliquen.

Paso 4

###### Realizar tu solicitud en la plataforma de movilidad internacional.

En los siguientes enlaces podrás encontrar las instrucciones en donde te enseñamos como hacerla. De igual forma, recuerda que para acceder a los videos debes iniciar sesión con tu cuenta de EAFIT.

1.   **Paso 1:** Acceso al formulario e información personal - [Ver el video instructivo](https://universidadeafit.widen.net/s/xppmclllrm/instructivo-onbase-acceso-e-informacion-personal).
2.   **Paso 2:** Información académica - [Ver el video instructivo](https://universidadeafit.widen.net/s/xzqswkccqq/instructivo-onbase-informacion-academica).
3.   **Paso 3:** Opciones de universidad, documentos y envío de formulario - [Ver el video instructivo](https://universidadeafit.widen.net/s/6nbdjv9wfs/instructivo-onbase-universidades-y-documentos).
4.   **Paso 4:** Notificaciones - [Ver el video instructivo](https://universidadeafit.widen.net/s/cmbnzgvsf8/instructivo-onbase-notificaciones).

**Los documentos que solicitaremos en la solicitud son:**

1.   Carta de Motivación: Esta debe ser de MÁXIMO DE 1 PÁGINA y debe ser escrita SOLO en relación con la universidad que es tu opción #1 de intercambio, OBLIGATORIAMENTE EN FORMATO PDF.
2.   Hoja de vida en formato PDF.
3.   Certificado de idioma: esto solo aplica si alguna de tus tres opciones es de un país de habla no hispana. 
4.   Foto reciente en formato JPG. 
5.   Pasaporte escaneado (solo la página biográfica).

Paso 5

###### Realiza tu acuerdo académico.

El acuerdo académico es el documento en el que realizaras la relación de materias de tu intercambio. Puedes escoger mínimo 4 y máximo 6 materias, pero recomendamos que no tomes más de 4 asignaturas durante el intercambio, ya que puede ser contraproducente debido a las diferencias metodológicas, culturales y evaluativas.

Es tu responsabilidad realizar el acuerdo académico, de manera individual debes ingresar a la página de la universidad extranjera y revisar las materias que podrías tomar.

En el siguiente enlace te dejamos un formato de acuerdo académico que puedes usar.

**Nota:**Recuerda que el acuerdo académico debes de hacerlo firmar de tu jefe de carrera solo después de que te haya sido asignado el cupo en la universidad de tu interés. Mientras sale el resultado puedes ir realizando un borrador de este.

**Importante:**

El estudiante tiene la responsabilidad de mantener siempre actualizada la versión más reciente de su acuerdo académico, firmada por su jefe o coordinador de programa. Esto garantizará que, al momento de realizar la homologación de materias una vez finalizado tu proceso de movilidad, se cuente con la versión más actual y válida del documento en la plataforma.

Ten en cuenta que podrás cargar varias versiones del acuerdo académico, pero es tu responsabilidad asegurarte de que la última versión esté debidamente actualizada y firmada.

## Contacto

Bloque 18 Oficina 508

Horarios de atención a estudiantes: lunes y miércoles 9 a.m. a 12 m. y de 2 p.m. a 5 p.m.

o los viernes de 9 a.m. a 12 m. ​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)