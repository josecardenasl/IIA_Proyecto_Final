# Guitarra - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Guitarra

*    Guitarra 

###### ​Presentación

Esta opción te plantea una alternativa pedagógica con apoyo en la música, forma artística que le brinda al hombre la posibilidad de expresar sus sentimientos, ayudándolo a descubrir, valorar y aprovechar sus potencialidades, que luego se verán reflejadas a través de un instrumento musical, desarrollando así tu sensibilidad, creatividad y capacidad de auto reflexión y de reflexión frente a tu entorno.

###### Evaluación

Seguimiento: 70%.

Final: Montaje de cualquier obra musical aplicado en el instrumento y la voz, sea solista, dueto, trío, cuarteto o grupo: 30%.

###### Contenido

Partes de la guitarra, denominación de los dedos de ambas manos. Ejercicios de digitación mano izquierda y mano derecha y temple y afinación de la guitarra.

Formación de acordes mayores, menores, sostenidos, bemoles, relativas mayores y menores. Acordes con 7ª mayor, 7ª menor, 6ª Mayor, 6ª menor, con novenas, aumentados, disminuidos y suspendidos.

Notación Musical, los signos de la escritura musical, sistema de cifra americana. Aspecto Rítmico, Aspecto Melódico y Aspecto Armónico.

Los círculos armónicos. Escala mayor y escala menor.

Evaluación de los Acordes mayores, menores, relativas mayores y menores, 7ª mayores y 7ª menor (Seguimiento 70%).

Ritmos: Vals, Bolero, Bolero ranchero, Bambuco, Pasillo, Fox, Pasodoble, Balada Rítmica, Balada arpegiada, y montajes de pequeñas obras clásicas.

Aplicación de Canciones, teniendo en cuenta los acordes y los ritmos vistos.

Exposiciones sobre guitarristas famosos (Final 15%).

Presentación final: Interpretación de una obra musical en la guitarra. (Instrumental o vocal, acompañándose con la guitarra) (Final 15%).​​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate