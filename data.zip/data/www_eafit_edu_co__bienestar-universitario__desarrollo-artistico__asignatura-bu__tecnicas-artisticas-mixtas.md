# Técnicas artísticas mixtas - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Técnicas artísticas mixtas

*    Técnicas Artísticas Mixtas 

###### ​​Presentación

Esta opción te propone incursionar en diferentes técnicas artísticas como son la escultura, la pintura, el moldeado, el collage… convocadas todas en un mismo proyecto que en este caso será la elaboración de una máscara, teniendo como hilo conductor y tema de inspiración los Carnavales de Barranquilla, la Fiesta de negros y blancos de Nariño (Pasto), algunas celebraciones mexicanas y colombianas de diferentes culturas indígenas, etc. Conocerás de paso los orígenes de las máscaras desde la tragedia y la comedia griega, así como su historia y protagonismo en los rituales y celebraciones contemporáneas.

###### Evaluación

Seguimiento 70%.

Final 30%.

###### Contenido

Presentación.

La máscara como ritual y celebración.

Aprendizaje elaboración máscara.

Desarrollo proyecto personal.

Entrega de trabajo final.

###### Materiales para elaboración de la máscara

1 tabla soporte: 30 X 40 centímetros (cada alumno).

2 kilos de arcilla gris para moldear (cada alumno).

1 Galón plástico (lo suministra el profesor).

Papel aluminio (un rollo 20 metros para todo el grupo).

Papel periódico blanco (dos hojas de pliego por alumno).

Periódico de reciclaje (5 páginas por alumno).

Vinipel (un rollo mediano para todo el grupo).

Cartón de reciclaje (trozos medianos).

Colbón (un tarro mediano por alumno).

Pintura base agua colores primarios: amarillo, azul, rojo, blanco y negro.

Laca transparente brillante en aerosol (tarro pequeño por alumno).

Cinta de enmascarar (un rollo).

###### Herramientas

Tijeras.

Bisturí.

Pinceles.

Brocha pequeña​.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)