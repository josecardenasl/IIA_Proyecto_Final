# A'tempo Group EAFIT

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

Discover your profile at EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Accessibility

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Language

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Look for 

Search

Menu

# A'tempo Group EAFIT

Director: Germán Gallego

*    A'tempo Group EAFIT 

### About A'tempo

This group aims to explore the body's versatility and movement capabilities through improvisation. They work on contemporary dance pieces that typically focus their routines on the floor, focusing on body weight and gravity. The performances, whether staged or presented as audiovisual pieces of contemporary dance, often aim to convey a story to the audience. Therefore, they blend diverse forms of physical expression originating from around the world, and also work with others, understanding their differences and characteristics, always based on respect for one another.

###### Cuando hacemos relación a Competencias en el grupo A'Tempo, nos referimos a aquello que nos compete, es decir, lo que nos ocupa, no como una fuente de inspiración a futuro, sino como una labor cotidiana que nos atañe en tanto nos interesa y moviliza.

**​​​Escucha:**Un trabajo permanente de diagnóstico, más que personal, íntimo, aludiendo a ese ser esencial que no se define en términos de la productividad sino de la contemplación, en un reconocimiento consciente de su experiencia humana.

Transformación: El reconocimiento honesto de nuestro Ser y experiencia humana, es el motor que impulsa la generación de nuevas realidades que atienden el crecimiento y desarrollo personal, como estado de plenitud que se procura en el devenir diario.

**Comprensión:** La conexión que posibilita el reconocimiento de sí, como vínculo de transformación, permite una aceptación del otro en sus procesos y dinámicas particulares, en tanto se aceptan las propias y se conciben como parte del crecimiento constante.

**Cohesión:** Dados los anteriores preceptos se abre un camino fértil para la comunicación, entendida como la "unión en común", que nos permite un ejercicio de sociedad, en donde a partir del respeto a la individualidad, se aprovechan las diferencias en la creación y transformación de realidades que nos vinculan, como lo es la creación en danza a partir de temas que nos interesan o afectan como seres humanos.

**Estas habilidades, consolidan tres pilares:**Reconocimiento, Comprensión y Transformación que permiten su vez el desarrollo del sujeto más allá del salón de ensayo o de la danza como actividad creativa, son camino tanto para la resolución de situaciones cotidianas al igual que para la trascendencia de la existencia misma.​

Germán Gallego concibe la danza como un lugar de encuentro consigo mismo, desde la creación, la interpretación y la enseñanza, es en suma, su manera de comprender la vida, una ventana al universo.

En este sentido, su inquietud por la generación de discursos corpóreos desde la danza interactúa con reflexiones sobre el vivir cotidiano, el ser en sociedad, el amor, la muerte o la nada misma.

Su vinculación con el grupo de proyección de danza contemporánea A'tempo, cómo acompañante desde la dirección, permite un diálogo abierto desde el disfrute del Ser, donde la honestidad, el respeto propio y ajeno, y la solidaridad se presentan cómo insumos para crear un tejido humano que nos permite recordar la virtud que es tenernos los unos a los otros.

La inquitud por crear un grupo de danza contemporánea sale de los estudiantes de la Asignatura BU – Danza Contemporánea de primer semestre en el año 2017. De allí se proporciona el espacio al surgimiento de un grupo autogestionado cien por ciento por estudiantes con la asesoría del bailarín y coreógrafo Germán Gallego. La propuesta metodológica para la conformación del Grupo se presenta distinta a lo acostumbrado con los Grupos representativos: se trata de aprovechar al máximo la pasión por la danza que surge de los estudiantes, a la vez que las posibilidades dancísticas que permite la danza contemporánea, en donde la experimentación es clave para llevar al escenario expresiones corpóreas que se construyen sobre todo tipo de temáticas, sin restricción ninguna, sin imposición.

Esta metodología, coherente con el principio del mutuo cuidado, donde la responsabilidad, el crecimiento y el bien estar de los sujetos son una co-construcción, permite que sean los integrantes quienes se apropien de la consolidación y mantenimiento del grupo, bajo el amparo institucional y el acompañamiento pertinente del coreógrafo. Este espacio se proyecta entonces no solo como un grupo artístico, sino como un grupo de investigación integral en torno a la creación artística en danza. De esta manera, la promoción, divulgación y perpetuación del grupo se presentan más que como una iniciativa institucional, como una responsabilidad mutua entre los danzarines y la Universidad.

Para el año 2019 su asesor Germán Gallego oficializa su incorporación como director artístico del grupo creando planes de trabajo y metodologías para el desarrollo de los planes de trabajo anual del grupo. En el año 2020 el grupo toma el nombre A´Tempo representando a la Universidad en diferentes encuentrso de carácter regional e internacional como el Festival Internacional de Danza Contemporánea de la Universidad Jorge Tadeo Lozano.

Para ser parte del grupo deberás enviar un correo a [dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co) y estar atento(a) a la respuesta pues tu ingreso dependerá de la capacidad que se tenga para recibir a más personas durante el semestre.

###### Group rehearsal schedule and location:

Tuesdays and Thursdays from 4:00 to 6:00 pm

Dance rehearsal room: 12-201​.

###### Technical and logistical requirements for presentations:

The space required for the Group's performances is a minimum of 8m x 8m, with a wooden or tile floor, or failing that, a platform. Dancing on granite or cement floors is not advisable because it can cause injuries and knee problems for the dancers.

Adapt a covered space near the presentation venue with sufficient area for 20 people and the corresponding attire for each of them.

If the presentation is at night, lights are required for the show.

Round trip transportation.

Provide refreshments and hydration to each member of the group.

Ensure good sound amplification that includes at least two returns.

Setup and sound check must be carried out at least 30 minutes before the group's performance.

Start the program at the scheduled time, to meet the group's presentation time, given that the members are mostly students who must fulfill other academic commitments.

Having a presenter who introduces the group, or any possible interventions throughout the presentation and its closing at the end.

If the Contradanza performance is accompanied by the folk music group La Colombina, please see the group's requirements.

**Any additional information will be handled by emailing**[dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co) .

### In action

## Follow us on our social media channels

### Facebook

### Instagram

### X

Study at EAFIT

Connect with EAFIT

Contact us

Legal information

University with Institutional Accreditation until 2026. 

Supervised by the Ministry of Education.

Our headquarters

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National hotline: 01 8000 515 900

Customer service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Customer service line: (57) 606 3214115, 606 3214119

Email: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 office 401

Customer service line: (57) 601 6114618

Email: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks