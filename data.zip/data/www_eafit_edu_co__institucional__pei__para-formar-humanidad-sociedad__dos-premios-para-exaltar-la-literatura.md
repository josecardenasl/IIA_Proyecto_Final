# Dos premios para exaltar la literatura

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Dos premios para exaltar la literatura

*    Dos Premios Para Exaltar La Literatura 

​​​Son momentos importantes en el año, que los amantes de la palabra esperan con ansias. Autores y sus obras se exaltan en estos reconocimientos con los que EAFIT y sus aliados en la cultura, fomentan la creación literaria como una forma de contribuir al desarrollo de las comunidades y a la formación de públicos.

## Premio Biblioteca de Narrativa Colombiana

Se convoca con el fin de reconocer y estimular la producción y publicación de obras literarias en Colombia, y como una forma de promocionar la lectura de obras de alta calidad en el país. Han sido ganadores los escritores Juan Esteban Constaín, Andrés Felipe Solano, Patricia Engel, Pilar Quintana, Ricardo Silva y Juan Gabriel Vásquez. Es posible gracias al apoyo del Grupo Familia y Caracol Televisión.

## Premio al Mérito Literario León de Greiff

Reconoce la vida y obra de un escritor, y es una forma de promover la lectura y la creación literaria. Se concede, en el marco de la Fiesta del Libro y la Cultura de Medellín, a un poeta en los años pares y en los impares a un narrador (cuentista o novelista). Juan Calzadilla, Luisa Valenzuela, Elkin Restrepo y Edgardo Rodríguez Juliá recibieron el galardón. El Premio se entrega como parte de una alianza entre la Universidad EAFIT, la Alcaldía de Medellín y el Grupo Argos y sus empresas Argos y Celsia.

## 17. Alianzas para lograr los objetivos

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)