# ​​Integridad, el valor supremo que orienta nuestro proyecto educativo

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# ​​​Integridad, el valor supremo

que orienta nuestro proyecto educativo

*    ​​Integridad, El Valor Supremo Que Orienta Nuestro Proyecto Educativo 

​​Ya lo decía recientemente Jamil Salmi, experto internacional en educación superior: el propósito de una universidad no es solo formar profesionales de alta calidad académica e innovadores, el foco se encuentra hoy más que nunca en la preparación de buenos ciudadanos, tolerantes, solidarios, éticos, honestos.

La integridad es una virtud fundamental para inspirar y guiar a los seres humanos. Es un valor que determina, en gran medida, la manera en que concebimos la relación con la humanidad, con la naturaleza, consigo mismos. EAFIT propuso, entonces, una conversación para sintonizar a la comunidad educativa y a la sociedad en general, con este Valor Institucional. De este surgió el Centro de Integridad, punto de encuentro y mediación para docentes, estudiantes y administrativos, con el propósito de promover la reflexión ética, fomentar la educación con sentido y generar procesos edificantes.

Desde sus tres ejes: educativo, investigativo y de proyección, el Centro de Integridad desarrolla su misión, concibiendo la integridad como un valor transversal de todos los procesos académicos y una competencia clave para complementar la formación de los estudiantes en las habilidades del siglo XXI, sobre todo, en las relacionadas con las maneras de habitar el mundo.

Los Diálogos de Integridad son espacios que buscan generar preguntas acerca de temáticas relacionadas con ética, formación ciudadana, respeto e integridad. En 2019 se realizaron los siguientes: Integridad en la tecnología, construyendo una ciudadanía digital, y Respeto y tolerancia, ¿qué tanto aceptamos la sexualidad diversa en Colombia?​

## Educación de calidad

## 16. Paz, justicia e instituciones sólidas

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)