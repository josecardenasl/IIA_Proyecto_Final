# Natación - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Natación

Cursos de natación en EAFIT: mejora tus habilidades acuáticas con instructores expertos. Inscripciones abiertas para empleados, estudiantes y público general.

*    Natación 

##### Inscripciones entre el 16 y 26 de febrero de 2026

###### Curso Natación de principiantes e iniciación a estilos

**Inversión estudiantes, empleados administrativos y docentes EAFIT:**Beca del 100%**.** Antes de inscribirte asegúrate que puedes cumplir con los horarios y políticas.

**Inversión familiares** (padres, hijos, hermanos y esposo o compañero permanente) de empleados, profesores, estudiantes de pregrado y posgrado y graduados de los programas de pregrado y posgrado de la Universidad EAFIT.**$53.000**

**Inversión Particulares**: $106.000

###### Curso Master avanzado

**Inversión Estudiantes, empleados administrativos y docentes EAFIT:**Beca del 100%

**Inversión familiares, graduados y particulares**: $203.000

###### Para Eafitenses: Empleados, estudiantes de programas de pregrado, posgrado, profesores, y graduados de pre y posgrado.

Digitar tipo de documento del participante

Matriculas

Talleres

Semestre

Consultar

Seleccionar curso

Registrarse

Le debe aparecer: La inscripción del taller ha terminado exitosamente y posterior escoger la opción pagar (graduados, familiares y público en general)

###### Para familia de eafitenses y particulares: Padres, hijos, hermanos y esposo o compañero permanente y particulares.

Digitar tipo de documento del participante

Matriculas

Talleres

Semestre

Consultar

Seleccionar curso

Registrarse

Le debe aparecer: La inscripción del taller ha terminado exitosamente y posterior escoger la opción pagar (graduados, familiares y público en general)

**Importante:** Si el participante (menor o mayor de edad) no es un usuario registrado en las bases de datos de la Universidad de [clic aquí](https://app.eafit.edu.co/crm-jsp/clientes/rch_registro.htm) para registrarse y de nuevo haga la inscripción.

No hacemos nivelaciones. Las personas de acuerdo con la descripción del nivel se inscriben.

Luego de inscribirse y realizar pago, no se hace devolución de dinero. Salvo en casos justificados.

Para la comunidad que tiene apoyo del 100%, deben asistir al 80% de las clases, de lo contrario el curso debe ser pagado en su totalidad.

Las clases que se pierden por lluvia no se reponen, pero existe la posibilidad de asistir en otros horarios.

Las inscripciones se abren para todo el público en general (comunidad, familiares, egresados y particulares).

###### Principiantes

Familiarización con el agua, reconocimiento de la flotación y respiración en el agua.​

**Adultos (16 horas):**

**​Horario:** Martes/ 11:00 a.m.

**Inicio:** 03 de Marzo

**Finalización:** 16 de Junio

**Entrenador:**Monica Cecilia Torres

**Adultos (16 horas):**

**​Horario:** Jueves / 2:00 p.m.

**Inicio:** 05 de Marzo

**Finalización:**25 de Junio

**Entrenador:** Monica Cecilia Torres

**Niños de 6 y 8 años (16 horas):**

**​Horario:** Sábados / 11:00 a.m.

**Inicio:** 07 de Marzo

**Finalización:**27 de Junio

**Entrenador:** Mónica Cecilia Torres

###### Iniciación a estilos

Aprendizaje de las bases de los estilos.

Iniciación estilo libre-espalda

Iniciación estilo pecho- mariposa

**Niños de 9 a 12 años (16 horas):**

**​​Horario:** Sábado / 10:00 a.m.

**Inicio:** 07 de Marzo

**Finalización:** 27 de Marzo

**Entrenador:**Mónica Cecilia Torres

**Adultos (16 horas):**

**​​Horario:** Viernes / 11:00 a.m.

**Inicio:** 06 de Marzo

**Finalización:** 26 de Junio

**Entrenador:** Juan Guillermo Uran

**Adultos (16 horas):**

**​​​Horario:** Miércoles / 5:00 p.m.

**Inicio:** 04 de Marzo

**Finalización:** 24 de Junio

**Entrenador:** Juan Guillermo Uran

###### Master Natación

Dirigido a nadadores de las diferentes modalidades (Triatlón, aguas abiertas, natación carreras) con experiencia previa y dominio de la técnica mínimo del estilo libre. ​

**​​Horario:** Martes y jueves / 8:00 p.m a 9:00 p.m. (31 horas)

**Inicio:**03 de Marzo

**Finalización**: 23 de junio

**Entrenador:**Juan Guillermo Uran

##### Generalidad​es

**Nota:​** Los dias en los que no se tenga clase en alguno de nuestros cursos, estas no se reponen. Los usuarios podrán asistir a otros horarios y reponer dicho tiempo, si así lo desean.​​

Profundidad piscina: 1.40 metros.

Piscina climatizada.

Obligatorio el uso del gorro de baño.

La piscina cuenta con locker. (Necesario llevar candado).

No se realizan nivelaciones. Puedes realizar tu inscripción en el curso de tu interés, de acuerdo a la explicación descrita en cada nivel.

Nuestras clases son de 45 minutos​

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate