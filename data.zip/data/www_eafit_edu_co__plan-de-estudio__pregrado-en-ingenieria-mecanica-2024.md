# Plan de estudios vigente a partir de 2024-1. Pregrado en Ingeniería Mecánica - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

![Image 20: Pregrado en Ingeniería Mecánica, Universidad EAFIT.
Un estudiante manipula un equipo de cómputo en un laboratorio de EAFIT.](https://universidadeafit.widen.net/content/przjfb3zj5/web/pregrado-ingenieria-mecanica-2.jpg?crop=yes&k=c&w=1920&h=788&itok=rf0-wuvE)

# Plan de estudios

Plan de estudios vigente a partir de 2024-1. Pregrado en Ingeniería Mecánica

*    Plan de Estudio 
*    Plan de Estudios Vigente A Partir de 2024-1. Pregrado En Ingeniería Mecánica 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas de ciencias básicas 

- [x] Asignaturas disciplinares 

- [x] Básicas en Ingeniería (ECAI) 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Línea de Proyectos 

- [x] Matemáticas y Ciencias Básicas 

- [x] Núcleo de Formación Institucional 

- [x] Prepráctica - Práctica 

- [x] Trayectorias flexibles 

- [x] Trayectorias profesionalizantes 

Semestre 1

Créditos 

totales-

Créditos 0

#### Inducción

Código: BU0010

Inducción y Bienestar Universitario
## Inducción

0 Créditos

0 UMES

Código: **BU0010**

Créditos 1

#### Bienestar Universitario

Código: BU0011

Inducción y Bienestar Universitario
## Bienestar Universitario

 Cancelable 

1 Créditos

1 UMES

La asignatura Bienestar Universitario, por medio de actividades artísticas, deportivas, académicas y de reflexión, facilita la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, contribuyendo a la transición entre el colegio y la Universidad.

Código: **BU0011**

Correquisito Créditos 0

#### Taller de Salud

Código: BU0600

Créditos 0

#### Taller de Salud

Código: BU0600

Inducción y Bienestar Universitario
## Taller de Salud

0 Créditos

0 UMES

Código: **BU0600**

Créditos 3

#### Expresión Gráfica

Código: CI1001

Básicas en Ingeniería (ECAI)
## Expresión Gráfica

3 Créditos

4 UMES

Código: **CI1001**

Créditos 3

#### Proyecto Escuela

Código: CI1002

Básicas en Ingeniería (ECAI)
## Proyecto Escuela

3 Créditos

4 UMES

Código: **CI1002**

Créditos 3

#### NFI - Ciudadanía y Democracia

Código: FH1001

Núcleo de Formación Institucional
## NFI - Ciudadanía y Democracia

3 Créditos

UMES

Código: **FH1001**

Créditos 3

#### Física 1

Código: NC1001

Asignaturas de ciencias básicas
## Física 1

3 Créditos

5 UMES

Código: **NC1001**

Créditos 3

#### Cálculo 1

Código: NM1001

Asignaturas de ciencias básicas
## Cálculo 1

3 Créditos

4 UMES

Código: **NM1001**

Créditos 3

#### NFI - Pensamiento Computacional

Código: FH1002

Núcleo de Formación Institucional
## NFI - Pensamiento Computacional

3 Créditos

UMES

Código: **FH1002**

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

Núcleos, ciclos, trayectorias y énfasis

- [x] Asignaturas de ciencias básicas 

- [x] Asignaturas disciplinares 

- [x] Básicas en Ingeniería (ECAI) 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Línea de Proyectos 

- [x] Matemáticas y Ciencias Básicas 

- [x] Núcleo de Formación Institucional 

- [x] Prepráctica - Práctica 

- [x] Trayectorias flexibles 

- [x] Trayectorias profesionalizantes 

#### **Trayectorias**

###### Trayectoria en sistem​as mecánicos

En esta trayectoria profundizarás en aspectos relacionados al diseño de sistemas mecánicos desde el dimensionamiento de componentes atendiendo teorías de diseño clásico; la aplicación de metodologías de diseño que conducen al planteamiento de requerimientos de diseño, diseño conceptual, preliminar y de detalle de sistemas mecánicos; y la modelación computacional de problemas de la mecánica. Finalmente integrarás todo lo aprendido en un proyecto de fin de trayectoria aplicando las metodologías de gestión de proyectos aprendidas durante la carrera.

1.   Fundamentos de Diseño Mecánico.
2.   Diseño Mecánico Computacional.
3.   Diseño Mecánico.
4.   Proyecto Sistemas Mecánicos.

###### Trayectoria en sistemas de potencia y control

En esta trayectoria aprenderás las herramientas para el análisis y diseño de sistemas automáticos, considerando los requerimientos de la industria y las exigencias de los sistemas técnicos actuales. Comenzarás conociendo los dispositivos eléctricos, electrónicos y mecánicos que conforman un sistema de potencia y control; luego conocerás los modelos computacionales que te permitan entender como se comportan estos sistemas para poder diseñar un controlador automático; y tendrás la posibilidad de conocer las últimas tecnologías disponibles en el mercado para controlar sistemas de potencia, neumáticos e hidráulicos que son los más utilizados en cualquier planta industrial. Finalmente integrarás todo lo aprendido en un proyecto de fin de trayectoria aplicando las metodologías de gestión de proyectos aprendidas durante la carrera.

1.   Elementos de Potencia y Control.
2.   Modelación de Sistemas de Control.
3.   Tecnologías de Potencia y Control.
4.   Proyecto Sistemas de Potencia y Control.

###### ​Trayectoria en sistemas energéticos​​

En esta trayectoria aplicarás los conceptos de termodinámica, mecánica de fluidos y transferencia de calor en el diseño, selección y caracterización de sistemas de flujo de energía y materia. Para ello conocerás las últimas tecnologías en máquinas hidráulicas, neumáticas y térmicas, su dimensionamiento, selección y aplicación en sistemas energéticos; asimismo conocerás los diferentes modelos computacionales que te permiten predecir el comportamiento de sistemas hidráulicos y térmicos para optimizar su desempeño y reducir su consumo y su costo de operación; y adquirirás conocimientos en el campo de las energías alternativas tales como la solar, eólica, hidroeléctrica y la electromovilidad. Finalmente integrarás todo lo aprendido en un proyecto de fin de trayectoria aplicando las metodologías de gestión de proyectos aprendidas durante la carrera.

1.   Sistemas energéticos.
2.   Modelación de sistemas energéticos.
3.   Energías alternativas y aplicaciones.
4.   Proyecto Sistemas Energéticos.

###### ​Trayectoria en mantenimiento de sistemas

En esta trayectoria profundizarás en las acciones técnicas, administrativas y logísticas de mantenimiento que se deben adelantar para maximizar la eficiencia operacional de una máquina, equipo o instalación durante todo su ciclo de vida; también conocerás los modelos computacionales que se pueden ejecutar para determinar el estado técnico de una máquina y cómo estas herramientas facilitan la toma de decisiones; y conocerás las tecnologías de última generación para el diagnóstico, caracterización y monitoreo de sistemas técnicos. Finalmente integrarás todo lo aprendido en un proyecto de fin de trayectoria aplicando las metodologías de gestión de proyectos aprendidas durante la carrera.

1.   Operación y Mantenimiento.
2.   Modelación en Mantenimiento.
3.   Tecnologías de Mantenimiento.
4.   Proyecto Mantenimiento de Sistemas.

###### Bioingenie​ría

En esta trayectoria aprenderás los fundamentos necesarios para introducirte en el diseño y desarrollo de dispositivos médicos. Para ello deberás aprender fundamentos de biomecánica, procesamiento de imágenes médicas y biomateriales los cuales son esenciales para el desarrollo de los dispositivos médicos que utilizamos hoy en día. También aprenderás los aspectos más importantes de la legislación aplicable a los dispositivos médicos y que siempre debes tener en cuenta si quieres sacar uno de estos productos al mercado.

1.   Biomecánica.
2.   Biomateriales.
3.   Análisis y procesamiento de imágenes.
4.   Introducción a los dispositivos médicos.

###### Rob​​ótica

En esta trayectoria aprenderás los elementos necesarios para diseñar un sistema robótico. Comenzarás por aprender la dinámica de los sistemas multicuerpo, la cual es esencial para entender como se mueven los sistemas robóticos; entenderás cuales son los métodos de procesamiento de datos y aprendizaje de máquina basados en inteligencia artificial que te permiten ejecutar tareas con tus sistemas robóticos; al mismo tiempo conocerás los actuadores y sensores necesarios y cómo se programan para poder controlar tu sistema robótico y finalmente estudiarás conceptos de visión artificial que le permiten a tu sistema robótico tomar decisiones autónomas en procesos industriales, como por ejemplo el control de calidad.

1.   Dinámica y simulación robótica.
2.   Sensores y actuadores en robótica.
3.   Inteligencia artificiales en robótica.
4.   Visión artificial.

###### Veh​ículos

En esta trayectoria aprenderás los conceptos básicos de diseño de vehículos de combustión interna y vehículos eléctricos. Para ello deberás aprender dinámica de vehículos la cual te permite entender como se comportan las variables que describen el movimiento de un vehículo y cómo se puede estimar su desempeño mecánico, energético y ambiental; deberás entender los fenómenos físicos en los procesos de combustión de máquinas térmicas y la generación de las emisiones de contaminantes atmosféricos; modelar el funcionamiento de los motores de combustión interna para cuantificar su desempeño y conocer sus avances para controlar las emisiones de contaminante y finalmente aprender los conceptos de diseño y tecnologías de los vehículos híbridos y eléctricos para determinar los componentes involucrados en su operación y su desempeño.

1.   Dinámica de Vehículos.
2.   Fundamentos de combustioón y emisiones.
3.   Motores de combustión interna.
4.   Vehículos híbridos y eléctricos.

#### **Línea​​s de énfasis**

​La línea de énfasis es un conjunto de materias de 12 créditos que el estudiante del pregrado decide elegir. Estas pertenecen a una especialización bajo el mismo nombre, dándole al estudiante la oportunidad de proyectar su formación académica (para especialización, maestría o doctorado).

Uno de los problemas más comunes que enfrenta un Ingeniero Mecánico durante su ejercicio profesional es el de diseñar una planta industrial. Una planta industrial es un conjunto de sistemas técnicos que interactuando entre sí producen uno o varios productos. ​El desafío de diseñar una planta industrial consiste en responder las siguientes preguntas: ¿Qué tipos de sistemas mecánicos, de potencia y de control debo utilizar para producir determinado producto? ¿Cómo se calcula la​ capacidad de estos sistemas? ¿Cómo se acomodan en el espacio físico disponible en la planta? ¿Cuál es el orden en que debo colocarlos? ¿Qué equipos necesito para cada sistema técnico? ¿Cómo los dimensiono? ¿Cómo los selecciono entre la oferta comercial disponible?, entre otras. Todas estas preguntas las puedes responder estudiando la línea de énfasis en Diseño Mecánico, la cual consta de las siguientes asignaturas:

**Código:**MC6001

**Asignatura:** Sistemas Hidráulicos

**Créditos:**2

**Código:**MC6002

**Asignatura:** Sistemas Térmicos

**Créditos:**2

**Código:**MC6003

**Asignatura:** Sistemas de Transporte

**Créditos:**2

**Código:**MC6004

**Asignatura:** Sistemas Neumáticos

**Créditos:**2

**Código:**MC6005

**Asignatura:** Sistemas de Potencia

**Créditos:**2

**Código:**MC6006

**Asignatura:** Proyecto Sistemas Industriales

**Créditos:**2

**Más información:**

Michael Daniel Giraldo Giraldo ​

Profesor Doctor In​geniero

Para poder realizar su función primaria de transformar, transportar y/o almacenar materias primas, insumos o productos terminados, las empresas requieren de maquinaria con mayor complejidad tecnológica y de nivel científico. Estos equipos con el uso, el medio ambiente y el paso de los años, requieren de un mantenimiento que les permita cumplir con la misión para la cual fueron diseñados y construidos.

Es por lo anterior que, en Colombia, desde la década de los setenta, el área de mayor empleo para los ingenieros sigue siendo la de mantenimiento, la cual supera la cifra del 35 por ciento del empleo generado para la ingeniería de fábricas.

**Las materias que se ven en esta línea de énfasis son:**

**Código:** IM610

**Asignatura​:** Acciones preventivas

**Créditos:** 2

**Código:** IM611

**Asignatura​:** T.P.M. - Manejo y Mantenimiento Productivo

**Créditos:** 2

**Código:** IM614

**Asignatura​:** Logística documental para la toma de decisiones

**Créditos:** 2

**Código:** IM615

**Asignatura​:** Sistemas de información

**Créditos:** 2

**Código:** IM617

**Asignatura​:** Acciones correctivo-modificativas

**Créditos:** 2

**Código:** IM612

**Asignatura​:** Acciones predictivas

**Créditos:** 2

Los estudiantes de pregrado que deseen continuar con el sistema metro y terminar la Especialización en Mantenimiento Industrial, tendrán la capacidad de desempeñarse dentro de una empresa en condiciones de:

Optimizar del proceso productivo, la calidad, las finanzas, la construcción, la ejecución de un mantenimiento correctivo y preventivo.

Organizar, la planeación, intervención técnica y administrativa del mantenimiento y de sus áreas afines, desarrollando programas organizados de mantenimiento.

Vigilar y medir los procesos productivos y de mantenimiento desde la óptica financiera y de costos mediante las ciencias económicas, convencimiento y motivación del personal.

Auditar, asesorar​​​, planear, mejorar o constituir cualquier organización de mantenimiento en todo tipo de empresas.

**Más información:**

Gustavo Adolfo Villegas López

​Profesor Doctor Ingeniero

A​punta al impacto industrial mediante la transferencia del conocimiento desarrollado por los grupos de investigación y el fortalecimiento de la comunidad académica relacionada. En este sentido, se ha identificado una fuerte orientación en áreas como el desarrollo de nuevos materiales e investigación netamente experimental.

Este componente se debe acompañar de modelos matemáticos -y de la posibilidad de poder resolverlos numéricamente- que permitan conceptualizar las observaciones. Además, en los últimos años se han generado en el país nuevos programas de formación doctoral en ingeniería, los cuales requieren ser alimentados ( desde especializaciones y maestrías) por medio de estudiantes con altos niveles de formación.

**Las materias que se dictan en esta línea de énfasis son:**

**Nivel 1 - Fundamentación​**

Mecánica de los medios continuos avanzada (impronta de Mecánica Aplicada): 3 créditos.

Matemáticas avanzadas para ingenieros: 3 créditos.

Introducción al método de los elementos finitos: 3 créditos.

Introducción al método de elementos de frontera: 3 créditos.

**Total:** 12 créditos.

Los estudiantes de pregrado que deseen continuar con el sistema metro y terminar la Especialización en Mecánica Computacional tendrán la capacidad de desempeñarse dentro de una empresa como:

Líderes de grupo de investigación (y/o docentes) enfocados al estudio de problemas de ingeniería o física que demanden verificaciones y conceptualizaciones basadas en simulaciones numéricas.

Líderes de grupo de investigación (y/o docentes) enfocados al avance de nuevos métodos de simulación numérica y de desarrollo de software de simulación numérica.

Ingenieros consultores en diferentes áreas de la ingeniería (de acuerdo con su origen de formación básico) en proyectos de desarrollo de nuevos productos, diseño de nuevos materiales y revisión de estructuras existentes.

Ingenieros gestores de empresas orientadas al desarrollo y estimulo de software de simulación numérica a nivel nacional.

**Más información:**

Juan Manuel Rodríguez Prieto​

Profesor Doctor Ingeniero

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)