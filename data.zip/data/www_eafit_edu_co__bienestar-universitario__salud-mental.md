# ¡Cuidémonos! - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Buscar 

Búsqueda

Menú

# ¡Cuidémonos!

*    ¡Cuidémonos! 

### Si necesitas ayuda psicológica, comunícate con:

En la U

Línea Calma, atención 24/7 para estudiantes

Asesoría en salud mental y violencia basada en​​​ género.

 018000521021

Línea 24/7 de ARL Sura para empleados

Linea telefónica nacional 018000 511 414 opción 1- opción 4

Directorio de convenios de servicios en salud mental

¿Necesitas ayuda?

Canal de atención para citas psicológicas para estudiantes y empleados.

## Bienestar Universitario

​​​​​​​​​​​La filosofía ​​de Bienestar Universitario

 La Dirección de Desarrollo Humano y Bienestar pretende hacer del bienestar un valor individual y colectivo en la comunidad eafitense. Desde la conciencia del mutuo cuidado, con base en los valores institucionales invita a que la vida sea un vivir bien. Que las acciones sean una oportunidad para el recto actuar en un ambiente solidario y respetuoso de la diversidad y del entorno.

### Notas sobre Salud Mental

### Cuidar la mente también es cuidar la vida

### Pequeños cambios por tu salud mental

### Sostener y ciudad la vida es un acto cotidiano

### Cuando lo normal deja de ser “normal”

### ¿Te cuesta concentrarte o descansar bien?

### ¿Y si la vida no es solo una carrera?

#### Este primero de octubre tenemos una invitación a conversar sobre salud mental y productividad

#### Fuera del consultorio: estos son los profesionales que cuidan nuestra salud mental en la U

#### ¿Qué nos mueve?

#### Movernos por los sueños y metas

#### ¿Qué pasa en nuestros cuerpos cuando dejamos de fumar o vapear?

### Rutas

## Ruta de atención para el manejo de crisis emocionales

## Ruta de atención para personas con conducta suicida​​​​​​

### Educación emocional

##### Ciclo de conversaciones

#### Haz una pausa: hablemos de salud mental

#### Apoyos en salud mental, ¿qué debemos saber?

#### Profe, estoy en crisis - Hablemos sobre la promoción de la seguridad, la calma y las redes de apoyo

#### Con-sumo-cuidado

#### Salud mental y formas del lazo social

#### ¿Cómo inciden los imperativos de la época en nuestra salud mental?

#### Campus Global: ¿Pueden las redes sociales afectar la construcción de identidad la comprensión del mundo y el aprendizaje?

#### La confianza en la época de la inteligencia artificial

#### Suicidio: riesgo, estigma y prevención

#### En la U también hablamos de ansiedad

## Guías de Salud Mental

### Gestión emocional

### Un camino para afrontar las adversidades

### ¿Sabes manejar el duelo?

### Primeros Auxilios Psicológicos para profesores y empleados

### Gestionar tu tiempo y concentrarte

### Orientación para estudiantes foráneos

### III Concurso de Microcuento

#### ExpresARTE: Elogio a lo simple

Las palabras permiten expresar lo que sentimos y pensamos sobre aquello que vivimos, son un recurso a través del cual podemos encontrarnos con lo más íntimo de nosotros y conectar con algo de la intimidad del otro. Las palabras son refugio, son camino, son encuentro. Las palabras dan vida, tienen efecto en quien las escucha, las lee, las da y las recibe.

En la prisa de la sociedad actual parece que queda poco espacio para detenerse y contemplar, los días inician con premura y los propósitos cada vez son más robustos. Las exigencias de rendimiento, producción, consumo y éxito piden ir a toda velocidad, parecemos absortos en el ruido incesante de un mundo que no deja de acelerar, de demandar, de complejizar lo simple, vivir.

Bajo este panorama y siendo la palabra un recurso primordial para la vida humana, extendemos la invitación a todos los miembros de la Comunidad Universitaria a participar de la Tercera Edición del Concurso de Microcuento ExpresArte: elogio a lo simple. Para que por medio de la escritura elogiemos lo simple de la vida, esas cosas que por su sutileza conmueven, serenan o nos hacen sentir vivos

## Microcuentos Ganadores del Tercer Concurso de Microcuento:

Primer lugar

###### **Primer Lugar**

###### Soplando la Espuma

**Autora: Victoria Eugenia Giraldo Henao**

Crecí aprendiendo a leer el silencio. Cuando mi padre alzaba la voz y cerraba la puerta con fuerza, mi hermano y yo sabíamos que había que guardar los cuadernos y contener la respiración. Mi madre, siempre de pie, parecía más frágil que la loza que temblaba en la cocina.

Nos mudamos tantas veces que dejé de desempacar del todo. En cada ciudad aprendí algo distinto: a no hacer ruido, a proteger a mis hermanas, a mirar al suelo.

Pero también aprendí otra cosa.

Una noche, después de una discusión interminable, mi madre nos sirvió chocolate caliente. Afuera el mundo seguía siendo un grito; en la mesa, éramos mi madre y cuatro hermanos soplando la espuma. Nadie habló de lo que había pasado. Solo partimos el pan y lo compartimos.

Con el tiempo entendí que no era el chocolate ni el pan. Era mi madre quien, en medio del miedo, nos regalaba un momento de calma…

Segundo lugar

###### **Segundo lugar**

###### Canoa

**Autor: Valentín Vélez.**

Había llegado el día.

Después de la fiesta y el trasnocho, cuando el cielo todavía olía a ceniza y guarapo, con la salida del sol todos los hombres del pueblo entramos al bosque. Íbamos en fila, callados, como si el monte nos estuviera escuchando. El Caracolí me esperaba desde antes de que yo naciera: lo decía mi padre, lo repetían los viejos en la cantina, lo juraban las sombras largas al pie de su tronco. Era un árbol con memoria.

Entre todas las manos, talaríamos el árbol y llevaríamos su tronco corriente abajo. El filo mordía la madera y cada golpe tenía algo de promesa y algo de despedida. La savia nos salpicó como si el bosque también sangrara. Nadie hablaba, pero todos entendíamos: era una ceremonia.

En la desembocadura nos esperaba el pueblo, pequeño, pero nuestro, con las mujeres reunidas como un círculo de agua quieta, listas para bendecir lo que se desprendía del monte y se volvía camino.

Ahora yo tenía 18 años.

Ahora tendría mi propia canoa.

Un tronco tallado por todos los hombres y bendecido por todas las mujeres.

Ahora soy un pescador.

Tercer lugar

###### **Tercer Lugar**

Viaje en la Máquina del Tiempo

**Autora: Luz María Garcés Flórez.**

¡Qué aguacero! La lluvia forma cortinas blancas que se mueven impulsadas por las ráfagas de viento. ¡Sssssssss! Me envuelve ese sonido sibilante, que cambia de tono e intensidad, mezclado con el chocar de las gotas contra el pavimento. Los carros dejan de circular. Estoy de pie, en el andén. Trato de evitar que el agua me moje. ¡Sssssssss! Veo una niña que está parada en la calle, a dos metros de mí, junto al andén. En su cabeza recibe un chorro continuo y ruidoso, que cae a borbotones, proveniente de una canoa que desagua un techo alto, cubierto de tejas. Una joven está tras de ella, pero conserva la distancia. Se protege bajo el alero y trata de evitar el contacto con el agua. Le chilla, suplicante: “Negrita, no se moje que doña Rocío me va a regañar.” La niña está empapada. Le escurre agua por todas partes. Levanta los brazos, brinca, se ríe y da vueltas como una bailarina, en el mismo punto, sin salirse del chorro. La veo. Me veo. En mi mente, le digo: “Negrita, mójese. Tranquila que doña Rocío no va a regañar a nadie.”

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate