# Contradanza EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Contradanza EAFIT

Director: Mauricio Aristizabal

*    Contradanza EAFIT 

### Acerca de Contradanza

El Grupo de danza folclórica Contradanza de la Universidad EAFIT tiene como finalidad fomentar y proyectar las tradiciones dancísticas y folclóricas de nuestro país y, a su vez, enfocar su trabajo, dándole una proyección con carácter internacional, incorporando elementos de la danza moderna y el ballet, para dotarlo de un carácter más estilizado y dinámico. Está dirigido a estudiantes de pregrado y posgrado, egresados y empleados administrativos y docentes de la Institución.

Quienes hacen parte del grupo Contradanza podrán desarrollar la Confianza, pertenencia, trabajo en equipo y motivación. Así mismo podrán ser agentes vivo de conservación del patrimonio cultural de Colombia al conocer su riqueza cultural a través de la danza​.

Es bailarín y coreógrafo, director Artístico del Grupo de danza Folclórica Contradanza de la Universidad EAFIT por más de 20 años. Estuvo vinculado al Ballet Folclórico de Antioquia por 23 años como bailarín y Codirector artístico. Es Maestro en artes Plásticas de la Universidad de Antioquia.

Ha representado a Colombia en más de 20 países como bailarín y director artístico con el Ballet Folclórico de Antioquia, en escenarios de gran importancia a nivel mundial entre los que se destacan el palacio de Bellas Artes en México, el Petit Palau de la música en Barcelona-España, La sede de la Unesco en Paris-Francia, Teatro Verdi en Florencia- Italia, el Teatro del Pueblo en Beijín –China, entre otros.

También ha participado como Jurado en eventos locales, regionales y nacionales, estímulos de creación de la Alcaldía y la Gobernación de Antioquia.

Forma parte del equipo interdisciplinario de la Secretaria de Cultura en el área de danza, apoyando los diferentes encuentros ciudadanos que se realizan, como expo cultura, mes de la danza, festival de tango, feria de flores, la investigación del estado del arte de la danza, DanzaMed, convocatorias, desfile de mitos y leyendas, festival de navidad, calle de artistas entre otros.​

Este Grupo, que empezó sus actividades en 1988 en el área de Promoción Cultural, hoy Departamento de Desarrollo Artístico, ha contado con un numeroso grupo de personas entre estudiantes, empleados y egresados, quienes han contribuido al fortalecimiento y desarrollo de la actividad dancística y cultural de la Universidad.

Contradanza se ha presentado en diversos espacios de la ciudad, como instituciones universitarias, colegios, festivales, congresos, plazas y hoteles, y además ha proyectado a la Universidad hacia departamentos como Atlántico, Córdoba y Risaralda.

Con su trabajo hace un recorrido por la belleza de nuestro folclor, arraigado en las tradiciones del pueblo colombiano. Pasillos, bambucos, redovas, vueltas antioqueñas, contradanza, mapalé, joropo, bullerengue y cumbia, entre otros ritmos, es el registro de Contradanza, Grupo que, acompañado con música en vivo por el Grupo musical folclórico La Colombina, lleva 30 años de actividad dancística ininterrumpida.

Todo participante que desee ser parte de Madriguera teatro, debe pasar primero por el semillero de teatro, donde se realizará una evaluación de su conocimiento y desempeño para ser promovido. Una vez el grupo cuente con la posibilidad de recibir nuevos integrantes, serán tenidos en cuenta quienes tengan y demuestren un mayor avance.

###### Horario y lugar de ensayo del grupo:

Sábados de 10:00 a.m. a 2:00 p.m.

Aula de ensayo de baile: 12-201​.

###### Semillero de danza folclórica

Este espacio está creado para dar una formación en corporalidad que se alinee hacia los movimientos de la danza folclórica.

###### Ensayos del semillero

Viernes de 4:00 p.m. a 6:00 p.m.​

Aula de ensayo de baile: 12-201​​.

###### Requerimientos técnicos y logísticos para presentaciones:

El espacio requerido para las presentaciones del Grupo es de mínimo 8mtrs x 8 mtrs., con piso en madera o baldosa, o en su defecto una tarima. No es conveniente bailar en pisos de granito o cemento porque se pueden presentar lesiones y problemas en las rodillas de los bailarines.

Adaptar cerca del lugar de la presentación un espacio cubierto con área suficiente para 20 personas y el vestuario correspondiente de cada una de ellas.

Si la presentación es en la noche se requieren luces para el espectáculo.

Transporte ida y regreso.

​Brindar refrigerio e hidratación a cada uno de los integrantes del Grupo.

Garantizar una buena amplificación de sonido que incluya mínimo dos retornos.

Debe realizarse montaje y ensayo de sonido, mínimo 30 minutos antes de la presentación del Grupo.

Empezar el programa a la hora señalada, para cumplir con el tiempo de presentación del grupo, dado que los integrantes son en su mayoría estudiantes, que deben cumplir con otros compromisos académicos.

Contar con un presentador que haga la respectiva presentación del Grupo, o posibles intervenciones a lo largo de la presentación y el cierre de la misma al finalizar.

​​Si la presentación de Contradanza va acompañada por el Grupo musical folclórico La Colombina, ver requerimientos de este Grupo.​

**Cualquier información adicional, será atendida en el correo**[dllo.artistico@eafit.edu.co](mailto:dllo.artistico@eafit.edu.co).

### En acción​

## Síguenos en nuestras redes sociales

### Facebook

### Instagram

### X

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)