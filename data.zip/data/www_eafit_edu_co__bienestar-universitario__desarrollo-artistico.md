# Desarrollo Artístico - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Desarrollo Artístico

*    Desarrollo Artístico 

### Un luga​r para descubrirse

El Departamento de Desarrollo Artístico, como parte de la Dirección de Desarrollo Humano-Bienestar Universitario, es un lugar para descubrirse, para expresar las habilidades culturales y artísticas de una forma divertida y para realizar una introspección orientada al conocimiento personal, donde es posible vincularse con el arte no solo a través de la apreciación, sino de la realización.​​

​Servicios e información destaca​da​

## Asignatura BU

Cursos artísticos para estudiantes EAFIT como parte de Bienestar Universitario: baile, pintura, joyería, fotografía, guitarra y más.

## Talleres artísticos

Conoce y participa en los diferentes Talleres artísticos.​​​

## ​Grupos de expresión artística

​Consu​​​lte los grupos de expresión artística que ofrece la Universidad.​

## Muestras expresión artística

Muestras de expresión artística de eafitenses aficionados.

## Aula abierta para el Desarrollo Artístico

Disfruta de espacios artísticos libres en EAFIT.

## Noticias y eventos

Explora eventos destacados de Desarrollo artístico EAFIT: Festival de la Canción, Escénica, Días de Bienestar y más convocatorias artísticas.

Contacto - DptoDlloArtistico 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

DptoDlloArtistico

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Celular*? 

Correo electrónico*? 

Su comentario o solicitud*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)