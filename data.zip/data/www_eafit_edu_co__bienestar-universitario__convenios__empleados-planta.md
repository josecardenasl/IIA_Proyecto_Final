PadelHub

El pádel es un deporte de raqueta que se juega en parejas en una cancha cerrada, combinando elementos del tenis y el squash, se distingue por su dinamismo y estrategia, utilizando paredes de vidrio y malla metálica para mantener la pelota en juego.

Con reglas y puntuación similares al tenis, el pádel es accesible para todas las edades y niveles de habilidad, promoviendo tanto el ejercicio físico como la competitividad en un entorno social.

Beneficios físicos y mentales

Aliado clave para el bienestar personal

Mejora la forma física y la resistencia

Regula la presión arterial

Ayuda a mantener una buena densidad ósea

Mejora la flexibilidad

Fortalece músculos, tendones, ligamentos y articulaciones

Ayuda a perder peso

No es un deporte de contacto, tiene un riesgo mínimo de lesiones

**En convenio con la Universidad, tendrás lo siguientes beneficios:**

Alquiler de canchas de pádel con descuentos del 20%.

Venta de tiqueteras para clases individuales con el 10% al 15% de descuento.

Acceso a programas de formación deportiva en pádel, con el fin de brindar espacios de esparcimiento y actividad física.

Adquirir paquete básico para la organización de torneos de pádel, acordes a los objetivos y ejecución que se requiera, incluye suvenires, manutención y otros servicios.​

###### Contacto

**Andrés Correa**

3162384458

Contacto sede central PADEL HUB DE MODA: 3235117565

Para redimir el beneficio debes reservar a través de la APP EASY CANCHA y abonar al menos el 25% de la reserva.

​Al momento de hacer efectiva la reserva, deberás pagar el saldo restante donde el asesor de la sede aplicará el descuento una vez presentes el carnet de la Universidad EAFIT.​

Para mayor información de la compañía y de los productos que ofrece. Visita la página [https://www.padelhub.com.co/​](https://www.padelhub.com.co/%E2%80%8B)

*Aplica para las sedes PADEL HUB DE MODA, PADEL HUB BOLIVARIANA, y PADEL HUB PREMIUM PLAZA

Davivienda

**Servicios bancarios**

Apertura de cuenta de nómina: [Beneficios nó​​mina​](https://universidadeafit.widen.net/content/ec56g99zw3/jpeg/beneficios-nomina-eafit2.jpeg).​​

Convenio firmado para créditos de libranza con condiciones especiales en tasas de interés, plazos, cuotas fijas, conoce las ofertas que tenemos para ti. [Conoce más​](https://www.appdavivienda.com/?asesor=43873277&s=are-regional)

Opciones de financiamiento:

1.   Compra de cartera
2.   Libre inversión
3.   Fidelidad
4.   VehículoVivienda

**Código de asesor:**1037614895

Contacto

### Vanessa González Súarez

### Teléfono

Código de asesor: 1037614895

3207517944

### Correo

xiorley.gonzalez@davivienda.com​

### Estefania Echeverri Buitrago

### Teléfono

3137444248

### Correo

meechbui@davivienda.com

Aportes en línea

**Através de este convenio puedes acceder a:**

**Capacitación virtual:** acceso a cursos, foros y diplomados a través del siguiente [enlace](https://www.aulasaportesenlinea.com/empresasaportesenlinea)​.

Si el programa de interés se encuentra etiquetado como grabado puedes inscribirte por tu propia cuenta después de realizar el registro en el portal. Estos**cupos son ilimitados y son certificables.** Si los programas cuentan con la etiqueta próximo o en curso son los que se van a dar con docente en línea y para esto puedes solicitar la inscripción con: [seleccionydesarrollo@eafit.edu.co](mailto:seleccionydesarrollo@eafit.edu.co)dado que este tipo de cursos si es con cupo limitado.

**Programa Mas Para Todos-Aliados para personas:** Descuentos en establecimientos comerciales y empresariales a través del siguiente [enlace](https://masparatodos.aulasaportesenlinea.com/masparatodos#%21/inicio)​​:

**Nota:** Para hacer uso de este convenio, debes ingresar al respectivo enlace de interés y registrarte con tus datos personales, el correo de EAFIT y crear una contraseña​.

Banco de Occidente

###### Servicios bancarios

Convenio firmado para créditos de libranza con condiciones especiales en tasas de interés, plazos, cuotas fijas y sin codeudor. Los empleados que finalicen su vinculación laboral antes de la fecha de cancelación del crédito, se le realizará la deducción correspondiente al saldo adeudado de acuerdo a la autorización firmada por el empleado que se presenta al momento de hacer la solicitud del crédito.

*Para acceder al crédito de libranza, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Contacto

### Andres Felipe Porras

### Teléfono

3153646521

### Correo

afjesus@nexabpo.com

Seguro de exequias – SURA

Es un seguro que ofrece en caso de fallecimiento un reconocimiento económico sin exceder el valor asegurado ($5.000.000), distinto a los servicios exequiales que cubren el servicio funerario.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro de renta por hospitalización – SURA

​​Es en seguro que reconoce en caso de hospitalización y/o cirugía e incapacidad derivada de estas, una retribución económica según el plan que escoja.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

CEM – Emergencia Médica

​Es un servicio de atención médica para aquellas personas que deseen ser atendidas en la comodidad de su hogar o en el lugar donde se encuentren, ofrece la atención de urgencias, emergencias y consultas médicas.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Empleados cátedra: El empleado deberá realizar el pago directamente en Sura.

Empleados temporales: El empleado deberá realizar el pago directamente en Sura.

Estudiantes de pregrado: El estudiante deberá realizar el pago directamente en Coomeva.

Estudiantes de idiomas: El estudiante deberá realizar el pago directamente en Coomeva.

Egresados: El egresado deberá realizar el pago directamente en Coomeva.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Medicina Prepagada – Colsanitas

​Empleados planta, Empleados cátedra, Empleados temporales, Estudiantes de pregrado, Estudiantes de idiomas, Egresados, Pensionados, MARSHEs un plan de medicina prepagada que cubre en el territorio nacional, los gastos médicos y hospitalarios que se generen como consecuencia de una enfermedad o un accidente ocurrido al asegurado o beneficiario durante la vigencia del seguro, siempre que el evento no sea de origen preexistente o congénito.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro de salud - Allianz

​Es un seguro que cubre en el territorio nacional, los gastos médicos y hospitalarios que se generen como consecuencia de una enfermedad o un accidente ocurrido al asegurado o beneficiario durante la vigencia del seguro, siempre que el evento no sea de origen preexistente o congénito.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro de salud global – SURA

​Es un seguro que cubre en el territorio nacional y en el exterior, los gastos médicos y hospitalarios que se generen como consecuencia de una enfermedad o un accidente ocurrido al asegurado o beneficiario durante la vigencia del seguro, siempre que el evento no sea de origen preexistente o congénito. En forma opcional y mediante pago de prima adicional, los asegurados pueden incluir los anexos de consulta externa con médicos especialistas, urgencias y EMI.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro de salud clásica – SURA

​Es un seguro que cubre en el territorio nacional, los gastos médicos y hospitalarios que se generen como consecuencia de una enfermedad o un accidente ocurrido al asegurado o beneficiario durante la vigencia del seguro, siempre que el evento no sea de origen preexistente o congénito. En forma opcional y mediante pago de prima adicional, los asegurados pueden incluir los anexos de consulta externa con médicos especialistas, urgencias y EMI.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro de vida integral – SURA

​Es un seguro que ampara en caso de fallecimiento, enfermedad grave e incapacidad total y permanente al empleado y a su familia, este producto es modular, es decir, que además de los amparos informados el empleado podrá incluir coberturas como accidentes personales y renta.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro de vida patronal – SURA

Es un seguro que ampara en caso de fallecimiento, enfermedad grave e incapacidad total y permanente al empleado por un valor asegurado por 25 veces su salario y en el cual la Universidad aporta el 50% en el pago de la prima.

**Importante:**el subsidio o descuento que se otorga al empleado son beneficios de carácter discrecional que la Universidad EAFIT otorga a empleados y a sus beneficiarios, los cuales no constituyen salario en tanto no están retribuyendo el servicio que prestan los empleados.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro para autos – SURA

​Es un seguro integral, con amplias coberturas como responsabilidad civil, pérdidas parciales y totales por daños y hurto, asistencia en viajes, asistencia jurídica etc.

Contará con el servicio y acompañamiento en todo momento.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Empleados cátedra: El empleado deberá realizar el pago directamente en Sura.

Empleados temporales: El empleado deberá realizar el pago directamente en Sura.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

Seguro de hogar – Allianz

​Con este seguro su vivienda y contenidos estarán protegidos contra eventos de la naturaleza, desde incendios hasta derrumbes; el seguro de hogar le permite definir el valor asegurado de acuerdo al valor comercial de sus bienes, además tendrás asistencia en casos de plomería, cerrajería, electricista, entre otros.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

Empleados planta: Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pensionados: El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

*Aplica a nivel nacional.

Contacto

### Correo

delima​​@eafit.edu.co​

### Teléfono

310236​​6526

VetPlus

​​​​​​​​​Servicio de Medicina Prepagada Veterinaria con cobertura a nivel nacional. Presta servicios de medicina preventiva, atención y tratamiento de urgencias, enfermedades y accidentes.

En convenio con la Universidad, se obtiene descuento sobre la tarifa de los diferentes planes ofrecidos por VetPlus.

Aplica para perros y gatos.

**Aplica a nivel nacional.**

Emi

###### Salud en casa

Compañía de salud que presta servicios de atención médica a domicilio.

Aplica a nivel nacional.

Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Contacto

### Santiago Varela Giraldo

### Teléfono- Línea corporativa

3160282760

### Teléfono - Línea personal

3127084884

### Correo electrónico

santiago.varela@somosemi.com

###### Ahora te puedes afiliar a EMI fácil y rápido, consulta más información en el este [enlace​](https://afiliaciones.grupoemi-asegurate.com/afiliacion-en-linea?gad_source=1&gad_campaignid=20862075000&gbraid=0AAAAAqpHXTtgTVd_VYIJ3AKbA5DobhtHF&gclid=Cj0KCQjwjL3HBhCgARIsAPUg7a7znFwhwc9Qu6ZjFgAQtDhUz4s1V7WRguGv6ftZSnz495THLBOYlDAaAqRUEALw_wcB)

Bancolombia

###### Servicios bancarios

Convenio firmado para créditos de libranza con condiciones especiales en tasas de interés, plazos, cuotas fijas y sin codeudor. Los empleados que finalicen su vinculación laboral antes de la fecha de cancelación del crédito, se le realizará la deducción correspondiente al saldo adeudado de acuerdo a la autorización firmada por el empleado que se presenta al momento de hacer la solicitud del crédito.

Aplica a nivel nacional.

Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Contacto

### Ana Maria Gallego

Asesora Multisegmento.

### Teléfono

3206778356

### Correo

amghurta@bancolombia.com.co

Contacto

### Liliana Marcela Gómez

Asesora Multisegmento.

### Teléfono

3126248546

### Correo

liliagom@bancolombia.com.co

Prever

###### Seguro exequial

Plan de servicio exequial no reembolsable en dinero que otorga tarifas preferenciales sin límite en lazos de consanguinidad o afinidad.

También incluye servicio exequial para mascotas (perros y gatos).

## Pago por nómina

$ 3.650​ por afiliado.

## Pago por directo

Plan Previ familia Clásico $5.800 por cliente.

Plan Previ familia Especial $7.400 por cliente.

* Cancelando el trimestre obtiene 20% de descuento o si cancela semestre o

Aplica a nivel nacional.

Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

Pago por nómina solo aplica para empleados de planta.

Contacto

### Ángela María García

### Teléfono

(57) 3218383205​

### Correo

angela.garcia@prever.com.co

Directorio de servicios de salud

​​​​​​​​​​​Este servicio es atendido por un grupo de médicos especialistas e instituciones recomedados por la universidad que ofrecen excelentes servicios tarifas diferenciales a: estudiantes de educación formal, empleados con contrato laboral con EAFIT, estudiantes extranjeros, personas con contrato por prestación de servicios.

En el momento se estan actualizando los convenios con nuestros aliados medicos, las tarifas aún pueden variar​ [DIRECTORIO 2024.pdf](https://universidadeafit.widen.net/s/9rpr5q7slq/directorio-de-servicios-en-salud)

Fondo Nacional del Ahorro – FNA

El Fondo Nacional del Ahorro te ofrece beneficios para vivienda, estudios, cesantías o ahorro voluntario. Como afiliado puedes acceder a tasas preferenciales, asesoría personalizada y productos para el bienestar. En caso que requieras más información, puedes comunicarte con el asesor encargado, quien también está disponible para atención personalizada y presencial todos los martes, de 10:00 a.m. a 12:00 m., en el Bloque 29, Piso 4.

Contacto

### Juan David Gallego Loaiza

Asesor Comercial

### Teléfono

(57) 3004400337

### Correo

jdgallegol@fna.gov.co

Cosmo Schools

EAFIT y Cosmo School se unen para ofrecerte más oportunidades de crecimiento. A través de este convenio, tú y tu familia podrán acceder a beneficios y descuentos especiales en programas educativos y de bienestar, disponibles a nivel local y nacional.

**Beneficios que podrás disfrutar:**

5% de descuento en la matrícula

10% de descuento en servicios complementarios (extracurriculares, alimentación y servicios digitales)

4% de descuento por pronto pago en matrícula y pensión, aplicable al realizar el pago total desde octubre del año anterior.

Charlas o actividades exclusivas para colaboradores, virtuales o presenciales, según sea tu preferencia

Contacto

### Para más información, escríbenos a

beneficios.empleados@eafit.edu.co