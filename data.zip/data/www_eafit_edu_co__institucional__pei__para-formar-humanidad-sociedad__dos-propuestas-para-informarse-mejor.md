# Dos propuestas para informarse mejor

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Dos propuestas para informarse mejor

*    Dos Propuestas Para Informarse Mejor 

1.   El Coronamonitor es una plataforma que busca generar información permanente y con alta precisión geográfica que sea útil para analizar las dinámicas de la crisis sanitaria, en sus diferentes dimensiones. De acuerdo con las más de 12.953 encuestas en cerca de 186 municipios del país, en un poco más de tres meses, se ha podido recopilar información relacionada con síntomas, pruebas, provisiones, dinero disponible e ingresos, cadenas de suministro, salud mental y comportamiento durant​e la cuarentena. La iniciativa es liderada por el Centro de Investigaciones Económicas y Financieras de EAFIT con el apoyo de Universidad del Rosario, Corporación Universitaria Lasallista, Universidad EIA, Universidad Pontificia Bolivariana, Universidad del Norte, Cesde, Innovations for Poverty Action, Interactuar, Invamer, Proantioquia y Comfama.
2.   Un nuevo modelo para la gerencia pública de la pandemia es propuesto en el documento Supervivencia, vivencia y convivencia durante y después del covid-19, que presenta 10 estrategias para la adaptación social a la nueva normalidad. El texto es un documento “vivo” que será actualizado y ampliado incluso con nuevos aportes. La propuesta fue presentada por la Rectoría y expertos académicos de la Escuela de Humanidades, y de la Escuela de Economía y Finanzas, con el propósito de abrir una discusión pública y convocar a un gran foro de concertación entre actores del sector público, privado y sociedad civil.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)