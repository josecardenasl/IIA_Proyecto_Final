# Un epicentro en Medellín de la supercomputación

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Un epicentro en Medellín de la supercomputación

*    Un Epicentro En Medellín de La Supercomputación 

Aliado de la investigación y la innovación, Centro de Supercomputación Apolo tiene la facultad de ser un supercomputador de alto rendimiento, logrando que varias máquinas trabajen en paralelo resolviendo el problema científico que se presente en cualquier campo.

Desde 2012 cuando hizo su primera actividad en la Universidad EAFIT, han sido muchos los proyectos resueltos a través de cálculos matemáticos, modelos o simulaciones, que, por lo general, pueden llevar mucho tiempo para su ejecución, pero que gracias a este centro de computación es posible acortar considerablemente, facilitando a investigadores y docentes predecir resultados, anticipar problemas, superar retos y reducir a días procesos de cálculo de datos que tomaría siglos analizar en un computador normal: en 2019, Apolo computó lo que un computador normal hubiera realizado en 363 años.

Cada año se incrementa su uso. Integrantes de 25 grupos de investigación emplearon en 2019 sus recursos. Y aunque potencias como China y Estados Unidos lideran el área de la computación de alto rendimiento, Colombia también aporta con Apolo y otras mecanismos que funcionan en instituciones educativas de orden nacional, al desarrollo de este campo.

Las oportunidades que llegaron con Apolo para la academia y la industria han permitido analizar proce​sos destinados a comprender las capacidades físicas y químicas de un objeto, verificar el comportamiento de un río, determinar la manera óptima de transportar cemento a todo el país, entender cómo se adapta la ciudad respecto a microsismos, saber si un puente funcionará, entre muchos otros temas de investigación.

## Gracias a su actualización, Apolo pasó de 34,3 billones de operaciones por segundo a 388 billones, de los cuales 336 están dedicados a procesos de inteligencia artificial.

## 4. Educación de calidad

## 8. Trabajo decente y crecimiento ecónomico

## 9. Industria, inovacción e infraestructura

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate