# R​elación entre estudiantes

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# R​elación entre estudiantes

*    R​elación Entre Estudiantes 

En el marco del respeto se hace necesario revisar la relación entre estudiantes, aclarando que si bien en esta, no se presenta la condición de verticalidad, es fundamental enfatizar en algunos aspectos que contribuyan a garantizar una convivencia armónica, que permitan sentir confianza y seguridad en los entornos físicos y digitales que habitan los estudiantes.

​Construir confianza y experimentar seguridad, tanto en el campus como en los entornos digitales, constituiría entonces un mínimo ético no negociable para que el paso por la Universidad pueda ser una experiencia de vida significativa y transformadora. En ese sentido, se abordarán los mínimos éticos que deben tenerse en cuenta en la relación entre pares, con el fin de prevenir la transgresión de derechos y libertades al ser conscientes de cuál es el límite del otro.

#### Retos y lecciones aprendidas

Aportar a la construcción de una comunidad segura nos impulsa a compartir las lecciones aprendidas durante los últimos años en la Universidad, para visibilizar aquellas acciones que se han naturalizado en nuestros comportamientos y que hoy requieren revisarse, con el único propósito de generar reflexiones en torno a la validez de repetir y reproducir estereotipos y roles de comportamientos que hoy se reconocen como transgresores de respeto hacia cualquier persona.

#### Guía y recomendaciones relación entre estudiantes

Como ya se ha expresado en este documento, valoramos y confiamos en la integridad de cada uno de las personas que conforman la comunidad eafitense. Sin embargo, en todo proceso de formación es importante revisar permanentemente nuestras propias acciones para avanzar en la transformación del ser huma​no. Esto cobra relevancia a partir de los casos que se denuncian con ocasión del Protocolo para la Equidad de Género y la Sexualidad Diversa​, porque nos permiten ser conscientes de cuáles son aquellas conductas o comportamientos que sobrepasan el límite del respeto y, por ende, resquebrajan la confianza en el otro.

Uno de los casos más frecuentes que se abordan en el Comité de Inclusión y Equidad está relacionado con la manera de interactuar en las redes sociales. Los comentarios inapropiados o descalificadores sobre la forma de pensar, vestir, estudiar, expresarse; la orientación sexual y la identidad de género constituyen faltas al respeto, a la libertad y a la dignidad de la persona. En ese sentido, se recomienda abstenerse de cualquier expresión ofensiva o discriminatoria acerca de otro estudiante o compañero.

​Otro asunto que ha mostrado ser complejo es la divulgación de aspectos íntimos, como fotos de índole sexual o material pornográfico, toda vez que pueden representar un riesgo en dos sentidos: a) La persona que recibe el mensaje puede verse ofendida o acosada sexualmente y b) Una vez se publica un contenido se pierde el control del mismo. Por eso, se recomienda evaluar de manera estricta las posibles consecuencias al compartir este tipo de contenidos.

Los comentarios que se realizan con el propósito de ser chistosos, a partir de la reproducción de estereotipos de género o de roles asociados a la condición social o que van dirigidos contra una persona en particular, pueden afectar la seguridad y autoestima de un estudiante e incidir en su desempeño académico y personal. La invitación entonces es a reflexionar para buscar puntos de encuentro que nos permitan comprender el valor de la diferencia y evaluar los efectos que en el otro producen dichos comentarios.​

En estas reflexiones no desconocemos la manera como tradicionalmente en nuestra cultura se abordan las relaciones, a partir de la cercanía y el afecto y, en algunas ocasiones, aún del contacto físico. No obstante, en la cotidianidad entre estudiantes, es fundamental comprender que la diferencia entre un trato amable y la invasión a la privacidad puede residir en una línea muy delgada. En ese sentido, los roces, los tocamientos o cualquier acercamiento físico no consentido pueden generar molestia o incomodidad en quien los recibe. Por ello, es fundamental evitar insistir en dichos comportamientos, más aún si la otra persona ha expresado su rechazo hacia el mismo.​

Somos conscientes del ámbito personal e íntimo a partir del cual se establecen y desarrollan las relaciones afectivas entre estudiantes. Sin embargo, a partir de denuncias que han llegado al Comité de Inclusión y Equidad, resulta importante advertir en la necesidad de que, independientemente del curso que tome una relación afectiva en un momento determinado, es fundamental que cada una de las partes pueda seguir desarrollando con libertad y tranquilidad su vida universitaria.

En este punto, siempre será útil advertir sobre la pertinencia de reconocer que el límite en cualquier relación siempre lo impondrá el otro y reflexionar para comprender que no pueden forzarse situaciones a partir del propio deseo.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate