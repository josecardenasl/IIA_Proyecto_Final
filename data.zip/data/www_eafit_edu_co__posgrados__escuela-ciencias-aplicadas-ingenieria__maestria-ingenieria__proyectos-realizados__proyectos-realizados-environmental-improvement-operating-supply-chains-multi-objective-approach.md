# Proyectos realizados / Environmental improvement of operating supply chains: A multi-objective approach for the cement industry - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Proyectos realizados / Environmental improvement of operating supply chains: A multi-objective approach for the cement industry

*    Escuela Ciencias Aplicadas Ingenieria 
*    Proyectos Realizados / Environmental Improvement Of Operating Supply Chains: A Multi-objective Approach For The Cement Industry 

###### Nora Cadavid Giraldo

**Abstract**

Nowadays companies worldwide face a growing pressure to reduce the environmental impact of their manufacturing activities. However, the strategies used to achieve this goal are not clearly defined because of their conflicting relations with financial outcomes. In parallel, globalization trends imply that as companies grow, usually through mergers and acquisitions, their supply chains become more complex. The environmental improvement of these supply chains imply not only technical retrofit decisions aiming at adopting cleaner production technologies but also decisions regarding the structure of the supply chain itself. Making these decisions becomes a difficult task because of the large number of variables involved, and the diversity of the interactions among them. To tackle this problem, this research aims at providing a multi-objective solution approach for making technological retrofit decisions within an operating supply chain, so that both environmental and financial goals are best met. The proposed solution approach is applied to the case of an operating cement supply chain in Colombia. Several computational experiments were conducted, obtained results demonstrates that the proposed model is an effective tool for multi-objective improvement decisions making, towards a more sustainable production process.

**Keywords:**

Sustainable supply chain management, technological updating decision making, en-terprise wide optimization, multi-objective optimization, mixed integer linear programming.

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate