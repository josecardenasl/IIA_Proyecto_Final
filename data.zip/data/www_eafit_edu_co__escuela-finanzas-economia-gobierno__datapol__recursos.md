# Recursos DataPol - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Recursos

Para satisfacer los requerimientos en los diferentes servicios que atiende, DataPOL cuenta con modernos equipos y materiales.

*    Recursos DataPol 

1.   Programas estadísticos para el procesamientos de datos para sus trabajos: STATA, Statgraphics y R.
2.   Programas para el procesamiento de datos cualitativos: Pajek, QCA y NVivo.
3.   Computadores con alta capacidad para obtención y análisis de datos cualitativos y cuantitativos.
4.   Computadores para trabajo en línea (teleconferencias o trabajo en grupo que demande descarga de información).
5.   Espacio para reuniones de grupos de trabajo-investigativo para tratamiento de datos y procesamiento de datos o información.
6.   Apoyo y orientación en la obtención de información para investigaciones.
7.   Objetos de aprendizaje:

Recursos de articulación para la docencia en la asignatura de Matemáticas (exploración de matriz, intervalos, construcción de matriz, sumatoria y potenciación, lógica, conjuntos, razones y proporciones, álgebra, función lineal, función exponencial, ética).

Recursos de articulación para la docencia en la asignatura Estadística (estudios observacionales y experimentales, población, muestra, parámetros y estadísticos, tipos de variables, análisis descriptivo de variables cualitativas, variable dependiente e independiente, medidas de tendencia centra -media-, gráficos de distribución, diagrama de dispersión).

1.   Bases de datos: DNP, CINEP, Proyecto Programas partidistas, Barómetro de las Américas-LAPOP, Latinobarómetro, World Values Survey, Electoral Integrity Project, Proyecto Cómo Vamos, Democracy Barometer, Archivos electorales audio-video, Fondo Escobar-Maya, Bases de datos electorales de la Registraduría Nacional del Estado Civil.
2.   Publicaciones del Centro de Análisis Político

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)