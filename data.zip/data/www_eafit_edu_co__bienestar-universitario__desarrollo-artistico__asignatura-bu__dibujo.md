# Dibujo - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Dibujo

*    Dibujo 

###### Presentación

Dirigido a explorar los procesos básicos del dibujo de manera personalizada, enfocándose en ejercicios para el dominio de la técnica, y el uso adecuado de las herramientas y materiales usados en el dibujo clásico, llegarás a dominar la técnica y sus distintos materiales, mostrándote una oportunidad para que descubras mundos nuevos y maneras propias de aproximarte al quehacer artístico.

###### Evaluación

70% Seguimiento.

30% Final.

###### Contenido

Muestra de dibujos de grandes maestros para motivar al alumno al dibujo.

Comienzo de la técnica del dibujo: manejo del lápiz y sombras.

Seguimiento del trabajo pictórico, con intervención de más materiales, lápices, papeles, etc.

Exposición de dibujos y técnicas realizadas por los alumnos.

Manejo de la técnica de dibujo en figura humana: la anatomía y el retrato.

Trabajo libre donde habrá un debate del manejo de técnica.

Manejo de técnica que escoja el estudiante, creatividad y dominio de composición.

###### Bibliografía

Parramón, J.M. (2003) El Gran Libro del dibujo. España: Parramón Ediciones, S.A.

Parramón, J.M. (1978) Así se compone un cuadro. España: Parramón Ediciones, S.A.

Parramón, J.M. (2001) El rincón del pintor – Cabeza y retrato. Barcelona: Espuma.

Loomis, Andrew (1971) How to Draw and Paint Figures in Action. California, U.S.A: Walter Foster Publishing, Inc.

###### Páginas Web

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)