# Gender, diversity and inclusion

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

Discover your profile at EAFIT

Are you a student, professor, graduate, or part of an organization? Explore the options and find the personalized information EAFIT has for you. Click on your profile and access resources, news, and events designed especially for you. Your EAFIT experience starts here!

**Your EAFIT experience starts here!**

Students and graduates

Employees

Teachers

Children and young people

Organizations

Close profiles

Information for you

*   That's EAFIT

Return

*   Study at EAFIT

Return

*   Science, Technology and Innovation

Return

*   Connecting with organizations

Return

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Accessibility

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Language

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Information for you

Look for 

Search

Menu

# Gender, diversity and inclusion

We promote and work towards a culture of respect and a life free from violence and discrimination related to gender and diversity; we welcome and respect difference and offer mediation mechanisms to overcome differences. 

 We also facilitate collaboration among the various departments of the University to offer equal opportunities to all individuals in accessing and remaining at the institution and, in the case of students, also for their timely graduation.

*    Gender, Diversity and Inclusion 

Desplegar menú

Our guidelines

Previous card Next card

Declaration of our commitment to diversity, inclusion and pluralism

Inventory of situations, analysis, and protocol

Dictionary of equity, diversity and inclusion

Report on cases handled by the gender, diversity and inclusion office in 2025

Protocol for a life free from violence and discrimination

Protocol for a life free from violence and gender-based discrimination

Diversity, equity and inclusion policy

Inclusive Education Guide

##### Our protocols

###### Protocol for a life free from violence and gender-based discrimination

The Directorate of Human Development and University Welfare, with its philosophy of mutual care and a rights-based approach based on the principle of human dignity, is aware of the importance of promoting a culture of respect, with zero tolerance for violence, discrimination, and all harmful acts that affect people morally, psychologically, and physically, in relation to gender, sex, personal identity, free development of personality, human dignity, freedom, and equality.

Therefore, this Protocol, which is subject to review and reform, incorporates the lessons learned and experiences acquired since 2018, when the Academic Council approved the Protocol for Gender Equity and Diverse Sexualities, with two main purposes: first, to include preventative measures, that is, to promote ongoing reflection and actions aimed at fostering an academic community committed to building respectful relationships that embrace difference and aware of the prejudices and stereotypes that lead to the violation of rights and the exclusion of individuals or social groups, with the hope of contributing to the country's cultural transformation. Second, to establish a support pathway to protect the rights of those who claim to have been violated as a result of acts of discrimination, harassment, mistreatment, and violence based on gender and diverse sexualities.

Las acciones y estrategias que se desarrollen en virtud de la prevención y el abordaje de los casos en la ruta de atención se harán dentro de un marco de mediación con un enfoque restaurativo, que busca aportar a la solución de las diferencias con la participación directa de las personas involucradas y, en donde, prime la verdad, la reparación y la no repetición de los hechos lesivos, evitando un daño mayor. No obstante, en caso de ser necesario, el asunto podrá remitirse a las instancias encargadas institucionalmente de investigar y sancionar.

El Protocolo de EAFIT consta de: 1. Principios. 2. Ámbitos de aplicación. 3. Responsables de la aplicación y del seguimiento del Protocol​o. 4. Rutas de prevención y atención. 5. Atención a terceros. 6. Implementación y seguimiento. 7. Glosario y Marco de referencia.

Los principios que sirven de fundamento al presente Protocolo son los siguientes:

**1.1​​. Debida diligencia:** con enfoque de derechos humanos, la Institución oportunamente activará las rutas de atención que se prevén en este Protocolo, con el fin adoptar las medidas de protección eficaces que requiera el caso, y evitar la revictimización y la vulneración de los derechos de las personas.

**1.2. No discriminación:** ninguna persona podrá ser objeto de trato excluyente, perjudicial o arbitrario debido a su género, sexo, orientación o preferencia sexual y de cualquier manifestación relacionada con la pertenencia étnica-racial, el estrato socioeconómico, la discapacidad y la neurodiversidad.

**1.3. Igualdad:** todas las personas nacen libres e iguales ante la ley y, por lo tanto, deben recibir el mismo trato y protección por parte de las autoridades, y gozar de los mismos derechos, oportunidades y libertades sin ninguna discriminación por razones de sexo, raza, origen nacional o familiar, lengua, religión, opinión política o filosófica (Constitución Política, art. 13).

**1.4. Libre desarrollo de la personalidad:** la facultad que tienen los individuos de realizar su proyecto de vida conforme a sus valores, intereses, creencias y convicciones, sin más límites que los derechos de los demás y el orden jurídico (Corte Constitucional, Sentencia T 077 de 2016).

**1.5. Autonomía de la voluntad:** toda persona puede disponer de sus derechos por sí misma, sin restricción alguna, salvo los límites consagrados en la Constitución y en la ley.

**1.6. Integridad:** de conformidad con los valores institucionales de la Universidad, la Integridad se erige como virtud fundante que inspira los actos de todos los seres humanos y, en especial, en aplicación del presente Protocolo, los relacionados con la probidad, entereza en todas las acciones, la rectitud en el desempeño y acatamiento de las normas y el respeto de la diversidad.

**1.7. Enfoque diferencial:** el presente Protocolo busca brindar y garantizar un tratamiento especial y diferenciado a las personas con discapacidad, a las comunidades étnicas y a las personas con vulnerabilidad económica, con el fin de visibilizar las barreras para el acceso, la permanencia y la graduación, y adoptar medidas que conduzcan a respetar y proteger sus derechos, la individualidad, la diversidad y el reconocimiento del otro.

**1.8. Enfoque interseccional:** al activar las rutas de prevención y atención que prevé el Protocolo, se identificará y analizará si en una misma persona confluyen distintos marcadores sociales debido a su género, etnia, capacidad económica, diversidad funcional, entre otros, con el fin de adoptar acciones afirmativas que conduzcan a garantizar la igualdad material y formal en el acceso y disfrute de todos los derechos, bienes y servicios en la Institución educativa.

**1.9. Acciones afirmativas:** son las medidas encaminadas a equiparar los derechos de las personas que se encuentran en situación de desigualdad, debido a la pertenencia étnico-racial, el estrato socioeconómico, la discapacidad o la neurodiversidad.

**1.10. Flexibilidad:** el presente Protocolo será objeto de revisión y actualización con el fin de dar respuesta a los retos institucionales para promover y acoger la diversidad.

**1.11. Corresponsabilidad:** todos los miembros de la comunidad universitaria son sujetos activos y responsables del mutuo cuidado, no violencia y la no discriminación que se formula en el presente Protocolo. Así mismo, para la implementación, cumplimiento y seguimiento de este Protocolo, se trabajará articuladamente desde la Dirección de Desarrollo Humano con las distintas dependencias administrativas y Escuelas de la Universidad, con el fin de avanzar hacia la igualdad y garantía de oportunidades de todas las personas.

**1.12. Atención integral:** en la ruta de atención e inclusión, conforme a este Protocolo, se atenderá a la víctima en su esfera física, psicosocial y humana, respetando el cumplimiento de las normas jurídicas que apliquen al caso.

**1.13. Atención inclusiva:** en la ruta de atención e inclusión conforme a este Protocolo, siempre se tendrá en cuenta las condiciones personales de la víctima, la perspectiva de género, la orientación sexual, la pertenencia étnica racial, el estado de vulneración económica, la discapacidad y la neurodiversidad con el fin de garantizar la efectividad del principio de no discriminación.

**1.14. Confidencialidad:** de todas las actuaciones, acciones, medidas urgentes y de protección que se apliquen en la ruta de atención, se garantizará la absoluta reserva de todos aquellos hechos, circunstancias y datos que se conozcan debido a esta política, respetando la información personal y la intimidad de la víctima y del presunto agresor en el marco de la protección del habeas data.

**1.15. Debido proceso:** a todas las personas involucradas en actos de discriminación, violencia de género, violencia sexual, agresiones físicas, psicológicas y morales y demás actos lesivos a la dignidad humana, al libre desarrollo de la personalidad, a la libertad, se les garantizará que en el trámite que prevé el presente Protocolo se observarán los principios de imparcialidad, justicia, transparencia y celeridad.

**1.16. Imparcialidad:** los miembros del Comité de Género, Diversidad e Inclusión brindarán un trato respetuoso y digno a las partes involucradas en la investigación, manteniendo el equilibrio y realizando los ajustes necesarios para superar las barreras de desigualdad de aquellas personas históricamente discriminadas debido al género, de la sexualidad diversa, de la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y la neurodiversidad.

**1.17. Accesibilidad:** el presente Protocolo se divulgará entre la comunidad eafitense y el público en general. Para este propósito se utilizará un lenguaje claro y sencillo.

**1.18. Protección:** se garantizará la ejecución de la ruta de atención e inclusión con el fin de evitar la revictimización y asegurar las medidas de prevención necesarias, tendientes a evitar que en el claustro universitario y en las demás dependencias de la Universidad se realicen actos lesivos indicadores de maltrato, hostigamiento, discriminación y violencia.

**1.19. Celeridad:** se dará prioridad para adelantar el trámite previsto en el presente Protocolo de manera ágil y rápida.

**1.20. Prohibición de represalias:** ningún miembro de la Universidad podrá realizar acciones que tengan como propósito castigar o sancionar a aquellas personas que intervinieron como testigos, como informantes, o como apoyo a la víctima.

**1.21. Impedimento y recusación:** cualquiera de los miembros del Comité de Género, Diversidad e Inclusión deberá declararse impedido para participar en el trámite en caso de tener parentesco por consanguinidad en cuarto grado, o segundo de afinidad, ser cónyuge, compañero o permanente de la víctima o reportado. Asimismo, si existe enemistad grave o amistad íntima entre alguno de los miembros del Comité y la víctima, o de la persona contra la que se dirige el reporte. En tal caso, la víctima o el reportado podrán recusarlos debido al interés que pueda condicionarlos en relación con el trámite.

El presente Protocolo se aplicará sin excepción para toda la comunidad eafitense y demás personas que accedan a las diferentes instalaciones de la Universidad, con el fin de proteger los derechos, prevenir y eliminar toda forma de discriminación, hostigamiento, ​maltrato y violencia que tengan su causa en la pertenencia étnica-racial, en el estrato socioeconómico, en la discapacidad y en la neurodiversidad. Asimismo, se activará en los casos que más adelante se señalan.

El Comité de Género, Diversidad e Inclusión valorará las distintas situaciones que las personas reporten y, de conformidad con lo detallado más adelante bajo el enunciado de ruta de atención, asumirá el conocimiento del respectivo caso, o podrá​​​ remitir a los responsables de investigar y sancionar, según lo definido en este Protocolo, en el Estatuto Profesoral, en el Reglamento Interno de Trabajo, y en los Reglamentos académicos de programas de pregrado y de posgrado.

Las rutas que prevé​​ el Protocolo no constituyen un requisito previo para acudir al proceso disciplinario, por consiguiente:

La víctima en cualquier momento podrá decidir si activa directamente el proceso disciplinario, sin que previamente se requi​era agotar el trámite que prevé el presente Protocolo.

El Comité de Género, Diversidad e Inclusión, sin avocar el conocimiento del caso, podrá remitir para su investigación a la insta​​ncia que corresponda cuando así lo considere necesario debido a las circunstancias de tiempo, modo y lugar en que se desarrollan los hechos; o en aquellos eventos en que la víctima o el presunto responsable no expresen su consentimiento para participar en el abordaje pedagógico.

En consecu​encia, siempre que así lo consienta la víctima y el presunto responsable, se activará la ruta de atención que prevé el presente Protocolo.

**2.1.Ámbito de aplicación por el lugar dónde ocurren los hechos**

Se activará​​ el presente Protocolo

Cuan​​do los hechos ocurran en cualquiera de las instalaciones físicas de la Universidad.

Cua​​ndo los hechos ocurran durante actividades académicas, deportivas, culturales o laborales que tengan lugar por fuera de la Universidad.

Cua​ndo los hechos ocurran en los espacios digitales de que dispone o administra la Universidad; esto es, correos institucionales, Teams, redes sociales, entre otros.

**​2.2. Ám​​bito de aplicación por la naturaleza de las conductas**

Con el fi​​n de orientar a los integrantes de la Institución, a continuación, se señalan, a modo de ejemplo, algunas de las conductas asociadas a discriminación, hostigamiento, maltrato y violencias que tengan su causa en la pertenencia étnica-racial, en el estrato socioeconómico, en la discapacidad y en la neurodiversidad; el listado, se advierte, es enunciativo, mas no taxativo:

Di​​scriminar, excluir, agredir física o verbalmente, maltratar, ofender o ridiculizar a cualquier persona por causa de la diversidad económica, de la pertenencia étnica-racial, de la discapacidad y de la neurodiversidad.

De​​scalificar las competencias profesionales o intelectuales de cualquier persona debido a la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y de la neurodiversidad.

Re​alizar comentarios ofensivos, burlarse de una persona debido a la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y de la neurodiversidad.

Pro​​hibir, restringir o limitar el acceso a cualquier instalación de la Universidad por causa de la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y de la neurodiversidad.

Realizar gestos o utilizar palabras obscenas, observaciones, insultos de manera directa o a través de redes sociales, correos electrónicos, llamadas o mensajes de texto por causa de la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y de la neurodiversidad.

Violentar psicológica, física, sexual y económicamente a cualquier persona debido a la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y de la neurodiversidad.

Negar un derecho, un servicio, una solicitud a cualquier persona debido a la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y de la neurodiversidad.

Publicar, difundir en redes sociales, medios de comunicación masiva, mensajería instantánea o a través de cualquier otro medio de divulgación aspectos de la vida íntima y personal de un tercero sin su consentimiento, debido a la pertenencia étnica-racial, del estrato socioeconómico, de la discapacidad y de la neurodiversidad.

​Las conductas derivadas del desconocimiento del presente Protocolo se asumen incorporadas al régimen disciplinario que corresponda según el caso; para el inicio de los procesos disciplinarios, se remitirá a la instancia respectiva de acuerdo con el rol de la persona denunciada, y de conformidad a lo previsto en el Reglamento Interno de Trabajo, en el Reglamento Académico de Programas de Pregrado y en el Reglamento de Posgrado.

**3.1.Comité de Género, Diversidad e Inclusión**

El Comité de Género, Diversidad e Inclusión es el organismo encargado de diseñar, dirigir, implementar y hacer seguimiento a las acciones y estrategias de este Protocolo. Está integrado por quien lidere cada una de las siguientes dependencias que se enuncian a continuación:

Director (a) de Desarrollo Humano o su delegado, quien lo preside.

Secretaria (o) general o su delegado.

Director (a) del Centro Humanista o su delegado.

Dos decanos, estos elegirán cuál de ellos hará parte del Comité.

Profesional en psicología.

Un representante estudiantil ante el Consejo Académico.

La coordinadora de Género, Diversidad e Inclusión.

Igualmente, el Comité podrá tener invitados permanentes u ocasionales según la temática a analizar.

**3.1.1. Funciones del Comité de Género, Diversidad e Inclusión**

El Comité tendrá dentro de sus funciones las siguientes:

Definir las estrategias de sensibilización al interior de la Universidad para prevenir los actos de discriminación, hostigamiento, maltrato, violencias basadas en la pertenencia étnico-racial, la capacidad económica, la discapacidad y la neurodiversidad.

Definir los programas de formación para los integrantes de la comunidad eafitense en temas de diversidad e inclusión.

Hacer seguimiento a los casos atendidos debido al Protocolo, con el fin de establecer estrategias dirigidas a hacer visibles los estereotipos, prejuicios e imaginarios culturales que propician la reiteración de conductas asociadas a vulneración de derechos.

Definir los indicadores que permitan hacer seguimiento a los casos reportados y dar insumos para implementar acciones preventivas, correctivas y de mejora.

**3.1.2.Quórum**

Para todos los efectos, el Comité tendrá un quórum deliberatorio y decisorio. Para el primero, se requiere asistencia mínima de 4 integrantes del Comité; para el segundo, se requiere la participación mínima de 5 integrantes para decidir. Las decisiones se tomarán por mayoría simple.

**3.1.3.Reuniones del Comité de Género, Diversidad e Inclusión**

El Comité sesionará ordinariamente cuatro veces al año: en marzo, junio, agosto y noviembre. También podrá sesionar extraordinariamente por solicitud de cualquiera de los integrantes del Comité; y su convocatoria estará a cargo de la Coordinadora de Género, Diversidad e Inclusión.

Parágrafo. La secretaría técnica del Comité estará a cargo de la coordinadora de Género Diversidad e Inclusión, quien además elaborará el acta del desarrollo de cada una de las reuniones.

**3.2.Comisión de análisis de casos**

Acompaña y emite recomendaciones para la atención inicial y, además, evalúa el caso para determinar el trámite a seguir y las medidas urgentes y de protección necesarias para mitigar cualquier daño mayor a las personas involucradas en el caso reportado, de conformidad a lo señalado en el Protocolo.

**3.2.1. Las funciones principales de este comité son:**

Decidir si por la gravedad de la conducta denunciada, la reiteración de la misma, por el incumplimiento a los acuerdos de la medidas pedagógico-restaurativas o las circunstancias de tiempo, modo y lugar en que se presentaron los hechos, el caso reportado debe remitirse a otras instancias institucionales; esto es, Comité de Convivencia Laboral, al Comité Disciplinario o a la Dirección de Desarrollo Humano, o la Secretaría General cuando la persona involucrada en los hechos sea un contratista.

Evaluar los posibles riesgos que afecten o puedan afectar, entre otros, la integridad física, emocional, el proceso de enseñanza o aprendizaje de la víctima, con el fin de adoptar medidas urgentes y de protección para la misma.

Informar a la Secretaría General y la Dirección Administrativa y Financiera para la adopción de todas aquellas medidas tendientes a informar al contratante cuando el caso reportado involucre a un contratista, su personal y, además, para que se adopten los trámites necesarios con el propósito de iniciar la investigación que corresponda.

​

​**3.2.2 Integra​ntes:**

Direct​or de Desarrollo Humano-Bienestar Universitario o su delegado.

Coor​dinación de Género, Diversidad e Inclusión.

Jef​​e de Desarrollo Estudiantil o su delegado, intervendrá cuando el presunto responsable tiene la calidad de estudiante.

J​efe del programa de la Escuela, intervendrá cuando el presunto responsable tiene la calidad de estudiante.

Dire​​ctor de área de la Escuela, intervendrá cuando el presunto responsable tiene la calidad de profesor.

Jefe ​inmediato, intervendrá cuando el presunto responsable tiene la calidad de colaborador.

Invit​​ados especiales.

**3.3.Coordinadora de Género, Diversidad e Inclusión**

**3.3.1 Funciones de la coordinadora de Género, Diversidad e Inclusión**

La coordinadora tendrá dentro de sus funciones las siguientes:

Activar la ruta de atención de conformidad a lo señalado en este Protocolo, y tomar las medidas que permitan asegurar que se asumirá el conocimiento de cada uno de los casos reportados, sin perjuicio de que estos puedan remitirse a otras instancias institucionales o archivarse por falta de información, de todo ello se dejará constancia por escrito.

Convocar al Comité de Análisis de Casos con el fin de evaluar los posibles riesgos que afecten o puedan afectar, entre otros, la integridad física, emocional, el proceso de enseñanza o aprendizaje de la víctima; y también para adoptar medidas urgentes y de protección para la misma.

Llevar un registro que permita tener trazabilidad de cada uno de los casos desde el momento del reporte hasta la finalización del abordaje previsto en el Protocolo, preservando la identidad de los participantes, precisando la fecha de ocurrencia de los hechos, la fecha del reporte, el rol de los participantes en la Universidad, la Escuela o área administrativa de los sujetos involucrados en el caso, y precisando el resultado de cada uno de los asuntos tramitados, el seguimiento a los acuerdos y la fecha de cierre.

Convocar al Comité de Análisis de Casos para adoptar medidas urgentes y de protección a la víctima.

Sugerir al Comité de Género, Diversidad e Inclusión las estrategias de sensibilización al interior de la Universidad para prevenir los actos de discriminación, hostigamiento, maltrato, violencias basadas en la pertenencia étnico-racial, la capacidad económica, la discapacidad y la neurodiversidad.

Sugerir al Comité de Género, Diversidad e Inclusión programas de formación para los integrantes de la comunidad eafitense en temas de diversidad e inclusión.

Hacer seguimiento a los compromisos pactados por los intervinientes en la mediación para validar el cumplimiento de estos.

Convocar al Comité de Análisis de Casos para determinar las consecuencias del incumplimiento de un acuerdo pedagógico; esto es, si se reabre el trámite previsto en el Protocolo, o si se remite a la instancia disciplinaria que corresponda.

Presentar en las sesiones ordinarias del Comité de Género, Diversidad e Inclusión un informe sobre el número de casos atendidos y el resultado del trámite.

Convocar de manera extraordinaria al Comité de Análisis de Casos e Inclusión para definir estrategias de acompañamiento cuando el caso así lo requiera, o para evaluar la remisión a otras instancias institucionales.

La Universidad EAFIT declara su compromiso con los principios de no tolerancia y no neutralidad frente a actos de violencia, discriminación, hostigamiento, maltrato e irrespeto de las personas debido a la per​​​tenencia étnica-racial, del estrato socioeconómico, de la sexualidad diversa, la discapacidad y la neurodiversidad. Por ello, para prevenir y atender los hechos que se enmarquen en tales conductas, se establecen las siguientes rutas de prevención y de atención.

**4.1. Ru​​tas de Prevención**

La Institución continuará promoviendo una cultura del mutuo cuidado y de respeto entre todos sus integrantes, con la que se valore la diferencia, se propicien acciones para alcanzar la igualdad de oportunidades para​ todas las personas y se rechace cualquier acto de violencia. Para prevenir, detectar, diagnosticar y hacer seguimiento al presente Protocolo, se implementarán, entre otras, las siguientes acciones.

**4.1.​​1. Sensibilización y difusión:** la Institución realizará campañas de sensibilización y de difusión de este Protocolo con el fin de evitar o minimizar los posibles casos de violencia, discriminación, hostigamiento, maltrato e irrespeto de las personas relacionados con la pertenencia étnica racial, el estrato socioeconómico, la discapacidad y la neurodiversidad.

**4.1.2. Detección:** la Institución adelantará estrategias para realizar un diagnóstico, con el propósito de detectar las posibles transgresiones a los derechos de las personas y su diversidad, y con el fin de adoptar las acciones dirigidas a prevenir y evitar cualquier manifestación de maltrato, hostigamiento discriminación y violencia.

**4.1.3. Formación:** la Institución implementará estrategias dirigidas a capacitar en diversidad e inclusión a los profesores, estudiantes y personal administrativo, con el fin de sensibilizar y concientizar sobre el reconocimiento del otro, procurando la transformación del imaginario social anclado en prejuicios y estereotipos sobre la diversidad.

**4.1.4. Investigación:**la Institución fomentará las líneas de investigación sobre diversidad e inclusión, con el fin de propiciar espacios académicos de reflexión con miras a superar las brechas de inequidad y exclusión.

**4.1.5. Acompañamiento:**la Institución establecerá los mecanismos necesarios y adecuados para la eficaz implementación y seguimiento de este Protocolo, lo que comprende la asistencia directa y personalizada a las personas sobre las distintas etapas que conforman la ruta de atención de que trata este Protocolo.

**4.1.6. Orientación:** la Institución establecerá los responsables de brindar asesorías y orientación a los integrantes de la comunidad académica que así lo requieran, la que comprenderá las rutas de atención y prevención para conocer y atender cualquier hecho de violencia, discriminación, hostigamiento, maltrato e irrespeto de las personas que tengan su causa en la pertenencia étnica-racial, en el estrato socioeconómico, en la discapacidad y en la neurodiversidad.

**4.2. Rutas de atención**

Con el compromiso institucional de obrar con debida diligencia y cuidado, y trabajar para generar espacios de confianza y seguros, libres de cualquier acto de discriminación, hostigamiento, maltrato y violencias que tengan su causa en la pertenencia étnica-racial, en el estrato socioeconómico, la discapacidad y la neurodiversidad, se observarán los siguientes criterios de atención.

**4.2.1. Procedimiento**

**4.2.1.1. Reporte de la queja**: Cualquier persona podrá reportar una situación de discriminación, hostigamiento, maltrato y violencia que tengan su causa en la pertenencia étnica-racial, en el estrato socioeconómico, en la discapacidad y en la neurodiversidad, a través de la línea de transparencia, cuyos enlaces son:

Línea telefónica gratuita y confidencial para llamadas nacionales desde su celular o número fijo:

01-8000-11-11-55

Lo anterior, sin perjuicio de que pueda reportarse la queja directamente ante la coordinadora de Género, Diversidad e Inclusión.

En ningún caso se exigirán pruebas, para asumir el conocimiento del caso. Bastará el solo dicho de la víctima para activar la ruta de atención.

Cuando el reporte provenga de un anónimo, no se activará el trámite a cargo del Comité de Género, Diversidad e Inclusión, salvo que el hecho reportado permita adelantar la investigación de oficio por contener la información del posible presunto responsable y las situaciones de tiempo, modo y lugar en que ocurrieron los hechos.

En todos los eventos en que el acto violento o agresión ocurra en las instalaciones de la Universidad, cualquier persona podrá en ese mismo momento activar la línea 911 de emergencias de la Institución, la que conforme a su Protocolo se encargará de adoptar las medidas de atención urgentes que el caso requiera.

**4.2.1.2. Inicio de la ruta: Atención integral.**

**4.2.1.2.1. Entrevista con la víctima:** El Comité de Género, Diversidad e Inclusión, dentro de los cinco días hábiles siguientes a la recepción del reporte, citará a quien lo formula con el fin de ampliar, aclarar o precisar su declaración.

Desde el inicio de la ruta:

Se evitarán las repeticiones innecesarias y los comentarios o juicios acerca de la conducta de la víctima, o las expresiones tendientes a atribuir responsabilidades sobre los hechos reportados, o expresar sentimientos de consideración o lástima.

No se admitirán los juicios u opiniones personales por parte de quienes intervengan en la entrevista.

Se ofrecerá atención y acompañamiento psicológico, lo que comprenderá la evaluación del riesgo psicosocial en el caso de los empleados.

Se ofrecerá orientación clara y completa sobre el alcance y trámite de la mediación.

Se ofrecerá orientación clara y completa sobre el trámite del proceso disciplinario y se le advertirá sobre su derecho a recibir información completa y oportuna del estado del trámite por parte del Comité Disciplinario, si este se iniciara.

Se ofrecerá orientación clara y completa sobre las acciones jurídicas que protegen el derecho que se afirma fue vulnerado por un tercero, lo que comprende el proceso penal, en el evento en que se advierta que la conducta reportada puede constituir un delito.

Se evaluarán las posibles situaciones de riesgo en que se encuentre la víctima, con el fin de adoptar medidas urgentes y de protección.

Consentimiento de la víctima. Para dar inicio al presente abordaje, es necesario el consentimiento de la víctima para participar en esta mediación; lo que se hará una vez que esta conozca el alcance del presente trámite. Del consentimiento se dejará constancia escrita.

**4.2.1.2.2. Medidas urgentes y de protección:** Después de la entrevista con la víctima, el Comité de Análisis de Casos analizará las posibles situaciones de riesgo en que se encuentre la víctima, con el fin de adoptar medidas urgentes y de protección; entre las cuales se citan como simplemente enunciativas, mas no limitativas, las siguientes:

Flexibilizar la asistencia a clase y las evaluaciones de la víctima y del presunto responsable, en el evento en que el estado emocional de los mismos interfiera con su proceso de aprendizaje.

La reubicación laboral del presunto responsable.

Cambios en los horarios de trabajo del presunto responsable cuando se trate de un empleado de la Universidad, para evitar escenarios de confrontación o de revictimización.

Las medidas urgentes permanecerán el tiempo que se requiera para evitar un daño mayor a la víctima.

**4.2.1.2.3. Escuchar a la persona contra la cual se formule la queja:** Dentro de los cinco días hábiles siguientes a la entrevista con la víctima que reporta el caso, o del tercero que reporta, se citará a la persona contra la cual se formula la queja para escuchar su versión sobre los hechos reportados. En esa entrevista se le informará al presunto responsable del procedimiento a seguir, y del derecho a recibir información completa y oportuna del estado del presente trámite. Así mismo, se le ofrecerá apoyo psicológico por parte de la Universidad, lo que comprende la valoración del riesgo psicosocial, si se trataré de un empleado.

Consentimiento del presunto responsable. Para dar inicio al presente abordaje, es necesario el consentimiento del presunto responsable para participar en este abordaje de mediación, lo que se hará una vez que este conozca el alcance del presente trámite. Del consentimiento se dejará constancia escrita.

**4.2.1.2.4. Mediación:** Consciente del poder transformador de la educación, la Universidad propiciará espacios de mediación orientados por un tercero imparcial que trabaje en la construcción de soluciones que permitan superar los hechos victimizantes. Con la mediación también se busca enseñar, aprender, desaprender, reconocer y crear conciencia sobre los propios comportamientos, sesgos, estereotipos y conductas que inciden en la continuidad de las violencias y de los actos de discriminación. En consecuencia, en cada caso se valorará la necesidad de reparar el daño que se ha causado, y el compromiso para evitar la repetición de los hechos reportados.

Durante toda la mediación, se garantizará el principio de confidencialidad y de protección de la identidad de la persona que formule la queja; por lo tanto, se dispondrá de un código alfanumérico para identificar el caso tratado. En las comunicaciones que se produzcan durante el trámite, solamente se identificará a los intervinientes con dicho código.

Si el trámite de mediación termina con un acuerdo, se dejará constancia por escrito de este, la que se suscribirá por las partes intervinientes. Corresponderá a la coordinadora de Género, Inclusión y Diversidad hacer seguimiento al cumplimiento de los compromisos acordados y, en caso de incumplimiento de estos, o de que se reitere la conducta que dio origen al presente trámite, se convocará al Comité de Análisis de Casos para determinar si se retoma el abordaje pedagógico o si se remite a otra instancia institucional.

**4.2.1.2.5. Remisión a otras instancias:** Como ya se expresó, el Comité de Género, Diversidad e Inclusión hará remisión del caso reportado en los siguientes casos:

Cuando la víctima así lo considere necesario, sin que previamente se requiera agotar el trámite que prevé el presente Protocolo.

Cuando debido a las circunstancias de tiempo, modo y lugar en que se desarrollan los hechos no sea pertinente la mediación.

En aquellos eventos en que la víctima o el presunto responsable no expresen su consentimiento para participar en la mediación.

Cuando fracase la mediación, y en concepto del Comité de Análisis de Casos, es necesario investigar para determinar si los hechos reportados ocurrieron o no y, por consiguiente, si hay lugar a una sanción.

Cuando fracasa la mediación y la víctima decide activar el trámite del proceso disciplinario.

Cuando el conocimiento de los hechos que se ponen en conocimiento corresponda a otras instancias institucionales; esto es:

Si se trata de fraude contra la integridad académica o violación al reglamento de Pregrado por parte de un estudiante, se remitirá al Comité Disciplinario.

Si se trata de un caso de maltrato, hostigamiento, violencia que no tenga su causa en la discapacidad, neurodiversidad, vulnerabilidad económica o pertenencia étnica racial, y cuando las personas involucradas son empleados de la Universidad, se remitirá al Comité de Acoso Laboral.

Si se trata de conductas propias de la relación académica se remitirá a la respectiva Escuela.

La Coordinadora de Género, Diversidad e Inclusión gestionará ante las instancias respectivas todas las gestiones tendientes a brindar la atención prioritaria que requiera la víctima para superar la afectación a su integridad física o psicológica

El trámite del proceso disciplinario es una instancia diferente e independiente de la mediación. Por consiguiente, en esa instancia no se podrá acceder a las conversaciones y grabaciones que se realicen durante la mediación, las que están protegidas por el principio de confidencialidad.

**4.2.1.2.6. Seguimiento de los casos atendidos:** El Comité de Género, Diversidad e Inclusión se encargará de realizar el seguimiento de todas las medidas y estrategias adoptadas en virtud de este Protocolo, con el fin de conocer el impacto en la comunidad y adoptar los correctivos necesarios para restablecer los derechos de las víctimas y evitar la repetición de las conductas investigadas en cualquier ámbito de la Universidad. El Comité determinará las fechas de seguimiento atendiendo a la situación particular, pero en todo caso el primer seguimiento se realizará tres (3) meses después de la decisión final del mismo Comité.​

**5.1. Niños, niñas o adolescentes**

En aquellos eventos en los que la víctima sea un niño, niña o adolescente, se tendrá presente la primacía de los derechos de los mismos que consagra la Constitución Nacional, la Convención sobre los Derechos del niño y el bloque de constitucionalidad, las disposiciones de protección y restablecimiento de derechos previstos en el Código de Infancia y Adolescencia que se consagra en la Ley 1098 de 2006. En todos los trámites que la Institución adelante con ocasión de estos hechos, además de lo descrito en los apartados anteriores, se tendrá presente lo siguiente:

Se garantizará el principio de confidencialidad.

Se protegerá la identidad del niño, niña o adolescente y de su grupo familiar.

Se informará de manera inmediata al representante legal o grupo familiar del mismo.

Se respetará el derecho a ser escuchados siempre.

El Comité y las distintas personas que debido a sus funciones deban participar tendrán presente que no podrán realizar comentarios desestimando la validez del testimonio del niño, niña o adolescente, debido a su edad, ni debido a estereotipos de género o discriminación por su orientación sexual, por la pertenencia étnica racial, por la discapacidad, la neurodiversidad y por su situación económica.

En aquellos casos en que el niño, niña o adolescente se encuentre en situación de peligro de su integridad física o psicológica, se informará a sus padres o al grupo familiar que haga las veces de cuidador, a Bienestar Familiar a través de la

Comisaría de Familia, o a las autoridades penales o de policía que corresponda. Cuando se sospeche que la agresión puede provenir de sus padres o del cuidador, solo se informará a Bienestar Familiar y a las autoridades que correspondan.

El Comité se abstendrá de provocar encuentros entre la víctima y el presunto responsable. 

Si se hace necesario el testimonio del niño, niña o adolescente dentro de la investigación que adelante la Institución, solo podrá recibirse su declaración si este se encuentra en presencia de sus padres o representantes legales, y, en todo caso, se procurará además la intervención de un psicólogo, como apoyo al menor para la libre expresión de su propio discurso.

**5.2. Personas con contrato de prestación de servicios con la Universidad, empleados de contratistas u outsourcing, y empleados de concesionarios**

En estos eventos, la persona que llegaré a ser objeto de discriminación, maltrato físico o psicológico dentro de las instalaciones de la Universidad, o con ocasión de los servicios que presta, en caso de ser necesario una atención inminente, se activará la ruta de atención de emergencia a través de la línea 911, para brindar los primeros auxilios a la víctima, lo que comprende la atención psicológica en caso de que así se requiera, y siempre que lo acepte la víctima; así mismo, se le brindará la orientación legal que requiera para activar la ruta de protección a sus derechos. De igual manera, la víctima podrá denunciar los hechos ante el Comité de Género, Diversidad e Inclusión para que la misma defina el procedimiento a seguir de acuerdo con los parámetros establecidos en este Protocolo.

Por otra parte, si la persona contra la cual se formula la denuncia se encuentra vinculada a la Universidad a través de contrato de prestación de servicios, o es empleado de contratistas, outsourcing, o empleados de concesionarios de la Institución, el Comité de Género, Diversidad e Inclusión informará a la Secretaría General y la Dirección Administrativa y Financiera para la adopción de todas aquellas medidas tendientes a informar al contratante, y para que se adopten los trámites necesarios con el propósito de iniciar la investigación que corresponda. Todo lo anterior sin perjuicio de que, según los términos del contrato, pueda invocarse la terminación de la relación contractual o la aplicación de las sanciones contractuales previstas en el respectivo convenio.

Si se evidencia la comisión de un ilícito, se formulará la denuncia ante las autoridades competentes, siempre que el delito o la conducta no sean de aquellos que la ley exija que deben denunciarse únicamente por la víctima.

**5.3. Estudiantes en semestre de práctica en entidades externas**

Cuando la presunta víctima se encuentre realizando su semestre de práctica profesional, y la conducta objeto de denuncia se haya presentado en la entidad en la cual se esté desempeñando, el Comité de Género, Diversidad e Inclusión conocerá el caso y procederá a informar la situación a la entidad a efectos de que determine la viabilidad de iniciar la investigación correspondiente. En todo caso, se activará la ruta de atención para la protección de la víctima acorde con lo contemplado en este Protocolo.

Así mismo, la Universidad analizará la pertinencia de continuar o no con el convenio de práctica profesional con la entidad en la que se presentaron los hechos.

**​5.4. Pasantes**

Si la víctima de maltrato, discriminación, violencia basadas en la pertenencia étnica racial, en la vulnerabilidad económica, en la discapacidad, en la neurodiversidad se encuentra realizando una pasantía en la Universidad, se activará la ruta de emergencia señalada por la Institución a través de la línea 911, para brindar los primeros auxilios a la víctima, lo que comprende la atención psicológica en caso de que así se requiera y lo acepte la víctima, y la orientación legal que requiera para activar la ruta de protección a sus derechos. De igual manera, la víctima podrá denunciar los hechos ante el Comité de Género, Diversidad e Inclusión para que la misma defina el procedimiento a seguir de acuerdo con los parámetros establecidos en este Protocolo.

Cuando se trate de conductas delictivas que no exijan la denuncia exclusivamente por parte de la víctima, se alertará a las autoridades policiales y judiciales competentes.

**5.5. Visitantes**

Si la víctima de maltrato, discriminación, violencia basadas en la pertenencia étnica racial, en la vulnerabilidad económica, en la neurodiversidad y en la discapacidad no tiene ninguna relación con la Universidad, y se encuentra asistiendo a un evento, o en condición de visitante, se activará la ruta de emergencia señalada por la Institución a través de la línea 911, para brindar los primeros auxilios a la víctima, lo que comprende la atención psicológica en caso de que así se requiera y lo acepte la víctima, y la orientación legal que requiera para activar la ruta de protección a sus derechos.

Cuando se trate de conductas delictivas que no exijan la denuncia exclusivamente por parte de la víctima, se alertará a las autoridades policiales y judiciales competentes.

**6.1. Formación**

La Dirección de Desarrollo Humano se encargará de propiciar de manera progresiva una capacitación sobre diversidad funcional, cultural, social, económica, con el fin de comprender la riqueza de la diversidad y la importancia de trabajar por una educación inclusiva, propiciando la igualdad de oportunidades para todas las personas; especialmente, los grupos sociales tradicionalmente vulnerados.

Así mismo, se diseñará una campaña para socializar entre la comunidad eafitense y el público en general el presente Protocolo, el que deberá encontrarse en la página web institucional.

**6.2. Indicadores**

El Comité de Género, Diversidad e Inclusión, a través de indicadores, medirá cuantitativa y cualitativa el nivel de avance e implementación del presente Protocolo, así como sus indicadores de gestión una vez puesto en marcha.

**6.3. Seguimiento y revisión del Protocolo**

Con fundamento en el resultado de los indicadores de implementación del Protocolo, se procederá a su ajuste, modificación o adopción de las acciones tendientes a garantizar la permanencia y efectividad de la política de inclusión en equidad de género y sexualidad diversa. La primera revisión se efectuará a los dos años siguientes a la promulgación del presente Protocolo.

Culturalmente, son muchos los imaginarios asociados a los conceptos de género, sexualidad diversa y discapacidad, entre otras razones, debido al desconocimiento de las categorías que involucran estos ámbitos. En consecuencia, conviene iniciar este Protocolo institucional con un lenguaje claro e ilustrativo que permita orientar y comprender la razonabilidad y efectividad de las medidas que se toman a través de este instrumento.

Muchas disciplinas se han ocupado de estos temas con rigor científico y responsabilidad social. Es por eso por lo que se usan las siguientes definiciones, algunas de ellas literales para efectos de este Protocolo. Por lo tanto, se entenderá por:

**Maltrato:** Tratar con crudeza, de forma brusca, desconsideración, o con crueldad (Real Academia de la Lengua [RAE], s. f.).

**Hostigamie​​nto:** Molestar a una persona constantemente, burlarse de la misma insistentemente (RAE, s. f.).

**Discriminación:** Dar un trato desigual a una persona o grupo de personas por motivos raciales, religiosos, políticos, de sexo, ​de edad, de condición física o mental (RAE, s. f.).

**Referencia:** Real Academia de la Lengua. (s. f.). Diccionario de la Real Academia de la Lengua. URL: [https://www.rae.es](https://www.rae.es/)

**Discapacidad:** La discapacidad es un concepto que evoluciona y que resulta de la interacción entre las personas con deficiencias y las barreras debidas a la actitud y al entorno que evitan su participación plena y efectiva en la sociedad, en igualdad de condiciones con las demás (Convención de Naciones Unidas sobre los derechos de las personas con discapacidad).

**Tipos de discapacidad tomados de la Resolución 113 de 2020 del Ministerio de Salud y Protección Social:**

**Discapacidad física**. En esta categoría se encuentran las personas que presentan en forma permanente deficiencias corporales funcionales a nivel músculo esquelético, neurológico, tegumentario de origen congénito o adquirido, pérdida o ausencia de alguna parte de su cuerpo, o presencia de desórdenes de movimiento corporal.

**Discapacidad auditiva**. En esta categoría se encuentran las personas que presentan en forma permanente deficiencias en las funciones sensoriales, relacionadas con la percepción de los sonidos y la discriminación de su localización, tono, volumen y calidad; como consecuencia, presentan diferentes grados de dificultad en la recepción y producción de mensajes verbales y, por tanto, para la comunicación oral. Se incluye en esta categoría a las personas sordas y a las personas con hipoacusia; esto es, aquellas que debido a una deficiencia en la capacidad auditiva presentan dificultades en la discriminación de sonidos, palabras, frases, conversación e incluso sonidos con mayor intensidad que la voz conversacional, según el grado de pérdida auditiva.

**Discapacidad visual**. En esta categoría se incluye a aquellas personas que presentan deficiencias para percibir la luz, forma, tamaño o color de los objetos. Se incluye a las personas ciegas y a las personas con baja visión; es decir, quienes, a pesar de usar gafas o lentes de contacto, o haberse practicado cirugía, tienen dificultades para distinguir formas, colores, rostros, objetos en la calle, ver en la noche, ver de lejos o de cerca, independientemente de que sea por uno o ambos ojos.

**Sordoceguera**. La sordoceguera es una discapacidad única que resulta de la combinación de una deficiencia visual y una deficiencia auditiva que genera en las personas que la presentan problemas de comunicación, orientación, movilidad y el acceso a la información. Algunas personas sordociegas son sordas y ciegas totales, mientras que otras conservan restos auditivos y/o restos visuales.

**​Discapacidad intelectual**. Se refiere a aquellas personas que presentan deficiencias en las capacidades mentales generales, como el razonamiento, la resolución de problemas, la planificación, el pensamiento abstracto, el juicio, el aprendizaje académico y el aprendizaje de la experiencia. Estos producen deficiencias del funcionamiento adaptativo, de tal manera que el individuo no alcanza los estándares de independencia personal y de responsabilidad social en uno o más aspectos de la vida cotidiana, incluidos la comunicación, la participación social, el funcionamiento académico u ocupacional y la independencia personal en la casa o en la comunidad.

**Discapacidad psicosocial (mental)**. Resulta de la interacción entre las personas con deficiencias (alteraciones en el pensamiento, percepciones, emociones, sentimientos, comportamientos y relaciones, considerados como signos y síntomas atendiendo a su duración, coexistencia, intensidad y afectación funcional) y las barreras del· entorno que evitan su participación plena y efectiva en la sociedad.

**Discapacidad múltiple**. Presencia de dos o más deficiencias asociadas, de orden físico, sensorial, mental o intelectual, las cuales afectan significativamente el nivel de desarrollo, las posibilidades funcionales, la comunicación, la interacción social y el aprendizaje, por lo que requieren para su atención de apoyos generalizados y permanentes. Las particularidades de la discapacidad múltiple no están dadas por la sumatoria de los diferentes tipos de deficiencia, sino por la interacción que se presenta entre ellos. A través de dicha interacción se determina el nivel de desarrollo, las posibilidades funcionales, de la comunicación y de la interacción social.

**Neurodiversidad:** “La neurodivergencia es un término general para referirse a los individuos que viven con autismo principalmente, pero también abarca dislexia, dispraxia, déficit atencional con hiperactividad (TDAH), u otras condiciones que los llevan a navegar procesos cognitivos y emocionales de manera distinta a la norma. El término fue acuñado en los 90, cuando activistas por los derechos de las personas con autismo como Jim Sinclair, Kathy Lissner Grant y Donna Williams fundaron la Red Internacional del autismo, bajo el principio de que esta condición no es una enfermedad, sino un estilo de procesamiento cognitivo. Dimensionar el autismo y otras diferencias de proceso mental en las personas es el primer paso para ofrecer una experiencia educativa realmente inclusiva para todos de acuerdo a su manera de aprender y percibir el mundo”.

Referencia: Instituto para el fortalecimiento de la educación, Observatorio, Tecnológico de Monterrey (García, 2021). URL: [https://observatorio.tec.mx/edu-news/neurodiversidad](https://observatorio.tec.mx/edu-news/neurodiversidad)

**Etnicidad, Raza e Identidad:** A diferencia de raza, etnicidad es un concepto de uso más reciente y de menor carga valórica. Etnicidad proviene del concepto griego ethnos, que significa pueblo o nación; su uso generalizado ha emergido precisamente como reemplazo de la desprestigiada palabra raza. Pero no es solo un sinónimo, porque mientras raza se refiere a características fenotípicas, etnicidad se refiere a cultura y, específicamente, a diferencias culturales.

Etnicidad son las prácticas culturales y perspectivas que distinguen a una comunidad dada de personas. Los miembros de los grupos étnicos se ven a sí mismos como culturalmente diferentes de otros agrupamientos en una sociedad, y son percibidos por los demás de igual manera. Hay diversas características que pueden servir para distinguir unos grupos étnicos de otros, pero las más habituales son la lengua, la historia o la ascendencia <<real o imaginada>>, la religión y las formas de vestirse y adornarse (Giddens, 1991).

De este modo, raza y etnicidad se acercan y se alejan porque ambos conceptos son el reflejo de construcciones sociales y culturales que los sujetos elaboran y manipulan en función de diversos contextos. La diferencia, como ya se ha hecho mención, reside en que uno se construye –sobre todo– a partir de características fenotípicas, mientras que el otro se vincula a la identidad étnica (Comisión Económica para América Latina y el Caribe, 2000, pp. 7 - 8).

Referencia. Comisión Económica para América Latina y el Caribe. (2000). Etnicidad, "raza" y equidad en América Latina y el Caribe. URL: https://repositorio.cepal.org/bitstream/handle/11362/31450/S008674_es.pdf?sequ

Acciones Afirmativas: Políticas, medidas o acciones dirigidas a favorecer a personas en estado de vulnerabilidad, con el fin de eliminar o reducir las desigualdades y barreras de tipo actitudinal, social, cultural o económico que los afectan.

Referencia. Tejiendo Justicia, Ministerio de Justicia y del Derecho. URL: [https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad](https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad)

**Accesibilidad:** Condiciones y medidas pertinentes que deben cumplir las instalaciones y los servicios de información para adaptar el entorno, productos y servicios, así como los objetos, herramientas y utensilios, con el fin de asegurar el acceso de las personas con discapacidad, en igualdad de condiciones, al entorno físico, el transporte, la información y las comunicaciones, incluidos los sistemas y las tecnologías de la información y las comunicaciones, tanto en zonas urbanas como rurales. Las ayudas técnicas se harán con tecnología apropiada teniendo en cuenta estatura, tamaño, peso y necesidad de la persona.

Referencia. Tejiendo Justicia, Ministerio de Justicia y del Derecho. URL: [https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad](https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad)

**Ajustes razonables:** Se entenderán las modificaciones y adaptaciones necesarias y adecuadas que no impongan una carga desproporcionada o indebida, cuando se requieran en un caso particular, para garantizar a las personas con discapacidad el goce o ejercicio, en igualdad de condiciones con las demás.

Referencia. Tejiendo Justicia, Ministerio de Justicia y del Derecho. URL: [https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad](https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad)

**Apoyos:** Los apoyos son tipos de asistencia que se prestan a la persona con discapacidad para facilitar el ejercicio de su capacidad legal. Esto puede incluir la asistencia en la comunicación, la asistencia para la comprensión de actos jurídicos y sus consecuencias, y la asistencia en la manifestación de la voluntad y preferencias personales.​

Tejiendo Justicia, Ministerio de Justicia y del Derecho. URL: [https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad](https://www.minjusticia.gov.co/programas/tejiendo-justicia/glosario-discapacidad)

**8.1.Marco de referencia**

El presente Protocolo y las actuaciones del Comité de Género, Diversidad e Inclusión tienen como marco de referencia las siguientes normas e instrumentos:

**8.1.1. Constitución**: Artículos 1 (Estado social), 2 (protección de derechos), 5 (primacía de los derechos inalienables), 13 (igualdad), 16 (libre desarrollo de la personalidad), 43 (igualdad de derechos y oportunidades para hombres y mujeres); artículo 47 (el Estado adelantará una política de previsión, rehabilitación e integración social para​​ los personas con discapacidad, a quienes se prestará la atención especializada que requieran), 54 (el estado garantizará el derecho al trabajo a las personas con discapacidad acorde con su salud), 67 (derecho a la educación), 69 (autonomía universitaria).

**8.1.2. Instrumentos ​Internacionales:**

La Convención Americana de Derechos Humanos- Pacto San José (Ley 16 de 1972).

El Protocolo Adicional a la Convención Americana sobre Derechos Humanos – Protocolo de San Salvador (Ley 319 de 1996).

La Convención sobre la tortura y otros tratos o penales crueles, inhumanos o degradantes (Ley 70 de 1986).

Convención sobre los Derechos del Niño (OEA, 1989).

La Declaración Universal de los Derechos Humanos.

El Pacto Internacional de los Derechos Civiles y Políticos.

El Pacto Internacional de Derecho Económicos, Sociales y Culturales.

La Convención Interamericana para la Eliminación de Todas las Formas de Discriminación en contra de las Personas con Discapacidad.

La Convención de Naciones Unidas sobre los Derechos de las Personas con discapacidad.

**8.1.3. Leyes:**

Ley 21 de 1991, se aprueba el convenio número 169 sobre pueblos indígenas y tribales en países independientes, adoptado por la 76a reunión de la conferencia internacional de la O.I.T., (Ginebra, 1989): los pueblos indígenas y tribales deben gozar plenamente de los derechos humanos y libertades fundamentales, sin barreras y sin discriminación.

Ley 70 de 1993, el reconocimiento y la protección de la diversidad étnica y cultural y el derecho a la igualdad de todas las culturas que conforman la nacionalidad colombiana.

La ley 1098 de 2006, Código de Infancia y Adolescencia.

Ley 1381 de 2010, se dictan normas sobre reconocimiento, uso, protección, fomento, preservación y fortalecimiento de las lenguas de los grupos étnicos de Colombia.

La Ley 1482 de 2011, modificada por la Ley 1752 de 2015, consagra el tipo penal para los actos de discriminación por razones de raza, etnia, religión, nacionalidad, ideología política o filosófica, sexo u orientación sexual, discapacidad y demás razones de discriminación.

Ley 1616 de 2013, ley de la salud mental, priorizando la atención de niños, niñas y adolescentes.

Ley Estatutaria 1618 de 2013.

Ley 1639 de 2013, se fortalecen las medidas de protección a la integridad de las víctimas de crímenes con ácido.

Ley 1996 de 2019, se establecen mecanismos para la garantía del derecho a la capacidad legal plena de las personas con discapacidad, adultos mayores, y al acceso de los apoyos que puedan requerirse para el ejercicio de la misma.

Ley 2126 de 2021, Violencia Intrafamiliar.

Decreto 487 de 2022, reglamenta el servicio de la valoración de apoyos que realicen​ las entidades públicas y privadas en los términos de la ley 1996 de 2019.

**8.1.4. Jurisprudencia:**

Sentencias y Autos de la Corte Constitucional: C131 de 1993, C-109 de 1995, C-1508 de 2000, C-983 de 2002, C-076 de 2006, Auto 006 de 2009 y Auto 173 de 2014, C-863 de 2012, C- 182-2016, C- T-444- de 2019, T 433 de 2021, C-025 de 2021, entre otras.

**​8.1.5. Senten​​cia de Unificación:**

SU 245 de 2021, Derecho a la educación de las comunidades indígenas, Etnoeducación.

**​​8.1.6. Cibergrafía:**

MINISTERIO DE JUSTICIA Y DEL DERECHO. (2023). Publicaciones discapacidad. URL: [https://www.minjusticia.gov.co/programas-co/tejiendo-justicia/Paginas/publicaciones-discapacidad.aspx](https://www.minjusticia.gov.co/programas-co/tejiendo-justicia/Paginas/publicaciones-discapacidad.aspx)

###### Protocolo para una vida libre de violencia y discriminación que tenga su causa en la pertenencia étnica racial, en la discapacidad, en la neurodiversidad y en la vulnerabilidad económica​.

La Dirección de Desarrollo Humano, con su filosofía del mutuo cuidado, y con base en un enfoque de derechos a partir del principio de dignidad humana, es consciente de la importancia de promover una cultura de respeto, con cero tolerancia a la violencia, a la discriminación, y de todos los actos lesivos que afectan moral, psicológica y físicamente a las personas, en relación con el género, el sexo, la identidad personal, el libre desarrollo de la personalidad, la dignidad humana, la libertad y la igualdad.

De conformidad con el objetivo número 4 de Desarrollo Sostenible, no es posible hablar de una educación de calidad cuando no se promueven y facilitan acciones dirigidas a resaltar la importancia de la diversidad humana como una riqueza en sí misma, y a considerar a la persona como el centro del proceso educativo con un enfoque de derechos, en el que prima la igualdad de oportunidades, las capacidades de todos los estudiantes, y con el que se trabaja para redu​cir y eliminar las barreras del aprendizaje, la segregación, la exclusión y la deserción en el sistema educativo.

​De acuerdo con lo anterior, el presente Protocolo tiene dos grandes propósitos: el primero, contemplar una ruta de prevención; esto es, promover reflexiones permanentes y acciones dirigidas a trabajar por una comunidad académica comprometida con la construcción de relaciones respetuosas de la diferencia, y consciente de los prejuicios y estereotipos que propician la vulneración de derechos y la exclusión de personas o grupos sociales, con la intención de aportar a la transformación cultural del país. El segundo, establ​​ecer una ruta de atención para proteger los derechos que se afirmen fueron vulnerados con ocasión de actos de discriminación, hostigamiento, maltrato y violencias que tengan su causa en la pertenencia étnica-racial, en el estrato socioeconómico, la discapacidad y en la neurodiversidad.

​​Las acciones y estrategias que se desarrollen en virtud de la ruta de prevención y el abordaje de los casos en la ruta de atención se harán dentro de un marco ético pedagógico con un enfoque restaurativo, que busca aportar a la solución de las diferencias con la participación directa de las personas involucradas y en el que prime la reparación y la no repetición de los hechos lesivos, evitando un daño mayor. No obstante, en caso de ser necesario, el respectivo caso podrá remitirse a las instancias encargadas institucionalmente de investigar y sancionar.

El Protocolo de EAFIT consta de: 1. Definiciones. 2. Principios. 3. Ámbitos de aplicación. 4. Responsables de la aplicación y del seguimiento del Protocolo. 5. Acciones de prevención y ruta de atención. 6. Atención a terceros. 7. Implementación y seguimiento. 8. Marco normativo.

**1.1. Definiciones:**

Culturalmente son muchos los imaginarios asociados a los conceptos de género, sexualidad diversa y discapacidad, entre otras razones, debido al desconocimiento de las categorías que involucran estos ámbitos. En consecuencia, conviene iniciar este Protocolo institucional con un lenguaje claro e ilustrativo que permita orientar y comprender la razonabilidad y efectividad de las medidas que se toman a través de este instrumento.

Muchas disciplinas se han ocupado de estos temas con rigor científico y responsabilidad social. Es por eso que se usan las siguientes definiciones, algunas de ellas literales para efectos orientativos de este Protocolo. Por lo tanto, se entenderá por:

**Abuso sexual:** Comprende toda intrusión física cometida o amenaza de intrusión física de carácter sexual, ya sea por la fuerza, en condiciones de desigualdad o con coacción (ONU, SGB/2003/13).

En Colombia, los delitos sexuales abusivos se constituyen a partir de criterios subjetivos que tiene que ver con el aprovechamiento, por parte del sujeto activo del delito o agresor, de circunstancias que lo ubican en una situación ventajosa frente a la víctima. Estas circunstancias que le dan ventaja al agresor pueden ser por razones de la edad, por el poder o autoridad (jefe, maestro, médico, sacerdote, pastor, funcionario público, militar, etc.), por la incapacidad física o psicológica de la víctima, entre otras. La característica de esta forma de violencia es el aprovechamiento de la condición de ventaja o de la condición de vulnerabilidad de la víctima como mecanismo utilizado por el agresor para cometer el delito sexual (Ministerio de Salud y Protección Social de la Republica de Colombia, Resolución 459/12).

**Acoso sexual:** Según la Entidad de las Naciones Unidas para la Igualdad de Género y el Empoderamiento de las Mujeres: el acoso sexual es toda práctica de contenido sexual no consentido por las mujeres, en los espacios públicos y privados. Comprende una gama de expresiones de contenido sexual que van desde la observación, exhibición, expresiones relacionadas al cuerpo de las mujeres, tocamientos, amenazas.

El acoso sexual puede darse sin contacto físico cuando hay comentarios sobre el cuerpo o apariencia, silbidos, miradas sexualmente sugestivas, exposición de órganos sexuales, etc. o con contacto físico al rozar o frotar el cuerpo de otra persona, tocar, pellizcar o agarrar partes del cuerpo de otra persona sin su consentimiento (ONU Mujeres, 2019, p. 11).

El acoso sexual atenta contra la dignidad y la integridad de las personas, genera un ambiente de temor, de subordinación, hostil, degradante e intimidatorio y pone en riesgo el bienestar, seguridad, salud física y emocional de quien la padece (Fuentes Vásquez, 2019).

Para efectos institucionales, se considera que el acoso sexual se puede presentar no únicamente frente a mujeres, sino frente a cualquier persona sin distinción de género ni orientación sexual.

**La expresión «violencia y acoso» en el mundo del trabajo:** Designa un conjunto de comportamientos y prácticas inaceptables, o de amenazas de tales comportamientos y prácticas, ya sea que se manifiesten una sola vez o de manera repetida, que tengan por objeto, que causen o sean susceptibles de causar, un daño físico, psicológico, sexual o económico (Organización Internacional del Trabajo, 2019, Definiciones).

**Agénero:** “Describe a una persona que no se identifica como hombre o mujer, o que se considera carente de una identidad de género” (National Geographic, 2017).

**Conformidad de género:**“Se refiere a una persona cuya expresión de género es consistente con las normas culturales que se esperan de dicho género” (National Geographic, 2017, Redefinir el género).

**Disconformidad de género:** La disconformidad de género significa, no adherirse a las normas de género de la sociedad. Las personas pueden describirse a sí mismas como disconformes con el género si no se ajustan a la expresión, la presentación, los comportamientos, los roles o las expectativas de género que la sociedad considera como la norma para su género. Las personas de cualquier identidad de género pueden ser inconformistas de género (American Psychological Association, 2015).

**Expresión de género:** El concepto expresión de género se refiere a la forma en que una persona se expresa en su entorno respecto de su género, como, por ejemplo: su forma de vestir, sus gestos y las costumbres que puede llegar a tener. (…) Es bajo el concepto de expresión de género, que aparecen las categorías de masculino, femenino o andrógino. Esta expresión de género puede ser o no congruente con el sexo y con la identidad de género de una persona (Ministerio de Justicia y del Derecho, s.f., p. 1).

**Feminicidio:** Tipo penal consagrado como delito autónomo por la Ley 1761 de 2015, que señala que éste ocurre cuando se causa la muerte a una mujer por su condición de mujer o por motivos de su identidad de género. La Corte Constitucional ratifica que el feminicidio “como tipo penal responde a la penalización autónoma del homicidio de mujer en razón a su género” (Sentencia C-297, 2016).

**Género:** “…construcción social referido a las identidades, las funciones y los atributos construidos de la mujer y el hombre y al significado social y cultural que se atribuye a esas diferencias biológicas” (Corte Constitucional, Sentencia T-804, 2014).

**Género fluido:**Describe a una persona cuya identidad de género no es fija. Una persona con género fluido quizá se sienta siempre como una mezcla de los dos géneros tradicionales, pero puede que se sienta más como un género unos días, y como otro género otros días (National LGBT Health Education Center, s.f., p. 3).

**Género no binario:** Las identidades no binarias son aquellas que no se identifican única o completamente como mujeres o como hombres; es decir, que trascienden o no están incluidas dentro del binario mujer-hombre [de modo que] (…) reúnen, entre otras categorías identitarias, a personas que se identifican con una única posición fija de género distinta de mujer u hombre, personas que se identifican parcialmente como tales, personas que fluyen entre los géneros por períodos de tiempo, personas que no se identifican con ningún género y personas que disienten de la idea misma del género (Corte Constitucional, Sentencia T-033, 2022).

**Hostigamiento:** “promoción o instigación de actos orientados a causar daño físico o moral, se produce por razón de su raza, etnia, religión, nacionalidad, ideología política o filosófica, sexo u orientación sexual” (Corte Constitucional, Sentencia C-671, 2014).

**Identidad sexual:** La identidad sexual incluye la manera como la persona se identifica como hombre o mujer, o como una combinación de ambos, y la orientación sexual de la persona. Es el marco de referencia interno que se forma con el correr de los años, que permite a un individuo formular un concepto de sí mismo sobre la base de su sexo, género y orientación sexual y desenvolverse socialmente conforme a la percepción que tiene de sus capacidades sexuales (Organización Panamericana de la salud & Organización Mundial de la salud, 2000, p.7).

**Identidad de género (“gender identify):** La jurisprudencia constitucional indica que es la vivencia interna e individual del género tal como cada persona la siente profundamente, que puede o no corresponder con el sexo asignado al momento del nacimiento, incluyendo la vivencia personal del cuerpo (que podría involucrar la modificación de la apariencia o la función corporal a través de medios médicos, quirúrgicos o de otra índole, siempre que la misma sea libremente escogida). También se refiere a la “experiencia personal de ser hombre, o mujer o de ser diferente que tiene cada persona” (ya sea transgenerista, {transexual, travesti, transformista, drag queen o king}, o intersexual) y la forma en que aquella lo manifiesta a la sociedad” (Corte Constitucional, Sentencia T 099,2015; T-077, 2016).

**Igualdad de género:** La igualdad de derechos, responsabilidades y oportunidades de las mujeres y los hombres, y las niñas y los niños. La igualdad no significa que las mujeres y los hombres sean lo mismo, sino que los derechos, las responsabilidades y las oportunidades no dependen del sexo con el que nacieron. La igualdad de género supone que se tengan en cuenta los intereses, las necesidades y las prioridades tanto de las mujeres como de los hombres, reconociéndose la diversidad de los diferentes grupos de mujeres y de hombres (UNESCO, 2014, p. 104).

**Injurias por vía de hecho:** Conducta potencialmente delictiva que se presenta cuando “el sujeto activo consciente y voluntariamente impute a otra persona conocida o determinable, un hecho capaz de lesionar su honra, además de conocer el carácter deshonroso de la imputación y la capacidad de daño y menoscabo a la integridad moral del afectado, de la imputación” (Corte Constitucional, Sentencia C-442 2011).

Entendido también como las formas, distintas a las verbales, en que se ofende el honor de una persona, como cuando se le abofetea –sin que se trate, en estricto sentido, de lesiones personales-, escupe o somete a escarnio (Corte Suprema de Justicia. Sala de Casación Penal, Sentencia SP-107, 2018)..

**Intersexual:** Categoría que describe a una persona con un trastorno del desarrollo sexual (TDS); una configuración reproductiva, genética, genital u hormonal que resulta en un cuerpo que no es fácil de categorizar como hombre o mujer. Se confunde con frecuencia con lo transgénero, pero son distintos e, incluso, inconexos. El término más familiar, hermafrodita se considera obsoleto y ofensivo (National Geographic, 2017, Redefinir el género).

**LGBTIQ+:** “Acrónimo usado para referirse a lesbiana, gays, bisexuales, transgénero, queers e individuos o comunidades “que se cuestionan”. No es sinónimo de “homosexual”, ya que ello implicaría que transgénero es una orientación sexual. Incluye variantes como LGBT y LGBQ” (National Geographic, 2017, Redefinir el género).

**Orientación sexual:** “… atracción física o emocional de una persona por otra, ya sea heterosexual, lesbiana, homosexual, bisexual o asexual” (Corte Constitucional, Sentencia T-077, 2016).

**Queer:**“término paraguas para un rango de personas no heterosexuales o cisgénero. A lo largo del tiempo se ha usado como insulto; algunos lo reclaman como afirmativo, mientras otros aún lo consideran despectivo” (National Geographic, 2017, Redefinir el género).

**Rol de género:** Los roles de género se refieren a las normas sociales y de conducta que, dentro de una cultura específica, son ampliamente aceptadas como socialmente apropiadas para las personas de un sexo específico. Suelen determinar las responsabilidades y tareas tradicionalmente asignadas a hombres, mujeres, niños y niñas. Al igual que el género, los roles de género pueden transformarse con el transcurso del tiempo (ONU Mujeres, s.f., Profundicemos en términos de género, diapositiva 62).

**​Sexo:** “hecho biológico que hace referencia a las diferencias biológicas entre el hombre y la mujer” (Corte Constitucional, Sentencia T-077, 2016).

**Sexualidad diversa:** Las diferentes y múltiples manifestaciones de la sexualidad humana, evidenciadas a través de la orientación, la identidad y la preferencia sexual, incluida la perspectiva de género. La sexualidad humana es una y se matiza a través de sus diferentes expresiones y ejercicio, que incluyen distintas variables relacionadas o no con la asignación del sexo biológico al nacer, con la reasignación artificial mediante intervenciones quirúrgicas, con las manifestaciones culturales aceptadas en una sociedad determinada (Universidad EAFIT, Centro de integridad, s.f., Definiciones).

**Transexual:** … las personas que modifican su cuerpo para ajustarlo a su sentimiento íntimo de "ser" hombre o mujer son un fenómeno moderno, vinculado a las posibilidades de transformación corporal que surgen con la endocrinología y la cirugía plástica reconstructiva. De ahí que en el Diccionario de la Lengua Española de la Real Academia aparezca el término "transexual" como adjetivo: "Dícese de la persona que mediante tratamiento hormonal e intervención quirúrgica adquiere los caracteres sexuales del sexo opuesto (Lamas, 2009, p. 1).

**Transgénero:** Tienen una vivencia que no corresponde con el sexo asignado al momento de nacer. Cuando el sexo asignado al nacer es masculino y la vivencia, en los términos descritos es femenino, dicha persona generalmente se autorreconoce como una mujer trans. Cuando el sexo asignado al nacer es femenino y la vivencia de la persona es masculina, dicha persona generalmente se autorreconoce como un hombre trans (Corte Constitucional, Sentencia T-099, 2015).

**Travesti:** Un individuo que en ocasiones se viste con ropa tradicionalmente asociada con las personas de un sexo diferente. Las personas travestis suelen estar cómodas con el sexo que se les asignó al nacer y no desean cambiarlo. "Travesti" no debe ser usado para describir a alguien que se ha trasladado a vivir a tiempo completo con un sexo diferente, o que tenga intención de hacerlo en el futuro. Algunas personas prefieren utilizar el término travesti para describirse a sí mismas, pero debe evitarse a menos que se esté citando a alguien que se auto identifica de esa manera (Ministerio De Sanidad, Servicios Sociales E Igualdad de España, 2018, p.25).

**Violencia contra la mujer:** “… cualquier acción o conducta, basada en su género, que cause muerte, daño o sufrimiento físico, sexual o psicológico a la mujer, tanto en el ámbito público como en el privado” (Convención interamericana para prevenir, sancionar y erradicar la violencia contra la mujer, 1984, artículo 1).

**Violencia de género:**La violencia de género se refiere a los actos dañinos dirigidos contra una persona o un grupo de personas en razón de su género. Tiene su origen en la desigualdad de género, el abuso de poder y la existencia de normas dañinas. El término se utiliza principalmente para subrayar el hecho de que las diferencias estructurales de poder basadas en el género colocan a las mujeres y niñas en situación de riesgo frente a múltiples formas de violencia. Si bien las mujeres y niñas sufren violencia de género de manera desproporcionada, los hombres y los niños también pueden ser blanco de ella. En ocasiones se emplea este término para describir la violencia dirigida contra las poblaciones LGBTQI+, al referirse a la violencia relacionada con las normas de masculinidad/feminidad o a las normas de género (ONU Mujeres, s.f., Tipos de violencia contra las mujeres y las niñas, par. 2).

**Violencia económica o patrimonial:** “Cualquier acto que desconozca o restrinja el derecho a los ingresos, a la propiedad, el uso y disfrute de bienes y servicios, que tiene una persona, o que atenta contra otros derechos” (Ministerio de Salud y Protección Social [MinSalud], 2016, p.26).

**Violencia física:** Es cualquier acto de agresión qué mediante el uso de la fuerza, o cualquier mecanismo que pueda u ocasione daños físicos internos o externos a la persona agredida y pone en riesgo o disminuye su integridad corporal. Dentro de este tipo de violencia se incluyen golpizas, empujones, sacudidas, estrujones, agresiones con objetos o con líquidos, ácidos, álcalis, sustancias similares o corrosivas que generen daño o destrucción al entrar en contacto con el tejido humano (MinSalud, 2016, p.26).

**Violencia psicológica:** La violencia psicológica se ocasiona con acciones u omisiones dirigidas intencionalmente a producir en una persona sentimientos de desvalorización e inferioridad sobre sí misma, que le generan baja de autoestima. Esta tipología no ataca la integridad física del individuo sino su integridad moral y psicológica, su autonomía y desarrollo personal y se materializa a partir de constantes y sistemáticas conductas de intimidación, desprecio, chantaje, humillación, insultos y/o amenazas de todo tipo (Corte Constitucional, Sentencia T-967, 2014).

**Violencia sexual:** Todo acto o comportamiento de tipo sexual ejercido sobre una persona, a través del uso de la fuerza; la amenaza -; la coacción física, psicológica o económica; o cualquier otro mecanismo que anule o limite la voluntad personal aprovechado las situaciones y condiciones de desigualdad; y las relaciones de poder existentes entre víctima y agresor. Esto incluye aquellos casos en que el/la agresor/a obligue a la víctima a realizar alguno de estos actos con terceras personas. Todo acto sexual con persona menor de 14 años es considerado abuso en tanto no existe la capacidad de consentir y esto afecta su desarrollo personal, por lo tanto, siempre será considerado violencia sexual. Las formas de coacción pueden ser chantaje, soborno, manipulación entre otros (MinSalud, 2016, p.26).

**Maltrato:** Tratar con crudeza, de forma brusca, desconsideración, o con crueldad (Real Academia de la Lengua [RAE], s.f.).

**Hostigamiento:** Molestar a una persona constantemente, burlarse de la misma insistentemente (RAE, s.f.).

**Discriminación:** Dar un trato desigual a una persona o grupo de personas por motivos raciales, religiosos, políticos, de sexo, de edad, de condición física o mental (RAE,s.f.).

**Ciberacoso:** Consiste en el envío de mensajes en línea o digitales intimidatorios o amenazantes (ONU Mujer, s.f,, Tipos de violencia contra las mujeres y las niñas).

**Sexteo o sexting:** Envío de mensajes o fotos en línea o digitales de contenido explícito sin contar con la autorización de la persona destinataria (ONU Mujer, s.f,, Tipos de violencia contra las mujeres y las niñas).

**Doxing:** Publicación en línea o digital de información privada o identificativa sobre la víctima (ONU Mujer, s.f, Tipos de violencia contra las mujeres y las niñas).

Los principios que sirven de fundamento al presente Protocolo son los siguientes:

**Debida diligencia:** Con enfoque de derechos humanos la Institución oportunamente activará las rutas de atención que se prevén en este Protocolo, con el fin adoptar las medidas de protección eficaces que requiera el caso, prevenir y evitar la revictimización y la vulneración de los derechos de las personas.

**No discriminación:** Ninguna persona podrá ser objeto de trato excluyente, perjudicial o arbitrario en razón de su género, sexo, orientación o preferencia sexual y de cualquier manifestación relacionada con la sexualidad humana.

**Igualdad:** Todas las personas nacen libres e iguales ante la ley y, por lo tanto, deben recibir el mismo trato y protección por parte de las autoridades, y gozar de los mismos derechos, oportunidades y libertades sin ninguna discriminación por razones de sexo, raza, origen nacional o familiar, lengua, religión, opinión política o filosófica (Constitución Política, artículo 13).

**​Libre desarrollo de la personalidad:** La facultad que tienen los individuos de realizar su proyecto de vida conforme a sus valores, intereses, creencias y convicciones, sin más límites que los derechos de los demás y el orden jurídico (Corte Constitucional, Sentencia T 077 de 2016).

​**Autonomía de la voluntad:** Toda persona puede disponer de sus derechos por sí misma, sin restricción alguna salvo los límites consagrados en la Constitución y en la ley.

**Integridad:** De conformidad con los valores institucionales de la Universidad, la Integridad se erige como virtud fundante que inspira los actos de todos los seres humanos y en especial, en aplicación del presente Protocolo, los relacionados con la probidad, entereza en todas las acciones, la rectitud en el desempeño, acatamiento de las normas y el respeto de los derechos de las mujeres y de la diversidad.

**Perspectiva de género:** Es el análisis de las construcciones culturales frente a los roles tradicionales que se atribuyen a las mujeres y a los hombres, con el fin de conocer y hacer visibles las desigualdades existentes entre los mismos e implementar políticas que conduzcan a equiparar los derechos de las mujeres y garantizar la igualdad de oportunidades.

**Enfoque diferencial:** El presente Protocolo, busca brindar y garantizar un tratamiento especial y diferenciado a las mujeres y la población LGBTIQ+ con un enfoque interseccional, con el fin de respetar y proteger sus derechos, la individualidad, la diversidad y el reconocimiento del otro.

**Enfoque interseccional:** Al activar las acciones y estrategias de prevención y atención que prevé el Protocolo se identificará y analizará si en una misma persona confluyen distintos marcadores sociales en razón de su género, etnia, capacidad económica, diversidad funcional, entre otros; con el fin de adoptar acciones afirmativas que conduzcan a garantizar la igualdad material y formal en el acceso y disfrute de todos los derechos, bienes y servicios en la institución educativa.

**Acciones afirmativas:**Son las medidas encaminadas a equiparar los derechos de las personas que se encuentran en situación de desigualdad, por su condición de género, sexo o manifestaciones múltiples de la sexualidad humana.

**Corresponsabilidad:** Todos los miembros de la comunidad universitaria son sujetos activos y responsables del mutuo cuidado, no violencia y la no discriminación que se formula en el presente Protocolo. Así mismo, para la implementación, cumplimiento y seguimiento de este Protocolo, se trabajará articuladamente desde la Dirección de Desarrollo Humano y Bienestar Universitario con las distintas dependencias administrativas y Escuelas de la Universidad con el fin de avanzar hacia la igualdad y garantía de oportunidades de todas las personas.

**Atención integral:** En la ruta de atención e inclusión, conforme a este Protocolo, se atenderá a la víctima en su esfera física, psicosocial, académica y humana, respetando el cumplimiento de las normas jurídicas que apliquen al caso. Se aplicará un enfoque centrado en las víctimas con acceso a servicios oportunos y de calidad, es decir, garantizando confidencialidad, respeto, escucha libre de prejuicios, acción sin daño, no revictimización e información sobre sus derechos.

**Atención inclusiva:** En la ruta de atención e inclusión conforme a este Protocolo, siempre se tendrá en cuenta las condiciones personales de la víctima, la perspectiva de género, la orientación sexual, la pertenencia étnica racial, el estado de vulneración económica, la discapacidad y la neurodiversidad con el fin de garantizar la efectividad del principio de no discriminación.

**Confidencialidad:** De todas las actuaciones, acciones, medidas urgentes y de protección que se apliquen en la ruta de atención, se garantizará la absoluta reserva de todos aquellos hechos, circunstancias y datos que se conozcan en razón de esta política, respetando la información personal y la intimidad de la víctima y del presunto agresor en el marco de la protección del habeas data.

**Debido proceso:** En el trámite que prevé el presente Protocolo se observarán los principios de imparcialidad, justicia, transparencia y celeridad a todas las personas involucradas en actos de discriminación, violencia de género, violencia sexual, agresiones físicas, psicológicas, morales y demás actos lesivos a la dignidad humana, al libre desarrollo de la personalidad y a la libertad.

**Imparcialidad:** Los miembros del Comité de Género, Diversidad e Inclusión brindarán un trato respetuoso y digno a las partes involucradas en la investigación, manteniendo el equilibrio y realizando los ajustes necesarios para superar las barreras de desigualdad de aquellas personas históricamente discriminadas en razón del género y de la sexualidad diversa.

**Accesibilidad:** El presente Protocolo se divulgará entre la comunidad eafitense y el público en general. En este propósito se utilizará un lenguaje claro y sencillo.

**Protección:** Se garantizará la ejecución de la ruta de atención e inclusión con el fin de evitar la revictimización y asegurar las medidas de prevención necesarias tendientes a evitar que en el claustro universitario y en las demás dependencias de la Universidad se realicen actos lesivos constitutivos de maltrato, hostigamiento, discriminación y violencia.

**Celeridad:** Se dará prioridad para adelantar el trámite previsto en el presente Protocolo de manera ágil y rápida.

**Prohibición de represalias:** Ningún miembro de la Universidad, podrá realizar acciones que tengan como propósito castigar o sancionar a aquellas personas que intervinieron como testigos, como informantes, o como apoyo a la víctima.

**Impedimento y recusación:** Cualquiera de los miembros del Comité de Género, Diversidad e Inclusión, deberá declararse impedido para conocer del trámite, o la víctima o el reportado podrán recusarlos en razón del interés directo o indirecto de alguno de los integrantes del Comité con el resultado del trámite, en razón del parentesco de alguno de éstos dentro del cuarto grado de consanguinidad, o segundo de afinidad, o ser cónyuge o compañera (o) permanente, de la víctima o del reportado; existir enemistad grave o amistad íntima entre alguno de los miembros del comité y la víctima o de la persona contra la que se dirige el reporte, entre otros.

Inhabilidades para el nombramiento y contratación de profesores y personal administrativo y de apoyo conforme lo previsto en la ley 1918 de 2018 reglamentado por el decreto 753 de 2019: La institución dará cumplimiento a los lineamientos que se señalan en la ley y el decreto antes citado y, por consiguiente, no podrá contratar para desempeñar cargos, oficios o profesiones que involucren una relación directa y habitual con niños, niñas y adolescentes, a aquellas personas que hayan sido condenadas por la comisión de delitos contra la integrid​ad, la libertad, la formación sexual de persona menor de 18 años.

El presente Protocolo se aplicará sin excepción para toda la comunidad eafitense y demás personas que accedan a las diferentes instalaciones de la Universidad, con el fin de proteger los derechos, prevenir y eliminar toda forma de discriminación, hostigamiento, maltrato y violencia que tengan su causa en el género y, en la sexualidad diversa. Así mismo se activará en los casos que más adelante se señalan.

El Comité de Género, Diversidad e Inclusión valorará las distintas situaciones que las personas reporten y, de conformidad con lo detallado más adelante bajo el enunciado de ruta de atención, asumirá el conocimiento del respectivo caso o, podrá remitir a los responsables de investigar y sancionar, según lo definido en este Protocolo, en el Estatuto Profesoral, en el Reglamento Interno de Trabajo, en los Reglamentos académicos de programas de pregrado y de posgrado.

Las rutas que prevé el Protocolo no constituyen un requisito previo para acudir al proceso disciplinario, por consiguiente:

La víctima en cualquier momento podrá decidir si activa directamente el proceso disciplinario, sin que previamente se requiera agotar el trámite que prevé el presente Protocolo.

El Comité de Género, Diversidad e Inclusión sin avocar el conocimiento del caso, podrá remitir para su investigación a la instancia que corresponda, cuando así lo considere necesario en razón de las circunstancias de tiempo, modo y lugar en que se desarrollan los hechos; o en aquellos eventos en que la víctima o el presunto responsable no expresen su consentimiento para participar en el abordaje restaurativo.

Por consiguiente, siempre que así lo consienta la víctima y el presunto responsable, se activará la ruta de atención que prevé el presente Protocolo:

**3.1 Ámbito de aplicación por el lugar dónde ocurren los hechos:**

Se activará el presente Protocolo:

Cuando los hechos ocurran en cualquiera de las instalaciones físicas de la Universidad.

Cuando los hechos ocurran durante actividades académicas, deportivas, culturales o laborales que tengan lugar por fuera de la universidad.

​Cuando los hechos ocurran en los espacios digitales de que dispone o administra la universidad, esto es, correos institucionales, Teams, redes sociales, entre otros.

Cuando los hechos ocurran en espacios digitales ajenos a la universidad; esto es, en correos electrónicos, redes sociales, mensajería instantánea, o cualquier plataforma virtual, siempre que la víctima y el presunto responsable sean integrantes de la comunidad eafitense y, que con ellos se afecten de manera grave los derechos de la víctima, su proceso de formación o su desempeño laboral.

Cuando los hechos ocurran por fuera de la universidad y durante actividades ajenas a la misma, siempre que la víctima y el presunto responsable sean integrantes de la comunidad eafitense y, que con ellos se afecten de manera grave los derechos de la víctima, su proceso de formación o su desempeño laboral.

**3.2 Ámbito de aplicación por la naturaleza de las conductas:**

Con el fin de orientar a los integrantes de la Institución a continuación se señalan a modo de ejemplo, algunas de las conductas asociadas a discriminación, hostigamiento, maltrato y violencias que tengan su causa en el género o en la sexualidad diversa. El listado se advierte, es enunciativo mas no taxativo:

**3.2.1 Conductas de discriminación, maltrato, hostigamiento y violencias asociadas a género:**

**Acoso sexual:** Abrazos, caricias, besos, tocamientos, roces, comentarios de índole sexual sobre la apariencia física o sobre el sexo de una persona, miradas lascivas, gestos obscenos, solicitud de favores sexuales a cambio de ofrecer o modificar la nota evaluativa o flexibilizar las evaluaciones o, tratándose de empleados, condicionar un ascenso, una bonificación salarial, dichos comportamientos atentan contra la dignidad y la integridad de quien los padece, generando un ambiente hostil, degradante y de intimidación.

**Abuso sexual:**Tocamientos, contacto sexual con una persona que se encuentra bajo los efectos del alcohol, sustancias sicoactivas, dormida o con un menor de edad.

**Violencia física:** Golpes, gritos, insultos, empujones, maltratos, lesiones, que atenten contra la integridad física, psicológica, económica, o la vida de las personas.

**Violencia psicológica:** Presionar, coaccionar, amenazar a una persona para que ésta acepte invitaciones de carácter sexual, o una relación afectiva no deseada.

Compartir mensajes, fotografías, imágenes o videos con contenido sexual sin consentimiento del destinatario, usando las redes sociales o el celular.

Vulnerar el derecho a la intimidad, esto es, vigilar, controlar, espiar, manipular, perseguir para interferir en las decisiones y en la vida de una persona.

Acosar, hostigar, perseguir a una persona mayor de edad o niño, niña y adolescente por redes sociales, correos, mensajerías instantáneas, o juegos en línea.

Exponer con fines sexuales no consentidos en redes sociales o espacios virtuales.

Descalificar las competencias profesionales o intelectuales de cualquier persona.

Realizar comentarios sobre la apariencia física, o sobre las publicaciones de una persona en redes sociales afectando la dignidad e integridad de la víctima.

Ejercer poder o dominación mediante el abuso de la posición jerárquica o posición de autoridad o por razones de género.

**Violencia económica:**

Ofrecer beneficios académicos, económicos, laborales o de otro tipo a cambio de actividad sexual no deseada.

Ofrecer promover para ocupar otros cargos, otorgar becas, pasantías, sabáticos y en general beneficios laborales o, amenazar con no hacerlo; a cambio de acceder a una relación con connotación sexual no deseada.

Controlar el dinero y el uso de los bienes de una persona sin su consentimiento.

Impedir el uso y goce de los bienes y servicios de la Institución.

**3.2.2 Conductas de discriminación, maltrato, hostigamiento y violencias asociadas a la diversidad sexual.**

Las previstas en el numeral 3.2.1.

No nombrar a la persona o abstenerse de registrarlo por su nombre identitario, en las bases de datos de la universidad, en el correo electrónico, en Teams, en Epik, en el carnet institucional, so pretexto de que no ha sido modificado el documento de identidad.

Las conductas derivadas del desconocimiento del presente Protocolo se entienden incorporados al régimen disciplinario que corresponda según el caso, para el inicio de los procesos disciplinarios se remitirá a la instancia respectiva de acuerdo al rol de la persona denunciada de conformidad a lo previsto en el Reglamento Interno de Trabajo, en el Reglamento Académico de Programas de Pregrado y en el Reglamento de Posgrado.

**4.1 Comité de Género, Diversidad e Inclusión.**

El Comité de Género, Diversidad e Inclusión es el organismo encargado de diseñar, dirigir, implementar y hacer seguimiento a las acciones y estrategias de este Protocolo. Está integrado por quien lidere cada una de las siguientes dependencias que se enuncian:

Director (a) de Desarrollo Humano o su delegado, quien lo preside.

Secretaria (o) General o su delegado.

Dos Decanos (as). Al momento de aprobarse la reforma al Protocolo se determinó que serían el decano de Derecho y la decana de Administración. Cada dos años, los decanos a su criterio, elegirán cuáles de ellos harán parte del Comité.

Profesional en Psicología con sensibilidad y formación en equidad de género y sexualidad diversa.

Un profesor con formación en estudios humanísticos con sensibilidad hacia la equidad de género y a la sexualidad diversa.

Un representante estudiantil al Consejo Académico.

La Coordinadora de Género, Diversidad e Inclusión, con conocimientos en enfoque de género y en mecanismos alternativos de solución de conflictos.

Igualmente, el Comité podrá tener invitados permanentes u ocasionales según la temática a analizar.

**4.1.2 Funciones del Comité de Género, diversidad e inclusión.**

El Comité tendrá dentro de sus funciones las siguientes:

Definir las estrategias de sensibilización al interior de la Universidad para prevenir los actos de discriminación, hostigamiento, maltrato, violencias basadas en el género y en la sexualidad diversa.

Definir los programas de formación para los integrantes de la comunidad eafitense, en temas de género, sexualidad diversa, diversidad e inclusión.

Hacer seguimiento a los casos atendidos en razón del Protocolo, con el fin de establecer estrategias dirigidas a hacer visibles los estereotipos, prejuicios e imaginarios culturales que propician la reiteración de conductas asociadas a vulneración de derechos.

Definir los indicadores que permitan hacer seguimiento a los casos reportados y dar insumos para implementar acciones preventivas, correctivas y de mejora.

**4.1.3 Quórum.** Para todos los efectos el Comité tendrá un quórum deliberatorio y decisorio. Para el primero, se requiere asistencia mínima de 6 integrantes del Comité; para el segundo, se requiere la participación mínima de 7 integrantes para decidir. Las decisiones se tomarán por mayoría simple.

**4.14 Reuniones del Comité de Género, Diversidad e Inclusión.** El Comité sesionará ordinariamente cuatro veces en el año: en marzo, junio, agosto y noviembre. También podrá sesionar extraordinariamente por solicitud de cualquiera de los integrantes del Comité; y su convocatoria estará a cargo de la Coordinadora de Género, Diversidad e Inclusión.

Parágrafo. La secretaría técnica del Comité estará a cargo de la Coordinadora de Género, Diversidad e Inclusión, quien además elaborará el acta del desarrollo de cada una de las reuniones.

**4.2 Comisión de análisis de caso de violencias basadas en género**

Acompaña y emite recomendaciones para la atención inicial y además, evalúa el caso para determinar el trámite a seguir y las medidas urgentes y de protección necesarias para mitigar cualquier daño mayor a las personas involucradas en el caso reportado, de conformidad a lo señalado en el Protocolo.

**4.2.1. Las funciones principales de este comité, son:**

Decidir si por la gravedad de la conducta denunciada, la reiteración de la misma, por el incumplimiento a los acuerdos de las medidas restaurativas o las circunstancias de tiempo, modo y lugar en que se presentaron los hechos, el caso reportado debe remitirse a otras instancias institucionales, esto es, Comité de Convivencia Laboral, al Comité Disciplinario o a la Dirección de Desarrollo Humano, o la Secretaría General cuando la persona involucrada en los hechos sea un contratista.

Evaluar los posibles riesgos que afecten o puedan afectar, entre otros, la integridad física, emocional, el proceso de enseñanza o aprendizaje de la víctima, con el fin de adoptar medidas urgentes y de protección para la misma.

Informar a la Secretaría General y la Dirección Administrativa y Financiera para la adopción de todas aquellas medidas tendientes a informar al contratante cuando el caso reportado involucre al mismo contratante o su personal, además, para que se adopten los trámites necesarios con el propósito de iniciar la investigación que corresponda.

**4.2.2 Integrantes:**

Director de Desarrollo Humano-Bienestar Universitario o su delegado.

Coordinación de Género, Diversidad e Inclusión.

Jefe de Desarrollo Estudiantil o su delegado, intervendrá cuando el presunto responsable tiene la calidad de estudiante.

Jefe del programa de la Escuela, intervendrá cuando el presunto responsable tiene la calidad de estudiante.

Director de área de la Escuela, intervendrá cuando el presunto responsable tiene la calidad de profesor.

Jefe inmediato, intervendrá cuando el presunto responsable tiene la calidad de colaborador.

Invitados especiales.

​

**4.3 Coordinadora de Género, Diversidad e Inclusión.**

3.3.1 Funciones de la Coordinadora de Género, Diversidad e Inclusión. La Coordinadora tendrá dentro de sus funciones las siguientes:

Activar la ruta de atención de conformidad a lo señalado en este Protocolo y con lo dispuesto por la Comisión de Análisis de Casos.

Gestionar ante las instancias respectivas todas las acciones tendientes a brindar la atención prioritaria que requiera la víctima para superar la afectación a su integridad física o psicológica.

Convocar a la Comisión de Análisis de Casos con el fin de evaluar los posibles riesgos que afecten o puedan afectar, entre otros, la integridad física, emocional, el proceso de enseñanza o aprendizaje de la víctima, con el fin de adoptar medidas urgentes y de protección para la misma.

Orientar a la comunidad eafitense sobre las rutas internas que prevé la universidad y externas que existen en Medellín, para atender los casos asociados a violencias basadas en género, lo que comprende las que afectan a las personas en razón de su identidad de género u orientación sexual.

Llevar un registro que permita tener trazabilidad de cada uno de los casos, desde el momento del reporte hasta la finalización del abordaje previsto en el Protocolo, preservando la identidad de los participantes, precisando la fecha de ocurrencia de los hechos, la fecha del reporte, el rol de los participantes en la universidad, la Escuela o área administrativa de los sujetos involucrados en el caso, y precisando, el resultado de cada uno de los asuntos tramitados, el seguimiento a los acuerdos y, la fecha de cierre.

Sugerir al Comité de Género, Diversidad e Inclusión las estrategias de sensibilización al interior de la Universidad para prevenir los actos de discriminación, hostigamiento, maltrato, violencias basadas en el género y en la sexualidad diversa.

Sugerir al Comité de Género, Diversidad e Inclusión programas de formación para los integrantes de la comunidad eafitense, en temas de género, sexualidad diversa, diversidad e inclusión.

Hacer seguimiento a los compromisos pactados por los intervinientes en la mediación para validar el cumplimiento de los mismos.

Convocar al Comité de Análisis de Caso para determinar las consecuencias del incumplimiento de un acuerdo con medidas -restaurativas, esto es, para tomar la decisión si se reabre el trámite previsto en el Protocolo, o si se remite a la instancia disciplinaria que corresponda.

Presentar en las sesiones ordinarias del Comité de Género, Diversidad e Inclusión un informe sobre el número de casos atendidos y el resultado del trámite.

Convocar de manera extraordinaria al Comité de Análisis de Casos para definir estrategias de acompañamiento cuando el caso así lo requiera, o para evaluar la remisión a otras instancias institucionales.

Presentar, al Comité de Género, Diversidad e Inclusión un informe anual sobre el número de casos atendidos, la naturaleza de las conductas reportadas, el rol de las personas involucradas en cada caso, la Escuela o el área administrativa al que pertenecen las personas involucradas, la fecha en que ocurrió el caso, la fecha del reporte, el resultado del trámite, esto es acuerdo, remisión o archivo. Con el informe se procurará recomendar al Comité sobre aquellas acciones o estrategias que deberían desarrollarse para prevenir aquellas conductas que por su multiplicidad en los reportes o por su gravedad, requieren de intervención inmediata para evitar la reiteración de las mismas.

La Universidad EAFIT declara su compromiso con los principios de no tolerancia y no neutralidad frente a actos de violencia, discriminación, hostigamiento, maltrato e irrespeto de las personas en razón del género y, de la sexualidad diversa. Para prevenir y atender los hechos que se enmarquen en tales conductas, se establecen las siguientes acciones de prevención y ruta de atención:

**5.1 Acciones de Prevención:**

La institución continuará promoviendo una cultura del mutuo cuidado y de respeto entre todos sus integrantes, donde se valore la diferencia, se propicien acciones para alcanzar la igualdad de oportunidades para todas las personas y, se rechace cualquier acto de violencia.

De otro lado, promoverá acciones que contribuyan a cambios estructurales necesarios hacia una educación no sexista y fomentar una cultura de rechazo a las violencias basadas en género.

Para prevenir, detectar, diagnosticar, hacer seguimiento y evaluación al presente Protocolo, se implementarán, entre otras, las siguientes acciones:

**5.1.1 Sensibilización y difusión:** La institución realizará campañas de sensibilización y de difusión de este protocolo con el fin de evitar o minimizar los posibles casos de violencia, discriminación, hostigamiento, maltrato e irrespeto de las personas relacionados con las condiciones particulares de género, sexo y las diferentes manifestaciones de la sexualidad humana y diversa.

**5.1.2 Detección:** La Institución adelantará estrategias para realizar un diagnóstico con el propósito de detectar las posibles transgresiones a los derechos de las mujeres o de las personas en razón de su orientación sexual, o identidad de género y, de las diferentes manifestaciones de la sexualidad humana y diversa, las brechas existentes y las causas de las distintas situaciones de maltrato, hostigamiento discriminación y violencia, teniendo presente el contexto cultural, económico y social.

**5.1.3 Formación:** La Institución implementará estrategias dirigidas a capacitar en género, sexualidad humana, diversidad e inclusión, a los profesores, estudiantes y personal administrativo, con el fin de sensibilizar y concientizar sobre el reconocimiento del otro, procurando la transformación del imaginario social anclado en prejuicios y estereotipos de género, sexualidad y diversidad.

**5.1.4 Investigación:** La Institución fomentará las líneas de investigación en igualdad de género, sexualidad diversa, diversidad e inclusión, con el fin de propiciar espacios académicos de reflexión con miras a superar las brechas de inequidad y exclusión.

**5.1.5 Acompañamiento:** La Institución establecerá los mecanismos necesarios y adecuados para la eficaz implementación y seguimiento de este Protocolo, lo que comprende la asistencia directa y personalizada a las personas sobre las distintas etapas que conforman la ruta de atención de que trata este Protocolo.

**5.1.6 Orientación:** La institución establecerá los responsables de brindar asesorías y orientación a los integrantes de la comunidad académica que así lo requieran, la que comprenderá las rutas de atención y acciones de prevención para conocer y atender cualquier hecho de violencia, discriminación, hostigamiento, maltrato e irrespeto de las personas que tengan su causa en el género y en la sexualidad diversa.

**5.2 Rutas de atención.**

Con el compromiso institucional de obrar con debida diligencia y cuidado y, trabajar para generar espacios de confianza y seguros, libres de cualquier acto de discriminación, hostigamiento, maltrato y violencias que tengan su causa en el género y en la sexualidad diversa, se observarán los siguientes criterios de atención:

**5.2.1 Criterios de atención:** La Universidad EAFIT acoge los lineamientos de la Corte Constitucional en las Sentencias: T- 012 del 2016 y T 735 de 2017 que dispone de unas orientaciones para la atención de personas víctimas de violencia de género y sexual. Estos criterios también aplican para los casos que puedan presentarse situaciones con relación a la sexualidad diversa:

“(i) desplegar toda actividad investigativa en aras de garantizar los derechos en disputa y la dignidad de las mujeres;

(ii) analizar los hechos, las pruebas y las normas con base en interpretaciones sistemáticas de la realidad, de manera que en ese ejercicio hermenéutico se reconozca que las mujeres han sido un grupo tradicionalmente discriminado y como tal, se justifica un trato diferencial;

(iii) no tomar decisiones con base en estereotipos de género;

(iv) evitar la revictimización de la mujer a la hora de cumplir con sus funciones; reconocer las diferencias entre hombres y mujeres;

(v) flexibilizar la carga probatoria en casos de violencia o discriminación, privilegiando los indicios sobre las pruebas directas, cuando estas últimas resulten insuficientes;

(vi) considerar el rol transformador o perpetuador de las decisiones judiciales;

(vii) efectuar un análisis rígido sobre las actuaciones de quien presuntamente comete la violencia;

(viii) evaluar las posibilidades y recursos reales de acceso a trámites judiciales;

(ix) analizar las relaciones de poder que afectan la dignidad y autonomía de las mujeres”.

**5.3 Procedimiento**

**5.3.1 Reporte de la queja.**

Cualquier persona podrá reportar una situación de discriminación, hostigamiento, maltrato y violencia que tengan su causa en el género y en la sexualidad diversa; a través de la línea de transparencia, cuyos enlaces son:

Línea telefónica gratuita y confidencial, para llamadas nacionales, desde su celular o número fijo: 01-8000-11-11-55

Lo anterior, sin perjuicio, de que pueda reportarse la queja directamente ante la Coordinadora de Género, Diversidad e Inclusión.

En ningún caso se exigirán pruebas, para asumir el conocimiento del caso. Bastará el sólo dicho de la víctima para activar la ruta de atención.

Cuando el reporte provenga de un anónimo, no se activará el trámite a cargo del Comité de Género, Diversidad e Inclusión, salvo que el hecho reportado permita adelantar la investigación de oficio, por contener la información del posible presunto responsable y las situaciones de tiempo, modo y lugar en que ocurrieron los hechos.

En todos los eventos en que el acto violento o agresión ocurra en las instalaciones de la Universidad, cualquier persona podrá en ese mismo momento activar la línea 911 de emergencias de la Institución, la que conforme a su Protocolo se encargará de adoptar las medidas de atención urgentes que el caso requiera.

**5.3.2 inicio de la ruta interna: Atención integral**

**5.4.3.2.1. Atención Inicial.**

La institución cuenta con una ruta de atención de emergencia a través de la línea 911, para los casos de violencia dentro de las instalaciones de la Universidad, esta tiene como propósito brindar los primeros auxilios a la víctima, comprendiendo la atención psicológica en caso de que así se requiera y siempre que lo acepte la víctima.

La primera atención a la persona afectada por las violencias de género se realizará a través de la Coordinación de Género, Diversidad e Inclusión, para orientar a la persona sobre los derechos, procedimientos y garantías brindadas en este protocolo. De acuerdo con las circunstancias del caso se prestarán los servicios de estabilización psicológica para un adecuado abordaje de la situación.

**5.4.3.2.2. Entrevista con la víctima.** La Coordinadora de Género, Diversidad e Inclusión, dentro de los cinco días hábiles siguientes a la recepción del reporte, citará a quien lo formula con el fin de ampliar, aclarar o precisar su declaración.

Desde el inicio de la ruta:

Se ofrecerá orientación clara y completa sobre el alcance y trámite de la mediación.

Durante todo el trámite de la mediación con enfoque restaurativo se garantizará el principio de confidencialidad y de protección de la identidad de la persona que formule la queja y del presunto responsable.

Se evaluarán las posibles situaciones de riesgo en que se encuentre la víctima, con el fin de adoptar medidas urgentes de atención integral de calidad y eficientes, es decir, apoyo psicológico, atención en crisis, apoyo legal, médico, académico y de protección en caso de ser requerido.

Se ofrecerá atención y acompañamiento psicológico por la unidad competente, lo que comprenderá la evaluación del riesgo psicosocial en el caso de los empleados.

Se ofrecerá atención y acompañamiento médico. Para estos efectos, el servicio médico, salud y seguridad en el trabajo cuentan con un protocolo de atención a víctimas de violencia basadas en género y su personal médico tiene formación en temas de género.

Se evitarán las repeticiones innecesarias y los comentarios o juicios acerca de la conducta de la víctima, o las expresiones tendientes a atribuir responsabilidades sobre los hechos reportados, o expresar sentimientos de consideración o lástima.

No se admitirán los juicios u opiniones personales por parte de quienes intervengan en la entrevista.

Se informará del derecho que le asiste a la persona afectada con los hechos de violencia a no ser confrontada con su agresor.

Se evitará la confrontación entre los asistentes a la conversación.

Se ofrecerá orientación clara y completa sobre el trámite del proceso disciplinario.

Se ofrecerá orientación clara y completa sobre las acciones jurídicas que protegen el derecho que se afirma fue vulnerado por un tercero, lo que comprende el proceso penal, en el evento en que se advierta que la conducta reportada puede constituir un delito.

**5.3.2.2 Consentimiento de la víctima.**Para dar inicio al presente abordaje, es necesario el consentimiento de la víctima para participar en este abordaje restaurativo, lo que se hará una vez que ésta conoce del alcance del presente trámite. Del consentimiento se dejará constancia escrita.

**5.3.2.3 Medidas urgentes y de protección.** Después de la entrevista con la víctima, el Comité de Análisis de Caso analizará las posibles situaciones de riesgo en que se encuentre la víctima, con el fin de adoptar medidas urgentes y de protección, tendientes a asegurar el acceso y la permanencia en el sistema educativo superior, dichas medidas pueden ser:

Separar del aula de clase al o la estudiante que se reporta como presunto responsable.

Garantizar la continuidad del proceso académico al estudiante que temporalmente se separa del aula de clase, haciendo uso de las diferentes modalidades de clase, horarios entre otros.

Flexibilizar la asistencia a clase y las evaluaciones de la víctima y del presunto responsable, en el evento en que el estado emocional de los mismos interfiera con su proceso de aprendizaje.

Separar del lugar de trabajo y del aula de clase, al profesor o colaborador, que se reporta como presunto responsable.

La reubicación laboral del presunto responsable.

Suspender temporalmente al agresor mientras se investiga y sanciona por la presunta acción cometida.

Cambios en los horarios de trabajo del presunto responsable cuando se trate de un empleado de la Universidad para evitar escenarios de confrontación o de revictimización.

Las estrategias mencionadas anteriormente son de carácter enunciativo mas no limitativo. Es decir, el Comité de análisis de caso podrá precaver otras medidas de acuerdo al caso.

Las medidas urgentes permanecerán el tiempo que se requiera para evitar un daño mayor a la Victima.

**5.3.2.4 Escuchar a la persona contra la cual se formule la queja.** Dentro de los cinco días hábiles siguientes a la entrevista con la víctima que reporta el caso, o del tercero que reporta, se citará a la persona contra la cual se formula la queja para escuchar su versión sobre los hechos reportados.

En esa entrevista se le informará al presunto responsable del procedimiento a seguir, y del derecho a recibir información completa y oportuna del estado del presente trámite. Así mismo se le ofrecerá apoyo psicológico por parte de la Universidad, lo que comprende la valoración del riesgo psicosocial, si se trataré de un empleado.

**5.3.2.5 Consentimiento del presunto responsable.** Para dar inicio al presente abordaje, es necesario el consentimiento del presunto responsable para participar en este abordaje restaurativo de la mediación, lo que se hará una vez que éste conoce del alcance del presente trámite. Del consentimiento se dejará constancia escrita.

**5.3.3 Abordaje de mediación con enfoque restaurativo.**

Consciente del poder transformador de la educación, la universidad propiciará espacios de reflexión y mediación con un enfoque restaurativo, para que a través del diálogo se generen espacios que contribuyan a aprender, desaprender, reconocer y crear conciencia sobre los propios comportamientos, sesgos, estereotipos y conductas que inciden en la continuidad de las violencias y de los actos de discriminación.

En consecuencia, en cada caso, se valorará la verdad, la necesidad de reparar el daño que se ha causado y, el compromiso del presunto responsable para evitar la repetición de los hechos reportados.

Durante todo el trámite, se garantizará el principio de confidencialidad y de protección de la identidad de la persona que formule la queja y del presunto responsable, por lo tanto, se dispondrá de un código alfanumérico para identificar el caso de que se trate.  En las comunicaciones que se produzcan durante el trámite, solamente se identificará a los intervinientes con dicho código.

Si el trámite de mediación termina con un acuerdo de medidas restaurativas, se dejará constancia por escrito del mismo, la que se suscribirá por las partes intervinientes.

Corresponderá a la Coordinadora de Género, Inclusión y Diversidad hacer seguimiento al cumplimiento de los compromisos acordados y, en caso de incumplimiento de los mismos, o de que se reitere la conducta que dio origen al presente trámite se convocará al Comité de Análisis de Casos para determinar si se retoma este abordaje o si se remite a otra instancia institucional.

**5.3.4 Articulación otras instancias.**

En este apartado se indica la ruta de articulación interna para la procedencia de la remisión de los casos al ente competente para la investigación y sanción, además, de las rutas de atención externas según sea el caso.

**5.3.4.1. Ruta de remisión de casos Interna.**

El Comité de Género, Diversidad e Inclusión hará remisión del caso reportado en los siguientes casos:

Cuando la víctima así lo considere, sin que previamente se requiera agotar el trámite que prevé el presente Protocolo.

Cuando en razón de las circunstancias de tiempo, modo y lugar en que se desarrollan los hechos no sea pertinente el abordaje de mediación con enfoque restaurativo.

Se establecen los siguientes criterios para la remisión:

Cuando se trate de hechos reiterativos asociados a violencia de género.

Cuando el caso reportado sea de abuso sexual, violación, u otra conducta que atente contra la integridad física y sexual de las personas, salvo que la víctima no consienta la remisión al proceso disciplinario.

Cuando el presunto responsable ocupe un cargo de superior jerarquía frente a la víctima, salvo en aquellos casos, en que se trate de una única situación y que la conducta reportada se asocie a la reproducción de estereotipos de género o sesgos, en cuyo caso, se valorará la pertinencia de abordar el caso, con un enfoque de mediación que contribuya a crear consciencia sobre el rol que cada persona tiene desde su quehacer y la responsabilidad social de promover relaciones respetuosas y sin discriminación.

En aquellos eventos en que la víctima o el presunto responsable no expresen su consentimiento para participar en el abordaje de mediación con enfoque restaurativo.

Cuando fracase el abordaje de mediación y, en concepto del Comité de Análisis de Casos es necesario investigar para determinar si los hechos reportados ocurrieron o no y, por consiguiente, si hay lugar a una sanción.

Cuando fracasa el abordaje de mediación con enfoque restaurativo y la víctima decide activar el trámite del proceso disciplinario.

Cuando los hechos que se ponen en conocimiento corresponda a otras instancias institucionales, esto es:

Si se trata de fraude contra la integridad académica o violación al reglamento de Pregrado por parte de un estudiante, se remitirá al Comité Disciplinario.

Si se trata de un caso de maltrato, hostigamiento violencia no basada en género y, cuando las personas involucradas son empleados de la universidad, se remitirá al Comité de Acoso Laboral.

Si se trata de conductas propias de la relación académica se remitirá a la respectiva Escuela.

Si se trata de conductas propias de la relación académica de estudiantes de posgrado, Maestría o doctorado se remitirá al Comité de ética.

En el trámite del proceso disciplinario, se le dará celeridad al mismo con el fin de garantizar la adecuada atención a la víctima y de ser el caso, mantener las medidas urgentes y de protección. La víctima es libre de participar o no dentro del proceso disciplinario y en ningún caso se le podrá obligar a participar en una confrontación con el presunto responsable.

El trámite del proceso disciplinario es una instancia diferente e independiente del abordaje de Mediación con enfoque restaurativo. Por consiguiente, en esa instancia no se podrá acceder a las conversaciones y grabaciones que se realicen en el marco del abordaje de mediación, las que están protegidas por el principio de confidencialidad; a excepción de las denuncias que podrán ser remitidas al ente disciplinario desde el inicio, por el deseo de la víctima o porque fracase la mediación.

**5.3.4.2. Rutas externas.**

A continuación, se señalan las rutas de atención para la garantía y el restablecimiento de derechos de las mujeres víctimas de violencia de género, estas cuentan con las asistencias en todos los niveles: Nacionales, departamentales y municipales.

**Tipo de caso****Dónde reportar**
Restablecimiento de derechos para adolescentes Línea única 0​18000918080 o 141.

Correo electrónico: [atencionalciudadano@icbf.gov.co](msilto: atencionalciudadano@icbf.gov.co)

Centros zonales ICBF

Comisarías de Familia
Denuncia por material con contenido sexual infantil[Sistema de denuncia virtual](https://adenunciar.policia.gov.co/Adenunciar/)
Denuncia por violencia intrafamiliar, sexual o de género y trata de personas Fiscalía: Línea 122

Comisaría de Familia (Violencia Intrafamiliar)
Atención de la Consejería Presidencial para la equidad de la Mujer con el apoyo de la Policía Nacional para casos de violencia -Línea púrpura-Línea 155
Atención en situación de riesgo, emergencia Línea de emergencia 123
Violencia basada en género Línea 123 Mujer

WhatsApp: 321 467 70 71 – 305 319 28 72. Horario de atención: de 8:00 a. m. a 5:00 p. m.
Violencia intrafamiliar Comisaría de Familia

Línea 141 ICBF

Casa de Justicia El Bosque: Teléfono 604 385 55 55 Ext. 9785, 9786, 9782 y 9783. Horarios de atención: lunes a jueves de 7:30 a. m. a 5:30 p. m. y viernes, sábados y domingos de 7:30 a.m. a 4:30 p. m. Teléfono 604 493 98 70 –604 493 98 71 – 604 493 98 66 y 604 493 98 68. Horario de atención: de 10:00 p. m. a 6:00 a. m.
Violencia Intrapersonal Inspección de Policía: delitos menores y contravenciones
Violencia Institucional Personería

Defensoría del Pueblo- Regional Antioquia Dupla de Género

Procuraduría General de la Nación
Violencia sexual Hospitales

EPS

IPS.

Fiscalía
Para recibir orientación En Medellín: Línea 123 -Agencia Mujer-

Secretaría de las Mujeres

En el área metropolitana: Línea 123 Mujer Metropolitana.

En el resto de Antioquia: Línea única nacional 155 o en la Secretaría de las Mujeres

o la línea Salud Para el Alma: 6044407643
Atención psico jurídica para mujeres víctimas o en riesgo de violencia 604 260 14 00 – 300 587 52 19
Para solicitar ayuda inmediata En Medellín: Línea 123 Agencia Mujer

En el área metropolitana: Línea 123 Mujer Metropolitana.

En el resto de Antioquia: llamar a la Policía del cuadrante que corresponda a tu domicilio o a la Estación de Policía del Municipio.

Si la mujer reside en una vereda: Inspección de Policía.

Si la mujer vive en una comunidad Indígena: Cabildo o Sailato.
Para solicitar protección Comisaría de Familia

Juez control de Garantías por solicitud de la Fiscalía, la Víctima o su Representante.

​Fuente: Adaptación realizada a la Caja de Herramientas No. 7 de las Autoridades Unidas por una Vida Libre de Violencias contra las Mujeres y, de las rutas previstas por la Secretaría de Mujeres de Medellín y por la Secretaría de las Mujeres de la Gobernación de Antioquia.

**5.3.6 Seguimiento de los casos atendidos**

El Comité de Género, Diversidad e Inclusión se encargará de realizar el seguimiento de todas las medidas y estrategias adoptadas en virtud de este Protocolo, con el fin de conocer el impacto en la comunidad y adoptar los correctivos necesarios para restablecer los derechos de las víctimas y evitar la repetición de las conductas investigadas en cualquier ámbito de la Universidad.

El Comité determinará las fechas de seguimiento atendiendo a la situación particular, pero en todo caso el primer seguimiento se realizará tres (3) meses después de la decisión final del mismo Comité.

**5.6.7 Flujograma de ruta de atención**

**6.1 Niños, niñas o adolescentes.**

En aquellos eventos en que la víctima sea un niño, niña o adolescente, se tendrá presente la primacía de los derechos de los mismos que consagra la Constitución Política, la Convención sobre los Derechos del niño y el bloque de constitucionalidad, las disposiciones de protección y restablecimiento de derechos previstos en la Ley 1098 de 2006 -Código de Infancia y Adolescencia.

En todos los trámites que la Institución adelante con ocasión de estos hechos, además, de lo descrito en los apartados anteriores, se tendrá presente:

Se garantizará el principio de confidencialidad.

Se protegerá la identidad del niño, niña o adolescente y de su grupo familiar.

Se informará de manera inmediata a los padres o representante legal o persona responsable de su cuidado.

Se respetará el derecho a ser escuchados.

El Comité y las distintas personas que en razón de sus funciones deban participar, tendrán presente que no podrán realizar comentarios desestimando la validez del testimonio del niño, niña o adolescente, en razón de su edad, ni en razón de estereotipos de género o discriminación por su orientación sexual, por la pertenencia étnica racial, por la discapacidad, la neurodiversidad y por su situación económica.

En aquellos casos en que el niño, niña o adolescente se encuentre en situación de peligro en su integridad física o psicológica, o éste sea de violencia o abuso sexual, de inmediato se informará a sus padres o representante legal o la persona responsable de su cuidado, igualmente, a Bienestar Familiar a través de la Comisaría de Familia o, a las autoridades penales o de policía que corresponda. Cuando se sospeche que la agresión puede provenir de sus padres o del cuidador, sólo se informará a Bienestar Familiar y a las autoridades que correspondan.

El Comité se abstendrá de provocar encuentros entre la víctima y el presunto responsable. Si se hace necesario el testimonio del niño, niña o adolescente dentro de la investigación que adelante la Institución, sólo podrá recibirse su declaración si este se encuentra en presencia de sus padres o representantes legales y en todo caso se procurará además la intervención de un psicólogo, como apoyo al menor para la libre expresión de su propio discurso.

**6.2 Personas con contrato de prestación de servicios con la Universidad, empleados de contratistas u outsourcing, y empleados de concesionarios.**

En estos eventos la persona que llegaré a ser objeto de discriminación, maltrato físico o psicológico dentro de las instalaciones de la Universidad o con ocasión de los servicios que presta, en caso de ser necesario una atención inminente, se activará la ruta de atención de emergencia a través de la línea 911, para brindar los primeros auxilios a la víctima, la que comprende la atención psicológica en caso de que así se requiera y siempre que lo acepte la víctima; así mismo se le brindará la orientación legal que requiera para activar la ruta de protección a sus derechos.

De igual manera la víctima podrá denunciar los hechos ante el Comité de Género, Diversidad e Inclusión para que la misma defina el procedimiento a seguir de acuerdo con los parámetros establecidos en este Protocolo.

Por otra parte, si la persona contra la cual se formula la denuncia se encuentra vinculado a la Universidad a través de contrato de prestación de servicios, o es empleado de contratistas, outsourcing, o empleados de concesionarios de la Institución, el Comité de Análisis de Casos informará a la Secretaría General y la Dirección Administrativa y Financiera para la adopción de todas aquellas medidas tendientes a informar al contratante y para que se adopten los trámites necesarios con el propósito de iniciar la investigación que corresponda.

Todo lo anterior, sin perjuicio, de que, según los términos del contrato, pueda invocarse la terminación de la relación contractual o la aplicación de las sanciones contractuales previstas en el respectivo convenio.

Si se evidencia la comisión de un ilícito, se formulará la denuncia ante las autoridades competentes, siempre que el delito o la conducta no sean de aquellos que la ley exija que deben denunciarse únicamente por la víctima.

**6.3 Estudiantes en semestre de práctica en entidades externas.**

Cuando la presunta víctima se encuentre realizando su semestre de práctica profesional y la conducta objeto de denuncia se haya presentado en la empresa o institución en la cual se esté desempeñando, el Comité de Análisis de Casos una vez que conozca del caso procederá a informar la situación a la respectiva entidad, a efectos de que determine la viabilidad de iniciar la investigación correspondiente.

En todo caso, se activará la ruta de atención para la protección de la víctima acorde a lo contemplado en este Protocolo.

Así mismo, la Universidad analizará la pertinencia de continuar o no con el convenio de práctica profesional con la entidad en la que se presentaron los hechos.

**6.4 Pasantes.**

Si la víctima de maltrato, discriminación, violencias basadas en el género, se encuentra realizando una pasantía en la Universidad, se activará la ruta de emergencia señalada por la institución a través de la línea 911, para brindar los primeros auxilios a la víctima, la que comprende la atención psicológica en caso de que así se requiera y lo acepte la víctima y la orientación legal que requiera para activar la ruta de protección a sus derechos.

De igual manera la víctima podrá denunciar los hechos en la línea de transparencia y el Comité de Análisis de Casos definirá el procedimiento a seguir de acuerdo con los parámetros establecidos en este Protocolo.

Cuando se trate de conductas delictivas que no exijan la denuncia exclusivamente por parte de la víctima, se alertará a las autoridades policiales y judiciales competentes.

**6.5 Visitantes.**

Si la víctima de maltrato, discriminación, violencia, violencia basadas en el género, no tiene ninguna relación con la Universidad, y se encuentra asistiendo a un evento, o en condición de visitante, se activará la ruta de emergencia señalada por la institución a través de la línea 911, para brindar los primeros auxilios a la víctima, la que comprende la atención psicológica en caso de que así se requiera y lo acepte la víctima y la orientación legal que requiera para activar la ruta de protección a sus derechos.

Cuando se trate de conductas delictivas que no exijan la denuncia exclusivamente por parte de la víctima, se alertará a las autoridades policiales y judiciales competentes.

**7.1 Formación.**

La Dirección de Desarrollo Humano, se encargará de propiciar la capacitación en enfoque de género y de sexualidad diversa, a los integrantes del Comité de Género, Diversidad e Inclusión, los Comités disciplinarios, al personal de seguridad y a los Departamentos de servicio médico y Seguridad y Salud en el Trabajo, desarrollo de empleados y desarrollo estudiantil. Para estos efectos, se coordinará la misma con Desarrollo de Empleados.

También se dictará formación básica en género a los estudiantes y empleados de la Universidad, lo que se hará de manera progresiva, iniciando con un curso básico y que año tras año, se irá complementando y profundizando con temáticas que permitan generar conciencia sobre las violencias de género y las brechas todavía hoy existentes entre hombres y mujeres.

Para las capacitaciones a los integrantes del Comité de Género, Diversidad e Inclusión, al cuerpo profesoral, estudiantes y personal administrativo, el Comité de Género, Diversidad e Inclusión contará con seis (6) meses a partir de la aprobación del presente Protocolo, para programar las mismas.

Las campañas de reflexión para trabajar por la eliminación de prejuicios y estereotipos basados en género y sexualidad diversa, se iniciarán de manera inmediata a la aprobación de este Protocolo. Así mismo, se diseñará una campaña para socializar entre la comunidad eafitense y el público en general el presente Protocolo, el que deberá encontrarse en la página web institucional.

**7.2 Indicadores.**

El Comité de Género, Diversidad e Inclusión, a través de indicadores, medirá cuantitativa y cualitativa el nivel de avance e implementación del presente Protocolo y, además de indicadores de gestión que permitan evaluar la pertinencia y eficacia de las acciones programadas para la detección, prevención y atención de violencias de género.

**7.3 Seguimiento y revisión del Protocolo**

Con fundamento en el resultado de los indicadores de implementación del Protocolo, se procederá a su ajuste, modificación o adopción de las acciones tendientes a garantizar la permanencia y efectividad del presente Protocolo y, en su momento cuando la Universidad cuente con una política de género, los indicadores también permitirán hacer seguimiento a los lineamientos que allí se definan. La primera revisión se efectuará al año siguiente de la promulgación del presente Protocolo.

El presente Protocolo y las actuaciones del Comité de Género, Diversidad e Inclusión y de la Comisión de Análisis de Casos tienen como marco de referencia las siguientes normas e instrumentos:

**Constitución Política de Colombia:**

Artículos 1: Estado social. Artículo 2: Protección de derechos. Artículo 5: Primacía de los derechos inalienables. Artículo 13: Igualdad.

Artículo 16: Libre desarrollo de la personalidad. Artículo 40: Adecuada y efectiva participación de las mujeres en los niveles decisorios de la administración pública. Artículo 42: Familia. Artículo 43: Igualdad de derechos y oportunidades para hombres y mujeres.

Artículo 53: Protección especial para la mujer. Artículo 67: Derecho a la educación. Artículo 69: Autonomía universitaria.

**Instrumentos Internacionales:**

La Convención sobre la Eliminación de Todas las Formas de Discriminación contra la Mujer (CEDAW), en especial, su artículo 10 señala “Los Estados Partes adoptarán todas las medidas apropiadas para eliminar la discriminación contra la mujer a fin de asegurarle la igualdad de derechos con el hombre en la esfera de la educación”, Colombia ratificó este instrumento mediante la Ley 51 de 1981.

La Convención Interamericana para Prevenir, Sancionar y Erradicar la Violencia contra la Mujer (Belem do Pará), que se ratificó por el Estado Colombiano mediante la Ley 248 de 1995.

La Convención Interamericana de Derechos Humanos (Pacto San José), ratificado por la Ley 16 de 1972.

El Protocolo Adicional a la Convención Americana sobre Derechos Humanos (Protocolo de San Salvador) , ratificado por la Ley 319 de 1996.

El Protocolo facultativo de la Convención sobre la Eliminación de todas las Formas de discriminación contra la Mujer, ratificada por Ley 984 de 2005.

La Convención sobre la tortura y otros tratos o penales crueles, inhumanos o degradantes, ratificado por el Estado Colombiano a través de la Ley 70 de 1986.

Los Principios de Yogyakarta, La Corte Constitucional incorporó al análisis de la discriminación por identidad de género u orientación sexual, los Principios constituyen un parámetro integral para aplicar de manera eficiente el Derecho Internacional de los Derechos Humanos aplicando los principios generales del soft law, entendidos como los “instrumentos internacionales que no obstante no ser vinculantes tienen relevancia jurídica, si no también albergar bajo su mando diversas manifestaciones de acuerdos interestatales y consensos internacionales que independientemente de su valor jurídico se incorporan al discurso internacional y producen ciertos efectos que repercuten de diferentes formas en la formación, desarrollo, interpretación, aplicación y cumplimiento del derecho internacional, tanto en el ámbito interno de los Estados como en el propio seno del derecho internacional” (Corte Constitucional, Sentencia T 077 de 2016).

La Declaración y Plataforma de Acción de Beijing de 1995, fue adoptada por Colombia, se trata de un programa de empoderamiento para las mujeres y las niñas y para la eliminación de las barreras sistemáticas que impiden la participación igualitaria, entre ellas este instrumento pide al Estado garantizar la adopción de medidas que permitan un sistema educativo sensible al género que elimine todas las formas de discriminación en la educación.

Objetivos de Desarrollo Sostenible de la Asamblea General de las Naciones Unidas (2005), dentro de sus numerales 4 y 5 se encuentran como metas para el 2030 que los estudiantes adquieran conocimientos teórico-prácticos tales como: estilo de vida sostenible, derechos humanos, igualdad de género, cultura de paz y no violencia entre otros (Lineamientos de Prevención, Detección, Atención de violencias y cualquier tipo de discriminación basada en género en Instituciones de Educación Superior (IES), 2022).

La Declaración sobre Orientación Sexual e Identidad de Género de la Asamblea General de las Naciones Unidas (2008), reiterando el derecho de no discriminación y condenando la violencia, acoso, exclusión, estigmatización y prejuicio contra personas por causa de su orientación sexual o identidad de género.

Resolución 17/19 de la Asamblea General de las Naciones Unidas de (2011), allí se expresa la preocupación por los actos de violencia y discriminación por razones de orientación sexual e identidad de género existentes en el mundo y se pide a la Alta Comisionada que documente leyes y prácticas discriminatorias.

Protocolo para Prevenir, Reprimir y sancionar la Trata de Personas, especialmente Mujeres y Niños (Protocolo de Palermo), se ratificó en la Ley 800 de 2003.

Convención sobre los Derechos del Niño (OEA,) ratificada por Colombia en Ley 12 de 1991.

Convenio sobre pueblos indígenas y tribales en países independientes, ratificada en la Ley 21 de 1991, allí se aprueba el convenio número 169 adoptado en la 76a reunión de la conferencia internacional de la O.I.T., Ginebra, 1989: los pueblos indígenas y tribales deben gozar plenamente de los derechos humanos y libertades fundamentales, sin barreras y sin discriminación.

**Leyes:**

Ley 70 de 1993, se establece el reconocimiento y la protección de la diversidad étnica y cultural y el derecho a la igualdad de todas las culturas que conforman la nacionalidad colombiana.

Ley 731 de 2002, busca mejorar la calidad de vida de las mujeres rurales, priorizando las de bajos recursos, estableciendo medidas para la equidad entre el hombre y la mujer rural, particularmente, pretende garantizar el acceso a la educación para las mujeres rurales.

La Ley 1434 de 2011, mediante la cual se establecen los mecanismos para fomentar la participación de la mujer en la tarea legislativa y de control político, a través de la creación de la Comisión Legal para la Equidad de la Mujer en el Congreso de la República.

La Ley 581 de 2000, mediante la cual se establecen los mecanismos para garantizar la adecuada y efectiva participación de las mujeres en todas las ramas y demás órganos del poder público y en las instancias de decisión de la sociedad civil.

La Ley 823 de 2003, mediante la cual se establecen mecanismos para garantizar la equidad e igualdad de oportunidades de las mujeres, en la esfera pública y privada.

En la Ley 985 de 2005, se adoptan medidas contra la trata de personas y normas para la atención y protección de las víctimas; en materia de educación el Ministerio de Educación Nacional, en colaboración con las instituciones relacionadas con el tema, diseñará y aplicará programas de prevención de la trata de personas en los niveles de Educación Básica, Media y Superior.

La Ley 1098 de 2006, Código de Infancia y Adolescencia.

La Ley 1146 de 2007, establece medidas para la prevención de la violencia sexual y atención integral de los niños, niñas y adolescentes abusados sexualmente. Igualmente, establece la obligación en las instituciones de Educación Media y Superior de incluir en sus programas cátedras para la educación sexual y respeto a la dignidad humana.

Ley 1257 de 2008, se adopta normas de sensibilización, prevención y sanción de las formas de violencia y discriminación contra las mujeres, se especificaron los derechos de las víctimas de violencias basadas en género y se estableció el delito de acoso sexual.

Ley 1381 de 2010, se dictan normas sobre reconocimiento, uso, protección, fomento, preservación y fortalecimiento de las lenguas de los grupos étnicos de Colombia.

La ley 1482 de 2011, modificada por la Ley 1752 de 2015, consagra el tipo penal para los actos de discriminación por razones de raza, etnia, religión, nacionalidad, ideología política o filosófica, sexo u orientación sexual, discapacidad y demás razones de discriminación.

Decreto 4798 de 2011, a través del cual se dictan normas de sensibilización, prevención y sanción de formas de violencia y discriminación contra las mujeres y se da directrices en esta materia al sistema educativo.

Ley 1542 de 2012, establece garantías de protección y diligencia de la autoridad en la investigación de los presuntos delitos de violencia contra las mujeres, elimina el carácter de querellable de los delitos de violencia intrafamiliar e inasistencia alimentaria.

Ley 1616 de 2013, garantías del derecho a la salud mental, priorizando la atención de niños, niñas y adolescentes.

Ley 1639 de 2013, se fortalecen las medidas de protección a la integridad de las víctimas de crímenes con ácido.

Decreto 1930 de 2013, se adopta la política pública nacional de equidad de género.

Ley 1719 de 2014, por la cual se adoptan medidas para garantizar el acceso a la justicia de las víctimas de violencia sexual, en especial, la violencia sexual con ocasión del conflicto armado.

Ley 1761 de 2015, por la cual se crea el tipo penal de feminicidio como delito autónomo.

Ley 1773 de 2016, con la cual se modifica la Ley 599 de 2000 y 906 de 2004, y crea un delito autónomo para las lesiones con ácido u otros agentes químicos.

Ley 1996 de 2019, se establecen mecanismos para la garantía del derecho a la capacidad legal plena de las personas con discapacidad, adultos mayores, y al acceso de los apoyos que puedan requerirse para el ejercicio de la misma.

El Decreto 762 de 2018, adopta la política y establece garantías para los sectores LGBTI, al derecho a la educación, así como la adopción de medidas para su reconocimiento y respeto.

Ley 2126 de 2021, se establecen derechos y garantías en los casos de violencia Intrafamiliar.

Decreto 487 de 2022, reglamenta el servicio de la valoración de apoyos que requiere la persona con discapacidad para ejercer su capacidad legal que realicen las entidades públicas y privadas en los términos de la ley 1996 de 2019.

Ordenanza Departamental No. 03 de 14 de mayo de 2010 de la Asamblea Departamental de Antioquia, se indica el carácter obligatorio de la transversalidad de género en el departamento; dicha norma se va actualizando a través de la ordenanza 14 de 2015.

Acuerdo Municipal No. 22 del 12 de agosto del 2003 del Consejo de Medellín, se crea la Política Pública para las Mujeres Urbanas y Rurales del Municipio de Medellín; Acuerdo Municipal No. 01 de 29 de marzo de 2007, por el cual se crea la Secretaria de las Mujeres; esta política se actualiza en el Acuerdo No. 102 de 27 de diciembre de 2018.

**Jurisprudencia de la Corte Constitucional:**

Sentencias: C-804 de 2006, C-811 de 2007, C-075 de 2007, T-1241 de 2008, el Auto 092 de 2008, C-029 de 2009, C-577 de 2011, T-276 de 2012, C-874 de 2014, SU-659 de 2015, C-683 de 2015, C-071 de 2015, T-758 de 2015, T 095 de 2015, T-012 de 2016,  T-077 de 2016, SU-214 de 2016, T-265 de 2016, T-145 de 2017; T-735 de 2017, T-140 de 2021, T-275 de 2021 T-426 de 2021, T061 de 2022, entre otras.

**Refere​ncias​​**

American Psychological Association. (2015). Guidelines for psychological practice with transgender and gender nonconforming people. American Psychologist.

Entidad de las Naciones Unidas para la Igualdad de Género y el Empoderamiento de las Mujeres. (2017). Estudio sobre acoso sexual y otras formas de violencia sexual contra las mujeres y niñas en espacios públicos en la Ciudad de Guatemala. Recuperado de: https://lac.unwomen.org/sites/default/files/Field%20Office%20Americas/Documentos/Publicaciones/2020/05/06/GT_Estudio%20Acoso%20Sexual%20Ciudad%20Guatemala_Estudio-compressed.pdf

Fuentes Vásquez, Lya Y. (2019). "Cuentos que no son cuentos" acoso sexual, violencia naturalizada en las aulas universitarias. Recuperado: file:///C:/Users/user/Downloads/Dialnet-CuentosQueNoSonCuentos-7436434.pdf

Lamas, M. (2009). Fenómeno trans. Debate Feminista, p.p. 39, 3-13. Recuperado de: http://www.jstor.org/stable/42625541

Ministerio de Justicia y del Derecho. (s.f.). Cartilla de género. Recuperado de: https://www.minjusticia.gov.co/programas-co/conexion-justicia/Documents/caja-herramientas-genero/Cartilla%20Género%20final.pdf

Ministerio de Salud y Protección Social de la Republica de Colombia. (2016). Observatorio nacional de violencias ONV Colombia. Línea de violencias de género: Guía metodológica de la línea de violencias de género LVG. Recuperado de: https://www.minsalud.gov.co/sites/rid/Lists/BibliotecaDigital/RIDE/VS/ED/GCFI/guia-ross-observatorio-violencia-genero.pdf

Ministerio de Salud y Protección Social de la Republica de Colombia (2012). Resolución 459 de 2012: Por la cual adopta el Protocolo de modelado de atención integral en salud para víctimas de violencia sexual. Recuperado de: https://www.medellin.gov.co/normograma/docs/astrea/docs/resolucion_minsaludps_0459_2012.htm

Ministerio De Sanidad, Servicios Sociales E Igualdad de España. (2018). Glosario de términos sobre diversidad afectivo sexual. Documento de apoyo para el abordaje de la salud sexual y la diversidad afectivo sexual en la prevención de la infección por el VIH y otras ITS. Recuperado de: https://www.sanidad.gob.es/en/ciudadanos/enfLesiones/enfTransmisibles/sida/docs/glosarioDiversidad110418.pdf

National Geographic. (2017). Género: La revolución. 40. Recuperado de: https://otdchile.org/biblioteca/genero-la-revolucion/

National LGBT Health Education Center. (s.f.). Glosario de términos LGBT para equipos de atención a la salud. The Fenway Institute. Recuperado de: https://www.lgbtqiahealtheducation.org/wp-content/uploads/2018/03/National-LGBT-Health-Education-Center-Glossary.SPANISH-2018.pdf

ONU (2003). Medidas especiales de protección contra la explotación y el abuso sexuales. Boletín del Secretario General. (SGB/2003/13). Recuperado de: https://pseataskforce.org/uploads/tools/secretarygeneralsbulletinspecialmeasuresforprotectionfromsexualexploitationandsexualabuse_unsecretarygeneral_spanish.pdf

ONU Mujeres & Ministerio de Educación de la República de Colombia(2022). Lineamientos de Prevención, Detección, Atención de violencias y cualquier tipo de discriminación basada en género en Instituciones de Educación Superior (IES). Recuperado de: https://www.mineducacion.gov.co/portal/micrositios-superior/Publicaciones-Educacion-Superior/411493:Lineamientos-VBG-para-IES

ONU Mujeres (2019). Estudios exploratorios sobre el acoso sexual en la universidad de San Carlos Guatemala: Evidencias para la toma de decisiones. Recuperado de: https://lac.unwomen.org/sites/default/files/Field%20Office%20Americas/Documentos/Publicaciones/2019/09/Estudio%20exploratorio%20sobre%20el%20acoso%20sexual%20en%20la%20U%20LOW.pdf

ONU Mujeres. (s.f.). Profundicemos en términos de género. [presentación en diapositivas]. Recuperado de: ONU.org.gt. http://onu.org.gt/wp-content/uploads/2017/10/Guia-lenguaje-no-sexista_onumujeres.pdf

ONU Mujer. (s.f.). Preguntas frecuentes: Tipos de violencia contra las mujeres y niñas. Recuperado de: https://www.unwomen.org/es/what-we-do/ending-violence-against-women/faqs/types-of-violence

Organización Internacional del Trabajo. (2019). Convenio sobre la violencia y el acoso, C190-2019. Recuperado de: https://www.ilo.org/dyn/normlex/es/f?p=NORMLEXPUB:12100:0::NO::P12100_ILO_CODE:C190

Organización Panamericana de la salud & Organización Mundial de la salud (2000, mayo 19-22). Promoción de la salud sexual: Recomendaciones [Acta de reunión]. Guatemala. https://iris.paho.org/handle/10665.2/51672

Real Academia de la Lengua. (s.f.). Diccionario de la Real Academia de la Lengua. URL: https://www.rae.es/

UNESCO. (2014). Igualdad de género. En Indicadores UNESCO de cultura para el desarrollo. Recuperado de: https://es.unesco.org/creativity/sites/creativity/files/digital-library/cdis/Iguldad%20de%20genero.pdf

Universidad EAFIT, Centro de integridad. (s.f.). Protocolo para la equidad de género y la sexualidad diversa en la Universidad EAFIT. Recuperado de: https://www.eafit.edu.co/centro-integridad/Documents/Protocolo-genero-eafit.pdf

**Normas**

Asamblea General de las Naciones Unidas (septiembre 25 de 2015). Objetivos de Desarrollo Sostenible. Recuperado de: https://onu.org.gt/objetivos-de-desarrollo/

Asamblea General de las Naciones Unidas (junio 17 de 2011). Resolución 17/19. Recuperado de: https://documents-dds-ny.un.org/doc/UNDOC/GEN/G11/148/79/PDF/G1114879.pdf?OpenElement

Asamblea General de las Naciones Unidas (diciembre 18 de 2008). Declaración sobre orientación sexual e identidad de género. Recuperado de: https://dhpedia.wikis.cc/wiki/Declaraci%C3%B3n_sobre_orientaci%C3%B3n_sexual_e_identidad_de_g%C3%A9nero_de_las_Naciones_Unidas

Asamblea General de las Naciones Unidas (septiembre 15 de 1995). La Declaración y Plataforma de Acción de Beijing. Recuperado de: https://www.acnur.org/fileadmin/Documentos/Publicaciones/2015/9853.pdf

Asamblea General de las Naciones Unidas (3 de septiembre de 1981). La Convención sobre la Eliminación de Todas las Formas de Discriminación contra la Mujer “CEDAW”, Recuperado de: https://www.ohchr.org/es/instruments-mechanisms/instruments/convention-elimination-all-forms-discrimination-against-women

Congreso de la Republica de Colombia (julio 6 de 2015). Ley 1761 de 2015. Por la cual se crea el tipo penal de feminicidio como delito autónomo y se dictan otras disposiciones. (Rosa Elvira Cely). Recuperado de: https://www.medellin.gov.co/normograma/docs/astrea/docs/ley_1761_2015.htm

Organización de los Estados Americanos (junio 9 de 1984). Convención interamericana para prevenir, sancionar y erradicar la violencia contra la mujer "Convención De Belem Do Para". Recuperado: https://www.oas.org/juridico/spanish/tratados/a-61.html

**Jurisprudencia**

Corte Constitucional (febrero 4 de 2022). Sentencia T-033 de 2022. M.P. Gloria Stella Ortiz Delgado. Recuperado de: [https://www.corteconstitucional.gov.co/Relatoria/2022/T-033-22.htm](https://www.corteconstitucional.gov.co/Relatoria/2022/T-033-22.htm)

Corte Constitucional (diciembre 15 de 2017). Sentencia T-735 de 2017. M.P. Antonio José Lizarazo Ocampo. Recuperado: [https://www.corteconstitucional.gov.co/relatoria/2017/t-735-17.htm#:~:text=1.,de%20su%20familia%20ser%C3%A1n%20remplazados.](https://www.corteconstitucional.gov.co/relatoria/2017/t-735-17.htm#:~:text=1.,de%20su%20familia%20ser%C3%A1n%20remplazados.)

Corte Constitucional (enero 22 de 2016). Sentencia T-012 de 2016. M.P. Luis Ernesto Vargas Silva. Recuperado: [https://www.corteconstitucional.gov.co/relatoria/2016/t-01216.htm#:~:text=La%20violencia%20en%20contra%20de,el%20hecho%20de%20ser%20mujer.](https://www.corteconstitucional.gov.co/relatoria/2016/t-01216.htm#:~:text=La%20violencia%20en%20contra%20de,el%20hecho%20de%20ser%20mujer.)

Corte Constitucional (febrero 22 de 2016). Sentencia T-077 de 2016. M.P. Jorge Iván Palacio Palacio. Recuperado: [https://www.corteconstitucional.gov.co/relatoria/2016/t-077-16.htm](https://www.corteconstitucional.gov.co/relatoria/2016/t-077-16.htm)

Corte Constitucional (junio 8 de 2016). Sentencia C-297 de 2016. M.P. Gloria Stella Ortiz Delgado. Recuperado de: [https://www.funcionpublica.gov.co/eva/gestornormativo/norma.php?i=185267](https://www.funcionpublica.gov.co/eva/gestornormativo/norma.php?i=185267)

Corte Constitucional (marzo 10 de 2015). Sentencia T-099 de 2015. M.P. Gloria Stella Ortiz Delgado. Recuerdo de: [https://www.corteconstitucional.gov.co/RELATORIA/2015/T-099-15.htm](https://www.corteconstitucional.gov.co/RELATORIA/2015/T-099-15.htm)

Corte Constitucional (septiembre 10 de 2014). Sentencia C-761 de 2014. M.P. Luis Guillermo Guerrero Pérez. Recuperado de: [https://www.corteconstitucional.gov.co/relatoria/2014/C-671-14.htm](https://www.corteconstitucional.gov.co/relatoria/2014/C-671-14.htm)

Corte Constitucional (diciembre 15 de 2014). Sentencia T-967 de 2014. M.P. Gloria Stella Ortiz Delgado. Recuperado: [https://www.corteconstitucional.gov.co/relatoria/2014/T-967-14.htm](https://www.corteconstitucional.gov.co/relatoria/2014/T-967-14.htm)

Corte Constitucional (noviembre 4 de 2014). Sentencia T-804 de 2014. M.P. Jorge Iván Palacio Palacio. Recuperado de: [https://www.corteconstitucional.gov.co/Relatoria/2014/T-804-14.htm](https://www.corteconstitucional.gov.co/Relatoria/2014/T-804-14.htm)

Corte Constitucional (mayo 25 de 2011). Sentencia C-442 de 2011. M.P. Humberto Antonio Sierra Porto. Recuperado de: [https://www.corteconstitucional.gov.co/relatoria/2011/c-442-11.htm](https://www.corteconstitucional.gov.co/relatoria/2011/c-442-11.htm)

Corte Suprema de Justicia. Sala de Casación Penal. Sentencia SP-107 de 2018. M.P. Luis Guillermo Salazar Otero. Enero 24 de 2018). Recuperado de: [https://cortesuprema.gov.co/corte/index.php/2018/02/23/acoso-sexual-naturaleza-y-caracteristicas/](https://cortesuprema.gov.co/corte/index.php/2018/02/23/acoso-sexual-naturaleza-y-caracteristicas/)

### Ruta de atención en EAFIT para una vida libre de violencia basada en género y discriminación​

## ¿Qué es violencia de género?

"La violencia de género se refiere a los actos dañinos dirigidos contra una persona o un grupo de personas en razón de su género" — ONU Mujeres.

## ¿Qué es discriminación?

"Dar un trato desigual a una persona o grupo de personas por motivos raciales, religiosos, políticos, de sexo, edad, condición física o mental" — RAE,s.f.

¿Cuáles son los tipos de violencia?

## Sexual

Cuando alguien te acosa, te abusa, te toca sin tu consentimiento.

## Psicológica

Cuando alguien te intim

 ida, te humilla y te hace sentir inferior.

## Física

Cuando alguien te agrede, golpea tu cuerpo con intención.

## Económica

Cuando alguien no te permite administrar tu dinero, tu salario o usar la tarjeta de crédito.

## Patrimonial

Cuando alguien te rompe, te esconde tus elementos personales.

Rutas de atención

## Internas

Mediación con enfoque restaurativo.

 Proceso disciplinario.

## Externas

Fiscalía: Línea 122

 Línea Mujer Medellín: 123

 Bienestar Familiar (si la víctima es menor de 14 años)

## Apoyo de la Universidad

Psicosocial

 Jurídico

 Médico

 Académico

 Medidas urgentes de protección

 Proceso disciplinario.

## Compromisos de la Universidad

Cero tolerancia a la violencia

 Debida diligencia en la atención

 No revictimización

 Confidencialidad

 No retaliación

 Línea Mujer Medellín: 123

 Bienestar Familiar (si la víctima es menor de 14 años)

¿Quién p​uede o debe acudir?

Cualquier integrante de la comunidad eafitense que se reconozca como víctima de una situación de discriminación, maltrato, acoso, abuso sexual o violencia basada en género o en la sexualidad diversa.

Cualquier integrante de la comunidad eafitense que se reconozca como víctima de una situación de discriminación, maltrato o violencia que tenga su causa en la discapacidad, neurodiversidad, en la pertenencia étnica o en la vulnerabilidad económica.

Cualquier integrante de la comunidad eafitense que requiera de ajustes necesarios o apoyos razonables para avanzar en su aprendizaje o, para cumplir con sus compromisos laborales, según se trate de un estudiante o empleado.

## ¿Dónde reportar?

### Línea de transparencia

### Correo: EAFIT lineatransparencia

### 01-8000-11-11-55 (hechos dentro de la Universidad)

### Línea de emergencia: 911

### Las iniciativas y publicaciones que nos trajeron hasta este punto

## Respe​​to en EAFIT​​

​La Universidad EAFIT, comprometida con sus valores de integr​​​idad, inclusión y pluralismo, presentó a la comunidad eafitense el proyecto #RespetoEnEAFIT que busca generar sensibilización con dos temas fundamentales en el siglo XXI.​​

## Declaraci​ón por la Integr​idad y e​l resp​​​eto​​

Una reflexión sobre las relaciones interpersonales en pro ​de una comunidad segura, a partir de lazos de confianza.

 ⠀

 ⠀

 ⠀

## Fases de comunicaciones

⠀

## Diálogos de integridad

⠀

## Centro de integridad

⠀

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

National hotline: 01 8000 515 900

Customer service line: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Customer service line: (57) 606 3214115, 606 3214119

Email: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 office 401

Customer service line: (57) 601 6114618

Email: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks