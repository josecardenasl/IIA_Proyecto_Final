# Acción EAFIT​​ - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Buscar 

Búsqueda

Menú

# Acción EAFIT​​

Proyecto Educativo Institucional

 Del 20 al 23 de abril

*    Acción EAFIT​​ 

Acción EAFIT es una invitación a vivir el aprendizaje en movimiento, inquieto y retador. En esta edición, el enfoque estará en las tecnologías en la educación como eje de transformación. Abrimos las puertas de nuestro Campus/Laboratorio Vivo para conectar academia, tecnología y entorno en una experiencia colaborativa de experimentación y conexión.

Este encuentro incluirá eventos formativos como talleres y seminarios, una muestra de iniciativas inspiradoras de aprendizaje experiencial y espacios de conversación que abordan la innovación educativa, el uso de tecnologías y el impacto de la inteligencia artificial en la enseñanza, el aprendizaje y la evaluación.

Te invitamos a ser parte activa en la co-creación del futuro.

**¡Te esperamos en Acción EAFIT!**

**Del 20 al 23 de abril**

## Tipo de eventos que tendremos en Acción EAFIT

### Eventos formativos: Aprende+ EAFIT

### Eventos de conexión

### Muestra de iniciativas

### Eventos culturales

## C​onoce toda la programación​ del 20​ al 23 de abril

Lunes 20 de abril

## Diálogos digitales en el aula de 7:00 a.m. a 9:00 m.

Conversación para reflexionar sobre cómo la inteligencia artificial transforma la manera en que enseñamos, aprendemos y evaluamos. A partir de conceptos del MIT y ejemplos prácticos promoveremos la construcción de diálogos significativos entre estudiantes e IA, pasando de un uso superficial hacia un pensamiento exploratorio y crítico.

 Lidera: Juan Carlos Monroy

 Lugar: Bloque 15 segundo piso - Salón EXA

## Escape Room de 10:00 a.m. a 12:00 m.

Espacio dirigido a profesores o formadores donde aprenderán a diseñar con uso de IA un escape room como metodología experiencial basada en la simulación. 

 Lideran: Mariaclara Olaya Mesa, María Auxiliadora González y Diana Molina Portilla 

 Lugar: EXA - Bloque 15 segundo piso

## Asistente IA para el diseño de syllabus y rúbricas de 2:00 p.m. a 3:30 p.m.

Taller práctico orientado al uso de agentes de inteligencia artificial, desarrollados por EAFIT, para el diseño de syllabus y rúbricas de evaluación, con énfasis en la interacción efectiva entre los profesores y la herramienta. A través de ejercicios guiados, los participantes aprenderán a generar los diseños de sus asignaturas.

 Lidera: Gina Patricia Santana Sanabria

 Lugar: EXA - Bloque 15 segundo piso

## Tertulia voces y experiencias: Aprendizaje E en Acción de 3:30 p.m. a 5:00 p.m.

Conversación abierta y participativa en el que profesores, colaboradores y miembros de la comunidad educativa se reúnen para reflexionar, dialogar y compartir experiencias alrededor del uso e impacto del fondo destinado a impulsar iniciativas de aprendizaje experiencial.

 Lideran: Paola Podestá Correa - Vicerrectora de aprendizaje, Andrés Mauricio Mora Cuartas - Director Desarrollo Académico 

 Invitados: 

 1. María Isabel Hernández Pérez, profesora, E. Ciencias Aplicadas e Ingeniería 

 2. Paulina Yepes Villegas, Decana Asociada E. Artes y Humanidades 

 3. Liliana González Palacio, Profesor, E. Ciencias Aplicadas e Ingeniería 

 4. Manuela Cárdenas Duque, Líder proyectos Kratos 

 Lugar: Bloque 18, piso 2

## Cineclub EAFIT: François Truffaut, cinéfilo y autor. La Piel Dura de 5:00 p.m. a 7:00 p.m.

¿Por qué una programación cultural en Acción EAFIT? En un mundo donde el avance de la tecnología nos induce a estar solos frente a una pantalla, los espacios de encuentro presencial se convierten en pequeños milagros. Sólo el arte y la creatividad nos mantendrá presentes. El arte y la cultura son fundamentales para acompañar la tecnología y su vértigo. 

 Espacio dirigido para la apreciación de la vida y obra del cineasta francés François Truffaut. "La piel dura" es un retrato de las distintas infancias que se viven en el París de la década de los setenta. 

 Lideran: Clara Cristina Acosta Ossa y Santiago Bustos Ayala

 Lugar: Bloque 38, auditorio 110

 Entrada gratuita.

Martes 21 de abril

## Potencia tus cursos en EAFIT Interactiva con Inteligencia Artificial de 8:00 a.m. a 10:00 a.m.

Taller formativo en el uso de LumIA, la inteligencia artificial para EAFIT Interactiva.

 Lidera: Gestión Digital de Aprendizaje 

 Lugar: EXA - Bloque 15 segundo piso

## Seguridad en acción: Protegiendo el Aprendizaje Digital de 10:00 a.m. a 12:00 m.

Conversación práctica para profesores y estudiantes enfocada en reconocer riesgos digitales comunes en el entorno académico y aprender buenas prácticas para proteger datos, plataformas y experiencias de aprendizaje. Incluye microcasos, demostraciones y actividades interactivas para fortalecer una cultura de seguridad en el campus.

 Lidera: Juan Pablo Cardona 

 Lugar: Bloque 18, piso 2

## Conectando capacidades: simplificación de procesos para transformar resultados de 2:00 p.m. a 3:00 p.m.

Conversación orientada a presentar las funcionalidades, ventajas y experiencias de uso de la plataforma OnBase para optimizar procesos y reducir cargas operativas en las distintas áreas de la universidad, desde el lado humano de la gestión del cambio.

 Lideran: Internacionalización (Diana Nieto) y la Dirección de Tecnologías de Información (Valeria Arroyave y Diana Sánchez)

 Lugar: bloque 27, aula 203

## Fundamentos de Learning Analytics para la toma de decisiones pedagógicas de 2:00 p.m. a 4:00 p.m.

En este seminario conocerás los fundamentos de Learning Analytics y cómo el uso de métodos analíticos puede ayudarte a comprender mejor el aprendizaje y fortalecer la toma de decisiones pedagógicas.

 Lidera: Luis Gerardo Pachón 

 Lugar: EXA - Bloque 15 segundo piso

## Pensar con las manos: LEGO® como tecnología análoga para el aprendizaje de 4:00 p.m. a 6:00 p.m.

Taller experiencial que utiliza LEGO® SERIOUS PLAY® como tecnología análoga para activar el pensamiento, la reflexión pedagógica y la construcción de significado, permitiendo a los profesores diseñar y repensar experiencias de aprendizaje desde la acción y la metáfora.

 Lidera: María José Gaviria Rincón, profesora de la Escuela de Administración 

 Lugar: Makers - Bloque 26-104

 *Cupo limitado

## Abro Hilo: Jacques Prévert de 5:00 p.m. a 6:00 p.m.

¿Por qué una programación cultural en Acción EAFIT? En un mundo donde el avance de la tecnología nos induce a estar solos frente a una pantalla, los espacios de encuentro presencial se convierten en pequeños milagros. Sólo el arte y la creatividad nos mantendrá presentes.

 El arte y la cultura son fundamentales para acompañar la tecnología y su vértigo. 

 Abro Hilo es un espacio para hablar de las formas de literatura breves. Esta sesión esta dedicada al poeta francés Jacques Prévert, famoso por sus vínculos con el surrealismo, el humor y los problemas del pueblo; autor fundamental en la literatura universal.

 Lideran: Santiago Bustos Ayala

 Lugar: Teatrino La Tilde.Hall, bloque 18

 *Asistencia gratuita, evento abierto

Miércoles 22 de abril

## Muestra de iniciativas inspiradoras de aprendizaje experiencial de 8:00 a.m. a 6:00 p.m.

La Muestra es una ventana para presentar los proyectos educativos que integran tecnologías, tanto digitales como análogas, para enriquecer los procesos de enseñanza y aprendizaje. Este espacio busca demostrar cómo diversas herramientas, desde las más avanzadas hasta las más sencillas, pueden generar experiencias educativas significativas cuando se aplican desde un enfoque práctico, participativo y centrado en el estudiante.

 Lugar: Plazoleta del Estudiante

L

## Diseño de clases asistido con IA de 4:00 p.m. a 6:00 p.m.

Taller formativo para el diseño de experiencias de aprendizaje a través de prompts que permiten abordar la secuencia didáctica de Ciclo de Kolb. 

 Lidera: Maryory Yarce 

 Lugar: EXA - Bloque 15 segundo piso

## Amar y Comprender la ópera: Piotr Ilich Tchaikovsky. Eugenio Oneguin de 4:00 p.m. a 6:00 p.m.

¿Por qué una programación cultural en Acción EAFIT? En un mundo donde el avance de la tecnología nos induce a estar solos frente a una pantalla, los espacios de encuentro presencial se convierten en pequeños milagros. Sólo el arte y la creatividad nos mantendrá presentes.

 Espacio dedicado a la apreciación de la ópera con énfasis en efemérides mundiales. Esta sesión esta dedicada al compositor ruso Piotr Ilich Tchaikovsky y su adaptación de la novela Eugenio Oneguin. Conduce, Profesora Luz Marina Monrroy.

 Lideran: Clara Cristina Acosta Ossa y Santiago Bustos Ayala

 Lugar: Sala de audición Musical, Tercer piso biblioteca Universidad Eafit

## Tecnologías Emergentes en el Aula: Entre la Experimentación y la Transformación Educativa de 5:00 p.m. a 7:00 p.m.

La tecnología educativa ha recorrido un largo camino: desde las aulas virtuales y los LMS hasta la inteligencia artificial generativa, las realidades extendidas y la analítica predictiva del aprendizaje. 

 Pero ¿cómo pasamos de la novedad al impacto real en el aprendizaje? En este conversatorio exploraremos cómo ha evolucionado el uso de la tecnología en EAFIT, los desafíos actuales que enfrentamos y las oportunidades que ofrecen las tecnologías emergentes para transformar la experiencia educativa. 

 Conversación: Abordaremos los retos pedagógicos y operativos de integrar tecnología de manera humanista y basada en evidencia. Una conversación necesaria sobre cómo la tecnología puede potenciar —no reemplazar— la dimensión humana del aprendizaje.

 Lideran: Ernesto José Garnica Barraza - Director de Tecnologías de la Información, Andrés Mauricio Mora Cuartas - Director Desarrollo Académico 

 Invitados: 

 1. José Alejandro Betancur Álvarez, Director, Imaginar Futuros 

 2. Edwin Mauricio Hincapié Montoya, profesor, Área De Creación 

 3. Fabio Téllez. Líder Educación AWS 

 Lugar: Bloque 18 - Piso 2

Jueves 23 de abril

## Diseño de clases con uso de agentes de 9:00 a.m. a 11:00 a.m.

Taller colaborativo enfocado en identificar cómo usar agentes para la creación de diseño de experiencias de aprendizaje. Dirigido a profesores que ya cuentan con conocimientos básicos de IA y diseño de prompts.

 Lidera: Maryory Yarce 

 Lugar: EXA - Bloque 15 segundo piso

## Día del Libro: lectura, creación y encuentro de 10:00 a.m. - 3:00 p.m.

En el marco del Día del Libro, el 23 de abril, celebraremos una jornada de lectura, creación y encuentro que promueve el aprendizaje experiencial. A través de talleres concebidos como un laboratorio vivo, invitamos a la comunidad a explorar la lectura como punto de partida para crear, dialogar y construir.

 Lideran: Equipo Biblioteca, Equipo Apropiación Social del Conocimiento, Semillero de Literatura Aplicada y Semillero de Análisis del Lenguaje

 Lugar: Hall bloque 18- piso 1

 Agenda especifica del espacio: 

 10:00 - 12:00: Taller de encuadernación

 10:00 - 12:00: Activación con serigrafía con la obra de 5 autores de la literatura.

 10:00 - 12:30: Lectura en voz alta

 12:30 - 15:00: Lectura en voz alta

 13:00 - 15:00: Activación con serigrafía con la obra de 5 autores de la literatura

 14:00 - 15:00: Taller de encuadernación

## Taller Diseño de Exlibris de 12:00 p.m a 2:00 p.m.

El taller de Diseño de Exlibris es una actividad práctica en la que los participantes crearán su propio sello personal para identificar su biblioteca, explorando el vínculo entre el diseño gráfico, la cultura del libro y las tecnologías análogas como herramientas de expresión e identidad. En el marco de la reflexión sobre tecnologías de la educación (tanto análogas como digitales) el exlibris se presenta como un ejemplo vivo de cómo las prácticas tradicionales del diseño siguen siendo relevantes y complementarias en los entornos contemporáneos de aprendizaje. 

 Es una iniciativa de la Escuela de Artes y Humanidades, abierta a toda la comunidad universitaria.

 Hall bloque 38

## LumIA: Tu alIAda en EAFIT Interactiva de 2:00 p.m. a 4:00 p.m.

Formación sincrónica para el uso de elementos de inteligencia artificial en el diseño de cursos, instrumentos de evaluación y apoyo al estudiante en EAFIT Interactiva con el complemento de Inteligencia Artificial de la plataforma. 

 Experto temático: Juan Palma y Mario Gómez de D2L

 Lugar: EXA - Bloque 15 segundo piso

## Producción de Recursos Educativos Digitales Multimedia apoyados en IA de 4:00 p.m. a 6:00 p.m.

Taller práctico para el descubrimiento y exploración de herramientas gratuitas destinadas a la producción de recursos educativos digitales.

 Lidera multimedia: Luis Gerardo Pachón 

 Lugar: EXA - Bloque 15 segundo piso

### Conoce nuestras versiones anteriores

#### 2025-1

#### 2024-1

#### 2023-1

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)