# Asignatura BU - Opciones artísticas - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Asignatura BU - Opciones artísticas

*    Asignatura BU - Opciones Artísticas 

**La Asignatura Bienestar Universitario consiste en distintas opciones que eligen los estudiantes donde se les brinda un ambiente propicio para expresar sus sentimientos, necesidades, intereses y condiciones, necesarios para su formación integral. Allí se promueven valores y se generan lazos que les permiten articularse con mayor acierto a la vida universitaria​.**

Para lograr este objetivo, los Departamentos de Desarrollo Estudiantil, Deportes y Recreación, Desarrollo Artístico y Servicio Médico ofrecen diversos cursos y talleres sobre temas acordes a cada área, con el fin de crear una cultura reflexiva, lúdica y creativa que permita la formación integral del estudiante y la responsabilidad en el devenir académico.

La Asignatura Bienestar Universitario se compone de 30 horas que están divididas en 20 horas correspondientes a la actividad que elija el estudiante —de acuerdo con las opciones que ofrecen los Departamentos—, de 8 horas correspondientes al Taller de salud (tres charlas sobre métodos anticonceptivos, enfermedades de transmisión sexual y adicciones) y dos horas del proyecto institucional Atreverse a pensar.​

Las opciones de la A​signatura de Bienestar Universitario ofrecidas por el Departamento de Desarrollo Artístico:

## Baile

## Danza contemporánea

## Joyería

## Caricatura

## Dibujo

## Expresión corporal

## Origami

## Fotografía

## Pintura

## Guitarra

## Técnicas artísticas mixtas

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate