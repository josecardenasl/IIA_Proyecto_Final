# Origami - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Origami

*    Origami 

###### Presentación

En esta opción aprenderás el arte de doblar el papel, dejando una huella en el mismo con la intención de crear una figura con sentido artístico. Al igual que muchas otras prácticas chinas y japonesas, el origami fue creado para la contemplación, la quietud y la tranquilidad, buscando la paciencia como una de las máximas virtudes del ser humano, y a su vez la interacción entre los distintos participantes.

###### Evaluación

70% Parcial.

30% Exposición final.

###### Contenido

Qué es el origami, lenguaje y figuras bases.

Figuras geométricas con dos o más papeles. Ensambles modulares y kusudamas.

Figuras de un solo papel. Esculturas.

Figuras bidimensionales de una o dos piezas. Tesselados y quilts.

Lectura de diagramas y elaboración de muestra artística.

###### Bibliografía

Brill, David (1996) Origami brillante. U.S.A.: Editorial J-P.

Clemente, Eduardo (1996) Papiroflexia. Barcelona: Editorial P y J.

Corredor Torres, Josué (2003) Practiquemos el Origami. Bogotá: Editorial Nessan Ltda.

Antología de historias antiguas del Zen (1979). Madrid: Editorial Swan.

Fuse, Tokomoto. Transformaciones multidimensionales.

Kunihiko Kasahara & Toshie Takahama (1993) Origami para expertos. Madrid: Editorial Edaf.

###### Páginas web

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate