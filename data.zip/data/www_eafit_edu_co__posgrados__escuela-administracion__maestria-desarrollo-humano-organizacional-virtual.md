# Maestría en Desarrollo Humano Organizacional - Virtual - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 16: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

Posgrado

# Maestría en Desarrollo Humano Organizacional - Virtual

SNIES 104963, Medellín

Las dinámicas organizacionales actuales sugieren cambios permanentes asociados al talento y a las nuevas formas de concebir el trabajo, los cuales se convierten en desafíos para la gestión del talento humano y la generación de valor sostenible. Las tendencias en atracción, desarrollo, compensación y medición de talento, así como los temas de liderazgo y bienestar, requieren líderes que contribuyan al desarrollo de capacidades organizacionales, potenciando el talento y el bienestar de sus equipos con una perspectiva estratégica y global.

Nuestra maestría tiene un enfoque humanista, estratégico y global, que busca comprender al ser humano de manera integral y desarrollar competencias para la transformación organizacional en entornos laborales desafiantes que demandan adaptación y soluciones sostenibles. Buscamos formar líderes con criterio social y herramientas para dirigir las estrategias de talento humano desde la realización personal, conjugada con los objetivos organizacionales. Asimismo, profesionales que investiguen fenómenos sociolaborales y conozcan tendencias globales en la gestión de talento.

*    Escuela Administracion 
*    Maestría En Desarrollo Humano Organizacional - Virtual 

## Registro calificado

Resolución 023266 del 07 de diciembre de 2022. Vigencia por 7 años.

Duración

3 semestres

Lugar

Medellín

Horario

Viernes y sábado

Más información

Viernes de 6:00 p.m. a 10:00 p.m. y sábados de 8:00 a.m. a 12:00 p.m. 

Idioma 

Español

Modalidad

Virtual

SNIES

SNIES 104963

Precio total del programa

$ 49.621.592

## Sobre el programa

Calidad y excelencia

Estamos acreditados por The Association to Advance Collegiate Schools of Business (AACSB International), la alianza más grande para la educación.

Nuestro programa es parte de la Escuela de Administración, la primera en Latinoamérica en recibir una acreditación de alta calidad de la Business Graduate Association (BGA).

La maestría ocupa el puesto 12 entre los 25 mejores másteres de Latinoamérica, según el ranking Eduniversal, en la categoría de Gestión de Recursos Humanos en Latinoamérica 2024.

Nuestros profesores son reconocidos por su formación académica, experiencia profesional y trayectoria investigativa. Algunos de ellos ocupan cargos de alto nivel de responsabilidad en diversos tipos de organizaciones.

EAFIT es pionera en la formación de profesionales que lideran la gestión del talento. Sus primeros programas se ofrecieron en 1978 a nivel de Especialización y, a partir de 2011, en Maestría. Desde entonces, nos hemos mantenido activos y actualizados, conservando la relevancia y pertinencia de los programas.

Campus transformador

Promovemos el aprendizaje experiencial a través de diversas actividades y casos de estudio. Los estudiantes pueden interactuar con distintos espacios y recursos físicos y digitales que forman parte del campus, como la cámara de Gesell, el aula inversa, las salas de estudio y los recursos bibliográficos.

Nuestros estudiantes tienen acceso a una variada oferta de eventos nacionales e internacionales organizados por la Escuela de Administración. El programa también incluye espacios de interacción como los Encuentros para el Desarrollo Humano, donde los egresados comparten sus trabajos de grado con la comunidad universitaria.

Si estás cursando la especialización o la completaste en los últimos cinco años, puedes continuar con el ciclo de maestría y obtener una doble titulación.

Los estudiantes tienen la posibilidad de homologar materias para continuar sus estudios en otras maestrías de la universidad o cursar el MIB.

Aprendizaje vivo y activo

Nuestros programas se ofrecen en modalidad presencial y virtual.

Nuestros estudiantes desarrollan propuestas de valor para la transformación organizacional desde la comprensión del ser humano, la cultura y los retos de la sociedad.

Nuestro enfoque es práctico. Los estudiantes gestionan los procesos del sistema de talento humano mediante la aplicación de modelos y herramientas gerenciales.

Los estudiantes estudian al ser humano en el mundo del trabajo, su interacción, influencia mutua y comportamiento. Es una mirada integral del ser humano, no funcionalista ni instrumental.

Innovación y liderazgo

Nuestra maestría puede cursarse en modalidad virtual, de manera asincrónica, con encuentros sincrónicos semanales y acompañamiento permanente por parte del profesor.

Contamos con una plataforma diseñada para la interacción de los estudiantes con los profesores y los materiales didácticos y pedagógicos.

Los estudiantes que ingresan a la maestría virtual residen en otras regiones del país y en otros países como Estados Unidos, México y Portugal, lo que nos permite contar con una perspectiva multicultural.

Nuestros profesores combinan su experiencia académica con una destacada trayectoria profesional, ocupando cargos de alto nivel de responsabilidad en diferentes tipos de organizaciones.

Conexiones e incidencia

La formación de nuestros programas tiene un enfoque práctico que se materializa a través de un proyecto integrador que permite a los estudiantes impactar una realidad organizacional, aplicando los conocimientos adquiridos en el plan de estudios. Las organizaciones beneficiadas por este trabajo práctico destacan su relevancia e impacto en los procesos asociados al talento humano.

Nuestros estudiantes pueden ser líderes con capacidad para crear propuestas de valor, gestionar los procesos del sistema de talento humano y dirigir estrategias de talento humano.

**Somos puerta al mundo**

Los estudiantes tienen la posibilidad de tener una experiencia académica internacional de corta duración con instituciones de educación superior con las cuales tenemos convenio. Esta es una experiencia voluntaria que no está incluida en el plan de estudios.

**Graduados inspiradores**

Nuestros estudiantes realizan proyectos prácticos y reales. Un ejemplo destacado es el de Jimena Gutiérrez Rúa, quien desarrolló a partir de su tesis de maestría el proyecto de emprendimiento Talento Verde, del cual es directora. Talento Verde es una agencia de consultoría especializada en empleos verdes y transición justa, que apoya a diversos actores del mercado laboral en la superación de los desafíos relacionados con el capital humano necesario para la transición hacia una economía verde.

Acreditaciones

**Acreditados en 2024**

​Menos del 6% de Escuelas de Negocios a nivel global, cuentan con este [reconocimiento](https://www.aacsb.edu/). Esta acreditación evalúa estándares de calidad académica al más alto nivel y representa el logro más importante para las Escuelas de Administración en el mundo entero.

**Reacreditados en 2019 – 2024**

La [Asociació​n del ​​MBA (Amba)](https://www.amba-bga.com/amba) acreditó a la maestría en Administración de EAFIT por cinco años, válida para los programas de Medellín, Bogotá, Pereira, Armenia y Guatemala. Esta acreditación conviert​e a la Universidad en la primera del departamento en recibir este reconocimiento, lo que le ofrece a sus egresados la posibilidad de competir en el mercado laboral internacional con profesionales de los mejores programas de MBA.

**Acreditados 2019 a 2024**

La [acreditación BGA](https://www.amba-bga.com/) es un sello de alta calidad que se otorga a las escuelas de negocios comprometidas con las prácticas de gestión responsable y el aprendizaje a lo largo de la vida, al mismo tiempo que demuestran un impacto positivo y creciente en sus estudiantes y comunidades. Nuestra Escuela se convirtió en la primera institución en América Latina en recibir esta acreditación en enero de 2020.​​

Membresías

**​European Foundation for Management Developme​nt (Efmd)**

​An international, not-for-profit, membership organization of business schools and corporations, based in Brussels, Belgium, with offices in Asia and the Americas.​

Nearly 900 member organizations from academia, business, public service and consultancy in 86 countries.​

A unique forum for information, research, networking and debate on innovation and best practice in management development.

Recognized globally as an accreditation body for quality & impact assessment in management with established accreditation services for business schools and business school programmes, corporate universities and online courses.​

**Prme**

Principios para una Educación Responsable en la Gestión o Principles for Responsible Management Education (Prme, por sus siglas en inglés), es una iniciativa de la Organización de las Naciones Unidas lanzada en la Cumbre de los Líderes del Pacto Global Mundial de las Naciones Unidas en Ginebra, y que relaciona a las Naciones Unidas y las Escuelas de Negocios con la secretaría de los Prme.

Todo con la finalidad de promover e inspirar una nueva forma de educación, de gestión responsable, de investigación y pensamiento de liderazgo a nivel mundial en los negocios. Para tal fin, proporciona el marco de Principios para la Educación Responsable de la Gestión, al desarrollar comunidades de aprendizaje y promover la conciencia sobre los Objetivos de Desarrollo Sostenible de las Naciones Unidas.

**Paciber​**

The mission of Paciber is to establish linkages to promote internation​al business education, research and exchanges of information, faculty and students; and to promote/widen the scope of cooperation, facilitate communication and expand consciousness about Asia among American member institutions (tomado de su sitio web).

**PMI​®**

EAFIT, desde hace más de tres años, es un Proveedor de Educación Registrado (R.E.P.s) que está aprobada por PMI® para ofrecer programas de este tipo. Es la única universidad en Medellín que tiene esta certificación.

**​Rankings​**

1.   Puesto 17 en América Economía 2023.
2.   Puesto 101 en el World University Rankings - Masters​ in Marketing​.

Renovación de la acreditación

##### Autoevaluación para acreditación​​​

**​¿Qué es la Acreditación de Alta Calidad?​​​**

La acreditación es el reconocimiento de la alta calidad que otorga el Ministerio de Educación Nacional a los programas académicos y a las instituciones que cumplen con los más altos criterios de calidad y que realizan sus propósitos y objetivos, teniendo en cuenta la naturaleza jurídica, identidad, misión, tipología, niveles de formación y modalidades. La acreditación en alta calidad promueve el fortalecimiento de una cultura de la alta calidad de los programas académicos y de las instituciones, que se soporta en los sistemas internos de aseguramiento de la calidad. La evaluación con fines de acreditación en alta calidad se realiza por la institución sobre sí misma y sus programas académicos, los pares académicos, y el Consejo Nacional de Acreditación – CNA.

**¿Qué es el proceso de autoevaluación?​**

La autoevaluación consiste en el ejercicio permanente de revisión, reconocimiento, reflexión e intervención que lleva a cabo la institución sobre sí misma o sobre un programa académico, con una amplia participación de la comunidad institucional y con el objetivo de valorar el desarrollo de sus funciones sustantivas, en aras de lograr la alta calidad en todos sus procesos, conforme los componentes del modelo de acreditación en alta calidad establecidos en el presente Acuerdo. La autoevaluación que adelanta internamente la institución culmina con un informe, el cual contiene los resultados y un plan de mejoramiento.

**¿Cuáles son los requisitos para optar por la acreditación de alta calidad ante el CNA?​**

**Programa académico acreditable. ​**

Es el programa académico que se encuentra autorizado para ser ofrecido y desarrollado por la institución y que cuenta con por lo menos ocho (8) años continuos de funcionamiento, verificable en el Sistema Nacional de Información de la Educación Superior – SNIES. Se consideran acreditables los programas académicos de los niveles de formación técnica profesional, tecnológico, universitario, maestría, especialidad, medico quirúrgica y doctorado.

**¿Quiénes participan de un proceso de autoevaluación y acreditación de programas académicos?**

Para surtir este proceso, se conforma un comité de autoevaluación y acreditación del programa, compuesto por el decano de la escuela, coordinador del programa académico, representantes de profesores, estudiantes y egresados del programa del posgrado, con el fin de tener una visión holística del programa. Este es un grupo responsable de la autoevaluación del programa, quien emite juicio integral sobre la calidad del programa, el cual debe contener argumentos soportados por evidencias cualitativas y cuantitativas. Así mismo, es el encargado de orientar el desarrollo del proceso, la redacción del informe final por parte del respectivo programa, el diagnóstico de problemas, la búsqueda de soluciones y la coordinación de estrategias para sustentar e introducir los cambios que se requieran para mejorar la calidad.​​

**Acreditaciones Internacion​​ales**

EAFIT, es miembro de la alianza para la educación en negocios más grande del mundo, [AACSB Int​ernational - The Association to Advance Collegiate Schools of Business](https://www.aacsb.edu/).

La Escuela de Administración de EAFIT y todos sus programas de pregrado y posgrado, se encuentran acreditados por [The Business Graduates Association](https://businessgraduatesassociation.com/) –BGA- organismo internacional, de membresía y garantía de calidad, de escuelas de negocios, líderes en el mundo y de alto potencial que comparten el compromiso por las prácticas de gestión responsable y por el aprendizaje permanente, y además, buscan generar un impacto positivo en sus estudiantes, comunidades y la economía en su conjunto.

Contacto

###### Ejecutiva de promoción

**Lina Agudelo Aristizábal**

+57 310 2099707

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Becas y financiación

## **Guía de aspirantes posgrados**

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

## Inicia tu proceso de inscripción

El valor es de $360.500.

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

## Líneas de atención

Correo electrónico: [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

Teléfono: +57 6042619500

## **Nuestras acreditaciones**

### También te puede interesar

#### Maestría en Administración - MBA Medellín

Duración

3 semestres

Lugar

Medellín

Horario

Modalidad regular e intensiva

Más información

Medellín - modalidad regular

 Clases presenciales cada 2 semanas, jueves y viernes de 17.00 a 21.00 y sábados de 08.00 a 12.00

 Medellín - modalidad intensiva

 Clases presenciales una semana al mes, de lunes a viernes de 17.00 a 21.00 y sábados de 08.00 a 12.00

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1265 

Precio total del programa

$84.862.286

#### Doctorado en Administración

Duración

4 años

Lugar

Medellín

Horario

Dedicación exclusiva. Tres días cada dos semanas de 8:00 a.m. a 12:00 m.

Idioma 

Español

Modalidad

Presencial

SNIES

SNIES 20820

Precio total del programa

$143.713.510

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Liderar para generar impacto: decisiones que transforman personas, equipos y oportunidades

Mayo 12, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate