# Ingeniería de Diseño de Producto - EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

![Image 20: Pregrado en Ingeniería de Diseño de Producto, Escuela de Ciencias Aplicadas e Ingeniería.
Estudiantes hacen tareas en talleres de la Universidad.](https://universidadeafit.widen.net/content/dbwfb9rz9c/web/pregrado-ingenieria-dise%C3%B1o-producto%20(2).jpg?crop=yes&k=c&w=1920&h=788&itok=NHk7zfFq)

Pregrado

# Ingeniería de Diseño de Producto

SNIES 7446, Medellín

Este es el programa donde personas curiosas, creativas y apasionadas por el diseño, las personas, la tecnología y el mercado encuentran un lugar. Un pregrado para trabajar en la solución de problemas contemporáneos y futuros, a través del diseño de nuevos productos, servicios y experiencias, y el rediseño de lo que ya está hecho.

El ingeniero de diseño de producto de EAFIT es el encargado de concebir y dar forma a los productos de consumo, los servicios y las experiencias del futuro. No solo diseñarás productos que tengan una buena apariencia y que sean fáciles de usar, sino que también estén orientados a las necesidades de los usuarios finales, el proceso de producción y el contexto. Aprenderás a combinar la tecnología y la creatividad para diseñar y desarrollar mejores soluciones. Junto con tus compañeros, pasarás tiempo en el campus de la universidad ideando y fabricando servicios y productos (físicos o digitales).

Si quieres obtener una base sólida en tecnología e ingeniería y abarcar una gran variedad de materias, desde las matemáticas hasta el diseño, y desde los factores humanos hasta el mercadeo, Ingeniería de Diseño de Producto es la opción para ti.

*    Escuela Ciencias Aplicadas Ingenieria 
*    Ingeniería de Diseño de Producto 

## Registro calificado

Resolución 011674 del 12 de julio de 2023. Vigencia: 8 años.

## Acreditación de alta calidad

Resolución 011674 del 12 de julio de 2023 (renovación). Vigencia: 8 años.

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 7446

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$15.786.076

Becas y Financiación

## Sobre el programa

Calidad y excelencia

**Somos top en el mundo**

Nuestros estudiantes y profesores han desarrollado soluciones de ingeniería y diseño que han sido premiadas nacional e internacionalmente.

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

Nuestra Escuela cuenta con el respaldo de un gran ecosistema de laboratorios: tenemos 43 de ellos equipados con infraestructura de última generación.

Contamos con un bloque nuevo completamente equipado para las ciencias aplicadas y la ingeniería, construido con la idea de generar bajo impacto ambiental, y diseñado para ser sostenible con el uso eficiente de la energía, el cuidado del aire, la gestión de residuos y la movilidad. Todo integrado al trabajo de investigadores, estudiantes en semilleros y jefes de laboratorio. Configurando un verdadero engranaje de investigación y aprendizaje abierto y a disposición de la comunidad estudiantil.

Nuestro campus es un espacio vivo, activo y natural y un escenario de experimentación y aprendizaje para los temas de biología, diseño, urbanismo, entre otros.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en EAFIT.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Nuestra Escuela será la primera en implementar las trayectorias profesionales, estos son caminos educativos configurados por los estudiantes para posibilitar la homologación, el doble título o un posgrado que quieran cursar.

El plan de estudios de este programa integra conocimientos de administración de negocios y mercadeo.

Además, contamos con 12 líneas de énfasis para que cada uno elija cómo complementar su desarrollo profesional, entre ellas Computación científica, Modelado matemático y simulación, Optimización y métodos heurísticos e Inteligencia artificial.

Innovación y liderazgo

**Somos innovación en educación**

Nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de EAFIT y a las áreas de conocimiento que las componen.

Además, el 73% de nuestros profesores de planta tienen doctorado.

**Cultivamos el liderazgo temprano y la investigación**

En EAFIT tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

Como Escuela tenemos más de 20 grupos de investigación y más de 60 semilleros enfocados en la experimentación y el desarrollo de tecnologías prácticas.

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Contamos con el Centro de Estudios Urbanos y Ambientales, Urbam, que promueve procesos en los que el conocimiento técnico de lo urbano se conjuga con el saber de las comunidades, transformando el paisaje y las infraestructuras a favor de la sostenibilidad. Esto les da entrada a nuestros estudiantes al conocimiento de primera mano de profesionales con experiencia y trayectoria en los temas de planeación urbana, decisión en el ámbito público e incidencia en las empresas y organizaciones privadas que tienen que ver con estos temas.

Trabajamos de la mano con NODO, el centro de formación en tecnologías de EAFIT, un espacio donde se transforma el talento y se pone al servicio de los retos reales de las organizaciones, creando procesos de aprendizaje práctico y exponencial en temas relacionados con desarrollo web.

Disponemos de una revista de Ingeniería y Ciencia que presenta y difunde trabajos de investigación básica y aplicada que contribuyen al desarrollo de la tecnología, la ciencia y la industria.

Contamos con centro de estudios e incidencia, Valor Público y con un espacio de innovación y desarrollo social: EAFIT Social.

En EAFIT tenemos una línea especial de Gerencia y empresa que presta consultoría y, también, a ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

**Somos una puerta al mundo**

Como universidad contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrados han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores start-ups de Colombia.

## Plan de estudios

## Profesores

## Conoce nuestra escuela

## Pruebas Saber Pro

## Guía de aspirantes a pregrado

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

## Inicia tu proceso de inscripción

El valor es de $224.300.

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

- [x] 

## Líneas de atención

Correo electrónico:[mercadeo@eafit.edu.co](mailto:mercadeo@eafit.edu.co)

Teléfono: +57 6042619500

### También te puede interesar

#### Ingeniería de Producción

Duración

9 semestres

Lugar

Medellín

Horario

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1249

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$16.060.617

Becas y financiación

#### Ingeniería Mecánica

Duración

9 semestres

Lugar

Medellín

Horario 

Tiempo completo

Idioma

Español

Modalidad

Presencial

SNIES

SNIES 1250

Valor del primer semestre

$16.060.617

Valor promedio de los semestres

$15.786.076

Becas y Financiación

### **Noticias**

## La vigencia del profesor y su papel en tiempos de incertidumbre y transformación

Mayo 14, 2026

## EAFIT logra su mejor resultado en las pruebas Saber Pro

Mayo 13, 2026

## Debate global con sello estudiantil

Abril 7, 2026

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)