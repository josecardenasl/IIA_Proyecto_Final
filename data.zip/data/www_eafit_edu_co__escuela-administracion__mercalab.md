# MercaLAB - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# MercaLAB

*    MercaLAB 

###### ¿Qué somos?​

S​omos un laboratorio de mercadeo que cuenta con diferentes espacios y herramientas que nos permiten conocer el comportamiento del consumidor desde diferentes perspectivas, apoyando la formación de estudiantes y la evolución empresarial a través de investigaciones aplicadas.​​

## Acerca de nosotros​

​​​​​​Histor​​ia​

La historia del Laboratorio de Mercadeo de la Universidad EAFIT se remonta a finales de 2008, cuando un grupo de nuevos docentes en el Departamento de Mercadeo identificó la necesidad de contar con herramientas de alta calidad y espacios destinados para investigaciones de mercado. Sin embargo, en ese momento, esta idea parecía difícil de realizar debido a la falta de recursos y contactos con empresas que fabrican este tipo de herramientas en Colombia.

La oportunidad para la creación del laboratorio surgió cuando se introdujeron dos nuevos programas académicos en el Departamento de Mercadeo: un pregrado y una maestría. Esto llevó a la idea de crear el actual MercaLAB, que se convertiría en un laboratorio de mercadeo equipado con tecnología de punta. Para que esta idea se hiciera realidad, se llevó a cabo una exhaustiva investigación sobre los espacios, equipos y software necesarios para el laboratorio.

Finalmente, en 2011, el proyecto del MercaLAB fue aprobado por el Consejo Superior de la Universidad EAFIT, lo que permitió su establecimiento y desarrollo. Hoy en día, el laboratorio está plenamente operativo y está abierto para satisfacer las necesidades de los estudiantes y los investigadores que buscan desarrollar conocimientos y habilidades en el campo del mercadeo. Además, el MercaLAB también está disponible para colaborar con iniciativas de la comunidad empresarial del país en sus proyectos de investigación de mercado.​​

Objetivos

Formar estudiantes de pregrado/ posgrado/ diplomados.

Generar conocimiento a través de investigaciones aplicadas.

Prestar servicios de extensión: empresas, centros de investigación, entre otros.​​

Manual monitores MercaLAB

¡Vamos a divertirnos juntos mientras aprendemos!​​

Laboratorios

## Cámara de Gesell

## Sala Makers

## Laboratorio Visual/Eye Tracker

## Aula de Innovación y Creatividad

## Sala de Entrevistas a Profundidad

## Manilla Electro Galvánica

## Face Reader

#### Conoce el MercaLAB

Generamos conocimiento a través de investigaciones con herramientas de neuromarketing.

Junio 27 del 2023

###### ​​L​ínea de tie​​​​mpo de las marcas con las que hemos trabaja​do​

Contacto 

¿Quieres saber más?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono de contacto*? 

Correo electrónico*? 

Ciudad de residencia*? 

Contenido de interés 

Cuéntanos, ¿Qué deseas saber?*? 

- [x] 

- [x] 

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate