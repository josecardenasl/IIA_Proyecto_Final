# Vida universitaria - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Vida universitaria

Conoce los diferentes beneficios a los que pueden acceder ​los eafitenses durante su estadía en la Universidad.​

*    Vida Universitaria 

##### Aprovechamiento del tiempo libre

Aprovechar bien el tiempo libre también es parte del bienestar en EAFIT. Actividades deportivas en las instalaciones del Campus, o actividades artísticas en la Casa de Desarrollo Artístico, son algunas de las opciones que tienen los eafitenses.

## Talleres artísticos

## ​Cursos deportivos

## ​Club de caminantes

## ​Deporte libre

## Aula ensayo musical

## ​Préstamo de escenarios e implementos deportivos​

## ​Eventos culturales

## Festivales, encuentros y concursos​

#### Becas

EAFIT ha construido un abanico de opciones para que los estudiantes puedan acceder a un apoyo económico que podrá cubrir total o parcialmente el valor de sus matrículas, de acuerdo con sus dificultades económicas y excelencia académica.

###### ¿Qué becas tiene EAFIT?

La Universidad EAFIT ofrece un programa de becas que comprende los servicios de apoyo para el aprendizaje, el desempeño académico y el crecimiento personal de los estudiantes, acompañando su proceso de integración a la vida universitaria, su sostenimiento y permanencia a nivel académico, social y económico.​

Tipos de Becas ofrecidos por la Universidad:

**​Becas por dificultades económicas**

**Becas por estímulo académico**

**Becas por reconocimientos y estímulos extra-curriculares**

#### Servicios de salud

Con servicios de consultas de medicina general, odontológica y nutricional, así como actividades en medicina preventiva y promoción de la salud, EAFIT contribuye a crear hábitos saludables en la comunidad universitaria.​

###### Atención en salud​

Estos son los servicios de atención en salud a los que tienen derecho la comunidad eafitense:

## Consulta psicológica para estudiantes y empleados​

## Consulta de medicina general

#### Talento humano EAFIT

El Departamento de Talento H propicia las condiciones laborales, personales y profesionales para el desarrollo de estos eafitenses, a través de programas y servicios para ellos.​

## ​​​​​​​​​​​​​¿Qué te ofrecemos como empleado de EAFIT? ​

Los siguientes son algunos de los beneficios que hacen parte de la comunidad eafitense:

1.   Flexitrabajo
2.   En Bici al trabajo
3.   Horario flexible
4.   Jornada reducida
5.   Medias jornadas libres
6.   Media jornada libre por el día del cumpleaños

1.   ​Consulta médica general
2.   Espacios para realizar actividades físicas, deportivas y de esparcimiento
3.   Establecimientos de comercio y servicios en las instalaciones
4.   Atención en primeros auxilios y servicios en atención de urgencias

1.   ​​Fondo de empleados
2.   Préstamos para compra de vivienda
3.   Deducciones de nómina
4.   Prima extralegal de servicios
5.   Reconocimiento extralegal por incapacidad
6.   Convenios con entidades externas
7.   Préstamos con entidades financieras

1.   Becas a nivel de educación formal y no formal para empleados y sus beneficiarios

2.   Becas para talleres artísticos y cursos deportivos

1.   ​​Programas en salud y prevención de la enfermedad
2.   Programas de deporte, recreación y grupos de expresión artística
3.   Programación artística y cultural durante todo el año
4.   Vacaciones extralegales
5.   Teletrabajo

#### Transición a la vida universitaria

En este servicio los estudiantes eafitenses encontrar una guía que les facilitará su tránsito de la secundaria a la Universidad, al aportar a su integración al medio universitario y formación integral. ​

Actividades

## Asignatura Inducción

Esta asignatura pretende que los estudiantes de primer semestre identifiquen alternativas personales, institucionales y académicas que faciliten su integración a la vida universitaria, por medio de la información y el acompañamiento adecuado para comenzar esta nueva etapa y así promover un vínculo con compañeros, docentes y la institución que favorezca la experiencia de aprendizaje.

## Consulta de orientación vocacional

Consulta ofrecida a estudiantes de pregrado de EAFIT, estudiante de colegio o bachilleres, empleados que van a cursar algún pregrado y aspirantes a beca en EAFIT, para favorecer la toma de decisiones en relación con la educación superior y la elección laboral- ocupacional considerando sus aptitudes, intereses, rasgos de personalidad, proyección y contexto.

##### Más información

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)