# Partners Campus - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Partners Campus

*    Internacionalizacion Campus 
*    Partners Campus 

##### **Acerca de Part​​ners Campus**

Partners Campus EAFIT es un capítulo de la red Partners of the Americas, integrado a la universidad EAFIT como grupo estudiantil en el año 2013. Este es conformado y liderado por estudiantes de pregrado apasionados por el voluntariado y el acercamiento a otras culturas.

Nuestros pilares​

## Conectar

## Servir

## Cambiar vidas

## Misión

Nuestra misión es promover la cooperación internacional a través de voluntarios activos, con el objetivo de avanzar hacia el desarrollo social y económico de comunidades de las Américas, basado en la dignidad humana y el compromiso social. Apoyando iniciativas de educación, cultura y desarrollo social.

## Visión

Visualizamos un mundo en el que las comunidades y las personas estén empoderadas y sustentadas a través del voluntariado y las asociaciones.​

## Presidencia

Se encarga de velar por el bienestar de todos los miembros del grupo y el representante del capítulo frente a la universidad y a la red Partners of the Americas.​

## Vicepresidencia

Se encarga de llevar las finanzas del grupo. Así mismo, realiza actividades que integren a los nuevos miembros con el resto del grupo.

## Comité Social

En este nos dedicamos dejar huella mediante el voluntariado, al tratar de sembrar en los niños un acercamiento con el inglés y la vida. También apoyamos múltiples comunidades que lo requieran llevándoles un poquito de felicidad, amor y diversión.

## Comité Internacional

En este comité nos encanta conocer personas y culturas de todo el mundo por lo que nos encargamos de integrar a los estudiantes extranjeros que vienen a nuestra universidad con el Campus y Medellín.

## Comité de Gestión Humana

Nos encargamos de planear actividades de Partners para Partners con el objetivo de integrarnos, compartir y salir un poquito de la rutina.

## Comité de Mercadeo

Nos encargamos de realizar las campañas de expectativa y promoción de los eventos que realiza el grupo, mientras compartimos con la comunidad universitaria los valores que nos representan y todo lo que nos apasiona por medio de piezas gráficas y audiovisuales en nuestra cuenta de Instagram.

## Comité de Relaciones Públicas

Nos encargamos d​e contactar a las empresas para tener los mejores patrocinios para los eventos del grupo y también conseguimos a los ponentes más tesos para realizar charlas dentro y fuera de partners. Además, somos el contacto directo con la red Partners of the Americas.

##### **Nuestros eventos principales​**

Noche internacional, TKP, Friends Without Borders, Voluntarios por un día, Día Partners, entre otros.

###### ​Contacto

## Lugar

Bloque 29, oficina 501

## Correo

partnerscampus@eafit.edu.co

### Instagram

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)