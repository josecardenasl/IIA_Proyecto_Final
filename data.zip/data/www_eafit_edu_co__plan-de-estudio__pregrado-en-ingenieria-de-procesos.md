# Pregrado en Ingeniería de Procesos - Universidad EAFIT

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Atención al cliente en lengua de señas.

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

Empleados

Profesores

Niños y jóvenes

Organizaciones

Cerrar perfiles

Buscar 

Búsqueda

Menú

*   Así es EAFIT

Volver

*   Estudia en EAFIT

Volver

*   Ciencia, Tecnología e Innovación

Volver

*   Conexión con las organizaciones

Volver

*   Internacionalización

Volver

*   Cultura y Bienestar

Volver

*   Noticias

Volver

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

Cerrar Menú

# Plan de estudios

Pregrado en Ingeniería de Procesos

*    Plan de Estudio 
*    Pregrado En Ingeniería de Procesos 

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

1241

#4d63b3

1246

#c341a0

1306

#ff84c9

1311

#c341a0

1316

#4bcddf

1321

#ca5351

2321

#4d63b3

2326

#ffb900

2331

#e3c6c7

2336

#0fab0b

2341

#f3082c

2346

#184958

2351

#656565

2356

#4ccda8

2361

#599a87

2366

#a4d0d7

2371

#171717

2376

#a36931

2381

#7b9180

2386

#146aef

2391

#000066

2396

#85c051

2401

#4dd76e

2406

#0a4d42

2411

#0a9e4d

2431

#7981b7

2441

#0e443a

2446

#4b4b4b

2451

#1d1d1d

2461

#ea4a06

2466

#c4d081

2471

#4d63b3

2476

#ffe500

2481

#00a9e0

2486

#ac9683

3086

#000000

3091

#146aef

3141

#45c6d8

3146

#f0142c

3151

#6d6e71

3156

#bcbec1

3161

#7bb851

3166

#159449

3171

#508f7d

## Clasificación de asignaturas

Filtros

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

10 

Núcleos, ciclos, trayectorias y énfasis

- [x] Complementarias 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Núcleo de Formación Institucional 

- [x] Obligatorias 

- [x] Prepráctica - Práctica 

Semestre 1

Créditos 

totales-

Créditos 0

#### Inducción

Código: BU0010

Inducción y Bienestar Universitario
## Inducción

0 Créditos

0 UMES

Código: **BU0010**

Créditos 1

#### Bienestar Universitario

Código: BU0011

Inducción y Bienestar Universitario
## Bienestar Universitario

 Cancelable 

1 Créditos

1 UMES

La asignatura Bienestar Universitario, por medio de actividades artísticas, deportivas, académicas y de reflexión, facilita la creación de vínculos entre los estudiantes de primer semestre y la comunidad universitaria, contribuyendo a la transición entre el colegio y la Universidad.

Código: **BU0011**

Correquisito Créditos 0

#### Taller de Salud

Código: BU0600

Créditos 0

#### Taller de Salud

Código: BU0600

Inducción y Bienestar Universitario
## Taller de Salud

0 Créditos

0 UMES

Código: **BU0600**

Créditos 4

#### Fenómenos Químicos y Laboratorio

Código: BI0230

Obligatorias
## Fenómenos Químicos y Laboratorio

4 Créditos

6 UMES

Código: **BI0230**

Créditos 3

#### Cálculo I

Código: CM0230

Obligatorias
## Cálculo I

3 Créditos

4 UMES

Código: **CM0230**

Créditos 4

#### Física I

Código: DF0236

Obligatorias
## Física I

4 Créditos

6 UMES

Código: **DF0236**

Correquisito Créditos 3

#### Cálculo I

Código: CM0230

Créditos 2

#### Introducción a la Ingeniería de Procesos

Código: PR0231

Obligatorias
## Introducción a la Ingeniería de Procesos

2 Créditos

4 UMES

Código: **PR0231**

Créditos 3

#### NFI: Ciudadanía y Democracia

Código: 

Núcleo de Formación Institucional
## NFI: Ciudadanía y Democracia

3 Créditos

UMES

Código: 

Créditos 

#### Introducción

Código: 

Obligatorias
## Introducción

Créditos

UMES

Código: 

Semestres

1 

2 

3 

4 

5 

6 

7 

8 

9 

10 

Núcleos, ciclos, trayectorias y énfasis

- [x] Complementarias 

- [x] Énfasis 

- [x] Inducción y Bienestar Universitario 

- [x] Núcleo de Formación Institucional 

- [x] Obligatorias 

- [x] Prepráctica - Práctica 

### **Líneas de énfasis**

Las líneas de énfasis son un conjunto de cursos que el estudiante de pregrado elige para profundizar en un área del conocimiento de su interés. Estos cursos pertenecen a un programa de Especialización (que tiene el mismo nombre de la línea), y por esto se le ofrecen al estudiante de pregrado la oportunidad de reconocimiento de estos cursos para continuar con su formación académica a nivel de posgrado en la Universidad EAFIT.

Los estudiantes de Ingeniería de Procesos de EAFIT puedes escoger una de las siguientes líneas de énfasis:

Diseño de procesos químicos y biotecnológicos.

Bioprocesos​.

Gestión sostenible de procesos industriales.​​

###### **Líneas de énfasis de ofertadas por otros programas**

Procesos de transformación del plástico y del caucho.​

Dirección de operaciones y logística.

Diseño de materiales.

Gerencia de proyectos.

Desarrollo de software.

El énfasis en Diseño de Procesos prepara profesionales capaces de diseñar procesos industriales competitivos, seguros y sostenibles, teniendo en cuenta las consideraciones técnicas y económicas del diseño, montaje, puesta en marcha y normalización del proceso.

**Las materias que conforman la línea de énfasis son: ​**

**Código​​:**PR0601

**Materia:** Simulación de Procesos

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0602​

**Materia:**Optimización de Procesos

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0603

**Materia:**Redes de Servicios Industriales

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0604

**Materia:**Seguridad y análisis de Riesgo en Procesos Industriales​

**Créditos:** 3

**UMES:** 4

​​El egresado con énfasis en Bioprocesos se caracteriza por sus competencias para desarrollar investigación aplicada, de modo que promueva soluciones tecnológicas y científicas a necesidades en el área ambiental y la biotecnología.

**Las materias que conforman la línea de énfasis son: ​**

**Código​​:**PR0611

**Materia:** Procesos Celulares

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0612​

**Materia:**Procesos de Biotransformación

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0613

**Materia:**Operaciones Biotecnológicas

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0614

**Materia:**Simulación de BioProcesos​

**Créditos:** 3

**UMES:** 4

Forma profesionales capaces de aplicar los conocimientos de ingeniería en la gestión sostenible de procesos industriales, tomando decisiones dentro de las organizaciones, considerando aspectos sociales, ambientales y financieros.

**Las materias que conforman la línea de énfasis son: ​**

**Código​​:**PR0604

**Materia:**​Seguridad y Análisis de Riesgo en Procesos Industriales

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0628

**Materia:**Gestión Sistémica por Procesos

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0629

**Materia:**Sostenibilidad industrial

**Créditos:** 3

**UMES:** 4

**Código​​:**PR0705

**Materia:**Seminario

**Créditos:** 2

**UMES:** 3

**Código​​:**PR0632

**Materia: ​**Herramientas para l​a Competitividad

**Créditos:** 2

**UMES:** 3

Estudia en EAFIT

Conéctate con EAFIT

Contáctanos

Información de ley

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate