Title: Política de tratamiento y protección de datos personales

URL Source: https://www.eafit.edu.co/datospersonales

Markdown Content:
# Política de tratamiento y protección de datos personales - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 2: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 3: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 4: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 5: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 6: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 8: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 9: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 10: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 11: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 12: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 13: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 14: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 15: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Pasar al contenido principal](https://www.eafit.edu.co/datospersonales#main-content)

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

[![Image 17: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/datospersonales#)

[![Image 18: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/datospersonales# "Spanish")[![Image 19: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/datospersonales# "English")

 Información para ti

Buscar 

Búsqueda

Menú

![Image 20: Imagen de banner campus EAFIT ](https://universidadeafit.widen.net/content/f259173b-6ad7-4db9-a883-2505ff7c4c49/web/eafit-mejores-anios.jpg?crop=yes&k=c&w=1920&h=788&itok=0tFvQSmg)

# Política de tratamiento de protección de datos personales de los titulares Universidad EAFIT

La Universidad EAFIT garantiza la privacidad y protección de datos personales conforme a la Ley 1581 de 2012 y el Decreto 1377 de 2013.

*   [Inicio](https://www.eafit.edu.co/)
*    Política de Tratamiento y Protección de Datos Personales 

*   [Política de tratamiento y protección de datos personales](https://www.eafit.edu.co/datospersonales#4257225834-3506768776)
*   [1. Identificación del responsable del tratamiento](https://www.eafit.edu.co/datospersonales#4257225834-2907497907)
*   [2. Marco legal](https://www.eafit.edu.co/datospersonales#4257225834-3602902812)
*   [3. Ámbito de aplicación](https://www.eafit.edu.co/datospersonales#4257225834-2797175722)
*   [4. Definiciones](https://www.eafit.edu.co/datospersonales#4257225834-4279068009)
*   [5. Principios](https://www.eafit.edu.co/datospersonales#4257225834-3047391142)
*   [6. Derechos del titular de la información​](https://www.eafit.edu.co/datospersonales#4257225834-2551422045)
*   [7. Deberes de la Universidad como responsable y encargada del tratamiento de los datos personales](https://www.eafit.edu.co/datospersonales#4257225834-1548370278)
*   [8. Autorización y consentimiento del titular](https://www.eafit.edu.co/datospersonales#4257225834-2130809393)
*   [9. Tratamiento al cual serán sometidos los datos personales](https://www.eafit.edu.co/datospersonales#4257225834-1966260858)
*   [10. Aviso de privacidad](https://www.eafit.edu.co/datospersonales#4257225834-4115364059)
*   [11. Garantías del derecho al acceso](https://www.eafit.edu.co/datospersonales#4257225834-4178046800)
*   [12. Procedimientos para la atención de consultas, reclamos, peticiones de rectificación, actualización y suspensión de datos](https://www.eafit.edu.co/datospersonales#4257225834-1681165590)
*   [13. Registro nacional de base de datos](https://www.eafit.edu.co/datospersonales#4257225834-2476580711)
*   [14. Seguridad de la información y medidas de seguridad ​​​](https://www.eafit.edu.co/datospersonales#4257225834-3103334318)
*   [15. Utilización y transferencia internacional de datos personales e información personal por parte de la Universidad](https://www.eafit.edu.co/datospersonales#4257225834-2522271331)
*   [16. Responsable y encargado del tratamiento de datos personales](https://www.eafit.edu.co/datospersonales#4257225834-2162915563)
*   [17. Vigencia](https://www.eafit.edu.co/datospersonales#4257225834-431778554)

[Política de tratamiento y protección de datos personales](https://www.eafit.edu.co/datospersonales#4257225834-3506768776)

Política de tratamiento y protección de datos personales

**Dando cumplimiento a lo dispuesto en la Ley Estatutaria 1581 de 2012 y a su Decreto Reglamentario 1377 de 2013, la Universidad EAFIT adopta la presente política para el tratamiento de datos personales, la cual será informada a todos los titulares de los datos recolectados o que en el futuro se obtengan en el ejercicio de las actividades académicas, culturales, comerciales o laborales.**

De esta manera, la Universidad EAFIT manifiesta que garantiza los derechos de la privacidad, la intimidad, el buen nombre y la autonomía universitaria, en el tratamiento de los datos personales, y en consecuencia todas sus actuaciones se regirán por los principios de legalidad, finalidad, libertad, veracidad o calidad, transparencia, acceso y circulación restringida, seguridad y confidencialidad.

Todas las personas que en desarrollo de diferentes actividades culturales, académicas, contractuales, comerciales, laborales, entre otras, sean permanentes u ocasionales, lleguen a suministrar a la Universidad EAFIT cualquier tipo de información o dato personal, podrán conocerla, actualizarla y rectificarla.

[Descarga la política de tratamiento de protección de datos personales de los titulares](https://universidadeafit.widen.net/s/lmgvkbc72h/politica-tratamiento-proteccion-datos-personales)

[1. Identificación del responsable del tratamiento](https://www.eafit.edu.co/datospersonales#4257225834-2907497907)

1. Identificación del responsable del tratamiento

**Nombre de la institución:** Universidad EAFIT, que en adelante se denominará LA UNIVERSIDAD, institución de educación superior de derecho privado con personería jurídica otorgada mediante la Resolución Número 75 del 28 de junio de 1960, expedida por la Gobernación de Antioquia, y reconocida como Universidad por el Decreto Número 759 del 6 de mayo de 1971 de la Presidencia de la República de Colombia; acreditada institucionalmente por el Ministerio de Educación Nacional, mediante Resolución 1680 del 16 de marzo de 2010.

**Domicilio y dirección:** la Universidad tiene su domicilio en la ciudad de Medellín, y su sede principal se encuentra ubicada en la Carrera 49 No. 7 Sur 50.

**Correo electrónico:** datospersonales@eafit.edu.co

**Teléfono:** (57) 604 2619500.

[2. Marco legal](https://www.eafit.edu.co/datospersonales#4257225834-3602902812)

2. Marco legal

Constitución Política, artículo 15.

Ley 1266 de 2008.

Ley 1581 de 2012.

Decretos Reglamentarios 1727 de 2009 y 2952 de 2010.

Decreto Reglamentario parcial 1377 de 2013.

Sentencias C – 1011 de 2008, y C - 748 del 2011, de la Corte Constitucional.

[3. Ámbito de aplicación](https://www.eafit.edu.co/datospersonales#4257225834-2797175722)

3. Ámbito de aplicación

La presente política será aplicable a los datos personales registrados en cualquier base de datos de la Universid cuyo titular sea una persona natural.

[4. Definiciones](https://www.eafit.edu.co/datospersonales#4257225834-4279068009)

4. Definiciones

Para los efectos de la presente política y en concordancia con la normatividad vigente en materia de protección de datos personales, se tendrán en cuenta las siguientes definiciones:

**Autorización:** Consentimiento previo, expreso e informado del Titular para llevar a cabo el Tratamiento de datos personales.

**Aviso de privacidad:** Comunicación verbal o escrita generada por el Responsable, dirigida al Titular para el tratamiento de sus datos personales, mediante la cual se le informa acerca de la existencia de las políticas de tratamiento de información que le serán aplicables, la forma de acceder a las mismas y las finalidades del tratamiento que se pretende dar a los datos personales.

**Base de Datos:** Conjunto organizado de datos personales que sea objeto de tratamiento.

**Causahabiente:** Persona que ha sucedido a otra por causa del fallecimiento de ésta (heredero).

**Dato personal:** Cualquier información vinculada o que pueda asociarse a una o varias personas naturales determinadas o determinables.

**Dato público:** Es el dato que no sea semiprivado, privado o sensible. Son considerados datos públicos, entre otros, los datos relativos al estado civil de las personas, a su profesión u oficio y a su calidad de comerciante o de servidor público. Por su naturaleza, los datos públicos pueden estar contenidos, entre otros, en registros públicos, documentos públicos, gacetas y boletines oficiales y sentencias judiciales debidamente ejecutoriadas que no estén sometidas a reserva.

**Datos sensibles:** Se entiende por datos sensibles aquellos que afectan la intimidad del Titular o cuyo uso indebido puede generar su discriminación, tales como que revelen el origen racial o étnico, la orientación política, las convicciones religiosas o filosóficas, la pertenencia a sindicatos, organizaciones sociales, de derechos humanos o que promueva intereses de cualquier partido político o que garanticen los derechos y garantías de partidos políticos de oposición, así como los datos relativos a la salud.

[5. Principios](https://www.eafit.edu.co/datospersonales#4257225834-3047391142)

5. Principios

Para garantizar la protección de datos personales, la Universidad aplicará de manera armónica e integral los siguientes principios, a la luz de los cuales se deberá realizar el tratamiento, transferencia y transmisión de datos personales:

**Principio de legalidad en el tratamiento de datos:**El tratamiento de datos es una actividad reglada, la cual deberá estar sujeta a las disposiciones legales vigentes y aplicables que rigen el tema.

**Principio de finalidad:** La actividad del tratamiento de datos personales que realice la Universidad o a la cual tenga acceso, obedecerá a una finalidad legítima en consonancia con la Constitución Política de Colombia, la cual deberá ser informada al respectivo titular de los datos personales.

**Principio de libertad:**El tratamiento de los datos personales solo puede realizarse con el consentimiento previo, expreso e informado del titular. Los datos personales no podrán ser obtenidos o divulgados sin previa autorización, o en ausencia de mandato legal, estatutario o judicial que releve el consentimiento.

**Principio de veracidad o calidad:** La información sujeta a tratamiento de datos personales debe ser veraz, completa, exacta, actualizada, comprobable y comprensible. Se prohíbe el tratamiento de datos parciales, incompletos, fraccionados o que induzcan a error.

**Principio de transparencia:** En el tratamiento de datos personales, la Universidad garantizará al titular su derecho de obtener en cualquier momento y sin restricciones, información acerca de la existencia de cualquier tipo de información o dato personal que sea de su interés o titularidad.

**Principio de acceso y circulación restringida:** El tratamiento de datos personales se sujeta a los límites que se derivan de la naturaleza de estos, de las disposiciones de la ley y la Constitución. En consecuencia, el tratamiento solo podrá hacerse por personas autorizadas por el titular y/o por las personas previstas en la ley. Los datos personales, salvo la información.

[6. Derechos del titular de la información​](https://www.eafit.edu.co/datospersonales#4257225834-2551422045)

6. Derechos del titular de la información​

De acuerdo con lo contemplado por la normatividad vigente aplicable en materia de protección de datos, los siguientes son los derechos de los titulares de los datos personales:

**a.**Acceder, conocer, actualizar y rectificar sus datos personales frente a la Universidad en su condición de responsable del tratamiento. Este derecho se podrá ejercer, entre otros, frente a datos parciales, inexactos, incompletos, fraccionados, que induzcan a error, o aquellos cuyo tratamiento esté expresamente prohibido o no haya sido autorizado.

**b.**Solicitar prueba de la autorización otorgada a la Universidad para el tratamiento de datos, mediante cualquier medio válido, salvo en los casos en que no es necesaria la autorización.

**c.** Ser informado por la Universidad, previa solicitud, respecto del uso que le ha dado a sus datos personales.

**d.** Presentar ante la Superintendencia de Industria y Comercio, o la entidad que hiciere sus veces, quejas por infracciones a lo dispuesto en la ley 1581 de 2012 y las demás normas que la modifiquen, adicionen o complementen, previo trámite de consulta o requerimiento ante la Universidad.

**e.**Revocar la autorización y/o solicitar la supresión del dato cuando en el Tratamiento no se respeten los principios, derechos y garantías constitucionales y legales.

**f.** Acceder en forma gratuita a sus datos personales que hayan sido objeto de tratamiento, al menos una vez cada mes calendario, y cada vez que existan modificaciones sustanciales de la presente política que motiven nuevas consultas.

Estos derechos podrán ser ejercidos por:

El titular, quien deberá acreditar su identidad en forma suficiente por los distintos medios que le ponga a disposición la Universidad.

Los causahabientes del titular, quienes deberán acreditar tal calidad.

El representante y/o apoderado del titular, previa acreditación de la representación o apoderamiento.

Otro a favor o para el cual el titular hubiere estipulado.

[7. Deberes de la Universidad como responsable y encargada del tratamiento de los datos personales](https://www.eafit.edu.co/datospersonales#4257225834-1548370278)

7. Deberes de la Universidad como responsable y encargada del tratamiento de los datos personales

La Universidad reconoce la titularidad que de los datos personales ostentan las personas y, en consecuencia, ellas de manera exclusiva pueden decidir sobre los mismos. Por lo tanto, la Universidad utilizará los datos personales para el cumplimiento de las finalidades autorizadas expresamente por el titular o por las normas vigentes.

En el tratamiento y protección de datos personales, la Universidad tendrá los siguientes deberes, sin perjuicio de otros previstos en las disposiciones que regulen o lleguen a regular esta materia:

**a.** Garantizar al titular, en todo tiempo, el pleno y efectivo ejercicio del derecho de hábeas data.

**b.** Solicitar y conservar copia de la respectiva autorización otorgada por el titular para el tratamiento de datos personales.

**c.** Informar debidamente al titular sobre la finalidad de la recolección y los derechos que le asisten en virtud de la autorización otorgada.

**d.** Conservar la información bajo las condiciones de seguridad necesarias para impedir su adulteración, pérdida, consulta, uso o acceso no autorizado o fraudulento.

**e.** Garantizar que la información sea veraz, completa, exacta, actualizada, comprobable y comprensible.

**f.** Actualizar oportunamente la información, atendiendo de esta forma todas las novedades respecto de los datos del titular. Adicionalmente, se deberán implementar todas las medidas necesarias para que la información se mantenga actualizada.

**g.** Rectificar la información cuando sea incorrecta y comunicar lo pertinente.

**h.**Respetar las condiciones de seguridad y privacidad de la información del titular.

**i.** Tramitar las consultas y reclamos formulados en los términos señalados por la ley.

**j.** Identificar cuando determinada información se encuentra en discusión por parte del titular.

**k.** Informar a solicitud del titular sobre el uso dado a sus datos.

**l.** Informar a la autoridad de protección de datos cuando se presenten violaciones a los códigos de seguridad y existan riesgos en la administración de la información de los titulares.

**m.** Cumplir los requerimientos e instrucciones que imparta la Superintendencia de Industria y Comercio sobre el tema en particular.

**n.** Usar únicamente datos cuyo tratamiento esté previamente autorizado de conformidad con lo previsto en la Ley 1581 de 2012.

**o.** Velar por el uso adecuado de los datos personales de los niños, niñas y adolescentes, en aquellos casos en que se encuentre autorizado el tratamiento de sus datos.

**p.** Registrar en la base de datos la leyenda "reclamo en trámite" en la forma en que se regula en la ley.

**q.** Insertar en la base de datos la leyenda "información en discusión judicial" una vez notificado por parte de la autoridad competente sobre procesos judiciales relacionados con la calidad del dato personal.

**r.** Abstenerse de circular información que esté siendo controvertida por el titular y cuyo bloqueo haya sido ordenado por la Superintendencia de Industria y Comercio.

**s.** Permitir el acceso a la información únicamente a las personas que pueden tener acceso a ella.

**t.** Usar los datos personales del titular sólo para aquellas finalidades para las que se encuentre facultada debidamente y respetando en todo caso la normatividad vigente sobre protección de datos personales.

[8. Autorización y consentimiento del titular](https://www.eafit.edu.co/datospersonales#4257225834-2130809393)

8. Autorización y consentimiento del titular

​La Universidad requiere del consentimiento libre, previo, expreso e informado del titular de los datos personales para el tratamiento de los mismos, excepto en los casos expresamente autorizados en la ley, a saber:

**a.** Información requerida por una entidad pública o administrativa en ejercicio de sus funciones legales o por orden judicial.

**b.** Datos de naturaleza pública.

**c.** Casos de urgencia médica o sanitaria.

**d.** Tratamiento de información autorizado por la ley para fines históricos, estadísticos o científicos.

**e.** Datos relacionados con el Registro Civil de las Personas.

###### Manifestación de la autorización

La autorización a la Universidad para el tratamiento de los datos personales será otorgada por:

El titular, quien deberá acreditar su identidad de forma suficiente por los distintos medios que le ponga a disposición la Universidad.

Los causahabientes del titular, quienes deberán acreditar tal calidad.

El representante y/o apoderado del titular, previa acreditación de la representación o apoderamiento.

Otro a favor o para el cual el titular hubiere estipulado.

###### Medios para otorgar la autorización

La Universidad obtendrá la autorización mediante diferentes medios, entre ellos el documento físico, electrónico, mensaje de datos, Internet, sitios web, o en cualquier otro formato que en todo caso permita la obtención del consentimiento mediante conductas inequívocas a través de las cuales se concluya que de no haberse surtido la misma por parte del titular o la persona legitimada para ello, los datos no se hubieran almacenado o capturado en la base de datos.

La autorización será solicitada por la Universidad de manera previa al tratamiento de los datos personales.

###### Prueba de la autorización

La Universidad conservará la prueba de la autorización otorgada por los titulares de los datos personales para su tratamiento, para lo cual utilizará los mecanismos disponibles a su alcance en la actualidad al igual que adoptará las acciones necesarias para mantener el registro de la forma y fecha en la que obtuvo ésta. En consecuencia, la Universidad podrá establecer archivos físicos o repositorios electrónicos realizados de manera directa o a través de terceros contratados para tal fin.

###### Revocatoria de la autorización

Los titulares de los datos personales pueden en cualquier momento revocar la autorización otorgada a la Universidad para el tratamiento de sus datos personales o solicitar la supresión de los mismos, siempre y cuando no lo impida una disposición legal o contractual. La Universidad establecerá mecanismos sencillos y gratuitos que permitan al titular revocar su autorización o solicitar la supresión de sus datos personales, al menos por el mismo medio por el que lo otorgó.

Para lo anterior, deberá tenerse en cuenta que la revocatoria del consentimiento puede expresarse, por una parte, de manera total en relación con las finalidades autorizadas, y por lo tanto la Universidad deberá cesar cualquier actividad de tratamiento de los datos; y por la otra de manera parcial en relación con ciertos tipos de tratamiento, en cuyo caso serán estos sobre los que cesarán las actividades de tratamiento, como para fines publicitarios, entre otros. En este último caso, la Universidad podrá continuar tratando los datos personales para aquellos fines en relación con los cuales el titular no hubiera revocado su consentimiento.

[9. Tratamiento al cual serán sometidos los datos personales](https://www.eafit.edu.co/datospersonales#4257225834-1966260858)

9. Tratamiento al cual serán sometidos los datos personales

El tratamiento de los datos personales de estudiantes, aspirantes, graduados, egresados, profesores, empleados, ex empleados, jubilados, proveedores, contratistas, o de cualquier persona con la cual la Universidad tenga o establezca una relación, permanente u ocasional, se realizará en el marco legal que regula la materia y en virtud de su condición de Institución de Educación Superior, y serán todos los necesarios para el cumplimiento de la misión institucional.

En todo caso, los datos personales podrán ser recolectados y tratados para:

**a.** Realizar el envío de información relacionada con programas, actividades, noticias, contenidos por área de interés, productos y demás bienes o servicios ofrecidos por la Universidad.

**b.** Desarrollar la misión de la Universidad conforme a sus estatutos.

**c.** Cumplir con la normatividad vigente en Colombia para las Instituciones de educación superior, incluyendo pero no limitándose a cualquier requerimiento del Ministerio de Educación Nacional, entidades acreditadoras o las autoridades locales.

**d.** Cumplir las normas aplicables a proveedores y contratistas, incluyendo pero no limitándose a las tributarias y comerciales.

**e.** Cumplir lo dispuesto por el ordenamiento jurídico colombiano en materia laboral y de seguridad social, entre otras, aplicables a ex empleados, empleados actuales y candidatos a futuro empleo.

**f.** Realizar encuestas relacionadas con los servicios o bienes de la Universidad.

**g.** Desarrollar programas conforme a sus estatutos.

**h.** Mantener en contacto a exalumnos con profesiones o intereses afines.

**i.** Informar sobre oportunidades de empleo, ferias, seminarios u otros estudios a nivel local e internacional.

**j.** Fomentar la investigación en todos los campos, incluyendo el científico.

**k.** Cumplir todos sus compromisos contractuales.

Para el tratamiento de datos personales de niños, niñas y adolescentes se procederá de acuerdo con lo contemplado en la presente política en el apartado relacionado con los derechos de estos.

###### Datos sensibles

Para el caso de datos personales sensibles, LA UNIVERSIDAD podrá hacer uso y tratamiento de ellos cuando:

**a.** El titular haya dado su autorización explícita, salvo en los casos que por ley no sea requerido el otorgamiento de dicha autorización.

**b.** El tratamiento sea necesario para salvaguardar el interés vital del titular y este se encuentre física o jurídicamente incapacitado. En estos eventos, los representantes legales deberán otorgar su autorización.

**c.**El tratamiento sea efectuado en el curso de las actividades legítimas y con las debidas garantías por parte de una fundación, ONG, asociación o cualquier otro organismo sin ánimo de lucro, cuya finalidad sea política, filosófica, religiosa o sindical, siempre que se refieran exclusivamente a sus miembros o a las personas que mantengan contactos regulares por razón de su finalidad. En estos eventos, los datos no se podrán suministrar a terceros sin la autorización del titular.

**d.** El tratamiento se refiera a datos que sean necesarios para el reconocimiento, ejercicio o defensa de un derecho en un proceso judicial.

**e.** El tratamiento tenga una finalidad histórica, estadística o científica. En este evento deberán adoptarse las medidas conducentes a la supresión de identidad de los titulares.Sin perjuicio de las excepciones previstas en la ley, en el tratamiento de datos sensibles se requiere la autorización previa, expresa e informada del titular, la cual deberá ser obtenida por cualquier medio que pueda ser objeto de consulta y verificación posterior.

[10. Aviso de privacidad](https://www.eafit.edu.co/datospersonales#4257225834-4115364059)

10. Aviso de privacidad

El Aviso de Privacidad es el documento físico, electrónico o en cualquier otro formato, puesto a disposición del titular para informarle acerca del tratamiento de sus datos personales. A través de este documento se comunica al titular la información relacionada con la existencia de las políticas de tratamiento de información de la Universidad y que le serán aplicables, la forma de acceder a las mismas y las características del tratamiento que se pretende dar a los datos personales.

El aviso de privacidad deberá contener, como mínimo, la siguiente información:

**a.** La identidad, domicilio y datos de contacto del responsable del tratamiento.

**b.** El tipo de tratamiento al cual serán sometidos los datos y la finalidad del mismo.

**c.** Los derechos del titular

**d.** Los mecanismos generales dispuestos por el responsable para que el titular conozca la política de tratamiento de la información y los cambios sustanciales que se produzcan en ella. En todos los casos, debe informar al titular cómo acceder o consultar la política de tratamiento de información.

**e.** El carácter facultativo de la respuesta relativa a preguntas sobre datos sensibles

[11. Garantías del derecho al acceso](https://www.eafit.edu.co/datospersonales#4257225834-4178046800)

11. Garantías del derecho al acceso

Para garantizar el derecho de acceso del titular de los datos, l pondrá a disposición de este, previa acreditación de su identidad, legitimidad o personalidad de su representante, sin costo o erogación alguna, de manera pormenorizada y detallada, los respectivos datos personales a través de todo tipo de medio, incluyendo los medios electrónicos que permitan el acceso directo del titular a ellos. Dicho acceso deberá ofrecerse sin límite alguno y le debe permitir al titular la posibilidad de conocerlos y actualizarlos en línea.

[12. Procedimientos para la atención de consultas, reclamos, peticiones de rectificación, actualización y suspensión de datos](https://www.eafit.edu.co/datospersonales#4257225834-1681165590)

12. Procedimientos para la atención de consultas, reclamos, peticiones de rectificación, actualización y suspensión de datos

**​a. Consultas:**

Los titulares o sus causahabientes podrán consultar la información personal del titular que repose en la , quien suministrará toda la información contenida en el registro individual o que esté vinculada con la identificación del Titular.

Con respecto a la atención de solicitudes de consulta de datos personales, la Universidad garantiza:

Habilitar medios de comunicación electrónica u otros que considere pertinentes.

Establecer formularios, sistemas y otros métodos simplificados, los cuales deberán ser informados en el aviso de privacidad.

Utilizar los servicios de atención al cliente o de reclamaciones que tiene en operación.

En cualquier caso, independientemente del mecanismo implementado para la atención de solicitudes de consulta, las mismas serán atendidas en un término máximo de diez (10) días hábiles contados a partir de la fecha de su recibo. Cuando no fuere posible atender la consulta dentro de dicho término, se informará al interesado antes del vencimiento de los 10 días, expresando los motivos de la demora y señalando la fecha en que se atenderá su consulta, la cual en ningún caso podrá superar los cinco (5) días hábiles siguientes al vencimiento del primer plazo.

Las consultas podrán formularse al correo [datospersonales@eafit.edu.co](mailto:datospersonales@eafit.edu.co)

**b. Reclamos**

El Titular o sus causahabientes que consideren que la información contenida en una base de datos debe ser objeto de corrección, actualización o supresión, o cuando adviertan el presunto incumplimiento de cualquiera de los deberes contenidos en la ley, podrán presentar un reclamo ante la Universidad, el cual será tramitado bajo las siguientes reglas:

1.   El reclamo del Titular se formulará mediante solicitud dirigida a la Universidad al correo electrónico datospersonales@eafit.edu.co o mediante comunicación escrita dirigida al departamento de Mercadeo Institucional, con la identificación del titular, la descripción de los hechos que dan lugar al reclamo, la dirección, y acompañando los documentos que se quiera hacer valer. Si el reclamo resulta incompleto, se requerirá al interesado dentro de los cinco (5) días siguientes a la recepción del reclamo para que subsane las fallas. Transcurridos dos (2) meses desde la fecha del requerimiento, sin que el solicitante presente la información requerida, se entenderá que ha desistido del reclamo.

En caso de que quien reciba el reclamo no sea competente para resolverlo, dará traslado a quien corresponda en un término máximo de dos (2) días hábiles e informará de la situación al interesado.
2.   Una vez recibido el reclamo completo, éste se catalogará con la etiqueta "reclamo en trámite" y el motivo del mismo, en un término no mayor a dos (2) días hábiles. Dicha etiqueta se mantendrá hasta que el reclamo sea decidido.
3.   El término máximo para atender el reclamo será de quince (15) días hábiles contados a partir del día siguiente a la fecha de su recibo. Cuando no fuere posible atender el reclamo dentro de dicho término, se informará al interesado los motivos de la demora y la fecha en que se atenderá su reclamo, la cual en ningún caso podrá superar los ocho (8) días hábiles siguientes al vencimiento del primer término.

**c. Petición de actualización y/o rectificación**

La Universidad rectificará y actualizará, a solicitud del titular, la información de este que resulte ser incompleta o inexacta, de conformidad con el procedimiento y los términos antes señalados, para lo cual se tendrá en cuenta:

1.   El titular deberá allegar la solicitud al correo electrónico datospersonales@eafit.edu.co o en medio físico dirigido al departamento de Mercadeo Institucional indicando la actualización y/o rectificación a realizar y aportará la documentación que sustente su petición.
2.   La Universidad podrá habilitar mecanismos que le faciliten el ejercicio de este derecho al titular, siempre y cuando estos lo beneficien. En consecuencia, se podrán habilitar medios electrónicos u otros que considere pertinentes, los cuales serán informados en el aviso de privacidad y se pondrán a disposición de los interesados en la página web.

**d. Petición de supresión de datos**

El titular de los datos personales tiene el derecho de solicitar a LA UNIVERSIDAD su supresión (eliminación) en cualquiera de los siguientes eventos:

1.   Considere que los mismos no están siendo tratados conforme a los principios, deberes y obligaciones previstas en la normatividad vigente.
2.   Hayan dejado de ser necesarios o pertinentes para la finalidad para la cual fueron recabados.
3.   Se haya superado el periodo necesario para el cumplimiento de los fines para los que fueron recabados

Esta supresión implica la eliminación total o parcial de la información personal de acuerdo con lo solicitado por el titular en los registros, archivos, bases de datos o tratamientos realizados por LA UNIVERSIDAD. Sin embargo este derecho del titular no es absoluto y en consecuencia LA UNIVERSIDAD podrá negar el ejercicio del mismo cuando:

**a.** El titular tenga un deber legal o contractual de permanecer en la base de datos.

**b.** La eliminación de datos obstaculice actuaciones judiciales o administrativas vinculadas a obligaciones fiscales, la investigación y persecución de delitos o la actualización de sanciones administrativas.

**c.** Los datos sean necesarios para proteger los intereses jurídicamente tutelados del titular; para realizar una acción en función del interés público, o para cumplir con una obligación legalmente adquirida por el titular.

[13. Registro nacional de base de datos](https://www.eafit.edu.co/datospersonales#4257225834-2476580711)

13. Registro nacional de base de datos

La Universidad se reserva, en los eventos contemplados en la ley y en sus estatutos y reglamentos internos, la facultad de mantener y catalogar determinada información que repose en sus bases o bancos de datos como confidencial, de acuerdo con las normas vigentes, sus estatutos y reglamentos. Todo lo anterior es en consonancia con el derecho fundamental y constitucional a la educación, a la libre cátedra, y principalmente, de la autonomía universitaria.

La Universidad procederá, de acuerdo con la normatividad vigente y la reglamentación que para tal fin expida el Gobierno Nacional, a realizar el registro de sus bases de datos ante el Registro Nacional de Bases de Datos (RNBD), que será administrado por la Superintendencia de Industria y Comercio. El RNBD es el directorio público de las bases de datos sujetas a tratamiento que operan en el país, y será de libre consulta para los ciudadanos, de acuerdo con la normatividad que para tal efecto expida el Gobierno Nacional.

[14. Seguridad de la información y medidas de seguridad ​​​](https://www.eafit.edu.co/datospersonales#4257225834-3103334318)

14. Seguridad de la información y medidas de seguridad ​​​

Dando cumplimiento al principio de seguridad establecido en la normatividad vigente, la universidad adoptará las medidas técnicas, humanas y administrativas que sean necesarias para otorgar seguridad a los registros, evitando su adulteración, pérdida, consulta, uso o acceso no autorizado o fraudulento.

[15. Utilización y transferencia internacional de datos personales e información personal por parte de la Universidad](https://www.eafit.edu.co/datospersonales#4257225834-2522271331)

15. Utilización y transferencia internacional de datos personales e información personal por parte de la Universidad

​En cumplimiento de la misión institucional y del plan estratégico de desarrollo de la Universidad, y atendiendo a la naturaleza de las relaciones permanentes u ocasionales que cualquier persona titular de datos personales pueda tener con la Universidad, esta podrá realizar la transferencia y transmisión, incluso internacional, de la totalidad de los datos personales, siempre y cuando se cumplan los requerimientos legales aplicables; y, en consecuencia, los titulares, con la aceptación de la presente política, autorizan expresamente la transferencia y transmisión, incluso a nivel internacional, de los datos personales. Los datos serán transferidos para todas las relaciones que puedan establecerse con la Universidad.

Para la transferencia internacional de datos personales de los titulares, la Universidad tomará las medidas necesarias para que los terceros conozcan y se comprometan a observar la presente política, bajo el entendido de que la información personal que reciban únicamente podrá ser utilizada para asuntos directamente relacionados con la Universidad y solamente mientras esta dure, y no podrá ser usada o destinada para propósito o fin diferente. Para la transferencia internacional de datos personales se observará lo previsto en el artículo 26 de la Ley 1581 de 2012.

Las transmisiones internacionales de datos personales que efectúe la Universidad no requerirán ser informadas al titular ni contar con su consentimiento cuando medie un contrato de transmisión de datos personales conforme al artículo 25 del Decreto 1377 de 2013.

La Universidad también podrá intercambiar información personal con autoridades gubernamentales o públicas de otro tipo (incluidas, entre otras, autoridades judiciales o administrativas, autoridades fiscales y organismos de investigación penal, civil, administrativa, disciplinaria y fiscal), y terceros participantes en procedimientos legales civiles y sus contadores, auditores, abogados y otros asesores y representantes, porque es necesario o apropiado: (a) para cumplir con las leyes vigentes, incluidas las leyes distintas a las de su país de residencia; (b) para cumplir con procesos jurídicos; (c) para responder a las solicitudes de las autoridades públicas y del gobierno, y para responder a las solicitudes de las autoridades públicas y del gobierno distintas a las de su país de residencia; (d) para hacer cumplir nuestros términos y condiciones; (e) para proteger nuestras operaciones; (f) para proteger nuestros derechos, privacidad, seguridad o propiedad, los suyos o los de terceros; y (g) obtener las indemnizaciones aplicables o limitar los daños y perjuicios que nos puedan afectar.

[16. Responsable y encargado del tratamiento de datos personales](https://www.eafit.edu.co/datospersonales#4257225834-2162915563)

16. Responsable y encargado del tratamiento de datos personales

La Universidad será la responsable del tratamiento de los datos personales.

El Departamento de Mercadeo Institucional será el encargado del tratamiento de los datos personales, por cuenta de la Universidad.

[17. Vigencia](https://www.eafit.edu.co/datospersonales#4257225834-431778554)

17. Vigencia

​​La presente política rige a partir del 2 de septiembre de 2013 y deja sin efectos los reglamentos o manuales especiales que se hubiesen podido adoptar por instancias académicas y/o administrativas en la Universidad.

**Juan Luis Mejía Arango**

**Rector**

![Image 21: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 22: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 23: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 24: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 25: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 26: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 27: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 28: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
