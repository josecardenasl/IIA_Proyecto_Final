Title: Escuela Ciencias Aplicadas e Ingeniería

URL Source: https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria

Markdown Content:
# Escuela Ciencias Aplicadas e Ingeniería - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria# "English")

*   [Spanish](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria)
*   [Inglés](https://www.eafit.edu.co/en/escuela-ciencias-aplicadas-ingenieria)

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner estudiante con un robot](https://universidadeafit.widen.net/content/1a6b03e8-a349-4d2a-a825-8c7d790f7dfe/web/banner-escuela-ciencias-aplicadas.jpg?crop=yes&k=c&w=1920&h=788&itok=qClkwBE7)

# Ciencias Aplicadas e Ingeniería

*   [Inicio](https://www.eafit.edu.co/)
*    Escuela Ciencias Aplicadas e Ingeniería 

Filtros

*   [Posgrados(25)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=tipo_de_programa_ciencias%3Aposgrados)
*   [Pregrados(14)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=tipo_de_programa_ciencias%3Apregrados)

Facet Tipo de programa ciencias 

*   [Ciencias Fundame​ntales(13)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=area_de_conocimiento_pre_pos_ciencias%3A1641)
*   [​​Industria​, Materiales y Energía(8)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=area_de_conocimiento_pre_pos_ciencias%3A1656)
*   [Sistemas Naturales y Sostenibilidad(5)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=area_de_conocimiento_pre_pos_ciencias%3A1661)
*   [​Diseño de Productos y Experiencias(4)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=area_de_conocimiento_pre_pos_ciencias%3A1646)
*   [​Territorios y Ciudades(3)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=area_de_conocimiento_pre_pos_ciencias%3A1651)
*   [​​​Computación y Analítica(2)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=area_de_conocimiento_pre_pos_ciencias%3A1666)
*   [​​​Ciencias del Cuidado y la Vida(1)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=area_de_conocimiento_pre_pos_ciencias%3A1671)

Facet Área de conocimiento pre pos ciencias 

*   [Presencial(37)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=modalidad_pre_pos_ciencias%3A101)
*   [Virtual(2)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=modalidad_pre_pos_ciencias%3A106)

Facet Modalidad pre pos ciencias 

*   [Medellín(38)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=sedes_pre_pos_ciencias%3A121)
*   [Pereira(1)](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?f%5B0%5D=sedes_pre_pos_ciencias%3A126)

Facet Sedes pre pos ciencias 

#### Especialización en Desarrollo de Software - Virtual

![Image 22: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 Semestres

![Image 23: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín (virtual) 

![Image 24: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Sincrónico y asincrónico (virtual) 

![Image 25: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 26: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Virtual

![Image 27: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES ​8514​​​​​

![Image 28: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$25.008.000 

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-en-desarrollo-de-software-virtual "Ver posgrado")

[Ciencias Aplicadas e Ingeniería](https://www.eafit.edu.co/taxonomy/term/1541)

#### Ingeniería de Construcción

![Image 29: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 semestres

![Image 30: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 31: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 32: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 33: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 34: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES

![Image 35: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$16.060.617

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 36: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$15.717.441

Becas y financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-ciencias-aplicadas-ingenieria/ingenieria-de-construccion "Ver pregrado")

#### Maestría en Ciencias de la Ingeniería

![Image 37: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

4 semestres

![Image 38: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 39: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Varía según la línea de especialización

![Image 40: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 41: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 42: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 43: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$60.239.340

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-ciencias-aplicadas-ingenieria/maestria-en-ciencias-de-la-ingenieria "Ver posgrado")

#### Especialización en Dirección de Operaciones y Logística - Virtual

![Image 44: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres 

![Image 45: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín (virtual)​

![Image 46: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Sincrónico y asincrónico (virtual)

![Image 47: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 48: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Virtual

![Image 49: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 115873

![Image 50: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$25.940.140

[Conocer otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-en-direccion-de-operaciones-y-logistica-virtual "Ver posgrado")

[Ciencias Aplicadas e Ingeniería](https://www.eafit.edu.co/taxonomy/term/1541)

#### Ingeniería Industrial

![Image 51: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 semestres

![Image 52: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín​

![Image 53: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 54: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 55: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 56: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 117373

![Image 57: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$16.060.617

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 58: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$15.580.171

![Image 59: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Becas y financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-ciencias-aplicadas-ingenieria/ingenieria-industrial "Ver pregrado")

#### Especialización en Desarrollo de Software

![Image 60: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 Semestres

![Image 61: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 62: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Lunes y Jueves - Viernes y Sábados

Más información

Las clases se programan principalmente dentro de los siguientes rangos:

 Materias obligatorias: viernes de 6:00 p. m. a 08:00 p. m. y sábados de 8:00 a. m. a 12:00 p. m.

 Materias electivas: entre lunes y jueves de 6:00 p. m. a 7:30 p. m.

 Nota: La programación específica puede variar según la asignatura y la disponibilidad académica

![Image 63: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 64: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 65: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES ​8514​​​​​

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$30.026.326

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-desarrollo-software "Ver posgrado")

*   [Página actual 1](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=2 "Ir a la página 3")
*   [Página 4](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=3 "Ir a la página 4")
*   [Página 5](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=4 "Ir a la página 5")
*   [Página 6](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=5 "Ir a la página 6")
*   [Página 7](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=6 "Ir a la página 7")
*   [Siguiente página›](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria?label=&page=6 "Ir a la última página")

## Contenidos diferenciales de la Escuela

[Calidad y excelencia](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#4257225834-3461197307)

Calidad y excelencia

###### **Somos referente educativo en el ámbito local y nacional**

Gracias a nuestra oferta académica constituida por pregrados, especializaciones, maestrías y doctorados, de los cuales mas del 70% de los programas acreditables cuentan con reconocimiento de alta calidad.

Asimismo, contamos con una gran oferta de cursos, diplomados y rutas de aprendizaje ofrecidos a través de [**Nodo**](https://ecommerce.eafit.edu.co/es/cursos-y-diplomados), centro de formación en nuevas tecnologías de la Universidad EAFIT.

Todos nuestros conocimientos y saberes se encuentran enmarcados en las áreas de nuestra Escuela: **Ciencias Fundamentales, Sistemas Naturales y Sostenibilidad; Territorios y Ciudades; Industria, Materiales y Energía; Computación y Analítica; Diseño de Productos y Experiencias; y Ciencias del Cuidado y la Vida**. En las que, a su vez, se encuentra distribuida una [planta de profesores](https://www.eafit.edu.co/nuestros-profesores?f%5B0%5D=escuelas_profesores%3A336) altamente cualificada que nos permite garantizar la calidad en nuestra labor educativa e investigativa.

Nuestra Escuela también alberga al [**Centro de Estudios Urbanos y Ambientales - urbam**](https://www.eafit.edu.co/centros-estudio-incidencia/urbam), y al [**Centro de Laboratorios - CLAB**](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios), quienes aportan al desarrollo académico e investigativo interno, y brindan soluciones a los diferentes sectores productivos y gubernamentales, fortaleciendo nuestras relaciones con el entorno y generando valor y desarrollo económico, social y ambiental.

[Campus transformador](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#4257225834-1794485787)

Campus transformador

###### **Nos respalda un ecosistema de laboratorios para crear y experimentar**

Nuestra Escuela cuenta con el respaldo de un gran [**ecosistema de laboratorios**](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios)**que permite integrar el trabajo de nuestros profesores e investigadores, los proyectos académicos de estudiantes de pregrado y posgrado, y ampliar su cobertura y servicios a nuestros aliados**. El Centro de Laboratorios configura un verdadero engranaje de investigación y aprendizaje abierto y a disposición de la comunidad académica, estudiantil y de las organizaciones.

**Nuestro campus es un espacio vivo, activo y natural y un escenario de experimentación y aprendizaje para las ciencias aplicadas y la ingeniería.**

###### **Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de Ciudades Universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

[Aprendizaje vivo y activo](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#4257225834-325338654)

Aprendizaje vivo y activo

###### **Nuestros estudiantes están en el centro y configuran su plan de estudios**

Nuestra Escuela es la primera en implementar una estrategia curricular que **permite a nuestros estudiantes tener una mayor flexibilidad y personalización de su pregrado** y contar con un **plan de estudios estructurado por competencias y resultados de aprendizaje**que responde a las nuevas disposiciones del Ministerio de Educación Nacional (Decreto 1330 y Resolución 21795).

Gracias a estas transformaciones y a la nueva estructura modular de nuestros programas, **los estudiantes de pregrado podrán potenciar su perfil profesional y elegir los enfoques en los que desean profundizar en su formación, a través de las trayectorias flexibles y profesionalizantes**. Adicionalmente, se ampliarán las posibilidades de doble programa en nuestra Escuela, gracias a la convergencia de los planes de estudio en la formación fundamental en ciencias e ingeniería.

[Innovación y liderazgo](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#4257225834-1029062109)

Innovación y liderazgo

###### **Somos innovación en educación**

*   Nuestros estudiantes se exponen continuamente a conversaciones y proyectos con casos reales, industrias u otras entidades, a través de proyectos de aula.
*   Implementamos estrategias de **evaluación formativa en Ciencias y Matemáticas** para fortalecer la apropiación de conocimientos en nuestros estudiantes.
*   Consolidamos un **Consultorio de Ciencias** que ofrece una asesoría integral a los estudiantes de pregrado de nuestra Universidad, en temas relacionados con cálculo, matemáticas, ecuaciones diferenciales, álgebra lineal, estadística, física y química.

###### **Cultivamos el liderazgo temprano y la investigación**

En EAFIT tenemos 14 **grupos estudiantiles**, con más de 1.500 integrantes, en los que se desarrollan **habilidades de liderazgo**. Como Escuela tenemos 13 **grupos de investigación** y 40 **semilleros enfocados en la experimentación y el desarrollo de tecnologías prácticas**, en los que a su vez, pueden vincularse nuestros estudiantes y desarrollar iniciativas y/o proyectos de la mano de nuestros profesores e investigadores.

[Conexiones e incidencia](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#4257225834-3427822717)

Conexiones e incidencia

###### **Somos un universo de trabajo por lo público, las organizaciones y los emprendimientos**

Contamos con el **Centro de Estudios Urbanos y Ambientales - urbam**, que promueve procesos en los que el **conocimiento técnico de lo urbano se conjuga con el saber de las comunidades**, transformando el paisaje y las infraestructuras a favor de la sostenibilidad. Esto les da entrada a nuestros estudiantes al conocimiento de primera mano de profesionales con experiencia y trayectoria en los temas de planeación urbana, decisión en el ámbito público e incidencia en las empresas y organizaciones privadas que tienen que ver con estos temas.

Trabajamos de la mano con **NODO**, el centro de formación en tecnologías de EAFIT, un espacio donde **se transforma el talento** y se pone al servicio de los retos reales de las organizaciones, creando procesos de aprendizaje práctico y exponencial en temas relacionados con **desarrollo web y tecnologías**.

Con **ON.going**, el **centro de emprendimiento**de nuestra Universidad, se incuban ideas de negocio de impacto, conectando a los actores clave del ecosistema emprendedor, haciendo que emprender sea menos complicado.

Nuestra universidad es la sede de más de **21 landings empresariales**. **En nuestra Escuela**, hemos materializado estas alianzas con **empresas como Grupo BIOS, Carbon Solutions y Cecoltec**.

**Nuestros profesores** están en relación permanente con las organizaciones y a través de los proyectos de consultoría e investigación se estudian y proponen soluciones para los diferentes problemas que afectan nuestra sociedad.

[Somos una puerta al mundo](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria#4257225834-2076324705)

Somos una puerta al mundo

###### **Somos una puerta al mundo**

Como universidad contamos con **260 convenios internacionales**, **190 instituciones aliadas en 30 países del mundo**, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

Como Escuela contamos con un programa de [**Visiting Professorship**](https://universidadeafit.widen.net/s/xvr5lbq6xl/visiting-professor-2026)con la que buscamos sumar a profesores internacionales en nuestras iniciativas académicas e investigativas, establecer nuevas alianzas con diferentes universidades del mundo y promover el intercambio académico y cultural en nuestra comunidad.

Áreas

## Ciencias Fundamentales

Integra los métodos y conocimientos de las ciencias exactas, naturales y de la com​putación, como base para el desarrollo de investigación científica. Asimismo, lidera la solución de problemas fundamentales relacionados con nuestra comprensión del mundo, a partir de la generación de conocimiento que permita avanzar en el desarrollo tecnológico y el bienestar de la sociedad.​

 Director

 Luis Alejandro Gómez

 ​lgomez1@eafit.edu.co​​

[Conoce los profesores](https://www.eafit.edu.co/nuestros-profesores?f%5B0%5D=area_de_conocimiento_profesores%3A386)

## ​Diseño de Productos y Experiencias

Esta área reúne los saberes alrededor del diseño y el desarrollo de productos, servicios y experiencias. Además, lidera la investigación y la formación en temas relacionados con materiales y producción de productos, interacción humano-producto-entorno, metodologías de diseño, gestión de diseño y tecnologías digitales, para apoyar la innovación y el emprendimiento.​​​​

 Directora

 Elizabeth Rendón Vélez

 ​erendonv@eafit.edu.co​​​

[Conoce los profesores](https://www.eafit.edu.co/nuestros-profesores?f%5B0%5D=area_de_conocimiento_profesores%3A411)

## ​Territorios y Ciudades

Aplica conocimientos alrededor de la comprensión y la construcción de modelos de desarrollo y ordenamiento, apropiados para el territorio tropical colombiano. Asimismo, genera innovaciones tecnológicas, sociales, de infraestructura, de apropiación del conocimiento y de políticas a los problemas socio-ambientales, buscando el mejoramiento de la calidad de vida y la construcción de conciencia global.​

 Director

 José Fernando Duque

 jduquetr@eafit.edu.co​​​​

[Conoce los profesores](https://www.eafit.edu.co/nuestros-profesores?f%5B0%5D=area_de_conocimiento_profesores%3A396)

## ​​Industria​, Materiales y Energía

​​Reúne los saberes y la investigación alrededor de la transformación de la materia, la energía y la información, orienta​do a procesos industriales y servicios relacionado con cadena de suministro, las operaciones y la logística. Lidera proyectos sobre la concepción, el mejoramiento y el mantenimiento de procesos productivos industriales, el desarrollo y uso de los materiales de ingeniería y la generación y aprovechamiento sostenible de la energía.

 Directora

 Mónica Lucía Álvarez Láinez

 malvar26​@eafit.edu.co

[Conoce los profesores](https://www.eafit.edu.co/nuestros-profesores?f%5B0%5D=area_de_conocimiento_profesores%3A401)

## ​​Sistemas Naturales y Sostenibilidad

Enfocada en conocer el sistema Tierra (biosfera, geosfera, hidrosfera y atmósfera) a diferentes escalas espacio-temporales, y los desequilibrios ocasionados por las intervenciones humanas. Contribuye a la formación de científicos e ingenieros, y propondrá alternativas y soluciones tecnológicas que armonicen el funcionamiento biogeoquímico del planeta, la biodiversidad y las dinámicas del bienestar humano.

 Director

 Juan Fernando Díaz Nieto

 jdiazni@eafit.edu.co​​

[Conoce los profesores](https://www.eafit.edu.co/nuestros-profesores?f%5B0%5D=area_de_conocimiento_profesores%3A391)

## ​​​Computación y Analítica

Integra los saberes con el uso de tecnologías, alrededor de las matemáticas aplicadas, la computación, la estadística, la simulación y la optimización. Además, permite entender y predecir la realidad para dar mejores soluciones a problemas simples y retos complejos de sociedad, la industria y las organizaciones.

 Director

 Mario César Vélez Gallego​

 marvelez@eafit.edu.co​​​

[Conoce los profesores](https://www.eafit.edu.co/nuestros-profesores?f%5B0%5D=area_de_conocimiento_profesores%3A406)

## ​​​Ciencias del Cuidado y la Vida

Desarrolla acciones de formación, investigación y generación de conocimiento aplicado para transformar el sistema de salud hacia un sistema de cuidado y bienestar sostenible. Asimismo, contribuye con el desarrollo de una industria del cuidado, la salud y el bienestar más sofisticada y de mayor generación de valor social.​​​

![Image 67: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Grupos de investigación

[Ver grupos de investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/grupos-investigacion#4257225834-3437340343)

## Centro de laboratorios

[Ver Centro de laboratorios](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/centro-laboratorios)

## NODO

[Ver NODO](https://ecommerce.eafit.edu.co/es/cursos-y-diplomados)

## Urbam

[Ver Urbam](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

## Convocatoria de profesores

[Conoce las convocatorias](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/convocatorias-de-profesores)

## Consultorio de Ciencias

[Conoce el Consultorio](https://www.eafit.edu.co/ciencias-aplicadas-e-ingenieria/consultorio-de-ciencias)

## Visiting Professorship Program

[More information](https://universidadeafit.widen.net/s/xvr5lbq6xl/visiting-professor-2026)

## Nuestras redes

### Instagram

[Conoce nuestro Instagram](https://www.instagram.com/cienciasingenieriaeafit/)

### X

[Síguenos en X](https://x.com/CAEI_EAFIT)

### **Noticias**

![Image 68: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=397&h=250&itok=MKSJ4A11)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 69: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=397&h=250&itok=Ai1Iyv7S)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

![Image 70: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=397&h=250&itok=jKshJMEj)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-laboratorio-vivo-para-aprender-haciendo "Ver noticia")

Marzo 12, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias)

![Image 71: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 72: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 73: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 74: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 75: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 76: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 77: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 78: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 81](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
