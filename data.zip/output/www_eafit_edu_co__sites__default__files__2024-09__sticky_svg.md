Title: sticky.svg

URL Source: https://www.eafit.edu.co/sites/default/files/2024-09/sticky.svg

Published Time: Wed, 11 Sep 2024 15:10:13 GMT

Markdown Content:
# sticky.svg

The image depicts the green icon for WhatsApp, which is a popular messaging app
