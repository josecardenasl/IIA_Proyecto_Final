Title: Valor Público

URL Source: https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico

Markdown Content:
# Valor Público - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico# "English")

 Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 8: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 9: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 10: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 11: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 12: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 14: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 15: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 16: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 17: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 18: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 19: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 20: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 21: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 22: Imagen de banner principal mapa de colombia ](https://universidadeafit.widen.net/content/f4eb7aae-b579-4caa-aece-116eac1e22a8/web/Banner_sitio_web_valor_publico.png?crop=yes&k=c&w=1920&h=788&itok=xgvYUZ-i)

# Valor Público

*   [Inicio](https://www.eafit.edu.co/)
*   [​​​​​​​​​​Centros de Estudio ​e Incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
*    Valor Público 

Desplegar menú
*   [Somos](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico "Ancla menú")
*   [Iniciativas](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico "Ancla menú")
*   [Notas de política](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico "Ancla menú")
*   [Documentos de trabajo](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico "Ancla menú")
*   [Investigaciones](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico "Ancla menú")
*   [Mesa de empleo](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico "Ancla menú")

##### Investigamos, creamos y acompañamos proyectos y procesos estratégicos para mejorar problemas públicos.

## **¿Qué hacemos**

**y cómo lo hacemos?**

Inspiramos vidas para el bienestar colectivo. 

Creamos conocimiento para el país posible.

[Conozcan más aquí](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/valor-publico/sobre-nosotros)

### Iniciativas

## Seguridad y justicia

Mejoramos la seguridad y la justicia al comprender a fondo el crimen, sus causas y las dinámicas del sistema judicial. Promovemos mecanismos de prevención y abordamos los desafíos de las economías ilegales, desarrollando líneas de trabajo que fortalezcan políticas públicas para entornos más seguros y pacíficos.

[Conozcan Seguridad y justicia](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico/seguridad-y-justicia)

## Gobierno y democracia

Mejoramos la confianza, eficiencia, eficacia y transparencia de los gobiernos locales al diseñar estrategias y políticas públicas participativas. Acompañamos procesos de reforma del Estado, fortalecemos la gestión pública y el talento humano, e impulsamos liderazgos democráticos que promuevan el cambio en todo el país.

[Conozcan Gobierno y democracia](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico/gobierno-y-democracia)

## Desarrollo económico

Impulsamos la productividad y competitividad de empresas y regiones, con el objetivo de construir sociedades más prósperas e incluyentes. Acompañamos a gobiernos en el diseño y evaluación de políticas basadas en evidencia, utilizando modelos cuantitativos y métodos estadísticos.

[Conozcan Desarrollo económico](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico/desarrollo-economico)

## Equidad y desarrollo social

Aportamos a la disminución de la desigualdad al comprender a fondo los factores que intensifican la inequidad y los que impulsan el desarrollo social. Diseñamos, implementamos y evaluamos estrategias, programas y políticas con enfoque diferencial que promueven la equidad.

[Conozcan Equidad y desarrollo social](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico/equidad-y-desarrollo-social)

## Innovación social

Impulsamos el desarrollo social fortaleciendo la relación universidad-territorio-comunidad y acompañando a organizaciones de la sociedad civil en América Latina. Promovemos el liderazgo, la empresa social y la gerencia social con un enfoque en equidad, diversidad y pluralidad.

[Conozcan Innovación social](https://www.eafit.edu.co/centros-estudio-incidencia/eafit-social)

### Líderes

![Image 23: Imagen Santiago Tobón Zapata](https://universidadeafit.widen.net/content/05abcce5-3bbc-4fe5-93c1-66ccf9777f0f/web/card-santiago-tobon.jpg?crop=yes&k=c&w=397&h=253&itok=CYiYi6fM)

Santiago Tobón Zapata

Director del Centro de Valor Público y líder de la inciativa de Seguridad y justicia

![Image 24: Imagen Santiago Leyva Botero](https://universidadeafit.widen.net/content/beb822c8-556c-4e6c-acd9-61e9a9e69fc8/web/card-santiago-leyva.jpg?crop=yes&k=c&w=397&h=253&itok=8w4WveDU)

Santiago Leyva Botero

Líder de la iniciativa de Gobierno y democracia

![Image 25: Imagen Mónica Hernández Flórez](https://universidadeafit.widen.net/content/7176433d-ff7e-49b0-8e34-ea13fffa0a47/web/card-Monica-Hernandez.jpg?crop=yes&k=c&w=397&h=253&itok=KzGSWV_H)

Mónica Hernández Flórez

Líder de la iniciativa de Equidad y desarrollo social

![Image 26: Imagen Alejandro Torres García](https://universidadeafit.widen.net/content/a450e894-5a0f-4921-aa24-5c82a3b1319a/web/card-alejandro-torres.jpg?crop=yes&k=c&w=397&h=253&itok=eniXKECv)

Alejandro Torres García

Líder de la iniciativa de Desarrollo económico

![Image 27: Imagen Adolfo Eslava Gómez ](https://universidadeafit.widen.net/content/51bba1a7-0dc2-4f93-8fef-6ecec1a4c75f/web/card-adolfo-slava.jpg?crop=yes&k=c&w=397&h=253&itok=UuUpx-5k)

Adolfo Eslava Gómez

Líder de la iniciativa de Innovación social

![Image 28: Imagen María Paulina Domínguez Hernández](https://universidadeafit.widen.net/content/1acda9a8-80ad-4257-8068-5f07eb75c33c/web/card-Maria-Paulina-Dominguez.jpg?crop=yes&k=c&w=397&h=253&itok=fad7XQvh)

María Paulina Domínguez Hernández

Jefa de proyectos de Valor Público

![Image 29: Imagen Angie Palacio Sánchez ](https://universidadeafit.widen.net/content/722254e5-b79a-4078-9513-4d3e56f12e49/web/Angie%20Palacio%20jefa%20de%20incidencia.JPG?crop=yes&k=c&w=397&h=253&itok=mvb6KhjT)

Angie Palacio Sánchez

Jefa de incidencia de Valor Público

Notas de política

![Image 30: Imagen Construcción de Estado en la ciudad: lecciones de un experimento en alternativas civiles a la policía de Medellín](https://universidadeafit.widen.net/content/3a097b05-15e3-45ad-af7e-4d0678db8696/web/Card%20nota%20Construcci%C3%B3n%20de%20Estado.jpg?crop=yes&k=c&w=397&h=253&itok=g8QELMtg)

Construcción de Estado en la ciudad: lecciones de un experimento en alternativas civiles a la policía de Medellín

[Conoce la nota](https://universidadeafit.widen.net/s/s9qftgxgrm/construccion-de-estado-en-la-ciudad-lecciones-de-un-experimento-en-alternativas-civiles-a-la-policia-de-medellin)

![Image 31: Imagen Más allá del cultivo: estrategias para una política arrocera efectiva y sostenible](https://universidadeafit.widen.net/content/d4343425-9923-4f94-bb4e-3e55dd2ad59e/web/Portada%20nota%20de%20pol%C3%ADtica%20M%C3%A1s%20all%C3%A1%20del%20cultivo,%20estrat%C3%A9gias%20para%20una%20pol%C3%ADtica%20arrocera%20efectiva%20y%20sostenible.png)

Más allá del cultivo: estrategias para una política arrocera efectiva y sostenible

[Conoce la nota](https://universidadeafit.widen.net/s/b6khvs5vfs/nota-de-politica-mas-alla-del-cultivo-estrategias-para-una-politica-arrocera-efectiva-y-sostenible)

![Image 32: Imagen Promoción de la salud mental en universidades colombianas: desafíos y propuestas de política pública](https://universidadeafit.widen.net/content/3aec2c75-296e-4003-843f-fc06a134885d/web/Portada%20nota%20de%20pol%C3%ADtica%20promoci%C3%B3n%20de%20la%20salud%20mental%20en%20universidades.png)

Promoción de la salud mental en universidades colombianas: desafíos y propuestas de política pública

[Conoce la nota](https://universidadeafit.widen.net/view/pdf/bpyfhlwoqt/Promocion-de-la-salud-mental-en-universidades-colombianas-desafios-y-propuestas-de-politica-publica.pdf?t.download=true&u=amlqiy)

[Más notas de política](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico/notas-de-politica)

Documentos de trabajo

![Image 33: Imagen Del tsunami al terremoto demográfico en Colombia](https://universidadeafit.widen.net/content/bf920dcb-0969-45e4-9744-13307305dc94/web/Cards%20documentos%20de%20trabajo-29.jpg?crop=yes&k=c&w=397&h=253&itok=nEFVqvzo)

Del tsunami al terremoto demográfico en Colombia

[Conoce el documento](https://universidadeafit.widen.net/s/fwqqplvxrv/del-tsunami-al-terremoto-demografico-en-colombia)

![Image 34: Imagen The Property Tax Modernization Dilemma: A Decision-Support Framework for Equity and Revenue Under Cadastral Reform](https://universidadeafit.widen.net/content/4e8773ee-61dd-4296-af35-14e70e5bc3af/web/portada%20documento%20de%20trabajo%20The%20Property%20Tax%20Dilemma)

The Property Tax Modernization Dilemma: A Decision-Support Framework for Equity and Revenue Under Cadastral Reform

[Conoce el documento](https://universidadeafit.widen.net/s/md9xqzxlfx/the-property-tax-modernization-dilemma-a-decision-support-framework-for-equity-and-revenue-under-cadastral-reform)

![Image 35: Imagen Listening Through the Walls: How Qualitative Research Reveals the Human Impact of Better Housing](https://universidadeafit.widen.net/content/034e6949-84d5-46ae-b614-57b4b0ec8b92/web/Portada%20documento%20de%20trabajo%20Listening%20through%20the%20walls%202)

Listening Through the Walls: How Qualitative Research Reveals the Human Impact of Better Housing

[Conoce el documento](https://universidadeafit.widen.net/s/ljbqv7pjsl/listening-through-the-walls-how-qualitative-research-reveals-the-human-impact-of-better-housing)

[Más documentos de trabajo](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico/documentos-de-trabajo)

Investigaciones

![Image 36: Imagen Cuidar la democracia](https://universidadeafit.widen.net/content/18d8fe31-009b-4cd8-998e-de8e99b944bd/web/Portada%20investigaci%C3%B3n%20Cuidar%20la%20democracia.jpg)

Cuidar la democracia

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/dmnaozosnc/Cuidar-la-democracia.pdf?t.download=true&u=amlqiy)

![Image 37: Imagen Red de concejalas del Valle de Aburrá](https://universidadeafit.widen.net/content/0d64f35e-50cf-4657-8d1b-2224430d13d0/web/portada-diagnostico-red-de-concejalas-del-valle-de-aburra.jpg)

Red de concejalas del Valle de Aburrá

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/ylzvboviug/red-de-concejalas-del-valle-de-aburra-diagnostico.pdf?u=amlqiy)

![Image 38: Imagen Efectos económicos de la descentralización fiscal en Colombia](https://universidadeafit.widen.net/content/b0fdf242-e8c9-4b89-bfb9-0debe97656a9/web/efectos-economicos-valor-publico-2025.jpg)

Efectos económicos de la descentralización fiscal en Colombia

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/ufsvze6et6/1.Efectos-econmicos-de-la-descentralizacin-fiscal.pdf?t.download=true&u=amlqiy)

![Image 39: Imagen Medir la administración local para mejorarla descentralización](https://universidadeafit.widen.net/content/c407c0ac-f0e8-4860-9111-14e244562eae/web/medir-la-administracion-local-valor-publico-2025.jpg)

Medir la administración local para mejorarla descentralización

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/uxakviaa9o/eafit-medirla-administracion-para-la-descentralizacion.pdf?t.download=true&u=amlqiy)

![Image 40: Imagen ​​Descentralización y autonomía territorial](https://universidadeafit.widen.net/content/01a441a8-6dca-49ed-a163-d3aa4a48adba/web/descentralizacion-y-autonomia-territorial.jpg)

​​Descentralización y autonomía territorial

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/xmhvx8e9v1/descentralizacion-autonomia-territorial.pdf?t.download=true&u=amlqiy)

![Image 41: Imagen ​​Desigualdades Territoriales en Colombia: realidades y perspectivas](https://universidadeafit.widen.net/content/378f6a86-debd-4166-8dbe-0b3b9148d9ef/web/portada-desigualdades.png)

​​Desigualdades Territoriales en Colombia: realidades y perspectivas

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/iajbihhh1j/Desigualdades-territoriales-en-Colombia-realidades-y-perspectivas.pdf?t.download=true&u=amlqiy)

![Image 42: Imagen ​​Finanzas y biodiversidad para territorios posibles](https://universidadeafit.widen.net/content/403490d0-d43a-4528-8db6-892647c053c5/web/finanzas-biodiversidad.jpg)

​​Finanzas y biodiversidad para territorios posibles

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/bij3kodnkr/Libro-Finanzas-y-biodiversidad-para-territorios-posibles.pdf.pdf?t.download=true&u=amlqiy)

![Image 43: Imagen ​Por Antioquia firme​​](https://universidadeafit.widen.net/content/927b57e6-aab7-4f8f-977c-46e04aef5682/web/Portada-recomendaciones-a-por-antioquia-firme-anteproyecto-del-plan-de-desarrollo.jpg)

​Por Antioquia firme​​

[Conoce la investigación](https://universidadeafit.widencollective.com/assets/share/asset/a1jcsdglig)

![Image 44: Imagen ¿Cómo se ha construido la administración pública colombiana?](https://universidadeafit.widen.net/content/78c036f6-7f1b-406c-9c38-77e667a97717/web/portada-como-se-ha-construido-la-administracion-publica-colombiana.jpg)

¿Cómo se ha construido la administración pública colombiana?

[Conoce la investigación](https://universidadeafit.widen.net/s/shttkw72mt/leyva-sanabria-2024-construido-la-administracion-publica-colombiana)

![Image 45: Imagen Anteproyecto del Plan de Desarrollo de Medellín​​](https://universidadeafit.widen.net/content/1ae8e7e7-c157-43f9-9158-c283385f5f7f/web/portada-recomendaciones-a-el-plan-es-con-vos-anteproyecto-del-plan-de-desarrollo-de-medellin.jpg)

Anteproyecto del Plan de Desarrollo de Medellín​​

[Conoce la investigación](https://universidadeafit.widen.net/s/n7m7xgvslm/recomendaciones-plan-es-con-vos)

![Image 46: Imagen Dimensiones y dinámicas de la Agricultura Campesina](https://universidadeafit.widen.net/content/dd4fef95-4aea-491b-bf5b-9192a7d1cddd/web/portada-dimensiones-y-dinamicas-de-la-agricultura-campesina.jpg)

Dimensiones y dinámicas de la Agricultura Campesina

[Conoce la investigación](https://universidadeafit.widen.net/s/jzqfmrbqgr/dimensiones-dinamicas)

![Image 47: Imagen La transformación de Sabaneta](https://universidadeafit.widen.net/content/2a4e9139-a304-474d-889b-c2250efd0997/web/portada-la-transformacion-de-sabaneta.jpg)

La transformación de Sabaneta

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/kkk91xiblk/libro-sabaneta-2023.pdf)

![Image 48: Imagen Diagnóstico de brechas de género](https://universidadeafit.widen.net/content/935996dd-3aae-428d-a5bb-52e4167e363f/web/portada-diagnostico-de-brechas-de-genero-en-sectores-masculinizados-y-feminizados.jpg)

Diagnóstico de brechas de género

[Conoce la investigación](https://universidadeafit.widen.net/s/sjxhcdgqls/diagnostico-de-sectores-noviembre)

![Image 49: Imagen Estrategias efectivas para la incorporación de la perspectiva de género](https://universidadeafit.widen.net/content/be397980-390c-4369-8433-f4962bab5859/web/portada-estrategias-efectivas-para-la-incorporacion-de-la-perspectiva-de-genero.jpg)

Estrategias efectivas para la incorporación de la perspectiva de género

[Conoce la investigación](https://universidadeafit.widen.net/s/cwtbqpjfxg/estrategia-efectiva-cadena-de-valor-49)

![Image 50: Imagen Estrategias anticontrabando y crimen organizado](https://universidadeafit.widen.net/content/51dec927-dc69-4e5b-bda7-3523457dcc5c/web/estrategias-anticontrabandro.png)

Estrategias anticontrabando y crimen organizado

[Conoce la investigación](https://universidadeafit.widen.net/s/mt7pwmhjlw/libro-estrategias-anticontrabando-crimen-organizado)

![Image 51: Imagen Actualización  de la situación de las mujeres en el sector empresarial antioqueño ](https://universidadeafit.widen.net/content/4275bb64-6874-4999-ba5c-2f851062b3a5/web/documento-actualizacion.png)

Actualización de la situación de las mujeres en el sector empresarial antioqueño

[Conoce la investigación](https://universidadeafit.widen.net/s/lrrwqh6g5r/situacion-mujeres-empresarial-antioqueno-instrumentos-existentes)

![Image 52: Imagen  ​Estrategias para la conciliación de la vida laboral, personal y familiar en el sector privado ](https://universidadeafit.widen.net/content/f8d92399-abe8-4f14-8f9a-c461ba2a43c6/web/estrategias-concilacion.png)

​Estrategias para la conciliación de la vida laboral, personal y familiar en el sector privado

[Conoce la investigación](https://universidadeafit.widen.net/s/mwm2s2gxcp/estrategias-conciliacion-vida-laboral-personal-familiar-sector-privado-nacional-internacional)

![Image 53: Imagen Elaboración de diagnósticos sobre brechas de género al interior de empresas. ](https://universidadeafit.widen.net/content/fc5fa27b-a136-4326-bc11-d0f9f26cca91/web/guia-metodologica.png)

Elaboración de diagnósticos sobre brechas de género al interior de empresas.

[Conoce la investigación](https://universidadeafit.widen.net/s/ptn9hcnpxf/metodologica-elaboracion-diagnosticos-brechas-interior-empresas)

![Image 54: Imagen Guía para el diseño de políticas en equidad de género.](https://universidadeafit.widen.net/content/ec8eab04-dc7b-44b9-94bb-cd9e74184896/web/guia-diseno.png)

Guía para el diseño de políticas en equidad de género.

[Conoce la investigación](https://universidadeafit.widen.net/s/zzssgjmllr/guia-diseno-politicas-equidad-genero)

![Image 55: Imagen ABC de las políticas públicas. Kit para el diseño.](https://universidadeafit.widen.net/content/3552779e-ea7c-4493-be48-db62ce7a9184/web/abc.png)

ABC de las políticas públicas. Kit para el diseño.

[Conoce la investigación](https://universidadeafit.widen.net/s/wkcrzrfcwl/kit-politicas)

![Image 56: Imagen Guía Metodológica de Deliberación y Acción para Escenarios Metropolitanos de Interacción Social](https://universidadeafit.widen.net/content/6914f7f5-b309-4ece-96d4-77b068bb0061/web/guia-metodologica-deliberacion.png)

Guía Metodológica de Deliberación y Acción para Escenarios Metropolitanos de Interacción Social

[Conoce la investigación](https://universidadeafit.widen.net/s/tpqvvfxsmz/guia-metodologica-deliberacion-accion)

![Image 57: Imagen Criterios para la identificación de buenas prácticas empresariales  la equidad de género](https://universidadeafit.widen.net/content/ad4a8272-fc0e-4475-88d1-96db16ce32d3/web/criterios-buenas-practicas-genero.png)

Criterios para la identificación de buenas prácticas empresariales la equidad de género

[Conoce la investigación](https://universidadeafit.widen.net/s/tgljp2h7jf/criterios-para-la-identificacion-de-buenas-practicas-empresariales-para-la-equidad-genero)

![Image 58: Imagen Buenas prácticas empresariales para la equidad de género](https://universidadeafit.widen.net/content/6be3605e-9237-419d-8c42-11b9d7e0bc1a/web/buenas-practicas-genero.png)

Buenas prácticas empresariales para la equidad de género

[Conoce la investigación](https://universidadeafit.widen.net/s/6fdk7f2vzp/buenas-practicas-empresariales-para-equidad-genero)

![Image 59: Imagen Línea base e identificación de buenas prácticas de equidad en el sector empresarial antioqueño](https://universidadeafit.widen.net/content/6ba8204d-3085-494e-bb67-d65dc9525111/web/linea-base-equidad.png)

Línea base e identificación de buenas prácticas de equidad en el sector empresarial antioqueño

[Conoce la investigación](https://universidadeafit.widen.net/s/plkjbxdlts/linea-base-identificacion-buenas-practicas-equidad--sector-empresarial-antioqueno)

![Image 60: Imagen Mapas y factores de riesgo electoral](https://universidadeafit.widen.net/content/2c1c30d1-de98-4854-8dfc-c145aff83799/web/mapas-factores.png)

Mapas y factores de riesgo electoral

[Conoce la investigación](https://universidadeafit.widen.net/s/brp75pp82s/medellin-digital)

![Image 61: Imagen Agroparque Biosuroeste](https://universidadeafit.widen.net/content/3f83cf74-ef4d-4e44-8d1e-1e0311d0fa4d/web/agroparque-biosuroeste.jpg)

Agroparque Biosuroeste

[Conoce la investigación](https://universidadeafit.widen.net/s/lxrxcz6gcz/folleto-sitematizacion-proyecto-agroparque-biosuroeste-compressed)

![Image 62: Imagen Co-crear la cultura ciudadana apuntes ](https://universidadeafit.widen.net/content/5c527189-bcc4-4124-b765-6e13eda0bad5/web/co-crear.jpeg)

Co-crear la cultura ciudadana apuntes

[Conoce la investigación](https://universidadeafit.widen.net/s/mlzbfvt69p/crear-cultura-ciudadana-apuntes-conceptuales-taller-ideas)

![Image 63: Imagen Política Pública Metropolitana de Seguridad y Convivencia Ciudadana](https://universidadeafit.widen.net/content/5c8cd748-0915-4d9e-b301-4237ef599c40/web/politica-publica.png)

Política Pública Metropolitana de Seguridad y Convivencia Ciudadana

[Conoce la investigación](https://universidadeafit.widen.net/s/f9lbjbpzk9/politica-publica-metropolitana-final)

![Image 64: Imagen Análisis para las políticas públicas.](https://universidadeafit.widen.net/content/c3ef44e7-7479-4e66-88f7-c769ab267bfa/web/analisis-politicas-publicas.jpg)

Análisis para las políticas públicas.

[Conoce la investigación](https://universidadeafit.widen.net/s/nlgbxdrxdh/igualdad-genero)

![Image 65: Imagen Cultura Ciudadana. Reflexiones y experiencias de ciudad](https://universidadeafit.widen.net/content/5272feee-2c0c-4e2a-8f6b-7e6513cf2ba2/web/cultura-seguridad-ciudadana.jpg)

Cultura Ciudadana. Reflexiones y experiencias de ciudad

[Conoce la investigación](https://universidadeafit.widen.net/s/5ctxm8qzgd/libro-cultura-ciudadana)

![Image 66: Imagen Seguridad ciudadana desde la gobernanza metropolitana](https://universidadeafit.widen.net/content/9c404df9-b885-4637-b748-94d623bf394e/web/seguridad-ciudadana.jpg)

Seguridad ciudadana desde la gobernanza metropolitana

[Conoce la investigación](https://universidadeafit.widencollective.com/assets/share/asset/z1vuepiprj)

![Image 67: Imagen Pensar y construir el territorio desde la cultura.](https://universidadeafit.widen.net/content/da69f551-9c4d-4fab-ba94-3d06d918a523/web/pensar-construir.jpg)

Pensar y construir el territorio desde la cultura.

[Conoce la investigación](https://universidadeafit.widen.net/s/wnjqtwjbjt/publicacion-lab-cultura-ciudadana-2016)

![Image 68: Imagen Imaginarios comunes, sueños colectivos y acciones ciudadanas.](https://universidadeafit.widen.net/content/8326a817-cabd-4f4f-b458-cad53b80a93d/web/imaginarios-comunes.jpg)

Imaginarios comunes, sueños colectivos y acciones ciudadanas.

[Conoce la investigación](https://universidadeafit.widen.net/s/gqzrksmptm/publicacion-lab-cultura-ciudadana-2017-imaginar)

![Image 69: Imagen Gerencia social. Misión nacional, experiencias y alianzas para el desarrollo rural.](https://universidadeafit.widen.net/content/ff174197-85bb-4097-829c-ef3c69da4730/web/gerencia-social.jpg)

Gerencia social. Misión nacional, experiencias y alianzas para el desarrollo rural.

[Conoce la investigación](https://universidadeafit.widen.net/s/b5npqqqrrl/mision-documental)

![Image 70: Imagen Gerencia social. Hacia la gobernanza colaborativa](https://universidadeafit.widen.net/content/dffacf6f-e404-45a2-8fb0-c976d3eeb6bb/web/gerencia-social-gobernanzas.jpg)

Gerencia social. Hacia la gobernanza colaborativa

[Conoce la investigación](https://universidadeafit.widen.net/s/qjgh7rgq2p/mision-irlanda)

![Image 71: Imagen Gestión Territorial de la Seguridad en el Posconflicto CESEP 2016](https://universidadeafit.widen.net/content/c537e44c-a4b5-44a0-8c68-e074d645e5a0/web/gestion-territorial.png)

Gestión Territorial de la Seguridad en el Posconflicto CESEP 2016

[Conoce la investigación](https://universidadeafit.widen.net/s/75vnbnpkzr/gestion-territorial-seguridad-posconflicto-2016-2)

![Image 72: Imagen Medellín: memorias de una guerra urbana](https://universidadeafit.widen.net/content/bb09f0d7-375e-450c-bd6e-c976d536304d/web/medellin-memorias.png)

Medellín: memorias de una guerra urbana

[Conoce la investigación](https://universidadeafit.widen.net/s/fgvqxrdrt5/medellin-memorias-guerra-urbana)

![Image 73: Imagen Libro Blanco de la seguridad y la convivencia de Medellín](https://universidadeafit.widen.net/content/3e3a5057-bcd5-4c1f-86b5-1d3b869d280d/web/libro-blanco.jpg)

Libro Blanco de la seguridad y la convivencia de Medellín

[Conoce la investigación](https://universidadeafit.widen.net/s/vcf6c7lszs/libro-blanco-seguridad-convivencia-medellin)

![Image 74: Imagen Territorio, crimen, comunidad: Heterogeneidad del homicidio](https://universidadeafit.widen.net/content/3f9834f8-a122-4632-b866-375c1e303676/web/territorio-crimen.jpg)

Territorio, crimen, comunidad: Heterogeneidad del homicidio

[Conoce la investigación](https://universidadeafit.widen.net/s/wqjk9s6x2x/territorio-crimen-comunidad-heterogeneid)

![Image 75: Imagen Nuevas modalidades de captación de rentas ilegales en Medellín](https://universidadeafit.widen.net/content/eb4be702-3615-4883-baf6-a2dda63ab03d/web/nuevas-modalidades.jpg)

Nuevas modalidades de captación de rentas ilegales en Medellín

[Conoce la investigación](https://universidadeafit.widen.net/s/d5zpqzvjlg/rentas-ilegales-medellin)

![Image 76: Imagen Economía criminal en Antioquia: Narcotráfico](https://universidadeafit.widen.net/content/76b5228f-55d8-41cb-b086-3c2f24f1af54/web/Portada-economia-criminal-en-antioquia-narcotr%C3%A1fico.png)

Economía criminal en Antioquia: Narcotráfico

[Conoce la investigación](https://universidadeafit.widen.net/view/pdf/mgqcbneaub/libro-economia-criminal.pdf?t.download=true&u=amlqiy)

![Image 77: Imagen La Ciencia Política en Colombia](https://universidadeafit.widen.net/content/5f84c971-45f7-4b6f-bcc2-bc9126073bcf/web/ciencia-politica.jpg)

La Ciencia Política en Colombia

[Conoce la investigación](https://universidadeafit.widen.net/s/rwgwbmbcwq/la-ciencia-politica-colombia)

![Image 78: Imagen El lado dorado de la minería](https://universidadeafit.widen.net/content/431e4910-2de9-4862-9b2e-0826d3518fe4/web/el-lado-dorado.jpg)

El lado dorado de la minería

[Conoce la investigación](https://universidadeafit.widen.net/s/hkvsrvgz9r/3-cartilla-lado-dorado-mineria)

![Image 79: Imagen Análisis de política pública poblacional](https://universidadeafit.widen.net/content/47440a3b-0e2b-42f3-aecb-48c484c9fd8b/web/analisis-politicas-publica-poblacional.jpg)

Análisis de política pública poblacional

[Conoce la investigación](https://universidadeafit.widen.net/s/tpmxdpmsvm/libro-completo-analisis-politica)

![Image 80: Imagen Economía criminal y poder político](https://universidadeafit.widen.net/content/e595196c-fd14-482d-8ade-2ce50a7ae06f/web/economia-criminal-poder.jpg)

Economía criminal y poder político

[Conoce la investigación](https://universidadeafit.widen.net/s/89bsvfrtpx/economia-criminal-poder-politico)

![Image 81: Imagen Informalidad e ilegalidad](https://universidadeafit.widen.net/content/745c51f8-310d-4851-bee9-d3cf36eed94e/web/informalidad-ilegalidad.jpg)

Informalidad e ilegalidad

[Conoce la investigación](https://universidadeafit.widen.net/s/z5bbmwjxsb/oro-madera)

![Image 82: Imagen Encuesta de percepción](https://universidadeafit.widen.net/content/c0d117f1-7db2-4a01-860f-5b75b848f0e4/web/encuesta-percepcion.jpg)

Encuesta de percepción

[Conoce la investigación](https://universidadeafit.widen.net/s/r6wwwkgchn/encuesta-percepcion-seguridad)

![Image 83: Imagen Seguridad y convivencia en Medellín](https://universidadeafit.widen.net/content/a09d0de1-9394-4b07-9b65-b872ff0ce177/web/seguridad-convivencia.jpg)

Seguridad y convivencia en Medellín

[Conoce la investigación](https://universidadeafit.widen.net/s/zfpxv5hvpk/seguridad-convivencia-medellin)

![Image 84: Imagen Valores  en Antioquia 2013](https://universidadeafit.widen.net/content/7ea1d63a-c6ca-43ab-84fc-7b5e7bb26dd5/web/valores-representaciones.jpg)

Valores en Antioquia 2013

[Conoce la investigación](https://universidadeafit.widen.net/s/kds9sz9zcd/valores-representaciones-capital-social)

![Image 85: Imagen Oro como fortuna](https://universidadeafit.widen.net/content/760cd74f-a977-4895-9747-cfe95fbbcb37/web/oro-fortuna.jpg?crop=yes&k=c&w=397&h=253&itok=K60YCcB1)

Oro como fortuna

[Conoce la investigación](https://universidadeafit.widen.net/s/sqchkpv5vh/libro-oro-fortuna)

## Mesa del empleo de Antioquia

La Mesa del Empleo de Antioquia es una alianza interinstitucional que analiza datos oficiales y registros administrativos para comprender la dinámica del empleo en el departamento. A través de informes semestrales, aporta evidencia útil para la toma de decisiones públicas, empresariales y ciudadanas, entendiendo el trabajo como eje del desarrollo económico y social.

[Conoce la Mesa de Empleo](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico/mesa-del-empleo-antioquia)

![Image 86: Imagen Mesa del empleo de Antioquia](https://universidadeafit.widen.net/content/6b4f97c0-178a-4ab9-ae6f-5f8b6c211ac4/web/Empleo1900.jpg)

![Image 87: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 88: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 89: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 90: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 91: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 92: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 93: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 94: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 95](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
