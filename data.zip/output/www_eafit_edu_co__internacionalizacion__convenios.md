Title: Convenios

URL Source: https://www.eafit.edu.co/internacionalizacion/convenios

Published Time: Thu, 07 May 2026 21:02:30 GMT

Markdown Content:
# Convenios Internacionales - EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/internacionalizacion/convenios#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 2: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/internacionalizacion/convenios#)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/internacionalizacion/convenios# "Spanish")[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/internacionalizacion/convenios# "English")

 Información para ti

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 6: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 7: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 8: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 9: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 10: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 12: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 13: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 14: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 15: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 16: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 17: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 18: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 19: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 20: Imagen de banner Personas dialogando en sala de reuniones de EAFIT](https://universidadeafit.widen.net/content/31a05377-51b0-4d10-b93a-9d254c7e3d85/web/Convenios.jpg?crop=yes&k=c&w=1920&h=788&itok=55u9TAEW)

# Convenios

Bienvenido a la sección de convenios de Internacionalización EAFIT. Nuestra misión es fortalecer los vínculos institucionales, conectando los intereses de nuestros aliados con las capacidades académicas, Centros y Escuelas de la Universidad. Por medio de la exploración de alianzas estratégicas, la gestión de convenios y la recepción de visitas, conectamos a la Universidad EAFIT con el mundo.

[Ver mapa aliados](https://www.google.com/maps/d/embed?mid=1dn5HQVp9nDPh3P1akHxKAURE_Br-V8Y&ehbc=2E312F%22&ll=28.323531538955816%2C-17.086663494836785&z=2)

*   [Inicio](https://www.eafit.edu.co/)
*   [Internacionalización](https://www.eafit.edu.co/internacionalizacion)
*    Convenios 

## **Convenios**

[Solicitud inicial](https://www.eafit.edu.co/internacionalizacion/convenios#4257225834-2367901931)

Solicitud inicial

Puede ser una solicitud interna por parte de alguna dependencia/profesor de EAFIT, o una solicitud externa por parte de una institución internacional.

1.   **Responsable:** Institución externa o interesado académico/administrativo por parte de EAFIT.
2.   **Plazo estimado:** 3 meses de anticipación a la fecha esperada de entrada en vigor.
3.   **Documentación requerida:** Formato de solicitud de convenio diligenciado.
4.   **Correo de contacto:** agreements@eafit.edu.co

[Revisión por la Universidad](https://www.eafit.edu.co/internacionalizacion/convenios#4257225834-1757421126)

Revisión por la Universidad

**Revisión por parte de la Universidad EAFIT**

Revisión de la solicitud y del perfil de la institución internacional. Al igual que se realiza la elaboración y ajuste del modelo preliminar del convenio.

1.   **Responsable:**Internacionalización EAFIT (y responsable académico de ser necesario)
2.   **Plazo estimado**:15 días hábiles a partir de la solicitud o la entrega del Formato de Solicitud diligenciado.

[Revisión por la Institución](https://www.eafit.edu.co/internacionalizacion/convenios#4257225834-2263164407)

Revisión por la Institución

**Revisión por parte de la institución internacional**

Revisión del borrador del convenio por parte aliado.

1.   **Responsable:** Institución internacional
2.   **Plazo estimado*:** Aproximadamente 1 mes a partir del envío del documento revisado por EAFIT.

*Este plazo depende totalmente del proceso de revisión y los tiempos de la institución internacional.

[Dado el caso de que el aliado proponga una nueva versión del documento con ajustes o modificaciones, el proceso regresará a la Etapa 2 - Revisión EAFIT].

[Revisión de Secretaría](https://www.eafit.edu.co/internacionalizacion/convenios#4257225834-1106125263)

Revisión de Secretaría

**Revisión de Secretaría General (EAFIT)de la versión final del convenio**

1.   **Responsable:** Secretaría General.
2.   **Plazo estimado:** 5 días hábiles a partir de la recepción de la versión final del convenio.

[En caso de que Secretaría General requiera una nueva versión del documento con ajustes o modificaciones, el proceso regresará a la Etapa 3 - Revisión del aliado].

[Firma por EAFIT](https://www.eafit.edu.co/internacionalizacion/convenios#4257225834-2521646023)

Firma por EAFIT

**Firma por parte de la Universidad EAFIT**

Firma del convenio por parte de la Vicerrectora de Aprendizaje, representante legal de la Universidad EAFIT.

1.   **Responsable:**Internacionalización EAFIT.
2.   **Plazo estimado:** 15 días hábiles a partir de la entrega de todos los documentos.
3.   **Documentos:** El responsable académico del convenio (EAFIT) debe firmar el convenio y el formato de "Aprobaciones para firmas de convenios VRA".

**Responsable académico**

**¿Quién es el responsable académico del convenio?**

En algunos casos, se trata de la persona que lidera el relacionamiento con la institución aliada, mientras que en otros, es quien avala la suscripción del mismo y que promueve su aplicación dentro del ámbito académico dentro de las Escuelas y los programas.

**¿Qué significa ser responsable del convenio?**

Como requisito de la Vicerrectoría de Aprendizaje, todos los convenios deben tener la firma de un responsable académico, que respalde la gestión del convenio. Lo que responde a la estrategia de la universidad de firmar únicamente convenios que tengan un propósito y beneficio claro para las Escuelas, Centros y la comunidad eafitense, en general.

[Firma por el Aliado](https://www.eafit.edu.co/internacionalizacion/convenios#4257225834-163477551)

Firma por el Aliado

**Firma por el Aliado**

El aliado recibe el convenio firmado por la Universidad EAFIT y procede con la firma del documento por su parte.

1.   **Responsable:**Institución aliada.
2.   **Plazo estimado*:**Aproximadamente 1 mes a partir del envío del convenio firmado.

_*Este plazo depende totalmente de los tiempos de la institución internacional._

[Otras formas de internacionalización](https://www.eafit.edu.co/internacionalizacion/convenios#230548828-129353967)

*   Acreditaciones internacionales.
*   Actividades culturales, académicas, deportivas o de extensión que tengan un componente internacional o de segunda lengua.
*   Actividades de Internacionalización en casa.
*   Articulación con los Centros de Incidencia y Estudio de EAFIT.
*   Centro de Idiomas.
*   Convenios internacionales.
*   Grupos de investigación.
*   Grupos entrantes de Study Abroad.
*   Métodos de enseñanza-aprendizaje utilizados para la internacionalización del currículo.
*   Pasantías de investigación.
*   Participación en proyectos de cooperación internacional.
*   Política de Lengua Extranjera.
*   Prácticas en el extranjero.
*   Producción intelectual de alcance internacional: ponencias, conferencias, artículos, capítulos de libros, patentes, coautorías, etc.
*   Profesores visitantes.
*   Redes y asociaciones internacionales.

[Conviértete en aliado de EAFIT](https://www.eafit.edu.co/internacionalizacion/convenios#230548828-798405549)

La Universidad EAFIT tiene como prioridad alianzas con instituciones de alta calidad y reconocimiento. Estas asociaciones suelen implicar investigación cofinanciada, movilidad de profesores y estudiantes y programas conjuntos.

Como se ha mencionado anteriormente, EAFIT establece relaciones estratégicas con socios nacionales e internacionales de alta calidad, con los que compartimos nuestros valores fundamentales y desarrollamos asociaciones únicas a largo plazo que contribuyen a:

1.   Cumplir la misión de ambas instituciones.
2.   Ofrecer a estudiantes, profesores y personal una amplia gama de oportunidades para mejorar sus competencias y alcance internacionales.
3.   Apoyar el desarrollo de capacidades de alcance institucional.

**Nuestras asociaciones internacionales abarcan un amplio espectro de países, idiomas y propósitos, y se desarrollan bajo las premisas de:**

1.   Reciprocidad.
2.   Confianza.
3.   Compromiso.
4.   Sostenibilidad.

## Contact

![Image 21: Imagen Contact](https://universidadeafit.widen.net/content/e6941656-54f1-49a6-b065-a991092db822/web/aprendizaje-global-contacto.jpg?crop=yes&k=c&w=770&h=380&itok=cBmNVzx6)

Global Engagement

[agreements@eafit.edu.co](mailto:agreements@eafit.edu.co)

![Image 22: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 23: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 24: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 25: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 26: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 27: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 28: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 29: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
