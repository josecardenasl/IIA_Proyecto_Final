Title: banner-proyectos-ctei.jpg

URL Source: https://www.eafit.edu.co/sites/default/files/2025-07/banner-proyectos-ctei.jpg

Published Time: Fri, 25 Jul 2025 19:32:24 GMT

Markdown Content:
# banner-proyectos-ctei.jpg

a person pointing at plans on a white wall
