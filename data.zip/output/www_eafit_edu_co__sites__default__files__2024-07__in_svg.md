Title: in.svg

URL Source: https://www.eafit.edu.co/sites/default/files/2024-07/in.svg

Published Time: Wed, 31 Jul 2024 02:35:09 GMT

Markdown Content:
# in.svg

A 53x48 small image, likely a logo, icon or avatar
