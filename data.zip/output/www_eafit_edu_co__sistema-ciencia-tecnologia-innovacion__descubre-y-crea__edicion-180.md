Title: Edición 180

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180

Markdown Content:
[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180# "English")

Buscar

![Image 6: Imagen de banner mujer en laboratorio ](https://universidadeafit.widen.net/content/a0a6dd27-5ae0-4990-bb08-2ad68cf88680/web/banner_dyc_180.jpg?crop=yes&k=c&w=1920&h=788&itok=S9pRoU6J)

## Revista Descubre y Crea

#### Tiempo - Edición 180

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Descubre y Crea](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea)
*    Edición 180 

![Image 7: Imagen El valor de la historia empresarial para la prospectiva y la estrategia](https://universidadeafit.widen.net/content/cf8a5619-2246-4dcb-b6cb-1836209d6175/web/conexion-emprendimientos%20(10).jpg?crop=yes&k=c&w=397&h=250&itok=SKiwFzMB)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## El valor de la historia empresarial para la prospectiva y la estrategia

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/entre-preguntas-y-decisiones-para-navegar-la-gerencia-del-futuro "Ver noticia")

Agosto 24, 2025

![Image 8: Imagen Recorre la historia del planeta Tierra en un paseo por EAFIT ](https://universidadeafit.widen.net/content/929a535f-65ab-4414-8703-5c1ba6c4bcff/web/personas-caminnado-por-el-campus.jpg?crop=yes&k=c&w=397&h=250&itok=HadVx9w1)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## Recorre la historia del planeta Tierra en un paseo por EAFIT

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/recorre-la-historia-del-planeta-tierra-en-un-paseo-por-eafit "Ver noticia")

Agosto 24, 2025

![Image 9: Imagen ¿Por qué ya no se puede leer el tiempo en el sol?  ](https://universidadeafit.widen.net/content/6d9c328e-c26e-4bf5-b4e9-e8cd06601d10/web/calendario-wayuu.png?crop=yes&k=c&w=397&h=250&itok=ekbAgYSF)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## ¿Por qué ya no se puede leer el tiempo en el sol?

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/por-que-ya-no-se-puede-leer-el-tiempo-en-el-sol "Ver noticia")

Agosto 24, 2025

![Image 10: Imagen El factor “tiempo” en la generación de valor público e impacto positivo a través de la intencionalidad empresarial  ](https://universidadeafit.widen.net/content/1decbeeb-06d6-4ff9-bae2-fe54de2dfd4c/web/empresas_descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=Hudcz8yp)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## El factor “tiempo” en la generación de valor público e impacto positivo a través de la intencionalidad empresarial

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/el-factor-tiempo-en-la-generacion-de-valor-publico "Ver noticia")

Agosto 21, 2025

![Image 11: Imagen Michel Hermelin. Un abrazo a la Tierra ](https://universidadeafit.widen.net/content/98c63fe6-d198-4b00-b4e2-cff1a18c6ca1/web/guatape_descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=rl7uoKNn)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## Michel Hermelin. Un abrazo a la Tierra

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/michel-Hermelin-un-abrazo-a-la-tierra "Ver noticia")

Agosto 21, 2025

![Image 12: Imagen ¿El mundo en el futuro? Tres escenarios posibles  ](https://universidadeafit.widen.net/content/b4cb599b-5d7b-44e3-90d7-fed4850305a2/web/laberinto_descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=05jSwgpO)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## ¿El mundo en el futuro? Tres escenarios posibles

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/el-mundo-en-el-futuro-tres-escenarios-posibles "Ver noticia")

Agosto 21, 2025

![Image 13: Imagen Entre combustibles fósiles y nuevas tecnologías: el dilema de la energía en el futuro  ](https://universidadeafit.widen.net/content/1c1ebded-1c3c-435f-a47f-270d1aa2a98e/web/energia_descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=R8oIm7Af)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## Entre combustibles fósiles y nuevas tecnologías: el dilema de la energía en el futuro

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/entre-combustibles-fosiles-y-nuevas-tecnologias-el-dilema-de-la-energia-en-el-futuro "Ver noticia")

Agosto 21, 2025

![Image 14: Imagen El riesgo no espera](https://universidadeafit.widen.net/content/c1d89ff9-a8ad-4451-b4cb-a42e52469060/web/medellin_descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=85hQRT7K)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## El riesgo no espera

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/medellin-vivir-al-borde-del-agua "Ver noticia")

Agosto 20, 2025

![Image 15: Imagen Vivir en dos tiempos: el trabajo de reconstrucción de memoria colectiva en Colombia ](https://universidadeafit.widen.net/content/f6a7f203-5417-4ff1-aa21-38db863d5c93/web/manos_plantas-descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=mjSS_XSt)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## Vivir en dos tiempos: el trabajo de reconstrucción de memoria colectiva en Colombia

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/vivir-en-dos-tiempos-el-trabajo-de-reconstruccion-de-memoria-colectiva-en-colombia "Ver noticia")

Agosto 20, 2025

![Image 16: Imagen ¿Está temblando más últimamente? ](https://universidadeafit.widen.net/content/48ad5401-87ae-4713-aed1-78f658feb996/web/sismos.jpg?crop=yes&k=c&w=397&h=250&itok=PTtAv186)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## ¿Está temblando más últimamente?

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/esta-temblando-mas-ultimamente "Ver noticia")

Agosto 20, 2025

![Image 17: Imagen Editorial: El tiempo como herencia y promesa ](https://universidadeafit.widen.net/content/38738d27-a95e-459d-95b8-78ea134792cd/web/tiempo_descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=5dQb0oBv)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## Editorial: El tiempo como herencia y promesa

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/el-tiempo-como-herencia-y-promesa "Ver noticia")

Agosto 20, 2025

![Image 18: Imagen Los tiempos de la ciencia](https://universidadeafit.widen.net/content/e3fa6b9d-5ea7-4e90-957b-7b1f5f0fea88/web/tiempo_ciencia_descubre_crea.jpg?crop=yes&k=c&w=397&h=250&itok=vvctizaT)

[Revista Descubre y Crea](https://www.eafit.edu.co/taxonomy/term/2196)

[Edición 180](https://www.eafit.edu.co/taxonomy/term/3101)

## Los tiempos de la ciencia

[Ver noticia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/los-tiempos-de-la-ciencia "Ver noticia")

Agosto 20, 2025

*   [Página actual 1](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180?label=&page=2 "Ir a la página 3")
*   [Siguiente página](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180?label=&page=1 "Ir a la página siguiente")
*   [Última página](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180?label=&page=2 "Ir a la última página")

![Image 19: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 20: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 21: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 22: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 23: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 24: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 25: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 26: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
