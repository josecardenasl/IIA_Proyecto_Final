Title: Becas y financiación

URL Source: https://www.eafit.edu.co/becas-y-financiacion

Published Time: Thu, 07 May 2026 20:25:31 GMT

Markdown Content:
# Becas y financiación - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/becas-y-financiacion#main-content)

[![Image 10: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 11: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 12: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/becas-y-financiacion#)

[![Image 13: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/becas-y-financiacion# "Spanish")[![Image 14: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/becas-y-financiacion# "English")

*   [Spanish](https://www.eafit.edu.co/becas-y-financiacion)
*   [Inglés](https://www.eafit.edu.co/en/becas-y-financiacion)

 Información para ti

[![Image 15: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 16: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 17: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 18: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 19: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 20: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 21: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 22: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 23: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 24: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 25: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 26: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 27: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 28: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 29: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 30: Imagen de banner tres personas caminando por el campus de la Universidad EAFIT](https://universidadeafit.widen.net/content/a697cb73-ebf5-4462-81ff-efb349111b2b/web/rutas-aprendizaje-educacion-continua.jpg?crop=yes&k=c&w=1920&h=788&itok=iwfFsUz6)

# Becas y financiación de pregrados y posgrados

​Encuentra aquí información sobre diferentes formas de financiación para tu programa.

*   [Inicio](https://www.eafit.edu.co/)
*    Becas y Financiación 

#### **Quiero f​inanciar mi carrera**

Construyamos juntos el camino para lograr tu futuro profesional. En EAFIT, tenemos diferentes opciones de financiación tanto propias como externas, con el fin de entregarte la posibilidad de escoger la opción que mejor se adecúe a tus necesidades.

![Image 31: Imagen Fondo Futuro](https://universidadeafit.widen.net/content/7134708d-0087-4c4d-8669-8cc67bbbead7/web/foto-inicio-permanencia.jpg?crop=yes&k=c&w=397&h=253&itok=Uiu70Lj8)

Fondo Futuro

[Conoce el Fondo Futuro](https://www.eafit.edu.co/becas-y-financiacion/fondo-futuro)

![Image 32: Imagen EAFIT a tu alcance](https://universidadeafit.widen.net/content/6404d4bc-81ca-4de2-91d2-f466a7f8bd55/web/induccion-estudiantes-foraneos-202429.jpg?crop=yes&k=c&w=397&h=253&itok=Npe9-GcX)

EAFIT a tu alcance

[Conoce esta oportunidad](https://www.eafit.edu.co/becas-y-financiacion/eafit-a-tu-alcance)

![Image 33: Imagen Alianza Lumni EAFIT](https://universidadeafit.widen.net/content/513bc898-f8b4-4bdb-9317-4a04e118fc95/web/Foto-estudiantesRegresoclases-022.jpg?crop=yes&k=c&w=397&h=253&itok=7gLDt5kt)

Alianza Lumni EAFIT

[Conoce esta alianza](https://www.eafit.edu.co/becas-y-financiacion/alianzalumnieafit)

![Image 34: Imagen Crédito educativo Sufi a corto plazo y libre](https://universidadeafit.widen.net/content/eeeddbf8-95a6-4b24-a8fd-3552d69ba19d/web/Foto-estudiantesCampusU-051.jpg?crop=yes&k=c&w=397&h=253&itok=xxjMI7Yk)

Crédito educativo Sufi a corto plazo y libre

[Conoce este crédito](https://www.eafit.edu.co/becas-y-financiacion/credito-educativo-sufi-corto-plazo)

![Image 35: Imagen Fo​ndo Sapiencia con recursos de EPM​​](https://universidadeafit.widen.net/content/3064cdde-7777-4185-8ccf-118bfdb30a48/web/induccion-estudiantes-foraneos-2024112.jpg?crop=yes&k=c&w=397&h=253&itok=lmjrtFgR)

Fo​ndo Sapiencia con recursos de EPM​​

[Conoce este fondo](https://universidadeafit.widen.net/s/lkv8bsmptk/fondo-sapiencia-epm-eafit)

![Image 36: Imagen Otras entidades aliadas para financiar tu pregrado](https://universidadeafit.widen.net/content/ca4767ce-1e46-4d22-82f0-dc622fe0b285/web/Foto-estudiantesRegresoclases-020.jpg?crop=yes&k=c&w=397&h=253&itok=sFrPW3L9)

Otras entidades aliadas para financiar tu pregrado

[Descubre las entidades](https://www.eafit.edu.co/directorio-de-entidades-financieras)

Filtros

*   [Estudiante activo de pregrado(14)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_estudiante%3A1351)
*   [Estudiante de primer semestre de pregrado(9)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_estudiante%3A1346)
*   [Estudiante activo de posgrado(5)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_estudiante%3A1356)
*   [Egresados de EAFIT u otras universidades(4)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_estudiante%3A2156)
*   [Estudiante nuevo de posgrado(3)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_estudiante%3A1361)

Facet Tipo de estudiante 

*   [Beca(20)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_beneficio%3A1336)
*   [Financiación(6)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_beneficio%3A1341)

Facet Tipo de beneficio 

*   [Pregrado(18)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_programa_byf%3A1366)
*   [Posgrado(10)](https://www.eafit.edu.co/becas-y-financiacion?f%5B0%5D=tipo_de_programa_byf%3A1371)

Facet Tipo de programa 

![Image 37: Estudiantes-campus-05133](https://universidadeafit.widen.net/content/vwmqeid8k0/web/Estudiantes-campus-05133.jpg?crop=yes&k=c&w=823&h=450&itok=7Cv84_pm)

## EAFIT a tu alcance

Queremos facilitar tu permanencia en la Universidad. Conoce nuestras alternativas de financiación.

[Conoce más información](https://www.eafit.edu.co/becas-y-financiacion/eafit-a-tu-alcance)

![Image 38: Educación Continua EAFIT, banner Rutas de Aprendizaje](https://universidadeafit.widen.net/content/whznn4dahd/web/rutas-aprendizaje-educacion-continua.jpg?crop=yes&k=c&w=823&h=450&itok=JMU8iRRa)

## Crédito educativo Sufi a corto plazo y libre educativo

Sufi te presta para que estudies lo que te apasiona

[Conoce más información](https://www.eafit.edu.co/becas-y-financiacion/credito-educativo-sufi-corto-plazo)

![Image 39: Imagen de Becas Talento](https://universidadeafit.widen.net/content/aobqfayjzq/web/becastalentoeafit-2.jpg?crop=yes&k=c&w=823&h=450&itok=CNstZcQW)

## Becas Talento y Aliados pregrado (Nutresa, Santa Ana, F.E. Suiza y Aurelio Llano)

Si quieres conectar con tu talento, tienes capacidades de liderazgo y excelencia académica, y necesitas apoyo económico para realizar tus estudios de pregrado, puedes acceder a becas que cubren entre el 40% y el 100% del valor de la matrícula del programa. Aquí encontrarás opciones como: las Becas Talento, Nutresa Acceso, Santa Ana, Fundación Educación Suiza y Aurelio Llano. Postúlate a partir del 10 de marzo de 2026.

[Conoce más información](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)

![Image 40: Educación Continua EAFIT, banner Rutas de Aprendizaje](https://universidadeafit.widen.net/content/whznn4dahd/web/rutas-aprendizaje-educacion-continua.jpg?crop=yes&k=c&w=823&h=450&itok=JMU8iRRa)

## Beca Sapiencia mejores bachilleres de Medellín

Aplican los mejores bachilleres en las **Pruebas Saber 11** (Icfes).

[Conoce más información](https://www.eafit.edu.co/becas-y-financiacion/beca-sapiencia-mejores-bachilleres-medellin)

![Image 41: Educación Continua EAFIT, banner Rutas de Aprendizaje](https://universidadeafit.widen.net/content/whznn4dahd/web/rutas-aprendizaje-educacion-continua.jpg?crop=yes&k=c&w=823&h=450&itok=JMU8iRRa)

## ​​Sapiencia B​​ecas mejores Deportistas

Esta beca está dirigida a los deportistas **medallistas** del Municipio de Medellín.

[Conoce más información](https://www.eafit.edu.co/becas-y-financiacion/sapiencia-becas-mejores-deportistas)

![Image 42: Educación Continua EAFIT, banner Rutas de Aprendizaje](https://universidadeafit.widen.net/content/whznn4dahd/web/rutas-aprendizaje-educacion-continua.jpg?crop=yes&k=c&w=823&h=450&itok=JMU8iRRa)

## Beca Fundación Fraternidad - EAFIT

El Fondo Beca cubrirá el**100%** de la matrícula en instituciones de **carácter público.**

[Conoce más información](https://www.eafit.edu.co/becas-y-financiacion/beca-fundacion-fraternidad-eafit)

*   [Página actual 1](https://www.eafit.edu.co/becas-y-financiacion?becas_financiacion=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/becas-y-financiacion?becas_financiacion=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/becas-y-financiacion?becas_financiacion=&page=2 "Ir a la página 3")
*   [Página 4](https://www.eafit.edu.co/becas-y-financiacion?becas_financiacion=&page=3 "Ir a la página 4")
*   [Página 5](https://www.eafit.edu.co/becas-y-financiacion?becas_financiacion=&page=4 "Ir a la página 5")
*   [Siguiente página›](https://www.eafit.edu.co/becas-y-financiacion?becas_financiacion=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/becas-y-financiacion?becas_financiacion=&page=4 "Ir a la última página")

Otras formas de acceder a los programas

## Renovación de Icetex

[Conoce el instructivo](https://universidadeafit.widen.net/s/n7z9bjs9sf/instructivo-renovacion-icetex)

## Descuentos por consanguinidad

[Conoce el descuento](https://universidadeafit.widen.net/s/9sfqvtskfh/descuento-por-consanguinidad)

## Descuentos y convenios de Educación Continua

[Conoce los descuentos](http://portalqa.omega.eafit.edu.co/descuentos-y-convenios)

## Alianzas para el conocimiento

[Conoce las alianzas](https://universidadeafit.widen.net/view/pdf/wvoewvvtpf/alianzas-para-el-conocimiento.pdf?u=mt4aap)

## Estas son las diferentes formas con las que puedes pagar la matrícula

[Conoce las formas de pago](https://universidadeafit.widen.net/s/fzhrqwkdkc/alternativas-de-finanaciacion-y-formas-de-pago)

## Facturación a empresa

[Conoce la facturación](https://universidadeafit.widen.net/s/pzxt8f2qgh/facturacion-a-empresa)

![Image 43: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

Tarifas

## Tarifas de programas de pregrado

[Conoce las tarifas](https://www.eafit.edu.co/tarifas)

## Tarifas de programas de posgrado

[Conoce las tarifas](https://www.eafit.edu.co/tarifas)

## Tarifas generales

[Conoce las tarifas](https://www.eafit.edu.co/tarifas)

![Image 44: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

![Image 45: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 46: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 47: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 48: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 49: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 50: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 51: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 52: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 53](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
