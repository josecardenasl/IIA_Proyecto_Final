Title: fb.svg

URL Source: https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg

Published Time: Wed, 31 Jul 2024 01:05:32 GMT

Markdown Content:
# fb.svg

A 55x48 small image, likely a logo, icon or avatar
