Title: Transferencia de Tecnología y Conocimiento

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento

Markdown Content:
# Transferencia de Tecnología y Conocimiento - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner innovación y desarrollo tecnológico EAFIT](https://universidadeafit.widen.net/content/fe5ac810-8178-4d96-813c-d96f9fe790a2/web/banner-principal-transferencia.jpg?crop=yes&k=c&w=1920&h=788&itok=FMBOnzj3)

# Transferencia de Tecnología y Conocimiento

Servicios para investigadores de EAFIT

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Innovación y Transferencia Tecnológica EAFIT](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
*    Transferencia de Tecnología y Conocimiento 

###### Conecta tu conocimiento con el mundo.

Potenciamos el conocimiento para generar valor, facilitando procesos de desarrollo tecnológico y conexión con los mercados para que tus ideas y soluciones se conviertan en innovaciones con impacto real.

Desde el área de transferencia, te guiamos en el proceso de transferir y comercializar tus resultados de investigación, descubre las herramientas y servicios que te ofrecemos para transferir tu conocimiento.

**¿Tienes una idea con potencial de ser transferida o comercializada?**

**¿Desarrollaste una solución aplicada a algún sector industrial?**

[¡Registra ahora tu idea o solución!](https://forms.office.com/pages/responsepage.aspx?id=XrX3mb6ce0aBQ5GXgpGK-98rZzYqwfRAmbEtxiBvg55URjM0TFkxUVNPNTNFWTcwTU1BUEdYRTNJTi4u&route=shorturl)

## Identificación del potencial de transferencia

A partir del potencial de mercado y la inclusión de tu solución en el portafolio de tecnologías de la Universidad, te brindamos apoyo personalizado en cada etapa

![Image 22: Imagen Identificación del potencial de transferencia](https://universidadeafit.widen.net/content/7df5b46c-fa5b-42ea-bf8f-40d1468aeb5a/web/servicio-1-identificacion-potencial.jpg)

[Mecanismo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-1435553095)

Mecanismo

###### Selección del mecanismo de transferencia

Evaluamos las características de tu innovación, como su nivel de desarrollo y su potencial de protección, para determinar la mejor estrategia de transferencia. Exploramos contigo los diferentes mecanismos y definimos la ruta más adecuada para que tu tecnología llegue al mercado y genere impacto.

[Propuesta](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-1906593525)

Propuesta

###### Validación de la propuesta de valor y diferencial

Te ayudamos a definir claramente los beneficios que tu tecnología ofrece y cómo se diferencia de las soluciones existentes. Trabajamos en la construcción de un mensaje contundente que comunique el valor de tu innovación a potenciales socios o inversionistas.

[Tendencia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-2633846104)

Tendencia

###### Rastreo de mercado e identificación de tendencias

Investigamos el mercado relevante para tu tecnología, identificando las necesidades, tendencias y competencia. Te ayudamos a definir el público objetivo al que se dirige tu innovación y facilitamos la conexión con empresas, inversionistas y otros actores clave en el sector.

## Convocatoria de alistamiento tecnológico

¿Tienes una solución con potencial validado, en una etapa temprana de desarrollo?

 Trabajemos en conjunto en una validación precomercial, al tiempo en que se perfecciona técnicamente la solución. Si eres beneficiado de la convocatoria, recibirás apoyo con

[Conoce la convocatoria de alistamiento tecnológico](https://www.eafit.edu.co/transferencia-tecnologia-y-conocimiento/3a-convocatoria-interna-alistamiento-tecnologico)

![Image 23: Imagen Convocatoria de alistamiento tecnológico](https://universidadeafit.widen.net/content/3c0eea41-5bcc-4cab-b090-98671da6bbc6/web/servicio-2-convocatoria-alistamiento.jpg)

[Estratégica](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-1097146838)

Estratégica

###### Planeación estratégica de negocio

Definimos la hoja de ruta para llevar tu solución al mercado. Analizamos tu modelo de negocio, identificamos tus clientes potenciales, definimos tu propuesta de valor y establecemos una estrategia de comercialización. Te ayudamos a construir un plan sólido que te permita alcanzar tus objetivos comerciales.

[Aliados](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-1023209901)

Aliados

###### Identificación de aliados y proveedores estratégicos

Te conectamos con los actores clave que necesitas para impulsar tu solución. Identificamos posibles aliados que complementen tus capacidades, así como proveedores que te brinden los insumos o servicios necesarios.

[Desarrollo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-2664354077)

Desarrollo

###### Avance en la etapa de desarrollo TRL – BRL

Te ayudamos a alcanzar el nivel de madurez necesario para comercializar tu solución. Recibe asesoría técnica, accede a infraestructura y conéctate con expertos que te ayuden a superar los retos técnicos y avanzar en la escala TRL y BRL.

## Conexión con los mercados

Impulsamos la visibilidad y el alcance de tu tecnología. Juntos, abordaremos el relacionamiento comercial para que tu innovación llegue al mercado de forma efectiva. Al ser parte de nuestro portafolio, tendrás acceso a

![Image 24: Imagen Conexión con los mercados](https://universidadeafit.widen.net/content/7ca23f07-dc76-4daa-98ef-a4b6be88dedd/web/servicio-3-conexion-mercados.jpg)

[Micrositio](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-3081935451)

Micrositio

###### Publicación de micrositio exclusivo de la tecnología

Daremos a conocer tu tecnología a través de un micrositio web dedicado, con información detallada sobre sus características, beneficios y aplicaciones. Este espacio te permitirá mostrar tu innovación al mundo y conectar con potenciales interesados.

[Herramientas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-1285153789)

Herramientas

###### Diseño de kit de herramientas comerciales

Te proporcionamos un conjunto de herramientas de marketing para promocionar tu tecnología. Estos materiales te ayudarán a comunicar el valor de tu innovación de forma clara y atractiva.

[Escalamiento](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-3200477448)

Escalamiento

###### Contacto y reuniones con aliados para escalamiento o comercialización

Facilitamos el contacto con empresas, inversionistas y otros actores clave en tu sector que puedan estar interesados en tu tecnología. Te ayudaremos a establecer relaciones estratégicas que impulsen el escalamiento y la comercialización de tu innovación.

[Negociación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento#4257225834-3529288499)

Negociación

###### Acompañamiento en procesos de negociación

Acompañamos todo el proceso de negociación, brindándote nuestra experiencia y las herramientas necesarias para que puedas presentar tu tecnología con seguridad, definir la mejor estrategia y alcanzar acuerdos exitosos que impulsen la transferencia de tu conocimiento.

Mecanismos de transferencia de tecnología

![Image 25: Imagen Explotación directa](https://universidadeafit.widen.net/content/5d16a018-db0e-4119-a2f7-bb67b28d9eaa/web/card-1-explotacion-directa.jpg?crop=yes&k=c&w=397&h=253&itok=pbcfsm4C)

Explotación directa

Venta de productos y servicios derivados de las actividades de investigación y desarrollo (I+D) de la universidad.

![Image 26: Imagen Licenciamiento de tecnologías](https://universidadeafit.widen.net/content/aad83363-3029-4daf-aa04-416bb316cd33/web/card-2-licenciamiento-tecnologias.jpg?crop=yes&k=c&w=397&h=253&itok=s4ydF80U)

Licenciamiento de tecnologías

Acuerdo mediante el cual la universidad otorga a un tercero el derecho de explotar o comercializar su propiedad intelectual, como patentes, marcas, franquicias o secretos industriales.

![Image 27: Imagen Venta de tecnología](https://universidadeafit.widen.net/content/1690f999-a346-4b7e-ade2-a65d79f3fc04/web/card-3-venta-tecnologia.jpg?crop=yes&k=c&w=397&h=253&itok=gqEGjKKN)

Venta de tecnología

Transferencia o cesión definitiva de la propiedad intelectual, a cambio de una compensación económica para el titular de la tecnología.

![Image 28: Imagen Productos de conocimiento](https://universidadeafit.widen.net/content/ab962a1d-f6ec-49e5-9a74-5f0579054d2a/web/card-4-productos-conocimiento.jpg?crop=yes&k=c&w=397&h=253&itok=Q6ke_AJL)

Productos de conocimiento

Consultorías y servicios especializados basados en el conocimiento generado por la universidad.

![Image 29: Imagen Liberación de tecnologías](https://universidadeafit.widen.net/content/de7c61e0-d6eb-4411-a380-008c9a4a752c/web/card-5-liberacion-tecnologias.jpg?crop=yes&k=c&w=397&h=253&itok=6mgSN8_P)

Liberación de tecnologías

Tecnologías con un enfoque social liberadas para uso público: software libre, patentes en dominio público, metodologías y modelos compartidos.

## Portafolio de tecnologías

Conoce las soluciones de EAFIT que están transformando el entorno social y empresarial.

[Conoce nuestro portafolio de tecnologías](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias)

![Image 30: Imagen Portafolio de tecnologías](https://universidadeafit.widen.net/content/defc389f-4703-4fb6-8e9d-b63728fb403d/web/portafolio-tecnologias.jpg?crop=yes&k=c&w=463&h=450&itok=FAVAb5Qc)

#### **Únete a nuestra red en LinkedIn**

Descubre cómo el conocimiento de EAFIT se convierte en acciones que transforman realidades desde la ciencia, la tecnología y la innovación.

[Únete a nuestra red](https://www.linkedin.com/showcase/innovaci%C3%B3n-eafit)

[![Image 31: Imagen de mujer con micrófono en la mano sonriendo y otras mujeres adicionales](https://universidadeafit.widen.net/content/f67fc677-626c-48d2-839b-df58fba144f9/web/banner-redes-sociales-tecnologias.jpg?crop=yes&k=c&w=570&h=216&itok=JRvuo7eb)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento)

![Image 32](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/transferencia-tecnologia-y-conocimiento)

![Image 33: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 34: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 35: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 36: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 37: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 38: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 39: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 40: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 43](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
