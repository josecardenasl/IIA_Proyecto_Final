Title: Historia de EAFIT

URL Source: https://www.eafit.edu.co/institucional/historia

Markdown Content:
# Historia de EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/institucional/historia#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/historia#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/historia# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/institucional/historia# "English")

 Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 8: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 9: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 10: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 11: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 12: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 14: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 15: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 16: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 17: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 18: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 19: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 20: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 21: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 22: Imagen de banner eventos educacion contiua ](https://universidadeafit.widen.net/content/55d12337-e523-496e-9032-53a721114499/web/eventos-educacion-continua.jpg?crop=yes&k=c&w=1920&h=788&itok=ZRAUE9cB)

# Historia de EAFIT

​EAFIT, una histo​​ria que tejem​​os con nuestra comunidad de talento y organizaciones aliadas​.

*   [Inicio](https://www.eafit.edu.co/)
*   [Información Institucional](https://www.eafit.edu.co/institucional)
*    Historia de EAFIT 

Un grupo de visionarios, líderes de empresas, se reunieron en las oficinas de la Asociación Nacional de Industriales, en el centro de esa Medellín industrial que experimentaba un crecimiento inusitado en varios frentes. Con los Estatutos de la Fundación, diligenciados en máquina de escribir el 4 de mayo de 1960, comenzó la historia de la entonces Escuela de Administración y Finanzas, hoy Universidad EAFIT.​​​

##### Los primeros protagonistas y quienes siguieron su legado de liderazgo​

## Funda​dores

Desde grandes empresarios, preocupados por el avance de la educación en Medellín, nace la idea de una escuela para la formación de los administradores del patrimonio público y económico del país y de la región antioqueña.​

[Conoce fundadores](https://www.eafit.edu.co/institucional/historia/fundadores)

## Rect​ores

Detrás de cada hecho en la historia de la Universidad hay 11 hombres y 1 una mujer que han liderado la Institución para cumplir nuestro propósito de inspirar vidas, crear conocimiento y transformar sociedad.​

[Conoce rectores](https://www.eafit.edu.co/institucional/historia/rectores)

### Un álbum para nun​​​ca olvidar​

[![Image 23: Imagen de un Grupo de personas](https://universidadeafit.widen.net/content/0293bdae-fe32-4d02-995c-36e50dba79ae/web/foto-panoramica.jpg?crop=yes&w=768&h=512&itok=Cjo2ngTl)](https://www.eafit.edu.co/institucional/historia)

![Image 24](https://www.eafit.edu.co/institucional/historia)

[![Image 25: Imagen de Frente de casa con placa de EAFIT](https://universidadeafit.widen.net/content/c2655d63-4de6-423c-9bfe-5a77adb1d6f8/web/placa.jpg?crop=yes&w=768&h=512&itok=ETqd5koh)](https://www.eafit.edu.co/institucional/historia)

![Image 26](https://www.eafit.edu.co/institucional/historia)

[![Image 27: Imagen de los primeros edificios de EAFIT](https://universidadeafit.widen.net/content/5f069b57-422e-43dc-8c8b-c7f9797fd9dc/web/universidad-antes.jpg?crop=yes&w=768&h=512&itok=hfsiDhT7)](https://www.eafit.edu.co/institucional/historia)

![Image 28](https://www.eafit.edu.co/institucional/historia)

[![Image 29: Imagen del Antiguo parqueadero de EAFIT](https://universidadeafit.widen.net/content/cd984c2b-81e5-4ff4-a084-3bf149fd22f8/web/carros-antiguos.jpg?crop=yes&w=768&h=512&itok=sOV2DPrn)](https://www.eafit.edu.co/institucional/historia)

![Image 30](https://www.eafit.edu.co/institucional/historia)

[![Image 31: Imagen de Aula antigua de EAFIT, fotográfia a blanco y negro.](https://universidadeafit.widen.net/content/65f9d0fd-2eec-4818-a072-0789430e4398/web/tablero.jpg?crop=yes&w=768&h=512&itok=tXA7ieZm)](https://www.eafit.edu.co/institucional/historia)

![Image 32](https://www.eafit.edu.co/institucional/historia)

[![Image 33: Imagen de un Periódico antiguo anunciando la inauguración de la Escuela de Administración y Finanzas](https://universidadeafit.widen.net/content/1649ab07-fc03-4158-8e05-8c4e19227923/web/periodico.jpg?crop=yes&w=768&h=512&itok=TxVJ_SpV)](https://www.eafit.edu.co/institucional/historia)

![Image 34](https://www.eafit.edu.co/institucional/historia)

[![Image 35: Imagen de graduados en ceremonia](https://universidadeafit.widen.net/content/00be1e22-0b71-41e0-b812-a81ec877aad7/web/grados.jpg?crop=yes&w=768&h=512&itok=0kWDDeUD)](https://www.eafit.edu.co/institucional/historia)

![Image 36](https://www.eafit.edu.co/institucional/historia)

[![Image 37: Imagen de una panorámica de la ciudad de Medellín](https://universidadeafit.widen.net/content/6e326504-ab94-4bb2-bf5e-02db8d2bdb6a/web/ciudad.jpg?crop=yes&w=768&h=512&itok=w80_jbPP)](https://www.eafit.edu.co/institucional/historia)

![Image 38](https://www.eafit.edu.co/institucional/historia)

[![Image 39: Imagen de participantes de evento, imagen antigua a blanco y negro](https://universidadeafit.widen.net/content/8ceaca19-584a-4e50-8611-8e690f8c848f/web/foto-antigua.jpg?crop=yes&w=768&h=512&itok=-ppb0VKi)](https://www.eafit.edu.co/institucional/historia)

![Image 40](https://www.eafit.edu.co/institucional/historia)

[![Image 41: Imagen antigua a blanco y negro de ceremonia de grados](https://universidadeafit.widen.net/content/cb83c305-267f-4728-8571-3266334997d1/web/foto-grados.jpg?crop=yes&w=768&h=512&itok=KTznZKOn)](https://www.eafit.edu.co/institucional/historia)

![Image 42](https://www.eafit.edu.co/institucional/historia)

[![Image 43: Imagen de panorámica de campus universitario en sus inicios](https://universidadeafit.widen.net/content/eb0b38eb-74d9-42d3-834f-6e337909fe99/web/terreno-universidad.jpg?crop=yes&w=768&h=512&itok=L8YzW9gd)](https://www.eafit.edu.co/institucional/historia)

![Image 44](https://www.eafit.edu.co/institucional/historia)

[![Image 45: Imagen de un aula de computadores](https://universidadeafit.widen.net/content/84b2127c-7c5b-478e-94a6-8b58de1e543d/web/computadores.jpg?crop=yes&w=768&h=512&itok=MWVFOeR0)](https://www.eafit.edu.co/institucional/historia)

![Image 46](https://www.eafit.edu.co/institucional/historia)

[![Image 47: Imagen de la antigua entrada a la Universidad](https://universidadeafit.widen.net/content/c7af75d1-24dc-4635-83b1-3b526c412d19/web/entrada-universidad.jpg?crop=yes&w=768&h=512&itok=jncP48uS)](https://www.eafit.edu.co/institucional/historia)

![Image 48](https://www.eafit.edu.co/institucional/historia)

[![Image 49: Imagen de panorámica de la Universidad en sus inicios](https://universidadeafit.widen.net/content/4684d3f9-f60a-4d59-8be3-70f05f60b6f8/web/panoramica-universidad.jpg?crop=yes&w=768&h=512&itok=8pxpvU8i)](https://www.eafit.edu.co/institucional/historia)

![Image 50](https://www.eafit.edu.co/institucional/historia)

[![Image 51: Imagen antigua a blanco y negro de estudiantes](https://universidadeafit.widen.net/content/52a9e06d-b3bd-4007-8e68-5c77bd636ad4/web/estudiantes.jpg?crop=yes&w=768&h=512&itok=vCPCepBP)](https://www.eafit.edu.co/institucional/historia)

![Image 52](https://www.eafit.edu.co/institucional/historia)

[![Image 53: Imagen de la reunión con orquesta](https://universidadeafit.widen.net/content/203d0c2c-453c-47d3-9bfb-1d305ae6b087/web/charla-orquesta.jpg?crop=yes&w=768&h=512&itok=MlVcCOvJ)](https://www.eafit.edu.co/institucional/historia)

![Image 54](https://www.eafit.edu.co/institucional/historia)

[![Image 55: Imagen de asistentes a evento en el campus universitario](https://universidadeafit.widen.net/content/108a388a-ba1c-4527-baa7-36cea70ba6ad/web/evento.jpg?crop=yes&w=768&h=512&itok=TeKKIevb)](https://www.eafit.edu.co/institucional/historia)

![Image 56](https://www.eafit.edu.co/institucional/historia)

[![Image 57: Imagen de la construcción del bloque de la biblioteca](https://universidadeafit.widen.net/content/282a64a6-158a-4e63-99b5-e658db2470a1/web/construccion.jpg?crop=yes&w=768&h=512&itok=DIM8hm37)](https://www.eafit.edu.co/institucional/historia)

![Image 58](https://www.eafit.edu.co/institucional/historia)

[![Image 59: Imagen del corte de cinta durante inauguración](https://universidadeafit.widen.net/content/01943504-24a9-4c91-b916-87d41582d262/web/inaguracion.jpg?crop=yes&w=768&h=512&itok=9wQjP6PA)](https://www.eafit.edu.co/institucional/historia)

![Image 60](https://www.eafit.edu.co/institucional/historia)

[![Image 61: Imagen antigua a blanco y negro del lote en el que está actualmente la Universidad](https://universidadeafit.widen.net/content/0ee537a2-a662-444b-b437-7f205bae5af1/web/panoramica-terreno.jpg?crop=yes&w=768&h=512&itok=aOIhe5ly)](https://www.eafit.edu.co/institucional/historia)

![Image 62](https://www.eafit.edu.co/institucional/historia)

[![Image 63: Imagen de los Inicios de la cafetería](https://universidadeafit.widen.net/content/70b9bc28-02f5-4af2-bdc1-333200fa4466/web/quiosco.jpg?crop=yes&w=768&h=512&itok=X1ii8pbv)](https://www.eafit.edu.co/institucional/historia)

![Image 64](https://www.eafit.edu.co/institucional/historia)

[![Image 65: Imagen de una presentación en proyector](https://universidadeafit.widen.net/content/2d3ebc91-18ed-4984-ba08-3e11f17be61d/web/proyector.jpg?crop=yes&w=768&h=512&itok=BsV5Q4ra)](https://www.eafit.edu.co/institucional/historia)

![Image 66](https://www.eafit.edu.co/institucional/historia)

[![Image 67: Imagen de la orquesta musical](https://universidadeafit.widen.net/content/1ab6dac4-f524-4e8d-8843-a160c2cdc597/web/orquesta-musica.jpg?crop=yes&w=768&h=512&itok=VTfOvhj-)](https://www.eafit.edu.co/institucional/historia)

![Image 68](https://www.eafit.edu.co/institucional/historia)

[![Image 69: Imagen de una prueba con maquinaria](https://universidadeafit.widen.net/content/a780572a-e2bf-4b0a-8621-2acd37d5aae8/web/80-historicas-escuela.jpg?crop=yes&w=768&h=512&itok=wd0CRXqv)](https://www.eafit.edu.co/institucional/historia)

![Image 70](https://www.eafit.edu.co/institucional/historia)

### Década de 1960

[Ver década](https://www.eafit.edu.co/institucional/historia/decada-1960)

### Década de 1970

[Ver década](https://www.eafit.edu.co/institucional/historia/decada-de-1970)

### Década de 1980

[Ver década](https://www.eafit.edu.co/institucional/historia/decada-1980)

### Década de 1990

[Ver década](https://www.eafit.edu.co/institucional/historia/decada-1990)

### Década de 2000

[Ver década](https://www.eafit.edu.co/institucional/historias/decada-2000)

### Década de 2010

[Ver década](https://www.eafit.edu.co/institucional/historia/decada-2010)

### Década de 2020

[Ver década](https://www.eafit.edu.co/institucional/historia/decada-2020)

#### ...Y se vive en el territorio

En 2020, cuando conmemoramos 60 años, hicimos un recorrido por la transformación urbana que ha tenido el sector de La Aguacatala, en el sur de Medellín, durante las seis primeras décadas de historia de la Universidad. Este camino, que se reconstruyó con el tesroro documental y el trabajo la Sala de Patrimonio Documental de la Biblioteca, Urbam y el Departamento de Comunicación, inicia en la configuración del municipio de Medellín y recorre los momentos en los que EAFIT nace y teje un territorio lleno de vidas e historias.​

###### Conmemoración de nuestros aniversarios

## ​En 2015 celebramos nuestros 55 años

[Ver 55 años](https://www.eafit.edu.co/institucional/historia/55-anos)

## En 2020 celebramos nuestros 60 años

[Ver 60 años](https://www.eafit.edu.co/institucional/historia/60)

![Image 71: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

![Image 72: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 73: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 74: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 75: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 76: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 77: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 78: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 79: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 82](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
