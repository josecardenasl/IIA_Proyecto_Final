Title: Campoenjuegofoto%20(4).jpg

URL Source: https://www.eafit.edu.co/sites/default/files/2026-04/Campoenjuegofoto%20(4).jpg

Published Time: Tue, 14 Apr 2026 22:19:29 GMT

Markdown Content:
# Campoenjuegofoto%20(4).jpg

a line of balls positioned next to a wall and floor
