Title: Escuela Derecho

URL Source: https://www.eafit.edu.co/escuela-derecho

Markdown Content:
# Escuela Derecho - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/escuela-derecho#main-content)

[![Image 43: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 44: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-derecho#)

[![Image 45: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-derecho# "Spanish")[![Image 46: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/escuela-derecho# "English")

*   [Spanish](https://www.eafit.edu.co/escuela-derecho)
*   [Inglés](https://www.eafit.edu.co/en/escuela-derecho)

 Información para ti

[![Image 47: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 48: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 49: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 50: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 51: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 52: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 53: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 54: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 55: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 56: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 57: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 58: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 59: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 60: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 61: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 62: Imagen de banner estudiantes de derecho](https://universidadeafit.widen.net/content/ab1104e8-e66b-457c-8f7a-3af8ea353fd7/web/pregrado-derecho-13.jpg?crop=yes&k=c&w=1920&h=788&itok=ijoRQ6vm)

# Escuela de Derecho

Si te interesan temas como la desigualdad, la regulación de negocios y empresas, los derechos humanos, la crisis climática, cómo funciona el Estado, los problemas del país, la región o el mundo, los asuntos relacionados con la legislación de las organizaciones o de la tecnología, y las reflexiones sobre qué es el poder, este es el lugar donde a diario se conversa y aprende con excelencia sobre ello.

 O a lo mejor simplemente te preguntas si hay maneras de apoyar desde las normas la mejora de procesos gerenciales, de ventas o comerciales, o las relaciones entre unas y otras comunidades o países; o si una sociedad que todas en el noticiero o las redes prueba ser injusta puede transformarse. Bien, tal vez acá no aprenderás a cambiar por completo el mundo, pero sí conseguirás una visión que te permitirá transformar empresas, emprendimientos, gobiernos y la vida de muchas personas.

*   [Inicio](https://www.eafit.edu.co/)
*    Escuela Derecho 

Filtros

*   [Posgrados(13)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=tipo_de_programa_derecho%3Aposgrados)
*   [Pregrados(1)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=tipo_de_programa_derecho%3Apregrados)

Facet Tipo de programa derecho 

*   [Derecho(5)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=area_de_conocimiento_pre_pos_derecho%3A1551)
*   [Derecho empresarial comercial(2)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=area_de_conocimiento_pre_pos_derecho%3A1566)
*   [Derecho penal(2)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=area_de_conocimiento_pre_pos_derecho%3A1576)
*   [Derecho privado(2)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=area_de_conocimiento_pre_pos_derecho%3A1581)
*   [Derecho público(2)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=area_de_conocimiento_pre_pos_derecho%3A1556)
*   [Derecho laboral(1)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=area_de_conocimiento_pre_pos_derecho%3A1571)

Facet Área de conocimiento pre pos derecho 

*   [Presencial(14)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=modalidad_pre_pos_derecho%3A101)

Facet Modalidad pre pos derecho 

*   [Medellín(14)](https://www.eafit.edu.co/escuela-derecho?f%5B0%5D=sedes_pre_pos_derecho%3A121)

Facet Sedes pre pos derecho 

#### Doctorado en Derecho

![Image 63: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

8 semestres

![Image 64: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 65: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Depende de la programación académica semestral 

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español (con requisito de lectura en inglés o idioma franco, nivel B1 para graduarse)

![Image 67: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 68: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 118215

![Image 69: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$117.000.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-derecho/doctorado-en-derecho "Ver posgrado")

#### Especialización en Derecho de las Familias

![Image 70: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 71: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 72: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Martes - Viernes 

Más información

En modalidad híbrida, las materias virtuales tendrán sesiones asincrónicas sin horario y sesiones sincrónicas dos veces por semana, de 1.5 horas cada una. Las materias presenciales iniciarán con clases intensivas la primera semana (martes a viernes, de 8:00 a.m. a 1:00 p.m. y de 2:00 p.m. a 6:00 p.m.). Durante las semanas 2, 3 y 4 se trabajará de forma sincrónica y asincrónica, con evaluaciones según el horario acordado con el profesor.

![Image 73: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 74: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Híbrida

![Image 75: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 118146

![Image 76: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

 $23.808.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-derecho/especializacion-en-derecho-de-las-familias "Ver posgrado")

#### Especialización en Derecho del Trabajo y de la Seguridad Social

![Image 77: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 78: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 79: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y Sábado - Martes y jueves

Más información

Viernes 8:00 -12:00 /14:00 - 18:00 y Sábado: 8:00 - 12:00 (cada tres semanas) Martes y jueves 18:00 a 21:00 en las demás semanas 

![Image 80: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 81: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 82: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 83: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$25.440.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-derecho/especializacion-en-derecho-del-trabajo-y-de-la-seguridad-social "Ver posgrado")

#### Especialización en Derecho Contractual

![Image 84: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 85: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 86: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Lunes, Martes, Miércoles y jueves 

Más información

Martes, miércoles, jueves de 5:00 a 8:00 p. m.

 Algunas materias asistidas por tecnología: lunes, martes y miércoles 6:00 a 8:00 p. m. por Teams y los jueves (presencial) 5:00 a 8:00 p. m., pero se informan previamente.

![Image 87: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 88: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 89: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 118233

[Ver opciones de financiación](https://www.eafit.edu.co/node/251)

![Image 90: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$24.931.200

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-derecho/especializacion-en-derecho-contractual "Ver posgrado")

#### Maestría en Estudios Jurídicos

![Image 91: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

4 semestres

![Image 92: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 93: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Martes, jueves, Miércoles, viernes y sábado.

Más información

Los horarios pueden variar dependiendo de las áreas de fundamentación y profundización elegidas por el estudiante:

 Maestría en Derecho: martes a jueves 6:00 p. m.- 9:00 p. m. Eventualmente las clases se podrán dictar los viernes de 6:00 p. m. a 9:00 p. m. y los sábados 8:00 a. m. a 1:00 p. m.

 Maestría en Derecho Penal: miércoles 5:00 p. m.- 9:00 p. m. jueves y viernes 8:00 a. m.- 6:00 p. m., sábados 8:00 a. m.-12:00 m. El horario corresponde a un encuentro mensual.

![Image 94: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 95: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 96: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 116162

![Image 97: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$51.994.517

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-derecho/maestria-estudios-juridicos "Ver posgrado")

#### Maestría en Derecho

![Image 98: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

4 semestres

![Image 99: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar 

Medellín

![Image 100: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Martes, Miércoles y Jueves

Más información

Martes, Miércoles y Jueves de 6:00 p.m. a 9:00 p.m.

 Algunas materias de investigación y e​lectivas, podrán programarse martes, miércoles y jueves de 6 a.m. a 9 a.m.

![Image 101: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 102: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 103: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

 SNIES

 SNIES 102673

![Image 104: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$54.861.956

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-derecho/maestria-derecho "Ver posgrado")

*   [Página actual 1](https://www.eafit.edu.co/escuela-derecho?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/escuela-derecho?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/escuela-derecho?label=&page=2 "Ir a la página 3")
*   [Siguiente página›](https://www.eafit.edu.co/escuela-derecho?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/escuela-derecho?label=&page=2 "Ir a la última página")

## Contenidos diferenciales de la escuela

[Calidad y excelencia](https://www.eafit.edu.co/escuela-derecho#4257225834-3752455394)

Calidad y excelencia

**Somos top en Colombia**

Nuestra Escuela es la mejor en Derecho de Antioquia, de acuerdo con las pruebas Saber Pro. Como pregrado, estamos en el top 5 de las mejores universidades del país según la misma fuente.

El pregrado recibió la reacreditación en Alta Calidad, esta vez por 8 años, un sello de confianza que les permite a nuestros estudiantes tener acceso a becas, incentivos y créditos condonables. También les da prelación en convocatorias gubernamentales.

**Nos respalda la experiencia y la tradición**

Contamos con 25 años de trayectoria en la formación de abogados integrales que trabajan en campos tan diversos como mercantil, bursátil, digital o penal.

[Campus transformador](https://www.eafit.edu.co/escuela-derecho#4257225834-846705913)

Campus transformador

**Nos respalda un ecosistema de aprendizaje y práctica**

Contamos con un consultorio jurídico con asesoría gratuita para personas naturales en situación de vulnerabilidad de los estratos 1, 2 y 3.

Nuestra sala de audiencias dentro del campus es escenario de importantes discusiones; entre 2006 y 2023 tuvimos 1.215 audiencias de conciliación.

El Ágora, un oasis dentro de la Universidad, es el espacio indicado para la reflexión y las conversaciones.Nuestra Biblioteca aloja casi 20.000 documentos especializados entre libros, enciclopedias, manuales, vídeos, revistas y proyectos de grado de diversas áreas del Derecho.

**Tenemos una agenda cultural y académica activa**

Lo mejor de la academia, las discusiones y análisis de coyuntura, la ciencia y la cultura convergen en EAFIT.

**Tenemos proyección y presencia nacional**

Nuestra Universidad cuenta con sedes en Bogotá y Pereira. Ha operado y acompañado proyectos de diversa índole en el territorio nacional.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de Ciudades Universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de Ciudades del Aprendizaje. Cada año, EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

[Aprendizaje vivo y activo](https://www.eafit.edu.co/escuela-derecho#4257225834-3712254004)

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

En este programa, cada persona tiene la libertad para configurar 24 créditos según sus intereses, incluyendo contenidos de las cinco escuelas de la Universidad y de sus áreas de conocimiento.

Se aprende desde la experiencia con retos y con la exposición a problemas y procesos reales.

[Innovación y liderazgo](https://www.eafit.edu.co/escuela-derecho#4257225834-69781854)

Innovación y liderazgo

**Somos innovación en educación**

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes están continuamente expuestos a conversaciones y procesos con casos reales y con los graduados. También reciben una formación multidisciplinaria gracias a las cinco escuelas de EAFIT y las áreas de conocimiento que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

Contamos con 40 grupos de investigación y más de 100 semilleros para el aprendizaje y crecimiento de los estudiantes.

En EAFIT tenemos 14 grupos estudiantiles, con más de 1.500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.

[Conexiones e incidencia](https://www.eafit.edu.co/escuela-derecho#4257225834-2714567932)

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Contamos con centro de estudios e incidencia, Valor Público, y con un espacio de innovación y desarrollo social: EAFIT Social.

Nuestros profesores están conectados con las organizaciones, la investigación y las mejores universidades del mundo. También están al tanto de los problemas que afectan a nuestra sociedad. Tenemos conexión permanente con las empresas y los territorios.

En nuestra escuela, nos proyectamos a la sociedad a través de la revista académica Nuevo Foro Penal, de la colección [Justicia y Conflicto](https://libreriasiglo.com/editoriales/siglo-editorial/colecciones/justicia-y-conflicto), de la publicación de obras académicas con la Editorial EAFIT y de la función social realizada por el [consultorio jurídico](https://www.eafit.edu.co/consultorio-juridico) y su [centro de conciliación](https://www.eafit.edu.co/centro-de-conciliacion).

Contamos con el Centro de estudio e incidencia Valor público, donde nos preocupamos por entender los problemas presentes y futuros en materia de política pública, seguridad, impacto social, entre otros.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que realizan intercambios al exterior, y programas de intercambio profesoral e investigativo.

Ofrecemos la posibilidad de realizar prácticas profesionales dentro y fuera de Colombia.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrado han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores start-ups de Colombia.

Áreas de conocimiento

## Derecho

## Derecho Público

## Derecho y Economía

## Derecho Empresarial Comercial

## Derecho Laboral

## Derecho Penal

## Derecho Privado

## Derecho Procesal

![Image 105: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Consultorio Jurídico

El Consultorio Jurídico cuenta con asesoría jurídica en todas las áreas del Derecho: Civil, Familia, Comercial, Penal, Laboral y Público.

[Ver Consultorio Jurídico](https://www.eafit.edu.co/consultorio-juridico)

## Profesores

Explora el directorio de docentes investigadores EAFIT: líderes en investigación y transformación del conocimiento.

[Ver profesores de Derecho](https://www.eafit.edu.co/profesores?f[0]=escuelas_profesores%3A346)

### **Noticias**

![Image 106: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=397&h=250&itok=MKSJ4A11)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 107: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=397&h=250&itok=Ai1Iyv7S)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

![Image 108: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=397&h=250&itok=jKshJMEj)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-laboratorio-vivo-para-aprender-haciendo "Ver noticia")

Marzo 12, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias)

![Image 109: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 110: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 111: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 112: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 113: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 114: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 115: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 116: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
