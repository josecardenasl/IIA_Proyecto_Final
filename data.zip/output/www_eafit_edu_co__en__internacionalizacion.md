Title: Internationalization

URL Source: https://www.eafit.edu.co/en/internacionalizacion

Markdown Content:
# Internacionalización - EAFIT
[Skip to main content](https://www.eafit.edu.co/en/internacionalizacion#main-content)

[![Image 4: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 5: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/internacionalizacion#)

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/internacionalizacion# "Spanish")[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/en/internacionalizacion# "English")

*   [Spanish](https://www.eafit.edu.co/internacionalizacion)
*   [Inglés](https://www.eafit.edu.co/en/internacionalizacion)

 Información para ti

[![Image 9: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 10: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 11: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 12: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 13: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 14: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Search 

Búsqueda

Menú

Información para ti

[![Image 15: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/en/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/en/node/42116)
    *   [Vida en el campus](https://www.eafit.edu.co/en/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/en/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/en/node/45896)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/en/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/en/node/45926)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/en/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/en/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/en/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/en/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/en/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/en/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/en/registrars-office)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/en/node/31081)
    *   [Cultura CTeI](https://www.eafit.edu.co/en/node/31171)
    *   [Formación](https://www.eafit.edu.co/en/node/31201)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/en/node/39301)
    *   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/en/node/30186)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/en/node/29776)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Transforma con nosotros](https://www.eafit.edu.co/en/node/43361)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/en/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/en/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/en/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/en/node/1151)
    *   [Intercambios nacionales](https://www.eafit.edu.co/en/node/1146)
    *   [Convenios](https://www.eafit.edu.co/en/node/1111)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/en/node/16436)
    *   [Misiones internacionales](https://www.eafit.edu.co/en/node/1136)
    *   [Aprendizaje global](https://www.eafit.edu.co/en/node/1131)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/en/node/45976)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/en/node/43446)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/en/node/47981)
    *   [Centro de artes](https://www.eafit.edu.co/en/node/47976)
    *   [Sala patrimonial](https://www.eafit.edu.co/en/node/39836)
    *   [Bienestar universitario](https://www.eafit.edu.co/en/bienestar)
    *   [Salud mental](https://www.eafit.edu.co/en/node/45826)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/en/node/38366)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/en/node/38196)
    *   [Sala de prensa](https://www.eafit.edu.co/en/node/38391)
    *   [Agenda y eventos](https://www.eafit.edu.co/en/node/18151)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 16: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 17: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 18: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 19: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 20: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 21: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 22: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 23: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 24: Jóvenes estudiantes caminando por el campus de la Universidad EAFIT](https://universidadeafit.widen.net/content/cfa60993-ead8-4c4e-82b8-6ed8656d705f/web/Banner-Home.jpg?crop=yes&k=c&w=1920&h=788&itok=VnbZmfNs)

# Internacionalización

Como parte de la Vicerrectoría de Aprendizaje, Internacionalización EAFIT desarrolla relaciones internacionales y construye capacidades transversales en la Universidad, generando experiencias para la comunidad eafitense. Dichas experiencias tienen como objetivo el desarrollo de una visión global y competencias interculturales que faciliten su inserción en contextos nacionales e internacionales, y su participación propositiva como profesionales y ciudadanos del mundo.

*   [Inicio](https://www.eafit.edu.co/en)
*    Internationalization 

# Experiencias

[Para quienes ya son eafitenses](https://www.eafit.edu.co/en/internacionalizacion#4257225834-1771184078)

Para quienes ya son eafitenses

## Intercambio académico internacional

[Ver intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)

## Intercambio académico nacional

[Ver intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)

## Convenios

[Conoce nuestros convenios](https://www.eafit.edu.co/internacionalizacion/convenios)

## Idiomas en el exterior

[Ver idiomas en el exterior](https://www.eafit.edu.co/en/internacionalizacion#)

## Oportunidades para profesores

[Ver oportunidades](https://www.eafit.edu.co/en/escuela-ciencias-aplicadas-ingenieria/convocatorias-de-profesores)

## Prácticas en el exterior

[Ver prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)

## Pasantías de investigación

[Ver pasantías](https://www.eafit.edu.co/pasantias-investigativas)

## Misiones – programas a la medida

[Ver misiones](https://www.eafit.edu.co/internacionalizacion/misiones-academicas-salientes)

## Aprendizaje global

[Conoce aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

## Cooperación Internacional en CteI

[Ver cooperación internacional](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

![Image 25: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

[Para quienes quieren venir a EAFIT](https://www.eafit.edu.co/en/internacionalizacion#4257225834-3375020470)

Para quienes quieren venir a EAFIT

## Intercambio académico internacional / Exchange

[Ver intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/international-exchange-students)

## Intercambio académico nacional

[Ver intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional-eafit)

## Convenios / Partnerships

[Conoce nuestros convenios](https://www.eafit.edu.co/internacionalizacion/convenios)

## Spanish program

[Conoce Spanish program](node::17136)

## Oportunidades para profesores / Opportunities for faculty

[Ver oportunidades](https://www.eafit.edu.co/en/internacionalizacion#)

## Pasantías de investigación / Research internships

[Ver pasantías](https://www.eafit.edu.co/pasantias-investigativas)

## Misiones – programas a la medida / Tailor-made programs

[Ver misiones](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)

## Aprendizaje global / Global Learning

[Conoce Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

## Cooperación Internacional en CteI / International Cooperation STI

[Ver cooperación internacional](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

## EAFIT, tu próximo destino / EAFIT, your next destination

[Conoce EAFIT, tu próximo destino](https://www.eafit.edu.co/internacionalizacion/eafit-next-destination)

![Image 26: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

Nuestras capacidades

![Image 27: Imagen Campus](https://universidadeafit.widen.net/content/a4e11f6e-fa26-476c-b59d-9014341c8950/web/Campus1.png?crop=yes&k=c&w=397&h=253&itok=-OmwEECV)

Campus

Conoce nuestra Universidad Parque.

[Ver campus](https://www.eafit.edu.co/campus)

![Image 28: Imagen CTeI](https://universidadeafit.widen.net/content/0c3b26f7-5763-403f-a1d5-8a10a27e8dff/web/CTei.jpg?crop=yes&k=c&w=397&h=253&itok=vJID7Rcr)

CTeI

Promover la investigación y generamos proyectos dinámicos e interdisciplinarios para responder a los desafíos de la sociedad.

[See STI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

![Image 29: Imagen Nuestras escuelas y programas](https://universidadeafit.widen.net/content/ef886cc7-c5cb-409a-b3f8-49e824a93496/web/EscuelasyProgramas.png?crop=yes&k=c&w=397&h=253&itok=1lQqcnpA)

Nuestras escuelas y programas

[Ver nuestras escuelas y programas](https://www.eafit.edu.co/en/nuestras-escuelas)

![Image 30: Imagen Centros de estudio e incidencia](https://universidadeafit.widen.net/content/5a49b2b9-8609-43f2-a08d-12be4d13f84f/web/Centros.jpg?crop=yes&k=c&w=397&h=253&itok=EW747AAK)

Centros de estudio e incidencia

[Ver Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)

## Convenios

## Para estudiantes eafitenses

Encuentra aquí los convenios disponibles para realizar intercambios o dobles titulaciones a nivel nacional e internacional.

[Ver convenios](https://apps.powerapps.com/play/e/default-99f7b55e-9cbe-467b-8143-919782918afb/a/5e285a8a-44ab-4dbc-99f9-440be6b54d14?tenantId=99f7b55e-9cbe-467b-8143-919782918afb&source=AppSharedV3&hint=bb28e263-a0e5-453a-bac9-2ecb2bc81d4c)

## Para usuarios externos

Conoce nuestros aliados nacionales e internacionales.

[Ver usuarios externos](https://www.eafit.edu.co/internacionalizacion/convenios)

## Aprendizaje global

Promovemos la formación de los eafitenses como ciudadanos del mundo, con competencias globales e interculturales.

[Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

![Image 31: Imagen Aprendizaje global](https://universidadeafit.widen.net/content/a697cb73-ebf5-4462-81ff-efb349111b2b/web/rutas-aprendizaje-educacion-continua.jpg)

Casos y experiencias

![Image 32: Imagen La noche internacional](https://universidadeafit.widen.net/content/c7337902-b9bb-42e8-a269-cf0d65f6c006/web/NocheInternacional.jpg?crop=yes&k=c&w=397&h=253&itok=pSW3Umv2)

La noche internacional

Un espacio para vivir la cultura y la gastronomía del mundo de la mano de nuestros estudiantes internacionales.

[Ver Video](https://www.youtube.com/watch?time_continue=5&v=clSKjTOyvHM&embeds_referring_euri=https%3A%2F%2Fwww.eafit.edu.co%2F&source_ve_path=MTM5MTE3LDIzODUx)

![Image 33: Imagen Harvard Business School – FIELD Global Immersion Course](https://universidadeafit.widen.net/content/4f586014-d422-48d3-94b4-77441251f2eb/web/HBS.jpg?crop=yes&k=c&w=397&h=253&itok=4xXlGWIo)

Harvard Business School – FIELD Global Immersion Course

[Ver video](https://www.youtube.com/watch?v=S9_x6JSeEzM)

![Image 34: Imagen EAFIT](https://universidadeafit.widen.net/content/b5742992-26e2-437d-8e53-9065539e4088/web/EAFIT%20tu%20proximo%20destino.jpg?crop=yes&k=c&w=397&h=253&itok=u62stJ36)

EAFIT

Conoce los testimonios de nuestros estudiantes de intercambio nacional e internacional y elige EAFIT como tu próximo destino.

[Ver video](https://www.instagram.com/internacionalizacion.eafit/reel/C9vN3bOyQ2w/)

![Image 35: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 36: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 37: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 38: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 39: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 40: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 41: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 42: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Our undergraduates](https://www.eafit.edu.co/en/pregrados)
*   [Our postgraduates programs](https://www.eafit.edu.co/en/posgrados)
*   [Other programs](https://www.eafit.edu.co/en/otros-programas)
*   [Learn about tuition and fees](https://www.eafit.edu.co/en/node/1171)
*   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

Conéctate con EAFIT

*   [Transform with us](https://www.eafit.edu.co/en/node/43361)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/en/node/30186)
*   [Work with us](https://www.eafit.edu.co/en/node/45751)

Contáctanos

*   [Register a PQRSF](https://www.eafit.edu.co/en/node/45736)
*   [Visitor center](https://www.eafit.edu.co/en/node/45661)
*   [Transparency line](https://www.eafit.edu.co/en/node/42081)

Información de ley

*   [Legal Status](https://www.eafit.edu.co/en/node/42106)
*   [Regulations and statutes](https://www.eafit.edu.co/en/node/35101)
*   [Gender, diversity and inclusion](https://www.eafit.edu.co/en/node/38366)
*   [Legal notices and certificates](https://www.eafit.edu.co/en/node/42111)
*   [Update your information](https://www.eafit.edu.co/en/node/45776)
*   [Data protection policy](https://www.eafit.edu.co/en/node/15276)
*   [Terms of use](https://www.eafit.edu.co/en/node/42146)

[Map of the website](https://www.eafit.edu.co/en/internacionalizacion#mapa-del-sitio)

Institutional Accreditation until 2026.

Supervised by Ministry of Education.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/en/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Our campuses

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellin](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

National line: 01 8000 515 900

Service line: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Service line: (57) 606 3214115, 606 3214119

[EAFIT Bogota](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Service line: (57) 601 6114618

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego – Rionegro

![Image 45](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
