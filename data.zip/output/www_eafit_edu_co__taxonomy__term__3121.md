Title: Alcampus

URL Source: https://www.eafit.edu.co/taxonomy/term/3121

Markdown Content:
# Alcampus | Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/taxonomy/term/3121#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 2: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/3121#)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/3121# "Spanish")[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/taxonomy/term/3121# "English")

 Información para ti

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 6: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 7: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 8: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 9: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 10: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 12: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 13: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 14: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 15: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 16: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 17: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 18: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 19: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

## [Alcampus 2025, el encuentro en el que recordamos porque ¡Somos eafitenses!](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando-nuestra-comunidad-de-talento/alcampus-2025-el)

Octubre 21, 2025

**•El 18 de octubre, EAFIT volvió a llenarse de vida, risas y abrazos. Graduados y graduadas de distintas generaciones regresaron a su alma mater para conocer los nuevos espacios, reencontrarse con amigos y revivir los años universitarios.**

**•Entre diálogos, recorridos, música y comida,**[_**Alcampus**_**2025**](https://www.eafit.edu.co/alcampus-2025)**fue una celebración de 65 años de historia compartida y del orgullo de ser eafitense. Fue un día para reconectar con la Universidad, con los compañeros y con la esencia que une a esta comunidad de talento.**

*   [Lee más sobre Alcampus 2025, el encuentro en el que recordamos porque ¡Somos eafitenses!](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando-nuestra-comunidad-de-talento/alcampus-2025-el "Alcampus 2025, el encuentro en el que recordamos porque ¡Somos eafitenses!")

Desde temprano, los pasillos de la Universidad comenzaron a llenarse de abrazos, risas y conversaciones que viajaban en el tiempo. Cada graduado que cruzaba las porterías traía consigo la emoción de volver a casa. Por fin era sábado 18 de octubre y _Alcampus_ 2025 daba inicio: una jornada para el reencuentro, la gratitud y los nuevos descubrimientos.

El ambiente estaba cargado de nostalgia. Ricardo Greiffenstein Restrepo, graduado en Administración de Negocios en 1981, fue uno de los primeros en llegar. “Contaba los días en el calendario, no veía la hora de que llegara _Alcampus_, creo que no venía hace 10 años”, recordó mientras se preparaba para recorrer los nuevos espacios y reconectarse con su historia universitaria. “Tengo un sentimiento muy grato con EAFIT. Estoy completamente descrestado por el crecimiento que ha tenido, esto es impresionante”.

Por los caminos del campus se cruzaban generaciones distintas, algunas que regresaban después de un largo tiempo. Catalina Mesa Gómez y Carolina Castillo, administradoras de negocios y amigas desde el pregrado, no ocultaban su sorpresa. “Junín, cuando yo estudiaba, estaba distribuida diferente. La Universidad está muy cambiada, se ve más amplia, más bonita, con una energía increíble”, comentó Catalina, mientras esperaba a sus padres, también egresados eafitenses, para recorrer juntos la Universidad y asistir a las charlas que habían escogido.

Los Diálogos _**AlCampus**_ fueron lo primero en la agenda, allí se reunieron graduados y expertos en torno a temas actuales como el futuro de la educación, el emprendimiento, la inclusión y la diversidad. Fueron espacios para volver a pensar el país y la Universidad desde la conversación. “Si hablamos de un modelo educativo basado en el aprendizaje por retos, esos retos deben venir del mundo de las organizaciones”, se escuchó en uno de los paneles, reflejando el espíritu de formación que caracteriza a EAFIT.

###### Reencuentros con colegas y amigos

El mediodía trajo consigo los reencuentros de escuelas y programas. En el auditorio Fundadores, la Escuela de Administración celebró sus 65 años con pastel, aplausos y anécdotas. En otro punto del campus, la Escuela de Finanzas, Economía y Gobierno conmemoró tres décadas de historia y reiteró su compromiso con la inclusión educativa con historias de impacto y gratitud.

Camila Eduarda Villadiego Núñez, estudiante becada de Economía, compartió con los graduados su historia. “Vengo de Maicao y gracias a sus donaciones mi vida y la de mis padres cambió. Ellos no pudieron acceder a una universidad, y esta beca me convirtió en la primera de mi familia en llegar hasta aquí”, expresó emocionada. Su historia inspiró a egresados como Santiago Arango Tobón, economista de la promoción 2015, quien destacó la importancia de devolverle algo a la institución que lo formó.

“Nos contaron que cerca del 27 % de la población estudiantil es becada, y estoy convencido de que la educación es una herramienta para encontrar la mejor versión de uno. Por eso es importante apoyar las becas y brindar oportunidades a quienes no podrían acceder”, afirmó. Hoy, Santiago asegura que la cultura empresarial que aprendió en EAFIT lo impulsó a crear proyectos con sentido social y transformador.

###### Descubrir el campus

Los recorridos guiados fueron uno de los espacios más concurridos. Desde la Biblioteca hasta el nuevo Bloque 20, los visitantes pudieron conocer una EAFIT renovada y verde. El Parque Origen fue una de las paradas más emotivas: un homenaje a la quebrada La Volcana y al antiguo Bloque 3, convertido ahora en símbolo de sostenibilidad y memoria. Allí, entre árboles jóvenes y ladrillos reutilizados, muchos se detuvieron a tomar fotos y a compartir recuerdos.

Entre los asistentes se encontraban Cecilia Callejas Vergara y Esaú Rojas Díaz, ingenieros de sistemas de las promociones de 1983 y 1982. Conmovidos, coincidieron en que recorrer la Universidad fue conectarse con una historia que también les pertenece. “Amo la universidad y descubrir lo hermoso que está el campus, todas las maravillas nuevas, la diversidad de disciplinas y los campos de investigación, es fascinante”, expresó Cecilia. Ambos recordaron con orgullo haber sido parte de las primeras cohortes de ingeniería de EAFIT y destacaron cómo su formación, basada en el pensamiento sistémico, les abrió las puertas del mundo laboral.

La tarde avanzó con ritmo y alegría. En la Plazoleta del Estudiante, la Orquesta Sinfónica EAFIT presentó su concierto Amor eterno, un homenaje a la memoria y al reencuentro. Las voces de Paula Olarte y Samir Becerra hicieron que los asistentes corearan canciones de José José, Rocío Dúrcal, Ana Gabriel, Roberto Carlos, Yuri y Pimpinela. El cierre estuvo a cargo del septeto Son de la Nubia, que llenó el campus con sonidos caribeños y puso a bailar a los graduados.

Entre los coros y la música, Johanna Cadavid Muriel y María Alexandra Quintero Loaiza se abrazaban entre risas y recuerdos. Amigas desde su tercer semestre de Administración de Negocios, volvían a habitar los mismos espacios que las vieron hacerse profesionales. “Reencontrarse con personas que no veía hace años es muy especial. Siento gratitud porque EAFIT me abrió puertas y me enseñó el valor de la corresponsabilidad”, resaltó Johanna.

En cada grupo de amigos había una historia: anécdotas de clase, nombres de profesores que aún perduran en la memoria y lugares que despertaban emociones. “EAFIT era el amor de mi vida, siempre quise estudiar aquí”, confesó una egresada, mientras brindaba con sus compañeros de promoción.

_Alcampus_ 2025 fue una cita con los afectos, un reencuentro entre generaciones y una reafirmación del orgullo de ser eafitense: de pertenecer a una comunidad que sigue creciendo, aprendiendo y escribiendo el futuro.

Imagen Noticia EAFIT

![Image 20: Alcampus noticias principal crónica](https://universidadeafit.widen.net/content/571fd4a9-a356-43ab-8aab-516ee9e08b61/web/cronica-alcampus.jpeg)

Leyenda de la imagen

Graduados de distintas generaciones regresaron al campus para revivir historias y fortalecer lazos.

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

Público Noticias

[Graduados](https://www.eafit.edu.co/taxonomy/term/1936)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Debate global con sello estudiantil](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil)

Abril 7, 2026

**Una delegación de ocho integrantes del grupo EAFIT UN Society participó en un modelo de Naciones Unidas organizado por la Universidad de Harvard, realizado en Lima.**

**Durante ocho meses se prepararon en habilidades como oratoria, negociación y trabajo en equipo para este encuentro, que reunió a más de 2.000 participantes de 110 países.**

**La experiencia fortaleció sus competencias en análisis de problemáticas globales y representación en escenarios internacionales.**

[Ver publicación en instagram](https://www.instagram.com/p/DW2ZJgQCiOE/)

*   [Lee más sobre Debate global con sello estudiantil](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Debate global con sello estudiantil ")

Imagen Noticia EAFIT

![Image 21: Debate global con sello estudiantil 

Una delegación de ocho integrantes del grupo EAFIT UN Society participó en un modelo de Naciones Unidas organizado por la Universidad de Harvard, realizado en Lima.

Canal de estudiantes](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [De una inspiración a la competencia internacional](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional)

Marzo 16, 2026

**Sofía Zuluaga Zuluaga, estudiante de Finanzas, participó en el Campeonato Panamericano de Esgrima, realizado en Bogotá.**

**Su proceso en la esgrima inició a los 13 años y evolucionó hasta su participación en la Selección Colombia, combinando su formación académica con el deporte de alto rendimiento.**

**Su participación en este torneo permitió evidenciar el desarrollo de habilidades como la estrategia, la concentración y la toma de decisiones en competencia.**

[Ver publicación en instagram](https://www.instagram.com/p/DV9nEfOClnr/)

*   [Lee más sobre De una inspiración a la competencia internacional](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "De una inspiración a la competencia internacional")

Imagen Noticia EAFIT

![Image 22: De una inspiración a la competencia internacional

Sofía Zuluaga Zuluaga, estudiante de Finanzas, participó en el Campeonato Panamericano de Esgrima, realizado en Bogotá.

Canal de estudiantes](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Liderazgo que empieza desde ahora](https://www.eafit.edu.co/noticias/eafit-es-noticia/liderazgo-que-empieza-desde-ahora)

Febrero 5, 2026

**Se realizó el acto de posesión de las juntas directivas de grupos estudiantiles para 2026, marcando el inicio de un nuevo ciclo de liderazgo.**

**Este espacio destacó el liderazgo como un ejercicio basado en la responsabilidad, el diálogo y la toma de decisiones con impacto en la vida universitaria.**

**La jornada permitió reconocer estos roles como un compromiso colectivo orientado a la construcción de comunidad.**

[Ver publicación en instagram](https://www.instagram.com/p/DUZRaizinkg/)

*   [Lee más sobre Liderazgo que empieza desde ahora](https://www.eafit.edu.co/noticias/eafit-es-noticia/liderazgo-que-empieza-desde-ahora "Liderazgo que empieza desde ahora")

Imagen Noticia EAFIT

![Image 23: Liderazgo que empieza desde ahora - Canal de estudiantes](https://universidadeafit.widen.net/content/9cb27a47-bde8-40c9-8c75-ee23913a97fb/web/liderazgo-que-empieza-desde-ahora.jpg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Aprender haciendo: así se vivieron las monitorías](https://www.eafit.edu.co/noticias/eafit-es-noticia/aprender-haciendo-asi-se-vivieron-las-monitorias)

Enero 30, 2026

**Durante el semestre 2025-2, 642 estudiantes participaron en el programa de monitorías, integrándose a distintas áreas de la vida universitaria.**

**A través de modalidades académicas, administrativas, de investigación, logísticas y por contraprestación, desarrollaron habilidades prácticas y ampliaron su comprensión del entorno universitario.**

**El proceso fue gestionado desde EPIK, articulando la experiencia con la formación académica y el acompañamiento a los estudiantes.**

[Ver publicación en instagram](https://www.instagram.com/p/DUI-zYVCsUV/)

*   [Lee más sobre Aprender haciendo: así se vivieron las monitorías](https://www.eafit.edu.co/noticias/eafit-es-noticia/aprender-haciendo-asi-se-vivieron-las-monitorias "Aprender haciendo: así se vivieron las monitorías ")

Imagen Noticia EAFIT

![Image 24: Grupo de jóvenes estudiantes compartiendo un momento agradable dentro de un Laboratorio financiero. Allí se encuentran varios estudiantes cada uno frente a su estación de trabajo. Se encuentran en un espacio equipado con múltiples estaciones de trabajo con monitores que muestran gráficos en tiempo real.](https://universidadeafit.widen.net/content/661905b1-656a-47e2-83f8-54bd70fd82cc/web/Espacios-aprendizaje-LaboratorioFinanciero-15.jpg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Así se vivieron los grupos estudiantiles](https://www.eafit.edu.co/noticias/eafit-es-noticia/asi-se-vivieron-los-grupos-estudiantiles)

Enero 29, 2026

**Durante tres días se realizó Vive Tus Grupos en la Plazoleta del Estudiante, un espacio para visibilizar el trabajo de los grupos estudiantiles.**

**La actividad permitió mostrar cómo, desde estos espacios, se desarrollan habilidades en liderazgo, trabajo en equipo y gestión de proyectos, complementando la formación académica.**

**El encuentro fortaleció el reconocimiento de los grupos como escenarios de aprendizaje práctico y construcción de comunidad.**

[Ver publicación en instagram](https://www.instagram.com/p/DUHOLKMikI0/)

*   [Lee más sobre Así se vivieron los grupos estudiantiles](https://www.eafit.edu.co/noticias/eafit-es-noticia/asi-se-vivieron-los-grupos-estudiantiles "Así se vivieron los grupos estudiantiles ")

Imagen Noticia EAFIT

![Image 25: Vive tus grupos 2026 - 1 , Canal de estudiantes](https://universidadeafit.widen.net/content/cef612ed-3c5e-4d59-afb0-a24065bb18ee/web/vive-tus-grupos-2026-1.jpg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Así empezó el viaje 2026-1](https://www.eafit.edu.co/noticias/eafit-es-noticia/asi-empezo-el-viaje-2026-1-0)

Enero 16, 2026

**Durante tres días se dio la bienvenida a la nueva cohorte de estudiantes, en un espacio orientado a su integración y apropiación de la vida universitaria.**

**La programación reunió a las diferentes escuelas y promovió el aprendizaje en comunidad como eje central, a través de actividades académicas y culturales, incluyendo la participación de Puerto Candelaria.**

**El encuentro permitió fortalecer el sentido de pertenencia y presentar la formación como un proceso participativo y en constante construcción.**

[Ver publicación en instagram](https://www.instagram.com/p/DTlgr9oCuO7/)

*   [Lee más sobre Así empezó el viaje 2026-1](https://www.eafit.edu.co/noticias/eafit-es-noticia/asi-empezo-el-viaje-2026-1-0 "Así empezó el viaje 2026-1 ")

Imagen Noticia EAFIT

![Image 26: Imágenes de inducciones estudiantes de pregrado](https://universidadeafit.widen.net/content/c59fd41f-a7b8-4620-b4dd-2ce10aaae772/web/Bienvenida%20estudiantes%20nuevos%20-09159.jpg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Un año que abrió oportunidades y dejó huella](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-ano-que-abrio-oportunidades-y-dejo-huella)

Diciembre 30, 2025

**Durante 2025, el 27 % de los estudiantes accedió a apoyos financieros, fortaleciendo la inclusión y la movilidad social.**

**Se impulsaron la ciencia, la tecnología y la innovación con una nueva política institucional y avances en investigación, conectando el conocimiento con los retos del entorno.**

**También se vivieron hitos como los 65 años, la renovación de la Acreditación Institucional, la transformación del Bloque 3, la apertura de Parque Origen y Alcampus 2025.**

**Estos logros reflejaron un trabajo conjunto y un año marcado por avances clave para la comunidad.**

[Ver publicación en instagram](https://www.instagram.com/p/DS5AglYDbKS/?utm_source=ig_web_copy_link&igsh=NTc4MTIwNjQ2YQ==)

*   [Lee más sobre Un año que abrió oportunidades y dejó huella](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-ano-que-abrio-oportunidades-y-dejo-huella "Un año que abrió oportunidades y dejó huella")

Imagen Noticia EAFIT

![Image 27: Política y políticas: ¿qué esperar de las elecciones 2026?](https://universidadeafit.widen.net/content/29b2baea-2f2e-485f-ada9-57e1de7d889c/web/politica2.jpeg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [El nuevo orden mundial: ¿quién define las reglas?](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/el-nuevo-orden-mundial-quien-define-las-reglas)

Octubre 18, 2025

El papel de la sociedad civil y de la opinión pública en la configuración del nuevo orden internacional fue el eje central de este Diálogo Alcampus. La conversación estuvo a cargo de Sandra Borda, politóloga e internacionalista de la Universidad de los Andes, y fue moderada por José Toro, profesor de EAFIT.

*   [Lee más sobre El nuevo orden mundial: ¿quién define las reglas?](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/el-nuevo-orden-mundial-quien-define-las-reglas "El nuevo orden mundial: ¿quién define las reglas?")

Durante el encuentro, la invitada explicó que en las últimas décadas se ha intensificado la participación ciudadana en los asuntos globales, impulsada por las redes sociales y los medios de comunicación, lo que ha transformado la manera en que los Estados y sus mandatarios interactúan en el escenario internacional.

Borda señaló que este interés se originó en las primeras protestas contra la globalización y que, con el paso del tiempo, borró las fronteras entre lo doméstico y lo internacional. En su análisis, destacó que los líderes actuales deben actuar simultáneamente en ambos ámbitos. “Hoy los mandatarios juegan en dos tableros simultáneamente: el interno y el internacional”, afirmó.

El diálogo también abordó el caso colombiano y sus implicaciones. La experta explicó que esta tendencia se consolidó durante el gobierno de Juan Manuel Santos, cuando se fortaleció la presencia del país en la esfera internacional. Sin embargo, advirtió que el contexto actual está marcado por cambios en la orientación de las relaciones económicas y diplomáticas, una situación que refleja una dinámica global más amplia.

> La politóloga destacó además que la opinión pública en Colombia se está involucrando cada vez más en temas internacionales, como los conflictos en el Medio Oriente o las relaciones con Estados Unidos. No obstante, alertó que este proceso ocurre en medio de una gran cantidad de opiniones sin suficiente información. “Lo que hace la falta de conocimiento con excesiva opinión es generar polarización”, señaló, al advertir que esta brecha entre conocimiento y opinión alimenta la división social y política.

> En ese sentido, Borda subrayó que “la sociedad civil está avanzando más rápido que la clase política y los medios de comunicación en los temas internacionales”, lo que evidencia un cambio en la forma en que se construyen las agendas globales y nacionales. También insistió en que “la división entre lo doméstico y lo internacional se ha atenuado: los temas globales hoy atraviesan las agendas internas de los países”.

> Finalmente, la invitada enfatizó la importancia de fortalecer el papel de la academia y de los medios de comunicación en la formación y divulgación del conocimiento sobre asuntos internacionales, con el fin de promover un debate público más informado y constructivo. Cerró con una llamado: “El precio político de ignorar los temas globales es cada vez más alto e indigerible”.

Imagen Noticia EAFIT

![Image 28: Nuevo orden mundial](https://universidadeafit.widen.net/content/d207fd68-e7f1-46b6-a2b0-7af453a68cce/web/nuevo-orden-mundial.jpeg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Equidad e inclusión: de la palabra a la acción colectiva](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/equidad-e-inclusion-de-la-palabra-la-accion-colectiva)

Octubre 18, 2025

Este diálogo fue un espacio para reflexionar sobre los retos que enfrenta la sociedad al hablar de diversidad y equidad desde un enfoque real, coherente y sostenible. La conversación reunió a Ángela Anzola, CEO de la Fundación Plan, y a Cristina Vélez Valencia, decana de la Escuela de Administración de EAFIT, en el marco de un ciclo de charlas sobre liderazgo y transformación social.

*   [Lee más sobre Equidad e inclusión: de la palabra a la acción colectiva](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/equidad-e-inclusion-de-la-palabra-la-accion-colectiva "Equidad e inclusión: de la palabra a la acción colectiva")

Desde su experiencia al frente de una organización presente en más de 80 países, Ángela destacó que Fundación Plan ha centrado su labor en empoderar a las niñas y a las comunidades, capacitándolas para que sean ellas mismas las gestoras del cambio. “El objetivo de una organización como Plan es que algún día no nos necesiten más. Si logramos dejar capacidad instalada en el territorio, habremos cumplido nuestra misión”, afirmó.

Para lograrlo, la Fundación trabaja con organizaciones locales, juntas de acción comunal y colectivos de mujeres, fortaleciendo su autonomía y su capacidad de ejecución. Esta visión, explicó Anzola, no solo busca eficiencia operativa, sino también una inclusión auténtica que respete las realidades culturales y sociales de cada comunidad. “Llegar con el mismo discurso a todos los territorios es un error; hay que escuchar, comprender y adaptar el lenguaje para que el mensaje sea cercano y significativo”, agregó.

Uno de los momentos más potentes de la charla fue su invitación a entender que la inclusión no siempre es cómoda. “Si no te estás incomodando, no lo estás haciendo bien. La inclusión implica adaptarse a realidades distintas y reconocer que otros ven el mundo de otra manera”, enfatizó, recordando que “la diversidad sin inclusión no es verdad; es una forma silenciosa de exclusión”.

Por su parte, Cristina Vélez resaltó la importancia de que la academia y el sector empresarial integren estos temas en su núcleo estratégico. “La equidad y la inclusión no pueden entenderse como asuntos periféricos o de responsabilidad social. Son parte del corazón estratégico de las organizaciones y determinan su sostenibilidad en el largo plazo”, afirmó la decana.

> Asimismo, subrayó la necesidad de formar líderes empáticos, conscientes de las desigualdades estructurales, y capaces de generar entornos laborales y sociales donde todas las personas tengan oportunidades reales de desarrollo. “La equidad y la inclusión no son temas sociales o filantrópicos, son decisiones estratégicas para la sostenibilidad y la ética empresarial”, insistió Cristina.

La conversación también abordó los desafíos sociales y culturales que persisten en Colombia: la violencia sexual contra niñas y mujeres, la disminución de la natalidad y la influencia de la tecnología y la inteligencia artificial en la formación de vínculos humanos. Anzola advirtió que estos fenómenos están afectando las habilidades sociales de los jóvenes y generando nuevas vulnerabilidades, especialmente entre las mujeres que recurren a economías digitales o informales para sobrevivir.

El encuentro concluyó con un llamado a la solidaridad y al compromiso ético del país. “Somos una nación de renta media, con empresarios fuertes y con posibilidades enormes. Pero eso también nos hace responsables de nuestro propio territorio y de quienes aún enfrentan exclusión y desigualdad”, expresó Ángela Anzola, quien invitó a los líderes y a las organizaciones a asumir la inclusión como una práctica diaria, no como un eslogan.

Imagen Noticia EAFIT

![Image 29: Equidad e inclusión](https://universidadeafit.widen.net/content/e17cbebe-3a29-4e13-aff0-d4bdb47b4829/web/equidad-e-inclusion.jpeg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

#### Paginación

*    Página 1 
*   [Siguiente página››](https://www.eafit.edu.co/taxonomy/term/3121?page=1 "Ir a la página siguiente")

[Suscribirse a Alcampus](https://www.eafit.edu.co/taxonomy/term/3121/feed)

![Image 30: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 31: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 32: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 33: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 34: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 35: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 36: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 37: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
