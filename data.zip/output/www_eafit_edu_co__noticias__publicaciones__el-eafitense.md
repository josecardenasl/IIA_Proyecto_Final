Title: El Eafitense

URL Source: https://www.eafit.edu.co/noticias/publicaciones/el-eafitense

Markdown Content:
[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense# "English")

Buscar

![Image 6: Imagen de banner estudiantes regreso a clases](https://universidadeafit.widen.net/content/485234a3-95cd-4a6e-8529-655b86bdecc3/web/Foto-estudiantesRegresoclases-027.jpg?crop=yes&k=c&w=1920&h=788&itok=_8ko34yZ)

*   [Inicio](https://www.eafit.edu.co/)
*   [Noticias](https://www.eafit.edu.co/noticias)
*   [Publicaciones](https://www.eafit.edu.co/noticias/publicaciones)
*    El Eafitense 

![Image 7: Imagen Lo que nos enseñan las abejas para cuidar a las futuras generaciones  ](https://universidadeafit.widen.net/content/2222f536-d5c6-4c11-96cb-f2456cae5133/web/abejas_descubre_crea.jpg?crop=yes&k=c&w=944&h=540&itok=xc-HRbVK)

[Edición 121](https://www.eafit.edu.co/taxonomy/term/2236)

###### Lo que nos enseñan las abejas para cuidar a las futuras generaciones

[Leer más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180/lo-que-nos-ensenan-las-abejas-para-cuidar-a-las-futuras-generaciones "Leer más")

Agosto 20, 2025

![Image 8: Imagen El presente y el futuro​ se conectan en cinco letras: ​EAFIT​](https://universidadeafit.widen.net/content/6ae0c787-3c34-4a4e-9c52-c31b5a464ac6/web/induccion-estudiantes-foraneos-202412.jpg?crop=yes&k=c&w=944&h=540&itok=7N4C2imr)

[Revista El Eafitense](https://www.eafit.edu.co/taxonomy/term/2231), [Edición 121](https://www.eafit.edu.co/taxonomy/term/2236)

###### El presente y el futuro​ se conectan en cinco letras: ​EAFIT​

[Leer más](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-121/el-presente-y-el-futuro-se-conectan-en-cinco-letras-eafit "Leer más")

[Revista El Eafitense](https://www.eafit.edu.co/taxonomy/term/2231), [Edición 121](https://www.eafit.edu.co/taxonomy/term/2236)

###### La volcana​ quiere ser un parque​​

[Leer más](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-121/la-volcana-quiere-ser-un-parque "Leer más")

[Revista El Eafitense](https://www.eafit.edu.co/taxonomy/term/2231), [Edición 121](https://www.eafit.edu.co/taxonomy/term/2236)

###### ¿Qué puede ser más humanista que una empresa?​

[Leer más](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-121/que-puede-ser-mas-humanista-que-una-empresa "Leer más")

Nuestras ediciones

## Edición 122

[Conoce nuestra última edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-122)

## Edición 121

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-121)

## Edición 120

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-120)

## Edición 119

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-119)

## Edición 118

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-118)

## Edición 117

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-117)

## Edición 116

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-116)

## Edición 115

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-115)

## Edición 114

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-114)

## Edición 113

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-113)

## Edición 112

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-112)

## Edición 111

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-111)

## Edición 110

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-110)

## Edición 109

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-109)

## Edición 108

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-108)

## Edición 107

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-107)

## Edición 106

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-106)

![Image 9: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

![Image 10: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 11: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 12: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 13: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 14: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 15: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 16: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 17: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
