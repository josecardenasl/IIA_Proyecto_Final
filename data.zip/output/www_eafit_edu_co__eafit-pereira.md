Title: EAFIT Pereira

URL Source: https://www.eafit.edu.co/eafit-pereira

Markdown Content:
# EAFIT Pereira - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/eafit-pereira#main-content)

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 12: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 13: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/eafit-pereira#)

[![Image 14: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/eafit-pereira# "Spanish")[![Image 15: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/eafit-pereira# "English")

 Información para ti

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 17: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 18: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 19: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 20: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 21: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 22: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 23: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 24: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 25: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 26: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 27: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 28: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 29: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 30: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 31: Imagen de banner eafit aniversario pereira ](https://universidadeafit.widen.net/content/770efb47-3586-4d1c-91e9-23f2d51bdcc3/web/eafit-aniversario-pereira940.jpg?crop=yes&k=c&w=1920&h=788&itok=LYaKMdXS)

# EAFIT Pereira

![Image 32: Campus EAFIT desde lejos](https://universidadeafit.widen.net/content/a39e11d6-cfd2-42bd-ae4b-451edab05d01/web/eafit-a-tu-alcance1500.jpg?crop=yes&k=c&w=1920&h=788&itok=vLaVYNya)

## **EAFIT a tu Alcance**

Conoce nuestras alternativas de financiación.

[Conoce EAFIT a tu Alcance](https://www.eafit.edu.co/becas-y-financiacion/eafit-a-tu-alcance)

*   [Inicio](https://www.eafit.edu.co/)
*    EAFIT Pereira 

En EAFIT Pereira formamos lideres acordes a las demandas y necesidades del entorno, conectamos con las capacidades de la universidad con sus desafíos, contribuyendo al desarrollo de la región.​

###### Lo que​​​ dicen n​uestros estudiantes y gra​​duados​​​

#### ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Conoce la sede EAFI​T Pereira​​​

![Image 33: Imagen Posgrados](https://universidadeafit.widen.net/content/4a46f5b4-04f4-4690-b459-5fbf5ec49036/web/posgrados-pereira-armenia-cali.jpg?crop=yes&k=c&w=397&h=253&itok=s7OUbeHt)

Posgrados

Especializaciones en Pereira, Armenia y Cali.

[Conocer posgrados](https://www.eafit.edu.co/posgrados?f%5B0%5D=sedes_posgrados%3A126)

![Image 34: Imagen Diplomados y cursos](https://universidadeafit.widen.net/content/f3628285-a69d-48e5-abfd-8b0c4320197a/web/diplomados-pereira.jpg?crop=yes&k=c&w=397&h=253&itok=UHnmA6ty)

Diplomados y cursos

Programas de Educación Continua.

[Conoce nuestra oferta](https://www.eafit.edu.co/otros-programas)

![Image 35: Imagen Saberes de Vida](https://universidadeafit.widen.net/content/4024c847-8a67-4e0a-b244-c8b0d3cc012f/web/saberes-de-la-vida.jfif)

Saberes de Vida

Un espacio para enriquecerse intelectualmente.

[Conocer saberes de vida](https://www.eafit.edu.co/eafit-pereira/saberes-de-vida)

#### Noticias

![Image 36: Imagen La Editorial EAFIT llevará su catálogo a la Filbo 2026](https://universidadeafit.widen.net/content/06775a08-60ca-4910-be81-9ede92d51066/web/Catalogo-la-Filbo2026.jpg?crop=yes&k=c&w=427&h=464&itok=-EdA7qmB)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)
###### La Editorial EAFIT llevará su catálogo a la Filbo 2026

La Feria Internacional del Libro de Bogotá (Filbo) es el escenario para el encuentro entre lectores, autores, editores, bibliotecas y distribuidores. En su edición de 2026, que se llevará a cabo entre el 21 de abril y el 4 de mayo, la Editorial EAFIT fortalecerá su proyección comercial y académica, así como el relacionamiento con actores clave del sector editorial universitario y cultural.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/la-editorial-eafit-llevara-su-catalogo-la-filbo-2026 "Leer más")

Abril 22, 2026

![Image 37: Imagen EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario](https://universidadeafit.widen.net/content/7560b375-a4ab-4d45-adb8-1b969563953a/web/premio-literario-1500.jpg?crop=yes&k=c&w=427&h=464&itok=1Meaql9E)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)
###### EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario

[**Las postulaciones deberán ser presentadas**](https://eafit.qualtrics.com/jfe/form/SV_8igZh8GDU9E16rs) por entidades culturales, editoriales públicas o privadas, de Colombia o del exterior que mantengan vínculo con el país, hasta el lunes 25 de mayo.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-y-la-alcaldia-de-medellin-tienen-abierta-la-convocatoria-para-la "Leer más")

Abril 21, 2026

![Image 38: Imagen Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://universidadeafit.widen.net/content/1e26403e-34ad-44fd-98d4-b1ff716a698f/web/Nueva-fase-energia.jpg?crop=yes&k=c&w=427&h=464&itok=aqxiQGn0)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar

En un momento en que el sistema energético atraviesa cambios profundos y acelerados, el sector se reunió el pasado 16 de abril en la Cámara de Comercio de Medellín para mirar hacia adelante.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando-publicaciones/nueva-fase-para-la-energia-en-america-latina-ya-no-se "Leer más")

Abril 20, 2026

![Image 39: Imagen Recorrer la cancha, la tribuna y la calle es la invitación de la nueva exposición de EAFIT](https://universidadeafit.widen.net/content/94c78b4d-8131-4055-b050-34f6b0d6954a/web/Recorrer-cancha.jpg?crop=yes&k=c&w=427&h=464&itok=9s6eUHr1)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)
###### Recorrer la cancha, la tribuna y la calle es la invitación de la nueva exposición de EAFIT

Puede que un partido de fútbol dure noventa minutos, pero las historias que deja pueden permanecer durante décadas. Más que un deporte, el fútbol es un fenómeno cultural capaz de atravesar la vida cotidiana y de instalarse en la memoria colectiva.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/recorrer-la-cancha-la-tribuna-y-la-calle-es-la-invitacion-de-la-nueva "Leer más")

Abril 15, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/lo-que-esta-pasando)

Sedes EAFIT 

¿Quieres conocer más sobre nuestros programas y servicios​?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Sedes EAFIT

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfonos*? 

Ciudad de residencia*? 

Programa de interés*? 

Nivel de formación (Seleccione según tu estudio más reciente)* ? 

¿Qué desea saber de nuestro programa?*? 

Inicio del programa 

Canal origen 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 40](https://universidadeafit.widen.net/content/47feabff-d797-418a-a261-b87b409d955e/web/idiomas-eafit-sede-Poblado-1.jpg?crop=yes&k=c&w=470&h=272&itok=0RiCG_G5)

#### ​Nuestros diferen​ciadores​​​

## Nuestros programas están acreditados a nivel nacional e internacional​.

## Nuestros profesores son de gran excelencia académica; en su mayoría cuentan con doctorado, o con maestría y una amplia experiencia a nivel empresarial.

## Tendrás la posibilidad de ampliar tus redes de contacto profesionales por medio del networking​.

## Generamos valor y desarrollo para las empresas, los sistemas públicos y el emprendimiento.

## Nuestros convenios académicos facilitan los procesos de movilidad tanto a nivel nacional como internacional, y, en algunos programas, ofrecen la posibilidad de realizar una pasantía internacional en el país de preferencia.

## Nuestro enfoque educativo es el conocimiento aplicado, por medio del cual nuestros estudiantes logran un desarrollo profesional y personal de alta calidad. Además, contamos con espacios de aprendizaje adecuados para lograr este fin,

[​Conoce la agenda de eventos de EAFIT](https://www.eafit.edu.co/calendario-eventos)

#### **Contacto**

![Image 41: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

​Norma Lasso, Gerente Regional.

Correo: [nlassor@eafit.edu.co](mailto:nlassor@eafit.edu.co)

Teléfono: (57) 601 6114618.

![Image 42: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

Maria Angélica González - A sesora de Posgrados

Correo: [mgonza59@eafit.edu.co](mailto:mgonza59@eafit.edu.co)

Teléfono: 315 641 3637

![Image 43: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

Francy Aguirre - A sesora de Posgrados

Correo: [faguirr1@eafit.edu.co](mailto:faguirr1@eafit.edu.co)

Teléfono: 311 728 7747

![Image 44: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

German Augusto Cruz - Coordinador de Crecimiento y Ventas

Correo: [gacruza@eafit.edu.co](mailto:gacruza@eafit.edu.co)

Teléfono: (6) 321 4115

![Image 45: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

Lina Maria Jiménez - Coordinadora Administrativa y Logística

Correo: [ljimen42@eafit.edu.co](mailto:ljimen42@eafit.edu.co)

Teléfono: (6) 321 4115

![Image 46: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 47: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 48: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 49: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 50: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 51: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 52: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 53: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 54](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
