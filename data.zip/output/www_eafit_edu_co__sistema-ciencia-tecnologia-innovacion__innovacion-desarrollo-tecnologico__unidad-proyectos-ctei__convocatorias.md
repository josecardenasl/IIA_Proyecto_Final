Title: Convocatorias Proyectos CTeI

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/unidad-proyectos-ctei/convocatorias

Markdown Content:
​Convocatorias proyectos de regalías

##### **​Convocatorias proyectos de regalías**

###### Nacionales

**043 - Convocatoria de la asignación para la ciencia, tecnología e innovación del sistema general de regalías para la conformación de un listado de proyectos elegibles para aprovechar el conocimiento, conservación y uso sostenible de la biodiversidad los bienes y servicios ecosistémicos en el territorio nacional​​​​**

Convocat​​​oria abierta

Fecha de apertura:

lunes 08 julio 2024​​

​Fecha de cierre:

viernes 06 septiembre 2024 05:00 pm​

Financiación:

​​​Para la presente convocatoria se asigna un monto de CIENTO OCHENTA Y SIETE MIL SETECIENTOS NOVENTA Y OCHO MILLONES SETECIENTOS SETENTA Y SIETE MIL CIENTO OCHENTA Y SIETE PESOS M/CTE ($187.798.777.187) provenientes de los recursos del Sistema General de Regalías, Asignación para la Ciencia, Tecnología e Innovación bienio 2023-2024, los cuales serán distribuidos en valores iguales para las seis regiones del Sistema General de Regalías, correspondiente a TREINTA Y UN MIL DOSCIENTOS NOVENTA Y NUEVE MILLONES SETECIENTOS NOVENTA Y SEIS MIL CIENTO NOVENTA Y SIETE PESOS M/CTE ($31.299.796.197)

De esa forma se espera financiar dos (2) proyectos por región cuyo valor debe encontrarse en el siguiente rango:

VALOR PROYECTO DESDE HASTA

$ 12.519.918.479 - $ 15.649.898.098​​

Objeto:​

​Conformar un listado de proyectos elegibles que contribuyan a la generación de conocimiento, desarrollo tecnológico e innovación para responder al Reto 1 “Aprovechar el conocimiento, conservación y uso sostenible de la biodiversidad, bienes y servicios ecosistémicos” y sus demandas territoriales establecidas en el plan bienal de convocatorias 2023-2024, incentivando su implementación en ecosistemas estratégicos, mediante una alianza entre entidades regionales del SNCTI que vinculen a Jóvenes Investigadores e Innovadores, estudiantes de Maestría y Doctores en estancias posdoctorales para el desarrollo de sus proyectos.

Dirigida a:

Los proyectos deberán ser presentadas a través de una Alianza estratégica conformadas por mínimo:

Dos (2) Instituciones de Educación Superior (IES). o Al menos tres (3) entidades territoriales de la región del SGR7 a la que se presente el proyecto, cada una en un (1) Departamento diferente.

Al menos una (1) entidad u organización dependiente o autónoma con reconocimiento vigente por el Ministerio de Ciencia,

Tecnología e Innovación a la fecha de cierre de la convocatoria

Al menos un (1) actor que agremie o agrupe empresas, por ejemplo, gremios empresariales, cámaras de comercio, cluster, asociaciones empresariales o empresas ancla

Al menos tres (3) organizaciones de sociedad civil que cuenten con representación legal de las cuales por lo menos dos deben tener domicilio en la zona de influencia del proyecto.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co) ​

**042 - ​Convocatoria de la asignación para la ciencia, tecnología e innovación del sistema general de regalías para la conformación de un listado de proyectos elegibles para la convergencia regional y el ordenamiento del territorio​​​**

Convocat​​​oria abierta

Fecha de apertura:

lunes 08 julio 2024​​

​Fecha de cierre:

viernes 06 septiembre 2024 05:00 pm​

Financiación:

​​Para la presente convocatoria se asigna un monto de CIENTO VEINTICINCO MIL CUATROCIENTOS VEINTIDOS MILLONES SETECIENTOS CINCUENTA Y CUATRO MIL SETECIENTOS SESENTA Y CINCO PESOS M/CTE ($125.422.754.765) provenientes de los recursos del Sistema General de Regalías, Asignación para la Ciencia, Tecnología e Innovación bienio 2023-2024, los cuales serán distribuidos en valores iguales para las seis regiones del Sistema General de Regalías, correspondiente a VEINTE MIL NOVECIENTOS TRES MILLONES SETECIENTOS NOVENTA Y DOS MIL CUATROCIENTOS SESENTA PESOS M/CTE ($20.903.792.460)

De esa forma se espera financiar un (1) proyecto por región cuyo valor debe encontrarse en el siguiente rango:

VALOR PROYECTO DESDE HASTA

$ 16.723.033.969 - $ 20.903.792.460​​

Objeto:​

​Impulsar proyectos que fomenten la convergencia supramunicipales, intrarregionales e interregionales2 y a la vez fortalezcan las vocaciones productivas y sociales, los vínculos urbano-rurales, interurbanos y subregionales a través de la ciencia, tecnología e innovación, con el fin, de reducir las brechas socioeconómicas mediante la conformación de un listado de proyectos elegibles en CTeI que contribuyan a atender las demandas territoriales del “Reto 6. Convergencia regional y ordenamiento territorial” del plan bienal 2023-2024 y la transformación del Plan Nacional de Desarrollo “Convergencia Regional”.

Dirigida a:

​​Las propuestas deberán ser presentadas a través de una Alianza estratégica conformadas por mínimo:

Al menos dos (2) Instituciones de Educación Superior (IES)

Al menos tres (3) Entidades Territoriales6, de las cuales dos deben estar domiciliadas en dos departamentos diferentes.

Al menos una (1) entidad u organización dependiente o autónoma con reconocimiento vigente por el Ministerio de Ciencia, Tecnología e Innovación a la fecha de cierre de la convocatoria.

Al menos un (1) actor que agremie o agrupe empresas, por ejemplo, gremios empresariales, cámaras de comercio, clúster, asociaciones empresariales o empresas ancla.

Al menos tres (3) organizaciones de sociedad civil que cuenten con representación legal de las cuales por lo menos dos deben tener domicilio en la zona de influencia del proyecto.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)​

**041 - Convocatoria de asignación para la ctei del sgr para la conformación de un listado de proyectos elegibles que contribuyan a la creación de conocimiento, desarrollo de tecnología e investigación apropiada en productividad agrícola y agroecología​​**

Convocat​​​oria abierta

Fecha de apertura:

lunes 08 julio 2024​​

​Fecha de cierre:

viernes 06 septiembre 2024 05:00 pm​

Financiación:

​Para la presente convocatoria se asigna un monto de DOSCIENTOS VEINTICUATRO MIL DIECISIETE MILLONES CIENTO DOCE MIL SETECIENTOS OCHENTA Y OCHO PESOS M/CTE (224.017.112.788) provenientes de los recursos del Sistema General de Regalías, Asignación para la Ciencia, Tecnología e Innovación bienio 2023-2024, los cuales serán distribuidos en valores iguales para las seis regiones del Sistema General de Regalías, correspondiente a TREINTA Y SIETE MIL TRESCIENTOS TREINTA Y SEIS MILLONES CIENTO OCHENTA Y CINCO MIL CUATROCIENTOS SESENTA Y CUATRO PESOS M/CTE ($37.336.185.464)

De esa forma se espera financiar dos (2) proyectos por región cuyo valor debe encontrarse en el siguiente rango:

​VALOR PROYECTO DESDE HASTA $ 14.934.474.188 - $ 18.668.092.732​

Objeto:​

​Contribuir a la investigación y desarrollo tecnológico para la generación del conocimiento alrededor de la agroecología implementada por productores como los Agricultores Campesinos, Familiares, Étnicos y Comunitarios-ACFEC u otras formas de producción sostenibles mediante la conformación de un listado de proyectos elegibles en Ciencia, Tecnología e Innovación (CTeI) en el marco del Reto 2 del Plan Bienal de Convocatorias 2023 – 2024 “Garantizar la Soberanía Alimentaria y el Derecho a la Alimentación”.

Dirigida a:

​​La presente convocatoria está dirigida a alianzas entre entidades del SNCTI y de éstas con otras entidades, que atiendan a lo establecido en los literales a), o b), del artículo 1.2.3.2.2 del Decreto 1821 de 2020.11

Al menos tres (3) entidades de la alianza deberán estar domiciliadas en la región del SGR a la que se presente el proyecto, cada una en un (1) departamento diferente La entidad proponente deberá cumplir con las siguientes condiciones:

El proponente deberá demostrar experiencia de mínimo dos (2) proyectos ejecutados o en ejecución de Ciencia, Tecnología e Innovación en los últimos siete (7) años (contados hasta la fecha de cierre de la presente convocatoria), financiados con cualquier fuente de financiación.

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**040 - ​Convocatoria de la asignación para la ciencia, tecnología e innovación del sistema general de regalías para la conformación de un listado de proyectos orientados al desarrollo de ecosistemas de investigación e innovación para la transición energética justa​**

Convocat​​​oria abierta

Fecha de apertura:

lunes 08 julio 2024​​

​Fecha de cierre:

viernes 06 septiembre 2024 05:00 pm​

Financiación:

​Para la presente convocatoria se asigna un monto de CIENTO SEIS MIL SEISCIENTOS CUARENTA Y DOS MILLONES OCHOCIENTOS SETENTA Y SIETE MIL CUARENTA Y SEIS PESOS M/CTE (106.642.877.046) provenientes de los recursos del Sistema General de Regalías, Asignación para la Ciencia, Tecnología e Innovación bienio 2023-2024, los cuales serán distribuidos en valores iguales para las seis regiones del Sistema General de Regalías, correspondiente a DIECISIETE MIL SETECIENTOS SETENTA Y TRES MILLONES OCHOCIENTOS DOCE MIL OCHOCIENTOS CUARENTA Y UN PESOS M/CTE ($17.773.812.841)

De esa forma se espera financiar un (1) proyecto por región cuyo valor debe encontrarse en el siguiente rango:

VALOR PROYECTO DESDE HASTA $ 14.219.050.273 - $ 17.773.812.841

Objetivo:​

Impulsar el desarrollo de Ecosistemas de Investigación e Innovación para la transición energética justa, mediante la conformación de un banco de proyectos elegibles de I+D+i orientados al desarrollo, adopción y adaptación de tecnologías, que aprovechen sosteniblemente el potencial de los recursos naturales de las regiones, desarrollen cadenas de valor y generen capacidades de CTeI en los territorios; en el marco del reto tres (3) “Asegurar la generación, acceso y uso de energías sostenibles para todos” del Plan Bienal de Convocatorias 2023 – 2024.

Dirigida a:

Alianzas entre entidades del SNCTI de conformidad con lo señalado en el artículo 1.2.3.2.2. del Decreto 1821 de 20206 que pertenezcan a una Región del Sistema General de Regalías (Anexo 8) y que aseguren la participación de actores de la cuádruple hélice: Academia, Sector Productivo, Estado y Sociedad Civil Organizada.

Únicamente y para efectos de participación y evaluación en la presente Convocatoria, se describen a continuación los actores de la cuádruple hélice:

Academia: se entiende como entidades de la academia

Sector Productivo - Empresa: se entiende como entidades del sector productivo - empresa

Estado: Entidad gubernamental del orden nacional, regional, departamental o municipal.

Sociedad Civil Organizada: Asociación, fundación, corporación, entidad del tercer sector, agremiación, grupos u organizaciones comunitarias con personería jurídica, legalmente constituidas en Colombia, que tenga operaciones a nivel nacional o regional

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**039 - ​Convocatoria de la asignación para la ciencia, tecnología e innovación del sistema general de regalías para la conformación de un listado de proyectos elegibles que contribuyan a la erradicación de la violencia para la construcción de sociedades más segur​​as**

Convocat​​​oria abierta

Fecha de apertura:

lunes 08 julio 2024​​

Fecha de cierre:

viernes 06 septiembre 2024 05:00 pm​

Financiación:

​Para la presente convocatoria se asigna un monto de CIENTO VEINTICINCO MIL CUATROCIENTOS VEINTIDÓS MILLONES SETECIENTOS CINCUENTA Y CUATRO MIL SETECIENTOS SESENTA Y CUATRO PESOS M/CTE ($125.422.754.764) provenientes de los recursos del Sistema General de Regalías, Asignación para la Ciencia, Tecnología e Innovación bienio 2023-2024, los cuales serán distribuidos en valores iguales para las seis regiones del Sistema General de Regalías, correspondiente a VEINTE MIL NOVECIENTOS TRES MILLONES SETECIENTOS NOVENTA Y DOS MIL CUATROCIENTOS SESENTA PESOS M/CTE ($20.903.792.460)

De esa forma se espera financiar un (1) proyecto por región cuyo valor debe encontrarse en el siguiente rango:

VALOR PROYECTO DESDE HASTA $ 16.723.033.969 - $ 20.903.792.460.​​​

Objetivo:​

Conformar un listado de proyectos elegibles de Ciencia, Tecnología e Innovación (CTeI) que, a través de la investigación, desarrollo tecnológico, la innovación, la apropiación social del conocimiento y la formación de talento humano, aborden las demandas territoriales del reto 5 'Poner fin a todas las formas de violencia' del Plan de Convocatorias del bienio 2023-2024. El propósito es establecer y fortalecer ecosistemas de ciencia y paz que contribuyan al cierre de brechas territoriales y al bienestar integral de Colombia, mediante la implementación de iniciativas de CTeI con un enfoque restaurativo y de justicia social, económica y ambiental.

Dirigida a:

​En este sentido, las propuestas deberán ser presentadas a través de una alianza estratégica por mínimo:

​Mínimo dos (2) Instituciones de Educación Superior (IES)15

Al menos dos (2) Entidades Territoriales16.

Al menos una (1) entidad u organización dependiente o autónoma reconocida por el Ministerio de Ciencia, Tecnología e Innovación con reconocimiento vigente a la fecha de cierre de la convocatoria17.

Al menos un (1) actor que agremie o agrupe empresas por ejemplo, gremios empresariales, cámaras de comercio, federaciones, clúster, asociaciones empresariales o empresas ancla18.

Al menos tres (3) organizaciones comunitarias19 que cuenten con representación legal de las cuales por lo menos dos deben estar en la zona de influencia del proyecto, y una debe estar reconocida como organización de víctimas u organizaciones de defensa de los derechos de las víctimas

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**038 - ​Convocatoria de la asignación para la ciencia, tecnología e innovación del sistema general de regalías para la conformación de un listado de proyectos elegibles para la seguridad sanitaria, la salud y el bienestar de la población en el territorio nacional​​**

Convocat​​​oria abierta

Fecha de apertura:

lunes 08 julio 2024​​

Fecha de cierre:

viernes 06 septiembre 2024 05:00 pm​

Financiación:

​​Para la presente convocatoria se asigna un monto de CIENTO CINCUENTA Y OCHO MIL DOSCIENTOS OCHENTA Y SIETE MILLONES QUINIENTOS CUARENTA MIL SETECIENTOS SETENTA Y DOS PESOS M/CTE ($158.287.540.772) provenientes de los recursos del Sistema General de Regalías, Asignación para la Ciencia, Tecnología e Innovación bienio 2023-2024, los cuales serán distribuidos en valores iguales para las seis regiones del Sistema General de Regalías, correspondiente a VEINTISÉIS MIL TRESCIENTOS OCHENTA Y UN MILLONES DOSCIENTOS CINCUENTA Y SEIS MIL SETECIENTOS NOVENTA Y CINCO PESOS M/CTE ($26.381.256.795).

De esa forma se espera financiar un (1) proyecto por región cuyo valor debe encontrarse en el siguiente rango:

VALOR PROYECTO EN EL RANGO $21.105.005.436 - $ 26.381.256.795.

Objeto:​

Fortalecer las capacidades territoriales en Ciencia, Tecnología e Innovación en salud mediante la conformación de un listado de proyectos elegibles de Investigación, Desarrollo e Innovación orientados hacia la Atención Primaria en Salud, desde un enfoque preventivo, predictivo y resolutivo, para responder a las demandas territoriales establecidas en el “Reto 4".

Dirigida a:

La presente convocatoria está dirigida a alianzas entre entidades del SNCTI y de éstas con otras entidades, que atiendan a lo establecido en los literales a), o b), del artículo 1.2.3.2.2 del Decreto 1821 de 20203.

Al menos tres (3) entidades de la alianza deberán estar domiciliadas en la región del SGR a la que se presenta el proyecto, cada una en un departamento diferente.

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

###### Internacionales

**036 - CONVOCATORIA DE LA ASIGNACIÓN PARA LA CIENCIA, TECNOLOGÍA E INNOVACIÓN DEL SISTEMA GENERAL DE REGALÍAS PARA LA CONFORMACIÓN DE UN LISTADO DE PROYECTOS ELEGIBLES EN CIENCIAS BÁSICAS Y DEL ESPACIO PARA MOVER LA FRONTERA DEL CONOCIMIENTO EN EL PAÍS Y FORTALECER CAPACIDADES EN LOS TERRITORIOS**

Convocat​​​oria cerrada

Fecha de apertura: viernes 10 noviembre 2023​​​

​​​​​Fecha de cierre: ​​jueves 11 abril 2024 05:00 pm​​​​​​​​​​​

Financiación:

​Para la presente convocatoria se asigna un monto de TRESCIENTOS SESENTA Y CINCO MIL MILLONES DE PESOS M/CTE (365.000.000.000) provenientes de los recursos del Sistema General de Regalías, Asignación para la Ciencia, Tecnología e Innovación 2023-2024.

Los proyectos podrán solicitar recursos al SGR desde diez mil millones de pesos M/CTE ($10.000.000.000) hasta treinta y seis mil quinientos millones de pesos M/CTE ($36.500.000.000).

Objetiv​​o:

​​Convocatoria de la asignación para la ciencia, tecnología e innovación del sistema general de regalías para la conformación de un listado de proyectos elegibles en ciencias básicas y del espacio para mover la frontera del conocimiento en el país y fortalecer capacidades en los territorios.

​Conformar un listado de proyectos elegibles de investigación en ciencias básicas y del espacio que, teniendo en cuenta las demandas territoriales enmarcadas en los retos del plan bienal de convocatorias 2023-2024, fomenten las capacidades de investigación a través de la generación y transferencia de conocimiento y el fortalecimiento de Infraestructuras de Investigación, para mover la frontera del conocimiento, contribuyendo al desarrollo de los territorios.

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**035 - Convocatoria para la asignación para la ciencia, tecnología e innovación del sistema general de regalías para la formación de capital humano de alto nivel para las regiones​​.​​**

Convocat​​​oria cerrada

Fecha de apertura: viernes 10 noviembre 2023​​​

​​​​​Fecha de cierre: lunes 01 abril 2024 05:00 pm​​​​​​​​​​​

Financiación:

Los cupos y recursos indicados para cada región se definen teniendo en cuenta que el costo promedio de la formación doctoral proyectado por cada beneficiario es de $400.000.000 CUATROCIENTOS MILLONES DE PESOS M/CTE, el monto total del crédito educativo condonable a otorgar a cada beneficiario, dependerá de la duración oficial establecida por la IES para el programa doctoral.

Objetiv​​o:

​Conformar un listado de proyectos estratégicos de formación de capital humano a nivel de doctorado para responder a los retos en Ciencia, Tecnología e Innovación establecidos en el plan bienal de convocatorias 2023-2024, otorgando créditos educativos condonables a 1.000 profesionales que inicien su formación a nivel doctoral en el país.

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**034 - ​Convocatoria de la asignación para ciencia, tecnología e innovación ambiental para el ordenamiento alrededor del agua, la justicia ambiental y la transformación productiva para la resolución de desafíos ambientales y desarrollo sostenible del país.​​**

Convocat​​​oria cerrada

Fecha de apertura: viernes 01 diciembre 2023​

​​​​​Fecha de cierre: jueves 02 mayo 2024 05:00 pm​​​​​​​​​

Financiación:

Para esta convocatoria se tiene un monto indicativo de TRESCIENTOS CINCUENTA Y OCHO MIL OCHOCIENTOS OCHENTA Y OCHO MILLONES SETECIENTOS SETENTA Y DOS MIL QUINIENTOS NOVENTA Y OCHO PESOS M/CTE ($358.888.772.598) de la Asignación CTeI ambiental.

Objetiv​​o:

​Conformar un listado de proyectos elegibles de ciencia, tecnología e innovación para el ordenamiento alrededor del agua, la justicia ambiental y la transformación productiva para la resolución de desafíos ambientales y desarrollo sostenible del país en respuesta a las demandas territoriales definidas en el plan de convocatorias 2023-2024 para la Asignación de Ciencia, Tecnología e Innovación Ambiental.

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**033 - ​Convocatoria de la asignación para la Ciencia, Tecnología e Innovación del Sistema General de Regalías para la conformación de un listado de proyectos elegibles para el fomento de vocaciones tempranas en las regiones a través de la estrategia Ondas.​​**

Convocat​​​oria cerrada

Fecha de apertura: miércoles 02 de agosto 2023​

​​​​​Fecha de cierre: viernes 22 de septiembre 2023 04:00 pm​​​​​​​​​

Financiación:

La distribución de los recursos para la presente convocatoria será por Departamentos y Bogotá D.C. Es decir, se financiará un único proyecto por Departamento y Bogotá D.C. Así las cosas, los proyectos podrán solicitar desde 3.640 millones hasta 6.720 millones según lo indicado por departamento.

Objetiv​​o:

Conformar un listado de proyectos elegibles de ciencia, tecnología e innovación que fomenten el desarrollo de las vocaciones, capacidades y habilidades en Ciencia, Tecnología e Innovación en niños, niñas y adolescentes en temáticas enmarcadas en los seis retos del plan bienal de convocatorias a través de la implementación de la estrategia Ondas del Ministerio de Ciencia, Tecnología e Innovación, en los departamentos de Colombia y su Distrito Capital.​

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

Convocatorias Proyectos Cofinanciados

##### **Convocatorias Proyectos Cofinanciados**

###### Nacionales

**956 - ​CONVOCATORIA MOVILIDAD ACADÉMICA CON EUROPA 2024**

**Convocat​​​oria abierta**

Fecha de apertura: viernes 14 junio 2024​

​​​​​Fecha de cierre: viernes 16 agosto 2024 04:00 pm

Financiación:

​$9.098.476.800 para financiar proyectos en esta convocatoria de acuerdo con el CDR.

Objeto:

​Conformar un banco de proyectos elegibles por línea temática con el fin de contribuir a la implementación de las misiones de “Bioeconomía y territorio”, “Derecho humano a la alimentación” y “Ciencia para la paz” a través de iniciativas de investigación, desarrollo tecnológico, innovación y apropiación social del conocimiento desarrollados por Ecosistemas de Ciencia y Paz, entendidos como alianzas entre actores de la academia, el sector productivo y la sociedad civil.

Dirigida a:

​En el marco del Ecosistema de Ciencia y Paz para la Transformación Territorial, los proyectos que se postulen a esta convocatoria deberán ser presentadas a través de una alianza estratégica conformada por mínimo:

Una (1) entidad que actuará en calidad de ejecutora

Tres (3) entidades en calidad de aliados, así:

Mínimo una (1) entidad u organización dependiente o autónoma reconocida por el Ministerio de Ciencia, Tecnología e Innovación con reconocimiento vigente a la fecha de cierre de la convocatoria.

Mínimo una (1) entidad del sector productivo con personería jurídica y que se encuentre legalmente constituida con antigüedad de mínimo dos (2) años a la fecha de cierre de la convocatoria.

Mínimo una (1) organización de base comunitaria con existencia y representación legal vigente.

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

###### Internacionales

**941 - Convocatoria Fortalecimiento del sector hidrocarburos y fuentes no convencionales de energía (FNCE) en Colombia con la vinculación de jóvenes investigadores​​**

Convocat​​​oria cerrada

Fecha de apertura: jueves 15 de junio 2023

​​​​​Fecha de cierre: viernes 18 de agosto 2023 05:00 pm​​​​​​​

Financiación:

$20.000.000

Objetiv​​o:

Fomentar las vocaciones científicas de las mujeres colombianas a través del otorgamiento de reconocimientos económicos a investigadoras colombianas con el fin de apoyar el desarrollo de sus propuestas I+D+i y/o su formación académica.​

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**942 - P​rograma para las mujeres en la Ciencia-Colombia 2023​​**

Convocat​​​oria cerrada

Fecha de apertura: jueves 29 de junio 2023

​​​​​Fecha de cierre: jueves 31 de agosto 2023 05:00 pm​​​​​​​

Financiación:

$39.000.000 para cada beneficiaria del Programa "Para Mujeres en la Ciencia-Colombia 2023".

Objetiv​​o:

Vincular semilleros de investigación, jóvenes investigadores e innovadores de pregrado y recién graduados a propuestas de I+D+i relaciondas con las líneas temáticas definidas en el numeral 4 de los TDR.

Contacto: [formulacion@eafit.edu.co​](mailto:formulacion@eafit.edu.co%E2%80%8B)

**952 | CONVOCATORIA MOVILIDAD ACADÉMICA CON EUROPA 2024​​​​​​​​​**

Convocatoria cerrada

Fecha de apertura: martes 30 abril 2024​​

​​​​​Fecha de cierre: jueves 06 junio 2024 04:00 pm​

​Valor financiación: Hasta $61.200.000​​​​​

Objetivo: Conformar un Banco de Elegibles de movilidades internacionales, en el marco del desarrollo de propuestas conjuntas investigación, desarrollo tecnológico e innovación I+D+i, formuladas con pares internacionales ubicados en Alemania Francia.​​​

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**951 - Fortalecimiento del Conocimiento Geocientífico y Tecnológico de las Fuentes No Convencionales de Energía y la Captura, Almacenamiento y Uso de CO2​​​​​​​​**

Convocatoria cerrada

Fecha de apertura: martes 30 abril 2024​​

​​​​​Fecha de cierre: miércoles 03 julio 2024 05:00 pm​

​Valor financiación: $52.500.000.000​​​​

Objetivo: Fortalecer el desarrollo del sector energético colombiano a través de la financiación de proyectos de I+D+i que contribuyan a la generación de nuevo conocimiento geocientífico y tecnológico en las Fuentes No Convencionales de Energía (FNCE) delegadas a la Agencia Nacional de Hidrocarburos, tales como energía geotérmica, eólica e hidrógeno, y la captura, almacenamiento y uso de dióxido de carbono​​​.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**950 - Convocatoria ColombIA Inteligente​​​​​​**

Convocatoria cerrada

Fecha de apertura: martes 26 marzo 2024​​​

​​​​​Fecha de cierre: lunes 06 mayo 2024 04:00 pm

​Valor financiación: $5.687.040.000​ ($131.220.000​)​​​

Objetivo: Fortalecer la Investigación Aplicada, el Desarrollo Tecnológico y la Innovación en Inteligencia Artificial y Tecnologías Aeroespaciales que contribuya al desarrollo ambiental, social y económico de las regiones en el marco de la Política de Investigación e Innovación Orientada por Misiones​​.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**949 - CONVOCATORIA MISIÓN SOBERANÍA SANITARIA Y BIENESTAR SOCIAL- TERRITORIOS GARANTES DE LA SALUD​​​​**

Convocatoria cerrada

Fecha de apertura: viernes 05 abril 2024​

​​​​​Fecha de cierre: viernes 21 junio 2024 04:00 pm​

​Valor financiación: ​​$49.000.000.000​​​

Objetivo: ​​Contribuir a la generación y/o fortalecimiento de las capacidades territoriales en salud, mediante el fomento de estrategias sectoriales e intersectoriales para el desarrollo, apropiación y/o validación de tecnologías en salud en Colombia con enfoque territorial y de diversidad​​.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**AMSUD CONVOCATORIA 2024​​​**

Convocatoria cerrada

Fecha de apertura: viernes 15 marzo 2024​

​​​​​Fecha de cierre: viernes 15 marzo 2024

​Valor financiación: entre 10.000€ y 20.000€​​​

Objetivo: ​​Apoyar el financiamiento de movilidades internacionales en el marco del desarrollo de propuestas de CTeI en investigación, desarrollo tecnológico e innovación entre países sudamericanos asociados y Francia; el Ministerio de Ciencia, Tecnología e Innovación junto con sus aliados, han acordado mantener abierta la convocatoria Amsud 2024 hasta el próximo 17 de mayo​.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**948 - CONVOCATORIA ORQUIDEAS: MUJERES EN LA CIENCIA 2024​​​**

Convocatoria cerrada

Fecha de apertura: lunes 12 febrero 2024

​​​​​Fecha de cierre: viernes 12 abril 2024 04:00 pm​

​Valor financiación: ​​$132.000.000​ ($11.000.000​)​​

Objetivo: ​​Conformar un listado de propuestas elegibles con un Eje Nacional y un Eje Pacífico, para la selección de proyectos de investigación, desarrollo tecnológico, y/o innovación, que sean realizados como una estancia postdoctoral, que contribuya al desarrollo de las rutas de innovación planteadas en las Misiones: “Bioeconomía y Territorio”, “Derecho Humano a la Alimentación” y “Ciencia para la Paz”, en el marco de la Política de Investigación e Innovación Orientada por Misiones.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**947 - Centros de interés en CTeI con enfoque STEM+​​**

Convocatoria cerrada

Fecha de apertura: viernes 22 diciembre 2023​

​​​​​Fecha de cierre: lunes 05 febrero 2024 04:00 pm​

​Valor financiación: ​​$5.036.246.246​​​​​

Objetivo: ​​Convocatoria para diseñar e implementar centros de interés en CTeI con enfoque STEM+ para el fortalecimiento de los procesos de formación integral y la re significación del tiempo escolar de niños, niñas y adolescentes haciendo uso de la metodología del programa ondas.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**946 - Red Econova de Ecopetrol​**

Convocatoria cerrada

Fecha de apertura: lunes 11 diciembre 2023

​​​​​Fecha de cierre: jueves 21 marzo 2024​

​Valor financiación: ​​$21.639.356.327​​​​

Objetivo: ​​Convocatoria para el apoyo a proyectos de I+D+i que contribuyan a resolver retos tecnológicos propuestos por los centros de innovación de la red Econova de Ecopetrol bajo el modelo de innovación abierta.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**944 - Convocatoria para el registro de proyectos que accederán a los beneficios tributarios por inversión en proyectos de ciencia, tecnología e innovación año 2023​**

Convocatoria cerrada

Fecha de apertura: martes 24 octubre 2023​

​​​​​Fecha de cierre: martes 07 noviembre 2023 05:00 pm

​Valor financiación: ​​Las micro, pequeñas, medianas (MiPymes) y grandes empresas podrán acceder al beneficio de un cupo de descuento tributario del 30% del valor invertido en el proyecto, acorde a lo estipulado en los artículos 256 y 258 del ET​​​

Objetivo: ​​Fomentar la inversión privada en investigación científica, desarrollo e innovación (I+D+i), mediante la calificación de proyectos de investigación científica, desarrollo e innovación, cuya inversión sea realizada durante el año 2023 y vigencias fiscales siguientes, para el acceso a los beneficios tributarios por inversión: descuento y crédito fiscal, según lo estipulado en los artículos, 256, 256-1 y 258 del Estatuto Tributario (E.T), respectivamente.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**945 - Sácale jugo a tu patente**

Convocatoria cerrada

Fecha de apertura: viernes 15 septiembre 2023

​​​​​Fecha de cierre: viernes 13 octubre 2023 11:59 pm​

Valor financiación: $295.000.000 ($59.863.902)​​​

Objetivo: Promover la explotación, comercialización y transferencia de las invenciones protegidas o en proceso de protección por patente.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**1052 - Invitación a presentar proyectos de soluciones innovadoras desde la CTeI, con enfoque de Apropiación Social del Conocimiento para abordar problemáticas y/o necesidades alrededor de la soberanía alimentaria de las organizaciones de base comunitaria**

Convocatoria cerrada

Fecha de apertura: jueves 17 agosto 2023​

​​​​​Fecha de cierre: lunes 18 septiembre 2023 04:00 pm

Valor financiación: ​$1.600.000.000​​

Objetivo: Invitación a presentar proyectos de soluciones innovadoras desde la CTeI, con enfoque de Apropiación Social del Conocimiento para abordar problemáticas y/o necesidades alrededor de la soberanía alimentaria de las organizaciones de base comunitaria ubicadas en los municipios de Riohacha, Uribia, Maicao y Manaure del departamento de La Guajira.​

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**1051 - Invitación a presentar proyectos de innovación que contribuyan a solucionar los problemas de productividad que impiden la soberanía alimentaria y la construcción de paz de las comunidades negras, afrocolombianas, raizales y palenqueras​**

Convocatoria cerrada

Fecha de apertura: ​jueves 10 agosto 2023

​​​​​Fecha de cierre: jueves 14 septiembre 2023 04:00 pm​

Valor financiación: ​$1.600.000.000​

Objetivo: Invitación a presentar proyectos de innovación construidos en el marco de apropiación social del conocimiento que contribuyan a solucionar los problemas de productividad que impiden asegurar la soberanía alimentaria, el derecho a la alimentación y la construcción de paz de las comunidades negras, afrocolombianas, raizales y palenqueras.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**1049 - Invitación a presentar propuestas para apoyar el desarrollo de expediciones científicas BIO, paz y territorio**

Convocatoria cerrada

Fecha de apertura: ​jueves 29 junio 2023

​​​​​Fecha de cierre: viernes 11 agosto 2023 04:00 pm

Valor financiación: ​$960.000.000

Objetivo: Apoyar el desarrollo de expediciones científicas a través de proyectos de I+D+i que contribuyan a la búsqueda de nuevos usos potenciales de la biodiversidad por medio del aprovechamiento sostenible, intensivo en conocimiento e innovación, así como a la actualización y/o generación de conocimiento en biodiversidad.

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**Convocatoria de Brain Chile 2023**

Convocatoria cerrada

Fecha de apertura: miércoles 25 de enero de 2023

​​​​​​​Fecha de cierre: miércoles 17 de mayo de 2023

Valor financiación: CLP $64.000.000 (COP $350.534.400)

Agregar valor económico, medioambiental y social al país y el mundo, impulsando proyectos de base científico-tecnológica provenientes de instituciones de educación superior nacionales e internacionales, que busquen mejorar la calidad de vida de las personas mediante soluciones innovadoras.​

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**Invitación a presentar propuesta para el diseño de un modelo de financiamiento basal**

Convocatoria cerrada

Fecha de apertura: jueves 23 marzo 2023

​​​​​​​Fecha de cierre: lunes 24 abril 2023 04:00 pm​​​​​​​

Valor financiación: $490.000.000

Diseñar una propuesta de financiamiento basal para el fortalecimiento y sostenibilidad de los Centros/Institutos de investigación autónomos o independientes, Centros/Institutos de investigación dependientes, Centros de desarrollo tecnológico autónomos o independientes, Centros desarrollo tecnológico dependientes en Colombia.​​​​​​​

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**938 - Convocatoria Ecosistemas en Energía Sostenible, Eficiente y Asequible-2023**

Convocatoria cerrada

Fecha de apertura: jueves 30 marzo 2023

​​​​​Fecha de cierre: jueves 15 junio 2023 04:00 pm​​​​​​​

Valor financiación: $6.900.000.000.

​​​​​​​Componente técnico $4.800.000.000. Estancias posdoctorales: $1.800.000.000. Jóvenes investigadores e innovadores: $300.000.000

Conformar un banco de propuestas elegibles de Programas de I+D+i tipo Ecosistema de Investigación e Innovación enfocados en el desarrollo, adopción y adaptación de tecnologías para apoyar el proceso de transición energética del País, basadas en la aplicación de resultados de investigación o la adopción o adaptación de tecnologías convergente.​

**937 - Convocatoria “Investigación Fundamental”**

Convocatoria cerrada

Fecha de apertura: jueves 30 marzo 2023

​​​​​​​Fecha de cierre: jueves 08 junio 2023 04:00 pm​​​​​​​

Valor financiación: $880.000.000Conformar un banco de proyectos elegibles en Investigación Fundamental, orientados a la generación de nuevo conocimiento, en diferentes áreas del conocimiento.​

**936 - Convocatoria ecosistemas en Bioeconomía, ecosistemas naturales, territorios sostenibles**

Convocatoria cerrada

Fecha de apertura: jueves 30 marzo 2023

​​​​​​​Fecha de cierre: jueves 29 junio 2023 04:00 pm

Valor financiación: $6.580.000.000Conformar un banco de propuestas elegibles de Programas de I+D+i tipo Ecosistema de Investigación e Innovación dirigidos a desarrollar soluciones a problemáticas en temáticas de bioeconomía, que permita validar productos y procesos de alto valor agregado en el mercado, basados en la gestión eficiente de la biomasa y el aprovechamiento sostenible de la biodiversidad y sus servicios ecosistémicos, y con esto aportar al desarrollo socioeconómico sostenible del País, desde y para las regiones.​

**935 - Convocatoria Programa Orquídeas, mujeres en la ciencia: Agentes para la Paz**

Convocatoria cerrada

Fecha de apertura: jueves 30 marzo 2023

​​​​​​​Fecha de cierre: martes 23 mayo 2023 04:00 pm

Vinculación de la joven investigadora e innovadora (estudiante): $18.000.000 ($1.500.000 mensual durante 12 meses)

Vinculación de la joven investigadora e innovadora (recién graduada): $30.000.000 ($2.500.000 mensual durante 12 meses)

Apoyo al sostenimiento mensual de la doctora: $120.000.000 ($10.000.000 mensuales durante 12 meses)

Apoyo para el desarrollo de la propuesta a desarrollar durante la Estancia: $50.000.000

Conformar un banco de propuestas elegibles en las cuales se contemple la realización de proyectos de investigación, desarrollo tecnológico y/o innovación (I+D+i), que vinculen Doctoras para llevar a cabo estancias posdoctorales y Jóvenes Investigadora e Innovadoras colombianas, con el fin de intervenir al menos una de las temáticas establecidas en el reto “Poner fin a todas las formas de violencia en Colombia” en el marco de la Misión "Ciencia para la Paz", e incrementar el nivel de desarrollo de vocaciones y capacidades investigativas, científicas, tecnológicas y de innovación de las mujeres en las diferentes regiones de Colombia.​​​​​​​​

**934 - Convocatoria de estancias posdoctorales orientadas por misiones**

Convocatoria cerrada

Fecha de apertura: martes, 28 febrero 2023.​​​​​​​

​​​​​​​Fecha de cierre: jueves 20 abril 2023 04:00 pm

Valor financiación: $290.000.000

Conformar un banco de doctores elegibles para realizar Estancias Posdoctorales en entidades que hagan parte del Sistema Nacional de Ciencia, Tecnología e Innovación. Convocatoria dirigida a profesionales colombianos que cuenten con el título de doctorado o que certifiquen que su tesis de doctorado ha sido sustentada y aprobada al cierre de la convocatoria

Contacto: [formulacion@eafit.edu.co](mailto:formulacion@eafit.edu.co)

**​​​​​​​933 - Convocatoria formación en doctorados nacionales con enfoque territorial, étnico y de género en el marco de la Política Orientada por Misiones**

Convocatoria cerrada

Fecha de apertura: martes, 28 febrero 2023.​​​​​​​​

​​​​​​​Fecha de cierre: miércoles 31 mayo 2023 04:00 pm

Valor financiación: $196.100.000

​Conformar un banco de candidatos elegibles con enfoque territorial, género y étnico para la formación de profesionales en programas de doctorado en Colombia.​

**1049 - Invitación a presentar propuestas para apoyar el desarrollo de expediciones científicas BIO, paz y territorio**

Convocatoria cerrada​

Fecha de apertura: jueves 29 de junio 2023

​​​​​Fecha de cierre: viernes 11 de agosto 2023 04:00 pm​​​​​​

Financiación: Las propuestas de proyectos de I+D+i presentadas no podrán exceder los $960.000.000

Apoyar el desarrollo de expediciones científicas a través de proyectos de I+D+i que contribuyan a la búsqueda de nuevos usos potenciales de la biodiversidad por medio del aprovechamiento sostenible, intensivo en conocimiento e innovación, así como a la actualización y/o generación de conocimiento en biodiversidad.
