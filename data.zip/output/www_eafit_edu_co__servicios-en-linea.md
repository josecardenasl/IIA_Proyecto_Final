Title: Servicios en línea

URL Source: https://www.eafit.edu.co/servicios-en-linea

Markdown Content:
[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/servicios-en-linea#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/servicios-en-linea# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/servicios-en-linea# "English")

Buscar

![Image 6: Imagen de banner ciencias tecnologia e innovaciòn ](https://universidadeafit.widen.net/content/dc255e7f-a198-4245-802b-86457b508777/web/formulario-ciencias-tecnologia-innovacion.jpg?crop=yes&k=c&w=1920&h=788&itok=86oCGFDI)

## Servicios en línea - Aplicaciones web

*   [Inicio](https://www.eafit.edu.co/)
*    Servicios En Línea 

*   [A](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [C](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [D](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [E](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [F](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [G](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [I](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [M](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [O](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [P](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [Q](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [R](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [S](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [T](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [V](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")
*   [Z](https://www.eafit.edu.co/servicios-en-linea "Ancla menú")

###### _

## A

[Activity Insigh​t - Gestión de informaci​ón de profesores Escuela de Administración & Escuela de Economía y Finanzas.​](https://www.digitalmeasures.com/login/co-eafit/faculty/authentication/showLogin.do)

[Activos Fijos - Inventario de muebles y equipos​​](http://webapps.eafit.edu.co/ssf/?_ga=2.206554771.1842434489.1733750963-1410123218.1732207013)

​​[Agenda - Historia Clínica​](https://universidades.imedicalcloud.net/Login.aspx)

[Aranda – Soporte a usuarios de Tecnología y Planta Física](http://saul.eafit.edu.co/USDKV8/Login.aspx)

[Autogestión – Recursos Humanos – Consultar​](https://app.eafit.edu.co/AtgEstandar/www/com.aspsolutions.gwtjforms.GWTJForms/GWTJForms.html?cn=com.atg.form.rhiniatg&war=AtgEstandar&prm1=null&prm2=LDAP&prm3=1&_ga=2.142315186.1842434489.1733750963-1410123218.1732207013)

[Autogestión – Recursos Humanos – Certificados del pago de la seguridad social​​](https://www.aportesenlinea.com/Autoservicio/CertificadoAportes.aspx)

###### _

## C

[Casandra – Desarrollo Artístico: Administración​](http://webapps.eafit.edu.co/casandra/login.do?_ga=2.238953344.1842434489.1733750963-1410123218.1732207013)

[Ceiba – Desarrollo profesional​](https://eafit-csm.symplicity.com/)

[Cesantías - Modulo para la solicitud de cesantías](http://webapps.eafit.edu.co/sibyc/login.do?_ga=2.200686510.1418864605.1643635661-1988501930.1628170644&_gac=1.225640936.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Comercio Electrónico - Pagos y Transacciones de Línea](https://app.eafit.edu.co/ecommerce/)​

​[Cónico - Contratos electrónicos​](https://eafitcontratos.azureedge.net/)

​[Contrata Innovación​](https://apps.powerapps.com/play/e/787444a7-3c73-e45a-80fa-aa0aab1ab101/a/d9ab111a-9ce7-47f7-816e-de4df6f5c313?tenantId=99f7b55e-9cbe-467b-8143-919782918afb&hint=9d0c1171-5fa6-44de-959d-da60cf5ba425&sourcetime=1706128183821)

[Contrata – Proceso de contratación](https://contrata.azureedge.net/#/inicio)

​[Costos ABC - Costeador Administrador](https://abcflex.com.co/eafit/)

​[Costos ABC - Costeo Basado en Actividades](https://abcflex.com.co/encuesta/eafit/)

[CRM Comercial (Sales Cloud)](https://ccaz.fa.us2.oraclecloud.com/)

[CRM Mercadeo (Eloqua)​](https://login.eloqua.com/)

​​[CRM de Servicio (Ivanti)​](https://eafit-amc.ivanticloud.com/)

[Cronos – Sistema para la gestión de compras​​](http://webapps.eafit.edu.co/cronos?_ga=2.237327872.1418864605.1643635661-1988501930.1628170644&_gac=1.217132772.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)​

[Cyco - Cont​ratos y Convenios: Administración​​​​​​](http://webapps.eafit.edu.co/cyco/login.do?_ga=2.237327872.1418864605.1643635661-1988501930.1628170644&_gac=1.217132772.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

###### _

## ​​​D

[Deducciones de Nomina - Modulo para la consulta y realización de deducciones de nomina​​](http://webapps.eafit.edu.co/sibyc/login.do?_ga=2.42477733.1842434489.1733750963-1410123218.1732207013)

[Directorio Telefónico Interno](https://app.eafit.edu.co/directorio)[​​​​](https://app.eafit.edu.co/directorio)

[Docusign](https://account.docusign.com/logout)

## E

​​[EAFIT Interactiva - Gestor de apredizaje​​](https://www.eafit.edu.co/interactiva)

[Epik EAFIT​](https://www.eafit.edu.co/epik)

[Eres EAFIT – Tu ruta de desarrollo](https://www.crehana.com/org/universidad-eafit-medellin/entrar/)

[​Expres – Sistema de información de elecciones profesorales y estudiantiles](https://app.eafit.edu.co/expresAdmin)​

[Extractos Fomune](http://wapp.eafit.edu.co/extractosfomune)

## F

[Fonedi: Administración -Compra de Libros de la Editorial Universidad EAFIT​​](http://webapps.eafit.edu.co/forms/frmservlet?config=appfonedi&amp;_ga=2.202801937.1842434489.1733750963-1410123218.1732207013)

## G

[​​GH - Sistema de Gestión Humana: Solicitud de cargos nuevos para el presupuesto, y consulta de perfiles​](http://webapps.eafit.edu.co/rh/login.do?_ga=2.138422195.1842434489.1733750963-1410123218.1732207013)

[Gestión Documental​](https://eafit.sharepoint.com/sites/Intranet/SitePages/procedimientos-y-formatos-de-centro-de-administracion-documental.aspx?xsdata=MDV8MDJ8fDUxNmU0NjAxZjVhYTRhNjI1OTA4MDhkZGVlZmNlYjBhfDk5ZjdiNTVlOWNiZTQ2N2I4MTQzOTE5NzgyOTE4YWZifDB8MHw2Mzg5Mjk0OTIxOTg5NzE2NTZ8VW5rbm93bnxWR1ZoYlhOVFpXTjFjbWwwZVZObGNuWnBZMlY4ZXlKRFFTSTZJbFJsWVcxelgwRlVVRk5sY25acFkyVmZVMUJQVEU5R0lpd2lWaUk2SWpBdU1DNHdNREF3SWl3aVVDSTZJbGRwYmpNeUlpd2lRVTRpT2lKUGRHaGxjaUlzSWxkVUlqb3hNWDA9fDF8TDJOb1lYUnpMekU1T2pVNE9XSXlaV0l4TFRVNU1EY3ROREl6WmkwNU9XUTNMVGswTURRMFpXTXlNbUkxTmw4NFkyTm1OV1UxTmkxaE1qRTNMVFJqTmpFdFltRXpPQzFtWkRnd01UWmtOREJrTjJaQWRXNXhMbWRpYkM1emNHRmpaWE12YldWemMyRm5aWE12TVRjMU56TTFNalF4T0Rnd01nPT18YmRlNDYyMjY0MzMzNDBlMmVjZWYwOGRkZWVmY2ViMDl8ZjhlMDIxNDJlYWFlNDAzYThjY2U2YmY2YWQ4ZDhmZmI%3D&sdata=RGNlUDUwNUJTdDhMckFSTWhNRzVUTm4wMUhZYlBWaW1FOXRQc2prblBhOD0%3D&ovuser=99f7b55e-9cbe-467b-8143-919782918afb%2Cnlopezs1%40eafit.edu.co&OR=Teams-HL&CT=1757370096377&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiI0OS8yNTA4MTUwMDcxNyIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D)

[Gestión Jurídica​](https://gestionjuridica.spapps.eafit.edu.co/)

## I

[Iniciativas DTI - Formulario de registro de nuevas iniciativas para la Dirección de Tecnologías de la Información​](https://www.eafit.edu.co/iniciativasDTI)

[Intranet Entrenós (Para empleados administrativos y profesores)](https://eafit.sharepoint.com/sites/Intranet)

​[Investiga (Módulo de gestión de proyectos de investigación)​](https://app.eafit.edu.co/investiga/)

​[ISOlución​](http://isolucion.eafit.edu.co/Isolucion)

## M

[Mercurio - Módulo de Gestión de Datos](https://app.eafit.edu.co/mercurio/)

## O

[​OnBase AyR - Gestión de Solicitudes Académicas Admisiones y Registro](https://unieafit.hylandcloud.com/app/203idpserver/Account/Login?ReturnUrl=%2Fapp%2F203idpserver%2Fconnect%2Fauthorize%2Fcallback%3Fresponse_type%3Dcode%26client_id%3D7e775a68-93d4-4192-9f7e-2ec6e3087537%26scope%3Dopenid%26redirect_uri%3Dhttps%253A%252F%252Funieafit.hylandcloud.com%252F203idp%252FLogin.aspx%26state%3DSec-Fetch-Site%253Dcross-site%2526Sec-Fetch-Mode%253Dnavigate%2526Sec-Fetch-User%253D%25253f1%2526Sec-Fetch-Dest%253Ddocument%2526sec-ch-ua%253D%252522Google%252BChrome%252522%25253bv%25253d%252522131%252522%25252c%252B%252522Chromium%252522%25253bv%25253d%252522131%252522%25252c%252B%252522Not_A%252BBrand%252522%25253bv%25253d%25252224%252522%2526sec-ch-ua-mobile%253D%25253f0%2526sec-ch-ua-platform%253D%252522Windows%252522%2526X-Forwarded-For%253D191.91.105.0)

## P

[Paco: Plantilla Contable - Administración](http://webapps.eafit.edu.co/paco/login.do?_ga=2.33370046.1842434489.1733750963-1410123218.1732207013)

[Parqueoo - Servicio de recarga de carné para pago de parqueadero](https://portalrecargas.parqueoo.com/NjM=)

[Parqueoo - Servicio de pago de tiquetes de parqueadero](https://portalpagos.parqueoo.com/NjM=)

[Paz y Salvo - Administración Aplicativo](https://apps.powerapps.com/play/e/787444a7-3c73-e45a-80fa-aa0aab1ab101/a/5000e392-1b40-4850-ba13-a1e7ee70aac1?tenantId=99f7b55e-9cbe-467b-8143-919782918afb&hint=e140b6f6-b482-4349-84a1-78a29c9b1025&sourcetime=1770062343544&source=portal)

[Paz y salvo - Gestión de solicitudes](https://apps.powerapps.com/play/e/787444a7-3c73-e45a-80fa-aa0aab1ab101/a/948642f2-2c9b-40dc-be0d-ba7143c72a9f?tenantId=99f7b55e-9cbe-467b-8143-919782918afb&hint=45373493-e988-453a-8bcb-10b48b8160bf&sourcetime=1770062784171&source=portal)

[​Plataforma π](https://eafit.fundanetsuite.com/IFundanet/Identificacion/IdentificacionFrw.aspx)

[Porcentaje de deducciones – Módulo para la consulta de porcentaje de deducciones del empleado disponible para realización de deducciones de nómina](http://webapps.eafit.edu.co/sibyc/login.do?_ga=2.229472796.1418864605.1643635661-1988501930.1628170644&_gac=1.263409278.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Pulso - Sistema de gestión profesoral](https://eafit.sharepoint.com/sites/Intranet/SitePages/pulso.aspx)

## Q

[Queryx7 – Sist​e​ma Recursos Humanos​](https://app.eafit.edu.co/Queryx7/inicio.do)

## R

[Recaudos - Tesorería](https://app.eafit.edu.co/recaudos/)​

[Reserva de espacios institucionales​](https://www.eafit.edu.co/reserva-espacios)

## S

[Sabe - Sistema de Administración de Becas](https://sabe.azureedge.net/)

[Sade - Sistema Área Desarrollo](http://webapps.eafit.edu.co/sade/)

[Segquim360](https://sigoverplus.com/sigover_quimico/segquim360/eafit//forma/forma_login.php)

​[Sentry - Consola Sentry (Google Chrome)](https://sentry.spapps.eafit.edu.co/VisionCenter/VisioncenterConsolawebcore/consolawebcoreapp#)

[Sentry - Vision Quality](https://sentry.spapps.eafit.edu.co/VisionQualityService/SistemasSentry.VisionQuality.Configuracion/Login.aspx)

[Seven - Sistema de Evaluaciones y Encuestas](http://webapps.eafit.edu.co/seven/index.html?_ga=2.229472796.1418864605.1643635661-1988501930.1628170644&_gac=1.263409278.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Sigavi - Gastos de Viaje](http://webapps.eafit.edu.co/sigavi/login.do?_ga=2.229472796.1418864605.1643635661-1988501930.1628170644&_gac=1.263409278.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Sigeo - Sistema de Información de los Laboratorios de Geología](http://webapps.eafit.edu.co/sigeo/login.do?_ga=2.263541260.1418864605.1643635661-1988501930.1628170644&_gac=1.222447337.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Sipres - Información Presupuestal](http://webapps.eafit.edu.co/sipres/login.do?_ga=2.263541260.1418864605.1643635661-1988501930.1628170644&_gac=1.222447337.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Siscar - Control y Administración de Recursos Estáticos y Dinámico](http://webapps.eafit.edu.co/siscar?_ga=2.263541260.1418864605.1643635661-1988501930.1628170644&_gac=1.222447337.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Sócrates - Sistema de información Sislenguas](http://webapps.eafit.edu.co/socrates/index.html?_ga=2.263541260.1418864605.1643635661-1988501930.1628170644&_gac=1.222447337.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)

[Software para eafitenses​​](https://www.eafit.edu.co/software)[​](http://webapps.eafit.edu.co/sigeo/login.do?_ga=2.199635502.1418864605.1643635661-1988501930.1628170644&_gac=1.258041336.1642694972.CjwKCAjw8-78BRA0EiwAFUw8LFMZq8qZ4RNb3W8LpYXlMg_1zKSc5U_YDtBr3ihIUzSHf4hX6dSBMhoCwtEQAvD_BwE)​

## T

[Taquillas virtuales​](https://customers.wolkvox.com/clicktocall/eafit/)

## V

[Vacaciones- Solicitud de vacaciones](https://apps.powerapps.com/play/e/baeef8d4-c861-e386-9f64-627d54fabc1e/a/9ba22020-2396-4706-afee-ff4978ffac65?tenantId=99f7b55e-9cbe-467b-8143-919782918afb&hint=da093ea7-0815-49b5-84e1-780e6d4a9db4&sourcetime=1755708197692)

## Z

[Zeus - Módulo de Asignación Docente​.](https://app.eafit.edu.co/zeus/)

![Image 7: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 8: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 9: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 10: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 11: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 12: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 13: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 14: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
