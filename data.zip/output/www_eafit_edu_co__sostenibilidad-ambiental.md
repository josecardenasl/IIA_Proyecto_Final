Title: Sostenibilidad ambiental​

URL Source: https://www.eafit.edu.co/sostenibilidad-ambiental

Markdown Content:
# Sostenibilidad ambiental​
[Pasar al contenido principal](https://www.eafit.edu.co/sostenibilidad-ambiental#main-content)

[![Image 3: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sostenibilidad-ambiental#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sostenibilidad-ambiental# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sostenibilidad-ambiental# "English")

 Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 8: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 9: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 10: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 11: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 12: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 14: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 15: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 16: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 17: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 18: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 19: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 20: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 21: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 22: Imagen de campus EAFIT ](https://universidadeafit.widen.net/content/2cc4228d-c461-4e0a-b49b-9175313f5acc/web/pimientos.jpg?crop=yes&k=c&w=1920&h=788&itok=Dch3l0ZV)

# Sostenibilidad ambiental

EAFIT, una Universidad Parque

 Universidad Parque es un modelo de Institución educativa en la cual conviven en armonía lo académico, lo cultural y lo ambiental, y pone en otra dimensión las nociones de movilidad y estadía, de caminar y hacer una pausa, la idea de transformar el ambiente y el campus universitario en un lugar en que conviven la academia y la naturaleza

*   [Inicio](https://www.eafit.edu.co/)
*    Sostenibilidad Ambiental​ 

### ​ODS priorizados por el Sistema de Gestión Ambiental​

[![Image 23: Imagen de agua limpia y saneamiento](https://universidadeafit.widen.net/content/0e197f0a-c0cc-4513-b3cf-9e360538ccce/web/agua-limpia-saneamiento.jpg)](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 24](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Ver más](https://www.un.org/sustainabledevelopment/es/water-and-sanitation/)

[![Image 25: Imagen de energía asequible y no contaminante](https://universidadeafit.widen.net/content/893aa808-039f-49ff-bab5-77ae31e72e7e/web/energia-asequible-no-contaminantes.jpg)](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 26](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Ver más](https://www.un.org/sustainabledevelopment/es/energy/)

[![Image 27: Imagen de industria, innovación e infraestructura](https://universidadeafit.widen.net/content/4538e97f-3a3f-44b4-b028-bc1f64a9f15d/web/industria-innovacion-infraestructura.jpg)](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 28](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Ver más](https://www.un.org/sustainabledevelopment/es/infrastructure/)

[![Image 29: Imagen de ciudades y comunidades sostenibles](https://universidadeafit.widen.net/content/d94a0d3b-0589-4a9c-939d-83faa7c87d5b/web/ciudades-cominidades-sostenibles.jpg)](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 30](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Ver más](https://www.un.org/sustainabledevelopment/es/cities/)

[![Image 31: Imagen de producción y consumo responsables](https://universidadeafit.widen.net/content/ae7a04d7-d3ff-4eb6-9a57-9653d13b903b/web/produccion-consumo-responsable.jpg)](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 32](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Ver más](https://www.un.org/sustainabledevelopment/es/sustainable-consumption-production/)

[![Image 33: Imagen de Acción por el clima](https://universidadeafit.widen.net/content/3390f22a-0397-4cae-8d65-2474d8c2945b/web/accion-por-el-clima.jpg)](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 34](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Ver más](https://www.un.org/sustainabledevelopment/es/climate-change-2/)

[![Image 35: Imagen de vida de ecosistemas terrestres](https://universidadeafit.widen.net/content/5a9ea98b-d75b-463a-96ed-4b0b50564bf6/web/vida-de-ecosistemas-terrestres.jpg)](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 36](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Ver más](https://www.un.org/sustainabledevelopment/es/biodiversity/)

​​​​​​​Nuestra gestión

## Vegetación y fauna

[Conoce Vegetación y fauna](https://www.eafit.edu.co/sostenibilidad-ambiental/vegetacion-y-fauna)

## Infraestructura

[Conoce Infraestructura](https://www.eafit.edu.co/sostenibilidad-ambiental/infraestructura)

## Agua

[Conoce Agua](https://www.eafit.edu.co/sostenibilidad-ambiental/agua)

## Residuos

[Conoce Residuos](https://www.eafit.edu.co/sostenibilidad-ambiental/residuos)

## Energía

[Conoce Energía](https://www.eafit.edu.co/sostenibilidad-ambiental/energia)

## Papel

[Conoce Papel](https://www.eafit.edu.co/sostenibilidad-ambiental/papel)

## Educación y divulgación

[Conoce Educación y divulgación](https://www.eafit.edu.co/sostenibilidad-ambiental/educacion-y-divulgacion)

## Compras sostenibles

[Conoce Compras sostenibles](https://www.eafit.edu.co/sostenibilidad-ambiental/compras-sostenibles)

## Movilidad

[Conoce Movilidad](https://www.eafit.edu.co/sostenibilidad-ambiental/movilidad)

## Plástico

[Conoce Plástico](https://www.eafit.edu.co/sostenibilidad-ambiental/plastico)

![Image 37: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

Sobre nosotros​​

![Image 38: Imagen Cambio Climático](https://universidadeafit.widen.net/content/3c303b93-0466-48aa-9144-429e67eac92d/web/el-jardin-de-cachi.jpg?crop=yes&k=c&w=397&h=253&itok=vY2PYObo)

Cambio Climático

[Conoce Cambio Climático](https://www.eafit.edu.co/sostenibilidad-ambiental/cambio-climatico)

![Image 39: Imagen Lineamientos y política ambiental](https://universidadeafit.widen.net/content/7955a5f6-55cd-4bca-9ebe-afdf4293543b/web/premiolapizdeacero.jpg?crop=yes&k=c&w=397&h=253&itok=T4dryZF8)

Lineamientos y política ambiental

[Conoce Lineamientos y política ambiental](https://www.eafit.edu.co/sostenibilidad-ambiental/lineamientos-politica-ambiental)

![Image 40: Imagen Cifras ambientales](https://universidadeafit.widen.net/content/381124fe-dbc4-4f21-ab27-0e6b596ee4b3/web/parque-guayabos.jpg?crop=yes&k=c&w=397&h=253&itok=xSl9KvhS)

Cifras ambientales

[Conoce Cifras ambientales](https://www.eafit.edu.co/sostenibilidad-ambiental/cifras-ambientales)

![Image 41: Imagen Publicaciones](https://universidadeafit.widen.net/content/034d6acf-6ac0-4e17-8d84-a7dc4e59b062/web/comite-de-etica.jpg?crop=yes&k=c&w=397&h=253&itok=iOUeHQJF)

Publicaciones

[Conoce Publicaciones](https://www.eafit.edu.co/sostenibilidad-ambiental/publicaciones)

Noticias sob​​​re Sostenibilidad

![Image 42: Imagen SOMOS UNO CON LA NATURALEZA.](https://universidadeafit.widen.net/content/2cc4228d-c461-4e0a-b49b-9175313f5acc/web/pimientos.jpg?crop=yes&k=c&w=397&h=253&itok=nOjv7Zw2)

SOMOS UNO CON LA NATURALEZA.

Propuestas para reimaginar el futuro y cambiar le presente.

[Conoce SOMOS UNO CON LA NATURALEZA.](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 43: Imagen ](https://universidadeafit.widen.net/content/57972c07-3cd4-4368-8cff-86e72bd80413/web/vestigios-de-la-guerra.jpg?crop=yes&k=c&w=397&h=253&itok=ZtbQ2-GE)

Ante los desafíos de un planeta en crisis, la sostenibilidad también se vive en clave empresarial.

[Conoce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 44: Imagen ](https://universidadeafit.widen.net/content/00fe37b1-3bf5-43ae-9544-a50ad32ae004/web/panico.jpg?crop=yes&k=c&w=397&h=253&itok=vMOyJ1gc)

Correos electrónicos innecesarios incrementan la crisis de almacenamiento global y la huella de carbono.

[Conce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 45: Imagen ](https://universidadeafit.widen.net/content/00fe37b1-3bf5-43ae-9544-a50ad32ae004/web/panico.jpg?crop=yes&k=c&w=397&h=253&itok=vMOyJ1gc)

¿Cómo aportan los correos electrónicos innecesarios a la crisis de almacenamiento global y aumentan la huella de carbono?

[Conoce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 46: Imagen ](https://universidadeafit.widen.net/content/01bd3247-a758-44e7-b2b9-bc08d6652fc3/web/estudiantes-en-clase-2.png?crop=yes&k=c&w=397&h=253&itok=UeMfvvaA)

¿Qué son los riesgos Natech? EAFIT sabe cómo identificarlos y mitigarlos

[Conoce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 47: Imagen ](https://universidadeafit.widen.net/content/eb44133f-ad7e-4257-b5ef-21fd1262e3b6/web/DIalogos-ISA.jpg?crop=yes&k=c&w=397&h=253&itok=NF7kmZtC)

Estudio revela que el 91% de encuestados prioriza la transición energética en la agenda nacional

[Conoce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 48: Imagen ](https://universidadeafit.widen.net/content/2cf87443-2409-4bbc-847b-e01a2fc5c0e3/web/campus-universitario-bloque-biblioteca.jpg?crop=yes&k=c&w=397&h=253&itok=FY7rVIMx)

EAFIT se transforma para cumplir el propósito de ser positivos para la naturaleza

[Conoce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 49: Imagen ](https://universidadeafit.widen.net/content/652af366-ac34-447b-9c7c-9910c6e84836/web/parque-cti2.jpg?crop=yes&k=c&w=397&h=253&itok=wM3Vv6vX)

Cada acción cuenta

[Conoce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 50: Imagen ](https://universidadeafit.widen.net/content/8d25aaa0-ca61-4366-bace-64298ce27e16/web/fachada-biblioteca-home.jpg?crop=yes&k=c&w=397&h=253&itok=mJASrv3L)

La milla extra ya no es una opción

[Conce más](https://www.eafit.edu.co/sostenibilidad-ambiental)

[Conoce más noticias](https://www.eafit.edu.co/filantropia/noticias)

Contacto

### Daniel Alejandro Pineda Pulgarín​

Analista de Gestión Ambiental. Gestión del Campus.

[dapineda@eafit.edu.co​](https://www.eafit.edu.co/sostenibilidad-ambiental)

### Juan David Franco Espinosa ​

Coordinador de Servicios Generales. Gestión del Campus.

[jdfrancoe@eafit.edu.co​​](https://www.eafit.edu.co/sostenibilidad-ambiental)

![Image 51: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 52: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 53: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 54: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 55: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 56: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 57: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 58: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
