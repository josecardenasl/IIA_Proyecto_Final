Title: Energy Valley

URL Source: https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley

Markdown Content:
# Energy Valley - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de Serena en el rio](https://universidadeafit.widen.net/content/c1b7d920-f4c9-46b0-9c3e-6005b55aab1c/web/serena-banner-energy-valley.jpg?crop=yes&k=c&w=1920&h=788&itok=01fwK8p1)

# Energy Valley

###### Centro Avanzado de Energía.

*   [Inicio](https://www.eafit.edu.co/)
*   [​​​​​​​​​​Centros de Estudio ​e Incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
*    Energy Valley 

###### Energy Valley, el Centro Avanzado de Energía, es una iniciativa acompañada por la Universidad EIA, la Alcaldía de Medellín y aliados empresariales como Erco Energía, Celsia, Grupo EPM, ISA y Azimut.

###### Aquí se formará el talento que el mercado todavía no sabe que necesita. Se probarán tecnologías en entornos reales, se analizarán las condiciones del entorno (política, regulación, mercado y aspectos sociales) y la ciencia se convertirá en soluciones que la gente pueda ver, tocar y usar.

###### Un lugar para los que construyen el futuro energético.

Para probar y validar tecnologías antes de llevarlas al mundo real.

Para formar el talento especializado que el sector va a necesitar.

Para conectar ideas con capital y llevarlas al mercado.

Para ser un Sandbox regulatorio que permita adoptar la política pública a los avances del sector.

Energy Valley tiene todo para ser el referente energético de América Latina.

[¿Quieres ser parte?](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley#contacto)

Informes y documentos

![Image 22: Imagen Informe señales y tendencias sector nergía en América Latina](https://universidadeafit.widen.net/content/34301a72-7efd-43a1-ad60-73231c21792d/web/informe-energia-latam-energy-valley.png?crop=yes&k=c&w=397&h=253&itok=ea6yi0sR)

Informe señales y tendencias sector nergía en América Latina

[Conoce el informe](https://universidadeafit.widen.net/s/8r9z5jwdm5/informe-tendencia-energia-latam)

![Image 23: Imagen Energy Transition, Distributed Energy Resources, and Flexibility Services: A Systematic Literature Review ](https://universidadeafit.widen.net/content/371edada-81fc-4137-8a74-b954dc6858d5/web/informe-energy-transition-energy-valley.png?crop=yes&k=c&w=397&h=253&itok=kWqWeneD)

Energy Transition, Distributed Energy Resources, and Flexibility Services: A Systematic Literature Review

[Conoce el informe](https://universidadeafit.widen.net/view/pdf/huscm33tth/EnergyTransition-DistributedEnergyResources-andFlexibilityServices-ASystematicLiteratureReview.pdf?t.download=true&u=amlqiy)

## Modelo de operación

### Un ecosistema en movimiento

> ###### "En Energy Valley, la energía se potencia a través de la articulación de cuatro frentes estratégicos que conectan el conocimiento con la industria."

## Comunidad y Conexiones Inteligentes

Este es el punto de encuentro para el networking y el intercambio de ideas. 

 Servicios: Coworking, eventos especializados, Energy Talks, Demodays y Hackatones. 

 ¿Quiénes confluyen?: Profesionales de empresas, investigadores, académicos (MSc y PhD), estudiantes y emprendedores.

## Proyectos CTel (Ciencia, Tecnología e Innovación)

Desarrollo de soluciones reales mediante ciencia aplicada. 

 Líneas de acción: Estructuración y ejecución de proyectos, testeo de tecnologías, transferencia de conocimiento y co-desarrollo. 

 Enfoque técnico: Electrificación avanzada, recursos distribuidos y mercados de energía.

![Image 24: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Laboratorios y Servicios Técnicos

Infraestructura de vanguardia para validar el futuro energético. 

 Capacidades: Diseño, integración y validación de tecnologías. 

 Oferta: Estructuración de nuevos laboratorios, servicios de ensayo, testeo/pruebas y modelos de co-inversión con riesgo compartido.

## Formación de Talento Especializado

Programas a la medida para cerrar la brecha de conocimiento en el sector. 

 Niveles: Pregrado, posgrado y educación para toda la vida. 

 Estrategias: Upskilling, Reskilling, cursos cortos y procesos de incubación.

![Image 25: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Aliados y apoyos

![Image 26: Imagen ](https://universidadeafit.widen.net/content/455ed9e0-25dd-46dc-b09d-f242c84c0939/web/erco-energy.png)

![Image 27: Imagen ](https://universidadeafit.widen.net/content/d29c7b0a-e60a-45e3-937a-8262749d8aaa/web/celsia-logo-energy.png)

![Image 28: Imagen ](https://universidadeafit.widen.net/content/90a987a8-b12e-49a6-b281-b83c95d9974e/web/grupo-epm-energy.png)

![Image 29: Imagen ](https://universidadeafit.widen.net/content/0b578f10-a37b-4bd0-982e-818288831c2d/web/azimut-energy.png)

![Image 30: Imagen ](https://universidadeafit.widen.net/content/7dde9abb-318c-4ad8-bd16-52a270165c58/web/eia-energy.png)

![Image 31: Imagen ](https://universidadeafit.widen.net/content/ad56740a-54f5-4e09-8092-de6a444019a7/web/alcaldia-medellin-ctei-energy.png)

### **Sobre el Centro y la Energía**

#### Llega Energy Valley: Centro Avanzado de Energía en Colombia

#### Imaginar Colombia - Energía eléctrica

#### El poder del prototipo | Ricardo Mejia | TEDxUniversidad EAFIT

En los medios

![Image 32: Imagen “Energy Valley nació para resolver problemas del sector energético en Colombia y el mundo”](https://universidadeafit.widen.net/content/4a7a56b4-39a1-4ff7-bfed-0821bbb24253/web/energy-valley-nota-la-republica1.png?crop=yes&k=c&w=397&h=253&itok=L9bSG4xB)

“Energy Valley nació para resolver problemas del sector energético en Colombia y el mundo”

[Lee la nota](https://www.larepublica.co/especiales/ciencia-tecnologia-y-talento-para-el-futuro-energetico/ricardo-mejia-gutierrez-director-ejecutivo-de-energy-valley-centro-avanzado-de-energia-dijo-que-desarrollaron-el-primer-bote-solar-de-colombia-4372071)

![Image 33: Imagen &quot;No sólo vamos a adoptar tecnología, sino que vamos a empezar a diseñar y fabricar&quot;](https://universidadeafit.widen.net/content/edd07d41-219d-498f-921f-d0b7c51d51a1/web/energy-valley-nota-la-republica2.png?crop=yes&k=c&w=397&h=253&itok=quX_fj0U)

"No sólo vamos a adoptar tecnología, sino que vamos a empezar a diseñar y fabricar"

[Conoce más](https://www.larepublica.co/especiales/ciencia-tecnologia-y-talento-para-el-futuro-energetico/entrevista-con-juan-esteban-hincapie-co-fundador-de-erco-energia-quien-hablo-sobre-el-futuro-de-la-industria-energetica-en-colombia-4372049)

![Image 34: Imagen La energía como decisión de país: capacidades para su transformación](https://universidadeafit.widen.net/content/57c96a97-5504-40b5-92ce-af12a563d065/web/energy-valley-nota-la-republica3.png?crop=yes&k=c&w=397&h=253&itok=EkqEXuXl)

La energía como decisión de país: capacidades para su transformación

[Leer más](https://www.larepublica.co/especiales/ciencia-tecnologia-y-talento-para-el-futuro-energetico/la-energia-como-decision-de-pais-capacidades-para-su-transformacion-4371990)

![Image 35: Imagen Hoy se presenta en Medellín el Energy Valley como Centro Avanzado de Energía](https://universidadeafit.widen.net/content/1960da6d-5d89-4444-99ca-b958038ae6b2/web/energy-valley-nota-la-republica4.png?crop=yes&k=c&w=397&h=253&itok=re7MUG6U)

Hoy se presenta en Medellín el Energy Valley como Centro Avanzado de Energía

[Leer más](https://caracol.com.co/2026/04/16/hoy-se-presenta-en-medellin-el-energy-valley-como-centro-avanzado-de-energia/)

![Image 36: Imagen “Hay déficit de energía firme, faltan KW para atender la demanda entre 2027 y 2030”](https://universidadeafit.widen.net/content/40372f3c-f658-47d7-b599-bd1d54e78bff/web/energy-valley-nota-la-republica5.png?crop=yes&k=c&w=397&h=253&itok=Gjt9R4f-)

“Hay déficit de energía firme, faltan KW para atender la demanda entre 2027 y 2030”

[Leer más](https://www.larepublica.co/especiales/ciencia-tecnologia-y-talento-para-el-futuro-energetico/entrevista-con-ricardo-sierra-lider-de-celsia-quien-hablo-sobre-los-retos-del-sistema-energetico-colombiano-4372032)

### Colabora en la transición energética

¡Escríbenos y cuéntanos tus ideas!

 energy.valley@eafit.edu.co

[](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley)

![Image 37: Imagen Colabora en la transición energética](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley)

![Image 38: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 39: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 40: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 41: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 42: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 43: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 44: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 45: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 46](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
