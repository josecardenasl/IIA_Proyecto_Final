Title: Maria Andrea De Villa Correa, nueva decana de la Escuela de Administración

URL Source: https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026/maria-andrea-de-villa-correa-nueva-decana-escuela-administracion

Markdown Content:
# Maria Andrea De Villa Correa, nueva decana de la Escuela de Administración - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026/maria-andrea-de-villa-correa-nueva-decana-escuela-administracion#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026/maria-andrea-de-villa-correa-nueva-decana-escuela-administracion#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026/maria-andrea-de-villa-correa-nueva-decana-escuela-administracion# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026/maria-andrea-de-villa-correa-nueva-decana-escuela-administracion# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: banner de comunicados](https://universidadeafit.widen.net/content/e21d876e-92e7-4efb-bfa2-770ef03a7826/web/comunicados3.jpg?crop=yes&k=c&w=1920&h=788&itok=aq4UtMEw)

# María Andrea De Villa Correa,

###### nueva decana de la Escuela de Administración

*   [Inicio](https://www.eafit.edu.co/)
*   [Información Institucional](https://www.eafit.edu.co/institucional)
*   [Comunicados Institucionales](https://www.eafit.edu.co/institucional/comunicados-institucionales)
*   [Comunicados 2026](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)
*    Maria Andrea De Villa Correa, Nueva Decana de La Escuela de Administración 

"La Escuela de Administración debe contribuir al desarrollo sostenible de la sociedad, conectando actores y conocimiento para transformar realidades y generar esperanza. Su liderazgo debe promover la integridad, el pensamiento crítico y estratégico, la investigación de alta calidad y el compromiso con la transformación del entorno. Nuestra trayectoria colectiva nos ha permitido llegar hasta aquí, gracias al aporte de muchas personas, que nos inspira a seguir innovando, imaginando y construyendo futuro. Asumo esta decanatura con entusiasmo y el firme compromiso de impulsar un diálogo constante para anticipar y contribuir a los desafíos de nuestro tiempo con creatividad, rigor y pertinencia".

 María Andrea De Villa

![Image 22: Imagen ](https://universidadeafit.widen.net/content/ef200c02-d0a6-403c-ba55-cec04ba36b02/web/maria-andrea-de-villa-28012026.jpg)

Estimada comunidad eafitense,

Me complace compartirles el nombramiento de la profesora María Andrea De Villa Correa como decana de la Escuela de Administración, designación que fue ratificada por el Consejo Directivo de la Universidad en su sesión del 28 de enero de 2026 y que entrará en vigor a partir del 2 de febrero del presente año.

Asume este cargo tras la gestión de[Cristina Vélez Valencia](https://nam10.safelinks.protection.outlook.com/?url=https%3A%2F%2Fs60148679.t.en25.com%2Fe%2Fer%3Fs%3D60148679%26lid%3D15767%26elqTrackId%3D492AD2732DFB5E05F35DA9BC86C2B9BD%26elq%3Ddc0c9e0f8d384cf19cf24efeccb7358b%26elqaid%3D30307%26elqat%3D1%26elqak%3D8AF5E3E9CA48318DFEEA79142905ACD5D3173593D4FEF3326A9F947D85811ACC886F&data=05%7C02%7Cnlopezs1%40eafit.edu.co%7C6f468e5887b248f9fd4508de5eb589bf%7C99f7b55e9cbe467b8143919782918afb%7C0%7C0%7C639052330958883811%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=QijDnY8V4FoQJr6fgK2jhjSQPXtRPJ3oB45Wlz80oXU%3D&reserved=0), quien se desempeñó como decana entre 2021 y 2025, y de [Carlos Mario Betancur Hurtado](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2025/%20carlos-mario-betancur-hurtado-asume-como-decano-encargado-de-la-escuela-de-administracion), quien asumió el rol de decano encargado desde el 11 de diciembre de 2025.

María Andrea cuenta con una trayectoria académica de más de dos décadas dedicada a la docencia, la investigación, la gestión institucional, la consultoría y la cocreación de proyectos con el sector empresarial. Es doctora en Administración con énfasis en Estrategia de Cranfield University (Reino Unido); y magíster en Administración, especialista en Mercadeo y negociadora internacional de la Universidad EAFIT. Además, tiene estudios adicionales en formación ejecutiva en Global Strategic Management de Harvard University (Estados Unidos), y en Strategic Performance Management de University of Cambridge (Inglaterra).

Desde 2004 ha estado vinculada a la Escuela de Administración de EAFIT, donde se ha desempeñado como directora académica de Alta Dirección, jefa de la maestría en Administración, líder de Acreditación Internacional Association of MBAs (AMBA), coordinadora del Programa Expopyme, en alianza con Procolombia, y profesora distinguida desde 2024. También ha sido profesora visitante en instituciones como la Universidad de Michigan (Estados Unidos); Aalto University (Finlandia); Université Catholique De L’Ouest (Francia); ESAN (Perú); University of Pula (Croacía); y University of Warwick (Inglaterra); e investigadora invitada en Northeastern University (Estados Unidos).

Como parte de esa trayectoria ha sido autora de artículos científicos, libros, capítulos de libros y ponencias sobre estrategia de no-mercado para abordar los entornos y riesgos socio-políticos, estrategia como práctica y proceso, estrategia para abordar grandes retos como el cambio climático y métodos cualitativos, y sus investigaciones han sido publicadas en revistas especializadas como Global Strategy Journal, International Business Review, Thunderbird International Business Review, Journal of International Management, AIB Insights, Academia Revista Latinoamericana de Administración y Revista Administer, entre otras.

Su trayectoria ha sido reconocida con distinciones como el Premio Global Strategy Journal Best Paper Prize de la Strategic Management Society, y el reconocimiento como finalista al Gunnar-Hedlund Award, otorgado por Stockholm School of Economics & European International Business Academy. En 2025, EAFIT le otorgó el Premio Ciencia, Tecnología e Innovación - Carreras de excelencia en ciencia, tecnología e innovación, en la Categoría Carrera destacada en CTeI.

Ha sido beneficiaria de fondos internacionales para la investigación otorgados por la Strategic Management Society y, en la actualidad, es representative-at-Large de los grupos de interés de Estrategia Global y Estrategia como Práctica de la Strategic Management Society; communications editor de Long Range Planning; co-editora de una edición especial de Journal of International Business Studies; e integrante de los comités evaluadores de las revistas Long Range Planning, Global Strategy Journal, Strategic Organization, Multinational Business Review , entre otras publicaciones del campo de la administración de manera ad-hoc.

También es integrante de Academy of Management, Strategic Management Society, Academy of International Business, Comité Cientifíco Asesor de Qualitative Comparative Analysis (QCA) of the Americas Conference, e integrante afiliada a The METHOS Lab (MEthods, THeories, Organizations, and Society), de HEC Montreal (Canadá).

Reiteramos nuestra gratitud a Cristina Vélez por su liderazgo al frente de la decanatura de la Escuela, que se distinguió por una visión estratégica y un firme compromiso con la excelencia, fortaleciendo la articulación entre la academia, las organizaciones y la sociedad. Y por una gestión que impulsó hitos como la acreditación internacional AACSB, la consolidación del Centro In-Sight y avances clave en la transformación curricular y el trabajo interdisciplinario. Mensaje que también extendemos a Carlos Mario por las semanas que estuvo al frente de esta Escuela con el deseo de muchos éxitos en la continuidad de su rol como decano asociado.

A María Andrea, por su parte, le expresamos un cálido mensaje de bienvenida como decana de la Escuela de Administración. Su llegada a este rol representa una oportunidad para seguir consolidando esta unidad académica, llamada a integrar y proyectar sus diferentes saberes y capacidades, en conexión con los desafíos y oportunidades globales en asuntos como liderazgo empresarial, estrategia, dirección, comprensión de los mercados, gestión del talento humano, internacionalización y gobierno corporativo.

Atentamente,

**Claudia Restrepo Montoya**

**Rectora**

Comunicado n° 3

Medellín, 28 de enero de 2026

![Image 23: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 24: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 25: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 26: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 27: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 28: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 29: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 30: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 31](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
