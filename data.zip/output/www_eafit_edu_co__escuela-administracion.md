Title: Escuela Administración

URL Source: https://www.eafit.edu.co/escuela-administracion

Markdown Content:
# Escuela Administración - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/escuela-administracion#main-content)

[![Image 43: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 44: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 45: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-administracion#)

[![Image 46: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-administracion# "Spanish")[![Image 47: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/escuela-administracion# "English")

*   [Spanish](https://www.eafit.edu.co/escuela-administracion)
*   [Inglés](https://www.eafit.edu.co/en/escuela-administracion)

 Información para ti

[![Image 48: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 49: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 50: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 51: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 52: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 53: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 54: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 55: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 56: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 57: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 58: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 59: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 60: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 61: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 62: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 63: Imagen del bloque 26 en el campus Medellín](https://universidadeafit.widen.net/content/f82a72ac-89bf-4b10-bb4a-43db9c121a45/web/bloque26conpersonas.jpg?crop=yes&k=c&w=1920&h=788&itok=5A-BDtTm)

# Escuela de Administración

¡En la Escuela de Administración hacemos que las cosas pasen! 

 ​Aquí combinamos diversas metodologías de aprendizaje para que tu camino profesional continúe a grandes pasos. 

 ¡Gracias por ser parte de este reto!​​

*   [Inicio](https://www.eafit.edu.co/)
*    Escuela Administración 

Filtros

*   [Posgrados(45)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=tipo_de_programa_admin%3Aposgrados)
*   [Pregrados(4)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=tipo_de_programa_admin%3Apregrados)

Facet Tipo de programa admin 

*   [Organización, Dirección y Estrategia(37)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=area_de_conocimiento_pre_pos_admin2%3A1606)
*   [Marketing e Innovación(5)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=area_de_conocimiento_pre_pos_admin2%3A1621)
*   [Mercados y Estrategia Financiera(2)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=area_de_conocimiento_pre_pos_admin2%3A1626)
*   [Políticas y Desarrollo(2)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=area_de_conocimiento_pre_pos_admin2%3A1636)
*   [Derecho y economía(1)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=area_de_conocimiento_pre_pos_admin2%3A1561)
*   [Gestión de la Información y de Riesgos(1)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=area_de_conocimiento_pre_pos_admin2%3A1616)
*   [Gestión Global(1)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=area_de_conocimiento_pre_pos_admin2%3A1611)

Facet Área de conocimiento pre pos admin2 

*   [Presencial(38)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=modalidad_pre_pos_admin%3A101)
*   [Blended(8)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=modalidad_pre_pos_admin%3A96)
*   [Virtual(3)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=modalidad_pre_pos_admin%3A106)

Facet Modalidad pre pos admin 

*   [Medellín(34)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=sedes_pre_pos_admin%3A121)
*   [Pereira(8)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=sedes_pre_pos_admin%3A126)
*   [Bogotá(4)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=sedes_pre_pos_admin%3A111)
*   [Popayán(3)](https://www.eafit.edu.co/escuela-administracion?f%5B0%5D=sedes_pre_pos_admin%3A186)

Facet Sedes pre pos admin 

#### Especialización en Gerencia de Instituciones de la Salud - Virtual

![Image 64: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 65: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín (virtual) 

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Sincrónico y asincrónico (virtual) 

![Image 67: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 68: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Virtual

![Image 69: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 101586

![Image 70: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$28.340.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/especializacion-en-gerencia-de-instituciones-de-la-salud-virtual "Ver posgrado")

#### Maestría en Gerencia de Instituciones de la Salud​​​​ - Bogotá

![Image 71: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 72: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Bogotá

![Image 73: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Presencial cada 15 días

Más información

Presencial cada 15 días, modalidad Blended. 

 Las asignaturas con 32 créditos tendrán sesiones virtuales. 

![Image 74: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma 

Español

![Image 75: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Blended

![Image 76: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 77: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$59.268.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/maestria-en-gerencia-de-instituciones-de-la-salud-bogota "Ver posgrado")

#### Especialización en Gerencia de Instituciones de la Salud​​​​​ - Bogotá

![Image 78: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 79: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Bogotá

![Image 80: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Presencial cada 15 días

Más información

Presencial cada 15 días, modalidad Blended. 

 Las asignaturas con 32 créditos tendrán sesiones virtuales. 

![Image 81: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 82: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Blended

![Image 83: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 84: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$35.022.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/especializacion-en-gerencia-de-instituciones-de-la-salud-bogota "Ver posgrado")

#### Especialización en Gerencia de Instituciones de la Salud​​​​​ - Pereira

![Image 85: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 86: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Pereira

![Image 87: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábado

Más información

Clases presenciales cada 15 días. 

 Viernes de 5:00pm a 9:00pm y sábado de 8:00am a 12:00p.m. y 1:00pm a 5:00pm. 

 Materias de 32 horas 8 horas adicionales remotas.

![Image 88: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 89: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 90: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 91: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$28.782.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/especializacion-en-gerencia-de-instituciones-de-la-salud-pereira "Ver posgrado")

#### Especialización en Gerencia de Proyectos - Bogotá

![Image 92: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 93: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Bogotá

![Image 94: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábado

Más información

6:00 a 9:00 pm viernes

 08:00 am a 05:00 p.m sábado 

![Image 95: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 96: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 97: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 98: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$35.100.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/especializacion-gerencia-proyectos-bogota "Ver posgrado")

#### Especialización en Gerencia del Desarrollo Humano - Bogotá

![Image 99: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 semestres

![Image 100: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Bogotá

![Image 101: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábado

Más información

V_18:30 - 21:00 y S_7:30-12:00 y 13:00 a 17:00

![Image 102: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma 

Español

![Image 103: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 104: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 105: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$34.000.018

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/especializacion-en-gerencia-del-desarrollo-humano-bogota "Ver posgrado")

*   [Página actual 1](https://www.eafit.edu.co/escuela-administracion?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/escuela-administracion?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/escuela-administracion?label=&page=2 "Ir a la página 3")
*   [Página 4](https://www.eafit.edu.co/escuela-administracion?label=&page=3 "Ir a la página 4")
*   [Página 5](https://www.eafit.edu.co/escuela-administracion?label=&page=4 "Ir a la página 5")
*   [Página 6](https://www.eafit.edu.co/escuela-administracion?label=&page=5 "Ir a la página 6")
*   [Página 7](https://www.eafit.edu.co/escuela-administracion?label=&page=6 "Ir a la página 7")
*   [Página 8](https://www.eafit.edu.co/escuela-administracion?label=&page=7 "Ir a la página 8")
*   [Página 9](https://www.eafit.edu.co/escuela-administracion?label=&page=8 "Ir a la página 9")
*   [Siguiente página›](https://www.eafit.edu.co/escuela-administracion?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/escuela-administracion?label=&page=8 "Ir a la última página")

## Contenidos diferenciales de la escuela

[Campus transformador](https://www.eafit.edu.co/escuela-administracion#4257225834-1433553821)

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

MercaLab, un espacio para enfrentar los retos de las organizaciones; Aula Makers, un escenario orientado al desarrollo del pensamiento creativo y computacional mediante actividades de aprendizaje activo; Laboratorio Visual (Eye tracker), un lugar para investigar las diversas dinámicas de percepción visual de los consumidores; el Aula de Innovación y Creatividad, diseñada para fortalecer dinámicas de innovación, creatividad, desarrollo de productos y diseño de servicios; y la Cámara Gessell, un laboratorio para análisis e investigación desde la observación no participante.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: lo mejor de la academia, la ciencia y las artes converge en EAFIT.

Como Escuela, organizamos eventos institucionales como Conamerc, Simpro y Gerenciar.

**Tenemos proyección y presencia nacional**

Estamos en Bogotá con nuestros programas de maestría en: Administración Financiera (MAF), Administración (MBA), Gerencia de Proyectos y Especialización en Finanzas. También llegamos a Pereira con las maestrías en: Administración (MBA) y Administración de Riesgos. Asimismo, ofrecemos las maestrías y especializaciones en: Mercadeo, Gerencia de Proyectos, Administración Financiera y la Especialización en Finanzas. En ambas sedes, contamos con flexibilidad en las clases presenciales cada quince días y cada mes, según el programa.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como la mejor ciudad universitaria a nivel regional, según el ICU (Índice de Ciudades Universitarias); y es la primera ciudad de Latinoamérica en unirse a la Red PASCAL de ciudades del aprendizaje. Cada año, EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

[Aprendizaje vivo y activo](https://www.eafit.edu.co/escuela-administracion#4257225834-291057186)

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

En el pregrado, cada persona tiene la libertad de configurar su plan de estudios con 17 líneas de énfasis para elegir.

Se aprende a partir de la experiencia, enfrentando retos empresariales y resolviendo proyectos reales.

[Innovación y liderazgo](https://www.eafit.edu.co/escuela-administracion#4257225834-519042946)

Innovación y liderazgo

**Somos innovación en educación**

Nuestro modelo de formación ha sido replicado por universidades como el Tecnológico de Monterrey. Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes están expuestos continuamente a conversaciones y procesos con casos reales y con los graduados. También reciben una formación multidisciplinaria gracias a las cinco escuelas de EAFIT y las áreas de conocimiento que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

En EAFIT tenemos 14 grupos estudiantiles, con más de 1,500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica. Contamos con 40 grupos de investigación, 3 de ellos en categoría A1, la más alta posible, y más de 100 semilleros para el aprendizaje y crecimiento de los estudiantes.

[Conexiones e incidencia](https://www.eafit.edu.co/escuela-administracion#4257225834-2857448340)

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo**

Contamos con un centro de estudios e incidencia, Valor Público, y con un espacio de innovación y desarrollo social: EAFIT Social.

Tenemos a On.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Contamos con**In-sight, el Centro de Estudio e Incidencia**, donde nos preocupamos por entender los problemas presentes y futuros de las organizaciones y de acompañarlas en la construcción de soluciones sostenibles, así como en la formación de sus líderes.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y las mejores universidades del mundo, así como con los problemas que afectan a nuestra sociedad. También ofrecemos consultoría a empresas del mundo, como el GOROM Institute.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países del mundo, aproximadamente 200 estudiantes que se van de intercambio al exterior, y programas de intercambio profesoral e investigativo.

Tenemos alianzas con importantes universidades de negocios en Europa: Rennes School of Business, IÉSEG y la Universidad de Estrasburgo. Recibimos clases del Korean Institute.

Nuestros estudiantes pueden obtener una doble titulación en el Bachelor in European Management.

Contamos con opciones de aprendizaje como Vive la Experiencia Disney, un intercambio de cinco meses para estudiar y trabajar en los parques.

**Representamos excelencia para los empleadores**

El 79.4% de nuestros graduados trabaja en las organizaciones donde hicieron sus prácticas, y el 89% de nuestros graduados está empleado.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrado han comenzado sus emprendimientos. Doce de ellos están en la lista de las 100 mejores start-ups de Colombia.

Áreas de conocimiento

## Organización, Dirección y Estrategia

Agrupa el conjunto de estudios organizacionales y de administración que apoyan la gestión de diferentes tipos de organizaciones para lograr su propósito.

## Gestión Global ​​​

Tiene como propósito conectar a las organizaciones con el contexto internacional. Nos comprometemos a impulsar la internacionalización del país, la región y las empresas desde múltiples perspectivas.

## Gestión de la Información y de Riesgos

Investigamos, comprendemos y solucionamos problemas sociales en las áreas de Analítica de datos, Gestión de Riesgos organizacionales, de Proyectos e Impuestos, Machine Learning, Sistemas de información contable, de Costos y presupuestos, y los nuevos enfoques del Control y la auditoría.

## Marketing e Innovación

Conforman el Pregrado en Mercadeo, la Especialización y la Maestría en Mercadeo, la Maestría en Gerencia de la Innovación y el Conocimiento; el Grupo de Investigación Estudios en Mercadeo (GEM) - categoría A1 en MINCIENCIAS, y el MercaLAB.

![Image 106: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## In-sight, centro de estudios e incidencia

[Conoce el centro](https://www.eafit.edu.co/in-sight)

## Grupos de investigación

[Ver grupos de investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/grupos-investigacion)

## Mecarlab

[Conócelo](https://www.eafit.edu.co/escuela-administracion/mercalab)

## Conex Consultorio contable

[Conoce el Consultorio](https://www.eafit.edu.co/consultorio-contable)

## Publicaciones de nuestros profes

[Conócelas](https://www.eafit.edu.co/escuela-administracion/publicaciones-de-nuestros-profes)

## Cátedras de Innovación Empresarial José Gutiérrez Gómez

[Más información](https://www.eafit.edu.co/escuela-administracion/catedras-de-innovacion-empresarial-jose-gutierrez-gomez)

## PRME Latinoamérica y el Caribe

[Conoce sobre el evento](https://www.eafit.edu.co/escuela-administracion/prme?check_logged_in=1)

## Consultorio empresarial

[Conócelo](https://www.eafit.edu.co/escuela-administracion/consultorio-empresarial)

## Nuestras redes

### Instagram

[Conoce nuestro Instagram](https://www.instagram.com/escueladeadministracioneafit)

### Linkedin

[Síguenos en Linkedin](https://www.linkedin.com/company/escueladeadministracioneafit/)

### **Noticias**

![Image 107: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=397&h=250&itok=MKSJ4A11)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 108: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=397&h=250&itok=Ai1Iyv7S)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

![Image 109: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=397&h=250&itok=jKshJMEj)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-laboratorio-vivo-para-aprender-haciendo "Ver noticia")

Marzo 12, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/escuela-administracion/noticias-de-la-escuela-de-administracion)

![Image 110: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 111: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 112: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 113: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 114: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 115: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 116: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 117: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 120](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
