Title: Cultura

URL Source: https://www.eafit.edu.co/vida-cultural

Published Time: Thu, 07 May 2026 20:54:12 GMT

Markdown Content:
# Cultura - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/vida-cultural#main-content)

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/vida-cultural#)

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/vida-cultural# "Spanish")[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/vida-cultural# "English")

 Información para ti

[![Image 9: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 10: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 11: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 12: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 13: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 14: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 15: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 16: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 17: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 18: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 19: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 20: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 21: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 22: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 23: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 24: Imagen de banner concierto de temporada orquesta](https://universidadeafit.widen.net/content/079b7dbc-6edd-4526-afba-5d5306c29713/web/exposicion-futlbol-abril2026-c1.jpg?crop=yes&k=c&w=1920&h=788&itok=ThXFL5F-)

# Vida cultural

*   [Inicio](https://www.eafit.edu.co/)
*    Cultura 

### La cultura en EAFIT

El proyecto cultural de EAFIT es un sistema para educar, formar y disfrutar. Gracias a nuestros campus abiertos, no solo impactamos a la comunidad universitaria sino a la sociedad de Medellín. Nos interesan los mensajes, los contenidos, los repertorios y las actividades que generan emociones y conectan a la gente con nuestra universidad y lo que ella representa. Somos un sistema de arte, conocimiento y creatividad para compartir con el mundo lo mejor de EAFIT.

Exposiciones

## Exposición Campo en juego

Una exposición que invita a jugar. Porque la vida... da muchas vueltas. 

 Desde el jueves 16 de abril 

 Hora: 5:00 p.m.

[Explora la exposición](https://www.eafit.edu.co/calendario-eventos/exposicioncampoenjuego)

![Image 25](https://universidadeafit.widen.net/content/d83a5b77-ec20-49c6-8fe1-c46fd7784672/web/exposicion-campo-de-juego-abril2026.png?w=480&itok=fICPM7CC)

![Image 26: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

# Próximos eventos

[Música](https://www.eafit.edu.co/vida-cultural#4257225834-4292083231)

Música

## Transformación empresarial Kaizen explicada con orquesta

Función: Miércoles, 29 de abril, 10:00 a.m.

[Adquiere tus boletas](https://assets.eafit.edu.co/TransEmpresKaizen-20260312)

[Literatura](https://www.eafit.edu.co/vida-cultural#4257225834-2861458402)

Literatura

## Mundos posibles: un encuentro con la creación literaria

Fecha: Martes 14 de abril, 5:30 p.m. Hall Bloque 18, piso 1

[Más información](https://www.eafit.edu.co/calendario-eventos/mundos-posibles-un-encuentro-con-la-creacion-literaria)

## Lanzamiento del libro Juan Felipe Gaviria. Breve biografía sentimental

Fecha: Viernes 24 de abril, 7:00 p.m. Biblioteca de Los Fundadores.

 Gimnasio Moderno

[Más información](https://www.eafit.edu.co/calendario-eventos/lanzamiento-del-libro-breve-biografia-sentimental)

## Lanzamiento Liturgia de los bosques. Lectura en voz alta poemas

Fecha: Viernes 24 de abril, 6:00 p.m. Casa Tomada, transversal 19 Bis No.45D–23. (Barrio Palermo de Bogotá)

[Más información](https://www.eafit.edu.co/calendario-eventos/lanzamiento-liturgia-de-los-bosques)

## Homenaje cien años del nacimiento de Rocío Vélez de Piedrahíta

Fecha: Domingo 26 de abril, 4:00 p.m. - 5:00 p.m. Sala FILBo LIJ.

[Más información](https://www.eafit.edu.co/calendario-eventos/homenaje-cien-anos-del-nacimiento-de-rocio-velez-de-piedrahita)

## Conociendo al autor: David Eufrasio Guzmán (Pichón de diablo, Piel de conejo, Animales de familia)

Fecha: Jueves 30 de abril, 6:00 p.m. Cootivio Libros. Cl 64 #7-45, Chapinero.

 Bogotá.

[Más información](https://www.eafit.edu.co/calendario-eventos/conociendo-al-autor-david-eufrasio-guzman)

[Cine](https://www.eafit.edu.co/vida-cultural#4257225834-4271631252)

Cine

## François Truffaut llega a nuestro Cine Club

François Truffaut llega a nuestro Cine Club. 

 La obra de François Truffaut aborda con profundidad y aparente sencillez temas fundamentales de la existencia humana: la infancia, el ciclo vital, la muerte y el amor.

 El ciclo François Truffaut, cinéfilo y autor presenta una selección de 14 largometrajes entre la cinematografía de Truffaut, cuya obra tomada en su totalidad es imprescindible para la historia del cine.

 Todos los lunes

 5:00 p.m.

 Bloque 38, auditorio 110

[Más información](https://www.eafit.edu.co/calendario-eventos/la-piel-dura)

[Danza](https://www.eafit.edu.co/vida-cultural#4257225834-799374168)

Danza

## Obra de danza: Ensayo (Celebración del Día de la Danza)

Día: 28 de abril 2026

 Hora: 5:00 p.m.

 Compañía: Zonasuspendida

 Lugar: Auditorio Fundadores

 Sinopsis: una obra de danza que mezcla el texto, el cuerpo, la palabra y la escena

[Teatro](https://www.eafit.edu.co/vida-cultural#4257225834-1692552256)

Teatro

## Obra de teatro: Viernes Santo

Compañía: Teatriados.

 Día: 13 de mayo 2026

 Hora: 6:00 p.m.

 Lugar: Auditorio Fundadores

 Sinopsis: dos hermanas, han querido morir cada 24 de diciembre, no lo han logrado. En esta obra, vemos una secuela de una pareja de hermanas queridas por muchos, dos mujeres que aún no logran morirse.

[Conoce más eventos](https://www.eafit.edu.co/calendario-eventos)

Novedades de la Editorial

![Image 27: Imagen Liturgia de los bosques](https://universidadeafit.widen.net/content/6326ca35-57af-4aec-8a2f-55d819dc2c76/web/libro-liturgia-de-los-bosques-v3.png?crop=yes&k=c&w=397&h=253&itok=9J8i9jYx)

Liturgia de los bosques

Del ganador del premio León de Greiff, Darío Jaramillo, es una colección de poemas que explora la relación entre la naturaleza, la memoria y la vida interior.

[Ver el libro](https://editorial.eafit.edu.co/index.php/editorial/es/catalog/book/760)

![Image 28: Imagen Todos los Amigos](https://universidadeafit.widen.net/content/006b2b84-7889-4fde-b094-f92d2cf1be7f/web/libro-todos-los-amigos-son-imaginarios-v3.png?crop=yes&k=c&w=397&h=253&itok=S_pWvqmS)

Todos los Amigos

Libro de cuentos donde lo cotidiano se mezcla con lo extraño para explorar la soledad, el deseo y la fragilidad de los vínculos humanos desde una mirada íntima e inquietante.

[Ver el libro](https://editorial.eafit.edu.co/index.php/editorial/es/catalog/book/569)

![Image 29: Imagen Iusnaturalezas](https://universidadeafit.widen.net/content/575763c0-4e96-4fc0-bdea-e0081a6c9f36/web/libro-luznaturalezas-editorial-v3.png?crop=yes&k=c&w=397&h=253&itok=MhjjJw8w)

Iusnaturalezas

Un libro que propone reconocer la naturaleza como sujeto jurídico, cuestionando las bases del derecho ambiental y replanteando la relación entre lo humano y lo natural.

[Ver el libro](https://editorial.eafit.edu.co/index.php/editorial/es/catalog/book/761)

[Conoce nuestro catálogo](https://editorial.eafit.edu.co/)

### **Noti​cias de Cultura**

![Image 30: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=409&h=193&itok=JkRzgs7h)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 31: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=409&h=193&itok=NgUwJ00O)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

![Image 32: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=409&h=193&itok=Y_JcZf72)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-laboratorio-vivo-para-aprender-haciendo "Ver noticia")

Marzo 12, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/eafit-es-noticia)

Nuestro equipo

![Image 33: Extensión Cultural](https://universidadeafit.widen.net/content/70499c62-bbe2-401c-b30e-5eb74e11b334/web/exposicion-27-04.26.jpg?w=480&itok=3ThKEZNT)
## Extensión Cultural

[Conoce más](https://www.eafit.edu.co/extension-cultural)

![Image 34: Orquesta Sinfónica](https://universidadeafit.widen.net/content/4eb162df-75da-483a-b533-c4cb721cb3a7/web/orquesta-27-04-26.jpg?w=480&itok=0QZbl4U2)
## Orquesta Sinfónica

[Conoce más](https://www.eafit.edu.co/orquesta-sinfonica-eafit)

![Image 35: Editorial](https://universidadeafit.widen.net/content/e9c54eb5-eb8f-4db8-9675-c98f7cdcebbd/web/editorial-27-04-26.jpg?w=480&itok=OAG4zigK)
## Editorial

[Conoce más](https://www.eafit.edu.co/editorial)

![Image 36: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Nuestras Redes Sociales

### Instagram / Cultura

[Síguenos](https://www.instagram.com/culturaeafit/)

### Instagram / Orquesta Sinfónica

[Síguenos](https://www.instagram.com/sinfonicaeafit/)

### Instagram / Editorial

[Síguenos](https://www.instagram.com/editorialeafit/)

### Facebook / Orquesta Sinfónica

[Síguenos](https://www.facebook.com/sinfonicaEAFIT)

### Facebook / Cultura

[Síguenos](https://www.facebook.com/eafitcultura)

### Facebook / Editorial

[Síguenos](https://www.facebook.com/editorialeafit)

### Youtube / Cultura

[Síguenos](https://www.youtube.com/@extensionculturaleafit4523)

### Youtube / Orquesta Sinfónica

[Síguenos](https://www.youtube.com/@sinfonicaEAFIT)

![Image 37: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 38: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 39: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 40: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 41: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 42: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 43: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 44: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
