Title: Filantropía

URL Source: https://www.eafit.edu.co/filantropia

Markdown Content:
# Filantropía
[Pasar al contenido principal](https://www.eafit.edu.co/filantropia#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 2: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/filantropia#)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/filantropia# "Spanish")[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/filantropia# "English")

 Información para ti

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 6: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 7: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 8: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 9: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 10: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 12: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 13: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 14: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 15: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 16: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 17: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 18: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 19: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 20: Imagen de banner Filantropía EAFIT](https://universidadeafit.widen.net/content/3087aab8-518a-4b8e-9bce-1cee5231f95d/web/plataformas-del-ecosistema.jpg?crop=yes&k=c&w=1920&h=788&itok=ys3pN_gZ)

# Filantropía EAFIT

[Participa en el Giving Day 2025](https://www.eafit.edu.co/filantropia/iniciativas/giving-day)

*   [Inicio](https://www.eafit.edu.co/)
*    Filantropía 

Creemos que es posible que los jóvenes con talento puedan estudiar en nuestras aulas, en nuestro campus. 

 Trabajamos para lograr su acceso a la educación superior para lograr movilidad social y que sean parte de la comunidad eafitense, sin importar si cuentan o no con los recursos para hacerlo.​

[Dona aquí](https://ecommerce.eafit.edu.co/es/transformemos-juntos)

![Image 21: Imagen ](https://universidadeafit.widen.net/content/002ebbf9-0ee4-4aa2-88e1-4ac8f5587818/web/becarios-universidad-eafit.jpg)

### ¿Cómo donar?

[¿Cómo donar?](https://www.eafit.edu.co/filantropia/como-donar)

### Iniciativas

[Iniciativas](https://www.eafit.edu.co/filantropia/iniciativas)

### Informes de gestión

[Informes de gestión](https://www.eafit.edu.co/filantropia/informes-de-gestion)

### Noticias

[Noticias](https://www.eafit.edu.co/filantropia/noticias)

### Preguntas frecuentes

[Preguntas frecuentes](https://www.eafit.edu.co/filantropia/preguntas-frecuentes)

### Contacto

[Contacto](https://www.eafit.edu.co/filantropia/contacto)

Tenemos la certeza de que la educación le da las herramientas al estudiante para enfrentar problemas personales y colectivos, **para inspirar a otros, para crear conocimiento, para transformar realidades**. Invertir en educación es invertir en transformar comunidades, territorios, familias, personas con un pensamiento más autónomo, con capacidades propias para el desarrollo y​​, tal vez, más felices.

##### Juntos hemos logrado...

que 2 de cada 10 estudiantes de EAFIT tengan algún tipo de apoyo económico: más de 2.500 becas semestrales gracias a las personas y a las empresas que creen en nuestra universidad y su poder de transformarlo todo.

#### Voces que inspiran:

###### Historias de transformación

## Conoce nuestro​s principales aliados

[](https://www.eafit.edu.co/filantropia)

[![Image 22: Imagen de logo Andi](https://universidadeafit.widen.net/content/ef6ac6b8-7c5b-4916-9288-af8fa5dc81e6/web/logo-andi.png)](https://www.eafit.edu.co/filantropia)

[![Image 23: Imagen de logo Ariza Marin](https://universidadeafit.widen.net/content/7ef854c4-469a-41b9-81f3-283eb38d44d6/web/logo-ariza-marin.png)](https://www.eafit.edu.co/filantropia)

[![Image 24: Imagen de logo Cese](https://universidadeafit.widen.net/content/791a0289-9f42-43e0-9e53-d8ac18743873/web/logo-cese.png)](https://www.eafit.edu.co/filantropia)

[![Image 25: Imagen de logo Ternium](https://universidadeafit.widen.net/content/63b86a73-df16-4123-a561-39b92e3ace8b/web/logo-ternium.png)](https://www.eafit.edu.co/filantropia)

[![Image 26: Imagen de logo Fundación Aurelio Llano Posada](https://universidadeafit.widen.net/content/1e89b39b-f03a-4307-97ba-03c994cdcc24/web/logo-aurelio-llano-posada.png)](https://www.eafit.edu.co/filantropia)

[![Image 27: Imagen de logo Fundación Colombia Somos Todos](https://universidadeafit.widen.net/content/3c1507d5-1efe-4930-b50f-7bd92c8f8f2a/web/logo-fundacion-colombia-somos-todos.png)](https://www.eafit.edu.co/filantropia)

[![Image 28: Imagen de logo Fundación Bolívar Davivienda](https://universidadeafit.widen.net/content/ea6d2fc5-ac72-4f22-872c-2c8b8d300d9c/web/logo-fundacion-bolivar-davivienda.png)](https://www.eafit.edu.co/filantropia)

[![Image 29: Imagen de logo Fundación Educación](https://universidadeafit.widen.net/content/b53c5c77-b697-44ad-8691-55cb60978006/web/logo-fundacion-educacion.png)](https://www.eafit.edu.co/filantropia)

[![Image 30: Imagen de logo Fundación Fraternidad Medellín](https://universidadeafit.widen.net/content/49008e2e-571e-434a-a6a8-9a4fc8c0b2bc/web/logo-fundacion-fraternidad-medellin.png)](https://www.eafit.edu.co/filantropia)

[![Image 31: Imagen de logo Grupo Argos Fundación](https://universidadeafit.widen.net/content/44dea3ab-eaa9-4552-8958-9cebd8503716/web/logo-grupo-argos-fundacion.png)](https://www.eafit.edu.co/filantropia)

[![Image 32: Imagen de Fundación Grupo Bancolombia](https://universidadeafit.widen.net/content/1464d00f-1361-4196-afda-35df64f30f18/web/logo-fundacion-grupo-bancolombia.png)](https://www.eafit.edu.co/filantropia)

[![Image 33: Imagen de logo Fundación Juan Pablo Gutiérrez Cáceres](https://universidadeafit.widen.net/content/3f803eca-4c1f-485c-a305-15323ecd5542/web/logo-fundacion-juan-pablo-gutierrez-caceres.png)](https://www.eafit.edu.co/filantropia)

[![Image 34: Logo de imagen Sofia Pérez Soto Fundación](https://universidadeafit.widen.net/content/dd3db436-fc09-4f43-948c-ac32aa119874/web/logo-sofia-perez-soto-fundacion.jpg)](https://www.eafit.edu.co/filantropia)

[![Image 35: Imagen de logo Global seguros](https://universidadeafit.widen.net/content/18d02bb1-a335-4faa-8f71-cb7c71203523/web/logo-global-seguros.png)](https://www.eafit.edu.co/filantropia)

[![Image 36: Imagen de logo Grupo Bíos ](https://universidadeafit.widen.net/content/ebc7900b-dd92-4a99-baa0-265f9d24a017/web/logo-grupo-bios.png)](https://www.eafit.edu.co/filantropia)

[![Image 37: Imagen de logo Masglobal](https://universidadeafit.widen.net/content/f0c5a993-ae50-4a2c-9b2d-d01bb4f50366/web/logo-masglobal.png)](https://www.eafit.edu.co/filantropia)

[![Image 38: Imagen de logo Mineros por el bienestar de todos ](https://universidadeafit.widen.net/content/bc4d9d20-ecdd-4bb7-87ce-7ff4d5881fd7/web/logo-mineros.png)](https://www.eafit.edu.co/filantropia)

[![Image 39: Imagen de logo Sura Fundación](https://universidadeafit.widen.net/content/c377f108-5d33-4e88-88e3-06654ecb804d/web/logo-sura-fundacion.png)](https://www.eafit.edu.co/filantropia)

[![Image 40: Imagen de logo Serrano Martinez cma](https://universidadeafit.widen.net/content/4899f679-3ff2-4f8a-8fa1-2ec7375e9083/web/logo-serrano-martinez-cma.png)](https://www.eafit.edu.co/filantropia)

[![Image 41: Imagen de logo Con Cora](https://universidadeafit.widen.net/content/5886ab49-8520-4493-acee-088fc0473534/web/logo-con-corona.png)](https://www.eafit.edu.co/filantropia)

[![Image 42: Imagen de logo Fundación Felisa Johnson](https://universidadeafit.widen.net/content/94ae9f3d-eec8-4847-bd1b-2899779069de/web/logo-fundacion-felisa-johnson.jpg)](https://www.eafit.edu.co/filantropia)

[![Image 43: Imagen de logo Fundación Éxito](https://universidadeafit.widen.net/content/fc80e68a-19b5-497e-ba1c-4bf93888e3c1/web/logo-fundacion-exito.png)](https://www.eafit.edu.co/filantropia)

[![Image 44: Imagen de logo Grupo Nutresa](https://universidadeafit.widen.net/content/7b1322ff-0f03-414d-8812-7f9b89792a18/web/logo-grupo-nutresa.jpg)](https://www.eafit.edu.co/filantropia)

[![Image 45: Imagen de logo Renault Group Fundación Colombia](https://universidadeafit.widen.net/content/b3444364-0900-4f51-b33f-ed6a7e41091c/web/logo-renault-group-fundacion-colombia.png)](https://www.eafit.edu.co/filantropia)

[![Image 46: Imagen de logo Vélez Reyes](https://universidadeafit.widen.net/content/fe8d3342-80bb-4401-9218-929ccf2860ff/web/logo-velez-reyez.jpg)](https://www.eafit.edu.co/filantropia)

[![Image 47: Imagen de logo One Inversión Social](https://universidadeafit.widen.net/content/62614a8e-f163-45b7-8610-6ab174a9f382/web/logo-one-inversion-social.png)](https://www.eafit.edu.co/filantropia)

![Image 48: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 49: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 50: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 51: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 52: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 53: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 54: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 55: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
