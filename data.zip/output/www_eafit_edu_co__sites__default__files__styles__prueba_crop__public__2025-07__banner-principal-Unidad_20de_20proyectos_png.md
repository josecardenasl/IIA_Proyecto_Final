Title: banner-principal-Unidad%20de%20proyectos.png

URL Source: https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-07/banner-principal-Unidad%20de%20proyectos.png?itok=gqoBWjMM

Published Time: Fri, 25 Jul 2025 14:10:55 GMT

Markdown Content:
# banner-principal-Unidad%20de%20proyectos.png

A man with a map in his hand talks to a woman in a purple shirt
