Title: EAFIT está en el top 3 de las universidades colombianas que mejor atraen y retienen talento

URL Source: https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-esta-en-el-top-3-de-las-universidades-colombianas-que-mejor-atraen

Markdown Content:
# EAFIT destaca en atracción de talento
[Pasar al contenido principal](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-esta-en-el-top-3-de-las-universidades-colombianas-que-mejor-atraen#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 2: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-esta-en-el-top-3-de-las-universidades-colombianas-que-mejor-atraen#)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-esta-en-el-top-3-de-las-universidades-colombianas-que-mejor-atraen# "Spanish")[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-esta-en-el-top-3-de-las-universidades-colombianas-que-mejor-atraen# "English")

 Información para ti

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 6: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 7: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 8: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 9: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 10: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 12: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 13: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 14: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 15: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 16: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 17: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 18: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 19: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

# EAFIT está en el top 3 de las universidades colombianas que mejor atraen y retienen talento

**Así lo establece el ranquin Merco Talento 2025 que divulgó Monitor Empresarial de Reputación Corporativa (Merco) este 5 de junio, y en el que la Institución se ubicó como la tercera del país y primera en Antioquia en el sector educación.**

**En la medición general EAFIT mejoró con respecto a la edición de 2024, pasando del puesto 35 al 28. Para la realización de la medición, se aplicaron 74.851 encuestas, distribuidas en 13 fuentes de información desde 6 perspectivas diferentes.**

*   [Inicio](https://www.eafit.edu.co/)
*   [Noticias](https://www.eafit.edu.co/noticias)
*   [EAFIT Es Noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia)
*    EAFIT Está En El Top 3 de Las Universidades Colombianas Que Mejor Atraen y Retienen Talento 

![Image 20: Imagen EAFIT está en el top 3 de las universidades colombianas que mejor atraen y retienen talento](https://universidadeafit.widen.net/content/6e0d40f1-1bd8-45e5-bf3f-253b3eb1076e/web/el-podio.jpg?crop=yes&k=c&w=823&h=450&itok=5PO64fxR)

EAFIT se ubica en el lugar 28 de ranquin, aumentando 7 puestos con respecto a 2024.

De acuerdo con los resultados de la más reciente encuesta Merco Talento, publicada este 5 de junio, EAFIT es la tercera universidad en Colombia que mejor atrae y retiene el talento en las entidades del sector educación, subiendo dos puestos en el escalafón. En cuanto a la medición general, la Institución se ubicó en el puesto 28 del ranquin, aumentando 7 puestos con respecto a 2024.

Para evaluar el poder de las empresas para atraer y fidelizar el talento, Monitor Empresarial de Reputación Corporativa (Merco) tiene en cuenta variables como la coherencia entre el salario y la función desempeñada, el desarrollo profesional, la motivación, el sector al que pertenece la empresa y sus valores éticos, la reputación, entre otros.

Ricardo Uribe Marín, director de Desarrollo Humano y Bienestar de EAFIT, expresó que “este logro lo recibimos con alegría, entusiasmo y compromiso para seguir trabajando como Universidad en nuestros procesos de atracción y retención del talento. Esta mejora se debe al trabajo serio, decidido y responsable entre la Dirección, la alta dirección de la Universidad y todas las áreas académicas y administrativas a lo largo de varios años”.

Por su parte, Cristina Vélez Valencia, decana de la Escuela de Administración, complementó que “estar entre las tres universidades con mayor reconocimiento organizacional es un orgullo para EAFIT. Implica que nuestra promesa de conectarnos con las organizaciones, de hacer investigación relevante, de formar el mejor talento gerencial, se está cumpliendo y lo están reconociendo nuestros pares. Asimismo, haber subido en el ranquin general también habla de una noción de las universidades como actores relevantes del entramado empresarial y organizacional del país”.

###### Sobre la medición actual

En la edición número 16 de esta medición en Colombia, se realizaron un total de 74.851 encuestas, distribuidas en 13 fuentes de información entre universitarios, egresados, catedráticos, cazadores de talentos, responsables de equipos de recursos humamos, entre otros.

“Lo que hace Merco Talento es realizar una evaluación global de atractivo de las empresas y marcas empleadoras para atraer y fidelizar talento, considerando la opinión de diferentes targets. Esto se analiza comparativamente con todas las grandes empresas”, expresó Elena Orden, responsable de Merco Talento España, durante la socialización de los resultados.

Garantizar la transparencia de esta medición es un factor relevante, por eso “la presencia de las empresas en el ranquin es gratuita. Merco talento es un monitor de referencia para la empleabilidad y evaluación, y además analiza y compara otras empresas. Eso hace que sea un monitor de referencia”, afirmó Catalina Londoño Moreno, directora de Merco Colombia.

Como novedad en la presente edición de Merco, la encuesta incluyó preguntas como ¿Tu empresa tiene definido un propósito corporativo?, ¿el propósito se refleja en la actividad actual de la empresa?, ¿crees que el propósito es una buena apuesta o camino para el futuro de la empresa?, ¿en qué medida te identificas con el propósito?

Una de las conclusiones de esta medición es que los departamentos de recursos humanos, además de seguir trabajando en estrategias de atracción y fidelización, deben tener propuestas de valor adaptadas de acuerdo con los diversos públicos internos, pues los intereses o motivaciones varían según el rango de edad o la posición en la compañía.

En el caso de EAFIT, y en palabras de la decana Cristina Vélez, “como marca empleadora es coherente con lo que hacemos, es decir, es un reflejo de una organización que reta y acompaña a sus colaboradores. En donde la gente trabaja feliz”.

En ese sentido, Ricardo Uribe, manifestó que los resultados muestran que la Universidad es un referente como institución empleadora, lo que se ratifica con una mejora año a año en Merco Talento. Agregó, además, que este logro, a propósito de los 65 años de EAFIT, demuestra que somos “una Institución seria, madura y comprometida no solo con la atracción sino también con el desarrollo y retención del talento humano clave para el logro de nuestro propósito superior de transformar sociedad”.

#### Historias y noticias recomendadas

![Image 21: Imagen En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg?crop=yes&k=c&w=823&h=450&itok=2I2kS4Ud)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)
###### En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones

Una red de agua helada con pérdidas de eficiencia, una selladora industrial que requería mejorar su confiabilidad, sistemas energéticos con alto consumo y procesos que podían automatizarse: esos son algunos de los retos de empresas del sector productivo que cruzaron la puerta del aula y que hoy cuentan con propuestas desarrolladas por estudiantes de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "Leer más")

Mayo 7, 2026

![Image 22: Imagen Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://universidadeafit.widen.net/content/c5dd5394-7a1b-46bc-93d4-e01ffbbe080a/web/Patente-caminador.png?crop=yes&k=c&w=823&h=450&itok=elgTvZ7o)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano

La movilidad es uno de los factores que más influye en la autonomía y la calidad de vida de las personas, especialmente en quienes enfrentan procesos de rehabilitación o dificultades para caminar.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado "Leer más")

Abril 30, 2026

![Image 23: Imagen EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://universidadeafit.widen.net/content/9e97e1f2-ee3f-46aa-a923-d0b06278bd58/web/campus-vivo-1500.jpg?crop=yes&k=c&w=823&h=450&itok=ET4zIEwS)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología

La Plazoleta del Estudiante se transformó este miércoles 22 de abril en un espacio de experimentación y conexión con la _Muestra de iniciativas inspiradoras de aprendizaje experiencial_. Prototipos en impresión 3D, simuladores, juegos interactivos y modelos matemáticos se encontraron en una misma escena para dejar a un lado la teoría abstracta y permitir que estudiantes, profesores y colaboradores activaran los sentidos alrededor de diferentes proyectos.

[Leer más](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y "Leer más")

Abril 23, 2026

[Ver todas las historias y noticias](https://www.eafit.edu.co/noticias)

##### Nuestros programas

[Conoce los pregrados](https://www.eafit.edu.co/pregrados)[Conoce los posgrados](https://www.eafit.edu.co/posgrados)

_**Última actualización**_

Octubre 30, 2025

![Image 24: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 25: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 26: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 27: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 28: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 29: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 30: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 31: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
