Title: EAFIT, certificación en liderazgo, más de 100 líderes, gestión humana, empresas colombianas

URL Source: https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-certificacion-en-liderazgo-mas-de-100-lideres-gestion-humana

Markdown Content:
# EAFIT certificó en liderazgo a más 100 líderes de gestión humana de empresas colombianas
[Pasar al contenido principal](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-certificacion-en-liderazgo-mas-de-100-lideres-gestion-humana#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-certificacion-en-liderazgo-mas-de-100-lideres-gestion-humana#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-certificacion-en-liderazgo-mas-de-100-lideres-gestion-humana# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-certificacion-en-liderazgo-mas-de-100-lideres-gestion-humana# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

# EAFIT, certificación en liderazgo, más de 100 líderes, gestión humana, empresas colombianas

**Se trata de la certificación del programa Talento 100+, orientado a fortalecer competencias para transformar organizaciones, ofrecido por la Universidad a través de su Dirección de Estrategia y de In-sight, su centro de estudios e incidencia en liderazgo de impacto.**

**En la**_**masterclass**_**de cierre, Claudia Restrepo Montoya, rectora de EAFIT, invitó a los asistentes a reflexionar sobre el papel del poder en el ejercicio del liderazgo. El encuentro también contó con la presencia de Fernando Quijano, director del diario**_**La República**_**.**

*   [Inicio](https://www.eafit.edu.co/)
*   [Noticias](https://www.eafit.edu.co/noticias)
*   [Nuestro Impacto](https://www.eafit.edu.co/noticias/nuestro-impacto)
*    EAFIT, Certificación En Liderazgo, Más de 100 Líderes, Gestión Humana, Empresas Colombianas 

![Image 21: Imagen EAFIT, certificación en liderazgo, más de 100 líderes, gestión humana, empresas colombianas](https://universidadeafit.widen.net/content/853f17b5-4c12-4b7f-af2c-363487ad19c9/web/In-sight-liderazgo.jpg?crop=yes&k=c&w=823&h=450&itok=a71L3EUv)

Este encuentro con el liderazgo fue una alianza entre la Dirección de Estrategia e Insight, el _Centro de estudios e incidencia en liderazgo de impacto_ de EAFIT.

Influencia, inspiración, responsabilidad, guía, transformación y ejemplo fueron algunas de las palabras que surgieron desde el público cuando Claudia Restrepo Montoya, rectora de EAFIT, invitó a los asistentes a definir el liderazgo en una sola expresión. Aunque todas conectaban con el acto de liderar, su propósito era conducir hacia otra palabra: poder. Con esta idea inició la _masterclass_ que cerró la primera edición del programa Talento 100+, un componente formativo de In-sight, el centro de estudios e incidencia en liderazgo de impacto de la Universidad.

Talento 100+ es una iniciativa que surgió desde In-sight y la Dirección de Estrategia de EAFIT con el propósito de fortalecer las capacidades de liderazgo de los equipos de talento humano, tanto de empresas consolidadas como de entidades públicas, y promover espacios de aprendizaje colaborativo entre gerentes, directores y vicepresidentes del área.

Así lo explicó Mariana Correa, líder del Ecosistema de Empresas de esa Dirección, quien agregó que “uno de los objetivos era contrastar las definiciones y retos que enfrentan los líderes de talento humano, y propiciar espacios de trabajo conjunto para que ese conocimiento circule entre pares”. Esa posibilidad de intercambio directo entre quienes toman decisiones sobre liderazgo en sus instituciones es justamente uno de los diferenciadores del curso.

Juan Pablo Villegas, director de desarrollo humano y organizacional de Isagen, resaltó que uno de los aprendizajes que le quedan de esta experiencia es que el liderazgo es algo dinámico, “pero ese dinamismo, llevado a reflexiones diarias que se preguntan por la forma de relacionarnos con los demás, puede inducir a los otros a desarrollar sus propias competencias. Es un mensaje que me gustó mucho”, afirma.

Algunas de las empresas que se vincularon a este programa son: Postobón, Protección, Industrias Haceb, Isagen, Colegio Pinares, Grupo Argos, Metro de Medellín, entre otras.

###### Una conversación sobre retos y transformaciones del liderazgo

La clausura del curso, que se realizó este 18 de noviembre con una certificación, incluyó la _masterclass_ de la rectora Claudia Restrepo, y después un espacio de conversación entre la directiva y Fernando Quijano, director del diario _La República_.

En el primer espacio la Rectora se refirió a las diversas expresiones del poder, entre estas el fetichismo, la representación, la reflexión, lo social, lo técnico y lo artístico, y a cómo estas evolucionan a medida que el liderazgo se vuelve más sofisticado. En el plano organizacional explicó tres modelos de ejercicio del poder: el unitario, el radical y el pluralista, y destacó este último por su capacidad de enriquecer la interacción entre las personas y fomentar entornos más creativos.

También señaló que el poder actúa como un reflector que revela lo que cada líder lleva dentro, y subrayó la importancia de la ética y del cuidado personal para evitar que este se convierta en un factor de corrupción. En su mensaje, invitó a los líderes asistentes a irradiar sus virtudes hacia los demás y ejercer el poder con responsabilidad, pues son custodios de una luz capaz de transformar los entornos y generar esperanza.

Durante la conversación _Retos y transformaciones del liderazgo en la actualidad_, Fernando Quijano destacó que “el liderazgo no es un tema de cifras, sino dimensiones del ser y del hacer que se construyen en la educación permanente”, e insistió en que la innovación, la coherencia y la capacidad de generar impacto son rasgos esenciales en los líderes de hoy.

También explicó que no existe una fórmula única para identificar un buen líder, pero sí criterios orientadores: hechos positivos, presencia femenina en roles estratégicos y la capacidad de movilizar transformaciones. “Los liderazgos van cambiando. No es lo mismo ser poderoso que ser influyente”, afirmó, al subrayar que una persona influyente no necesariamente ejerce un liderazgo ético o inspirador.

El cierre del evento estuvo a cargo de Alex Garzón Lasso, director de In-sight, quien retomó la reflexión de la Rectora para recordar que un liderazgo auténtico reconoce y comprende el ejercicio del poder. Advirtió que, cuando ese poder no se entiende, puede terminar corrompiendo a quien lo ejerce. Por eso invitó a los asistentes a ser conscientes de su impacto: “No nos olvidemos de eso. Siempre que ejercemos poder recordemos que dejamos huella en los demás, pero ojalá no marcas”, concluyó.

#### Historias y noticias recomendadas

![Image 22: Imagen En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg?crop=yes&k=c&w=823&h=450&itok=2I2kS4Ud)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)
###### En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones

Una red de agua helada con pérdidas de eficiencia, una selladora industrial que requería mejorar su confiabilidad, sistemas energéticos con alto consumo y procesos que podían automatizarse: esos son algunos de los retos de empresas del sector productivo que cruzaron la puerta del aula y que hoy cuentan con propuestas desarrolladas por estudiantes de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "Leer más")

Mayo 7, 2026

![Image 23: Imagen Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://universidadeafit.widen.net/content/c5dd5394-7a1b-46bc-93d4-e01ffbbe080a/web/Patente-caminador.png?crop=yes&k=c&w=823&h=450&itok=elgTvZ7o)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano

La movilidad es uno de los factores que más influye en la autonomía y la calidad de vida de las personas, especialmente en quienes enfrentan procesos de rehabilitación o dificultades para caminar.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado "Leer más")

Abril 30, 2026

![Image 24: Imagen EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://universidadeafit.widen.net/content/9e97e1f2-ee3f-46aa-a923-d0b06278bd58/web/campus-vivo-1500.jpg?crop=yes&k=c&w=823&h=450&itok=ET4zIEwS)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología

La Plazoleta del Estudiante se transformó este miércoles 22 de abril en un espacio de experimentación y conexión con la _Muestra de iniciativas inspiradoras de aprendizaje experiencial_. Prototipos en impresión 3D, simuladores, juegos interactivos y modelos matemáticos se encontraron en una misma escena para dejar a un lado la teoría abstracta y permitir que estudiantes, profesores y colaboradores activaran los sentidos alrededor de diferentes proyectos.

[Leer más](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y "Leer más")

Abril 23, 2026

[Ver todas las historias y noticias](https://www.eafit.edu.co/noticias)

##### Nuestros programas

[Conoce los pregrados](https://www.eafit.edu.co/pregrados)[Conoce los posgrados](https://www.eafit.edu.co/posgrados)

_**Última actualización**_

Noviembre 24, 2025

![Image 25: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 26: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 27: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 28: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 29: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 30: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 31: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 32: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
