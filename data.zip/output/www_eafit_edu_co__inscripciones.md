Title: ​​Inscripc​iones ​pregrados y posgrado​s ​

URL Source: https://www.eafit.edu.co/inscripciones

Published Time: Thu, 07 May 2026 20:28:51 GMT

Markdown Content:
[![Image 1: Start](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[Español](https://www.eafit.edu.co/inscripciones#)

[Español](https://www.eafit.edu.co/inscripciones# "Spanish")[Inglés](https://www.eafit.edu.co/inscripciones# "English")

Look for

![Image 3: Banner image for students returning to school](https://universidadeafit.widen.net/content/f48dbf4f-5423-4437-a02f-4a60ac853cac/web/Banner-inscripciones.jpg?crop=yes&k=c&w=1920&h=788&itok=KiirCQFB)

## Registrations open

Undergraduate and postgraduate programs.

*   [Start](https://www.eafit.edu.co/)
*    Undergraduate and Postgraduate Registrations 

### **Start your undergraduate and postgraduate registration process 2026-2**

## This is where your university admission process begins.

[Start your registration](https://mcu.azureedge.net/?site=MCU_003&cmd=login)

## WhatsApp line for undergraduate information

[Request information](https://wa.me/573216420341)

## WhatsApp line for postgraduate information

[Request information](https://api.whatsapp.com/send?phone=573226783083)

![Image 4: Scroll icon](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

#### **We support your professional project**

**Learn how to start your life at EAFIT**

## Discover our undergraduate programs

[Learn about the programs](https://www.eafit.edu.co/pregrados)

## Discover our postgraduate programs

[Learn about the programs](https://www.eafit.edu.co/posgrados)

## Guide for applicants to undergraduate programs

[Check out the guide](https://universidadeafit.widen.net/s/xjmmtpgk9v/guia_aspirantes_pregrado_2026-2_con_programae-2)

## Guide for applicants to postgraduate programs

[Check out the guide](https://universidadeafit.widen.net/s/cgccts8sxp/guia-aspirantes-posgrados-2026-1)

## Discover the services we have for your well-being

[Learn about the services](https://www.eafit.edu.co/bienestar-universitario)

## Find out what your induction will be like

[Learn about induction](https://www.eafit.edu.co/bienvenidos)

![Image 5: Scroll icon](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

![Image 6: EAFIT University logo in white](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 7: Facebook icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 8: Instagram icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 9: LinkedIn icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 10: YouTube icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 11: White X icon](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 12: Spotify icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 13: TikTok icon in white](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Study at EAFIT

*   [Our undergraduate programs](https://www.eafit.edu.co/pregrados)
*   [Our postgraduate programs](https://www.eafit.edu.co/posgrados)
*   [Other programs](https://www.eafit.edu.co/otros-programas)
*   [Check out our rates](https://www.eafit.edu.co/tarifas)
*   [Library](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Connect with EAFIT

*   [Let's transform together](https://www.eafit.edu.co/filantropia)
*   [Science, Technology and Innovation](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Connecting with organizations](https://www.eafit.edu.co/organizaciones)
*   [Work with us](https://www.eafit.edu.co/trabaja-con-nosotros)

Contact us

*   [Register a PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Visitor services](https://www.eafit.edu.co/centro-visitantes)
*   [Transparency line](https://www.eafit.edu.co/linea-de-transparencia)

Legal information

*   [Legal personality](https://www.eafit.edu.co/constitucion)
*   [Regulations and statutes](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gender, Diversity and Inclusion](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Court notices and certificates](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Update your information](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Data protection policy](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Terms of use](https://www.eafit.edu.co/terminos-condiciones)

[Site map](https://www.eafit.edu.co/mapa-del-sitio)

University with Institutional Accreditation until 2026. 

Supervised by the Ministry of Education.

[EAFIT Interactive](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Space reservation](https://www.eafit.edu.co/reserva-espacios)[Mail](https://outlook.office.com/)[More apps](https://www.eafit.edu.co/servicios-en-linea)

Our headquarters

**National hotline:** 01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

National hotline: 01 8000 515 900

Customer service line: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Customer service line: (57) 606 3214115, 606 3214119

Email: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 office 401

Customer service line: (57) 601 6114618

Email: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
