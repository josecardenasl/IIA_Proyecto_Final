Title: logo_EAFIT_blanco.svg

URL Source: https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg

Published Time: Tue, 30 Jul 2024 17:53:24 GMT

Markdown Content:
# logo_EAFIT_blanco.svg

A 134x50 small image, likely a logo, icon or avatar
