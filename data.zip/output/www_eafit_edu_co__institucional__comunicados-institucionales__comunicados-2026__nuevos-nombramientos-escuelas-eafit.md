Title: Nuevos nombramientos en las escuelas de EAFIT

URL Source: https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026/nuevos-nombramientos-escuelas-eafit

Markdown Content:
*   [Inicio](https://www.eafit.edu.co/)
*   [Información Institucional](https://www.eafit.edu.co/institucional)
*   [Comunicados Institucionales](https://www.eafit.edu.co/institucional/comunicados-institucionales)
*   [Comunicados 2026](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)
*    Nuevos Nombramientos En Las Escuelas de EAFIT 

### **Escuela de Ciencias Aplicadas e Ingeniería**

Desde el 13 de enero NODO y la unidad de Educación Continua de la Escuela de Ciencias Aplicadas e Ingeniería se fusionan en un solo Centro de Formación en Tecnologías.

Esta unidad, que continúa con la denominación de Nodo expande ahora su alcance para abarcar todos los saberes de la Escuela de Ciencias Aplicadas e Ingeniería y proyectarlos a través de productos orientados a formación y a otros proyectos multipropósito. Y operará con cuatro líneas de trabajo: una enfocada en soluciones y metodologías educativas; una segunda en ejecución y logística operativa de las soluciones, productos o proyectos de formación; y dos unidades más, que se concentrarán en impulsar, complementar y fortalecer aspectos de comunicación, promoción, marca, comerciales y afines.

Su liderazgo estará a cargo de Sara Hernández, magíster en Administración Financiera, especialista en Finanzas y negociadora internacional de EAFIT, y quien cuenta con experiencia en temas de business intelligence, desarrollo del liderazgo y transferencia tecnológica.

Así mismo entre 2023 y 2026 se desempeñó como jefa administrativa y comercial del Centro Nodo, donde estuvo a cargo de la gestión ejecutiva, de crecimiento, y de operaciones y proyectos.

Su recorrido en la Universidad también ha estado ligado a la Dirección de Innovación, donde tuvo los cargos de jefa de transferencia de Tecnología, conocimiento y emprendimiento (2008-2022); coordinadora de Transferencia (2015-2018); y gestora de Innovación (2010-2018).

Sara recibe el liderazgo de esta unidad de manos de Carolina Arbeláez, quien tenía el cargo de jefa de Educación Continua de la Escuela; y de José Alejandro Betancur Álvarez, quien fue líder de Nodo durante su alcance anterior, y quien ahora se desempeña como director de Imaginar Futuros, bajo la dirección de Estrategia.

Alejandro es doctor en Ciencias de la Ingeniería de la Pontificia Universidad Católica de Chile y la Universidad Politécnica de Valencia (UPV); y magíster en Hábitat y arquitecto constructor de la Universidad Nacional de Colombia.

Se encuentra vinculado a la Universidad EAFIT como profesor e investigador desde el año 2014, recorrido en el que se ha desempeñado como coordinador del Semillero de Investigación en la Construcción (SIC) y, actualmente, es profesor adscrito al área de Territorios y Ciudades, e integrante del grupo de investigación en Estudios en Tecnologías Avanzadas de Producción y Mantenimiento Industrial.

Entre sus intereses académicos e investigativos se encuentran la construcción sostenible, la evaluación de edificaciones en condiciones reales de uso, y el enfoque metodológico de Lean Construction.

Alejandro asume la jefatura de este nuevo pregrado, y recibe la jefatura de la especialización en Gestión de la Construcción de Luis Fernando Botero Botero, quien continuará con sus actividades de docencia como profesor pensionado en la Escuela Ciencias Aplicadas e Ingeniería.

Mauricio es doctor en Ingeniería de Sistemas e Informática y magíster en Ingeniería de Sistemas de la Universidad Nacional de Colombia; e ingeniero en Instrumentación y Control del Politécnico Colombiano Jaime Isaza Cadavid.

Se encuentra vinculado a la Universidad EAFIT desde el año 2025 como profesor adscrito al área de Diseño de Productos y Experiencias y, actualmente, es integrante del grupo de investigación en Ingeniería de Diseño.

Entre sus intereses académicos e investigativos se encuentra el diseño de productos inteligentes, la mecatrónica, la robótica, el aprendizaje automático, el diseño de interacciones y de experiencia de usuario, y la investigación de nuevas tecnologías.

Mauricio recibe el cargo de Álvaro de Jesús Guarín, quien continuará con sus actividades de docencia en la Escuela Ciencias Aplicadas e Ingeniería.

Édgar Alexander es doctor en Ingeniería de la Universidad de Cambridge e Ingeniero Mecánico de la Universidad Pontificia Bolivariana.

Se encuentra vinculado a EAFIT desde 2006. En este recorrido se ha desempeñado como coordinador del grupo de investigación en Materiales, y como profesor de planta en el área de Industria, Materiales y Energía de la Escuela de Ciencias Aplicadas e Ingeniería.

También ha desarrollado investigaciones relacionadas con materiales biológicos y su comportamiento mecánico, y mediante el uso de la biomimética o bioinspiración, ha diseñado materiales y productos de alto desempeño para aplicaciones como resistencia al impacto y generación de energías limpias.

Además de asumir la jefatura de este nuevo programa, continúa como jefe de la maestría en Ingeniería perteneciente a la misma Escuela.

Juan Gregorio es magíster en Ciencias con especialidad en Sistemas de Calidad y Productividad, del Instituto Tecnológico y de Estudios Superiores de Monterrey (ITESM); especialista en Dirección de Operaciones de la Universidad de Ibagué y la Universidad Católica de Lovaina (Bélgica); e ingeniero de producción de la Universidad EAFIT.

Se encuentra vinculado a la Universidad desde hace 30 años y, durante este tiempo, se ha desempeñado como jefe del anterior departamento de Ingeniería de Producción, apoyó la creación del Warehousing Lab, y ejerció como jefe encargado del pregrado en Ingeniería de Diseño de Producto. Actualmente es profesor de planta adscrito al área de Industria, Materiales y Energía, e integrante del grupo de investigación en Analítica y Cadenas de Suministro.

Entre sus intereses académicos se encuentra el mejoramiento de procesos productivos, el almacenamiento, la administración de la cadena de abastecimiento y la planeación de la producción.

Juan Gregorio asumió la jefatura de la nueva modalidad virtual para la especialización en Dirección de Operaciones y Logística, que a su vez conserva la modalidad presencial en Medellín y Pereira, con Sergio Augusto Ramírez Echeverri como jefe del programa.

Elizabeth es doctora y magíster en Ciencias de la Computación con énfasis en Ingeniería de Software de la Pontificia Universidad Católica de Río de Janeiro, e Ingeniera Informática del Politécnico Colombiano Jaime Isaza Cadavid.

Se encuentra vinculada a la Universidad desde el año 2015, periodo durante el cual se ha desempeñado como jefa de la especialización en Desarrollo de Software en su modalidad presencial; profesora de planta perteneciente al área de Diseño de Productos y Experiencias; coordinadora del semillero de investigación en Ingeniería de Software; e investigadora en el Grupo de Investigación en Computación.

Sus intereses de investigación actuales abarcan áreas como la ingeniería de software, la automatización, el desarrollo de software ágil, la sostenibilidad en software, y la interacción persona-computadora, entre otros.

Elizabeth asumió la jefatura de la nueva modalidad virtual para la especialización en Desarrollo de Software, que a su vez conserva la modalidad presencial en Medellín, con Paola Andrea Vallejo como jefa de programa.

### **Escuela de Artes y Humanidades**

Danielle es magíster en Hermenéutica Literaria y comunicadora social de EAFIT, y sus campos de interés se enfocan en los proyectos educativos y culturales que promuevan movilización de comunidades de lectura, la transformación social y la creación de contenidos sobre literatura que generen conversaciones significativas.

Ha sido profesora de cátedra de la Universidad en los cursos narrativas del yo, seminario de lenguaje literario y análisis textual y, en su recorrido profesional, se ha destacado como gestora cultural de la Fiesta del Libro de Medellín, del proyecto Medellín en 100 palabras y de Antioquia Reimaginada; editora invitada en la edición 153 de Palabras Rodantes; y formadora en soft skills en la Universidad Corporativa Bancolombia.

Ha publicado textos periodísticos en medios como Casa Macondo, Bacánika, El Espectador, Literariedad, Generación y Revista Canéfora. Y, en los últimos cinco años se ha dedicado a cultivar comunidades de lectura creativa y escritura en librerías y espacios culturales de Medellín y Bogotá, y es autora del libro de cuentos Teoría de conjuntos, publicado en 2024 con la editorial Libros del Fuego.

Danielle, quien continua como jefa del pregrado en Literatura, recibe este nuevo cargo de Yonathan Alexánder Escobar, quien retomará con sus labores académicas, administrativas e investigativas.

### **Escuela de Derecho**

Camilo es magister en Derecho Económico de la Universidad Externado y en Gerencia de la Innovación y el Conocimiento de EAFIT; y abogado de la Universidad de Medellín. Desde hace 18 años se encuentra vinculado a EAFIT como profesor de la Escuela de Derecho.

En ese recorrido se ha desempeñado como decano de la Escuela de Derecho (2016-2021); y jefe del pregrado en Derecho (2008-2016). También ha sido coordinador del área y de la especialización en Derecho del Trabajo y de la Seguridad social.

En la actualidad es investigador en el área del derecho del trabajo y de la seguridad social y, en su recorrido profesional, ha sido asesor y litigante en asuntos de derecho laboral y de seguridad social y derecho económico.

Camilo Piedrahita Vargas recibe este cargo de Lina Lorenzoni Escobar, quien se dedicará a sus labores de investigación y docencia.

Catalina es doctora en Derecho de la Universidad de los Andes; magíster en Estudios de Paz, Conflictos y Desarrollo por la Universidad de Innsbruck (Austria); especialista en Derecho Administrativo de la Universidad de Antioquia; y abogada de la Universidad Autónoma Latinoamericana.

Es profesora de planta de la Escuela de Derecho en la línea de Derecho Internacional, y está a cargo de los cursos Derecho internacional público y Derecho y sostenibilidad. Desde 2013 está afiliada como investigadora al Center for the Study of Law and Social Transformation (LawTransform), en Noruega. Sus investigaciones se centran en el litigio y la gobernanza del cambio climático, el derecho humano al agua y los debates contemporáneos sobre el reconocimiento de los derechos de la naturaleza, con especial interés en el estudio del río Atrato.

En la actualidad, participa como investigadora en diversos proyectos de investigación de EAFIT relacionados con la justicia transicional ecológica, la transición energética y las re-escrituras del futuro en torno a las narrativas del colapso ecológico.

Catalina Vallejo recibe este cargo de Nataly Montoya Restrepo, quien asumió la jefatura del Doctorado en Derecho.

### **Escuela de Finanzas, Economía y Gobierno**

Alejandra es doctora en Ética y Democracia de la Universidad de Valencia (España), magíster en Filosofía de la Universidad de Antioquia, y filósofa de la Universidad de Antioquia.

Desde 2010 está vinculada a EAFIT como profesora de tiempo completo y, en la actualidad, hace parte de la Escuela de Finanzas, Economía y Gobierno, donde se desempeña como directora del Observatorio Legislativo Antioquia Visible – Valor Público.

Sus temas de interés se concentran en temas como idearios políticos, ética y filosofía moral, violencia, filosofía política y rendición de cuentas y democracia. Como parte de ese recorrido, ha publicado diversos artículos en revistas como Daímon. Revista Internacional de Filosofia, Co-Herencia, y Cuadernos de Trabajo en Gobierno y Ciencias Políticas, entre otras.

Alejandra recibe este cargo de Juan Carlos Muñoz, quien continuará con sus labores académicas e investigativas.

Atentamente,

**Ricardo Taborda Ríos**

Decano de la Escuela de Ciencias Aplicadas e Ingeniería.

**Verónica Uribe Hanabergh**

Decana de la Escuela de Artes y Humanidades.

**Esteban Hoyos Ceballos**

Decano de la Escuela de Derecho.

**Cesar Eduardo Tamayo Tobón**

Decano de la Escuela de Finanzas, Economía y Gobierno.

Comunicado n°6
