Title: Carnetización

URL Source: https://www.eafit.edu.co/carnetizacion

Markdown Content:
# Carnetización - Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

[![Image 3: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 4: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 5: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 6: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 7: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 8: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Información para ti

[![Image 9: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 10: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 11: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 12: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 13: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 14: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 15: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 16: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 17: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Pasar al contenido principal](https://www.eafit.edu.co/carnetizacion#main-content)

[![Image 18: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 19: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 20: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/carnetizacion#)

[![Image 21: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/carnetizacion# "Spanish")[![Image 22: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/carnetizacion# "English")

 Información para ti

Buscar 

Búsqueda

Menú

![Image 23: Imagen de banner estudiantes caminando por campus EAFIT](https://universidadeafit.widen.net/content/f259173b-6ad7-4db9-a883-2505ff7c4c49/web/eafit-mejores-anios.jpg?crop=yes&k=c&w=1920&h=788&itok=0tFvQSmg)

# Oficina de Carnetización​

¡Solicita tu carné y disfruta de nuestro campus!​​

*   [Inicio](https://www.eafit.edu.co/)
*   [Idiomas](https://www.eafit.edu.co/idiomas)
*    ¿Por Qué Estudiar Idiomas En EAFIT? 

###### Te informamos el paso a paso para que solicites tu carné y​​ puedas disfrutar de nuestro campus.

1.   **Asegúrate que tu documento de identidad este actualizado en el sistema EPIK**, de lo contrario debes tráelo al bloque 29, piso 1, ¡En Registro Académico!
2.   **Verifica el último dígito de tu documento de identidad**, si termina en 0,2,4,6 y 8 podrás solicitarlo los días pares del mes y los documentos terminados en 1,3,5,7 y 9 los días impares.
3.   **Presenta el documento de identidad en la oficina de Carnetización**, ubicada en el bloque 3, oficina 106, el día que te corresponda.
4.   **¡Prepárate para la foto!** No debes traer prendas blancas.​

**Ubicación:**bloque 7, primer piso, al lado de la entrada del Gimnasio.

**Horario:** lunes a viernes de 8:00 a.m., a 12:00 m., y 2:00 p.m., a 6:00 p.m. Sábados 8:00 a.m., a 12:00 m.

**Correo:**[oficinacarnetizacion@eafit.edu.co](mailto:oficinacarnetizacion@eafit.edu.co)

**Teléfono:** (57) 604 2619500 ext. 9181

*   [Tenga en​​ cuenta](https://www.eafit.edu.co/carnetizacion#4257225834-1603938689)
*   [Carnetiz​​ac​​ión](https://www.eafit.edu.co/carnetizacion#4257225834-2641685581)
*   [Definici​ones](https://www.eafit.edu.co/carnetizacion#4257225834-2591618546)
*   [Benefic​ios del carné](https://www.eafit.edu.co/carnetizacion#4257225834-3392953746)
*   [Condici​​​ones de uso](https://www.eafit.edu.co/carnetizacion#4257225834-1970206958)
*   [Recomendacion​​​es sobre el cuidado del carné](https://www.eafit.edu.co/carnetizacion#4257225834-134708983)
*   [Solicitud de carn​é con Foto por primera vez​](https://www.eafit.edu.co/carnetizacion#4257225834-1568277618)
*   [Solicitud de carné sin Foto por primera vez​](https://www.eafit.edu.co/carnetizacion#4257225834-3100603464)
*   [Solicitud de rep​​osición de carné​](https://www.eafit.edu.co/carnetizacion#4257225834-972594897)
*   [​​​​​​​​​​​​En caso de hurto o pérdida del carné](https://www.eafit.edu.co/carnetizacion#4257225834-1345395864)
*   [Falla​s técnicas del carné](https://www.eafit.edu.co/carnetizacion#4257225834-3388257750)
*   [Traslado de saldo](https://www.eafit.edu.co/carnetizacion#4257225834-397664532)
*   [​​​​​​​​​​​Conservación del carné](https://www.eafit.edu.co/carnetizacion#4257225834-699220547)

[Tenga en​​ cuenta](https://www.eafit.edu.co/carnetizacion#4257225834-1603938689)

Tenga en​​ cuenta

**Si su carné tiene foto**, le servirá para cualquier vínculo que adquiera con la Universidad EAFIT.

**​Si su carné no tiene foto**, le servirá para cualquier programa de extensión en el que se matricule en la Universidad EAFIT.​

**Consérvelo** después de que se inactive por lo menos un año más. Cuando adquiera un nuevo vínculo con EAFIT se reactivará automáticamente.

Los graduados y pensionados tendrán activos sus carnés de forma permanente.

**Cuídelo**para evitar trámites de reposición.

**Pórtelo**siempre para evitar hacer registro como visitante cuando ingrese a EAFIT.

[Carnetiz​​ac​​ión](https://www.eafit.edu.co/carnetizacion#4257225834-2641685581)

Carnetiz​​ac​​ión

Las políticas sobre el proceso de carnetización de la Universidad EAFIT tienen como objetivo establecer los lineamientos de uso, expedición, activación, reactivación, inactivación y pago de los carnés institucionales.​

El contenido detallado de las políticas podrá ser consultado en este [link](https://universidadeafit.widen.net/s/gj82f58g7b/politicas-carnetizacion)

[Definici​ones](https://www.eafit.edu.co/carnetizacion#4257225834-2591618546)

Definici​ones

​Carné: es un documento de identificación que da cuenta de algún tipo de vínculo o relación con la Universidad.

Carné activo: atributo asignado al carné cuando su titular tiene algún vínculo activo con la Universidad.

Reposición de carné: cambio del carné actual por un nuevo carné.

Saldo: Término utilizado para referirse a la cantidad de dinero cargado en el carné para su uso como monedero electrónico en la universidad.

​Vínculo: indica el tipo de relación que una persona tiene con la Universidad.

[Benefic​ios del carné](https://www.eafit.edu.co/carnetizacion#4257225834-3392953746)

Benefic​ios del carné

Ingreso a los diferentes espacios de la Universidad.

Acredita a la persona como miembro de la comunidad eafitense.

Préstamo de material bibliográfico, ayudas audiovisuales, herramientas en los laboratorios y demás servicios que requieran la identificación de la persona como miembro de la comunidad eafitense.

Uso de casilleros electrónicos y parqueadero.​

[Condici​​​ones de uso](https://www.eafit.edu.co/carnetizacion#4257225834-1970206958)

Condici​​​ones de uso

​El carné es personal e intransferible y todas las acciones realizadas con el carné se entienden como efectuadas por su titular.

Es deber del titular portarlo y presentarlo cuando sea necesario.

El titular del carné es responsable de informar de manera inmediata el hurto o pérdida del mismo con el fin de que sea desactivado, y evitar que otras personas hagan mal uso de éste o consuman el saldo del mismo.​

[Recomendacion​​​es sobre el cuidado del carné](https://www.eafit.edu.co/carnetizacion#4257225834-134708983)

Recomendacion​​​es sobre el cuidado del carné

Evite escribir sobre él, rasparlo, cortarlo, plastificarlo, doblarlo, perforarlo o aplicarle algún tipo de fuerza.

Evite colocarlo cerca de objetos que generen calor, elementos magnéticos, imanes.

Evite guardarlo en los bolsillos del pantalón sin la debida protección.

Evite guardarlo con objetos metálicos como monedas o llaves.

Manténgalo seco, la humedad y los líquidos pueden dañar los circuitos electrónicos.

Puede limpiar la superficie con paños suaves, sin utilizar líquidos corrosivos.

El carné debe conservarse separado de teléfonos móviles y otras tarjetas con chip, ya que éstos impiden que los lectores lo detecten.

Para su lectura ubicarlo sobre el lector a una distancia máxima de cinco (5) centímetros.

[Solicitud de carn​é con Foto por primera vez​](https://www.eafit.edu.co/carnetizacion#4257225834-1568277618)

Solicitud de carn​é con Foto por primera vez​

​Este carné está diseñado ​para identificar a las personas que adquieren alguno de los siguientes vínculos con la Universidad EAFIT:

​Estudiante de pregrado admitido

​Estudiante de pregrado matriculado​

Estudiante de posgrado

Graduado

Empleado

Aprendiz

Pensionado

![Image 24: carne-foto.jpeg](https://universidadeafit.widen.net/content/v542sdftij/jpeg/carne-foto.jpeg?w=640&keep=c&crop=yes&color=cccccc&quality=80&u=gab6en)
**En caso que la person​​​a posea este tipo carné, no deberá realizar el trámite de solicitud de carné.​**

[Procedimiento para estudiantes de pregrado, posgrado y empleados.](https://universidadeafit.widen.net/s/xbddf9pn6t/doc1-solicitud-carne-con-foto-primera-vez)

[Procedimiento para la solicitud del carné con​ foto para ceremonia de grado**.**](https://universidadeafit.widen.net/s/grmvqdrpsz/doc2-solicitud-carne-foto-ceremonias-de-grado)

[Solicitud de carné sin Foto por primera vez​](https://www.eafit.edu.co/carnetizacion#4257225834-3100603464)

Solicitud de carné sin Foto por primera vez​

Este carné está diseñado para identificar a las personas que adquieren alguno de los siguientes vínculos con la Universidad EAFIT:

Participante Alta Dirección

Participante Educación Continua

Participante Idiomas

Participante Deportes

Participante Desarrollo Artístico

Participante EAFIT Social

Participante Instituto Confucio

Participante Nivelatorio de Becas

Participante Universidad de los Niños​

Para solicitar este tipo de carné la persona no deberá realizar trámites, ya que será un funcionario responsable en cada dependencia el encargado de realizar la solicitud de expedición del carné a la oficina de carnetización.

Este carné es entregado por el funcionario designado por la dependencia durante los primeros días de inicio de actividades del futuro titular.

Para los menores de ​12 años, el carné deberá ser reclamado por el acudiente responsable.

![Image 25: carne-sin-foto.jpeg](https://universidadeafit.widen.net/content/ktrwnqgpvc/jpeg/carne-sin-foto.jpeg?w=640&keep=c&crop=yes&color=cccccc&quality=80&u=gab6en)

[Solicitud de rep​​osición de carné​](https://www.eafit.edu.co/carnetizacion#4257225834-972594897)

Solicitud de rep​​osición de carné​

**El carné se repone sin costo para el titular en los siguientes c​asos:**

​Si el titular adquiere de nuevo un vínculo con la Universidad luego de un periodo de inactividad de**más de un año** y no posee el carné entregado anteriormente.

En caso de errores de impresión.

En caso de presentarse fallas técnicas del carné por causas distintas a un mal uso del mismo.

En caso que su nuevo vínculo amerite el cambio de tipo de carné según las políticas de expedición de carné.

**El carné se repone con costo para el titular en los siguientes casos:**

​​El titular extravía el carné o le fue hurtado.

Se evidencia mal uso: doblado, quebrado, quemado, fisurado, derretido, rayado, mordido, cortado, perforado, entre otras.

En caso que el titular lo desee reponer para cambiar de foto, por cambio de nombre o por voluntad propia.

Si el titular adquiere de nuevo un vínculo con la Universidad luego de un periodo de inactividad de menos de un año y no posee el carné entregado anteriormente. En caso que su nuevo vínculo amerite el cambio de tipo de carné según las políticas de expedición de carné, este se generará sin costo independientemente del tiempo de inactividad.

En caso que el carné no sea compatible con la tecnología actual de acceso a la Universidad.

El valor a pagar por el carné será el valor vigente en la fecha de solicitud de generación de carné.

[Ver tarifas generales EAFIT​](https://www.eafit.edu.co/tarifas)

[Procedimiento para reposición de carné con foto ​​](https://universidadeafit.widen.net/s/rl7nvcld8d/procedimiento-reposicion-foto)

[Procedimiento para repo​sición de carné sin foto​](https://universidadeafit.widen.net/s/dqbmlxm2fs/doc4-procedimiento-reposicion-sin-foto)

[​​​​​​​​​​​​En caso de hurto o pérdida del carné](https://www.eafit.edu.co/carnetizacion#4257225834-1345395864)

​​​​​​​​​​​​En caso de hurto o pérdida del carné

1.   ​El titular del carné deberá comunicarse con la oficina de Carnetización o con la línea segura de la Universidad al 2619500 Ext. 8744 o 2619307, esta línea está disponible las 24 horas.
2.   Se recomienda formular el denuncio de pérdida de documento ante las autoridades competentes.
3.   El titular deberá realizar el trámite de reposición de carné.

[Falla​s técnicas del carné](https://www.eafit.edu.co/carnetizacion#4257225834-3388257750)

Falla​s técnicas del carné

Si el carné no le permite a su titular hacer uso de los controles de acceso o máquinas de recarga, deberá dirigirse a la oficina de carnetización en los horarios de atención establecidos, donde el funcionario encargado determinará la causa de dicha situación y le indicará el procedimiento a seguir. ​​​​​​​​​​​

[Traslado de saldo](https://www.eafit.edu.co/carnetizacion#4257225834-397664532)

Traslado de saldo

Para todos los casos en los cuales se entrega un nuevo carné y el titular tiene saldo en un carné anterior, podrá realizar la gestión de traslado del saldo al nuevo carné.

El traslado de saldos entre carnés, sólo s e realiza entre carnés de un mismo titular.

Para realizar el traslado, el titular del carné deberá dirigirse con el nuevo carné a la oficina de atención de servicio de parqueaderos.

[​​​​​​​​​​​Conservación del carné](https://www.eafit.edu.co/carnetizacion#4257225834-699220547)

​​​​​​​​​​​Conservación del carné

Al finalizar su vínculo, el titular debe conservar el carné como mínimo por un año, lo anterior con el fin que este documento sea reactivado en caso de adquirir nuevamente un vínculo con la universidad. Esto no aplica para titulares de carné Externo.

Los graduados y pensionados tendrán activos sus carnés de forma permanente.

​​​​​​​​​​​​Información relacionada

## Tarifas generales EAFIT​​

[Ver tarifas](https://www.eafit.edu.co/tarifas)

## Reglamento de ingreso y uso de parqueadero

[Ver reglamento](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular)

## Procedimiento para solicitud de carné externo​​

[Ver procedimiento](https://universidadeafit.widen.net/s/tncmjzjqtm/doc6-instructivo-para-la-solicitud-entrega-y-custodia-de-carnes-de-servicio-externo)

## Guía de aspirantes de pregrado

[Ver guía](https://www.eafit.edu.co/guia-aspirantes-pregrado)

## Guía de aspirantes de posgrado

[Ver guía](https://www.eafit.edu.co/guia-solicitantes-de-posgrado)

## Circular de grados para pregrado

[Ver circular](https://www.eafit.edu.co/circular-de-grados-para-pregrado)

## Circular de grado para posgrado

[Ver circular](https://www.eafit.edu.co/circular-de-grado-para-posgrado)

![Image 26: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

![Image 27: cambio-de-carne.jpeg](https://universidadeafit.widen.net/content/bmbbz2qbic/jpeg/cambio-de-carne.jpeg?w=640&keep=c&crop=yes&color=cccccc&quality=80&u=gab6en)

###### Preguntas frecuentes

*   [¿Qué debo hacer si quiero actualizar la foto del carné?](https://www.eafit.edu.co/carnetizacion#230548828-3668790145)
*   [Si mi carné no funciona, ¿Qué debo hacer?](https://www.eafit.edu.co/carnetizacion#230548828-3462686752)
*   [¿Dónde está ubicada la oficina de carnetización?](https://www.eafit.edu.co/carnetizacion#230548828-2390883605)
*   [¿Cuál es el horario de la oficina de carnetización?](https://www.eafit.edu.co/carnetizacion#230548828-1201318059)
*   [Cuando cancelo semestre o termino contrato laboral con la Universidad, ¿Debo devolver el carné?​](https://www.eafit.edu.co/carnetizacion#230548828-792358568)
*   [Si no tengo vínculos activos con la Universidad, ¿Puedo desechar el carné?](https://www.eafit.edu.co/carnetizacion#230548828-829014179)
*   [¿Qué pasa si la persona, después de un periodo de inactividad, adquiere de nuevo un vínculo y no tiene el carné?](https://www.eafit.edu.co/carnetizacion#230548828-3515834084)
*   [Si pierdo mi carné, ¿Qué debo hacer?](https://www.eafit.edu.co/carnetizacion#230548828-2266629756)
*   [Si pierdo mi carné, ¿Pierdo el saldo que tenía en él?](https://www.eafit.edu.co/carnetizacion#230548828-4083894431)
*   [¿Cómo se puede pagar la reposición del carné?](https://www.eafit.edu.co/carnetizacion#230548828-3543276235)
*   [¿Cuándo se inactiva el carné?](https://www.eafit.edu.co/carnetizacion#230548828-1953957703)
*   [Si no tengo carné de la Universidad, ¿Cómo puedo ingresar?](https://www.eafit.edu.co/carnetizacion#230548828-119567628)

[¿Qué debo hacer si quiero actualizar la foto del carné?](https://www.eafit.edu.co/carnetizacion#230548828-3668790145)

Debes realizar el trámite de reposición de carné.

Ten en cuenta que tiene un costo.​

[Si mi carné no funciona, ¿Qué debo hacer?](https://www.eafit.edu.co/carnetizacion#230548828-3462686752)

Dirígete a la Oficina de Carnetización (ubicada en el bloque 7, primer piso) para que validen el estado de tu carné y corrijan la anomalía.

**Ingreso temporal:** Podrás acceder al campus en calidad de visitante presentando tu documento de identidad (físico o digital) en la portería.

[¿Dónde está ubicada la oficina de carnetización?](https://www.eafit.edu.co/carnetizacion#230548828-2390883605)

La oficina se encuentra en el **Bloque 7, primer piso,** justo al lado del **Gimnasio Vivo**.

[¿Cuál es el horario de la oficina de carnetización?](https://www.eafit.edu.co/carnetizacion#230548828-1201318059)

​Lunes a viernes de 8:00 a.m., a 12:00 m., y de 2:00 p.m., a 6:00 p.m.

Sábados de 8:00 a.m., a 12:00 m.​

**No abre domingos ni festivos.​**

[Cuando cancelo semestre o termino contrato laboral con la Universidad, ¿Debo devolver el carné?​](https://www.eafit.edu.co/carnetizacion#230548828-792358568)

No, porque el carné es único y le sirve a la persona para cualquier vínculo que adquiera en el futuro con la Universidad.

Solo en caso de ser portador de un carné externo deberás realizar la devolución.

[Si no tengo vínculos activos con la Universidad, ¿Puedo desechar el carné?](https://www.eafit.edu.co/carnetizacion#230548828-829014179)

El carné se debe conservar, ya que cuando la persona regrese, el carné se reactivará automáticamente.

[¿Qué pasa si la persona, después de un periodo de inactividad, adquiere de nuevo un vínculo y no tiene el carné?](https://www.eafit.edu.co/carnetizacion#230548828-3515834084)

Si pasó más de un año de inactividad, se genera sin costo.

Si pasó menos de un año de inactividad, se genera con costo.

Estas condiciones no aplican para el vínculo de graduado o pensionado, dado que son vínculos perpetuos y siempre estarán activos.

[Si pierdo mi carné, ¿Qué debo hacer?](https://www.eafit.edu.co/carnetizacion#230548828-2266629756)

Se recomienda formular el denuncio de pérdida correspondiente ante la autoridad competente y reportar la pérdida de este a la central de monitoreo (extensiones 9307-8744-9181) u oficina de carnetización para su bloqueo. La reposición del carné se realiza en la oficina de carnetización.

[Si pierdo mi carné, ¿Pierdo el saldo que tenía en él?](https://www.eafit.edu.co/carnetizacion#230548828-4083894431)

No, el saldo que tenías disponible en el momento de reportar la pérdida será trasladado al nuevo carné luego de la solicitud del afectado.

[¿Cómo se puede pagar la reposición del carné?](https://www.eafit.edu.co/carnetizacion#230548828-3543276235)

**Pago presencial:** Dirígete a los puntos de recaudo de **Tesorería**, ubicados en el Bloque 29, primer piso.

**Pago en línea:** a través del aplicativo web Recaudos. Ingresa [aquí](https://app.eafit.edu.co/recaudos/)

[¿Cuándo se inactiva el carné?](https://www.eafit.edu.co/carnetizacion#230548828-1953957703)

El carné se inactiva solo al momento de ser reportado como pérdida o hurto. ​

[Si no tengo carné de la Universidad, ¿Cómo puedo ingresar?](https://www.eafit.edu.co/carnetizacion#230548828-119567628)

​Debes hacer registro como visitante en cualquiera de las porterías que estén habilitadas para este registro. Como visitante debes presentar tu documento de identidad original o digital, también puedes presentar el denuncio de pérdida vigente; de lo contrario, no se te permitirá el ingreso.

##### Contac​to

###### Oficina de Carneti​zación

**Ubicación: Bloque 7, primer piso contigua al Gimnasio.**

Horario: lunes a viernes 8:00 am a 12:00 m y 2:00 pm a 6:00 pm Sábados 8:00 am a 12:00 m.

Correo: [**jfcastanot@e​afit.edu.co**](mailto:jfcastanot@e%E2%80%8Bafit.edu.co)**,**[**oficinacarnetizacion@eafit.edu.co**](mailto:oficinacarnetizacion@eafit.edu.co)

Teléfono: ​​(57) 604 2619500 Ext. 9181

###### Puntos de recaudo

**Tesorería**

**Ubicación:** bloque 29 Primer piso

**Horario:** lunes a viernes de 8:00 a.m., a 5:00 p.m. 

**Teléfono:** (57) 604 2619500 Ext. 9612

Correo electrónico: [**soportescaja@eafit.edu.co**](mailto:soportescaja@eafit.edu.co)

**Aplicación Web “Recaudos”**

[Ver "Recaudos EAFIT"​](http://webapps.eafit.edu.co/recaudos/?_ga=2.23031609.320824152.1737400167-1304622036.1736972885)

Esta aplicación permite realizar en línea el pago de la reposición del carné institucional, eligiendo la opción “Pago de carné”.

El pago igualmente se podrá efectuar en cualquier sucursal de Bancolombia imprimiendo desde dicho aplicativo la respectiva liquidación.​

[Conoce más contactos clave](https://www.eafit.edu.co/contactos-clave-primarios)

![Image 28: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 29: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 30: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 31: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 32: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 33: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 34: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 35: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 36](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
