Title: Estatutos, reglamentos​, políticas y protocolos

URL Source: https://www.eafit.edu.co/institucional/reglamentos/reglamentos

Published Time: Thu, 07 May 2026 20:55:16 GMT

Markdown Content:
###### Estatutos Generales

[Estatutos generales​​](https://universidadeafit.widen.net/view/pdf/rq74uxag3e/estatutos-generales.pdf)

###### Reglam​​e​​ntos académicos

[Reglamento Académico de los programas de pregrado](https://www.eafit.edu.co/institucional/reglamentos/reglamento-academico-de-los-programas-de-pregrado)

[Reglamento Académico de los programas de posgrado​​](https://www.eafit.edu.co/institucional/reglamentos/reglamento-academico-de-los-programas-de-posgrado)

###### Estat​uto Pr​​ofesoral

[Estatuto Profesoral 2022](https://www.eafit.edu.co/profes-que-inspiran/estatuto-profesoral)

[Estatuto Profesoral 2012](https://universidadeafit.widen.net/view/pdf/0zzwvrouzn/estatuto-profesoral-2012.pdf)

[Estatuto Profesoral 2000](https://universidadeafit.widen.net/view/pdf/ufdslljgzw/estatuto-profesoral-2000.pdf)

[Reglamento para la promoción de los profesores entre las categorías de la carrera académica​​](https://universidadeafit.widen.net/view/pdf/lblcs2bir3/resolucion-reglamentaria-para-ascensos-docentes.pdf)

###### Declaraci​​ones de nu​​estra Universidad

[Nuestras declaraciones ​​i​​nstitucion​al​​es](https://www.eafit.edu.co/institucional/valores/nuestras-declaraciones-institucionales)

[Declaración de nuestro compromiso con la diversidad, la inclusión y el pluralismo​](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/declaracion-compromiso-diversidad-inclusion-pluralismo)

###### Reglamento​​​s y polí​​​ticas generales

[Diagnóstico de diversidad, equidad de género e inclusión​](https://universidadeafit.widen.net/s/jxf2djfpj9/diagnostico-diversidad-equidad-inclusion)

[Política sobre relaciones íntimas consensuales en el entorno académico y laboral de la Universidad EAFIT](https://universidadeafit.widen.net/s/jlplbttwqx/politica-relaciones-intimas-consensuadas-vf-11-octubre-2024)

[Política sobre conflicto de intereses​](https://universidadeafit.widen.net/s/bwjvwbxdpc/politica-sobre-conflicto-de-intereses-2024)

[Política de tratamiento de protección de datos personales de los titulares](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

[Reglamento de contratación](https://universidadeafit.widen.net/s/nf7sxbqpdw/reglamentos-de-contratacion-de-la-universidad-eafit)

[Reglamento de elección y representación](https://universidadeafit.widen.net/view/pdf/axwl9urrkv/reglamento-de-eleccion-representacion.pdf?u=klt7lh)

[Política de permanencia estudiantil y graduación oportuna​](https://universidadeafit.widen.net/s/sgzppcvzwr/politica-de-permanencia-y-graduacion-oportuna-eafti-2024)

[Reglamento de los Consejos de Escuela](https://universidadeafit.widen.net/view/pdf/uxtm911zgn/reglamento-consejos-escuelas.pdf)

[Política de Gestión de Riesgos](https://universidadeafit.widen.net/s/pfmkhdjsdn/politica-firmada-2026)

###### Reglame​ntos y polít​​icas sobre espacios y recursos

[Reglamento fuera de los predios de la Universidad](https://www.eafit.edu.co/institucional/reglamentos/paginas/reglamento-fuera-universidad)

[Reglamento para la utilización de las aulas para audiovisuales y sus respectivos equipos](https://www.eafit.edu.co/reglamentos-aulas-y-equipos-audiovisuales)

[Reglamento de ingreso peatonal y vehicular](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular)

[Políticas de tecnología](https://www.eafit.edu.co/politicas-de-tecnologia)

[Política de seguridad vial​](https://universidadeafit.widen.net/s/wlf82m9jsz/politica-de-seguridad-vial)

[​Protocolo para el ingreso​​ y la permanencia de mascotas en el campus​​​](https://www.eafit.edu.co/mascotas)

###### Políticas, reglam​entos y prot​​ocolos de Ciencia Tecnología e Innovación​​

[Política de Ciencia, Tecnología e Innovación](https://universidadeafit.widen.net/s/tf5mgwqlgr/universidad_eafit_politica_ctei_2025)

[Reglamento interno del Comité de Ciencia Tecnología e Innovación de Escuela](https://universidadeafit.widen.net/view/pdf/hixm25t8ir/reglamento-comite-ctei-de-escuela.pdf)

[Reglamento del Comité de Ciencia, Tecnología e Innovación](https://universidadeafit.widen.net/view/pdf/ftfdmfqcju/reglamento-comite-de-ciencia-tecnologia-e-Innovacion.pdf)

[Reglamento de propiedad intelectual](https://universidadeafit.widen.net/s/mnhqtdmpdp/reglamento-propiedad-intelectual-enero-2018-1)

###### Reglam​entos y prot​​ocolos específicos de programas académicos

[Protocolo de salidas de campo](https://www.eafit.edu.co/protocolo-de-salidas-de-campo)​

[Reglamento de los trabajos de investigación para optar el título de especialista](https://www.eafit.edu.co/reglamentos-trabajos-de-grado-titulo-de-especialista)

[Reglamento de trabajos de investigación de maestrías​](https://universidadeafit.widen.net/view/pdf/6i0w68zxii/reglamentotrabajoinvestigacion-maestrias-1.pdf?t.download=true&u=ftfwep)

[Reglamento ​​​Consultorio Jurídico](https://universidadeafit.widen.net/s/k2fcvnpg9w/reglamento-consultorio-juridico)

[Reglamento del doctorado en Humanidades​​](https://universidadeafit.widen.net/s/whhp86jmfr/reglamento-dh-2012)

###### Reglamentos y pol​​ítica​​s de asuntos estudiantiles​

[Política de ventas por parte de estudiantes de pregrado](https://universidadeafit.widen.net/s/lsdfdvsfp5/politica-ventas-estudiantes-de-pregrado)

[Reglamento económico académico](https://universidadeafit.widen.net/s/wggqcsdnhf/reglamento_economico)

[Reglamento de experiencias de talento](https://universidadeafit.widen.net/s/cftmswfhnp/reglamento-de-experiencias-de-talento)

###### Reglamentos para estudiantes de pregrado​

[Reglamento académico de los programas de pregrado](https://www.eafit.edu.co/institucional/reglamentos/reglamento-academico-de-los-programas-de-pregrado)

[Reglamento de prácticas profesionales](https://universidadeafit.widen.net/s/cftmswfhnp/reglamento-de-experiencias-de-talento)

[Reglamento económico académico](https://universidadeafit.widencollective.com/assets/share/asset/tzpwxrqwih)

###### Prot​​ocolos

[Protocolo institucional para la participación de candidaturas en el campus Medellín y las sedes de la Universidad EAFIT-2026](https://universidadeafit.widen.net/s/vkdd2t6hm2/protocolo-institucional-para-la-participacion-de-candidaturas-en-el-campus-medellin-y-las-sedes-de-la-universidad-eafit-2026)

[Protocolo de Funcionamiento de Experiencias de Aprendizaje en Campus Universidad de los Niños EAFIT](https://universidadeafit.widen.net/s/c92lm9nrpf/protocoo-funcionamiento-experiencia-aprendizaje-campus-universidad-de-los-ninos-eafit)

[Protocolo de Actuación para Asambleas Estudiantiles](https://universidadeafit.widen.net/s/cprjldslfn/protocolo-asambleas-marzo2026)
