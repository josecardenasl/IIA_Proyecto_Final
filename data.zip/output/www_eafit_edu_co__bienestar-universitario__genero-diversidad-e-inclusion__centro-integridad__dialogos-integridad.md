Title: Diálogos de integridad

URL Source: https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad

Markdown Content:
# Diálogos de integridad - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner conexion sistemas publicos](https://universidadeafit.widen.net/content/838dc642-5948-4c5a-acd1-00723d11105b/web/conexion-sistemas-publicos-comuna13%20(1).jpg?crop=yes&k=c&w=1920&h=788&itok=_Li3K9_u)

# Diálogos de integridad

*   [Inicio](https://www.eafit.edu.co/)
*   [Bienestar Universitario](https://www.eafit.edu.co/bienestar-universitario)
*   [Género, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Centro de Integridad​​](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad)
*    Diálogos de Integridad 

*   [Ciudadanía íntegra digital ¿Para qué la ética en entornos digitales?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-2958771137)
*   [Integridad y Género: Hacia la construcción de nuevas masculinidades.](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-1297345559)
*   [¿Generamos un ambiente de respeto en el campus?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-1340558186)
*   [La integridad en la tecnología](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-3321282590)
*   [Respeto y tolerancia ¿Qué tanto aceptamos la sexualidad diversa en Colombia?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-1786120145)
*   [Integridad vs Fraude Académico](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-43316184)
*   [¿Por qué hablar de acoso sexual en universidades?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-2195172038)

[Ciudadanía íntegra digital ¿Para qué la ética en entornos digitales?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-2958771137)

Ciudadanía íntegra digital ¿Para qué la ética en entornos digitales?

**Diálogo de Integridad Ciudadanía íntegra digital: ¿Para qué la ética en entornos digitales?**

**Participantes:**

Perla Toro Castaño, Responsable de Comunicaciones de Comfama.

Jonathan Echeverri, profesor de psicología de la Universidad EAFIT e investigador del Centro de Integridad.

**Modera:** Camilo Guzmán, consultor del Centro de Integridad.

[Integridad y Género: Hacia la construcción de nuevas masculinidades.](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-1297345559)

Integridad y Género: Hacia la construcción de nuevas masculinidades.

**Diálogo de integridad y Género: Hacia la construcción de nuevas masculinidades.**

**Conversación entre:**

Andrés Olaya, profesor de la Universidad de Antioquia, la Universidad EAFIT y Universidad del Norte.

Pablo Bedoya, profesor de la Universidad de Antioquia.

**Mo​dera:** Nathalia Franco Pérez, Jefe del Centro de Integridad, Universidad EAFIT.

Marzo 16 de 2021​

[¿Generamos un ambiente de respeto en el campus?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-1340558186)

¿Generamos un ambiente de respeto en el campus?

**¿Generamos un ambiente de respeto en el campus?:**

**Fecha:** 1 de octubre de 2018.

De la mano de Tatiana Romero Acevedo, coordinadora del grupo de justicia, y Ana Cristina Restrepo Jiménez, periodista y docente de cátedra en EAFIT, se habló sobre el nuevo proyecto de #RespetoEnEafit que busca desnaturalizar ciertas conductas que fomentan el irrespeto, además de abrir un canal de contacto para los casos y protocolo para la equidad de género y la sexualidad diversa.

[La integridad en la tecnología](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-3321282590)

La integridad en la tecnología

**La integridad en la tecnología: construyendo una ciudadanía digital**

**Fecha:**5 de abril de 2019.

De la mano de Juan Cristóbal Cobo, director de la Fundación Ceibal, y Diego Ernesto Leal, director del Centro de Excelencia en EAFIT, se habló sobre la incidencia de la tecnología en los procesos de aprendizaje y en las relaciones humanas.

[Respeto y tolerancia ¿Qué tanto aceptamos la sexualidad diversa en Colombia?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-1786120145)

Respeto y tolerancia ¿Qué tanto aceptamos la sexualidad diversa en Colombia?

De la mano de Mauricio Albarracín, investigador de Dejusticia y activista LGTBI , y de Carlos Julio Benjumea, profesor de Derecho de la Universidad EAFIT, se conversó sobre la manera como se vive en Colombia la tolerancia y el respeto por la sexualidad diversa, a nivel político, social, histórico y jurídico.

[Integridad vs Fraude Académico](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-43316184)

Integridad vs Fraude Académico

De la mano de Jean Guerrero, director del Centro de Integridad de la Universidad de Monterrey, y Pablo Andrés Estrada, estudiante de Ciencias Políticas y Economía, y representante estudiantil de pregrado ante el COnsejo Académico. Conversaron sobre el fraude académico y los efectos de la virtualidad en el proceso formativo.

[¿Por qué hablar de acoso sexual en universidades?](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/dialogos-integridad#4257225834-2195172038)

¿Por qué hablar de acoso sexual en universidades?

**Diálogo de integridad ¿Por qué hablar de acoso sexual en universidades?**

Miradas desde Chile, México y Colombia. Con: Karla Urriola, Oficina Nacional de Género y Comunidad Segura del TEC de Monterrey . Cecilia Rosales, Consejo de Prevención y Apoyo a Víctimas de Violencia Sexual, Pontificia Universidad Católica de Chile. María Ximena Dávila, investigadora de Dejusticia Colombia. Nathalia Franco, jefa del Centro de Integridad de EAFIT. Universidad EAFIT. Octubre 21 de 2020.

La Universidad EAFIT tiene la Misión de Contribuir al desarrollo sostenible de la humanidad mediante la oferta de programas que estimulen el aprendizaje a lo largo de la vida, promuevan el descubrimiento y la creación y propicien la interacción con el entorno, dentro de un espíritu de integridad, excelencia, pluralismo e inclusión.​​

![Image 22: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 23: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 24: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 25: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 26: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 27: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 28: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 29: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
