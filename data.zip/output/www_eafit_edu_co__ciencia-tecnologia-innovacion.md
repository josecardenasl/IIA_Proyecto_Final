Title: Sistema Ciencia, Tecnología e Innovación

URL Source: https://www.eafit.edu.co/ciencia-tecnologia-innovacion

Markdown Content:
# Sistema Ciencia, Tecnología e Innovación - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/ciencia-tecnologia-innovacion#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/ciencia-tecnologia-innovacion#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/ciencia-tecnologia-innovacion# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/ciencia-tecnologia-innovacion# "English")

*   [Spanish](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Inglés](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner chica con gafas de sol](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-05/Banner-CTeIBanner-CTeI-F.jpg?itok=fy7YkKgu)

# Ciencia, Tecnología e Innovación

Contribuimos a la transformación de nuestra sociedad mediante la generación, el uso y apropiación social del conocimiento.

[Conoce la convocatoria proyectos internos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/convocatorias/convocatoria-proyectos-internos)

*   [Inicio](https://www.eafit.edu.co/)
*    Sistema Ciencia, Tecnología e Innovación 

Desplegar menú
*   [Sistema CTeI](https://www.eafit.edu.co/ciencia-tecnologia-innovacion "Ancla menú")
*   [Impacto CTeI](https://www.eafit.edu.co/ciencia-tecnologia-innovacion "Ancla menú")
*   [Descubre y Crea](https://www.eafit.edu.co/ciencia-tecnologia-innovacion "Ancla menú")
*   [Historias y noticias](https://www.eafit.edu.co/ciencia-tecnologia-innovacion "Ancla menú")

## **Sistema CTeI**

**Nuestro propósito es contribuir a la transformación de la sociedad, abordando los grandes retos del presente y reflexionando sobre los del futuro.**

Investigamos la naturaleza y la sociedad, generando nuevo conocimiento.

Transferimos estos aprendizajes a las organizaciones, impulsando la innovación y el desarrollo tecnológico para que contribuyan a la solución de desafíos.

Promovemos la apropiación social del conocimiento y la construcción de una cultura que fomente la creatividad, el pensamiento crítico y la participación ciudadana.

Somos una comunidad de conocimientos y saberes aplicados que teje vínculos con el mundo para generar valor y desarrollo sostenible.

## Investigación

Dinamizamos la generación de conocimiento que transforme la sociedad, potenciando las capacidades del ecosistema de ciencia, tecnología e innovación a través de la gestión del ciclo de vida de la investigación.

[Conoce más sobre Investigación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion/investigacion)

## Innovación y Transferencia Tecnológica

Conectamos el conocimiento y las capacidades de EAFIT con las necesidades de las organizaciones, las industrias y la sociedad

[Conoce más sobre Innovación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico)

## Formación CTeI

Fomentamos una actitud científica para resolver problemas con curiosidad y pensamiento crítico, cultivando el asombro, desarrollando habilidades y competencias investigativas.

[Conoce más sobre formación CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacion-ciencia-tecnologia-innovacion)

## Cultura CTeI

Cultivamos la ciencia en el corazón de todos, con proyectos, contenidos, experiencias y metodologías que convierten la curiosidad y el descubrimiento en una forma de ver el mundo.

[Conoce más sobre cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)

Impacto CTeI

## Portafolio de tecnologías

[Conoce el portafolio](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias)

![Image 22: Innovación educativa CTeI](https://universidadeafit.widen.net/content/cd0dcafd-4607-4c2e-a2d0-650ab50b511d/web/innovacion-educativa-ctei.JPG?w=480&itok=mkCJrmTg)

## Servicios para organizaciones

[Conoce los servicios](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-consultorias-para-organizaciones-sistemas-publicos)

![Image 23: Innovación organizacional](https://www.eafit.edu.co/sites/default/files/styles/large/public/2026-03/Artes%20y%20Humanidades-6.jpg.webp?itok=jzu4ykEd)

## Política de CTeI

[Conoce la Política de CTeI](https://universidadeafit.widen.net/s/tf5mgwqlgr/universidad_eafit_politica_ctei_2025)

![Image 24: Publicaciones](https://universidadeafit.widen.net/content/4c7bc348-54cb-44d7-88a5-2a63bde9d2e1/web/publicaciones-2.jpg?w=398&itok=-GfgRafy)

## Red de las preguntas

[Conoce Red de las preguntas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/red-preguntas)

![Image 25: Manifiestos](https://www.eafit.edu.co/sites/default/files/styles/large/public/2025-08/Banner-Manifiestos2.jpg.webp?itok=ky_KMLvi)

## Propiedad intelectual

[Conoce más sobre PI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/propiedad-intelectual)

![Image 26: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

Descubre y Crea

![Image 27: Imagen Edición 179](https://universidadeafit.widen.net/content/6a17867e-91a9-4e98-a59b-be0831fa5a23/web/card-edicion-179.jpg?crop=yes&k=c&w=397&h=253&itok=Cr89PoIy)

Edición 179

En la presente edición, nos adentramos en el concepto de 'Incomprendidos' para explorar nuevas y persistentes incomprensiones en el mundo de la ciencia.

[Conoce la edición](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-179)

![Image 28: Imagen Edición 178](https://universidadeafit.widen.net/content/014fe3b8-795d-4516-9a04-f740e623b73e/web/card-1.jpg?crop=yes&k=c&w=397&h=253&itok=gttR7fKI)

Edición 178

En el centro de todo el trabajo sigue estando siempre nuestra gente, nuestra comunidad que dinamiza y genera impacto en la sociedad.

[Conoce la edición](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-178)

![Image 29: Imagen Edición 177](https://universidadeafit.widen.net/content/48186493-96da-4cb1-a346-87740d1557b6/web/card-2.jpg?crop=yes&k=c&w=397&h=253&itok=w05oZkUT)

Edición 177

Conoce la fuerte conexión de nuestra ciencia con los problemas tangibles de la sociedad.

[Conoce la edición](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-177)

![Image 30: Imagen Edición 176](https://universidadeafit.widen.net/content/91fbea2a-ebc5-4ccf-abb2-8aff500a1411/web/card-3.jpg?crop=yes&k=c&w=397&h=253&itok=47WExYq_)

Edición 176

Esta es una invitación a la reflexión y al intercambio de concepciones sobre apropiación social del conocimiento.

[Conoce la edición](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-176)

![Image 31: Imagen Edición 175](https://universidadeafit.widen.net/content/d4a9db46-1891-45a5-81f6-17f82f996444/web/card-4.jpg?crop=yes&k=c&w=397&h=253&itok=gjVv728b)

Edición 175

En este número ofrecemos insumos para la reflexión sobre las nuevas realidades que vivió el mundo en medio de la pandemia.

[Conoce la edición](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-175)

[Conoce la Revista Descubre y Crea](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea)

Centros de estudio e incidencia y otras capacidades

![Image 32: Imagen Centro de Valor Público](https://universidadeafit.widen.net/content/882e0096-0868-4ada-99c7-1540e347d4e1/web/centro-valor-publico.png?crop=yes&k=c&w=397&h=253&itok=gDdf7T71)

Centro de Valor Público

El Centro de Valor Público diseña, implementa y evalúa programas y políticas de seguridad y justicia, gobierno y democracia, desarrollo económico e inclusión social y diversidad, elaborando propuestas que aportan a la toma de decisiones basadas en evidencia que aporten a soluciones de corto, mediano y largo plazo.

[¿Qué hacemos y cómo impactamos desde el Centro de Valor Público?](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico)

![Image 33: Imagen URBAM – Centro de Estudios Urbanos y Ambientales ](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-07/comunicaci%C3%B3nurbam.jpg?itok=wDkNMthu)

URBAM – Centro de Estudios Urbanos y Ambientales

Urbam promueve entornos urbanos y rurales sostenibles e incluyentes que buscan el bienestar humano. Aborda territorios emergentes y en transición que se caracterizan por procesos acelerados de cambio, con problemáticas urbanas y ambientales de alta complejidad en el contexto de la región tropical.

[¿Qué hacemos y cómo impactamos desde URBAM?](https://www.eafit.edu.co/centros-estudio-incidencia/urbam/que-es-urbam)

![Image 34: Imagen In-sight](https://universidadeafit.widen.net/content/c28a7c55-4aa0-4755-a3ce-91850264bbe5/web/banner2-insight.jpg?crop=yes&k=c&w=397&h=253&itok=-sEWgX7O)

In-sight

Estudiamos a fondo el fenómeno del liderazgo, generamos conversaciones alrededor del tema, acompañamos a las organizaciones y contribuimos a la formación de líderes que generen impacto.

[Conoce este centro](https://www.eafit.edu.co/in-sight)

![Image 35: Imagen Innovación EAFIT](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2026-03/Generador-11.jpg?itok=5Kny2I8Z)

Innovación EAFIT

Somos la plataforma que conecta el conocimiento y las capacidades en ciencia, tecnología e innovación de EAFIT con las necesidades de las organizaciones, las industrias y la sociedad, tejiendo vínculos entre nuestras escuelas, grupos de investigación y centros de estudio e incidencia con el mundo.

[¿Qué hacemos y cómo impactamos desde Innovación EAFIT?](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 36: Imagen NODO](https://universidadeafit.widen.net/content/161e6b58-35ab-46ae-8f28-5e134697ea31/web/imagen-web-becas-fraternidad.png?crop=yes&k=c&w=397&h=253&itok=W7IvXXjj)

NODO

NODO es el centro de formación en nuevas tecnologías de la Universidad EAFIT. Desarrollan capacidades en personas y organizaciones, brindando soluciones a sus desafíos tecnológicos. Ofrecemos educación flexible, colaborativa y significativa.

[¿Qué hacemos y cómo impactamos desde NODO?](https://es.nodoeafit.com/)

![Image 37: Imagen Ongoing](https://universidadeafit.widen.net/content/e6bb22ca-0665-423f-b90d-016da779d94f/web/y-si-nos-dejamos-ayudar-por-la-ia.jpg?crop=yes&k=c&w=397&h=253&itok=BEVfxWv-)

Ongoing

Somos el Centro de Emprendimiento de Impacto de la Universidad EAFIT. Un universo donde creamos el nuevo tejido empresarial y dinamizamos la comunidad emprendedora de Colombia y América Latina.

[¿Qué hacemos y cómo impactamos desde OnGoing?](https://www.eafit.edu.co/ongoing)

##### Resultados e impacto del Sistema CTeI

[Investigación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion#4257225834-46045969)

Investigación

[![Image 38](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-07/Generador%20de%20Hidr%C3%B3geno%20bionspirado%20%284%29.jpg?itok=laI40zzY)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 39](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+31 %**

**de crecimiento en reputación en investigación según el Ranking QS (2019–2026)**

[![Image 40](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-07/banner-proyectos-ctei.jpg?itok=GWu1CqyU)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 41](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+21.000**

**citaciones a las publicaciones científicas de EAFIT en SCOPUS entre 2017 y 2024**

[![Image 42](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-05/2019-8M5A3525%20Lab.Mercadeo.jpg?itok=rusGzcDV)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 43](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+30 %**

**aumentó el impacto promedio de las publicaciones por campo del conocimiento**

[Transferencia de Tecnología](https://www.eafit.edu.co/ciencia-tecnologia-innovacion#4257225834-1606541522)

Transferencia de Tecnología

[![Image 44](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-09/KIT.png?itok=k-lLrwyf)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 45](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **8**

**spin-offs activas, con ingresos superiores a $3.000 millones entre 2021 y 2024.**

[![Image 46](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2026-03/DSC01371.JPG?itok=OnLHgl5T)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 47](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **19**

**acuerdos de licenciamiento nos permiten transferir resultados de investigación al sector productivo.**

[Formación para la CTeI](https://www.eafit.edu.co/ciencia-tecnologia-innovacion#4257225834-3583653907)

Formación para la CTeI

[![Image 48](https://universidadeafit.widen.net/content/d485571e-4202-4f50-8c22-ff3078ed8f64/web/Encuentros%20con%20la%20pregunta%20(13).jpg?crop=yes&k=c&w=1920&h=788&itok=nLJt0qn7)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 49](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+5.400**

**participantes en 2024 en programas de la Universidad de los Niños.**

[![Image 50](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-11/Genrador%20de%20Hidr%C3%B3geno%20bionspirado%20%288%29.JPG?itok=1BpZAk3L)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 51](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+1.600**

**estudiantes de pregrado participaron en semilleros de investigación en 2024.**

[![Image 52](https://universidadeafit.widen.net/content/c9f39293-6d99-4f6f-ae80-fa1b60f80d26/web/Presentacio%CC%81n%20balance%203.JPG?crop=yes&k=c&w=1920&h=788&itok=rUGHn89e)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 53](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **6 %**

**de los estudiantes de doctorado del país realizan su formación en EAFIT.**

[Apropiación Social del Conocimiento](https://www.eafit.edu.co/ciencia-tecnologia-innovacion#4257225834-4027834990)

Apropiación Social del Conocimiento

[![Image 54](https://universidadeafit.widen.net/content/600a5cdf-8351-4ff0-95d2-5f50ce14a28d/web/accioneafit-banner2025.jpg?crop=yes&k=c&w=1920&h=788&itok=zGQ098P8)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 55](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+1.700**

**participantes en actividades, talleres y experiencias que promueven la cultura científica en 2025.**

[![Image 56](https://universidadeafit.widen.net/content/b7573237-eb6a-4266-a6fe-ddd73755a6dc/web/imagen-descubre-y-brea.png?crop=yes&k=c&w=1920&h=788&itok=1SIjGXIz)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 57](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+265.000**

**visualizaciones en redes de los contenidos de divulgación científica entre 2024 y 2025.**

[Proyectos de CTeI](https://www.eafit.edu.co/ciencia-tecnologia-innovacion#4257225834-1639499420)

Proyectos de CTeI

[![Image 58](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-11/707c37f0f57f3982f6b6b1497c3d80ae.jpeg?itok=mvDZoVsa)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 59](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+300**

**proyectos activos en los 32 departamentos de Colombia y diversos escenarios internacionales en 2025.**

[![Image 60](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-10/Diapositiva1.JPG?itok=oRGJG3u3)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 61](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+370 mil**

**millones gestionados en 2025 consolidan el portafolio de soluciones basadas en conocimiento de EAFIT.**

[![Image 62](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-11/IMG_20241120_093158.jpg?itok=BFCfm2pu)](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 63](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

## **+240**

**organizaciones aliadas trabajan con EAFIT en 2025 en iniciativas de CTeI en distintos sectores y regiones.**

## Universidad de los Niños

Estimulamos el descubrimiento y el conocimiento de las ciencias en niños, niñas, adolescentes, jóvenes y mediadores de una forma colaborativa, incluyente y divertida.

[Conoce más sobre Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

## Centro Cultural Biblioteca

Democratizamos el conocimiento de manera innovadora y con vocación de servicio, ofreciendo experiencias memorables de conexión con el aprendizaje, la ciencia y la cultura.

[Conoce más sobre biblioteca](https://www.eafit.edu.co/biblioteca)

Publicaciones y revistas

![Image 64: Imagen Repositorio institucional](https://universidadeafit.widen.net/content/1e170349-77e1-4f97-b256-ce529c483b53/web/dyc.jpg?crop=yes&k=c&w=397&h=253&itok=8gNzUMsB)

Producción CTeI

[Conoce producción CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea)

![Image 65: Imagen Revistas Académicas](https://universidadeafit.widen.net/content/1aac2d55-0325-4f47-8c5e-ca3888e60e03/web/revistas-academicas-y-cientificas.jpg?crop=yes&k=c&w=397&h=253&itok=SFjZmszr)

Revistas Académicas

[Conoce revistas académicas](https://publicaciones.eafit.edu.co/)

![Image 66: Imagen Repositorio institucional](https://universidadeafit.widen.net/content/1e170349-77e1-4f97-b256-ce529c483b53/web/dyc.jpg?crop=yes&k=c&w=397&h=253&itok=8gNzUMsB)

Repositorio institucional

[Conoce repositorio institucional](https://repository.eafit.edu.co/home)

## Marco normativo

[Conoce el marco normativo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/marco-normativo)

![Image 67: Imagen Marco normativo](https://www.eafit.edu.co/sites/default/files/2025-05/Banner-CVLAC.jpg)

Contacto 

¿Quieres saber más?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono de contacto*? 

Correo electrónico*? 

Ciudad de residencia*? 

Contenido de interés 

Cuéntanos, ¿Qué deseas saber?*? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 68](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 69: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 70: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 71: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 72: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 73: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 74: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 75: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 76: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 77](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
