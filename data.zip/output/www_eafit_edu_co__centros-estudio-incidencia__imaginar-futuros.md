Title: Imaginar Futuros

URL Source: https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros

Markdown Content:
# Imaginar Futuros - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros#main-content)

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros#)

[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros# "Spanish")[![Image 9: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros# "English")

 Información para ti

[![Image 10: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 11: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 12: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 13: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 14: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 15: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 17: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 18: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 19: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 20: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 21: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 22: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 23: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 24: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 25: Imagen de banner varias personas en auditorio ](https://universidadeafit.widen.net/content/d2482d78-6b59-46eb-b46a-e40a199e03f1/web/banner-principal-imaginar-futuros.gif?animate=true)

# Imaginamos

futuros posibles

*   [Inicio](https://www.eafit.edu.co/)
*   [​​​​​​​​​​Centros de Estudio ​e Incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
*    Imaginar Futuros 

#### Transformamos la incertidumbre en oportunidad

Para que América Latina imagine, diseñe, construya y lidere sus futuros.

Anticipamos tendencias en la intersección de educación, trabajo y tecnología, conectando visiones con capacidades que generan impacto real en nuestra región.

###### Inspiramos

Conversaciones sobre futuros posibles que orientan los ecosistemas en temas de educación, trabajo y tecnología.

###### Creamos

Herramientas de navegación, marcos de prospectiva accionables y espacios de colaboración intersectorial.

###### Transformamos

Paradigmas educativos, organizacionales, sociales y culturales.

## Así lo hacemos

![Image 26](https://universidadeafit.widen.net/content/43984ccd-7f98-4bad-8173-a0a26de0b6d7/web/destacado-asi-lo-hacemos.jpg?w=480&itok=nw8l9YEO)

## Radar de Futuros

¿Qué tendencias críticas deberías tener en tu radar? Accede a informes con análisis de señales emergentes, sesiones ejecutivas personalizadas por ecosistema y herramientas de diagnóstico que te ayudan a tomar decisiones estratégicas antes que tu competencia.

![Image 27](https://universidadeafit.widen.net/content/3acf1c18-726e-46e0-bf20-80cef24a801a/web/destacado-asi-lo-hacemos2.jpg?w=480&itok=2l7jkPsY)

## Conversaciones de Futuros

Conéctate con los ecosistemas más dinámicos y líderes de pensamiento en espacios diseñados para el diálogo estratégico. Aquí las ideas se encuentran, las visiones se alinean y las colaboraciones transformadoras nacen.

![Image 28](https://universidadeafit.widen.net/content/19943cf1-1dac-49ef-ab15-41f799845ce7/web/destacado-asi-lo-hacemos3.jpg?w=480&itok=7e0dPR4I)

## Narrativas de Futuro

El futuro necesita ser contado. Sumérgete en contenidos que hacen visible lo emergente: podcasts con expertos, informes visuales, boletines especializados y análisis que traducen señales complejas en insights accionables para tu organización.

![Image 29](https://universidadeafit.widen.net/content/03d347d9-d477-404e-b409-46d4cd92665d/web/destacado-asi-lo-hacemos4.jpg?w=480&itok=rpsBQ9jU)

## Consejería Estratégica

Acompañamos a juntas directivas y equipos de liderazgo en la navegación de transformaciones complejas, traduciendo señales emergentes en estrategias específicas para tu contexto y conectándote con las capacidades de EAFIT que necesitas.

![Image 30: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Activa el radar

Conoce nuestros reportes para explorar lo que viene.

 En ellos reunimos las fuerzas que están moldeando el mundo, las señales que anuncian cambio y los escenarios posibles que podrían desplegarse en los próximos años.

[Conoce más](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros/observatorio)

![Image 31: Imagen Activa el radar](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros)

### Lentes Estratégicos

Observamos, analizamos e incidimos en los cambios del entorno desde tres perspectivas fundamentales. La verdadera riqueza está en las intersecciones donde estos lentes se superponen.

![Image 32: Imagen Educación](https://universidadeafit.widen.net/content/6a2921e2-08f9-43e2-b631-2d8ee92b8762/web/lentes-estrategicos-imaginar-futuros.jpg?crop=yes&k=c&w=397&h=253&itok=uWuAQuOd)

Educación

Analizamos la evolución de los modelos pedagógicos, las instituciones educativas y las trayectorias de aprendizaje a lo largo de la vida,

 considerando las nuevas formas de adquisición y certificación de

 conocimientos.

![Image 33: Imagen Tecnología](https://universidadeafit.widen.net/content/21cf37dc-5c35-49ee-b2f8-73f148a6cf1c/web/lentes-estrategicos-imaginar-futuros2.jpg?crop=yes&k=c&w=397&h=253&itok=TzXL_FSA)

Tecnología

Examinamos el impacto de la tecnología en los sistemas sociales, culturales, educativos y productivos, explorando tanto sus oportunidades de

 transformación como los desafíos que representa.

![Image 34: Imagen Trabajo](https://universidadeafit.widen.net/content/8f55aaf8-0cca-4a60-8b4b-105323f26ac4/web/lentes-estrategicos-imaginar-futuros3.jpg?crop=yes&k=c&w=397&h=253&itok=Rfs63bgn)

Trabajo

Abordamos los cambios en las actividades productivas y creadoras de valor, incluyendo relaciones laborales, oficios, emprendimientos, economía digital y formas emergentes de organización del trabajo.

### FAQ´S

[¿Cuál es nuestra ventaja diferencial?](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros#3785945213-2714501218-1)

Tenemos la capacidad de traducir tendencias en estrategias ejecutables para organizaciones y líderes regionales a través de los diferentes centros o escuelas de EAFIT. No solo estudiamos el futuro: lo hacemos posible.

[¿Cómo puedo participar?](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros#3785945213-2714501218-2)

Puedes acceder a nuestros informes trimestrales, participar en nuestras conversaciones de futuros, solicitar consejería estratégica para tu organización, o seguir nuestras narrativas a través de contenidos audiovisuales, podcasts y boletines.

[¿Qué metodología utilizamos?](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros#3785945213-2714501218-3)

Trabajamos con el framework de prospectiva estratégica: observamos señales y tendencias, imaginamos futuros posibles, diseñamos rutas estratégicas y activamos conversaciones que se convierten en productos y soluciones EAFIT.

[¿Con quienes trabajamos?](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros#3785945213-2714501218-4)

Colaboramos con organizaciones como Empresarios por la Educación, Alianza 4U, Tecnológico de Monterrey, Comfama, Cámara de Comercio de Medellín y Colombia Edtech, entre otros aliados estratégicos.

[Ver todas ->](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros#)

### Conócenos en

nuestras redes sociales

### Instagram

[Conoce más](https://www.instagram.com/imaginarfuturos/)

### Linkedin

[Conoce más](https://www.youtube.com/@imaginarfuturoseafit)

### Youtube

[Conoce más](https://nam10.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.youtube.com%2F%40imaginarfuturoseafit&data=05%7C02%7Cdhenaoz%40eafit.edu.co%7C9303857b3fb84a5b250d08dea08bafde%7C99f7b55e9cbe467b8143919782918afb%7C0%7C0%7C639124718974044616%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=bZhMOGWN2oaP5Un9pDbeZ8psFQXlsgYJC%2BdhfvgFqkg%3D&reserved=0)

![Image 35: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 36: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 37: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 38: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 39: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 40: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 41: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 42: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
