Title: Becas Talento y Aliados pregrado (Nutresa, Santa Ana, F.E. Suiza y Aurelio Llano)

URL Source: https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit

Markdown Content:
# Becas Talento y Aliados pregrado (Nutresa, Santa Ana, F.E. Suiza y Aurelio Llano) - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit# "English")

*   [Spanish](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)
*   [Inglés](https://www.eafit.edu.co/en/becas-y-financiacion/becas-talento-eafit)

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

# Becas Talento y Aliados pregrado (Nutresa, Santa Ana, F.E. Suiza y Aurelio Llano)

### [Beca](https://www.eafit.edu.co/taxonomy/term/1336)

Si quieres conectar con tu talento, tienes capacidades de liderazgo y excelencia académica, y necesitas apoyo económico para realizar tus estudios de pregrado, puedes acceder a becas que cubren entre el 40% y el 100% del valor de la matrícula del programa. Aquí encontrarás opciones como: las Becas Talento, Nutresa Acceso, Santa Ana, Fundación Educación Suiza y Aurelio Llano. Postúlate a partir del 10 de marzo de 2026.

![Image 21: Imagen de Becas Talento](https://universidadeafit.widen.net/content/fa56d88d-2d10-4bf5-adee-559ba89f7b6e/web/becastalentoeafit-2.jpg)

*   [Inicio](https://www.eafit.edu.co/)
*   [Becas y Financiación](https://www.eafit.edu.co/becas-y-financiacion)
*    Becas Talento y Aliados Pregrado (Nutresa, Santa Ana, F.E. Suiza y Aurelio Llano) 

Creemos en el poder transformador de la educación y sabemos que esta no solo cambia la vida de una persona, sino a su entorno cercano, a su familia, a su barrio, a su ciudad, a su país y al mundo. Por eso, en EAFIT actuamos para poner este gran propósito en marcha.

Queremos apoyar a las personas que eligen ser profesionales para que puedan estudiar en nuestro campus y vivir lo que es el aprendizaje activo, retador y sostenible. Y trabajamos para que el dinero no sea una barrera definitiva en los sueños de tantos jóvenes.

Por esto, si eres un joven bachiller de Colombia, te destacas por tu talento, liderazgo y excelencia académica, y no cuentas con los recursos económicos suficientes para costear tus estudios de Educación Superior, inscríbete a la Universidad EAFIT y postúlate a nuestra **Convocatoria de Becas Talento y Aliados pregrado**, donde encontrarás opciones que cubren**entre el 40% y el 100% del valor de la matrícula.**

Los aliados que se suman a esta convocatoria con cupos de becas son:

[![Image 22: Logo de Nutresa](https://universidadeafit.widen.net/content/5da8b657-6ac8-4d42-a51e-68f7d0fd297c/web/grupo-nutresa.png)](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)

![Image 23](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)

##### **Fundación Benéfica**

**Santa Ana**

[![Image 24](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)

![Image 25: Logo Fundación Educación Suiza](https://universidadeafit.widen.net/content/0570395a-fb19-448b-8c54-1e225a3bd519/web/fundacion-suiza-beca-talento.jpg?crop=yes&k=c&w=1920&h=788&itok=t34BxKbk)

[![Image 26](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)

![Image 27: Logo Aurelio Llano](https://universidadeafit.widen.net/content/33c00c55-6f56-47fe-9173-7d8b4d467fac/web/Logo%20Aurelio%20Llano.jpeg?crop=yes&k=c&w=1920&h=788&itok=YF0S2OOe)

Aplica desde el **10 de marzo hasta el 24 de mayo de 2026**, y haz parte de la comunidad de talento EAFIT.

[Postúlate aquí](https://forms.office.com/pages/responsepage.aspx?id=XrX3mb6ce0aBQ5GXgpGK-7eXmzQySqBIjG-wl2JS4HhUMDFSMDRaN0paUk5ZR0paRlVXMFU3UjQzUi4u&route=shorturl)

###### Para postularte, ten presente la siguiente información:

**Es indispensable que estés admitido a un pregrado en EAFIT antes del cierre de la convocatoria de becas, de lo contrario no podrás ser considerado como potencial beneficiario. Para conocer la oferta de programas y realizar tu inscripción a EAFIT,**[**ingresa aquí**](https://www.eafit.edu.co/pregrados)**.**

El formato de aplicación a las becas estará disponible**hasta el 24 de mayo de 2026**, es gratuito y debes diligenciarlo de forma virtual.

No aplica para estudiantes activos de EAFIT, ni para personas que ya tengan un título de pregrado.

Los cupos de becas por pregrado son limitados según la disponibilidad presupuestal de la Universidad y los recursos habilitados por los aliados.

Tu postulación será analizada para el pregrado al cual seas admitido.

Las becas que se otorgarán en el marco de esta convocatoria según el perfil y cumplimiento de requisitos de cada una son: ​

**o**Talento EAFIT (pregrado)

**o​**Acceso ​Nutresa - EAFIT

**o**​ [Fundación Benéfica Santa Ana](https://www.fbsantana.org/)

**o​** Fundación Aurelio Llano Posada

**o​**[Fundación Educación Suiza](https://www.fundacion-educacion.org/es/)

## Nota

Si tienes reserva de cupo autorizada para iniciar un pregrado en EAFIT en el semestre 2026-2, recuerda primero hacer tu inscripción a la universidad y luego postúlate a esta convocatoria de becas.

 Si estás cursando Programa E y al finalizar quedas admitido a un pregrado, podrás postularte a esta convocatoria de becas en las fechas establecidas.

 Solo se tendrán en cuenta en el proceso de selección, los aplicantes a las becas que hayan sido admitidos al pregrado antes de la fecha de cierre de la convocatoria.

 Si no eres admitido en las fechas antes mencionadas o si quedas en Programa E, no podrías postularte a esta convocatoria de becas.

​Fechas importan​tes

Recepción de postulaciones a la convocatoria de becas 2026-2

Del 10 de marzo al 24 de mayo de 2026

Proceso de selección y filtros

Del 25 de mayo al 11 de junio de 2026

Publicación de resultados

A más tardar el 12 de junio de 2026

Fecha máxima de pago de matrícula

Julio 6 de 2026

Inducción

8 y 9 de julio de 2026

Inicio de clases

13 de julio de 2026

##### A continuación, conoce los requisitos y beneficios de las becas disponibles en esta convocatoria

## Becas disponibles

[Beca Talento EAFIT (pregrado)](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#4257225834-310106679)

Beca Talento EAFIT (pregrado)

###### Requisitos para aplicar

Bachilleres graduados en Colombia, admitidos a un pregrado en EAFIT para 2026-2, y que no cuentan con los recursos económicos suficientes para costear estudios universitarios profesionales.

Haber presentado las pruebas Saber 11 (ICFES) de 2014-2 en adelante.

Residir en zonas de estrato **1, 2, 3 o 4** en cualquier municipio de **Colombia**.

No tener un título de pregrado.

Nota: Si eres técnico o tecnólogo puedes aplicar a esta beca. O si estás cursando un pregrado en otra institución, puedes realizar el proceso de transferencia externa y participar por la beca.

###### ¿Qué cubre la beca?

Un porcentaje sobre el valor de la matrícula que puede ser del **40%, 50%, 60%, 70%, 80% o 100%** para adelantar estudios del pregrado al que fuiste admitido en EAFIT, según la disponibilidad presupuestal de la Universidad y los cupos habilitados por programa.

No incluye inscripción, auxilio económico para sostenimiento, ni apoyo para idiomas.

[Beca de Acceso Nutresa - EAFIT](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#4257225834-2340614887)

Beca de Acceso Nutresa - EAFIT

###### Requisitos para aplicar

**Bachilleres** graduados**admitidos**a un pregrado en EAFIT para 2026-2, que no cuentan con los recursos económicos suficientes para costear estudios universitarios profesionales. Especialmente mujeres, que apenas van a iniciar su formación profesional.

Haber presentado las pruebas **Saber 11**(ICFES) de 2014-2 en adelante, y obtener un puntaje global igual o superior a**300**.

**Nota:** para las personas que hayan obtenido el título de bachiller en el exterior, deben haber presentado el ICFES en Colombia y alcanzar el puntaje mínimo requerido.

Residir en zonas de **estrato 1, 2 o 3** en cualquier municipio de **Colombia.**

**Edad**máxima **28 años.**

Los postulados no podrán haber cursado o estar cursando otra carrera de pregrado.

###### ¿Qué cubre la beca?

El **100%**del valor de la matrícula del pregrado al que fuiste admitido en EAFIT.

No incluye inscripción, auxilio económico para sostenimiento, ni apoyo para idiomas.

[Fundación Benéfica Santa Ana](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#4257225834-665925933)

Fundación Benéfica Santa Ana

###### Requisitos para aplicar

A través del Programa Puentes para la Educación Superior, la Fundación Benéfica Santa Ana tiene como propósito facilitar la continuidad académica de estudiantes pertenecientes a familias de **estratos 5 y 6** que atraviesan una situación de desequilibrio económico. Los requisitos para aplicar a esta beca son:

Bachilleres graduados de colegios privados de Medellín.

Estar admitido a un pregrado en EAFIT para 2026-2.

Aspirantes de **estrato 5 y 6 de la ciudad de Medellín y su área metropolitana**, que por alguna **coyuntura financiera** tienen dificultades para pagar la matrícula y garantizar su acceso a la Educación Superior

Demostrar excelencia académica

**Nota:** A quien sea preseleccionado para esta beca, se le solicitarán documentos adicionales donde se demuestre que la situación económica de su familia se encuentra afectada, impidiendo pagar la totalidad de la matrícula de la Universidad.

###### ¿Qué cubre la beca?

El 100% del valor de la matrícula del pregrado al que fuiste admitido en EAFIT.

No incluye inscripción, auxilio económico para sostenimiento, ni apoyo para idiomas.

[Fundación Aurelio Llano Posada](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#4257225834-459612429)

Fundación Aurelio Llano Posada

###### Requisitos para aplicar

Bachilleres graduados, admitidos a **Ingeniería Agronómica en EAFIT**para 2026-2, que no cuentan con los recursos económicos suficientes para costear estudios universitarios profesionales.

Residir en zonas rurales de **estrato 1, 2 o 3 en cualquier municipio de Colombia**.

Aceptar el compromiso de volver a su lugar de origen a crear conocimiento e impactar la sociedad una vez graduado.

###### ¿Qué cubre la beca?

El 100% del valor de la matrícula del pregrado Ingeniería Agronómica en EAFIT.

No incluye inscripción

Auxilio económico para sostenimiento.

[Fundación Educación Suiza – EAFIT](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#4257225834-4228890423)

Fundación Educación Suiza – EAFIT

###### Requisitos para aplicar

Bachilleres graduados en 2024 o 2025 en Colombia,admitidos a un pregrado en EAFIT para 20262, que no cuentan con los recursos económicos suficientes para costear estudios universitarios profesionales.

Haber presentado las pruebas **Saber 11**(ICFES) en 2024 o 2025 y haber obtenido un puntaje global igual o superior a **345**.

Residir en zonas de **estrato 1 o 2**de Medellín o cualquier otra zona del departamento de Antioquia.

Los postulados no podrán haber cursado o estar cursando otra carrera de pregrado.

Aceptar y firmar el **Compromiso de honor**que se asume al ser becario de la Fundación Educación.(Con el compromiso de

Honor los becarios se comprometen a restituir sus becas una vez graduados. De esta manera dan pie al otorgamiento de ayudas para otros jóvenes).

**Nota:**a quienes avancen en el proceso para esta beca se le solicitarán unos documentos adicionales.

###### ¿Qué cubre la beca?

El 100%de la matrícula en EAFIT de los pregrados en: Administración de Negocios, Negocios Internacionales, Contaduría Pública, Mercadeo, Economía, Finanzas, Ingeniería de Procesos, Ingeniería de Sistemas, Ingeniería de Producción, Ingeniería Civil, Ingeniería Mecánica, Ingeniería de Diseño de Producto, Ingeniería Industrial, Ingeniería de Construcción, Ingeniería Agronómica, Ingeniería Matemática, Ingeniería Física y Diseño Urbano y Gestión del Hábitat.

Derechos de grado del pregrado.

###### Analiza si cumples con los requisitos estipulados de al menos una de estas becas y postúlate para alcanzar tu sueño de ser profesional.

## Así puedes aplicar a esta convocatoria de becas

[Paso 1: Realiza el proceso de admisión a la Universidad](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#230548828-4266564943)

Para ser un candidato elegible de alguna de las becas disponibles en esta convocatoria, es indispensable que estés admitido a un programa de pregrado en EAFIT para 2026-2, por lo tanto te compartimos los pasos para realizar tu proceso de admisión:

1.   Ingresa al MCU [aquí](https://mcu.azureedge.net/#/management/request/1a8a62a7-e4bb-4466-aee2-d5e9c117388c)para crear tu usuario y contraseña, este te permitirá ingresar a nuestro aplicativo y avanzar en tu proceso.
2.   Ingresa a [Epik](https://www.eafit.edu.co/epik), en el módulo de inscripciones y diligencia el formulario de inscripción al pregrado de tu interés.
3.   Realiza el pago de la inscripción y adjunta los documentos requeridos.
4.   Presenta la entrevista y espera los resultados de admisión.

[Paso 2: Prepara los documentos requeridos para la postulación a la convocatoria de becas](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#230548828-2671882902)

Ten listos los siguientes documentos antes de diligenciar el formulario de becas:

**Constancia de ingresos** de todas las personas que aportan económicamente en tu hogar:

1.   Empleados: carta laboral que indique salario y fecha de vinculación.
2.   Desempleados, pensionados, independientes, contratistas o rentistas de capital: formato de ingresos diligenciado con el promedio mensual. Descarga el formato [aquí](https://universidadeafit.widen.net/view/pdf/9wtyo8gfpa/formato-para-certificar-ingresos-.docx).

**Impuesto predial** de la vivienda (si es propia o familiar), donde se vea el valor del avalúo de la propiedad y el nombre del propietario.

[Paso 3: Diligencia el formato de postulación a las becas](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#230548828-3530587288)

a.Ingresa al formulario de solicitud de becas con el usuario y la contraseña de EAFIT creados en el MCU. **Nota:** para el usuario debes agregar el dominio @eafit.edu.co

b.Realiza el proceso de doble factor de autenticación: selecciona la opción “_Usar otro método_” y configura tu teléfono y correo personal como métodos de seguridad.

c.Diligencia el formulario de becas en línea con tu información personal y adjunta los documentos del **Paso 2.**

Recuerda que el formulario estará disponible del**10 de marzo al 24 de mayo de 2026.**

[Ingresa aquí al formato de postulación](https://forms.office.com/r/iD24wbnybh)

**Ten en cuenta que es un formulario único para aplicar a las 5 opciones de becas (Talento, Nutresa, Santa Ana, Aurelio Llano, F.E. Suiza) y que serás evaluado según el cumplimiento de requisitos y perfil que busca cada una de ellas. De presentarse otras opciones de becas para este semestre, serán incluidas como parte integral de esta convocatoria y proceso de selección.**

[Paso 4: Proceso de selección](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#230548828-450253078)

El Comité de Becas revisará las solicitudes presentadas, siempre y cuando el aplicante esté admitido a la Universidad, haya diligenciado la totalidad del Formato de postulación de beca y adjuntado la documentación solicitada en los tiempos establecidos para la convocatoria 2026-2, de no contar con todos los requisitos anteriormente mencionados en su totalidad o si se llegarán a encontrar inconsistencias en la información reportada en los diferentes pasos de este proceso, la postulación no será analizada y será anulada.

El análisis y selección de los beneficiarios se realizará con un enfoque diferencial e interseccional, considerando aspectos académicos, familiares, económicos y personales de los postulados y tendrá en cuenta la información reportada en la inscripción a la Universidad y en el formato de postulación a la beca.

El Comité de Becas en función del cumplimiento de criterios, evaluación de tu perfil y los cupos habilitados, realizará la asignación de las becas disponibles en conjunto con los aliados (Talento, Nutresa, Santa Ana, Aurelio Llano, F.E. Suiza) y te notificará al correo electrónico personal, si fuiste seleccionado o no máximo el **12 de junio de 2026.**

### ¡Esta oportunidad es para ti, no la dejes pasar!​​​

###### ​Testi​monios de estudiantes​​ talentosos

#### Sofía Tobón

#### Christián Caghuana

#### Yazmin Torres​​

#### Andrés Vélez

[Conoce la historia de Katerin Cardona](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit#230548828-394761485)

Si me preguntan por lo que me apasiona, no importa la edad que tenga en este momento o la que haya tenido hace diez años, o hace ocho, mi respuesta siempre ha sido la misma, y ahora que soy un poco más consciente de lo que significa, creo tener la seguridad de decir que nunca va a cambiar: el sentido de mi vida lo encuentro en las letras. En la lectura y la escritura, en esas dos herramientas que durante tantos años han acompañado al hombre. En el lenguaje, porque estamos completamente atravesados por el y sin lenguaje no hay vida.

He de comenzar diciendo que quizá la pasión temprana por los libros venga de las circunstancias. Crecí en un lugar alejado tan solo una cuadra de una biblioteca pequeña y maravillosa, la sede local de la BPP (Biblioteca Pública Piloto). Cuando mi mamá debía irse a trabajar en el día, y no tenía alguien más con quien dejarme al cuidado, me llevaba a la biblioteca, donde las encargadas la conocían, y ellas me cuidaban las horas que ella tenía que ausentarse. ¿Qué puede hacerse entonces, en un lugar lleno de libros, sino más que agarrar uno e intentar descifrar cómo funciona? Fueron las mejores tardes de mi vida, me enamoré de los cuentos, de las novelas cortas y las más largas cuando coseché la virtud de la paciencia para comprenderlas. Así es como pasé gran parte de mi infancia, en un lugar lleno de posibilidades, donde podía convertirme en cualquier persona tan solo cambiando la historia que tenía entre las manos. Cuando me hice mayor y las ocupaciones ya no me permitieron volver con tanta regularidad, cuando las personas que conocía dejaron de trabajar allí y el entorno fue remodelado, lo único que permaneció igual siempre fue lo que me hacían sentir los libros.

*No sé si se trate de un talento, pero en un mundo en el que prima la atención y la veneración a las ciencias exactas (con justas razones, por supuesto), las humanidades, la capacidad de detenerse un momento y preguntarse por el mundo y por las personas y por lo que somos y lo que eso significa, apreciar la poesía, comprender que el mundo sin cultura no existiría y que la música y la escritura dignifican nuestra condición humana, debe ser algo.

Ser becada me brindó la posibilidad de entrar en el mundo de lo único que ha tenido sentido para mí desde que tengo memoria. Lo pienso así: no es que no haya podido dedicarme a otra cosa de no haber recibido el apoyo de EAFIT, es que no me hubiera sentido bien haciendo algo distinto que no sea esto. Tener la oportunidad de conocer personas que se apasionan tanto como yo por las palabras, de escuchar docentes brillantes impartir clases sobre un montón de cosas que abren un poco más mi percepción del mundo, comprender los procesos históricos que hay tras lo que conocemos ahora como escritura, y que tantos cambios ha pasado para llegar a ser lo que es hoy; todo eso te hace valorar un poco más la posibilidad de aprender, de que exista una carrera especializada en esto, de que las humanidades todavía sean tenidas en cuenta y de que existan convenios que se acercan a las personas para ofrecerles una oportunidad para estudiar lo que desean, como sucedió conmigo.

Estudiar lo que me apasiona no solo cambió mi vida cuando supe que tenía un lugar en la beca días después de postularme, sigue cambiándola aún hoy, cada vez que aprendo algo nuevo en alguna clase, cada vez que leo un texto que me lleva a entender mejor aspectos del mundo que ni siquiera conocía, cada vez que hablo con mis compañeros e incluso cada vez que tengo que esforzarme un poco más para comprender algo, porque incluso allí sé que estoy haciendo algo que yo escogí, y que si estuviera de nuevo a punto de decidir si postularme a la beca o no, no cambiaría lo que hice para estar aquí.

## ¿Tienes dudas?

Comunícate con nuestros canales de atención

 Teléfono: +57 604 2619500 / 01 8000 515900

 Correo electrónico: contacto@eafit.edu.co

[Comunicarme con un asesor al Whatsapp 3216420341](https://wa.me/573216420341)

![Image 28: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 29: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 30: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 31: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 32: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 33: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 34: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 35: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 36](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
