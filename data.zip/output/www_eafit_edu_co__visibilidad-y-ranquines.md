Title: Visibilidad y ránquines​​

URL Source: https://www.eafit.edu.co/visibilidad-y-ranquines

Markdown Content:
[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   [Inicio](https://www.eafit.edu.co/)
*    Visibilidad y Ránquines​​ 

###### ​​​​​​​​​​​​​​​​RANQUIN

MUNDIAL QS

Ranking anual publicado por Quacquarelli Symonds (QS) en el cual se clasifican las mejores universidades del mundo. En este se tienen en cuenta los siguientes ítems: Reputación Académica, Reputación entre Empleadores, Relación Facultad/Estudiante, Citas por Facultad, Internacionalización, Red Internacional de Investigación, Resultados de Empleo, Sostenibilidad.

### EN 2026

Colombia: 5

Mundial: 951-1000

###### ​​​​​​​​​​​​​​​RANQUIN QS - LATINOAMÉRICA

A diferencia del Ranking mundial, el de América Latina está adaptado para medir el rendimiento en un contexto regional, donde la infraestructura y los recursos pueden ser diferentes. En este se tienen en cuenta los siguientes ítems: Reputación académica, Reputación entre empleadores, Relación entre docentes y estudiantes, Personal con doctorado, Red internacional de investigación , Citas por artículo, Artículos por facultad, Impacto en la web.

### EN 2026

Colombia: 7

Latinoamérica: 57

###### ​​​​​​​​​​​​​​​RANQUIN QS - SOSTENIBILIDAD

Evalúa a las universidades en función de su impacto ambiental y social, utilizando indicadores diseñados para medir su capacidad para enfrentar los desafíos globales relacionados con la sostenibilidad. Evalúa los siguientes ítems: Impacto Ambiental, Impacto Social, Gobernanza

### EN 2026

Colombia: 5

Latinoamérica: 157 - Mundial: 667

###### RANQUIN QS - MASTERS

**QS Global MBA**

Resalta los mejores programas de MBA alrededor del mundo, las universidades proporcionan la información cumpliendo los estándares MBA CSEA, también utilizan en algunos casos información disponible al público con el fin de complementar la encuesta realizada.

### 2025

Colombia: 1

Latinoamérica: 8 - Mundial: 251+

###### RANQUIN QS - MASTERS

**QS Global MASTER IN MARKETING**

Resalta los mejores programas de Master in Marketing alrededor del mundo, las universidades proporcionan la información cumpliendo los estándares, también utilizan en algunos casos información disponible al público con el fin de complementar la encuesta realizada.

### 2025

Colombia: 1

Latinoamérica: 4 - Mundial: 101+

###### RANQUIN QS - MASTERS

**QS Global MASTER IN FINANCE**

Resalta los mejores programas de Master in Finance alrededor del mundo, las universidades proporcionan la información cumpliendo los estándares, también utilizan en algunos casos información disponible al público con el fin de complementar la encuesta realizada.

### 2025

Colombia: 1

Latinoamérica: 4 - Mundial: 151+

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Ciencias Sociales y Administración**

Mide la calidad y el prestigio de las universidades en áreas relacionadas con las ciencias sociales y la gestión. Este ranking abarca una amplia gama de disciplinas dentro de estas categorías, incluyendo economía, administración, ciencias políticas, sociología, y más

### 2026

Colombia: 7

Mundial: 303

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Economía y Econometría**

Evalúa la calidad y el prestigio de los programas en economía y econometría

### 2026

Colombia: 3

Mundial: 351-400

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Negocios y Estudios Administrativos**

Evalúa la calidad y el prestigio de los programas en negocios y administración

### 2026

Colombia: 2

Mundial: 141

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Ingeniería - Mecánica, Aeronáutica y Manufacturas**

Evalúa la calidad y el prestigio de los programas en ingeniería mecánica, aeronáutica y de manufactura

### 2026

Colombia: 4

Mundial: 451-500

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Contaduría y Finanzas**

Evalúa la calidad y el prestigio de los programas en Contaduría y Finanzas

### 2026

Colombia: 4

Mundial: 301-375

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Derecho**

Evalúa la calidad y el prestigio de los programas en Derecho

### 2026

Colombia: 6

Mundial: 351-400

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Ciencias computacionales y sistemas de información**

Evalúa la calidad y el prestigio de los programas en Ciencias computacionales y sistemas de información

### 2026

Colombia: 5

Mundial: 751-850

###### RANQUIN QS - ÁREAS DEL CONOCIMIENTO

**Arte y Diseño**

Evalúa la calidad y el prestigio de los programas en Arte y Diseño

### 2026

Colombia: 3

Mundial: 201-300

###### World

The World University Rankings realiza el Ranquin Internacional Times Higher Education que reúne a las mejores universidades a nivel mundial. En él se juzgan universidades con un alto nivel de investigación en cada una de sus misiones principales: la enseñanza, la investigación, perspectiva internacional, citas e ingresos de la industria.​

### 2025

Colombia: 3

Mundial: 1.501+

###### Latin America

Mide la calidad y el desempeño de las universidades en América Latina, utilizando una metodología adaptada para reflejar mejor el contexto y las características de la educación superior en la región. Evalúa los siguientes ítems: Enseñanza, Entorno de Investigación, Calidad de la Investigación, Industria, Perspectiva Internacional

### 2025

Colombia: 8

Latinoamérica: 126 - 150

###### Impacto

Mide el impacto social y económico de las universidades de todo el mundo, evaluando su contribución al cumplimiento de los Objetivos de Desarrollo Sostenible (ODS) de las Naciones Unidas. Este ranking va más allá de los criterios tradicionales de enseñanza e investigación, enfocándose en cómo las universidades están abordando desafíos globales como la pobreza, la desigualdad, la sostenibilidad ambiental, la salud y la educación

### 2025

Colombia: 2

Mundial: 601 - 800

###### Greenmetric

Mundial

Es un ranking internacional que evalúa las universidades según su compromiso con la sostenibilidad ambiental y las prácticas ecológicas. Este ranking fue lanzado por la Universidad de Indonesia y se centra en cómo las instituciones de educación superior abordan los desafíos ambientales y promueven la sostenibilidad en sus campus.

Mide las siguientes categorías: Entorno e Infraestructura , Energía y Cambio Climático , Residuos, Agua, Transporte, Educación e Investigación

### 2025

Colombia: 9

Mundial: 129- Latam: 18 - Universidades participantes: 1.547

###### Merco Empresas

Este ranking se basa en una evaluación integral de diferentes factores que influyen en la percepción y reputación de una empresa, considerando tanto la visión interna como la externa. En especifico, Merco Empresas clasifica a las empresas con mejor reputación corporativa

### 2025

Colombia: 27

Sector Educativo: 2

###### Merco Líderes

Se enfoca en evaluar la reputación de los líderes empresariales, es decir, de los altos ejecutivos y directores generales (CEOs) de empresas. Este ranking se realiza a través de encuestas y análisis de la percepción que tienen diversos grupos de interés sobre estos líderes, considerando su capacidad de gestión, valores, ética, y liderazgo

### 2025

Colombia: 18

Sector Educativo: 2

###### Merco Talento

Se enfoca en medir y evaluar la capacidad de las empresas para atraer, retener y desarrollar talento. Este ranking analiza cómo las empresas gestionan su capital humano y cuál es la percepción que tienen los empleados, estudiantes, expertos en recursos humanos y otros stakeholders sobre las políticas y prácticas de gestión del talento de las organizaciones

### 2025

Colombia: 28

Sector Educativo: 3

###### Merco Responsabilidad y Gobierno Corporativo

Este ranking evalúa y mide la percepción de la responsabilidad social corporativa (RSC) y el gobierno corporativo de las empresas. Se enfoca en cómo las empresas manejan sus responsabilidades sociales, éticas y ambientales, así como la calidad de su gobierno corporativo en términos de transparencia, equidad y cumplimiento de normas

### 2025

Colombia: 20

Sector Educativo: 1

###### 2025

## 21

Enviromental

## 19

Social

## 20

Governance

###### RANKING PAR

Latinoamérica

Mide el estado de las organizaciones en políticas y procesos de equidad de género y diversidad corporativa. Mide los siguientes indicadores: Gestión de objetivos, Cultura organizacional, Estructura organizacional, Gestión del talento, Género y diversidad.

### 2025

Latinoamérica: 132

Participantes: 501

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500
