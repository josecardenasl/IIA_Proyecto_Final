Title: Bienvenido a EPIK

URL Source: https://www.eafit.edu.co/epik

Published Time: Thu, 07 May 2026 20:25:33 GMT

Markdown Content:
**¡El camino a EAFIT comienza aquí!**Sigue estos pasos para completar tu formulario de inscripción de manera exitosa:

**1. Inicia tu solicitud**

En la página del programa de tu interés, **haz clic** en el botón **"Inscripción"**.

Si ya tienes una cuenta, ingresa con tus datos.

Si es tu primera vez, sigue los pasos para crear un usuario nuevo.

**2. Completa el formulario**

El formulario se divide en secciones clave que debes diligenciar:

**Datos personales:** Tus datos básicos se mostrarán automáticamente si ya estás registrado en nuestra base de datos. En caso de ser extranjero y usar pasaporte o cédula de extranjería, recuerda incluir los datos vigentes de tu visa.

**Datos del programa:**Verifica que el nombre del pregrado o posgrado coincida con tu elección.

Información académica: Registra tus estudios formales previos.

**Grupo familiar:** Diligencia los datos de tus padres. Si eres menor de edad, indica quién es tu acudiente o responsable de pago.

**Documentos:** Adjunta los archivos solicitados para tu admisión.

Y demás información que el Formulario te solicite.

¿No tienes los documentos a mano? No te preocupes, puedes enviarlos después a través del autoservicio de EPIK (opción "**Anexo de documentos**", o en "**Servicios y certificados"** - solicitud de servicios - Actualización de datos estudiante) .

**3. Finaliza y paga**

Una vez revises el resumen de tus datos, haz clic en **"Enviar Solicitud".** El sistema te mostrará el valor de la inscripción y podrás:

Pagar en línea de forma inmediata.

Descargar el PDF para pagar en una entidad bancaria o en nuestras taquillas ubicadas en el bloque 29 primer piso.

Tienes dos opciones para realizar tu inscripción de manera fácil y rápida:

**1. Inscripción en línea (Autogestión)**

*   Ingresa a la página de [**Educación continua**](https://ecommerce.eafit.edu.co/es/cursos-y-diplomados)
*   Busca el programa de tu interés y selecciona el botón **“Agregar al carrito”.**

El sistema te llevará a la página de matrícula, donde deberás completar el formulario con tus datos y realizar el pago a través de los medios electrónicos disponibles.

**2. Inscripción presencial**

Si prefieres realizar el proceso personalmente, puedes acercarte a las taquillas de la Universidad

**Ubicación:** Bloque 29, primer piso (Educación continua).

**1. Ingresa** con tu usuario y contraseña en el autoservicio de Epik.

**2. Valida** si tienes indicadores negativos en el módulo **"Mis Pendientes"** y ¡Gestiónalo!

**3.** Registra tus asignaturas de acuerdo con tu plan de estudios desde el 11 de mayo al 22 de mayo del 2026. De acuerdo con la cita asignada para tu escuela.

**4.** Consulta tu cita asignada para la selección de horario desde el 12 de junio del 2026 en la tarde.

**5.** Realiza tu selección de horario desde el 16 al 23 de junio del 2026.

Revisa las demás fechas en el siguiente[**enlace.**](https://universidadeafit.widen.net/s/lsxnbbsjsh/calendarios-academicos-pregrado_estudiantes)

La **cita** de inscripción de clases es el turno asignado por la Universidad que define el **día y la hora exacta** a partir de los cuales se te habilita el sistema en EPIK para inscribir tus materias.

**Ten en cuenta estos puntos clave:**

**Prioridad:**El orden de las citas se asigna generalmente según el promedio académico. Entre más pronto sea tu cita, más opciones de cupos y horarios encontrarás disponibles.

**No es presencial ni asistido:** Todo el proceso se realiza de forma virtual a través del autoservicio de EPIK. Ten en cuenta que es un paso de autogestión individual, lo que significa que tú mismo eres responsable de elegir y registrar tus materias en el sistema; no contarás con un asesor en tiempo real para realizar el proceso por ti.

Desde **EPIK**, ve al módulo **“Progreso Académico”** y selecciona tu nivel (pregrado o posgrado) para ver tu plan académico.

Tu opinión es fundamental para seguir mejorando la calidad académica de la Universidad. Puedes realizar este proceso de forma rápida a través de **EPIK**.

Para guiarte paso a paso, hemos preparado el siguiente material:

[**Descarga aquí el instructivo de 5 pasos para realizar tu evaluación docente.**](https://universidadeafit.widen.net/s/njrlgg7f5x/instructivo-evaluacion-profesores-epik)

Ten en cuenta que la evaluación se habilita en fechas específicas cerca al final de cada periodo académico.

Puedes conocer la oferta de asignaturas para el periodo intersemestral a través de estos dos canales:

**Desde la Web**: Consulta el listado actualizado directamente en el [**enlace de cursos intersemestrales**](https://www.eafit.edu.co/instructivo-intersemestrales)**.**

**Desde EPIK:**Ingresa con tu usuario y contraseña, y en el menú principal busca la sección **"Notas de interés"**. Allí encontrarás el documento con todas las materias ofertadas.

Los Servicios Académicos son trámites oficiales que puedes gestionar con la Universidad. Úsalos cuando necesites actualizar documentos, reservar cupo, solicitar supletorios o cumplir con requisitos específicos de tu carrera.

**Importante:** A través de esta opción, puedes cargar tu certificado de idioma para que sea verificado y así cumplir con el requisito de bilingüismo de tu plan de estudios.

**Pasos para realizar tu solicitud en Epik:**

**1.** Ingresa al autoservicio de Epik y ubícate en la opción **"Servicios y Certificados"**.

**2.**Selecciona la opción **"Solicitud de Servicios".**

**3.**Selecciona el ciclo lectivo, es decir, el semestre y el programa académico para el cual vas a realizar la solicitud del servicio. Haz clic en **"Buscar".**

**4.** El sistema te ubica en la página en la que podrás seleccionar el servicio que vas a solicitar. Allí encuentras el código y nombre de servicio, la categoría a la que pertenece, el valor del servicio, en caso de que lo requieras y la descripción del servicio.

**5.** Luego de seleccionar el servicio podrás diligenciar datos adicionales que se requieran para la gestión del servicio o realizar observaciones adicionales que creas pertinentes.

**6.** Al guardar la solicitud del servicio, el sistema te presenta una página con el resumen de la solicitud y, dependiendo del servicio, te puede habilitar diferentes opciones como: reprogramar o cancelar citas, añadir o eliminar documentos, entre otros. Y el campo ""Comentarios"" aparecerá activo, siempre y cuando el servicio no haya sido finalizado, para que realices observaciones a tu solicitud en caso de que lo requieras.

**7.** En la página inicial de **"Solicitud de Servicios"** puedes consultar el estado y la gestión de tu requerimiento seleccionando el servicio que deseas ver, o también puedes aplicar filtros para realizar la búsqueda de un servicio específico que quieras validar.​

A través de esta plataforma puedes gestionar diferentes requerimientos sin necesidad de desplazarte físicamente. Los servicios disponibles incluyen:

**Prueba de bilingüismo:** Carga de certificados para validar la competencia en lengua extranjera.

**Actualización de datos de estudiante:** Actualización de documento de identidad y de datos sensibles del estudiante.

**Contenidos programáticos:** Solicitud para generar los contenidos programáticos de las asignaturas.

**Solicitud de exámenes supletorios.**

**Cancelación de clase:** cancelación de la materia (según fechas del calendario).

**Recuerda:** Cada servicio tiene una descripción detallada dentro de EPIK donde podrás ver si tiene algún costo asociado.

Si no encuentras el trámite que necesitas en el apartado de **"Solicitud de Servicios",** la opción de **"Otros servicios"** agrupa solicitudes especiales y casos específicos.

Dentro de esta sección puedes encontrar:

**Reserva de cupo:** Permite asegurar tu lugar en el programa académico en caso de que decidas aplazar el inicio de tus estudios o suspenderlos temporalmente.

**Solicitud de nota:** Úsala si aprobaste una materia pero la calificación aún no se refleja en tu historial académico.

**Solicitudes al Consejo Académico:** Para peticiones formales que requieren evaluación de esta instancia.

**Prórroga de trabajo de grado**

Para gestionar cualquiera de estos trámites especiales, sigue estos pasos:

1.   Ingresa a**EPIK**>**Servicios y Certificados.**
2.   Selecciona la opción **Otros Servicios.**
3.   Haz clic en el **ícono de la lupa** para desplegar y buscar los servicios disponibles.
4.   Elige el trámite que necesitas, adjunta los soportes en el campo de documentos y haz clic en **Guardar.**

Puedes hacerlo directamente en la plataforma **EPIK** siguiendo estos pasos:

**1.****Ingresa** con tu usuario y contraseña.

**2.****Selecciona tu rol** (Estudiante o Solicitante).

**3.** Haz clic en **Servicios y Certificados → Solicitud de Certificados.**

**4.** Selecciona **Nueva Solicitud.**

**5.** Escoge el programa académico y da clic en Buscar Certificados Disponibles.

**6.** Elige el certificado, define el idioma y el modo de entrega.

**7.** En Acciones puedes:

- Ver versión preliminar.

- Confirmar la solicitud.

- Guardar sin solicitar.

- Anular la solicitud.

**8.** Si el certificado tiene costo, realiza el pago en **Mis Finanzas → Centro de Pagos.**

Si necesitas presentar una solicitud formal ante la Comisión de Casos del Consejo Académico, debes realizar el trámite a través de **EPIK** siguiendo estos pasos:

1.   **Ingresa** a EPIK con tu usuario y contraseña.
2.   Dirígete al módulo **"Servicios y Certificados"**.
3.   Selecciona la opción **"Otros Servicios".**
4.   Diligencia el formulario con la siguiente información:

*   Email adicional: Donde prefieras recibir notificaciones extra.
*   Programa académico: Tu carrera actual.
*   Tipo de solicitud: Elige la categoría que mejor describa tu caso.
*   Detalle del requerimiento: Explica de forma clara y respetuosa tu petición.

1.   **Cargar documentos:** Adjunta soportes (únicamente en PDF) que sustenten tu solicitud.
2.   Haz clic en el botón **"Finalizar"** para registrar tu trámite.

Ten en cuenta sobre los **tiempos de respuesta:**

De acuerdo con el Artículo 107 del Reglamento Estudiantil, la Comisión de Casos se reúne de la siguiente manera:

Ordinaria: Dos veces al mes.

Extraordinaria: Según el volumen de solicitudes recibidas.

**Nota:** La respuesta oficial será enviada directamente a tu correo electrónico institucional. Te recomendamos estar pendiente de tu bandeja de entrada tras las fechas de reunión.
