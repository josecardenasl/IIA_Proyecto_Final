Title: Cuidado y bienestar

URL Source: https://www.eafit.edu.co/taxonomy/term/1821

Markdown Content:
# Cuidado y bienestar | Universidad EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 2: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 3: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 4: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 5: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 6: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 8: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 9: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 10: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 11: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 12: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 13: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 14: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 15: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Pasar al contenido principal](https://www.eafit.edu.co/taxonomy/term/1821#main-content)

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 18: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/1821#)

[![Image 19: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/1821# "Spanish")[![Image 20: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/taxonomy/term/1821# "English")

 Información para ti

Buscar 

Búsqueda

Menú

## [Dormir mal, redes y estrés: claves detrás de la salud mental de los universitarios en Colombia](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/dormir-mal-redes-y-estres-claves-detras-de-la-salud-mental-de-los)

Abril 10, 2026

**Un estudio con 1200 participantes a nivel nacional, liderado por la Alianza 4U, ofrece una fotografía actualizada del estado emocional de los jóvenes en Colombia y plantea propuestas de abordaje desde la política pública hasta las instituciones educativas.**[**Conoce el estudio completo aquí**](https://alianza4u.co/estudio-salud-mental/)**.**

El estudio aporta evidencia para fortalecer estrategias de bienestar en las universidades. [**Conoce el estudio completo aquí**](https://alianza4u.co/estudio-salud-mental/).

La conversación sobre salud mental en las universidades colombianas ha estado presente durante años, pero con pocas cifras recientes que permitan dimensionar el fenómeno. Un nuevo estudio, desarrollado en el marco de la Alianza 4U —integrada por la Universidad del Norte, Universidad EAFIT, Universidad Icesi y el CESA, en articulación con la fundación Empresarios por la Educación— aporta evidencia actualizada sobre cómo están los principales indicadores de salud mental en jóvenes de educación superior en el país.

El levantamiento de información se realizó entre abril y junio de 2025, y reunió a 1200 estudiantes entre 18 y 28 años, provenientes de 122 instituciones en 23 departamentos y 35 municipios. La amplitud y selección estratificada de la muestra permite observar el fenómeno con una perspectiva nacional y comparativa, en un contexto donde la última medición oficial data de 2015.

A partir del análisis de los datos recolectados —que permitió examinar cómo se relacionan variables como el sueño, el uso de redes sociales, el consumo de sustancias y las experiencias de agresión entre pares— los investigadores encontraron que estos elementos influyen en la salud mental, principalmente a través de su impacto en la depresión, que a su vez se asocia de forma significativa con otros desenlaces en el bienestar emocional de los estudiantes.

El análisis por regiones evidencia variaciones en los niveles de ansiedad y depresión. En Bogotá, la región Cafetera y el suroccidente del país se registran niveles más elevados —alrededor de 8 a 9 puntos en las escalas utilizadas—, mientras que regiones como el Caribe y el Centro Oriental presentan valores de ansiedad y depresión ligeramente menores, entre 7 y 8. Aunque las diferencias no son amplias en términos absolutos, sí resultan estadísticamente significativas.

En bienestar también hay contrastes. El Caribe presenta uno de los valores más altos en este indicador, lo que sugiere que el malestar psicológico no se distribuye de manera homogénea y puede estar influido por dinámicas sociales y contextuales propios de cada territorio.

Sobre el alcance de estos hallazgos, Isabel Gutiérrez Ramírez, directora de Estrategia de EAFIT, señala que los datos permiten dimensionar con mayor claridad la magnitud del desafío y muestran que su atención requiere una respuesta articulada. “Cuando uno mira la evidencia entiende que estamos frente a un problema de mayor escala. Las universidades tenemos un rol, pero también el sistema de salud, las alcaldías, los departamentos y la nación. Atender una situación como la que revela este estudio exige una acción compartida y sostenida entre todos estos actores”, afirma.

Al mismo tiempo, enfatiza que las universidades también tienen un margen importante de acción: pueden fortalecer sus sistemas de acompañamiento, desarrollar estrategias de prevención y construir entornos académicos que favorezcan el bienestar. “La evidencia permite dimensionar mejor el fenómeno y, sobre todo, orientar acciones tanto desde la política pública como desde las propias instituciones para atender una situación que impacta directamente el bienestar y la trayectoria de los estudiantes”, concluye.

De igual forma, el estudio confirma una tendencia documentada en la literatura internacional. Las estudiantes presentan mayores niveles de ansiedad, depresión y estrés, mientras que los hombres reportan niveles más altos de actividad física, un factor que la literatura ha asociado con efectos protectores en salud mental.

Para Alberto De Castro, vicerrector académico de la Universidad del Norte, uno de los hallazgos más reveladores del estudio tiene que ver con la importancia de los vínculos humanos en la salud mental de los jóvenes. “Se reconfirma que ayudar a desarrollar relaciones interpersonales profundas y redes de apoyo significativas es absolutamente necesario para poder ser alguien saludable. En otras palabras, nadie podrá ser del todo sano si no es capaz de construir relaciones significativas, donde pueda compartir experiencias íntimas y afectivas”, afirma.

El académico también advierte que la respuesta institucional no puede limitarse únicamente a la intervención de los síntomas. “Se hace necesario no solo atender la problemática y su afectación psicológica, sino también —y sobre todo— ayudar a focalizar a los jóvenes en actividades que les permitan encontrar valor y un sentido de propósito, hacia el futuro, hacia los otros y hacia sí mismos”, concluye.

###### La depresión como núcleo de riesgo

Más allá de las diferencias, el estudio identifica un elemento central que articula todo el modelo: la depresión como núcleo del riesgo. A través de un modelo de ecuaciones estructurales, los investigadores demostraron que factores como el consumo de sustancias, la falta de sueño, el uso intensivo de redes sociales y las experiencias de agresión entre pares no inciden directamente en el riesgo de ideación suicida, sino que lo hacen a través del aumento de síntomas asociados a la depresión. Es decir, la depresión puede en algunos casos actuar como un puente entre las condiciones de vida de los estudiantes y los desenlaces más graves en salud mental.

Para José Eduardo Sánchez, director de la Escuela de Psicología Intervención y Comportamiento de Icesi, las universidades deben reconocerse como espacios fundamentales de socialización y de desarrollo personal, es decir, son plataformas para el desarrollo individual y social. “Por lo tanto, el primer aporte que pueden hacer las universidades es ubicar de manera central la promoción del bienestar en su agenta institucional, de tal manera que favorezcan la construcción de hábitos de vida saludables, experiencias positivas el fortalecimiento de recursos subjetivos para asumir los retos de la vida actual”.

Algunos elementos para desarrollar en las universidades, añade el académico, son la ampliación del acompañamiento psicosocial, garantizando programas de apoyo sólido; o la creación de rutas claras y confidenciales para atender casos de agresión entre pares, depresión y riesgo suicida.

###### El bienestar: la pieza que puede cambiar la historia

El estudio ofrece una clave esperanzadora: el bienestar general como el factor más poderoso para reducir la depresión. De hecho, fue el predictor más fuerte dentro del modelo, explicando una proporción significativa de la variabilidad en los síntomas depresivos.

Este resultado implica un cambio de enfoque. No se trata únicamente de intervenir cuando aparece el malestar, sino de construir entornos que fortalezcan el bienestar desde la base: hábitos de sueño saludables, espacios de desconexión, actividad física, relaciones seguras y culturas institucionales que promuevan el cuidado.

“Se hace evidente que la clave para disminuir los riesgos de salud mental reside en la prevención y el bienestar integral. Más allá de ampliar la cobertura de atención individual, las entidades educativas y gubernamentales deben centrar su capacidad técnica y económica en crear entornos que promuevan el cuidado preventivo”, recalca Diana González, consejera académica del CESA.

El estudio de la Alianza 4U plantea de esta forma la necesidad de fortalecer las estrategias institucionales en salud mental. Sugiere avanzar hacia enfoques integrales que incluyan acompañamiento psicosocial, promoción de hábitos saludables y desarrollo de habilidades socioemocionales. resalta la importancia de contar con protocolos claros para la detección temprana y la atención oportuna, así como de articular esfuerzos con el sistema de salud para ampliar la cobertura y la capacidad de respuesta.

“La salud mental debe incorporarse a las culturas institucionales, mediante la formación permanente de estudiantes, docentes y administrativos, la implementación de protocolos claros frente a situaciones de crisis y la creación de espacios seguros para el diálogo”, concluye González.

*   [Lee más sobre Dormir mal, redes y estrés: claves detrás de la salud mental de los universitarios en Colombia](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/dormir-mal-redes-y-estres-claves-detras-de-la-salud-mental-de-los "Dormir mal, redes y estrés: claves detrás de la salud mental de los universitarios en Colombia")

Imagen Noticia EAFIT

![Image 21: Dormir mal, redes y estrés: claves detrás de la salud mental de los universitarios en Colombia](https://universidadeafit.widen.net/content/0663082e-7cb3-440f-9c9a-5951b4e9daf0/web/Salud-mental-1500.jpg)

# Asumir la salud mental de manera integral

Propuesta del estudio:

### 1

### Agenda transversal

Salud mental como agenda transversal, con política explícita integrada a la planeación, la cultura académica y toma de decisiones.

### 2

### Acompañamiento sólido

Acompañamiento psicosocial sólido que garantice acceso, atención, seguimiento y evaluación permanente de la calidad de los servicios en salud mental.

### 3

### Factores de cuidado

Promoción de hábitos y entornos que favorezcan la regulación emocional.

### 4

### Alianzas intersectoriales

Alianzas intersectoriales que articulen capacidades y esfuerzos con el sistema de salud y otros actores clave.

### 5

### Formación socioemocional

Desarrollar competencias y habilidades socioemocionales

### 6

### Protocolos de detección y atención

Protocolos de detección y atención con rutas claras, personal entrenado y que asegure respuestas coordinadas y confidenciales

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Pausar, escuchar y crear vínculos nos protege en tiempos de inmediatez y desinformación](https://www.eafit.edu.co/noticias/especiales/pausar-escuchar-y-crear-vinculos-nos-protege-en-tiempos-de-inmediatez-y)

Septiembre 10, 2025

**La pausa es una herramienta poderosa frente a las dinámicas actuales: detenerse, contemplar, poner límites y escuchar las propias emociones permite, explican expertos eafitenses, recuperar control y tomar decisiones sin la presión del afán.**

**Ante la desinformación y la inmediatez, la invitación es a ejercitar una lectura crítica, verificar fuentes y evitar caer en el consumo automático de redes sociales. El diálogo y la búsqueda de ayuda profesional, cuando es necesario, se convierte también en un hábito esencial para fortalecer la salud mental.**

*   [Lee más sobre Pausar, escuchar y crear vínculos nos protege en tiempos de inmediatez y desinformación](https://www.eafit.edu.co/noticias/especiales/pausar-escuchar-y-crear-vinculos-nos-protege-en-tiempos-de-inmediatez-y "Pausar, escuchar y crear vínculos nos protege en tiempos de inmediatez y desinformación")

La salud mental se ha convertido en uno de los grandes retos de la sociedad actual. La hiperconexión permanente, la inmediatez con la que vivimos, la infoxicación y la polarización han generado un entorno que dificulta el bienestar emocional y aumenta los niveles de ansiedad. Psicólogos eafitenses y expertos en el tema coinciden en que, más que grandes transformaciones, son los hábitos cotidianos los que pueden marcar la diferencia en crear condiciones que favorezcan el equilibrio y la tranquilidad.

Uno de los puntos más reiterados por los expertos es la necesidad de darle lugar a la pausa. En un contexto en el que estar siempre ocupado parece ser la norma, detenerse se convierte en un acto de autocuidado. Como explica Enrique Macía Lalinde, psicólogo del Servicio Médico y Seguridad y Salud en el Trabajo de EAFIT: “En la vida personal hay que evitar acelerarse o tener mucha prisa para dar una respuesta. De hecho, en situaciones donde nos vemos forzados a elegir de manera apresurada, generalmente puede presentarse un escenario adverso para tomar decisiones”.

Además de frenar la prisa, resulta fundamental reconectar con lo esencial. Edwin Andrés Restrepo Zuleta, psicólogo de Desarrollo Estudiantil de la Universidad, destaca la importancia de propiciar encuentros presenciales, cuidar los momentos de ocio y conectarse con la naturaleza. Recomienda “salir de la hiperconexión tecnológica y conectarnos con nosotros mismos a través de momentos de pausa, silencio, meditación, oración (aquello que cada uno sienta que lo saca del ritmo agitado de la vida y le conecta con su propia persona)”.

La desinformación y la polarización, amplificadas por redes sociales, también afectan la salud mental. Por eso, fortalecer la lectura crítica y verificar las fuentes de información es clave. Evitar quedar atrapados en el consumo automático de contenidos y reconocer el impacto emocional de ciertas noticias ayuda a reducir el malestar. En palabras de Edwin Andrés Restrepo, esto es también un acto de responsabilidad con uno mismo y con los demás. “Recordar que no todo lo que se habla en redes sobre la salud mental tiene la rigurosidad sobre el tema, por tanto, lo mejor siempre será acudir a un profesional cuando siento dudas sobre lo que me pasa a nivel emocional y comportamental”.

En este escenario, la autenticidad y la capacidad de expresar lo que sentimos sin miedo a ser juzgados son herramientas poderosas. La coherencia entre lo que se siente y lo que se comunica no solo ayuda a procesar emociones, sino que también abre la posibilidad de pedir ayuda y encontrar apoyo en los demás. Para Enrique Macía, el diálogo y la escucha son pilares para ampliar horizontes y construir comunidad desde la diferencia.

###### Vincularse con la vida

El 10 de septiembre se conmemora el Día Mundial para la Prevención del Suicidio, una fecha que recuerda la urgencia de abordar el malestar emocional con responsabilidad y acompañamiento. Esta efeméride pone en el centro la importancia de abrir espacios seguros para la escucha y la atención oportuna. A propósito de este día, el podcast Hablemos de salud mental publicó el capítulo [¿Cómo orientarnos ante el suicidio?](https://www.youtube.com/playlist?list=PL-jpd755y6FG3WaYfiZypk9PtWloyKdGY)

Héctor Gallo, psicólogo y psicoanalista, insiste en que uno de los mayores riesgos es el aislamiento y la soledad. “La soledad es una vivencia, un sentimiento psicológico. A mayor conexión con estos aparatos tecnológicos, menores posibilidades de invención de cómo relacionarse con el otro”, advierte. Para él, escuchar de manera atenta y sin presuponer lo que siente un niño o un joven es fundamental para prevenir situaciones extremas.

El especialista agrega que la amistad y la solidaridad, pilares del apoyo emocional, se han debilitado en la sociedad actual, lo que deja a muchos sin referentes estables. “Hay que construir un deseo de vivir para poder vivir; es responsabilidad de cada uno hacerlo, pero apoyado con la vinculación con los seres. La pregunta por la existencia no es la misma pregunta por la vida, es por cómo me vinculo con los otros”, afirma.

Los psicólogos eafitenses coinciden en que, frente a una situación emocional difícil, llevar a cabo pequeñas acciones pueden fortalecernos: permitirse hablar y buscar ayuda, aceptar ser ayudados y mantener un diálogo claro y honesto. Conectar con personas de confianza, rodearse de quienes reconocen y validan lo que atravesamos, y practicar la escucha sin juicios son pasos esenciales.

El llamado final es a construir comunidad desde la diferencia y la autenticidad. Hacer pausas, cuidar los vínculos, expresarse con honestidad y aprender a escuchar al otro son pequeñas acciones que, sumadas, fortalecen la salud mental y ayudan a proteger la vida.

Imagen Noticia EAFIT

![Image 22: Pausar, escuchar y crear vínculos nos protegen en tiempos de inmediatez y desinformación](https://universidadeafit.widen.net/content/beb9aeda-5cd1-4b4c-8e86-5d48e813a38d/web/Salud-mental-agencia.jpg)

Leyenda de la imagen

En medio de la soledad y la hiperconexión, construir comunidad resulta vital para proteger la vida.

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

Sección de noticias EAFIT

[Especiales](https://www.eafit.edu.co/taxonomy/term/1891)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Límites digitales y alfabetización emocional: el llamado de expertos para fortalecer la salud mental en la escuela y la familia](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/limites-digitales-y-alfabetizacion-emocional-el-llamado-de-expertos)

Septiembre 2, 2025

**Así lo plantearon los invitados al**_**Seminario Internacional: Herramientas prácticas de educación emocional y salud mental para la transformación social**_**, donde se advirtió sobre los riesgos de las redes sociales y se propuso establecer límites y espacios libres de pantallas para promover un mundo social directo.**

**Alfabetizar emocionalmente a familias, escuelas y comunidades fue otro de los puntos claves del encuentro. Los expertos coincidieron en que la inteligencia emocional debe enseñarse como un idioma compartido, capaz de prevenir traumas, fortalecer la resiliencia y promover vínculos más sanos.**

*   [Lee más sobre Límites digitales y alfabetización emocional: el llamado de expertos para fortalecer la salud mental en la escuela y la familia](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/limites-digitales-y-alfabetizacion-emocional-el-llamado-de-expertos "Límites digitales y alfabetización emocional: el llamado de expertos para fortalecer la salud mental en la escuela y la familia ")

En tiempos de sobreexposición digital y creciente deterioro de la salud mental en niños, niñas y adolescentes, expertos e invitados nacionales e internacionales coincidieron en que la educación emocional debe dejar de ser un complemento y convertirse en un eje estructural en el entorno familiar y escolar. Este fue uno de los llamados del _Seminario Internacional: Herramientas prácticas de educación emocional y salud mental para la transformación social_, realizado en el Auditorio Fundadores de EAFIT el jueves 28 de agosto.

La jornada fue posible gracias a la organización conjunta de EAFIT, el Centro Internacional de Educación Emocional y Neurociencias (CIEEN), la Asociación de Educación Privada (Adecopria) y Comfama, con el apoyo de colegios aliados como el Montessori, Colombo Británico, The Columbus School y el Instituto Jorge Robledo.

En la instalación del encuentro, Ricardo Uribe Marín, director de Desarrollo Humano y Bienestar de EAFIT, subrayó la importancia de estos espacios: “En EAFIT sabemos que la educación y la salud mental están íntimamente ligadas y que juntas son una palanca fuerte de transformación social. Desde la Dirección hemos asumido grandes retos: en primer lugar, intervenir en la gestión del riesgo psicosocial, fortalecer la formación en liderazgo y promover la salud con acciones concretas de prevención de la enfermedad”.

La psicóloga Catalina Suárez, magíster en Desarrollo, presentó la primera ponencia sobre cómo acompañar el mundo emocional en las etapas de la infancia y la adolescencia. Para ilustrar este reto, compartió una metáfora: “La familia es el primer puerto, la escuela será el segundo que te dará experiencias, y al final descubrirás qué tipo de barco eres, cuál es tu misión y tu potencial”. Con este ejemplo, invitó a reflexionar sobre la importancia de fortalecer los entornos que rodean a los niños y jóvenes.

La experta también advirtió sobre los riesgos que enfrentan las nuevas generaciones con el auge de las redes sociales, que han cambiado los patrones de interacción y aumentado la ansiedad y la depresión, especialmente en adolescentes. Ante este panorama, propuso establecer límites, avanzar en la regulación y la creación de espacios libres de dispositivos digitales para promover interacciones reales y seguras.

###### Liderazgo educativo y bienestar emocional

Dentro de la agenda del evento, se desarrolló el panel _Liderazgo educativo y bienestar emocional_, con la participación de representantes de instituciones educativas de la ciudad como el Instituto Jorge Robledo, el Colegio Colombo Británico, el Colegio San José de las Vegas, The Columbus School, el Colegio Montessori y Cosmo Schools. En sus intervenciones coincidieron en que los cambios más urgentes para las instituciones deben enfocarse en integrar la formación socioemocional de manera estructural y no como un complemento.

“No nos han enseñado a educar emocionalmente. Esto debería parte de la formación y es importante aterrizarlo dentro del quehacer del colegio en conexión con sus principios y valores. El bienestar no es solo tener una psicóloga o un profesor bien preparado, tiene que ser una manera de liderar la institución, los profesores necesitan preparación, elementos y tiempo”, afirmó Adriana Ortiz Maldonado, rectora del Colegio Montessori.

Las panelistas destacaron la necesidad de que los adultos —padres, madres y docentes— se reconozcan como modelos en la gestión de las emociones, señalando que no basta con ofrecer clases aisladas, sino que el bienestar debe convertirse en un eje transversal de los proyectos educativos.

###### El valor del apego seguro

La segunda ponencia estuvo a cargo de Rafa Guerrero, doctor en Educación y uno de los referentes en Psicología Educativa en Hispanoamérica. Su conferencia, _Apego seguro: raíces y alas para nuestros hijos_, puso de relieve cómo los vínculos emocionales sólidos son un factor de protección clave en el desarrollo infantil y adolescente.

El experto explicó que el apego no es sinónimo de dependencia, sino de conexión, y que su función es amortiguar la vulnerabilidad de los más pequeños. Retomando un proverbio africano, afirmó que “Hace falta toda una tribu para criar a un niño”, subrayando la importancia de entornos familiares y sociales que favorezcan la confianza, la seguridad y el acompañamiento emocional.

Guerrero advirtió, además, sobre los riesgos de crecer en lo que denominó “tribus maltratantes”, marcadas por la sobreprotección, el autoritarismo o la indiferencia emocional. Estas experiencias, dijo, pueden derivar en rabia, frustración y traumas que se manifiestan en la adolescencia y la adultez. De ahí la urgencia de alfabetizar emocionalmente a las familias y las comunidades educativas para prevenir daños y fortalecer la resiliencia.

“Todas las emociones aparecen, queramos o no. Lo que debemos hacer es alfabetizar esas emociones. Tenemos un problema, y es que los seres humanos no sabemos gestionarlas. La solución para ese analfabetismo es alfabetizarnos, porque la inteligencia emocional es un idioma”, concluyó.

Imagen Noticia EAFIT

![Image 23: Límites digitales y alfabetización emocional: el llamado de expertos para fortalecer la salud mental en la escuela y la familia](https://universidadeafit.widen.net/content/b0be930b-ff37-4265-9287-516d90d20b5a/web/seminario-Emociones.jpg)

Leyenda de la imagen

A la cita también se sumaron colegios aliados como el Montessori, el Colombo Británico, The Columbus School y el Instituto Jorge Robledo.

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

## [¿Cuándo un hábito se convierte en una dependencia?](https://www.eafit.edu.co/noticias/especiales/cuando-un-habito-se-convierte-en-una-dependencia)

Agosto 5, 2025

**Muchas dependencias cotidianas, como el uso excesivo del celular, el trabajo sin descanso, el juego o las compras compulsivas, están tan naturalizadas que pasan desapercibidas. Desde la psicología, se advierte que estas prácticas pueden afectar la salud mental y distintas áreas de la vida.**

**De acuerdo con expertos eafitenses, estas dependencias tambi****én responden a dinámicas del sistema económico y cultural en el que vivimos. Reconocer las señales es clave para prevenir daños emocionales y abrir el diálogo sobre hábitos que, aunque aceptados socialmente, pueden ser perjudiciales.**

*   [Lee más sobre ¿Cuándo un hábito se convierte en una dependencia?](https://www.eafit.edu.co/noticias/especiales/cuando-un-habito-se-convierte-en-una-dependencia "¿Cuándo un hábito se convierte en una dependencia?")

No todas las adicciones se esconden en sustancias. En la actualidad, muchas formas de dependencia están ligadas a hábitos aparentemente inofensivos o incluso socialmente valorados. El celular, el trabajo, las redes sociales, el juego o las compras pueden convertirse en fuentes de ansiedad, angustia y malestar emocional. Sin embargo, al estar tan integradas en la vida diaria, pocas veces se reconocen como problemáticas.

Desde la psicología, explican expertos eafitenses, se ha empezado a visibilizar cómo estas conductas pueden derivar en formas de dependencia. “Esto ocurre cuando se instala un modo de relación rígido y privilegiado con las personas, los objetos o el mundo para afrontar las tensiones de la vida. Surge la creencia de ‘sin esto no soy capaz’ o, al menos, ‘es muy difícil’. Esa persona o ese objeto se convierte en un ‘tapón’ que silencia el malestar, la tristeza o la angustia; un tapón que, paradójicamente, a la larga genera más malestar en diversas áreas de la vida”, afirma Juan David Mesa Valencia, psicólogo de Desarrollo Estudiantil de EAFIT.

En este contexto, es importante diferenciar entre dependencia y adicción. La primera puede manifestarse como un vínculo emocional fuerte o necesario que, en ciertos casos, puede adquirir características patológicas. En cambio, la adicción se considera un trastorno complejo, caracterizado por la compulsión, el deterioro y la pérdida de control.

Juan David también señala que en un mundo que valora la hiperproductividad y la conexión permanente, no sorprende que el trabajo y el uso de dispositivos móviles hayan pasado de ser herramientas para convertirse en ejes de nuestra cotidianidad. La lógica dominante promueve la idea de que siempre se debe dar más: más horas, más resultados, más visibilidad. En especial para quienes emprenden, la consigna de “dar la milla extra” se ha vuelto una regla no escrita que responde tanto a exigencias externas como a expectativas personales.

A esto se suma la integración del celular como una extensión de la rutina. Ya no es solo un medio de comunicación: concentra vínculos afectivos, entretenimiento, estatus, dinero y, por supuesto, trabajo. Su uso constante no es casualidad, sino parte de una dinámica cultural y económica que incentiva su consumo. Más allá del análisis estructural, señala Juan David, es necesario interrogarse desde lo individual: ¿está al servicio de soportar un malestar emocional?, ¿cuál es la frecuencia y la cantidad de uso?, ¿estas actividades están afectando negativamente otras esferas de la vida?

Para Jorge Mauricio Cuartas Arias, profesor de la Escuela de Humanidades de EAFIT, una persona puede volverse adicta a actividades aparentemente inofensivas. “En la práctica clínica abordamos las dependencias comportamentales como dependencias que pueden construir una relación problemática con un objeto y convertirse en una adicción. Cuando se cumplen ciertos criterios como obsesión, tolerancia, abstinencia y conflicto con las situaciones que el sujeto vive a diario, hablamos de una condición que genera daños significativos”.

El profesor agrega que las señales psicológicas y emocionales de una dependencia en desarrollo pueden ser diversas. Entre las más comunes están el pensamiento obsesivo y la dificultad para detener o moderar la conducta, incluso al intentarlo repetidamente. A esto se suman la tolerancia (necesidad creciente de más tiempo y frecuencia) y los síntomas de abstinencia, irritabilidad o insomnio cuando no se realiza la actividad. Igualmente es frecuente la negación del problema, la racionalización y, con el tiempo, un deterioro emocional e interpersonal.

Entre los riesgos y consecuencias más frecuentes están la ansiedad, el estrés crónico y la depresión, producto de una constante exigencia emocional y la pérdida progresiva del placer en actividades que antes resultaban gratificantes. Asimismo, pueden aparecer síntomas como el _burnout_ (estado de agotamiento físico, emocional y mental que resulta de la exposición prolongada al estrés laboral), el insomnio, la fatiga constante y los cambios de humor, lo que afecta la concentración, la tolerancia a la frustración y las relaciones personales.

###### Un _detox_ de redes sociales

Una de las recomendaciones de los psicólogos eafitenses es desacelerar, entendiendo este gesto como un acto de resistencia y autoconocimiento. Detener el ritmo impuesto por el trabajo constante o el _scroll_ infinito en redes sociales permite abrir un espacio para preguntarse, con honestidad, qué se desea realmente. Crear momentos libres de pantallas y de exigencias externas se vuelve fundamental para reconectar con las propias emociones. En ese proceso, también es posible identificar qué situaciones disparan las conductas dependientes, ensayar nuevas formas de afrontar el malestar emocional y, si es necesario, buscar acompañamiento profesional que facilite el camino hacia una vida más consciente y equilibrada.

Un caso ilustrativo es el de Elena Restrepo Henao, estudiante de Administración de Negocios y representante estudiantil de EAFIT, quien en diciembre de 2023 decidió hacer una pausa voluntaria en el uso de redes sociales. “El nivel de conciencia que yo construí en esos días fue muy especial. Te enfrentas a no hacer nada e invertir el tiempo en algo que no sea tan estimulante o lleno de dopamina como lo pueden ser las redes sociales. Entonces lees, descansas o conversas con las personas, porque se nos olvida que en el mundo presencial también eso es posible”, afirma.

A partir de su experiencia, Elena se unió a la profesora María Alejandra González Pérez para proponer un [**desafío práctico en la clase de Ética e Integridad**](https://www.youtube.com/watch?v=_XztLpkhEx4&t=18s). La actividad consistió en que los estudiantes hicieran un _detox_ de redes sociales y llevaran un diario físico durante el proceso. El experimento reveló cómo muchos de ellos enfrentaron ansiedad por desconexión, pero también cómo, con el tiempo, descubrieron beneficios relacionados con el bienestar personal y la reconexión con actividades presenciales.

Los expertos insisten en la necesidad de revisar críticamente nuestros hábitos. “El primer paso, creo yo, es reconocerlo. El segundo, pedir ayuda. Y el resultado, tras un esfuerzo, es regresar a una vida más plena, saludable, en la que se construya un verdadero bienestar”, concluye el profesor Jorge Mauricio.

Imagen Noticia EAFIT

![Image 24: El celular, las redes sociales y el trabajo excesivo pueden convertirse en formas de dependencia que afectan la salud mental. Conoce más sobre este tema en el video podcast Hablemos de Salud mental](https://universidadeafit.widen.net/content/14ad0c13-c792-4a1e-9356-3bdabc27049a/web/Regresoclases2.jpg)

Leyenda de la imagen

El celular, las redes sociales y el trabajo excesivo pueden convertirse en formas de dependencia que afectan la salud mental. Conoce más sobre este tema en el video podcast Hablemos de Salud mental

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

Sección de noticias EAFIT

[Especiales](https://www.eafit.edu.co/taxonomy/term/1891)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [De una inspiración a la competencia internacional](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional)

Marzo 16, 2026

**Sofía Zuluaga Zuluaga, estudiante de Finanzas, participó en el Campeonato Panamericano de Esgrima, realizado en Bogotá.**

**Su proceso en la esgrima inició a los 13 años y evolucionó hasta su participación en la Selección Colombia, combinando su formación académica con el deporte de alto rendimiento.**

**Su participación en este torneo permitió evidenciar el desarrollo de habilidades como la estrategia, la concentración y la toma de decisiones en competencia.**

[Ver publicación en instagram](https://www.instagram.com/p/DV9nEfOClnr/)

*   [Lee más sobre De una inspiración a la competencia internacional](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "De una inspiración a la competencia internacional")

Imagen Noticia EAFIT

![Image 25: De una inspiración a la competencia internacional

Sofía Zuluaga Zuluaga, estudiante de Finanzas, participó en el Campeonato Panamericano de Esgrima, realizado en Bogotá.

Canal de estudiantes](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg)

Categoría de noticias EAFIT

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Escuela o área Noticia

[Escuela de Administración](https://www.eafit.edu.co/taxonomy/term/1941)

[Escuela de Artes y Hum​anidades](https://www.eafit.edu.co/taxonomy/term/1951)

[Escuela de Ciencias Aplicadas e Ingeniería​](https://www.eafit.edu.co/taxonomy/term/1946)

[Escuela de Derecho](https://www.eafit.edu.co/taxonomy/term/1956)

[Escuela de Finanzas, Economía y Gobierno](https://www.eafit.edu.co/taxonomy/term/1961)

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Conoce la historia de Juan Esteban Restrepo, nuestro jugador estrella de voleibol en EAFIT](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/conoce-la-historia-de-juan-esteban-restrepo-nuestro-jugador)

Marzo 11, 2025

**Entre canchas de voleibol, salones y laboratorios del bloque 20, así transcurren los días de Juan Esteban Restrepo Orozco, estudiante de tercer semestre del pregrado en Ingeniería de Sistemas e integrante de la selección de Voleibol de EAFIT, quien por su excelente desempeño en este deporte ha sido convocado también por las selecciones Colombia y Antioquia de esta disciplina.**

*   [Lee más sobre Conoce la historia de Juan Esteban Restrepo, nuestro jugador estrella de voleibol en EAFIT](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/conoce-la-historia-de-juan-esteban-restrepo-nuestro-jugador "Conoce la historia de Juan Esteban Restrepo, nuestro jugador estrella de voleibol en EAFIT ")

Imagen Noticia EAFIT

![Image 26: Conoce la historia de Juan Esteban Restrepo, nuestro jugador estrella de voleibol en EAFIT](https://universidadeafit.widen.net/content/e52b5c63-b9c9-419c-a12d-74cac5b48e9d/web/conoce-la-historia-de-juan-esteban-restrepo-nuestro-jugador.jpg)

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Público Noticias

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [En #EAFIT te acompañamos a cumplir tu sueño de ser un profesional eafitense](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/en-eafit-te-acompanamos-cumplir-tu-sueno-de-ser-un)

Febrero 4, 2025

**Por ello contamos con una Política de Permanencia dirigida a nuestros estudiantes de pregrado. Allí te ofrecemos diversos mecanismos como líneas de apoyo en salud y bienestar, atención psicosocial, formación académica y programas de mentoría para estudiantes de primer semestre. También te orientamos acerca de los servicios que tenemos en la U, los trámites que debes realizar a lo largo de tu vida universitaria y te brindamos asesoría sobre a dónde debes acudir en caso de tener dificultades académicas. ¿Tienes dudas sobre esta política? ️Miguel Colorado, estudiante de Ingeniería de Sistemas y Mariana Andrade, estudiante de Ciencias Políticas, nos cuentan cómo fue su experiencia accediendo a uno de estos beneficios, el de las mentorías. En palabras de Mariana: "Este fue un espacio seguro al iniciar el semestre en el que pude aclarar dudas, recibir recomendaciones de estudiantes de otros semestres y conocer nuevas personas" Recuerda que si eres estudiante de #EAFIT y estás pasando por alguna situación que ponga en riesgo tu graduación o permanencia en la U, puedes escribir al correo permanencia@eafit.edu.co para acceder a todos estos servicios.**

*   [Lee más sobre En #EAFIT te acompañamos a cumplir tu sueño de ser un profesional eafitense](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/en-eafit-te-acompanamos-cumplir-tu-sueno-de-ser-un "En #EAFIT te acompañamos a cumplir tu sueño de ser un profesional eafitense ")

Imagen Noticia EAFIT

![Image 27: En #EAFIT te acompañamos a cumplir tu sueño de ser un profesional eafitense](https://universidadeafit.widen.net/content/76a237e8-74ac-43cf-a38f-1681afb46dec/web/en-eafit-te-acompanamos-cumplir-tu-sueno-de-ser-un.jpg)

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Público Noticias

[Estudiantes de posgrado](https://www.eafit.edu.co/taxonomy/term/1921)

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Hypatia de Alejandra fue la inspiración de este nuevo semillero de la U](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/hypatia-de-alejandra-fue-la-inspiracion-de-este-nuevo)

Marzo 11, 2025

**Este #8M, día en el que se conmemora el Día Internacional por los Derechos de las Mujeres , es una oportunidad para hablar sobre los desafíos que, como sociedad, aún tenemos para alcanzar la equidad de género en diferentes ámbitos. Uno de ellos aún persiste en las carreras de ciencia, tecnología, ingeniería y matemáticas, conocidas como áreas #STEM -por sus siglas en inglés. Según datos del @Mineducacion, aunque en Colombia el número de mujeres graduadas en carreras STEM, entre 2001 y 2021 aumentó el doble, persiste la brecha de género en términos de formación profesional. En 2017, solo el 27,3% de los estudiantes matriculados en el primer año de programas académicos STEM eran mujeres. Para el 2021, esta misma cifra fue de 31,5%. Esta brecha puede tener múltiples causas que vienen desde la educación primaria y media, donde las niñas se enfrentan a prejuicios y estereotipos que pueden ocasionar que no se interesen por estas áreas, además de verse subrepresentadas por conocer pocos referentes en estos campos. Podríamos quedarnos ahí, pero, en este día, queremos visibilizar las iniciativas que desde diferentes lugares se gestan para cambiar esta realidad.**

*   [Lee más sobre Hypatia de Alejandra fue la inspiración de este nuevo semillero de la U](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/hypatia-de-alejandra-fue-la-inspiracion-de-este-nuevo "Hypatia de Alejandra fue la inspiración de este nuevo semillero de la U ")

Imagen Noticia EAFIT

![Image 28: Hypatia de Alejandra fue la inspiración de este nuevo semillero de la U](https://universidadeafit.widen.net/content/7d020602-b928-415d-9db7-7cb44233d031/web/hypatia-de-alejandra-fue-la-inspiracion-de-este-nuevo.jpg)

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

[Inclusión y diversidad](https://www.eafit.edu.co/taxonomy/term/1841)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Público Noticias

[Estudiantes de posgrado](https://www.eafit.edu.co/taxonomy/term/1921)

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Conoce la Ruta de Emprendimiento que puedes realizar en la U](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/conoce-la-ruta-de-emprendimiento-que-puedes-realizar-en-la-u)

Febrero 5, 2025

**Llegó el momento de contarte sobre la tercera ruta: la Ruta de Emprendimiento, esta es una alianza con nuestro Centro de Emprendimiento de Impacto @ongoing.eafit que tiene como objetivo promover habilidades y competencias para fortalecer la mentalidad emprendedora en nuestros estudiantes Sebastián Roldán, estudiante del pregrado en Ingeniería Agronómica eligió esta ruta para realizar sus prácticas, esto le permitió seguir potenciando una idea en la que ya venía trabajando, Grow Blue, un emprendimiento que trabaja con la industria del arándano aportando innovaciones a este sector como la biotecnología y la agricultura 4.0. Al elegir la Ruta de Emprendimiento, Sebastián recibió asesorías con mentores y sesiones de networking para llevar su idea de negocio a otro nivel.**

*   [Lee más sobre Conoce la Ruta de Emprendimiento que puedes realizar en la U](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/conoce-la-ruta-de-emprendimiento-que-puedes-realizar-en-la-u "Conoce la Ruta de Emprendimiento que puedes realizar en la U ")

Imagen Noticia EAFIT

![Image 29: Conoce la Ruta de Emprendimiento que puedes realizar en la U](https://universidadeafit.widen.net/content/4cc9f1df-6e3b-4c45-b16b-6fe4c40860c5/web/conoce-la-ruta-de-emprendimiento-que-puedes-realizar-en-la-u.jpg)

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

[Emprendimiento](https://www.eafit.edu.co/taxonomy/term/1851)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Público Noticias

[Estudiantes de posgrado](https://www.eafit.edu.co/taxonomy/term/1921)

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Conoce nuestra Ruta de Talento Organizacional](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/conoce-nuestra-ruta-de-talento-organizacional)

Enero 30, 2025

**Hoy conversaremos sobre la Ruta Organizacional en la que tienes la oportunidad de tener un ejercicio de conexión con mayor madurez con organizaciones consolidadas, públicas y sociales. Juan Pablo Cano, estudiante de Ingeniería Mecánica, quien eligió esta ruta de talento y realizó sus prácticas en @vicomtech_, nos cuenta cómo fue esta experiencia.**

*   [Lee más sobre Conoce nuestra Ruta de Talento Organizacional](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/conoce-nuestra-ruta-de-talento-organizacional "Conoce nuestra Ruta de Talento Organizacional ")

Imagen Noticia EAFIT

![Image 30: Conoce nuestra Ruta de Talento Organizacional](https://universidadeafit.widen.net/content/2e241090-6773-47ec-a74d-863c43b86032/web/conoce-nuestra-ruta-de-talento-organizacional.jpg)

Categoría de noticias EAFIT

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

[Emprendimiento](https://www.eafit.edu.co/taxonomy/term/1851)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Público Noticias

[Estudiantes de posgrado](https://www.eafit.edu.co/taxonomy/term/1921)

[Estudiantes de pregrado](https://www.eafit.edu.co/taxonomy/term/1916)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

#### Paginación

*    Página 1 
*   [Siguiente página››](https://www.eafit.edu.co/taxonomy/term/1821?page=1 "Ir a la página siguiente")

[Suscribirse a Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821/feed)

![Image 31: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 32: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 33: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 34: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 35: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 36: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 37: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 38: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 39](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
