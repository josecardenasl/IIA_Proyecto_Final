Title: Ongoing

URL Source: https://www.eafit.edu.co/ongoing

Published Time: Thu, 07 May 2026 20:30:35 GMT

Markdown Content:
[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/ongoing#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/ongoing# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/ongoing# "English")

Buscar

[Ongoing ![Image 7: Imagen logo On.going](https://universidadeafit.widen.net/content/873c39b0-3972-47df-ad32-fbfc5888c022/web/ongoing-logo.png)](https://www.eafit.edu.co/ongoing "On.going")

[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/ongoing#)

[![Image 9: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/ongoing# "Spanish")[![Image 10: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/ongoing# "English")

*   Soy emprendedor
    *   [Cursos para emprender](https://www.eafit.edu.co/ongoing/cursos-para-emprender)
    *   [Cowork & Landing empresarial](https://www.eafit.edu.co/ongoing/cowork-landing-empresarial)

*   Soy emprendedor de la U
    *   [Incubadora de ideas](https://www.eafit.edu.co/ongoing/incubadora-de-ideas)
    *   [Semilleros EAFIT](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/nuestros-semilleros)
    *   [Proyectos CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

*   Soy empresa
    *   [Membresía](https://www.eafit.edu.co/ongoing/membresia)
    *   [Bootcamps](https://www.eafit.edu.co/ongoing/bootcamps)

Buscar

[Ir al portal principal](https://www.eafit.edu.co/)

[![Image 11](https://www.eafit.edu.co/ongoing)](https://www.eafit.edu.co/ongoing)

![Image 12: Hero](https://www.eafit.edu.co/sites/default/files/2026-03/Hero_Ongoing_nostar.svg)

[![Image 13](https://www.eafit.edu.co/ongoing)](https://www.eafit.edu.co/ongoing)

![Image 14: Emprender](https://www.eafit.edu.co/sites/default/files/2026-03/EM%20PREN%20DER.svg)

[![Image 15](https://www.eafit.edu.co/ongoing)](https://www.eafit.edu.co/ongoing)

![Image 16: Cómo lo estamos haciendo](https://www.eafit.edu.co/sites/default/files/2026-03/Co%CC%81mo%20lo%20estamos%20haciendo.svg)

[Sigamos la conversación](https://api.whatsapp.com/send?phone=573142303843)

[![Image 17](https://www.eafit.edu.co/sites/default/files/2026-02/Cifras_02_23_2026.svg)](https://www.eafit.edu.co/ongoing)

![Image 18](https://www.eafit.edu.co/ongoing)

[![Image 19](https://www.eafit.edu.co/sites/default/files/2026-02/Banner_Sin%20riesgo_Ongoing.svg)](https://www.eafit.edu.co/ongoing)

![Image 20](https://www.eafit.edu.co/ongoing)

![Image 21: Imagen ¿Por qué estás pagando tanto por tus deudas?](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2026-03/por%20que%20pagando%20mas.png?itok=_CvKkSwi)

¿Por qué estás pagando tanto por tus deudas?

Hoy venimos al rescate de tu billetera con todo sobre la compra de cartera.

[Accede al artículo](https://www.eafit.edu.co/ongoing/sabelotodo/por-que-estas-pagando-tanto-deudas)

![Image 22: Imagen ¿Cómo estamos de inteligencia financiera?](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2026-03/inteligencia.png?itok=1uAtvH5k)

¿Cómo estamos de inteligencia financiera?

Necesaria si queremos alcanzar estabilidad financiera y tranquilidad mental.

[Accede al artículo](https://www.eafit.edu.co/ongoing/sabelotodo/como-estamos-inteligencia-financiera)

[![Image 23](https://www.eafit.edu.co/sites/default/files/2026-02/whatsapp-Ongoing_2026.svg)](https://api.whatsapp.com/send?phone=573142303843 "Botón sticky")

![Image 24: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 25: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 26: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 27: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 28: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 29: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 30: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 31: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
