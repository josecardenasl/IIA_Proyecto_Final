Title: Investigación

URL Source: https://www.eafit.edu.co/taxonomy/term/2626

Published Time: Fri, 08 May 2026 15:44:09 GMT

Markdown Content:
# Investigación | Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/taxonomy/term/2626#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/2626#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/2626# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/taxonomy/term/2626# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

## [Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado)

Abril 30, 2026

**La Superintendencia de Industria y Comercio otorgó la patente de invención del**_**Sistema móvil y plegable para asistir la movilidad de personas**_**a EAFIT y la Fundación Universitaria María Cano, una innovación desarrollada en colaboración con Tecnoparque SENA que busca mejorar la autonomía de pacientes con dificultades para caminar.**

**El desarrollo responde a las limitaciones de los caminadores tradicionales, como su peso, tamaño y dificultad de uso en espacios interiores, e integra un sistema ajustable para niños y adultos que permite mejorar la técnica de movilidad y acompañar procesos de rehabilitación.**

*   [Lee más sobre Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado "Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano")

La movilidad es uno de los factores que más influye en la autonomía y la calidad de vida de las personas, especialmente en quienes enfrentan procesos de rehabilitación o dificultades para caminar. En respuesta a este reto, EAFIT y la Fundación Universitaria María Cano, en colaboración con Tecnoparque SENA, desarrollaron un _Sistema móvil y plegable para asistir la movilidad de personas_, una innovación que recibió la patente de invención otorgada por la Superintendencia de Industria y Comercio mediante la Resolución 9791 de 2026, reconociendo su aporte al desarrollo de soluciones tecnológicas para la salud.

Para Juliana Ortiz Marín, directora de Innovación y Transferencia de EAFIT, “la concesión de esta patente representa para EAFIT un resultado que reafirma nuestra capacidad para identificar, alistar, proteger y transferir resultados de investigación, tecnologías y conocimiento al mercado y a las organizaciones. Es un hito que da cuenta de las capacidades en ciencia, tecnología e innovación de la Universidad”, dice, subrayando el valor de este logro en términos de impacto y transferencia del conocimiento.

La profesora Elizabeth Rendón Vélez, de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT y una de las inventoras del sistema, explica que el desarrollo parte de necesidades clínicas y de usuario identificadas durante el proceso de investigación. “La patente corresponde al desarrollo de un dispositivo tipo caminador que integra un sistema basculante, ajustable y plegable, diseñado para adaptarse al cuerpo del usuario, facilitar su transporte e incorporar monitoreo de variables de la marcha”.

La invención surge como respuesta a una problemática recurrente en los dispositivos médicos de asistencia a la movilidad: su peso y tamaño, que dificultan el desplazamiento en espacios reducidos. Se estima que del 70 % de los caminadores no permite el ingreso a espacios interiores debido a sus dimensiones y a la complejidad de sus sistemas de plegado, lo que limita la autonomía de los usuarios y su movilidad en entornos cotidianos.

El proyecto fue posible gracias a un trabajo colaborativo entre EAFIT, la Fundación Universitaria María Cano y el Tecnoparque SENA nodo Medellín, que integró capacidades académicas, clínicas y tecnológicas. En este proceso también participaron estudiantes del pregrado de Ingeniería de Diseño de Producto de EAFIT, quienes aportaron al diseño del sistema de plegado, el prototipado y la validación del sistema en el marco de espacios académicos de formación e investigación aplicada.

“La colaboración interinstitucional es clave en este tipo de desarrollos, en tanto permite complementar capacidades, fortalecer los procesos de diseño y asegurar que las soluciones respondan de manera más precisa a las necesidades identificadas”, destaca Juliana Ortiz.

La idea del dispositivo comenzó a gestarse en 2016, a partir de una conversación entre investigadores y especialistas en ortopedia infantil sobre las dificultades de movilidad de niños y personas con discapacidad en Medellín, especialmente por la topografía de la ciudad, el transporte público y las limitaciones de los dispositivos existentes. A partir de este diálogo se consolidó una alianza interinstitucional orientada a la vigilancia tecnológica, la identificación de necesidades clínicas y el desarrollo de un prototipo funcional.

###### Ciencia que mejora la calidad de vida

Para la profesora Fanny Valencia Legarda, inventora e investigadora de la Fundación Universitaria María Cano, el proyecto nació con el propósito de responder a una necesidad real de las comunidades. “Esta patente es un logro no solo académico, sino investigativo, ya que da solución a una necesidad fundamental como es la movilidad para personas que carecen de ella o tienen limitaciones en sus desplazamientos y actividades, mejorando su calidad de vida y su rol social”, afirma.

El dispositivo no está limitado a un tipo específico de población, ya que puede ajustarse a personas de distintas alturas y condiciones físicas, lo que lo hace útil tanto para niños como para adultos. Esta adaptabilidad permite acompañar procesos de rehabilitación a lo largo del tiempo, ajustando la altura, la inclinación del tronco y las condiciones de soporte según las necesidades del paciente, especialmente en niños con discapacidad o en procesos terapéuticos de movilidad, facilitando su desplazamiento de manera más segura y reduciendo la sobrecarga en las extremidades superiores.

Camilo Andrés Páramo Velásquez, experto del Tecnoparque SENA en la línea de Ingeniería y Diseño, resalta que la principal diferencia frente a los caminadores tradicionales radica en su capacidad de adaptación, ergonomía y monitoreo inteligente. “Más allá de asistir el desplazamiento, propone una nueva forma de interacción entre el usuario y el dispositivo, en la que el movimiento no solo se facilita, sino que también se mide, se comprende y se optimiza en función de las necesidades individuales”, señala.

Desde el área de Transferencia de Tecnología y Conocimiento de EAFIT, el proceso de patentamiento fue acompañado de manera integral, articulando a los aliados y gestionando los requerimientos técnicos y jurídicos ante la Superintendencia de Industria y Comercio.

El siguiente paso es avanzar hacia el desarrollo de prototipos más robustos, como lo afirma Melissa Durango Montoya, coordinadora de Transferencia de Tecnología y Conocimiento de EAFIT. “El principal reto es darle continuidad al desarrollo en una segunda etapa que permita avanzar hacia la materialización de prototipos, con el fin de validar la tecnología y explorar escenarios de fabricación y escalamiento. Este proceso deberá realizarse en articulación con los socios, buscando llevar el desarrollo hacia etapas más cercanas a su implementación por fuera del entorno académico”, afirma

De esta manera, la patente marca un punto de partida para que la investigación avance hacia su implementación en escenarios clínicos y productivos. El propósito es que el sistema móvil y plegable se consolide como una tecnología accesible para hospitales, centros de rehabilitación y comunidades que requieren soluciones eficientes de asistencia, demostrando que la articulación entre diferentes actores puede traducirse en innovaciones que fortalecen la seguridad, la autonomía y la inclusión de las personas.

Imagen Noticia EAFIT

![Image 21: Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://universidadeafit.widen.net/content/c5dd5394-7a1b-46bc-93d4-e01ffbbe080a/web/Patente-caminador.png)

Leyenda de la imagen

El sistema incorpora diseño ergonómico, adaptabilidad y monitoreo de la marcha para acompañar procesos terapéuticos y de recuperación.

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Nuestro impacto](https://www.eafit.edu.co/taxonomy/term/1886)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y)

Abril 23, 2026

**Este miércoles 22 de abril se realizó la**_**Muestra de iniciativas inspiradoras de aprendizaje experiencial**_**, un espacio en el que estudiantes, profesores y colaboradores presentaron sus proyectos en la Plazoleta del Estudiante, evidenciando cómo se transforma la teoría en experiencias aplicadas.**

**La Muestra, parte de la programación de la séptima edición de Acción EAFIT, una semana de eventos que en esta ocasión incluye talleres, conversaciones y actividades que exploran la innovación educativa, el uso de tecnologías y el impacto de la inteligencia artificial.**

*   [Lee más sobre EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y "EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología")

La Plazoleta del Estudiante se transformó este miércoles 22 de abril en un espacio de experimentación y conexión con la _Muestra de iniciativas inspiradoras de aprendizaje experiencial_. Prototipos en impresión 3D, simuladores, juegos interactivos y modelos matemáticos se encontraron en una misma escena para dejar a un lado la teoría abstracta y permitir que estudiantes, profesores y colaboradores activaran los sentidos alrededor de diferentes proyectos.

La Muestra, realizada en el marco de la séptima edición de Acción EAFIT, congregó propuestas que demostraron cómo en la Universidad se integra la tecnología para enriquecer los procesos educativos. Allí se reafirmó que el conocimiento cobra mayor sentido cuando se conecta con contextos reales y se pone en acción.

Uno de los proyectos participantes fue BeeMaker, una propuesta que, además de su enfoque en el aprendizaje experiencial, destaca por su origen familiar. La iniciativa es liderada por Hilda Bermúdez García junto con su esposo, graduado de Ingeniería Mecánica, y su hija, estudiante de Ingeniería de Diseño de Producto de EAFIT. Esta conexión intergeneracional ha permitido integrar conocimientos, experiencias y miradas complementarias en el desarrollo del proyecto.

“Todo este proyecto nace de un problema que tenemos en nuestra sociedad y es la desconexión mano-cerebro, la pérdida de atención, los problemas de salud mental que tenemos por pasar largas horas frente a las pantallas”, explica Hilda, quien resalta cómo esta iniciativa busca responder a esa necesidad a través de experiencias prácticas que conectan el hacer con el pensar.

BeeMaker también ha fortalecido su camino a través de su participación en la incubadora On.Going de EAFIT, donde fue uno de los finalistas de su cohorte más reciente. Este proceso les ha permitido consolidar su modelo educativo basado en laboratorios maker, tanto físicos como itinerantes, y proyectarlo hacia su implementación en diferentes contextos educativos.

En el campo de las ciencias aplicadas, los semilleros también demostraron el valor de conectar teoría y práctica. Un modelo epidemiológico desarrollado en el software Matlab permite simular escenarios como epidemias, en los que los usuarios pueden modificar variables como tasas de contagio o recuperación y observar sus efectos en tiempo real. “El punto es aplicarlo en problemas del entorno, y ver cómo las matemáticas pueden ser un puente para la toma de decisiones con un impacto en el mundo real”, explica Juan Pablo Peláez Montoya, coordinador del Semillero de Matemáticas Puras de la Universidad y estudiante de Ingeniería Matemática. 

Los laboratorios de la Universidad también fueron protagonistas, mostrando cómo los estudiantes diseñan soluciones tecnológicas integrales. Uno de los proyectos presentados fue un dosificador con aplicación en el ámbito medicinal, que combina diseño mecánico, electrónica y programación, e incorpora tecnologías como impresión 3D y comunicación inalámbrica. “A partir de toda la parte técnica y teórica que desarrollan con el profesor, los estudiantes llevan a cabo una planta tecnológica haciendo uso de los recursos de la Universidad”, cuenta Erika Montoya Cardona, coordinadora de los Laboratorios de Ciencias Físicas de EAFIT.

En esta misma línea, el programa Kratos, desarrollado por estudiantes y profesores con el apoyo de aliados estratégicos, presentó su vehículo de tracción eléctrica, resultado de un trabajo interdisciplinario que integra conocimientos de ingeniería y diseño. Además, compartió la experiencia del simulador de competencia, el cual permite a los estudiantes entrenar en condiciones similares a las reales antes de participar en escenarios nacionales.

###### Tecnología que potencia el aprendizaje

La integración de la tecnología en los procesos educativos también se hizo visible desde el Departamento de Gestión Curricular, que presentó un asistente de inteligencia artificial para el diseño microcurricular. Esta herramienta permite a los docentes crear syllabus, rúbricas y actividades de evaluación alineadas con el modelo educativo institucional, optimizando tiempos y fortaleciendo la planeación académica.

“Este asistente tiene un sello particular, porque está alimentado con documentos institucionales como nuestro Proyecto Educativo Institucional, la guía de acompañamiento para el diseño mesocurricular y nuestras definiciones sobre lo que es una competencia y un resultado de aprendizaje”, destacó Diana Karina Larrota Medrano, gestora de proyectos e iniciativas del Departamento de Gestión Curricular.

Por su parte, la Universidad de los Niños evidenció cómo las tecnologías también pueden acercarse a públicos más jóvenes a través de metodologías activas. En su espacio, los participantes se enfrentaron a retos basados en proyectos desarrollados por niños y jóvenes en áreas como robótica, automatización e inteligencia artificial. “No podemos dejar de lado la tecnología, porque hace parte del día a día de los niños y jóvenes”, afirmó Valery Julio Martínez, líder de metodologías de proyectos, al resaltar la importancia de conectar el aprendizaje con los contextos de las nuevas generaciones.

Desde las ciencias sociales, el Semillero de Investigación en Administración y Organizaciones también aportó a esta conversación al presentar una investigación sobre el impacto de tecnologías de la Cuarta Revolución Industrial en el desarrollo sostenible y el bienestar social. A través de un ejercicio divulgativo, los estudiantes mostraron cómo herramientas como la inteligencia artificial o el _blockchain_ están transformando la manera en que las organizaciones operan y toman decisiones. “Todo nace de una pregunta: estamos usando estas tecnologías, pero ¿cuál es el impacto que nos están generando?”, señaló Fernando Guevara Díaz, coordinador del Semillero.

Estas iniciativas reflejan cómo la tecnología, más que un fin, se convierte en un medio para ampliar las posibilidades del aprendizaje. Al integrarse con metodologías experienciales, no solo facilita procesos, sino que también promueve una formación más crítica, creativa y conectada con los desafíos actuales. Así, en Acción EAFIT, la tecnología se consolida como una aliada clave para seguir transformando la manera de enseñar y aprender.

Imagen Noticia EAFIT

![Image 22: Las actividades de Acción EAFIT se desarrollarán hasta este jueves 23 de abril, con eventos formativos, de conexión y culturales.](https://universidadeafit.widen.net/content/9e97e1f2-ee3f-46aa-a923-d0b06278bd58/web/campus-vivo-1500.jpg)

Leyenda de la imagen

Las actividades de Acción EAFIT se desarrollarán hasta este jueves 23 de abril, con eventos formativos, de conexión y culturales. 

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://www.eafit.edu.co/noticias/lo-que-esta-pasando-publicaciones/nueva-fase-para-la-energia-en-america-latina-ya-no-se)

Abril 20, 2026

**En el marco de los 20 años del Clúster Energía Sostenible,**[**el Centro Imaginar Futuros de EAFIT**](https://www.eafit.edu.co/centros-estudio-incidencia/imaginar-futuros)**presentó el informe**[_**Señales y tendencias 2030–2040 del sector energético en América Latina**_](https://universidadeafit.widen.net/s/8r9z5jwdm5/informe-tendencia-energia-latam)**. El documento plantea un cambio de enfoque: más que generar energía, el reto es gestionarla en sistemas y mercados que premien la flexibilidad.**

**En línea con este diagnóstico, y ante la necesidad de fortalecer el talento y la capacidad para gestionar sistemas complejos, durante el evento se lanzó el Centro Energy Valley, una iniciativa que articula empresa, Estado, academia y**_**startups**_**para ofrecer formación especializada e impulsar soluciones aplicadas.**

*   [Lee más sobre Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://www.eafit.edu.co/noticias/lo-que-esta-pasando-publicaciones/nueva-fase-para-la-energia-en-america-latina-ya-no-se "Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar")

En un momento en que el sistema energético atraviesa cambios profundos y acelerados, el sector se reunió el pasado 16 de abril en la Cámara de Comercio de Medellín para mirar hacia adelante. En el marco de los 20 años del Clúster Energía Sostenible, el Centro Imaginar Futuros de EAFIT presentó el informe [_Señales y tendencias 2030–2040 del sector energético en América Latina_](https://nam10.safelinks.protection.outlook.com/?url=https%3A%2F%2Fs60148679.t.en25.com%2Fe%2Fer%3Fs%3D60148679%26lid%3D16267%26elqTrackId%3D153597FBEC1165E0BF346D2AEED36AAD%26elq%3D98c76f77bdfa4f958ef422507a447b75%26elqaid%3D30759%26elqat%3D1%26elqak%3D8AF5286AAFA4E8E3ABF89844E2625418BBA0E93CFBE1F2C9F01C0187DC674F73E838&data=05%7C02%7Cslgutierrs%40eafit.edu.co%7Ccf8fd21e01af47d8f31508de9ee48f95%7C99f7b55e9cbe467b8143919782918afb%7C0%7C0%7C639122901650650538%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=ysVt5UKP1C1Va5UbP3BVcpZBSuIbcoCXilyXUA%2BmhQQ%3D&reserved=0), un análisis que traza el rumbo de la región en las próximas décadas y que coincidió con el lanzamiento de Energy Valley, centro avanzado de energía, como una apuesta para responder a estos desafíos creado gracias a una alianza entre EAFIT, la Universidad EIA, la Cámara de Comercio de Medellín para Antioquia, Celsia, ISA, EPM, Isagén, ERCO, Novatio, Azimut y la Alcaldía de Medellín.

El informe parte de una premisa clara: la transición energética en América Latina ya no se define únicamente por la expansión de las energías renovables, sino por la capacidad de gobernabilidad. En una región donde cerca del 60 % de la generación eléctrica ya es renovable y la demanda crecerá un 91 % hacia 2040, el reto está en construir sistemas capaces de almacenar, distribuir e integrar esa energía de manera confiable y eficiente en mercados que premien la flexibilidad.

“El almacenamiento de energía se está convirtiendo en el eje que habilita todo lo demás: no es solo una discusión tecnológica sobre baterías o materiales, sino una competencia por quién logra gestionarlo mejor y, con eso, liderar la transformación del sistema energético”, explicó José Alejandro Betancur, director del Centro Imaginar Futuros de EAFIT, quien conversó en un panel, en la presentación de Energy Valley, con Jaime Arenas, director del Clúster Energía Sostenible, sobre estos hallazgos.

En esa línea, el documento presenta el almacenamiento como la primera gran tendencia estructural, afirmando que ya no se trata de un complemento de las energías renovables, sino de un activo estratégico con modelos de negocio propios y múltiples fuentes de ingreso. Así, el valor del sistema se desplaza de la construcción de plantas hacia su gestión inteligente.

Esta reconfiguración del sistema no se sostiene en una única tendencia, sino en la unión de varias soluciones. “Almacenamiento, energía distribuida y energía nuclear son las tres tendencias fundamentales, pero deben articularse con interconexión y eficiencia energética para que el sistema funcione”, advirtió Jaime Arenas.

###### Otras tendencias y señales

Entre las principales tendencias identificadas, se destaca la expansión de la energía distribuida. Más que una tecnología, representa un cambio de comportamiento: hogares, empresas y comunidades pasan de ser consumidores a actores activos del sistema, lo que exige nuevas capacidades de coordinación, regulación y gestión de datos. “Con la energía distribuida estamos preparados, pero aún tenemos retos de colaboración para que funcione. Eso se hace evidente al ver las señales en Brasil y Chile: ese conocimiento es el que debemos exportar”, afirmó José Alejandro.

A estas transformaciones se suman nuevas fronteras tecnológicas y geopolíticas. El hidrógeno verde avanza hacia su consolidación institucional, aunque aún enfrenta desafíos, mientras que los minerales críticos como el litio y los mercados de carbono comienzan a incidir en la competitividad de empresas y territorios.

Otra tendencia relevante es el retorno de la energía nuclear a la conversación estratégica. Más allá de decisiones inmediatas y de los debates que aún genera, su inclusión en los marcos de planificación amplía el portafolio de soluciones para garantizar suministro firme en el largo plazo. “Hoy el cuello de botella ya no es tecnológico, sino de talento, regulación y financiamiento. Eso abre una oportunidad enorme, pero también un reto: necesitamos formar nuevas capacidades, perfiles y formas de aprendizaje que respondan a la complejidad del sistema energético que viene”, resaltó José Betancur.

Finalmente, la biomasa reaparece como una alternativa estratégica para aportar generación firme al sistema energético. El informe señala que las moléculas limpias provenientes de la bioenergía ya avanzan con marcos regulatorios robustos en países como Brasil, donde podrían movilizar inversiones a gran escala en los próximos años.

En Colombia, aunque existe un potencial importante, su desarrollo exige condiciones claras. “El país tiene potencia en biomasa, pero requiere escala, masa crítica e inversiones; en este momento todas las formas de generación valen”, advirtió Jaime Arenas, al subrayar que, en un escenario de alta incertidumbre climática, estas fuentes deberán complementar a las renovables para garantizar suministro continuo y conexión efectiva con los centros de consumo.

Con este panorama, el lanzamiento de Energy Valley busca cerrar brechas clave, especialmente en formación de talento y desarrollo tecnológico. La iniciativa apunta a convertir el conocimiento en soluciones aplicadas, fortalecer la investigación y anticipar las capacidades que requerirá la industria antes de que el mercado las demande.

La conclusión es contundente: el liderazgo energético en América Latina dependerá menos de la disponibilidad de recursos y más de construir nuevas capacidades, desarrollar talento especializado y gestionar sistemas cada vez más complejos. De esta forma, iniciativas como el nuevo centro buscan posicionar a Medellín y a Colombia como actores relevantes en la transformación energética de la región.

Imagen Noticia EAFIT

![Image 23: Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://universidadeafit.widen.net/content/1e26403e-34ad-44fd-98d4-b1ff716a698f/web/Nueva-fase-energia.jpg)

Leyenda de la imagen

El informe presenta señales y tendencias, así como las claves del sistema energético del futuro: flexibilidad, talento y nuevos modelos de mercado. En la imagen José Alejandro Betancur, director del Centro Imaginar Futuros de EAFIT y con Jaime Arenas, director del Clúster Energía Sostenible, durante la presentación del informe.

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

[Publicaciones](https://www.eafit.edu.co/taxonomy/term/1906)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Simens Energy implementará en Estados Unidos un aislador sísmico desarrollado en alianza con EAFIT](https://www.eafit.edu.co/noticias/nuestro-impacto/simens-energy-implementara-en-estados-unidos-un-aislador-sismico)

Abril 9, 2026

**El aislador sísmico, craeado por la Universidad en alianza con Ecuas Consultores y Edemco, será implementado por Siemens Energy en una subestación eléctrica en California (Estados Unidos), marcando un hito en la llegada de esta tecnología a mercados internacionales.**

**El desarrollo busca proteger infraestructuras críticas frente a terremotos y garantizar la continuidad del servicio eléctrico en zonas de alta sismicidad. El proyecto, resultado de cerca de 15 años de investigación, demuestra cómo la colaboración entre universidad y empresa permite llevar conocimiento científico al mercado.**

*   [Lee más sobre Simens Energy implementará en Estados Unidos un aislador sísmico desarrollado en alianza con EAFIT](https://www.eafit.edu.co/noticias/nuestro-impacto/simens-energy-implementara-en-estados-unidos-un-aislador-sismico "Simens Energy implementará en Estados Unidos un aislador sísmico desarrollado en alianza con EAFIT")

La energía que llega a hospitales, centros de comunicación, industrias y hogares depende de infraestructuras que deben seguir funcionando incluso en medio de un terremoto. Con este desafío en mente, EAFIT, en alianza con Ecuas Consultores y Edemco, desarrolló un aislador sísmico para subestaciones eléctricas que busca proteger estos sistemas críticos y garantizar la continuidad del servicio en zonas de alta sismicidad. Hoy, esta tecnología marca un hito al ser adquirida por Siemens Energy para su implementación en California (Estados Unidos), llevando la ingeniería desarrollada en Colombia a escenarios internacionales.

“Más allá de sus características técnicas, este desarrollo se diferencia por ser el resultado de un proceso colaborativo sostenido entre academia y empresa, que ha permitido llevar una tecnología desde su etapa inicial hasta su adopción por un actor global”, afirma Natalia Raigoza Rodríguez, coordinadora de Transferencia de Tecnología y Conocimiento de EAFIT, quien destaca que este proyecto evidencia que la innovación de alto impacto requiere procesos de largo aliento y trabajo articulado entre distintos actores.

La tecnología es el resultado de cerca de 15 años de trabajo conjunto entre EAFIT y Ecuas Consultores, junto con un proceso de transferencia tecnológica con Edemco, empresa encargada de su fabricación y comercialización. Para su desarrollo, el dispositivo fue probado en los laboratorios de ingeniería sísmica de la Universidad, que cuentan con capacidades como la mesa vibradora y el muro de reacción, espacios en los que se validaron modelos teóricos y computacionales en condiciones reales antes de avanzar hacia su implementación internacional.

###### Un modelo de colaboración

El proyecto se concibió con el propósito de conectar el conocimiento científico con su aplicación en el sector productivo, consolidando un modelo de innovación basado en la colaboración. “El rol de la Universidad en este proyecto y en cualquier otro es aportar el conocimiento, la ciencia y la tecnología, mientras el sector productivo pone las necesidades y su experiencia en el trabajo con este tipo de dispositivos”, afirma Juan Diego Jaramillo, investigador principal del proyecto por parte de EAFIT.

Desde el sector empresarial, Edemco ha sido un aliado clave en la fabricación del dispositivo. Giovanni Gelvez, representante legal en Ecuas Consultores y gerente de Estructuración de proyectos civil en Edemco, resalta que este avance posiciona a Colombia como un país capaz de responder a los estándares internacionales del sector energético. “Estar haciendo las pruebas del primer aislador sísmico fabricado en Colombia para equipos de subestaciones nos coloca a la vanguardia en metodologías para garantizar el desempeño y la confiabilidad de las subestaciones eléctricas”, asegura.

El desarrollo también ha contado con el acompañamiento de Siemens Energy, empresa que identificó el potencial de la tecnología y decidió incorporarla en uno de sus proyectos en Estados Unidos, lo que ha permitido alinear el sistema con exigencias globales y avanzar en su implementación. Juan Arias, senior key expert for Seismic Concept & Studies en Siemens Energy, Alemania, señala: “Somos conscientes de que en Colombia y en EAFIT existe un gran potencial en ingeniería y en el desarrollo de sistemas no convencionales, y por eso decidimos invertir en este desarrollo que ahora está a puertas de su aplicación en una zona de alta sismicidad en California”.

Actualmente, el aislador sísmico será sometido a pruebas adicionales en Europa antes de su instalación final en Estados Unidos, como parte del proceso de validación internacional. Este avance no solo consolida a EAFIT y a sus aliados como referentes en transferencia tecnológica, sino que también abre la puerta a nuevos desarrollos y colaboraciones en el sector energético, reafirmando el potencial de la ingeniería colombiana para crear soluciones que fortalezcan la seguridad energética y la resiliencia de infraestructuras críticas a nivel global.

Imagen Noticia EAFIT

![Image 24: Simens Energy implementará en Estados Unidos un aislador sísmico desarrollado en alianza con EAFIT](https://universidadeafit.widen.net/content/3301aa23-0d65-4f97-aed3-d1165112fe7d/web/SimensEnergy-1500.jpg)

Leyenda de la imagen

La tecnología continuará su proceso de pruebas en Europa antes de su instalación final en Estados Unidos. En la imagen, pruebas del aislador sísmico en el Laboratorio de ingeniería sísmica de EAFIT.

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Nuestro impacto](https://www.eafit.edu.co/taxonomy/term/1886)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [¿Por qué investigadores de EAFIT y la UdeA estudian a un gusano en la Antártica?](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/por-que-investigadores-de-eafit-y-la-udea-estudian-un-gusano)

Febrero 12, 2026

**Los investigadores participan en la Campaña 2026 de la Antártida, para estudiar gusanos marinos conocidos como Poliquetos. Se trata de una investigación que combina taxonomía, genética y biología molecular. En la misión está Javier**[**Correa Álvarez**](https://youtu.be/yZpJHjmAJ2Y)**, profesor de la escuela de Ciencias Aplicadas e Ingeniería de EAFIT.**

**Estudiar la adaptación de los Poliquetos antárticos a cambios extremos de temperatura y pH del océano servirá para comprender los efectos del cambio climático y prepararnos para afrontarlos. Esta misión es clave para posicionar a Colombia como un país que aporta ciencia de primer nivel en el continente blanco.**

*   [Lee más sobre ¿Por qué investigadores de EAFIT y la UdeA estudian a un gusano en la Antártica?](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/por-que-investigadores-de-eafit-y-la-udea-estudian-un-gusano "¿Por qué investigadores de EAFIT y la UdeA estudian a un gusano en la Antártica?")

¿Antártica o Antártida? Ambas formas son correctas para referirse al continente blanco, también referido como Polo Sur. Una masa de tierra seca y fría que contiene más del 70-80 % del agua del planeta, en estado de congelación. Un laboratorio vivo desde donde se estudian, entre otras cosas, los sistemas oceánicos, el cambio climático y el espacio. 

Es habitada por alrededor de 14 millones pingüinos, focas y ballenas, pero no tiene población nativa de humanos, ni osos polares. Es el único lugar del planeta Tierra que es de todos y a la vez de nadie, así se estableció en el Tratado Antártico de 1959, que declaró este territorio como una zona de ciencia y paz, prohibiendo actividades militares. Allí tampoco existen los conflictos entre países, pero en cambio sí se dan investigaciones entre naciones. Cada año, durante el verano, investigadores de diversas disciplinas viajan desde diferentes partes del mundo para cumplir misiones establecidas en el [Comité Científico de Investigaciones Antárticas](https://nam10.safelinks.protection.outlook.com/?url=https%3A%2F%2Fscar.org%2F&data=05%7C02%7Cslgutierrs%40eafit.edu.co%7Ca479e5ef63324004843b08de6365ef32%7C99f7b55e9cbe467b8143919782918afb%7C0%7C0%7C639057486628824595%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=r4G71ys0cxguf61tPDAVjMjb%2BsRBK4f%2Bcfg7y6ndtBM%3D&reserved=0), (SCAR por sus siglas en inglés).

Hasta ese lugar viajará el biólogo molecular Javier Correa Álvarez, profesor de la escuela de Ciencias Aplicadas e Ingeniería de EAFIT. Él es uno de los investigadores colombianos que integran la campaña 2025/2026 de la XII Expedición Antártica Colombiana, coordinada por el [Programa Antártico Colombiano](https://cco.gov.co/secretaria/asuntos-internacionales-y-politicos/asuntos-internacionales/pac/)(PAC), que desde el 2014 hace presencia en la zona.

El acercamiento del profesor Javier con la Antártica comenzó desde la distancia, cuando biólogos de la Universidad de Antioquia, quienes ya habían participado en expediciones anteriores, lo invitaron para “hacer parte de un estudio que indagaba sobre cómo un diminuto gusanito marino era capaz de resistir a temperaturas extremas”, recuerda el profesor. En ese entonces, su tarea consistió en analizar una serie de datos obtenidos en las expediciones, lo cual resultó en el primer [atlas genético](https://www.sciencedirect.com/science/article/pii/S1874778724000035) de estos gusanitos, conocidos como poliquetos.

Con la llegada del profesor Javier Correa a esta investigación, según lo expresa el biólogo Mario Londoño Mesa, profesor de la Universidad de Antioquia, “potenciamos la investigación que habíamos llevado durante varios años solos en la U.deA., dado su gran experiencia en biología molecular”.

Imagen Noticia EAFIT

![Image 25: En la imagen, participantes de la XII Expedición Antártica Colombiana, en el ARC Simón Bolívar, buque de investigación científica de la Armada Colombiana, durante el entrenamiento en la ciudad de Cartagena.](https://universidadeafit.widen.net/content/a30eb12e-e748-42cd-becc-3f0e6340cd31/web/Investigadores-ppal.jpg)

Leyenda de la imagen

En la imagen, participantes de la XII Expedición Antártica Colombiana, en el ARC Simón Bolívar, buque de investigación científica de la Armada Colombiana, durante el entrenamiento en la ciudad de Cartagena.

###### **Qué son los Poliquetos**

Resulta que las lombrices de tierra y las sanguijuelas tienen unos familiares a los que les gusta vivir en cuerpos de agua, muy cerca al mar, sea en el trópico o en la antártica. Si hay agua, preferiblemente salada, esa será su casa. Los poliquetos tienen el cuerpo segmentado y se caracterizan por la presencia de unas estructuras denominadas quetas, que se asemejan a pelos cortos.

Tienen alrededor de 80 familias diferentes. Pueden ser depredadores, herbívoros o sedimentívoros; también los hay que filtran agua, que son parásitos o simbiontes. Cada uno juega un papel diferente en el ecosistema, por ejemplo, son fuente de alimento de muchos organismos como peces, crustáceos o rayas. Por lo tanto, son demasiado importantes en el hábitat y lo han sido desde hace más de 500 millones de años, tiempo desde el cual se estima su existencia.

[![Image 26: imagen de referencia](https://universidadeafit.widen.net/content/08ee54bf-6015-4e1a-96a4-02b72eb4971d/web/Foto-sec-poliqueto.jpg)](https://www.eafit.edu.co/taxonomy/term/2626)

![Image 27](https://www.eafit.edu.co/taxonomy/term/2626)

###### La campaña 2025/2026

El interés del profesor Mario Londoño por los poliquetos comenzó en los años 90, cuando era estudiante del pregrado en biología de la UdeA. En un principio se enfocó en la taxonomía y ecología de los que habitan en las costas colombianas. Su trabajo continuó y uno de sus aportes fue la descripción de unas 40 especies nuevas.

Debido a que los poliquetos son modelos biológicos útiles para determinar cambios en los océanos y son sensibles a las variaciones en pH, temperatura y contaminación, particularmente en un ambiente como el austral “son importantes para estudiar el impacto del cambio climático, que es precisamente uno de los objetivos del PAC y del SCAR”, precisa Idalyd Fonseca González, profesora de la Universidad de Antioquia, quien desde el año 2017 lidera una investigación sobre el estrés térmico de los poliquetos y el cambio climático en la Península Antártica.

Cada nueva visita a la Antártica es una oportunidad para comprender a los Poliquetos y en esta campaña el propósito es entender a nivel molecular la adaptación del Poliqueto a un océano más ácido, para lo cual se requiere de la generación y procesamiento de datos genéticos obtenidos directamente en campo.

Los biólogos planean realizarán experimentos en el laboratorio en la [base científica chilena Prof. Julio Escudero](https://www.inach.cl/expedicion-antartica/bases-chilenas-en-antartica-2/base-profesor-julio-escudero/), donde los poliquetos serán expuestos a diferentes pH de agua oceánica, situaciones pronosticadas por las siguientes décadas, debido al deshielo causado por el calentamiento global. Luego se secuenciará el ADN y ARN para reconstruir cómo se genera la adaptación. “En esta oportunidad la resolución de la investigación será mucho más precisa porque, gracias a las [herramientas tecnológicas que tenemos](https://youtu.be/8tUS5tDMH3k?si=dCOH8lUt_4G0kzWz), vamos a poder detallar los genes y proteínas responsables de este fenómeno”, precisa el profesor Correa.

###### La cooperación

Cuando se habla de investigación en el continente blanco hay una palabra que está presente de principio a fin. Se trata de una herramienta intangible pero imprescindible: la cooperación. Si se tienen en cuenta la magnitud de los desafíos ambientales que enfrenta investigar en esta zona del planeta, se requiere de una acción colectiva, interdisciplinaria y multinacional. Al cooperar, “los países pueden optimizar recursos acceder a datos valiosos, formar redes de conocimiento y enfrentar, de manera conjunta, las urgencias del cambio climático y la conservación de uno de los ecosistemas más frágiles y esenciales del planeta”, reflexiona Alejandro Font Mascareño, jefe de la sección Plataformas Científica del Instituto [Antártico Chileno](https://www.inach.cl/)(INACH).

Hay cooperación cuando países como Chile, a través del INACH, posibilita estas investigaciones mediante la planificación de la expedición, el préstamo de su infraestructura en terreno, la logística para el desplazamiento, alojamiento, acceso a laboratorios, cámara fría de experimentación y acuarios en sus plataformas científicas en Punta Arenas, donde queda la base chilena profesor Julio Escudero.

Según Alejandro Font, “para Chile la colaboración con Colombia permite fortalecer la mirada regional frente a los desafíos comunes en ciencia, medioambiente y cambio climático. Colombia aporta capacidades científicas complementarias, nuevas miradas investigativas y vínculos institucionales que enriquecen el ecosistema de investigación polar. Además, este tipo de colaboración impulsa la descentralización del conocimiento y permite avanzar hacia una ciencia más inclusiva y representativa del sur global”.

También hay cooperación en el ámbito local, cuando universidades como la de Antioquia y EAFIT unen esfuerzos para potenciar sus capacidades porque, tal y como lo expresa la profesora Idalyd, “sin duda la ciencia es interdisciplinaria y precisamente, en la oportunidad de aunar recursos, ideas y capacidades está el mayor potencial de desarrollo científico”.

###### La relevancia de esta investigación

Es mucho lo que puede resultar de investigar a estos pequeños seres de mar. Por ejemplo, se podrán complementar los estudios sobre los efectos del cambio climático realizados en organismos carismáticos como ballenas, aves, crustáceos y mamíferos en general. También podría ayudarnos a evaluar esos cambios de temperatura y como nos puede afectar a los humanos.

La investigación liderada por las universidades de Antioquia y EAFIT, en palabras de Alejandro Font, “se enfoca en la caracterización taxonómica, genética y funcional de estas especies, contribuyendo significativamente a la comprensión de la biodiversidad de todo lo que habita en el fondo marino. Este trabajo complementa otras líneas de investigación desarrolladas por INACH y socios internacionales y aporta información valiosa sobre cómo estas especies responden a condiciones ambientales extremas y cambiantes”.

Los resultados de esta y otras investigaciones realizadas en la Antártica, tienen aplicaciones globales, desde la conservación de la biodiversidad hasta la proyección de escenarios climáticos futuros, lo que explica por qué la antártica es laboratorio natural esencial para la humanidad.

###### Colombia: camino a miembro votante del tratado antártico

Además de la relevancia de esta investigación para el planeta Tierra, la Expedición Científica Antártica número 12, que incluye la investigación sobre los poliquetos, significa para Colombia la posibilidad de mostrar capacidad investigativa, en ciencia y tecnología.

Esto último puede tener una consecuencia positiva: pasar de la categoría de miembros consultivos a miembros votantes, lo cual se logra obteniendo resultados científicos en las expediciones, demostrando a la comunidad internacional que queremos estar a la vanguardia de la investigación científica a nivel mundial.

“Por lo tanto, la importancia de que nosotros como Universidad Antioquia y EAFIT participemos en esta expedición y demostremos resultados, da méritos para que el Comité Internacional del Tratado Antártico nos vea con buenos ojos y podamos, en algún momento, colaborar como país consultivo, con voz y voto, en las decisiones que se tienen en la Antártica”, explica el profesor Mario Londoño.

Para EAFIT es la posibilidad de ser parte de investigaciones que trascienden el impacto regional para aportar en la solución problemáticas sociales y ambientales que afectan al planeta. Para el profesor Javier Correa, ser parte de esta expedición es la posibilidad de aportar conocimiento, “de descubrir algo que está oculto en la naturaleza por millones de años y entenderlo. Y poder, a partir de ahí, formular más preguntas, pues a eso nos dedicamos los biólogos, somos curiosos de la vida y eso es lo que me incentiva a investigar.

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [En EAFIT se ubica uno de los puntos de referencia de gravedad más importantes de Colombia](https://www.eafit.edu.co/noticias/especiales/en-eafit-se-ubica-uno-de-los-puntos-de-referencia-de-gravedad-mas-importantes)

Febrero 5, 2026

**Se trata de un vértice gravedad materializado por el Instituto Geográfico Agustín Codazzi (IGAC) y el Servicio Geológico Colombiano (SGC), ubicado al interior de la librería Acentos de EAFIT. Este es uno de los 28 puntos de gravedad absoluta que tiene Colombia y que integran la red de referencia nacional de gravedad del país.**

**La medición de la gravedad absoluta permite detectar variaciones imperceptibles del subsuelo, información útil en ingeniería, minería, geología y otras áreas. Por eso el vértice de gravedad ubicado en la Universidad, es un nodo científico que sirve para calibrar otros gravímetros y, además, alimenta modelos globales de gravedad, altura y comportamiento del planeta Tierra.**

*   [Lee más sobre En EAFIT se ubica uno de los puntos de referencia de gravedad más importantes de Colombia](https://www.eafit.edu.co/noticias/especiales/en-eafit-se-ubica-uno-de-los-puntos-de-referencia-de-gravedad-mas-importantes "En EAFIT se ubica uno de los puntos de referencia de gravedad más importantes de Colombia")

977 741,0917 mGaL ± 0.0108. Estos caracteres no provienen del azar ni son un accidente de tipeo que se escapó de la revisión. Corresponden al valor medido por el gravímetro _Microg LaCoste A10_ en el vértice absoluto de gravedad identificado como MEDE-01. Como se trata un asunto de precisión vamos a entregar una mejor ubicación: el epicentro de esta medición queda en el campus de EAFIT. Para mayor exactitud diríjase hasta la Librería Acentos, ingrese por el acceso occidental gire hacia la izquierda y busque en el piso la cabeza de una pequeña varilla plateada, del tamaño de una moneda de 50 pesos colombianos.

¿Eso es todo? No. Porque esa esfera, conocida también como vértice de gravedad, es de altísimo interés científico y alimenta los modelos de gravedad mundial, además, según lo explica, el Ingeniero Carlos Andrés Franco Prieto, subdirector de Cartografía y Geodesia del Instituto Agustín Codazzi (IGAC), “este vértice es de vital importancia ya que es, hasta la fecha, el primero seleccionado de la red de referencia nacional de gravedad para integrarse con las alturas definidas en el ámbito mundial”.

###### Primero, la Gravedad

Para seguir avanzando en esta historia habrá que retroceder en el tiempo, hasta el siglo XVII, cuando el físico inglés Isaac Newton definió formalmente el concepto de la gravedad como una fuerza universal, la cual describió matemáticamente en su ley de gravitación universal de 1687, donde estableció que todas las partículas con masa en el universo se atraen mutuamente con una fuerza directamente proporcional al producto de sus masas e inversamente proporcional al cuadrado de la distancia que los separa.

Para no complicarnos con cálculos matemáticos digamos que la gravedad es una fuerza invisible que atrae a los objetos con masa entre sí. Es algo así como un imán gigante que hace que las cosas caigan al suelo, que las personas tengamos los pies en la tierra y que los planetas giren alrededor del sol.

Sin embargo, la gravedad en la tierra no siempre es la misma, pues, “entre más cerca del centro de la Tierra yo esté, el valor es mucho más grande y entre más alejado será más pequeño. No será lo mismo medir la gravedad desde un polo que desde el Ecuador; así estén a la misma altura sobre el nivel del mar el valor absoluto es diferente”, explica David Santiago Avellaneda Jiménez, profesor del área de Sistemas Naturales y Sostenibilidad de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT.

Por eso, respuestas a preguntas como: ¿con qué fuerza cae un lápiz del escritorio? o ¿qué fuerza ejerce un edificio en un terreno?, dependerán del valor de la gravedad. Aunque parece un tema que interesa solo a geólogos, físicos o ingenieros, la fuerza de la gravedad es un asunto que, literalmente no solo nos “atrae”, sino que concierne a todos.

###### Luego, el vértice de gravedad

Para llegar al valor de la gravedad absoluta con que inició este texto, hubo que hacer la medición correspondiente en el punto de interés; de eso se ocupa la gravimetría. Ahora, el aparato que lo hace posible es el gravímetro: un instrumento de alta precisión que mide la aceleración de la gravedad terrestre y sus variaciones entre dos o más puntos.

Para medir la gravedad absoluta es necesario hacerlo desde un vértice de gravedad, como el ubicado en el campus de EAFIT por el Instituto Geográfico Agustín Codazzi, cuya selección y establecimiento “responde a criterios técnicos rigurosos que incluyen estabilidad geológica y sísmica, estabilidad hidrológica, mínima sismicidad artificial por tráfico vehicular, fácil acceso y alto potencial de utilización”, indica el subdirector de Cartografía y Geodesia del IGAC.

De los [**28 vértices que conforman la red de gravimetría absoluta en Colombia**](https://www.colombiaenmapas.gov.co/?e=-90.06785266601418,-11.337080004788033,-58.42722766602258,21.015531080307127,4686&b=igac&u=0&t=25), solo uno, el de EAFIT, fue seleccionado en 2015 por el [**Sistema de Referencia Geocéntrico para las Américas**](https://www.sirgas.org/es/sirgas-definition/)(SIRGAS), para ser la primera [**estación del Marco Internacional de Referencia de Alturas para Colombia**](https://mediatum.ub.tum.de/doc/1783587/1783587.pdf), debido a que corresponde a un vértice que posee una estación _Continually Operating Reference Station_ (CORS), para el monitoreo continuo de mediciones _Global Navigation Satellite System_ (GNSS), con una cantidad de registros históricos relevantes, además de una gran cantidad de información gravimétrica a su alrededor y de encontrarse en una zona de buena estabilidad geológica.

Imagen Noticia EAFIT

![Image 28: El vértice absoluto de gravedad identificado como MEDE-01, está ubicado en el primer piso del bloque 18, al interior de la librería Acentos.](https://universidadeafit.widen.net/content/aab9e2e5-f1cf-4e6b-87ae-11d53252e082/web/Foto-Acentos_principal-1.jpg)

Leyenda de la imagen

El vértice absoluto de gravedad identificado como MEDE-01, está ubicado en el primer piso del bloque 18, al interior de la librería Acentos.

**La estación de monitoreo CORS**

Si el vértice de gravedad es poco perceptible por su tamaño, la estación CORS es poco visible, pero por su ubicación: se encuentra sobre el techo del bloque 18 de EAFIT, para garantizar que la recepción de datos tenga el menor ruido posible. En palabras de Darwin Baquero Hernández, magíster en Tecnologías de la información geográfica, profesional en geodesia del IGAC, “una estación CORS es una estación fija equipada con receptores GNSS de alta precisión que registra, de manera continua, las señales emitidas por los satélites de posicionamiento, como GPS, Galileo, GLONASS, BeiDou, entre otras constelaciones”. A diferencia de los dispositivos de navegación comunes, estas estaciones operan las 24 horas del día, los 7 días de la semana, generando información precisa sobre la posición de un punto en la superficie terrestre.

En términos sencillos, una estación CORS funciona como un “punto de referencia permanente” que permite conocer con exactitud dónde se encuentra un lugar y cómo este puede cambiar con el tiempo. Gracias a esta información es posible corregir errores en las mediciones realizadas por otros receptores GNSS de menor calidad, lo que permite alcanzar precisiones del orden de centímetros o incluso milímetros.

“Además de su uso en actividades cotidianas como topografía, construcción o catastro, las estaciones CORS cumplen un papel fundamental en el ordenamiento del territorio. A partir de sus datos se pueden detectar movimientos lentos de la corteza terrestre, deformaciones asociadas a sismos, asentamientos del terreno o desplazamientos causados por procesos naturales y antrópicos. De esta manera, las estaciones CORS no solo apoyan el desarrollo de infraestructura y planificación territorial, sino que también contribuyen a la gestión del riesgo y al estudio de la dinámica del planeta”, aclara Darwin Baquero.

En conjunto, una red de estaciones CORS constituye la columna vertebral del marco geodésico del país, la región y el planeta, ya que garantiza que todas las mediciones espaciales se realicen sobre una base tecnológica común, precisa y confiable, asegurando la coherencia y calidad de la información geoespacial utilizada por instituciones, investigadores y la sociedad en general.

La información obtenida por estas antenas es de acceso público y se puede consultar en el sitio del [**Instituto Geográfico Agustín Codazzi**](https://www.igac.gov.co/).

[![Image 29](https://universidadeafit.widen.net/content/0ad90781-2d0a-4591-b99e-4435a3c73c58/web/Foto-sec-CORS.jpg)](https://www.eafit.edu.co/taxonomy/term/2626)

![Image 30](https://www.eafit.edu.co/taxonomy/term/2626)

###### La gravedad absoluta se mide con un vértice

Un vértice, que se materializa en terreno de distintas formas, es un punto de referencia permanente donde se realizan mediciones. En el caso del vértice absoluto de EAFIT, se encuentra materializado mediante un cilindro incrustado aproximadamente a 10 centímetros de profundidad, “a este punto se le asocia el valor medido junto con sus coordenadas precisas, lo que permite identificar exactamente el lugar de observación e integrarlo correctamente a la red gravimétrica nacional”, aclara Angélica Gutiérrez, ingeniera catastral y geodesta, profesional del área de gravimetría del IGAC.

La instalación de este punto no solo es competencia del IGAC y el Servicio Geológico Colombiano (SGC), también intervienen el [**Bureau Gravimétrique International**](https://bgi.obs-mip.fr/) (BGI) y el [**Institut de Recherche Pour le Développement**](https://www.ird.fr/) (IRD), ambos de origen francés. Y por eso, para la última medición, realizada en 2022, el gravímetro absoluto viajó directamente desde el IRD en Francia.

Existen dos tipos de gravímetros: relativos y absolutos. Los primeros miden la gravedad teniendo como referencia otro punto que ya fue medido previamente. De estos hay en Colombia y son los que usan entidades como el Agustín Codazzi o firmas de ingeniería para sus mediciones y exploraciones del terreno.

Los gravímetros absolutos son instrumentos especializados que miden el valor directo de la gravedad local en un punto específico de la superficie terrestre, sin necesidad de utilizar otro valor conocido como referencia. Estos equipos utilizan técnicas avanzadas como la interferometría láser y mediciones de tiempo con relojes atómicos, lo que permite obtener mediciones muy precisas. El principal desafío con los gravímetros absolutos, aclara el subdirector de Cartografía y Geodesia del IGAC, es que son “muy especializados, escasos y costosos, por esa razón el IGAC ha realizado un esfuerzo por conformar alianzas estratégicas con instituciones internacionales que cuentan con estos equipos, que los facilitaron para realizar las mediciones requeridas en el punto MEDE-01 ubicado en EAFIT”.

[![Image 31](https://universidadeafit.widen.net/content/e226e133-95ad-483a-8544-130010b3cefb/web/Gravimetro-absoluto.jpg)](https://www.eafit.edu.co/taxonomy/term/2626)

![Image 32](https://www.eafit.edu.co/taxonomy/term/2626)

La imagen corresponde a la medición de la gravedad absoluta del vértice MEDE-01 en 2022, realizada entre Instituto Geográfico Agustín Codazzi (IGAC) – Servicio Geológico Colombiano (SGC) _Bureau Gravimetrique International_(BGI) y el _Institut de Recherche Pour le Développement_ (IRD).

###### La utilidad de la medición de la gravedad

El valor de gravedad absoluta obtenido en el vértice MEDE-01 es de 977 741,0917 mGal, obtenido con una precisión instrumental de ± 0,01080 mGal. Pasando de los números y cifras a palabras entendibles por personas del común, este número indica qué tan fuerte es la gravedad en este lugar y su utilidad real aparece cuando se compara con otros vértices cercanos o con un modelo de referencia. Así lo expresa la geodesta Angélica Gutiérrez: “a partir de esas comparaciones es posible identificar variaciones del campo gravitacional que sí pueden asociarse a cambios de distribución de masas del subsuelo, diferencias topográficas o efectos geológicos regionales”.

Con respecto a los números asociados a la precisión, la ingeniera catastral y geodesta Paula Galeano, también del área de gravimetría del IGAC, complementa diciendo que “la precisión ± 0,01080 mGal significa que la medición es altamente confiable y que el valor real de la gravedad en el vértice se encuentra dentro de ese rango, lo que garantiza la calidad del dato para análisis posteriores”.

Por eso, más que explicar el número, este dato se convierte en base fundamental para estudios gravimétricos, cuyo significado se fortalece al analizarlo en conjunto con otros puntos de la red.

Aunque las variaciones de la gravedad pueden ser imperceptibles para las personas, sí son relevantes para la ciencia, “porque pequeños cambios en la gravedad nos hablan de la densidad en el subsuelo. Entonces es importante en la construcción. También utilizamos pequeñas variaciones en la gravedad para encontrar recursos en el subsuelo como depósitos de minerales, hidrocarburos o gases. Estas anomalías en la gravedad se detectan gracias a los puntos de gravedad, porque si bien se mide en el sitio se tiene que comparar con un punto de referencia”, explica el profesor David Santiago Avellaneda.

Conocer la gravedad absoluta es útil para determinar la forma de la tierra, pero también tiene aplicaciones en cartografía, calibración de sistemas satelitales, análisis geodinámicos, sismos tectónicos, ingeniería civil, catastro y determinación de alturas físicas. En general, cualquier actividad humana que requiera conocer, utilizar o comunicar una ubicación precisa en el espacio, necesita un marco de referencia confiable y estandarizado, el cual es provisto por puntos de referencia geodésicos, como el que está ubicado en Medellín, exactamente en el Bloque 18 de EAFIT, al interior de la Librería Acentos.

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Especiales](https://www.eafit.edu.co/taxonomy/term/1891)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [El 86 % de los grupos de investigación de EAFIT está en las máximas categorías de Minciencias](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/el-86-de-los-grupos-de-investigacion-de-eafit-esta-en-las)

Febrero 3, 2026

**En la más reciente Convocatoria Nacional para el Reconocimiento y Medición de Grupos de Investigación e Investigadores, el 69 % de los grupos de investigación de EAFIT quedaron clasificados en la máxima categoría A1 y el 17 % en la A.**

**En total, el 86 % de los grupos se ubican en las máximas categorías, un crecimiento frente al 74 % registrado en 2021. En esta medición, además, el porcentaje de profesores investigadores eafitenses en categorías Senior y Asociado pasó del 24 % al 31 %.**

*   [Lee más sobre El 86 % de los grupos de investigación de EAFIT está en las máximas categorías de Minciencias](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/el-86-de-los-grupos-de-investigacion-de-eafit-esta-en-las "El 86 % de los grupos de investigación de EAFIT está en las máximas categorías de Minciencias")

EAFIT consolidó su liderazgo en investigación tras los resultados de la Convocatoria Nacional de Minciencias 2024 para el reconocimiento y medición de Grupos de Investigación y para el reconocimiento de investigadores del Sistema Nacional de Ciencia, Tecnología e Innovación, que se conocieron a finales de 2025. Actualmente, la Universidad tiene 29 grupos de investigación, y el 86 % se ubica en las categorías A1 y A, un crecimiento 12 puntos frente al 74 % registrado en 2021.

En cuanto a investigadores, los resultados también reflejan un fortalecimiento de las trayectorias de los eafitenses. En esta medición, de los 347 profesores de planta activos, 102 ascendieron de categoría y 217 se mantuvieron. En comparación con la medición anterior, del año 2021, el porcentaje de profesores investigadores en categorías Senior y Asociado pasó del 24 % al 31 %, consolidando capacidades de alto nivel y liderazgo académico en la institución.

Estos logros fueron destacados, este 2 de febrero, durante el evento de Reconocimiento a la excelencia en CTeI, un espacio institucional en el que la Universidad celebró los esfuerzos individuales y colectivos alcanzados en el marco de la convocatoria de Minciencias. El encuentro se convirtió en un momento de reflexión sobre el papel de la investigación en la Universidad y su contribución al desarrollo del país.

En su intervención, Antonio Julio Copete Villa, vicerrector de Ciencia, Tecnología e Innovación de EAFIT, resaltó el valor institucional de estos reconocimientos: “Estos resultados evidencian el desempeño a lo largo de muchos años y décadas de trabajo. No son producto de un solo artículo o de una clase, sino el resultado de la suma de una cantidad de producción intelectual que el país reconoce y que nosotros, como Universidad, honramos”.

Durante la jornada, se resaltó al ecosistema de CTeI de la Universidad como un sistema vivo, dinámico y colectivo, en el que los grupos de investigación y sus integrantes son su fuerza esencial. Desde el rigor académico, la curiosidad intelectual y el compromiso ético, la investigación que se desarrolla en la Universidad dialoga con la sociedad y responde a los desafíos actuales.

Por su parte, César Tamayo Tobón, decano de la Escuela de Finanzas, Economía y Gobierno, subrayó el carácter procesual y colectivo de la investigación: “Hacer ciencia y creación puede ser un camino solitario e ingrato en un país como el nuestro. Por eso, nuestra solución es crear una comunidad científica como esta, que nos haga sentir menos solos y que celebre esa tenacidad y la construcción de comunidad”.

###### La CTeI en EAFIT: un eje de crecimiento

Desde la Dirección de Investigación de EAFIT, Ricardo Mejía Gutiérrez, enfatizó el posicionamiento de la Universidad en el contexto nacional. “Realmente hoy tenemos un gran portafolio de proyectos. Hemos ido creciendo, y esos impactos son los que hoy EAFIT puede proclamar que está consolidando y llevando al siguiente nivel. Somos la cuarta universidad en número de patentes y la primera en patentes per cápita en Colombia, gracias al trabajo de los investigadores. Además, la producción científica de alto nivel sigue creciendo”.

El directivo explicó que este crecimiento responde a una visión ampliada de la Ciencia, la Tecnología y la Innovación, en la que la investigación se articula con la formación, la transferencia y el impacto en el entorno. “La CTeI cobra sentido cuando el conocimiento se prepara para ser utilizado y transformar realidades, más allá del paper”, afirmó.

Desde la experiencia de los grupos de investigación, Mariantonia Lemos Hoyos, profesora de la Escuela de Artes y Humanidades de EAFIT y coordinadora del grupo Estudios en Psicología y Cambio Social, destacó el significado de los logros alcanzados y del trabajo sostenido en el tiempo. “El ascenso del grupo a A1 es un reconocimiento al trabajo en equipo y a la construcción de comunidades de investigación con estudiantes de pregrado y posgrado, que precisamente nos permite hacer puentes, no solo al interior del grupo, sino también con otras entidades”.

Con este evento, EAFIT reafirmó su compromiso con la investigación como eje estratégico de su proyecto educativo. Celebrar los resultados de la medición de Minciencias fue también una forma de reconocer trayectorias, fortalecer comunidad académica y proyectar el conocimiento como motor de transformación social y desarrollo sostenible.

Imagen Noticia EAFIT

![Image 33: En la más reciente Convocatoria Nacional para el Reconocimiento y Medición de Grupos de Investigación e Investigadores, el 69 % de los grupos de investigación de EAFIT quedaron clasificados en la máxima categoría A1 y el 17 % en la A.](https://universidadeafit.widen.net/content/22efee18-597d-4ecf-b9bf-2a1025171cd4/web/Reconocimiento-investigadores.jpg)

Leyenda de la imagen

El evento de Reconocimiento a la excelencia en CTeI resaltó el trabajo colectivo y el rigor investigativo de EAFIT.

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Nuestra comunidad de talento](https://www.eafit.edu.co/taxonomy/term/1881)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Estos son los dos nuevos habitantes de la Biblioteca Digital de Científicos Antioqueños](https://www.eafit.edu.co/noticias/nuestro-impacto/estos-son-los-dos-nuevos-habitantes-de-la-biblioteca-digital-de)

Diciembre 9, 2025

**A este acervo documental llegaron recientemente el médico Francisco Lopera Restrepo, pionero en estudios sobre la enfermedad de Alzheimer, y el físico William Ponce Gutiérrez, referente en física teórica de la región.**

**Este catálogo, con registros de 19 científicos, es posible gracias al trabajo conjunto de las bibliotecas de EAFIT y la Universidad Nacional de Colombia sede Medellín, y la Academia Colombiana de Ciencias Exactas, Físicas y Naturales capítulo Antioquia.**

*   [Lee más sobre Estos son los dos nuevos habitantes de la Biblioteca Digital de Científicos Antioqueños](https://www.eafit.edu.co/noticias/nuestro-impacto/estos-son-los-dos-nuevos-habitantes-de-la-biblioteca-digital-de "Estos son los dos nuevos habitantes de la Biblioteca Digital de Científicos Antioqueños ")

Según los registros, este repositorio ha recibido visitas desde 100 ciudades en 57 países, lo cual evidencia el impacto de este catálogo. Conoce el repositorio [**aquí**](https://repositorio.accefyn.org.co/communities/79ba063c-bba3-473b-a48c-cb8f74c41101). La imagen corresponde a la presentación de los nuevos científicos del repositorio.

Medicina y Física; neurociencia y mecánica cuántica si se quiere mayor especificidad. Puede decirse que poco tiene que ver lo uno con lo otro, pero cuando se revisa el catálogo de científicos antioqueños se percibe una estrecha relación, pues el legado de los investigadores Francisco Lopera Restrepo y William Ponce Gutiérrez, el primero médico y el segundo físico, ya está disponible en este repositorio de producción científica local.

Recuperar el patrimonio intelectual científico de Antioquia y ponerlo al alcance del mundo es el propósito de la Biblioteca Digital de Científicos Antioqueños, que nació en 2011 como una iniciativa de Michell Hermelín Arbaux, en ese entonces profesor de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT, quien era integrante del capítulo Antioquia de la Academia de Ciencias Exactas, Físicas y Naturales de Colombia (Accefyn).

[El médico y neurocientífico Francisco Lopera](https://repositorio.accefyn.org.co/communities/677a63f6-14c8-4680-b1ab-f711659f0eed), quien falleció en 2024, fue reconocido mundialmente por sus investigaciones sobre el Alzheimer, aportando avances para la comprensión y tratamiento de esta enfermedad. El físico [William Ponce Gutiérrez](https://repositorio.accefyn.org.co/communities/79ba063c-bba3-473b-a48c-cb8f74c41101?spc.page=1&f.author=Ponce,%20William%20A.,equals), además de haber sido pionero en la consolidación de la maestría y el doctorado en física de la Universidad de Antioquia, ha sido reconocido por su trabajo en física teórica y de partículas.

El proceso de selección de las obras ha pasado por la curaduría de académicos o personas que hayan tenido relación con el investigador, de manera que puedan entregar una recopilación completa de las obras y, en algunos casos, una semblanza. El material bibliográfico de ambos ya está disponible en el repositorio del catálogo.

Para la selección de los científicos que ingresan al catálogo se tienen en cuenta algunos criterios académicos que tienen que ver con el aporte que cada uno de los candidatos ha hecho al conocimiento desde su área de desempeño, “pero también al desarrollo de la ciencia en Medellín y Antioquia en términos de aportes a programas académicos, formación de talento humano, desarrollos de infraestructura para la investigación, entre otras cosas”, precisa Román Castañeda Sepúlveda, profesor de la Universidad Nacional y coordinador del componente académico de la Biblioteca Digital de Científicos Antioqueños.

###### La Biblioteca

La articulación para crear este repositorio se formalizó mediante un convenio suscrito entre Accefyn, la Universidad Nacional de Colombia Sede Medellín y la Universidad EAFIT, en el marco del programa Antioquia 200 años. Una de las motivaciones era poner al servicio de la comunidad obras escasas o de difícil acceso, de científicos antioqueños o extranjeros que hubieran desarrollado su carrera en la región.

Según lo explica Patricia Ospina Ospina, jefa del Centro Cultural Biblioteca Luis Echavarría Villegas de EAFIT, “la Biblioteca Digital de Científicos Antioqueños se está consolidando como un espacio relevante que conecta el legado intelectual de la región con las nuevas generaciones de investigadores. Su existencia como recurso abierto facilita el acceso de investigadores, estudiantes y público general a obras de la ciencia en Antioquia”.

Un trabajo colaborativo como este demuestra cómo diferentes actores pueden colaborar para rescatar y difundir la memoria científica, “también sirve para fortalecer la identidad regional, pues pone en valor la ciencia antioqueña y ayuda a consolidar una identidad local en torno al conocimiento científico”, explica Sonia María Valencia Grajales, jefa de División de Bibliotecas de la Universidad Nacional de Colombia sede Medellín.

[El repositorio](https://repositorio.accefyn.org.co/communities/79ba063c-bba3-473b-a48c-cb8f74c41101), alojado en la biblioteca Luis López de Mesa de la Academia Colombiana de Ciencias Exactas, Físicas y Naturales, tiene a su vez micrositios dedicados a cada uno de los científicos seleccionados, donde los interesados pueden acceder a su obra completa, así como a semblanzas y material complementario como fotografías, cartas y, en algunos casos, videos.

Para Santiago Zapata Restrepo, coordinador de la Sala de Patrimonio Documental de EAFIT, un proyecto de esta naturaleza, único en el contexto nacional, es relevante porque “aborda la conservación desde la unificación de esas obras representativas de científicos y autores que construyeron historia académica y científica de Antioquia. Como sala de patrimonio documental, nos da un rasgo de identidad en ese quehacer de la conservación patrimonial y se materializa esa convicción de que el conocimiento siga circulando y que sea factible la apropiación de las futuras generaciones”.

Con la más reciente inclusión, el catálogo cuenta con un acervo documental de más de 2.200 registros, correspondientes a 16 autores antioqueños y tres extranjeros, que han realizado su labor científica en la región. Se trata de un repositorio libre y gratuito al que pueden acceder usuarios de todo el mundo.

Es cierto que esta biblioteca es un repositorio documental, pero también es un lugar de protección del patrimonio intelectual colombiano que permite preservar y proyectar al mundo la memoria de quienes sentaron las bases del desarrollo científico del país. Es también una manera de democratizar el conocimiento a través de los años. Un antídoto para evitar el olvido de estos sabios.

Imagen Noticia EAFIT

![Image 34: Según los registros, este repositorio ha recibido visitas desde 100 ciudades en 57 países, lo cual evidencia el impacto de este catálogo. Conoce el repositorio aquí.  La imagen corresponde a la presentación de los nuevos científicos del repositorio.](https://universidadeafit.widen.net/content/3e687092-b9f3-4dee-9b7b-7a09b9541a61/web/Biblioteca-Digital.jpg)

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Nuestro impacto](https://www.eafit.edu.co/taxonomy/term/1886)

Bloque para noticias recomendadas

## [Hermanas del Páramo, un documental producido por EAFIT que aborda conflictos ambientales alrededor del agua](https://www.eafit.edu.co/noticias/especiales/hermanas-del-paramo-un-documental-producido-por-eafit-que-aborda-conflictos)

Diciembre 2, 2025

**Este contenido audiovisual es parte de la estrategia de divulgación de la investigación**_**Megaproyectos hídricos en Colombia y su impacto en la planificación urbana y la sostenibilidad ambiental**_**, realizado desde la Escuela de Derecho. El video revela tensiones entre derechos de propiedad y protección del agua en zonas de páramo.**

[**Conversamos con Irene Agudelo Saldarriaga**](https://youtu.be/Ek66sGUiBQk)**, estudiante de la maestría en Estudios Jurídicos y asistente de investigación del proyecto, sobre la relevancia de aplicar un caso real a la teoría, y la importancia de realizar divulgación a otros públicos diferentes del académico, en este caso, a través de un**[**producto audiovisual**](https://www.youtube.com/watch?v=j95wbNQIPD8)**.**

*   [Lee más sobre Hermanas del Páramo, un documental producido por EAFIT que aborda conflictos ambientales alrededor del agua](https://www.eafit.edu.co/noticias/especiales/hermanas-del-paramo-un-documental-producido-por-eafit-que-aborda-conflictos "Hermanas del Páramo, un documental producido por EAFIT que aborda conflictos ambientales alrededor del agua")

El Video documental Hermanas del páramo es desarrollado en el marco de la expansión transmedia de la Revista Universidad EAFIT [**Descubre y Crea Vol. 58 No. 179**](https://repository.eafit.edu.co/collections/d1f713fc-fe5a-421d-893c-eafeb847f858) (2024).

_El espacio de los megaproyectos de infraestructura hídrica en Colombia_ es un proyecto de investigación que se adelanta desde la Escuela de Derecho de EAFIT. Es liderado por la profesora Nataly Montoya Restrepo y le asiste Irene Agudelo Saldarriaga, estudiante de la [maestría en Estudios Jurídicos](https://www.eafit.edu.co/posgrados/escuela-derecho/maestria-estudios-juridicos).

Según la profesora Nataly, “una de las cosas que se ha encontrado en esta investigación, es que uno de los factores críticos para la planificación y ordenamiento de las ciudades es la disponibilidad de agua para la satisfacción de necesidades básicas”.

Paralelo a esto, un grupo de hermanas del municipio de Belmira, norte de Antioquia, adelantaban un proceso legal sobre la propiedad y el uso de unos terrenos de su herencia, ubicados en zona de protección ambiental del páramo de Belmira.

Cuando este caso llega a oídos de la profesora Nataly, a la teoría se le suma la realidad, pues en el contexto de esta investigación, “se inicia un trabajo articulado junto al semillero de investigación de Estudios Territoriales y es así como a la investigación se le da una metodología de caso de estudio”, explica Irene.

Por eso el caso de las _Hermanas del Páramo_ sirve para analizar la paradójica situación de muchos páramos del país pues parece haber un conflicto entre los derechos y necesidades de los seres humanos y el cuidado del agua desde el punto de vista de la sostenibilidad ambiental.

La investigación, que todavía está el proceso, tiene como uno de sus productos divulgativos un [video documental](https://www.youtube.com/watch?v=j95wbNQIPD8) en el que se analiza la situación desde el punto de vista jurídico, ecosistémico-biológico, hidrológico e ingenieril y se plantean preguntas hacia la resolución del caso y otros futuros conflictos ambientales alrededor del agua en Colombia. Es, además, “una manera de descentralizar el saber, que suele quedarse en los anaqueles a los que solo acceden los académicos”, reflexiona Irene.

Imagen Noticia EAFIT

![Image 35: El Video documental Hermanas del páramo es desarrollado en el marco de la expansión transmedia de la Revista Universidad EAFIT Descubre y Crea Vol. 58 No. 179  (2024).](https://universidadeafit.widen.net/content/4e69fa72-9429-416f-82a5-f3acaad24ab6/web/Hermanas-paramo.jpg)

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Especiales](https://www.eafit.edu.co/taxonomy/term/1891)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Acción EAFIT celebra el poder transformador de la ciencia en comunidad](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/accion-eafit-celebra-el-poder-transformador-de-la-ciencia-en-comunidad)

Agosto 25, 2025

**El 27 y 28 de agosto se realizará Acción EAFIT, un evento en el que la comunidad académica y el público general podrán conocer proyectos de investigación, alianzas estratégicas y experiencias que fortalecen la cultura científica y conectan el conocimiento con la sociedad.**

**En esta edición se socializará la nueva política institucional de CTeI, se realizará la feria Universo Semilleros y se presentará la edición No. 180 de la Revista Descubre y Crea, cuyo tema central es el tiempo. La programación completa se puede consultar en este**[**enlace**](https://www.eafit.edu.co/institucional/pei/accion-eafit)**.**

*   [Lee más sobre Acción EAFIT celebra el poder transformador de la ciencia en comunidad](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/accion-eafit-celebra-el-poder-transformador-de-la-ciencia-en-comunidad "Acción EAFIT celebra el poder transformador de la ciencia en comunidad")

En EAFIT la ciencia es una experiencia viva que conecta con las personas, los territorios y las realidades del país. Cada semestre, esa convicción se materializa en Acción EAFIT, un evento que se convierte en una celebración del conocimiento y de las múltiples conexiones que lo hacen posible. Este miércoles 27 y jueves 28 de agosto, la Universidad abrirá sus puertas para que estudiantes, investigadores, empresas, entidades gubernamentales y la ciudadanía se encuentren alrededor de la ciencia, la tecnología y la innovación (CTeI).

“Es importante tener estos espacios en los que enfoquemos la mirada para entender y admirar los avances que hemos tenido como Universidad alrededor de estos temas, enterarnos de todo lo que hacemos en las diferentes escuelas, los grupos y las líneas de investigación, porque definitivamente somos un universo amplio”, afirma Antonio Julio Copete Villa, vicerrector de Ciencia, Tecnología e Innovación de EAFIT.

Por su parte, Catalina López Otálvaro, jefa de Apropiación Social del Conocimiento y Divulgación de la misma vicerrectoría, destaca que Acción EAFIT se vincula estrechamente con el Proyecto Educativo Institucional (PEI), en el que la ciencia, la tecnología y la innovación se reconocen como un eje misional.

“Este evento visibiliza cómo la comunidad académica y sus aliados transforman la realidad a través de la investigación, la creación y la innovación. Además, fortalece la cultura científica institucional y fomenta el diálogo con la sociedad, en coherencia con la visión de una universidad abierta, conectada y comprometida con los grandes desafíos de nuestro tiempo”, dice Catalina.

###### Dos días de arte, ciencia y conocimiento

Uno de los momentos centrales de esta edición será la socialización de la política institucional de CTeI, un instrumento que orienta la investigación, el desarrollo tecnológico y la innovación en la Universidad. Esta política será presentada el miércoles 27 de agosto a las 9:00 a.m. Enel hall del bloque 20 (_Zona Descubre_), en una conversación con María Eugenia Puerta, profesora de la Escuela de Ciencias Aplicadas e Ingeniería; Ricardo Mejía Gutiérrez, director de Investigación; y Esteban Hoyos Ceballos, decano de la Escuela de Derecho, bajo la moderación del vicerrector Antonio Julio Copete.

Ese mismo día, a las 11:00 a.m. en la Zona Descubre, se realizará la presentación de la Revista Universidad EAFIT #DescubreyCrea, que en su edición 180 reflexiona sobre el concepto del tiempo. La actividad incluirá un concierto y una charla.

La programación de Acción EAFIT también contará con la feria Universo Semilleros, presente ambos días del evento en la plazoleta del Bloque 20 (Zona Wow). Este espacio reunirá a estudiantes de pregrado vinculados a semilleros de investigación, participantes de la Universidad de los Niños, integrantes de los Centros de Interés en CTeI y jóvenes investigadores, quienes compartirán los avances de sus proyectos.

Asimismo, el evento ofrecerá talleres, paneles y conversaciones con aliados de diferentes regiones del país. Entre los invitados estarán representantes de la Alcaldía de Medellín, el Ministerio de Ciencia, Tecnología e Innovación y el Ministerio de Educación Nacional, junto con empresas como SOFASA e ISA, que mantienen vínculos estratégicos con EAFIT.

Entre las actividades se destaca _Renault Kwid: todo tiene su ciencia_, una conversación sobre ciencia, tecnología e innovación en el marco del convenio EAFIT–SOFASA, que tendrá lugar en la Zona Descubre el miércoles 27 de agosto a las 4:30 p.m.

“Acción EAFIT es una gran fiesta de la ciencia; es un evento para fortalecer e incentivar la cultura científica, y para ver que la ciencia y el conocimiento están en todo”, afirma Ana María González Cotes, coordinadora de Cultura y Proyección de la Apropiación Social del Conocimiento, quien destaca el lanzamiento del documental _Anfibios y reptiles de Bahía Solano_, desarrollado por investigadores de la Universidad, el jueves 28 de agosto a las 6:00 p.m. en la Zona Descubre.

En suma, Acción EAFIT reafirma la visión de que la ciencia y la innovación son procesos colectivos, construidos en comunidad y en permanente diálogo con múltiples actores. La Universidad dispone este espacio para reconocer que el conocimiento compartido es la base para transformar realidades, proyectar futuros sostenibles y reafirmar que EAFIT es escenario de creación y reflexión.

Imagen Noticia EAFIT

![Image 36: La agenda de Acción EAFIT es abierta y gratuita. La mayoría de las actividades se realizarán en el hall del bloque 20 de la Universidad. La imagen corresponde a una edición anterior de este encuentro.](https://universidadeafit.widen.net/content/ebd016fe-effa-4c14-965e-05e51cf9342e/web/Accin-EAFIT.jpg)

Leyenda de la imagen

La agenda de Acción EAFIT es abierta y gratuita. La mayoría de las actividades se realizarán en el hall del bloque 20 de la Universidad. La imagen corresponde a una edición anterior de este encuentro.

Categoría de noticias EAFIT

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

#### Paginación

*    Página 1 
*   [Siguiente página››](https://www.eafit.edu.co/taxonomy/term/2626?page=1 "Ir a la página siguiente")

[Suscribirse a Investigación](https://www.eafit.edu.co/taxonomy/term/2626/feed)

![Image 37: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 38: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 39: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 40: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 41: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 42: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 43: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 44: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 45](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
