Title: Editorial

URL Source: https://www.eafit.edu.co/editorial

Markdown Content:
# Editorial
[Pasar al contenido principal](https://www.eafit.edu.co/editorial#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/editorial#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/editorial# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/editorial# "English")

 Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 8: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 9: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 10: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 11: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 12: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 14: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 15: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 16: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 17: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 18: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 19: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 20: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 21: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 22: Imagen de banner whatsapp](https://universidadeafit.widen.net/content/5e87235e-a1b9-4b3d-8a7e-ea2ea31c0ce4/web/banner-principal-editorial.jpg?crop=yes&k=c&w=1920&h=788&itok=taEjqp9d)

# Editorial

[Inscríbete a la comunidad de lectores](https://linktr.ee/editorialeafit)

*   [Inicio](https://www.eafit.edu.co/)
*    Editorial 

###### La Editorial EAFIT publica proyectos editoriales en las distintas áreas del saber y la cultura. Evalúa, asesora, edita, promociona y comercializa obras inéditas, tanto de autores de la comunidad universitaria propia como externos. Por medio de libros representa el proyecto científico, académico y cultural eafitense.

## Novedades

## Liturgia de los bosques

Del ganador del premio León de Greiff, Darío Jaramillo, es una colección de poemas que explora la relación entre la naturaleza, la memoria y la vida interior.

[Ver más](https://editorial.eafit.edu.co/index.php/editorial/es/catalog/book/760)

![Image 23: Imagen Liturgia de los bosques](https://universidadeafit.widen.net/content/b6d9f3ee-23b7-4681-b3d5-5c2e9d00c168/web/libro-liturgia-de-los-bosques-v2.png?crop=yes&k=c&w=463&h=450&itok=a1qtK66C)

## La confianza cotidiana

Un libro que explora la confianza como un tejido invisible que sostiene la vida en común, cuestionando su fragilidad en contextos de incertidumbre y proponiendo nuevas formas de entender su papel en la acción colectiva y la vida democrática.

[Ver más](https://editorial.eafit.edu.co/index.php/editorial/catalog/book/748)

![Image 24: Imagen La confianza cotidiana](https://universidadeafit.widen.net/content/35975e42-5884-468f-a579-0375fe8f4273/web/la-confianza-cotidiana-novedades-editorial.png?crop=yes&k=c&w=463&h=450&itok=KPPSbe-Q)

## Iusnaturalezas

Un libro que propone reconocer la naturaleza como sujeto jurídico, cuestionando las bases del derecho ambiental y replanteando la relación entre lo humano y lo natural.

[Ver más](https://editorial.eafit.edu.co/index.php/editorial/es/catalog/book/761)

![Image 25: Imagen Iusnaturalezas](https://universidadeafit.widen.net/content/e2c568f8-a2aa-42e0-875b-7d08c7b5efce/web/libro-luznaturalezas-editorial-v2.png?crop=yes&k=c&w=463&h=450&itok=LlQc6hDD)

[Conoce nuestro catálogo](https://editorial.eafit.edu.co/)

### Colecciones de la Editorial

[Colección Académica](https://www.eafit.edu.co/editorial#230548828-3131241407)

Esta colección tiene como propósito alojar la producción intelectual e investigativa de la comunidad interna y externa de la Universidad EAFIT en las diferentes áreas del conocimiento. Reúne libros resultado de investigación, investigación-creación y divulgación pública de la ciencia.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colacademica%20)

![Image 26: Imagen ](https://universidadeafit.widen.net/content/50aa092b-6e09-4d1a-97a0-f9e13ed6b1df/web/academica-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=soRi09EP)

[Colección Letra x Letra](https://www.eafit.edu.co/editorial#230548828-3072176741)

Esta colección tiene como propósito alojar creaciones literarias de todos los géneros narrativos de autores nacionales, emergentes y consolidados. Reúne libros de cuentos, novelas, relatos, y traducciones, entre otros.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/letraxletra%20)

![Image 27: Imagen ](https://universidadeafit.widen.net/content/e689515d-76d3-4557-a667-2e58e845738c/web/letraxletra-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=unrOTgZZ)

[Colección EAFIT-Tirant](https://www.eafit.edu.co/editorial#230548828-4166952457)

Esta colección, editada en conjunto con Tirant lo Blanch, tiene como propósito la publicación de libros de Derecho.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/ColEAFITTirant%20)

![Image 28: Imagen ](https://universidadeafit.widen.net/content/5b599687-4437-4d8d-a72e-4ae92057424c/web/eafit-tirant-lo-blanch-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=9Ww_T9Nn)

[Colección Tuerca Devuelta](https://www.eafit.edu.co/editorial#230548828-443048135)

Esta colección da una vuelta de tuerca a trabajos académicos y científicos para divulgarlos en la forma de aventuras literarias. Su propósito es acercar a públicos infantiles y juveniles al hábito de las preguntas, las exploraciones y la lectura.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/coltuercadev%20)

![Image 29: Imagen ](https://universidadeafit.widen.net/content/b9cd0291-05e8-4b1d-9253-6876fb3cf862/web/tuerca-devuelta-colecciones-editorial-eafit.jpg.jpg?crop=yes&k=c&w=463&h=450&itok=g4J8o7sz)

[Biblioteca Fernando González](https://www.eafit.edu.co/editorial#230548828-23276099)

Esta colección es fruto de la asociación entre la Editorial EAFIT y la Corporación Otraparte. Tiene como propósito preservar la obra del escritor y filósofo antioqueño Fernando González Ochoa. Reúne su obra en libros con aspecto de libretas de apuntes, como las que solía usar González.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colfernandogonzalez)

[Biblioteca Gonzalo Arango](https://www.eafit.edu.co/editorial#230548828-1125020393)

Esta colección es fruto de la asociación entre la Editorial EAFIT y la Corporación Otraparte. Tiene como propósito preservar la obra del escritor y fundador del movimiento nadaísta Gonzalo Arango Arias. Reúne su producción artística en libros de ensayos, poesía en prosa, manifiestos, entre otros.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colgonzaloarango%20)

![Image 30: Imagen ](https://universidadeafit.widen.net/content/1423f520-f0b4-4193-a5ba-8e41b24b7a7f/web/gonzalo-arango-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=OJjwT7Uj)

[Biblioteca Rocío Vélez de Piedrahíta](https://www.eafit.edu.co/editorial#230548828-600843878)

Esta colección tiene como propósito preservar y revitalizar la obra de la escritora y académica Rocío Vélez de Piedrahíta, seleccionada por el periódico El Colombiano como una de las personas más influyentes del siglo XX en Colombia. Reúne su producción artística en libros de cuentos y novelas.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colrociovelez)

![Image 31: Imagen ](https://universidadeafit.widen.net/content/2ae3b07f-94ba-43b8-87ff-495f64a724e5/web/rocio-velez-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=sjqpQ4uX)

[Biblioteca Jorge Alberto Naranjo](https://www.eafit.edu.co/editorial#230548828-3053468131)

Tiene como propósito preservar el legado del escritor, matemático, físico, sociólogo, historiador e ingeniero hidráulico Jorge Alberto Naranjo. Reúne su producción intelectual en libros de ensayos, poesía en prosa, manifiestos, entre otros. Esta colección invita a otras universidades, donde el profesor tuvo participación, a coeditar su obra.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/coljorgenaranjo%20)

![Image 32: Imagen ](https://universidadeafit.widen.net/content/2d6effc2-a925-499c-b4d1-8c62fbcde98b/web/jorge-naranjo-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=qZoNcTXJ)

[Colección Biblioteca Mario Escobar Velásquez](https://www.eafit.edu.co/editorial#230548828-1697433923)

Esta colección es fruto de la asociación entre la Editorial EAFIT y la Fundación Mario Escobar Velásquez. Permite la participación de otras editoriales y entidades, como ha ocurrido con Sílaba, Hilo de plata y la Biblioteca Pública Piloto. Su propósito es preservar y difundir la obra del cuentista y novelista Mario Escobar Velásquez. Reúne su producción artística en libros de cuentos y novelas.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colmarioescobar)

![Image 33: Imagen ](https://universidadeafit.widen.net/content/3956be04-725d-4d59-9da8-075c7e966df9/web/mario-escobar-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=aY0wygs6)

[Colección La Flecha](https://www.eafit.edu.co/editorial#230548828-3499338580)

Esta colección nació bajó el componente editorial de la Alianza 4U. Reúne publicaciones de índole literaria coeditadas entre EAFIT, CESA, ICESI y UNINORTE.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/ColLaFlecha%20)

![Image 34: Imagen ](https://universidadeafit.widen.net/content/10e26301-6894-4707-84bb-6e6dd7b2e299/web/alianza-4u-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=1cRfaeEU)

[Colección Cuadernos Z](https://www.eafit.edu.co/editorial#230548828-724864716)

Esta colección tiene como propósito alojar libros que sirvan de apoyo a los procesos de aprendizaje, tanto de los miembros de la comunidad eafitense como del resto de la sociedad. Reúne los resultados de actividades de apropiación social del conocimiento, como guías, manuales y talleres. La mayoría está disponible en acceso libre en su versión digital.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colcuadernosz)

![Image 35: Imagen ](https://universidadeafit.widen.net/content/237897bc-ea92-4811-9d1c-f3106fda1243/web/cuadernos-z-colecciones-editorial-eafit.jpg.jpg?crop=yes&k=c&w=463&h=450&itok=a4B_82VR)

[Colección Dos Tintas](https://www.eafit.edu.co/editorial#230548828-2863612016)

Esta colección tiene como propósito extender a los estudiantes y docentes de posgrado de la Universidad EAFIT la posibilidad de aprender de procesos de publicación científica e iniciar su trayectoria en la escritura académica. Reúne las mejores producciones académicas desarrolladas en clase, tales como reflexiones interdisciplinarias, libros de ensayos, revisiones históricas, entre otros.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/coldostintas%20)

![Image 36: Imagen ](https://universidadeafit.widen.net/content/8416acf5-55b0-496a-bb47-020b02c9050f/web/dos-tintas-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=OEfpgz2J)

[Colección Bicentenario de Antioquia](https://www.eafit.edu.co/editorial#230548828-2771335552)

Esta colección es fruto de la asociación entre la Universidad EAFIT y nueve universidades más de Medellín. Surgió con el propósito de celebrar los doscientos años de la independencia del departamento de Antioquia. Reúne una serie de textos donde se fija la memoria colectiva de la sociedad antioqueña. La mayoría está disponible en acceso abierto.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/bicentenarioantioquia%20)

![Image 37: Imagen ](https://universidadeafit.widen.net/content/87a4508c-8f82-4680-a144-d741797df432/web/bicentenario-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=xxWp3VEh)

[Colección Debajo de las Estrellas](https://www.eafit.edu.co/editorial#230548828-3961829528)

Esta colección surgió con el propósito de destacar las mejores producciones de la tradición cuentística del país. Reúne libros de cuentos de autores nacionales, ya editados o publicados, con reconocido valor literario.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/coldebajoestrellas%20)

[Colección Libellus](https://www.eafit.edu.co/editorial#230548828-4293596391)

Esta colección reúne libros que oscilan entre la argumentación y el ensayo literario, en la que los autores abordan temas importantes para la sociedad con un alto grado de libertad creativa.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/collibellus)

![Image 38: Imagen ](https://universidadeafit.widen.net/content/81d5f6c1-c02e-4d6a-be80-c7f3646d175d/web/libellus-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=dNOV17nY)

[Colección Nodum](https://www.eafit.edu.co/editorial#230548828-1562827837)

Esta colección tiene como propósito alojar obras enfocadas en temas, investigaciones o discusiones en torno a las ciencias de la salud, como la psicología. Reúne libros resultados de investigación, contribuciones históricas, reflexiones, entre otros.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colnodum%20)

[Colección Otramina](https://www.eafit.edu.co/editorial#230548828-460842945)

Esta colección, curada por el poeta Darío Jaramillo, tiene como propósito preservar y exponer creaciones representativas de la poesía iberoamericana. Reúne libros de poemas en prosa y verso.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colotramina%20)

![Image 39: Imagen ](https://universidadeafit.widen.net/content/e1fa5512-f89f-4e65-9a12-90c99b269644/web/otramina-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=Mi6zsCMm)

[Colección Premio León de Greiff](https://www.eafit.edu.co/editorial#230548828-1319048937)

Esta colección, curada por el poeta Darío Jaramillo, tiene como propósito preservar y exponer creaciones representativas de la poesía iberoamericana. Reúne libros de poemas en prosa y verso.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/premioleondegreiff%2520%20)

![Image 40: Imagen ](https://universidadeafit.widen.net/content/6873bce6-47e3-4fb8-ab7b-723c0f81df2e/web/premio-leon-de-greiff-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=set7h0lb)

[Colección Rescates](https://www.eafit.edu.co/editorial#230548828-821622394)

Esta colección tiene como propósito rescatar obras inéditas o editadas que, a pesar de pertenecer al pasado, tienen pertinencia en la actualidad, ya que, de alguna manera, responden a necesidades o conversaciones contemporáneas. Reúne memorias de viajes, ensayos, textos epistolares, novelas, entre otros.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/colrescates%20)

![Image 41: Imagen ](https://universidadeafit.widen.net/content/3f1f6284-33c3-4940-8ca3-1739dbd81195/web/rescates-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=E6TUtfAs)

[Colección Testigos](https://www.eafit.edu.co/editorial#230548828-2936170882)

Esta colección tiene como propósito fijar la memoria colectiva de la sociedad en libros de no ficción y géneros periodísticos, tales como columnas de opinión, reportajes, crónicas y entrevistas.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/coltestigos%20)

![Image 42: Imagen ](https://universidadeafit.widen.net/content/261ca70c-2c32-47fe-ba76-e971d901185f/web/testigos-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=oPNwhZoV)

[Colección Ediciones Musicales](https://www.eafit.edu.co/editorial#230548828-3097573601)

Esta colección tiene como propósito alojar libros que sirvan de herramienta de estudio para miembros de la comunidad universitaria y artistas musicales externos. Reúne tres tipos de series: 

 Compositores colombianos: Obras originales, instrumentales, vocales, corales, de música sinfónica y ópera de nuestros más representativos compositores nacionales. 

 Rescates: Textos inéditos de artistas musicales fallecidos, que por alguna circunstancia dejaron de circular. 

 Didáctica: Piezas de carácter formativo para diversos instrumentos.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/coledmusicales%20)

![Image 43: Imagen ](https://universidadeafit.widen.net/content/ae3cd8a8-26b7-4235-a805-1df7c05b46bd/web/ediciones-%20musicales-colecciones-editorial-eafit.jpg?crop=yes&k=c&w=463&h=450&itok=VSQ-kj2Q)

[Colección Ediciones Universidad EAFIT](https://www.eafit.edu.co/editorial#230548828-3547111493)

Esta colección tiene como propósito reflejar los valores de la Universidad EAFIT, declarar su proyecto académico y cultural. Reúne una heterogénea mezcla de textos de diferentes géneros y temáticas.

[Ver colección completa](https://editorial.eafit.edu.co/index.php/editorial/catalog/series/edicioneseafit%20)

#### Galería

[![Image 44](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 45: editorial-2026-abril](https://universidadeafit.widen.net/content/c2efcc4a-949d-46c7-bba6-8aff7081b96e/web/editorial-abril-2026.png)

[![Image 46](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 47: editorial-2026-abril](https://universidadeafit.widen.net/content/aad79bcc-28a1-4ff4-955e-5ca81677ddca/web/editorial-abril-2026-2.png)

[![Image 48](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 49: editorial-2026-abril](https://universidadeafit.widen.net/content/5d572453-0893-4101-a20e-337aefac3c0d/web/editorial-abril-2026-3.png)

[![Image 50](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 51: editorial-2026-abril](https://universidadeafit.widen.net/content/ff2ed958-e76b-421b-aa7e-828f63fa45af/web/editorial-2026abril%20(4).png)

[![Image 52](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 53: editorial-2026-abril](https://universidadeafit.widen.net/content/593d718f-2071-4a17-b930-888213d94dbf/web/editorial-2026abril%20(5).png)

[![Image 54](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 55: editorial-2026-abril](https://universidadeafit.widen.net/content/80ec25af-cb06-4ce7-92b3-f7479aa1229d/web/editorial-abril-2026-4.png)

[![Image 56](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 57: editorial-2026-abril](https://universidadeafit.widen.net/content/080fabff-1c2a-4c79-8684-eee24f27d298/web/editorial-2026abril%20(7).png)

[![Image 58](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 59: editorial-2026-abril](https://universidadeafit.widen.net/content/daf88241-ee0f-4272-9437-323426d9e587/web/editorial-abril-2026-5.png)

[![Image 60](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 61: editorial-2026-abril](https://universidadeafit.widen.net/content/97aa3c13-0590-466f-8391-f49ed42ffa0b/web/editorial-2026abril%20(9).png)

[![Image 62](https://www.eafit.edu.co/editorial)](https://www.eafit.edu.co/editorial)

![Image 63: editorial-2026-abril](https://universidadeafit.widen.net/content/39fe9801-0a06-4943-8fd5-8b2fb6cbcbc2/web/editorial-abril-2026-6.png)

#### Darío Jaramillo Agudelo y cuatro momentos con el escritor León de Greiff

## Nuestras Redes Sociales

### Instagram / Cultura

[Síguenos](https://www.instagram.com/culturaeafit/)

### Instagram / Orquesta Sinfónica

[Síguenos](https://www.instagram.com/sinfonicaeafit/)

### Instagram / Editorial

[Síguenos](https://www.instagram.com/editorialeafit/)

### Facebook / Orquesta Sinfónica

[Síguenos](https://www.facebook.com/sinfonicaEAFIT)

### Facebook / Cultura

[Síguenos](https://www.facebook.com/eafitcultura)

### Facebook / Editorial

[Síguenos](https://www.facebook.com/editorialeafit)

### Youtube / Cultura

[Síguenos](https://www.youtube.com/@extensionculturaleafit4523)

### Youtube / Orquesta Sinfónica

[Síguenos](https://www.youtube.com/@sinfonicaEAFIT)

Contacto 

¿Quieres saber más?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono de contacto*? 

Correo electrónico*? 

Ciudad de residencia*? 

Contenido de interés 

Cuéntanos, ¿Qué deseas saber?*? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 64](https://universidadeafit.widen.net/content/108982d4-7997-4ddd-94ef-8fc522c963a4/web/Campus-Biblioteca-2.jpg?crop=yes&k=c&w=470&h=272&itok=FDZTQMNF)

![Image 65: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 66: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 67: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 68: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 69: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 70: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 71: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 72: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 73](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
