Title: Renewal of institutional accreditation

URL Source: https://www.eafit.edu.co/en/institucional/acreditacion

Markdown Content:
# Institutional Accreditation | EAFIT University (English)
[Skip to main content](https://www.eafit.edu.co/en/institucional/acreditacion#main-content)

[![Image 1: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/institucional/acreditacion#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/institucional/acreditacion# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/en/institucional/acreditacion# "English")

*   [Spanish](https://www.eafit.edu.co/institucional/acreditacion)
*   [Inglés](https://www.eafit.edu.co/en/institucional/acreditacion)

 Información para ti

[![Image 6: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Search 

Búsqueda

Menú

Información para ti

[![Image 12: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/en/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/en/node/42116)
    *   [Vida en el campus](https://www.eafit.edu.co/en/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/en/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/en/node/45896)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/en/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/en/node/45926)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/en/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/en/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/en/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/en/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/en/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/en/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/en/registrars-office)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/en/node/31081)
    *   [Cultura CTeI](https://www.eafit.edu.co/en/node/31171)
    *   [Formación](https://www.eafit.edu.co/en/node/31201)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/en/node/39301)
    *   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/en/node/30186)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/en/node/29776)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Transforma con nosotros](https://www.eafit.edu.co/en/node/43361)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/en/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/en/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/en/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/en/node/1151)
    *   [Intercambios nacionales](https://www.eafit.edu.co/en/node/1146)
    *   [Convenios](https://www.eafit.edu.co/en/node/1111)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/en/node/16436)
    *   [Misiones internacionales](https://www.eafit.edu.co/en/node/1136)
    *   [Aprendizaje global](https://www.eafit.edu.co/en/node/1131)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/en/node/45976)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/en/node/43446)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/en/node/47981)
    *   [Centro de artes](https://www.eafit.edu.co/en/node/47976)
    *   [Sala patrimonial](https://www.eafit.edu.co/en/node/39836)
    *   [Bienestar universitario](https://www.eafit.edu.co/en/bienestar)
    *   [Salud mental](https://www.eafit.edu.co/en/node/45826)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/en/node/38366)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/en/node/38196)
    *   [Sala de prensa](https://www.eafit.edu.co/en/node/38391)
    *   [Agenda y eventos](https://www.eafit.edu.co/en/node/18151)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21](https://universidadeafit.widen.net/content/8ebf13a2-2f7c-4fd6-bca4-ace081d3d412/web/induccion-estudiantes-foraneos-2024213.jpg?crop=yes&k=c&w=1920&h=788&itok=a-HgrK_x)

# ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Renewal of Institutional Accreditation

*   [Inicio](https://www.eafit.edu.co/en)
*   [Institutional Information](https://www.eafit.edu.co/en/institucional)
*    Renewal Of Institutional Accreditation 

[Institutional Self-Assessment](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion-institucional)

[Process resources](https://www.eafit.edu.co/institucional/acreditacion/recursos-del-proceso)

[Our Accreditations](https://www.eafit.edu.co/institucional/acreditacion/acreditacion-institucional)

### Informe Autoevaluación Institucional - EAFIT 2025​​​​

[See the report](https://universidadeafit.widen.net/s/r6hzwxlxjs/informe-autoevaluacion-institucional-eafit-2025)

![Image 22: Imagen Balance 2017 - 2024](https://universidadeafit.widen.net/content/083951d5-43b9-4578-b7e7-3bd1ceba6199/web/Foto-estudiantesRegresoclases-021.jpg?crop=yes&k=c&w=397&h=253&itok=lWlgd19j)

Balance 2017 - 2024

[View file](https://universidadeafit.widen.net/s/htr59zpwvk/balance-itinerario-2017-2024)

![Image 23: Imagen Summary of the 2024 Institutional Self-Assessment Report](https://universidadeafit.widen.net/content/10aa62b7-a4fa-47ae-8398-fc90a32e2486/web/pregrado-ingenieria-sistemas-4.jpg?crop=yes&k=c&w=397&h=253&itok=RCQ1isgp)

Summary of the 2024 Institutional Self-Assessment Report

[View file](https://universidadeafit.widen.net/s/llpmlcf6pl/informe-sintesis-autoevaluacion-2024)

## Seguimos aprendiendo​

![Image 24: Imagen ](https://universidadeafit.widen.net/content/40969d17-4188-46bd-9a18-614a5a13909f/web/Espacios-aprendizaje-LabFotointerpretacion-16.jpg?crop=yes&k=c&w=397&h=253&itok=5HL5amwN)

Our achievements and lessons learned in well-being and national and international visibility.

[See our achievements](https://www.eafit.edu.co/nuestros-logros-y-aprendizajes-en-bienestar-y-en-visibilidad-nacional-e-intern-acional)

![Image 25: Imagen ](https://universidadeafit.widen.net/content/5def5176-df0c-4ec1-adfc-d78974178e84/web/graduados-20feb.jpg?crop=yes&k=c&w=397&h=253&itok=XyeGmsi8)

Our achievements and learnings in connection with students, teachers and graduates.

[See our achievements](https://www.eafit.edu.co/nuestros-logros-y-aprendizajes-en-conexion-con-estudiantes-profesores-y-graduados)

![Image 26: Imagen ](https://universidadeafit.widen.net/content/95d01cc7-5526-4e48-932e-e0457686abf8/web/autoevaluacion.jpg?crop=yes&k=c&w=397&h=253&itok=ezY7jFOA)

The progress and lessons learned from the Institutional Self-Assessment in our three mission axes

[See progress](https://www.eafit.edu.co/los-avances-y-oportunidades-que-nos-dejo-la-autoevaluacion-en-aprendizaje-investigacion-y-conexion)

![Image 27: Imagen ](https://universidadeafit.widen.net/content/df263e00-8573-4c61-b57f-c50c770f29f3/web/atencion.png?crop=yes&k=c&w=397&h=253&itok=rpqOpead)

Let's review together the strengths and growth opportunities that the Institutional Self-Assessment left us.

[See strengths](https://www.eafit.edu.co/repasemos-juntos-las-fortalezas-y-aprendizajes-que-nos-dejo-la-autoevaluacion-institucional)

![Image 28: Imagen ](https://universidadeafit.widen.net/content/3aff1b8b-287f-4575-9d81-4542cd3c286d/web/alta-calidad.jpg?crop=yes&k=c&w=397&h=253&itok=WP7n2kpf)

We're moving forward, continuing to learn, and our sights are set on Institutional Accreditation in 2026.

[See institutional accreditation](https://www.eafit.edu.co/avanzamos-seguimos-aprendiendo-y-tenemos-la-mirada-puesta-en-la-acreditacion-insti-tucion-al-2026)

The Institutional Self-Assessment is a commitment and a periodic reflection on our mission axes, which provides us with opportunities for continuous learning to recognize ourselves as a community of knowledge and applied knowledge.

![Image 29: Imagen ](https://universidadeafit.widen.net/content/8c64b5e2-0e66-45b8-8a18-3d463e6b6f1d/web/acreditacion-eafit-institucional.jpg?h=480&itok=W-ncRc0x)

Between 1994 and 2020, four self-assessment processes and more than 50 program self-assessments were carried out. The first process we went through as an Institution was prior to the consolidation of the National Accreditation System and was carried out between 1994 and 1995. Subsequently, in 2002, 2008, and 2016, we carried out three self-assessments for Institutional Accreditation purposes under the guidelines of the National Accreditation Council (CNA).

 For Universidad EAFIT, these processes are essential, as they have allowed for the formulation of curricular reforms, the creation of new Schools, the recognition of the high quality of the academic programs and of the Institution itself, and, especially, the strengthening of a culture of self-assessment and self-regulation through the periodic analysis of its substantive functions, which result in improvement plans that ensure the constant transformation of the Institution.

 Para la Universidad EAFIT estos procesos son indispensables, pues han permitido la formulación de reformas curriculares, la creación de nuevas Escuelas, el reconocimiento de la alta calidad de los programas académicos y de la Institución misma y especialmente, el fortalecimiento de una cultura de autoevaluación y autorregulación a través del análisis periódico de sus funciones sustantivas, que derivan en planes de mejoramiento que permiten asegurar la transformación constante de la Institución. ​​​

###### ​​​​Seguimos avanzando en el proceso de Acreditación Institucional. Y ahora… ¿qué sigue?​​​

The Self-Assessment process for Institutional Accreditation renewal has now been completed. Likewise, during the first semester of 2024, the Academic Quality team began consolidating the report that the University will submit to the Ministry of National Education. And to continue to reinforce our commitment to high quality, we will begin sharing our progress on the Entrenos Intranet.

But first, a moment to reflect on the progress we've made, to thank everyone for their participation, and to remember that we still have a responsibility to this task, which brings all EAFIT students together around a common purpose: to recognize ourselves as part of this educational project and contribute to the renewal of our highest standard of quality. This is the invitation extended to us by Claudia Restrepo, EAFIT Rector, and Paola Podestá, Vice Rector for Learning.

![Image 30: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 31: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 32: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 33: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 34: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 35: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 36: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 37: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Our undergraduates](https://www.eafit.edu.co/en/pregrados)
*   [Our postgraduates programs](https://www.eafit.edu.co/en/posgrados)
*   [Other programs](https://www.eafit.edu.co/en/otros-programas)
*   [Learn about tuition and fees](https://www.eafit.edu.co/en/node/1171)
*   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

Conéctate con EAFIT

*   [Transform with us](https://www.eafit.edu.co/en/node/43361)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/en/node/30186)
*   [Work with us](https://www.eafit.edu.co/en/node/45751)

Contáctanos

*   [Register a PQRSF](https://www.eafit.edu.co/en/node/45736)
*   [Visitor center](https://www.eafit.edu.co/en/node/45661)
*   [Transparency line](https://www.eafit.edu.co/en/node/42081)

Información de ley

*   [Legal Status](https://www.eafit.edu.co/en/node/42106)
*   [Regulations and statutes](https://www.eafit.edu.co/en/node/35101)
*   [Gender, diversity and inclusion](https://www.eafit.edu.co/en/node/38366)
*   [Legal notices and certificates](https://www.eafit.edu.co/en/node/42111)
*   [Update your information](https://www.eafit.edu.co/en/node/45776)
*   [Data protection policy](https://www.eafit.edu.co/en/node/15276)
*   [Terms of use](https://www.eafit.edu.co/en/node/42146)

[Map of the website](https://www.eafit.edu.co/en/institucional/acreditacion#mapa-del-sitio)

Institutional Accreditation until 2026.

Supervised by Ministry of Education.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/en/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Our campuses

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellin](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

National line: 01 8000 515 900

Service line: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Service line: (57) 606 3214115, 606 3214119

[EAFIT Bogota](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Service line: (57) 601 6114618

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego – Rionegro

![Image 38](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
