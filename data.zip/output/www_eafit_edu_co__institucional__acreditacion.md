Title: ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Renovación de la Acreditación Institucional

URL Source: https://www.eafit.edu.co/institucional/acreditacion

Markdown Content:
# Acreditación Institucional de Alta Calidad | EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/institucional/acreditacion#main-content)

[![Image 3: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/acreditacion#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/acreditacion# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/institucional/acreditacion# "English")

*   [Spanish](https://www.eafit.edu.co/institucional/acreditacion)
*   [Inglés](https://www.eafit.edu.co/en/institucional/acreditacion)

 Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 8: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 9: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 10: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 11: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 12: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 14: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 15: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 16: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 17: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 18: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 19: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 20: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 21: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 22: Imagen de banner induccion estudiantes foraneos ](https://universidadeafit.widen.net/content/8d7635d0-7091-49c5-87a8-eda64f2ad618/web/_DSC0711.jpg?crop=yes&k=c&w=1920&h=788&itok=jwLW6pHg)

# ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Renovación de la Acreditación Institucional

*   [Inicio](https://www.eafit.edu.co/)
*   [Información Institucional](https://www.eafit.edu.co/institucional)
*    ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Renovación de La Acreditación Institucional 

#### ¿Qué es la Acreditación en Alta Calidad?

La acreditación es un reconocimiento voluntario que el Estado otorga a las instituciones de educación superior que demuestran altos niveles de calidad en su organización y funcionamiento, la gestión de sus programas académicos y el cumplimiento de su función social. Se basa en una evaluación integral que considera la autoevaluación institucional, la verificación externa de pares académicos y la respuesta de la Universidad al informe de evaluación externa. En el caso de EAFIT, la acreditación en alta calidad y el proceso de autoevaluación que la habilita, le permite a la Institución continuar avanzando en su transformación y en la búsqueda permanente de la excelencia.

###### Beneficios de la Acreditación en Alta Calidad:

1.   Permite al Estado reconocer y exaltar ante la sociedad, la calidad alcanzada por la institución y por los programas que ofrece.
2.   Fortalece el reconocimiento social, la visibilidad y el prestigio de la Institución y sus programas académicos en la comunidad académica nacional e internacional.
3.   Contribuye al mejoramiento del sistema de educación superior colombiano para aportar al desarrollo económico, social, cultural, tecnológico y ambiental.
4.   Consolida la confianza en la Institución y en su compromiso social por brindar una enseñanza y servicios educativos de alta calidad, que favorecen el aprendizaje de los estudiantes y el desarrollo efectivo de sus competencias.
5.   Permite realizar un proceso de reflexión y análisis sobre el estado actual de la Institución e identificar fortalezas y oportunidades de aprendizaje.
6.   Promueve procesos de transformación orientados a demostrar la calidad educativa, y con esto la promoción de una cultura de la autoevaluación y la autorregulación.
7.   Facilita la elaboración de planes de mejoramiento que busquen contrarrestar las debilidades detectadas y potenciar las fortalezas de la Institución.
8.   Incide y promueve reformas en aspectos curriculares, pedagógicos y de investigación.
9.   Ayuda a identificar y proponer nuevos instrumentos y mecanismos que garanticen una gestión académica y administrativa más eficiente.
10.   Permite a las Instituciones acreditadas tener acceso a los incentivos que establece el Estado a través de programas de fomento.
11.   Tienen prelación en las convocatorias gubernamentales sobre becas y créditos condonables nacionales e internacionales.

###### Además, promueve:

1.   El acercamiento con los empleadores y permite identificar estrategias que favorecen la inserción laboral de los graduados y las transformaciones del currículo.
2.   La cooperación nacional e internacional, a través del desarrollo de convenios, para movilidad profesoral y estudiantil, proyectos de investigación, coautorías, entre otros.
3.   La búsqueda, identificación y diseño de mecanismos que favorecen el desarrollo profesoral, y el apoyo a la evaluación y mejora de la calidad profesoral.
4.   La interacción de todos los actores involucrados: profesores, estudiantes, directivos, administrativos y empleadores; para realizar un proceso de reflexión en torno al estado actual de la Institución.

Conoce nuestro proceso

## Autoevaluación Institucional

[Ingresa aquí](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion)

## Nuestras Acreditaciones

[Ingresa aquí](https://www.eafit.edu.co/institucional/acreditacion/acreditacion-institucional)

![Image 23: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

![Image 24: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 25: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 26: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 27: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 28: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 29: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 30: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 31: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
