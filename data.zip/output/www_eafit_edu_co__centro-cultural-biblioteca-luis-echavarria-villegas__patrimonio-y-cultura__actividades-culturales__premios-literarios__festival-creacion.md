Title: Festival de creación

URL Source: https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/festival-creacion

Markdown Content:
*   [Inicio](https://www.eafit.edu.co/)
*   [Centro Cultural Biblioteca Luis Echavarría Villegas](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)
*   [Patrimonio y Cultura](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
*   [Actividades Culturales](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales)
*   [Premios Literarios](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios)
*    Festival de Creación 

Los futuros no están escritos. Se crean a partir de nuestras preguntas, en los trazos de nuestras ideas y en el pulso de nuestra imaginación. Este festival es una invitación a soñar lo que podría ser, a construir narrativas que desafíen lo inevitable, que desplieguen alternativas y abran caminos insospechados. Desde la literatura, la imagen y el sonido, trazamos las posibilidades del mañana. Nos inspiran la ciencia, la naturaleza, la memoria y la utopía. En un mundo de incertidumbre, al acto de CREAR nos permite fijar, sellar y plasmar lo que nuestra mente puede lograr más allá de los límites físicos. En este festival, imaginamos juntos los futuros posibles.

El Festival de Creación 2025 es organizado por la Universidad EAFIT, es una colaboración entre distintas áreas: la Biblioteca Luis Echavarría Villegas, el programa de Literatura, el programa de Comunicación Social, la Universidad de los Niños, el área de Apropiación Social del Conocimiento y Divulgación, la Editorial Nexos. La Maestría en Lectura y Escritura, y el Laboratorio de Lectura, Escritura y Oralidad (CELEE).

#### Propuesta temática

El tema del festival es "Futuros Posibles", una invitación a explorar, desde diversas miradas, ciencias y conocimientos, las distintas maneras en que podemos imaginar, construir y contar los futuros que podrían ser.

#### Modalidades y categorías

###### El Festival cuenta con distintas categorías y modalidades de participación:

Categoría 1: 8 a 10 años

**Modalidad:**

Creación escrita (hasta 1.000 palabras) e ilustrada (Historia gráfica o ilustración).

**Premios:**

**Primer puesto de cada modalidad:**1 bono de $400.000 de la Librería Acentos de EAFIT, 1 cupo para las actividades vacacionales Zoom Ciencia de la Universidad de los niños.

***El lugar de residencia del participante debe estar ubicado en el departamento de Antioquia.**

Categoría 2: 11 a 14 años

**Modalidad:**

Creación escrita (hasta 1.000 palabras) e ilustrada (Historia gráfica o ilustración).

**Premios:**

Primer puesto de cada modalidad: 1 bono de $400.000 de la Librería Acentos de EAFIT, una beca para un curso corto en EAFIT (pendiente definir).

***El lugar de residencia del participante debe estar ubicado en el departamento de Antioquia.**

Categoría 3: para grados 10° y 11°

**Esta categoría se realizará en el marco del concurso Nexcolar para grados 10° y 11° que es organizado por el grupo estudiantil del Periódico NEXOS.**

**Modalidad:**

Creación escrita (hasta 500 palabras) e ilustrada (Historia gráfica o ilustración de 1080px x 1080px).

**Premios:**

**Primer puesto de cada modalidad:**Una beca para un curso de Desarrollo Artístico en EAFIT, publicación en edición impresa primíparos Nexos se encargará de entregar y anunciar otros premios.

***El lugar de residencia del participante debe estar ubicado en el departamento de Antioquia.**

Categoría 4: universitaria

**Modalidad:**

Creación sonora (de ficción o no ficción, con una duración máxima de 5 minutos), escrita (hasta 1.000 palabras) e ilustrada (Historia gráfica o ilustración).

**Premios:**

**Primer puesto de cada modalidad:**1 bono de $400.000 de la Librería Acentos de EAFIT, publicación en Nexos, una beca para un curso de Desarrollo Artístico en EAFIT.

***En esta categoría podrán participan estudiantes de las universidades miembros de la Alianza 4U (ICESI, Uninorte, CESA, EAFIT)**

Todos los ganadores serán además publicados en las redes sociales de los organizadores del Festival y se realizará una publicación de un librillo de obras ganadoras que se entregará en la premiación en la Fiesta del Libro. Las obras ganadoras de la categoría 1 y 2 serán publicadas también en la Revista Catalejo de la Universidad de los niños EAFIT.

La convocatoria estará abierta del 14 de marzo hasta el 13 de junio de 2025.

Las obras serán recibidas a través de la plataforma habilitada

Cada participante podrá presentar una sola obra por modalidad.

Las obras deben ser originales e inéditas.

El lugar de residencia de los participantes debe estar ubicado en el departamento de Antioquia.

Los nombres de los jurados se revelarán pocos días después del cierre del concurso.

El premio no podrá ser declarado desierto.

Se realizará una preselección con apoyo de prelectores de las distintas áreas de la Universidad.

Un jurado compuesto por expertos en literatura, ilustración y comunicación seleccionará las obras ganadoras.

El anuncio de ganadores se realizará el 11 de agosto de 2025.

Los resultados serán publicados en redes sociales y en la página del festival.

La Universidad EAFIT se reserva el derecho a escoger el jurado que considere acreditado para cada categoría, sean personas de la Universidad o externas, y solo se dará a conocer su nombre al final del concurso. El fallo del jurado será inapelable.

La ceremonia de premiación se llevará a cabo en la Fiesta del Libro y la Cultura de Medellín que se realiza en el Jardín Botánico.

Los ganadores recibirán premios según su categoría, incluyendo publicación, materiales patrocinados y cupos en cursos.

Los ganadores del concurso, así como quienes obtengan el segundo puesto, cederán a la Universidad EAFIT los derechos patrimoniales de sus obras para su reproducción en diferentes medios.

Los ganadores se declaran dispuestos a asistir por sus propios medios a la ceremonia de premiación de forma presencial y a ceder el derecho de imagen para la promoción, grabación y difusión impresa o digital de este evento.

Cuando se publique el fallo del jurado, las obras no premiadas serán eliminadas digitalmente.

Al inscribirse en el concurso, los autores y, en caso de ser menores de edad, sus acudientes, autorizan a que la Universidad EAFIT dé tratamiento a sus datos personales de acuerdo con las leyes respectivas ([http://www.eafit.edu.co/datospersonales](http://www.eafit.edu.co/datospersonales)).

La participación en este concurso implica la aceptación de sus condiciones.

Conoce los ganadores de las distintas ediciones del Festival

## 2024

Quebradas de la ciudad

 Donde hay agua hay vida

 Marcus

 El olvido de unos felices para siempre

 Un viaje a la eternidad

 El prisma de la vida

 Querido papá

 El ave María

[Ver 2024](https://repository.eafit.edu.co/items/5dad265f-73f9-444c-8126-8ac4d0117e76)

## 2023

Encadenado a la eternidad

 El chico en el espejo

 Anna y su experiencia con la Nueva Ola de Arte

 Todo lo que es falso

 Escuadrón de energía

[Ver 2023](https://repository.eafit.edu.co/items/80b38bd5-a3f5-4afe-bb53-72164226ad64)

## 2022

Cimarrona de la sierra

 ¿Es él culpable o el crimen?

 Al otro lado del río

 Manolo y el río

 Ciacramode

 Bao

[Ver 2022](https://repository.eafit.edu.co/items/f7a8899f-e567-447c-8fb5-8701644c44e2)

## 2021

El mimo

 Una nueva semilla

 Conspiración en el tiempo

 Cualquier gato es un universo

 El abue jardinero y su florecita

 Dibujo libre

[Ver 2021](https://repository.eafit.edu.co/items/7c8fbaf7-ead8-42b3-ad99-2f82d7ff0d90)

## 2020

Literatura infantil

 Cuentos

 Festival creativo

 Creación literaria

[Ver 2020](https://repository.eafit.edu.co/items/77c3c032-31d7-4934-a633-dd4838e47339)

## 2019

Creación literaria

 Festival creativo

 Cuentos

 Literatura infantil

[Ver 2019](https://repository.eafit.edu.co/items/190d3e97-70ed-43a1-b894-c69cc4595697)

## 2018

Creación literaria

 Festival creativo

 Cuentos

 Literatura infantil

[Ver 2018](https://repository.eafit.edu.co/items/87846e7f-e27f-4cc3-af1b-249d69ef5fc4)

![Image 1: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Contacto:​​

Centro Cultural Biblioteca Luis Echavarría Villegas 

 Correo: ​promocionlectura@eafit.edu.co

 Teléfono: 604 2619500 extensión 9527
