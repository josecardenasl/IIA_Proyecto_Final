Title: Calidad EAFIT

URL Source: https://www.eafit.edu.co/institucional/calidad-eafit

Markdown Content:
[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/calidad-eafit#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/calidad-eafit# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/institucional/calidad-eafit# "English")

Buscar

![Image 6: Imagen de banner crear localidades ](https://universidadeafit.widen.net/content/375cc531-4a4e-4d3c-81d1-eb161eac09ef/web/Crear-localidades.jpg?crop=yes&k=c&w=1920&h=788&itok=PpU0XN4F)

​​​​​​​​​​​​​​​​​​​​​​​​Registros calificados y acreditaciones del Consejo Nacional de Acreditación​.

*   [Inicio](https://www.eafit.edu.co/)
*   [Información Institucional](https://www.eafit.edu.co/institucional)
*    Calidad EAFIT 

![Image 7: Imagen ](https://universidadeafit.widen.net/content/3aff1b8b-287f-4575-9d81-4542cd3c286d/web/alta-calidad.jpg?crop=yes&k=c&w=397&h=253&itok=WP7n2kpf)

[Códigos Snies y Registros Calificados](https://www.eafit.edu.co/institucional/calidad-eafit/codigos-snies-y-registros-calificados)

![Image 8: Imagen ](https://universidadeafit.widen.net/content/e058ce0e-8938-4e4b-9e09-f2011a932eda/web/anies.jpg?crop=yes&k=c&w=397&h=253&itok=hCdgsdI0)

[​Acreditación de ​programas](https://www.eafit.edu.co/calidad-eafit/acreditacion-de-programas)

![Image 9: Imagen ](https://universidadeafit.widen.net/content/d57a71bf-806a-42c2-8d86-3b200aa9aa43/web/acreditacion-institucional.jpg?crop=yes&k=c&w=397&h=253&itok=jpX2mGBw)

[Acre​ditación Institucional​​](https://www.eafit.edu.co/institucional/acreditacion)

#### ​Acreditaciones Internacionales

[![Image 10: Imagen BGA - Acreditación Internacional Business Graduates. Vigencia 5 años](https://universidadeafit.widen.net/content/0918fb19-2d46-4fd1-b3f0-98da7087dc1c/web/bga-logo.jpg) ### BGA - Acreditación Internacional Business Graduates. Vigencia 5 años](https://www.amba-bga.com/bga/accreditation)

[![Image 11: Imagen AACSB - Association to Advance Collegiate Schools of Business](https://universidadeafit.widen.net/content/1e1f559c-e1a2-4457-8e60-fc3fc742406d/web/aacsb-logo-member.jpg) ### AACSB - Association to Advance Collegiate Schools of Business](https://www.aacsb.edu/)

[![Image 12: Imagen AMBA - Acreditación ante ​Association of MBAs​​​](https://universidadeafit.widen.net/content/e81abc69-00cf-4f8f-ae4a-e3b27614d49a/web/AMBA-logo-Acc-black-200.jpg) ### AMBA - Acreditación ante ​Association of MBAs​​​](https://www.amba-bga.com/amba/business-schools/accreditation)

[![Image 13: Imagen CACSLA - Acreditación ante el Consejo de Acreditación de Ciencias Sociales](https://universidadeafit.widen.net/content/24b0ed4c-46ad-49f9-a67b-a2327733644c/web/CACSLA-logo-200.jpg) ### CACSLA - Acreditación ante el Consejo de Acreditación de Ciencias Sociales](https://www.eafit.edu.co/institucional/calidad-eafit)

### ​Otras certificaciones y acreditaciones de procesos, productos o servicios​

[![Image 14: Imagen de Gráfico icontec sobre huella de carbono](https://universidadeafit.widen.net/content/bd50d711-191d-45e2-9478-df72d98c18ab/web/huella-de-carbono.jpg)](https://www.eafit.edu.co/institucional/calidad-eafit)

![Image 15](https://www.eafit.edu.co/institucional/calidad-eafit)

[Ver certificado](https://www.eafit.edu.co/certificado-de-huella-de-carbono)

![Image 16: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 17: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 18: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 19: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 20: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 21: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 22: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 23: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
