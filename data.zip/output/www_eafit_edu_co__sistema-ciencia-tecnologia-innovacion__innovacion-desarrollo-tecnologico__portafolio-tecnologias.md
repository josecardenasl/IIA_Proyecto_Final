Title: Portafolio de tecnologías

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias

Markdown Content:
# Portafolio de tecnologías - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias#main-content)

[![Image 4: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 5: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias#)

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias# "Spanish")[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias# "English")

 Información para ti

[![Image 9: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 10: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 11: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 12: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 13: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 14: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 15: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 16: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 17: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 18: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 19: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 20: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 21: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 22: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 23: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 24: Imagen de banner tecnologia ](https://universidadeafit.widen.net/content/16b217b2-bb18-4fb5-bce8-664dadbc009a/web/banner-principal-transferencia-tecnologias.jpg?crop=yes&k=c&w=1920&h=788&itok=xA7TkYlN)

# Portafolio de tecnologías EAFIT

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Innovación y Transferencia Tecnológica EAFIT](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
*    Portafolio de Tecnologías 

## Conoce nuestras soluciones

Este portafolio reúne soluciones diseñadas desde la ciencia para resolver problemas del mundo real. Cada tecnología está disponible para procesos de transferencia, ajustados a las necesidades de tu organización.

 Conversemos sobre los mecanismos disponibles y cómo llevar estas soluciones directamente a tus procesos, operaciones o proyectos.

[Conectar con un experto](mailto:transferencia.innovacion@eafit.edu.co)

![Image 25: Imagen Conoce nuestras soluciones](https://www.eafit.edu.co/sites/default/files/2025-07/Generador%20de%20Hidr%C3%B3geno%20bionspirado%20%284%29.jpg)

#### **Explora soluciones para tu sector**

![Image 26: Imagen Agrotech](https://universidadeafit.widen.net/content/9c37aa12-549d-4bc2-91e0-31bdd5c73402/web/imagen-agrotech.jpg?crop=yes&k=c&w=397&h=253&itok=5jM8febt)

Agrotech

Soluciones tecnológicas para cultivos, biotecnología agrícola, eficiencia productiva y gestión integral de la cadena agroindustrial.

[Ver sector](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/agrotech)

![Image 27: Imagen Healthtech](https://universidadeafit.widen.net/content/38848778-9a92-423d-9824-87e71ecd4b8c/web/imagen-healthtech.jpg?crop=yes&k=c&w=397&h=253&itok=KP0egTTE)

Healthtech

Dispositivos médicos, software clínico y tecnologías aplicadas al diagnóstico, tratamiento y gestión en salud.

[Ver sector](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/healthtech)

![Image 28: Imagen Industria y manufactura](https://universidadeafit.widen.net/content/86435e4f-e515-45c6-acd2-32a50761d970/web/industria-manufactura.jpg?crop=yes&k=c&w=397&h=253&itok=7a5RQQk2)

Industria y manufactura

Automatización, control, nuevos materiales y procesos para mejorar eficiencia y productividad industrial.

[Ver sector](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura)

![Image 29: Imagen Medio ambiente y desarrollo](https://universidadeafit.widen.net/content/e1ad1465-b705-4576-9cca-5d70ad31f7f1/web/ambiente-territorio.jpg?crop=yes&k=c&w=397&h=253&itok=3pc6vCYg)

Medio ambiente y desarrollo

Tecnologías para monitoreo ambiental, gestión de riesgos, energías renovables y uso sostenible de recursos.

[Ver sector](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/medio-ambiente-desarrollo)

![Image 30: Imagen Software y servicios](https://universidadeafit.widen.net/content/eafedee6-1b3f-470c-904a-e018344832ea/web/software-servicios.jpg?crop=yes&k=c&w=397&h=253&itok=w3tDk6NV)

Software y servicios

Plataformas digitales, analítica y soluciones tecnológicas para educación, cultura, finanzas, turismo y servicios públicos.

[Ver sector](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/software-servicios)

Tecnologías

![Image 31: Imagen CelluGen](https://universidadeafit.widen.net/content/ec019916-c53f-4048-bb9c-13eb936cccc7/web/banner-cellugen.jpg?crop=yes&k=c&w=397&h=253&itok=84j-S2CM)

CelluGen

Innovación biotecnológica para un futuro sostenible.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/healthtech/cellugen)

![Image 32: Imagen Serena](https://universidadeafit.widen.net/content/16ac8fee-e646-4488-afd1-47356f3f57b5/web/banner-serena.jpg?crop=yes&k=c&w=397&h=253&itok=pCuP_DkL)

Serena

Movilidad fluvial sostenible.

[Ver tecnología](node::39091)

![Image 33: Imagen AgroRisk](https://universidadeafit.widen.net/content/226b3156-f219-46b4-baab-577627f298a7/web/banner-progress-1.jpg?crop=yes&k=c&w=397&h=253&itok=7pfeEQpF)

AgroRisk

Plataformas de Inteligencia Aumentada para la Gestión de Riesgos para el Agro.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/software-servicios/agrorisk)

![Image 34: Imagen Recubrimiento por plasma](https://universidadeafit.widen.net/content/282c249d-7de1-4556-afda-f0a8bf472847/web/banner-recubrimiento-plasma.jpg?crop=yes&k=c&w=397&h=253&itok=rUnxqE81)

Recubrimiento por plasma

Mejora de condiciones tribológicas de piezas y maquinaria en diferentes industrias.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/recubrimiento-por-plasma)

![Image 35: Imagen Varieté adicciones](https://universidadeafit.widen.net/content/aec9eba9-fa19-4d43-a803-5ea5b7996bf6/web/banner-variete.jpg?crop=yes&k=c&w=397&h=253&itok=gM7fN4jg)

Varieté adicciones

Concientización juvenil sobre adicciones.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/software-servicios/variete-adicciones)

![Image 36: Imagen Progress](https://universidadeafit.widen.net/content/5d95a101-74bf-48ea-8992-fe420fcbee01/web/banner-progress.jpg?crop=yes&k=c&w=397&h=253&itok=RHxyRpKn)

Progress

Software para planear y programar operaciones de producción y servicios.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/software-servicios/progress)

![Image 37: Imagen BESMARTER](https://universidadeafit.widen.net/content/a940d448-08be-43a6-9b5c-8439ac3437bf/web/banner-be-smarter.jpg?crop=yes&k=c&w=397&h=253&itok=WbLgROx1)

BESMARTER

Interfaz gráfica en inteligencia de negocios y analítica de datos a la medida.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/software-servicios/besmarter)

![Image 38: Imagen Recubrimientos Fotocatalíticos](https://universidadeafit.widen.net/content/98535360-9390-4fcc-8e1f-f8c02d731cfc/web/banner-recubrimiento-fotocatalitico.jpg?crop=yes&k=c&w=397&h=253&itok=9cGfPwDu)

Recubrimientos Fotocatalíticos

Descontamina el aire a partir del recubrimiento en superficies y fachadas.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/medio-ambiente-desarrollo/recubrimientos-fotocataliticos)

#### Novedades

![Image 39: Imagen De residuos a energía](https://universidadeafit.widen.net/content/1874add4-b1c5-403e-a57b-6b0f09648454/web/banner-gasificador-biomasa.jpg?crop=yes&k=c&w=823&h=450&itok=m0UCVbQM)

[Tecnología e innovación](https://www.eafit.edu.co/taxonomy/term/1811)
###### De residuos a energía

En Colombia, donde el 80% de la energía consumida proviene de fuentes térmicas, la dependencia de los combustibles fósiles plantea un desafío significativo. Sin embargo, en medio de esta realidad, surge una alternativa innovadora desde los laboratorios de la Universidad EAFIT: un gasificador de biomasa diseñado para convertir residuos agrícolas en energía útil.

[Leer más](https://www.eafit.edu.co/noticias/de-residuos-energia "Leer más")

Noviembre 20, 2024

![Image 40: Imagen Melissa Londoño](https://universidadeafit.widen.net/content/909ae371-c2f8-4967-a1ec-e21acd86e79e/web/banner-melissa-londono.jpg?crop=yes&k=c&w=823&h=450&itok=eGTJ0g_9)

[Tecnología e innovación](https://www.eafit.edu.co/taxonomy/term/1811)
###### Melissa Londoño

###### Mi trayectoria en Transferencia de Tecnología

Hace doce años, cuando comencé mi carrera en innovación, nunca imaginé que terminaría traduciendo “membranas de nanofiltración” en “filtros eficientes y avanzados” para profesionales de compras. Pero así es el mundo de la transferencia de tecnología.

[Leer más](https://www.eafit.edu.co/noticias/melissa-londono "Leer más")

Noviembre 19, 2024

![Image 41: Imagen Proyección térmica: una tecnología prometedora en Colombia](https://universidadeafit.widen.net/content/203b854f-e3b8-41a0-8542-ed8629faeab3/web/banner-proyeccion-termica.jpg?crop=yes&k=c&w=823&h=450&itok=timlWtaz)

[Tecnología e innovación](https://www.eafit.edu.co/taxonomy/term/1811), [Industria y manufactura](https://www.eafit.edu.co/taxonomy/term/2171)
###### Proyección térmica: una tecnología prometedora en Colombia

###### Una técnica versátil con aplicación en diversas industrias

La proyección térmica es una tecnología versátil que permite aplicar capas protectoras de materiales, tanto metálicos como no metálicos, sobre distintas superficies. Utilizando temperaturas y energías controladas, estas técnicas generan recubrimientos de alta resistencia que ofrecen soluciones personalizadas, adecuándose a un amplio rango de industrias.

[Leer más](https://www.eafit.edu.co/noticias/proyeccion-termica-una-tecnologia-prometedora-en-colombia "Leer más")

Noviembre 14, 2024

[Ver más novedades](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/novedades)

###### **Únete a nuestra red en LinkedIn**

Descubre cómo el conocimiento de EAFIT se convierte en acciones que transforman realidades desde la ciencia, la tecnología y la innovación.

[Únete a nuestra red en LinkedIn](https://www.linkedin.com/showcase/innovaci%C3%B3n-eafit)

[![Image 42: Imagen de Redes sociales](https://universidadeafit.widen.net/content/f67fc677-626c-48d2-839b-df58fba144f9/web/banner-redes-sociales-tecnologias.jpg?crop=yes&k=c&w=645&h=245&itok=YWWY8ksS)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias)

![Image 43](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias)

![Image 44: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 45: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 46: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 47: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 48: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 49: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 50: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 51: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 52](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
