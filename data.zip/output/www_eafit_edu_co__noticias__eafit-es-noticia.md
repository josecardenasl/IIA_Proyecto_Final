Title: EAFIT es noticia

URL Source: https://www.eafit.edu.co/noticias/eafit-es-noticia

Markdown Content:
# EAFIT es noticia - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/noticias/eafit-es-noticia#main-content)

[![Image 3: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 4: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/eafit-es-noticia#)

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/eafit-es-noticia# "Spanish")[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias/eafit-es-noticia# "English")

 Información para ti

[![Image 8: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 9: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 10: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 11: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 12: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 13: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 14: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 15: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 16: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 17: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 18: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 19: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 20: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 21: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 22: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

# EAFIT es noticia

[Sociedad y democracia](https://www.eafit.edu.co/taxonomy/term/1831)

## Medellín avanza en calidad de vida y cultura, pero persisten retos en seguridad y gestión ambiental

Desde hace 19 años Medellín Cómo Vamos realiza análisis y seguimiento a la calidad de vida en la ciudad.

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/medellin-avanza-en-calidad-de-vida-y-cultura-pero-persisten-retos-en "Ver noticia")

Diciembre 5, 2025

![Image 23: Imagen Medellín avanza en calidad de vida y cultura, pero persisten retos en seguridad y gestión ambiental](https://universidadeafit.widen.net/content/dc2ea7bf-cba8-47c4-a2c4-9e195e5da120/web/Med-como-vamos.jpg?crop=yes&k=c&w=944&h=540&itok=6-baFXww)

*   [Inicio](https://www.eafit.edu.co/)
*   [Noticias](https://www.eafit.edu.co/noticias)
*    EAFIT Es Noticia 

Filtros

*   [Octubre 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-10)
*   [Mayo 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-05)
*   [Junio 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-06)
*   [Julio 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-07)
*   [Marzo 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-03)
*   [Abril 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-04)
*   [Febrero 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-02)
*   [Diciembre 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-12)
*   [Enero 2026](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2026-01)
*   [Febrero 2021](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2021-02)
*   [Febrero 2026](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2026-02)
*   [Marzo 2026](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2026-03)
*   [Noviembre 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-11)
*   [Julio 2022](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2022-07)
*   [Septiembre 2021](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2021-09)
*   [Abril 2024](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2024-04)
*   [Abril 2026](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2026-04)
*   [Agosto 2022](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2022-08)
*   [Agosto 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-08)
*   [Enero 2023](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2023-01)
*   [Julio 2015](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2015-07)
*   [Julio 2020](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2020-07)
*   [Julio 2021](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2021-07)
*   [Junio 2021](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2021-06)
*   [Septiembre 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=fecha%3A2025-09)

Facet Fecha EAFIT es noticia 

*   [Graduados(19)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=publico_noticias%3A1936)
*   [Estudiantes de pregrado(18)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=publico_noticias%3A1916)
*   [Empleados administrativos(8)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=publico_noticias%3A1931)
*   [Estudiantes de posgrado(6)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=publico_noticias%3A1921)
*   [Profesores(5)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=publico_noticias%3A1926)

Facet Público Noticias EAFIT es noticia 

*   [Alcampus(21)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A3121)
*   [Arte y cultura(18)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1826)
*   [Educación y futuro(17)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1836)
*   [Investigación(14)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A2626)
*   [Institucional(13)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1846)
*   [Sociedad y democracia(8)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1831)
*   [Tecnología e innovación(6)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1811)
*   [Emprendimiento(5)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1851)
*   [Empresas y negocios(4)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1856)
*   [Cuidado y bienestar(2)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1821)
*   [Medioambiente y cambio climático(1)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1816)
*   [Inclusión y diversidad(0)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A1841)
*   [Revista Descubre y Crea(0)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A2196)
*   [Revista El Eafitense(0)](https://www.eafit.edu.co/noticias/eafit-es-noticia?f%5B0%5D=categoria_de_noticias_eafit%3A2231)

Facet Categoría de noticias EAFIT es noticia 

![Image 24: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=397&h=250&itok=MKSJ4A11)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 25: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=397&h=250&itok=Ai1Iyv7S)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

![Image 26: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=397&h=250&itok=jKshJMEj)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-laboratorio-vivo-para-aprender-haciendo "Ver noticia")

Marzo 12, 2026

![Image 27: Imagen Una experiencia musical en escenarios internacionales ](https://universidadeafit.widen.net/content/84d46f2d-15ad-49a0-9f12-00128b98016d/web/banner-una-experiencia-musical-en-escenarios-internacionales.jpg?crop=yes&k=c&w=397&h=250&itok=JZLy8lEO)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

## Una experiencia musical en escenarios internacionales

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/una-experiencia-musical-en-escenarios-internacionales "Ver noticia")

Marzo 11, 2026

![Image 28: Imagen Aprender en el campo, en tiempo real ](https://universidadeafit.widen.net/content/8818430b-ae36-4541-955c-a61b1fcfb900/web/banner-aprender-en-el-campo-en-tiempo-real.jpg?crop=yes&k=c&w=397&h=250&itok=MZHFom--)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Aprender en el campo, en tiempo real

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/aprender-en-el-campo-en-tiempo-real "Ver noticia")

Febrero 21, 2026

![Image 29: Imagen De la idea al escenario global ](https://universidadeafit.widen.net/content/b348a13b-3f62-4c58-9751-ac4b1c7b5e31/web/de-la-idea-al-escenario-global.jpg?crop=yes&k=c&w=397&h=250&itok=OGgX-KMS)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

## De la idea al escenario global

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-la-idea-al-escenario-global "Ver noticia")

Febrero 18, 2026

*   [Página actual 1](https://www.eafit.edu.co/noticias/eafit-es-noticia?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/noticias/eafit-es-noticia?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/noticias/eafit-es-noticia?label=&page=2 "Ir a la página 3")
*   [Página 4](https://www.eafit.edu.co/noticias/eafit-es-noticia?label=&page=3 "Ir a la página 4")
*   …
*   [Siguiente página›](https://www.eafit.edu.co/noticias/eafit-es-noticia?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/noticias/eafit-es-noticia?label=&page=17 "Ir a la última página")

Te puede interesar

Lo que está pasando

Historias y noticias acerca de la actualidad, logros, ránquines, programas, eventos e iniciativas de incidencia de la Universidad EAFIT a través de su comunidad.

[Ver historias y noticias](https://www.eafit.edu.co/noticias/lo-que-esta-pasando)

Nuestra comunidad de talento

Historias y noticias sobre las vidas y logros de las personas y colectivos que integran la comunidad de EAFIT en academia, investigación y proyección social.

[Ver historias y noticias](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento)

Nuestro impacto

Historias y noticias sobre investigaciones, proyectos e iniciativas que generan impacto en el entorno y aportan respuestas y soluciones a la sociedad.

[Ver historias y noticias](https://www.eafit.edu.co/noticias/nuestro-impacto)

Especiales

Historias que se abordan a fondo, desde EAFIT, con múltiples visiones y formatos sobre un mismo tema.

[Ver especiales](https://www.eafit.edu.co/noticias/especiales)

Publicaciones

Descubre las ediciones de El Eafitense y Descubre y Crea, conoce lo mejor de nuestras revistas académicas, y encuentra las novedades de la Editorial EAFIT.

[Ver publicaciones](https://www.eafit.edu.co/noticias/publicaciones)

## Sala de prensa

Fuentes, fotografías, videos, audios y textos de la Universidad sobre historias, proyectos, logros y noticias de EAFIT para periodistas y medios de comunicación.

[Ir a Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)

![Image 30: Imagen Sala de prensa](https://universidadeafit.widen.net/content/9fc15555-fb1e-4e19-a258-b46db2574036/web/Pregrado-comunicacion-social-9.jpg)

![Image 31: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 32: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 33: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 34: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 35: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 36: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 37: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 38: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 39](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
