Title: Arte y cultura

URL Source: https://www.eafit.edu.co/taxonomy/term/1826

Markdown Content:
# Arte y cultura | Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/taxonomy/term/1826#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/1826#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/taxonomy/term/1826# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/taxonomy/term/1826# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

## [La Editorial EAFIT llevará su catálogo a la Filbo 2026](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/la-editorial-eafit-llevara-su-catalogo-la-filbo-2026)

Abril 22, 2026

**Con estand propio en el pabellón universitario, agenda académica y programación cultural en distintos espacios de Bogotá, la Editorial de la Universidad fortalece su presencia en la Feria Internacional del Libro de Bogotá (Filbo).**

**El libro de poemas**_**Liturgia de los bosques**_**, de Darío Jaramillo Agudelo ganador del premio León de Greiff, será una de las novedades editoriales de la feria. También se presentará el libro Juan Felipe Gaviria:**_**Breve biografía sentimental**_**, un retrato afectivo y coral de una figura pública poco convencional.**

*   [Lee más sobre La Editorial EAFIT llevará su catálogo a la Filbo 2026](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/la-editorial-eafit-llevara-su-catalogo-la-filbo-2026 "La Editorial EAFIT llevará su catálogo a la Filbo 2026")

La Feria Internacional del Libro de Bogotá (Filbo) es el escenario para el encuentro entre lectores, autores, editores, bibliotecas y distribuidores. En su edición de 2026, que se llevará a cabo entre el 21 de abril y el 4 de mayo, la Editorial EAFIT fortalecerá su proyección comercial y académica, así como el relacionamiento con actores clave del sector editorial universitario y cultural.

La Editorial contará con un estand ubicado en el pabellón 3, el espacio destinado a las universidades, donde presentará una cuidadosa curaduría de su oferta editorial. “Allá vamos a tener la opción habitual de libros de literatura y por supuesto libros académicos. Cada vez intentamos ser más refinados en la curaduría”, explica Esteba Duperly Posada, jefe de la Editorial.

###### Presentación de libros y lectura de poemas

También habrá actividades en otros espacios de la ciudad de Bogotá. El 23 de abril, en el Gimnasio Moderno, se presentará el libro Juan Felipe Gaviria: _Breve biografía sentimental_, cuyos autores son algunos de sus familiares y amigos. La presentación contará con la presencia de dos de sus hijos y a la vez autores:  Alejandro Gaviria y Pascual Gaviria.

El día 24 de abril, en la librería Casa Tomada, se realizará una lectura de poemas de Darío Jaramillo Agudelo, a propósito de su más reciente libro Liturgia de los Bosques, editado por EAFIT.

Otra de las actividades destacadas será el homenaje a Rocío Vélez de Piedrahita, que tendrá lugar el domingo 26 de abril, a las 4:00 p. m., en Corferias, en una conversación alrededor de la colección dedicada a la autora y de su vigencia en el panorama literario colombiano. En este encuentro participarán Esteban Duperly, Andrés Sarmiento, gerente de Editorial Panamericana, la escritora Yolanda Reyes y Yamili Ocampo, de la Fundación Ratón de Biblioteca.

Imagen Noticia EAFIT

![Image 21: La participación en la Filbo será clave para afianzar relaciones con actores del sector editorial, compartir experiencias de edición universitaria y consolidar alianzas comerciales e institucionales.](https://universidadeafit.widen.net/content/06775a08-60ca-4910-be81-9ede92d51066/web/Catalogo-la-Filbo2026.jpg)

Leyenda de la imagen

La participación en la Filbo será clave para afianzar relaciones con actores del sector editorial, compartir experiencias de edición universitaria y consolidar alianzas comerciales e institucionales.

###### Algunas novedades de la editorial EAFIT en FILBO

## Liturgia de los bosques - Darío Jaramillo Agudelo

En 2006 Darío Jaramillo Agudelo publicó con la Editorial Pre-Textos La voz interior, novela que narra la biografía de Sebastián Uribe Riley, un escritor que inventaba escritores. Sebastián publicó un único libro en su vida. Y se arrepintió hasta tal punto que asaltaba secretamente las bibliotecas de sus amigos para robarse los ejemplares de Liturgia de los bosques, el poemario que constituía toda su obra. Ese libro ficticio de poesía, incluido dentro de una novela real, nunca se había editado. Jaramillo, el autor de todo esto, tanto imaginario como auténtico, soñaba con ver esos poemas que hablan de mundos vegetales ilustrados por un dibujante de plantas.

## Soledad y destino: Cartas a Aurita (1968 – 1976) - Gonzalo Arango

Aura Becerra de Mera, intelectual caleña y periodista destacada de El País en los años sesenta, sostuvo desde sus columnas un diálogo constante con el movimiento nadaísta. Su cruce epistolar con Gonzalo Arango sirvió para tejer una amistad entrañable y permanente en el tiempo. En estas páginas se rescatan varias cartas escritas por el Profeta que dan cuenta de una memoria compartida, un afecto cultivado entre letras e ideas, y una complicidad que trasciende lo anecdótico para convertirse en testimonio de una época vivida y pensada con rebeldía.

## Juan Felipe Gaviria: Breve Biografía sentimental - Varios autores

Juan Felipe Gaviria fue profesor, columnista de prensa, concejal, alcalde de Medellín, empresario, ministro, rector de universidad, gerente de EPM. Su hoja de vida laboral fue realmente notable. Dicho de ese modo, nos encontramos frente a un hombre de éxito acción estándar; alguien hecho según el molde y los manuales del deber ser. Pero lo curioso es que este personaje no fue tan así, por lo menos no tanto. Tuvo una manera particular de ser y hacer que lo apartó de lo convencional. Este libro nos presenta la vida de este hombre. Sin embargo, no se trata de una reconstrucción profunda y detallada, sino de una biografía sucinta, narrada en clave sentimental —algunos autores fueron sus amigos o familia— y acompañada por fotos. Es, si se quiere, un retrato de cuerpo entero, aunque hecho a mano alzada, en el que no obstante lo sencillo del trazo alcanza a distinguirse la figura total.

## Política exterior colombiana: Historia, agenda y perspectivas - Varios autores

Organizada en quince capítulos alrededor de dos ejes principales –la historia y la agenda–, la obra describe y analiza temas como la influencia del conflicto y la seguridad en la política exterior nacional, el funcionamiento institucional del Estado en la formulación de esta política, y el impacto del bilateralismo con Venezuela, así como los procesos de integración regional más relevantes para el país. Este libro es una lectura esencial para quienes se interesan en la política exterior colombiana.

![Image 22: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

###### Agenda académica

La Filbo también ofrece un espacio formativo y académico a través de Las jornadas profesionales, en donde la Editorial EAFIT tendrá una participación destacada. El jueves 23 de abril, Carmiña Cadavid Cano, editora de esta dependencia eafitense, será una de las panelistas de la mesa Casos de éxito de la edición de mesa, una conversación que hace parte del Foro de Edición Universitaria organizado por la Feria.

Para la Editorial EAFIT, esta participación permitirá compartir experiencias concretas como la colección EAFIT–Tirant, “en la que hemos trabajado desde el inicio con la Escuela de Derecho y que ha supuesto tanto para la Editorial como para los profesores de la Escuela un aprendizaje enorme. También hablaremos del caso de la Biblioteca Fernando González, una de nuestras colecciones más consolidadas y en cuyo desarrollo hemos fortalecido un procedimiento de trabajo muy riguroso con Otraparte”, complementa Carmiña Cadavid.

El espacio propone reflexionar sobre las decisiones editoriales e institucionales que han permitido consolidar modelos exitosos de edición de mesa académica en Colombia, así como identificar aprendizajes y buenas prácticas replicables para el fortalecimiento del sector. Algunos de los interrogantes que se buscan responder en esta mesa son: ¿Qué decisiones institucionales y editoriales han sido determinantes para consolidar un modelo exitoso de edición de mesa académica en su institución? ¿Qué proyectos editoriales se destacan de su proyecto editorial como casos de éxito por su cuidadosa edición de mesa? ¿Qué aprendizajes y buenas prácticas podrían proyectarse como referentes para el fortalecimiento del campo editorial académico y cultural en Colombia?

En esta mesa, que será moderada por César Buitrago Quiñones, de la Universidad de Cundinamarca, también participarán Diego Pérez Medina (Biblioteca Nacional de Colombia), Juan Carlos Pino Correa (Universidad del Cauca) y Marcel Roa Rodríguez (Pontificia Universidad Javeriana).

Finalmente, la participación en la Filbo será una oportunidad para consolidar acuerdos con grandes compradores institucionales, como bibliotecas y universidades, así como con librerías y distribuidores nacionales e internacionales. “La Feria permite mucho más que exhibir libros: nos ayuda a construir redes, a posicionar el catálogo y a pensar estratégicamente el lugar del libro universitario en un ecosistema editorial cada vez más amplio y diverso”, concluye Esteban.

## EAFIT en Filbo como aliado del Tecnologías para Aprender

Este año EAFIT también participará en la Filbo como aliado estratégico del programa Tecnologías para Aprender, en un espacio que trasciende la exhibición tradicional para convertirse en un laboratorio vivo de innovación educativa. Según Jhonathan Bustamante Cuartas, coordinador de comunicaciones de Innovación EAFIT, “en el stand, los visitantes no solo se acercan a herramientas tecnológicas, sino que experimentan de primera mano cómo estas transforman las formas de aprender, narrar y construir conocimiento en el país. Se trata de una apuesta por visibilizar historias de cambio pedagógico donde la tecnología actúa como puente entre la creatividad, la cultura y la educación.

 Más que una agenda de actividades, el espacio propone experiencias inmersivas y participativas que invitan al público a dejar de ser espectador para convertirse en creador. Desde la exploración de narrativas digitales hasta la interacción con tecnologías emergentes, niños, jóvenes y adultos encuentran un entorno donde el “aprender haciendo” cobra sentido. Estas experiencias integran memoria, identidad y desarrollo tecnológico, permitiendo reconocer el potencial de estudiantes y profesores que participan del proyecto y evidenciando cómo la convergencia entre educación y tecnología abre nuevas formas de entender y participar en las historias del país.

![Image 23: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

###### Sobre Filbo

Durante 14 días continuos se llevará a cabo la 38 edición de la Feria Internacional del Libro de Bogotá (Filbo), uno de los eventos editoriales más grandes de América Latina. “Escuchar para leernos” es el concepto que abarca el encuentro, incentivando la lectura como ejercicio de diálogo y empatía en un contexto social marcado por la polarización y el ruido informativo.

Una de las principales novedades de ese año es que el país invitado es India, cuya participación incluye literatura, cine, gastronomía y artes escénicas, fortaleciendo el diálogo cultural entre ambos países.

Filbo ofrece a los asistentes una programación de más de 2 mil actividades, entre lanzamientos de libros, charlas, talleres, conciertos, exposiciones y encuentros profesionales.

Para la edición 2026, se espera la participación de alrededor de 500 expositores y una asistencia de más de 630 mil visitantes, superando las cifras del año anterior.

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-y-la-alcaldia-de-medellin-tienen-abierta-la-convocatoria-para-la)

Abril 21, 2026

**El Premio León de Greiff al Mérito Literario, que desde 2016 reconoce a destacadas voces de la literatura latinoamericana, ya tiene abierta la convocatoria para su sexta edición, que se realizará en el marco de la conmemoración de los 50 años del fallecimiento de este poeta antioqueño.**

**Este galardón, liderado por EAFIT y la Alcaldía de Medellín, exalta las trayectorias consolidadas de escritores y su aporte a la cultura y al tejido social. Está dirigido a escritores vivos en español y el nombre del ganador se dará a conocer en septiembre, durante la Fiesta del Libro y la Cultura, que este año cumple dos décadas.**

*   [Lee más sobre EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-y-la-alcaldia-de-medellin-tienen-abierta-la-convocatoria-para-la "EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario")

[**Las postulaciones deberán ser presentadas**](https://eafit.qualtrics.com/jfe/form/SV_8igZh8GDU9E16rs) por entidades culturales, editoriales públicas o privadas, de Colombia o del exterior que mantengan vínculo con el país, hasta el lunes 25 de mayo. En la imagen Darío Jaramillo Agudelo, ganador de la quinta edición del premio, en la presentación de su libro Liturgia de los Bosques.

En 2016 el primero en recibirlo fue el poeta venezolano Juan Calzadilla por su amplia trayectoria artística mezclando poesía y dibujo; en 2017 la argentina Luisa Valenzuela fue seleccionada por sus cuentos y novelas que cuestionaban el rol actual de la mujer en la sociedad y la realidad misma del lenguaje; en 2018 el turno fue para el misterio, el amor, la cotidianidad y lo onírico en los poemas del antioqueño Elkin Restrepo; en 2019, Edgar Rodríguez y su particular visión de la identidad de Puerto Rico y el caribe hispanohablante, fue el destacado; y, en 2025, después de seis años de ausencia del galardón, el homenajeado fue el poeta antioqueño Darío Jaramillo Agudelo.

Se trata del [_Premio León de Greiff al Mérito Literario_](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario) que, en sus cinco ediciones, ha celebrado la memoria de este autor a través del reconocimiento a la vida y obra de otros escritores y poetas de toda Latinoamérica que, con su arte, han aportado a la cultura y a la construcción de tejido social.

Y para su sexta edición, ya está abierta la convocatoria para este reconocimiento, que es posible gracias a una alianza entre la Universidad EAFIT y la Secretaría de Cultura Ciudadana de Medellín, y que este año se enmarca, justamente, en la conmemoración de los 50 años del fallecimiento de León de Greiff.

“Este premio es muy importante porque complementa el esfuerzo de la Alcaldía de Medellín por ampliar las oportunidades dirigidas a los autores. No se trata únicamente de los estímulos que ofrecen las convocatorias públicas, sino de otros espacios que generan posibilidades, como los Eventos del Libro y el Sistema de Bibliotecas Públicas, para reconocer el talento literario antioqueño”, señala Santiago Silva, secretario de Cultura Ciudadana de Medellín.

A estas palabras se suma Verónica Uribe Hanabergh, decana de la Escuela de Artes y Humanidades de EAFIT, quien agrega que otro de los hitos de este premio es la unión entre la Universidad y la administración local para potenciar la cultura y las letras. “Como Universidad es fundamental que estemos vinculados a este premio, pues hace parte de la cadena de producción literaria, y tiene una estrecha relación con lo que queremos posicionar a través de nuestros programas de pregrado y maestría en literatura”, afirma la directiva.

Este año, la convocatoria está dirigida a escritores vivos con una obra consolidada y publicada en español, y las postulaciones deberán ser presentadas por entidades culturales, editoriales públicas o privadas, de Colombia o del exterior que mantengan vínculo con el país, hasta el lunes 25 de mayo.

Durante este periodo, las instituciones interesadas también deberán diligenciar el formulario correspondiente y adjuntar una carta en la que se sustenten los méritos literarios del candidato, destacando su obra, trayectoria e influencia cultural. Las bases completas de la convocatoria, el formulario de postulación y la información sobre ediciones anteriores se pueden consultar en el siguiente [enlace](https://eafit.qualtrics.com/jfe/form/SV_8igZh8GDU9E16rs).

###### En septiembre se conocerá al ganador de la sexta edición del Premio León de Greiff

Desde su creación, el Premio León de Greiff reconoce de manera intercalada a un escritor en poesía y a un autor destacado en el campo de la narrativa. Este año el galardón premiará a un escritor de narrativa con 40 millones de pesos colombianos y la oportunidad de publicar una antología representativa de su trayectoria, o una obra inédita, por parte de la Editorial EAFIT.

Ese fue, justamente, el caso del ganador anterior, el poeta Darío Jaramillo Agudelo quien, como parte del galardón, publicó con la editorial eafitense su obra _Liturgia de los bosques_, un poemario que fue presentado, oficialmente, el pasado 6 de marzo.

Como lo destaca el acta con la que se le confirió el Premio, es un reconocimiento a “su obra poética consolidada y de amplio espectro; al trabajo renovador del lenguaje y su voz intimista y reflexiva; a su trayectoria en la novela, el ensayo y la crítica literaria; al impacto de su obra en los ámbitos nacional e internacional y la influencia en generaciones posteriores de poetas; y a su labor decidida como gestor, promotor cultural y editor”.

Y a Darío Jaramillo, Juan Calzadilla, Luisa Valenzuela, Elkin Restrepo y Edgar Rodríguez, se sumará un nuevo escritor galardonado este año. Su nombre se dará a conocer, en septiembre, durante la celebración de la Fiesta del Libro y la Cultura de Medellín, evento que, este año, también está conmemorando 20 años de trayectoria.

Imagen Noticia EAFIT

![Image 24: EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario](https://universidadeafit.widen.net/content/7560b375-a4ab-4d45-adb8-1b969563953a/web/premio-literario-1500.jpg)

## Sobre los jurados

Este año los jurados encargados de elegir al ganador del Premio León de Greiff al Mérito Literario son Guillermo Quijas-Corzo, escritor mexicano, fundador de la Editorial Almadía y gestor cultural de Feria Internacional del Libro de Oaxaca; Juan Diego Mejía, escritor de Medellín, ganador de los premios Nacional de Cuento (1982) y Nacional de Novela de Colcultura (1996), y ex director de la Fiesta del Libro y la Cultura de Medellín (2013–2016); y Alba Patricia Cardona Zuluaga, profesora de EAFIT e integrante del grupo de investigación en Estudios de Filosofía, Hermenéutica y Narrativas.

![Image 25: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Recorrer la cancha, la tribuna y la calle es la invitación de la nueva exposición de EAFIT](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/recorrer-la-cancha-la-tribuna-y-la-calle-es-la-invitacion-de-la-nueva)

Abril 15, 2026

**La muestra**_**Campo en juego. Fútbol, vida y barrio**_**llegará al Centro de Artes de la Universidad este jueves 16 de abril. A través de obras de arte, fotografías, objetos, instalaciones y espacios interactivos, propone mirar este deporte como un fenómeno cultural que atraviesa la memoria, la cotidianidad y las identidades.**

**La inauguración reunirá artistas, instituciones culturales y voces del mundo futbolero en un recorrido por la cancha, la tribuna y la calle. La exhibición cuenta con el apoyo del periódico**_**Universo Centro**_**, la Biblioteca Pública Piloto, el Archivo Histórico de Antioquia, el Archivo Histórico de Medellín, el Atlético Nacional Femenino y el Índer.**

*   [Lee más sobre Recorrer la cancha, la tribuna y la calle es la invitación de la nueva exposición de EAFIT](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/recorrer-la-cancha-la-tribuna-y-la-calle-es-la-invitacion-de-la-nueva "Recorrer la cancha, la tribuna y la calle es la invitación de la nueva exposición de EAFIT")

Puede que un partido de fútbol dure noventa minutos, pero las historias que deja pueden permanecer durante décadas. Más que un deporte, el fútbol es un fenómeno cultural capaz de atravesar la vida cotidiana y de instalarse en la memoria colectiva.

La Mano de Dios de Maradona, el gol de Fredy Rincón contra Alemania en el último minuto en Italia 90, el escorpión de Higuita o la celebración de la primera Libertadores de América para Atlético Nacional son recuerdos que conviven con otros más cercanos, como los partidos improvisados en la calle de un barrio, la creación de un ‘trapo’ para alentar un equipo o los estribillos de un cántico de barra que se quedan en la memoria. Todos ellos son muestra de cómo este deporte trasciende la cancha y se convierte en parte de las emociones, las identidades y la vida misma de una persona o de las comunidades.

A partir de esa idea, la Dirección de Cultura de EAFIT inaugurará en el Centro de Artes de la Universidad, este jueves 16 de abril a las 5:00 p.m., _Campo en Juego_. Fútbol, vida y barrio, una exposición que, en palabras de Clara Cristina Acosta Ossa, programadora cultural de la Institución, se convertirá en un espacio de encuentro, conversación y juego alrededor del fútbol y su conexión con otras dimensiones como la memoria, la historia y los temas de relevancia para el país.

“Existen fenómenos capaces de reunir miradas, sí, pero ninguno como el fútbol. Y por eso nos unimos a diferentes aliados como el periódico _Universo Centro_, la Biblioteca Pública Piloto, el Archivo Histórico de Antioquia, el Archivo Histórico de Medellín, el Atlético Nacional Femenino y el Instituto de Deportes y Recreación de Medellín (Índer), para traer esta muestra artística, que coincide con el año en el que se juega la Copa Mundial de Fútbol, uno de los eventos más importantes que vivimos como sociedad”, señala la gestora cultural.

De esta manera, en _Campo en juego_ los asistentes se convertirán en espectadores y, al mismo tiempo, en protagonistas y jugadores de un recorrido que propone mirar el fútbol no solo como los noventa minutos reglamentarios de un partido, sino como un movimiento cultural, reconociendo su influencia en la vida social, las memorias colectivas y las expresiones artísticas, como un fenómeno capaz de atravesar la vida cotidiana y de participar en la construcción de identidades y relatos colectivos.

###### El fútbol y su encuentro con las múltiples dimensiones de la vida

La propuesta curatorial permitirá que los asistentes vivan la experiencia desde tres ejes conceptuales: la cancha, la tribuna y la calle, reuniendo obras de arte contemporáneo, archivos fotográficos, objetos tridimensionales, instalaciones audiovisuales y espacios interactivos que buscan conectar la emoción del juego con la memoria y el recuerdo. 

En la muestra participan artistas como Fredy Serna, Maje, Víctor Gaviria, Helí Ramírez, Víctor Garcés, Félix Ángel, Julia López, Paul Smith, Gomito y Esteban Zapata, junto con aportes de coleccionistas, archivos y otras instituciones que permitirá acercarnos a este espectáculo deportivo desde el ritual del juego, las emociones, las voces de los hinchas, los cantos, las banderas, las formas de pertenencia que convierten al fútbol en una experiencia compartida, el juego en el barrio, los partidos improvisados y las múltiples maneras en que este deporte se integra a la vida cotidiana.

“Vamos a tener obras que nos cuestionan sobre lo que significa la selección Colombia para el país, videojuegos, intervenciones, collages, fotografías con momentos históricos asociados a este deporte, fútbol con tapitas e incluso, durante el tiempo que esté abierta, tendremos espacios de intercambio de láminas del álbum de _Panini_. Todo esto, acompañado de una agenda académica, cultural y de visitas guiadas con expertos”, agrega Clara Cristina.

En esta muestra en la que el espectador se convierte en jugador, se encontrará con obras como _Nosotras_, de Julia López, que hace un recorrido por la presencia de las mujeres en el fútbol; con las pinturas _Cancha de Pedregal y Estrella del Norte_, de Fredy Serna; con los poemas de Víctor Gaviria y Helí Ramírez; y con el collage de _El Gráfico_, de Félix Ángel, artista colombiano residente en Washington, entre otras.

Otra de las obras que se podrá visitar en la exposición es _Palomo_ del artista Santiago Rodas, se trata de un díptico en acrílico sobre lienzo de 2 metros de largo por 1.50 de alto que plasma la muerte violenta de El Palomo Usurriaga, futbolista entre los años 80 y 90. Según lo explica el artista “la obra produce una tensión entre: vida y muerte pura. Juego, ardor y vitalidad. También tiene que ver con las condiciones sociohistóricas de un país como el nuestro”.

También habrá uno de los típicos trapos largos que suelen atravesar las graderías, utilizados por las hinchadas de los equipos y que, en esta ocasión, aludirá a la desazón que deja la perdida en el fútbol. Este trapo mide 9 x 1.5 metros, y fue realizado por Esteban Rodríguez quien confecciona los de las barras del Atlético Nacional.

La exposición estará abierta hasta julio de 2026 y está dirigida a la comunidad universitaria, al público general, al sector cultural, a instituciones educativas y, por supuesto, a la comunidad futbolera.

“En este recorrido, cada visitante asiste a un partido distinto, ya sea desde la banca, la tribuna o la calle y por eso extendemos una invitación a toda la ciudad para que, en este año en el que tendremos el Mundial de Fútbol, nos regalemos este espacio de encuentro con este deporte y la vida”, concluye la programadora cultural.

Imagen Noticia EAFIT

![Image 26: La muestra Campo en juego. Fútbol, vida y barrio llegará al Centro de Artes de la Universidad este jueves 16 de abril. A través de obras de arte, fotografías, objetos, instalaciones y espacios interactivos, propone mirar este deporte como un fenómeno cultural que atraviesa la memoria, la cotidianidad y las identidades.](https://universidadeafit.widen.net/content/94c78b4d-8131-4055-b050-34f6b0d6954a/web/Recorrer-cancha.jpg)

Leyenda de la imagen

La exposición estará abierta hasta julio de 2026. 

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Liturgia de los bosques, el libro que nació en una novela de Darío Jaramillo, llega por primera vez a los lectores](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/liturgia-de-los-bosques-el-libro-que-nacio-en-una-novela-de-dario)

Marzo 9, 2026

**La Editorial EAFIT acaba de publicar el libro**[_**Liturgia de los bosques**_](https://www.youtube.com/watch?v=XMNjmRsbbbU&list=PLZK50pBaIInqhZl8YMU6DnoJ7ziDDWJjB&index=6)**, de Darío Jaramillo Agudelo, que surge tras recibir el Premio León de Greiff al Mérito Literario 2025. La obra tiene un origen singular: apareció primero como un poemario ficticio que el autor publicó dentro de su novela**_**La voz interior**_**(2006).**

**Durante el lanzamiento del libro se anunció la apertura de la sexta convocatoria del Premio León de Greiff, una iniciativa de la Secretaría de Cultura Ciudadana de Medellín y EAFIT. El galardón reconoce la trayectoria de escritores latinoamericanos y en la edición 2026 premiará a un autor o autora en el género de narrativa.**

*   [Lee más sobre Liturgia de los bosques, el libro que nació en una novela de Darío Jaramillo, llega por primera vez a los lectores](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/liturgia-de-los-bosques-el-libro-que-nacio-en-una-novela-de-dario "Liturgia de los bosques, el libro que nació en una novela de Darío Jaramillo, llega por primera vez a los lectores")

Árboles, plantas y paisajes naturales inspiran los versos de _Liturgia de los bosques_, presentado el 6 de marzo en EAFIT. La [**postulación**](https://fiestadellibroylacultura.com/premio-leon-de-greiff/) de candidatos para la sexta edición del premio León de Greiff al mérito literario estará abierta hasta el próximo 25 de mayo.

Un libro que durante años habitó únicamente en la ficción finalmente encontró su lugar entre los lectores. El 6 de marzo fue presentado [_Liturgia de los bosques_](https://www.youtube.com/watch?v=XMNjmRsbbbU&list=PLZK50pBaIInqhZl8YMU6DnoJ7ziDDWJjB&index=6), de Darío Jaramillo Agudelo, un poemario que nació dentro de una novela y que hoy se publica como obra independiente. El lanzamiento se realizó en la Universidad, en el marco del reconocimiento que el autor recibió en 2025 en la quinta edición del Premio León de Greiff al Mérito Literario, una iniciativa de la Secretaría de Cultura Ciudadana de Medellín y EAFIT.

El autor expresó su gratitud a EAFIT, a la Secretaría de Cultura Ciudadana de Medellín, así como también a la editorial y al ilustrador del libro, “que trabajaron con tanto amor, con tan buenos resultados para tener finalmente hoy el libro. Sin más que agregar que agradecer y agradecer y agradecer”. Conoce más sobre la vida de Darío Jaramillo Agudelo [aquí](https://www.youtube.com/watch?v=eyA29cyouAs&list=PLZK50pBaIInqhZl8YMU6DnoJ7ziDDWJjB&index=2).

Durante la presentación, el viernes 6 de marzo, el secretario de Cultura Ciudadana de Medellín, Santiago Silva Jaramillo, destacó el valor cultural del premio y del libro que se entrega como parte del reconocimiento. “Para el Distrito, un premio como este, en alianza con EAFIT, representa un apoyo decidido para fortalecer el ecosistema literario cultural de Medellín, y para posicionar a la ciudad como un epicentro de reflexión en torno a los libros y la lectura”, expresó.

En su intervención, el secretario también anunció la apertura de la sexta convocatoria del galardón, correspondiente a 2026, que en esta ocasión reconocerá a un autor o autora en el género de narrativa. Asimismo, el secretario invitó a instituciones culturales, editoriales y académicas a [postular candidatos](https://fiestadellibroylacultura.com/premio-leon-de-greiff/) hasta el 25 de mayo y destacó que este tipo de iniciativas contribuyen a consolidar a Medellín como un espacio de encuentro para la lectura, la escritura y la circulación de la literatura en América Latina.

Por su parte, Verónica Uribe Hanabergh, decana de la Escuela de Artes y Humanidades de EAFIT, resaltó la importancia de celebrar la trayectoria de un autor que ha marcado la literatura colombiana contemporánea. “Su obra ha sido especialmente influyente en la renovación de la poesía amorosa en español, al abordar el amor, el paso del tiempo y la intimidad con un lenguaje claro, reflexivo y cotidiano”, afirmó.

La decana también se refirió al valor material y simbólico del libro presentado, al señalar que _Liturgia de los bosques_ reúne poesía, ilustración científica y cuidado editorial. Para la académica, recorrer sus páginas es también una forma de reconocer la relación entre la literatura y el mundo natural, un tema central en la obra.

###### Un libro que salió de la ficción

El poemario tiene un origen singular. La idea apareció por primera vez en 2006 dentro de la novela _La voz interior_, en la que Darío Jaramillo narra la historia de Sebastián Uribe Riley, un escritor ficticio que inventaba escritores y que había publicado un único libro en su vida: precisamente _Liturgia de los bosques_. Durante años ese poemario permaneció como una obra imaginaria, integrada al universo narrativo de la novela.

Con motivo del premio recibido en 2025, el autor decidió convertir ese libro ficticio en una obra real. Así nació esta edición independiente, ilustrada con dibujos botánicos de Ricardo Macía y pensada como un homenaje a la naturaleza y al mundo vegetal que atraviesa los poemas. El resultado es un libro que, en palabras de su propio autor, parecía haber existido siempre, aunque apenas ahora llega a manos de los lectores.

Durante el evento, el escritor compartió con los asistentes algunas reflexiones sobre el origen del poemario y la historia que lo rodea. Según explicó, la idea de publicarlo surgió al momento de preparar el libro asociado al premio, ya que meses antes se había publicado una antología de su obra. “Y así se me ocurrió, ya que era obvio que Sebastián Uribe había desaparecido del mapa y se había robado todos los ejemplares, pues que lo volviéramos a escribir ya por fuera de la novela _La voz interior_”, relató.

La presentación concluyó con una lectura de algunos de los poemas del libro, en los que árboles, semillas y paisajes vegetales se convierten en metáforas del tiempo, la memoria y la existencia. Con este lanzamiento, _Liturgia de los bosques_ deja de ser un libro imaginado para integrarse plenamente al universo literario de su autor y a la tradición poética contemporánea.

Imagen Noticia EAFIT

![Image 27: Árboles, plantas y paisajes naturales inspiran los versos de Liturgia de los bosques, presentado el 6 de marzo en EAFIT. La postulación [SG4.1]de candidatos para la sexta edición del premio León de Greiff al mérito literario estará abierta hasta el próximo 25 de mayo.](https://universidadeafit.widen.net/content/c63942ef-7004-41c9-bd6b-8e88d0d0691b/web/Novela-DaroJaramillo.jpg)

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [EAFIT presenta su agenda cultural 2026-1, una oportunidad para el encuentro, la conversación y el pensamiento crítico](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-presenta-su-agenda-cultural-2026-1-una-oportunidad-para-el)

Enero 28, 2026

**Una agenda diversa y articulada que reúne arte, cine, ópera, literatura, teatro, música y danza bajo una misma propuesta: la cultura como un lenguaje de conocimiento, transformación y encuentro. Así es la programación con la que EAFIT se consolida como epicentro cultural de la ciudad y la región.**

**Se trata de una propuesta pensada para dialogar con Medellín y sus territorios, promover el pensamiento crítico, estimular la imaginación y propiciar experiencias colectivas desde la creación y el disfrute.**

*   [Lee más sobre EAFIT presenta su agenda cultural 2026-1, una oportunidad para el encuentro, la conversación y el pensamiento crítico](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-presenta-su-agenda-cultural-2026-1-una-oportunidad-para-el "EAFIT presenta su agenda cultural 2026-1, una oportunidad para el encuentro, la conversación y el pensamiento crítico")

Arte, cine, ópera, literatura, teatro, música y danza, entre otras manifestaciones artísticas, y todas ellas articuladas bajo una misma propuesta que busca posicionar la cultura como lenguaje de conocimiento, transformación y encuentro, se concentran en la agenda cultural diversa con la que EAFIT seguirá consolidándose, este semestre, como un epicentro cultural de la región.

“Hemos diseñado una programación de alta calidad que transformará el campus cada semana y que va más allá del entretenimiento: será una invitación a pensarse, sentir y construir ciudadanía cultural desde nuestras experiencias colectivas en EAFIT”, expresa Shirley Zuluaga Cosme, jefa del Departamento de Cultura de la Universidad.

Dentro de la programación destacan iniciativas como las exposiciones en torno al fútbol —a propósito de la Copa Mundial— desde un enfoque interdisciplinar, que lo aborda como fenómeno cultural y social; las propuestas experimentales de la Orquesta Sinfónica de EAFIT, que expanden los límites de la experiencia sonora; los lanzamientos editoriales y los territorios de lectura como espacios vivos de diálogo.

Todo esto, como agrega Shirley, con el objetivo de profundizar el vínculo entre la Universidad y la ciudad con una agenda que trascienda los límites del campus y dialogue con otras ofertas culturales de Medellín.

“Queremos que todas estas acciones no solo enriquezcan la experiencia cultural de los eafitenses y de la ciudad, sino que sigan posicionando a EAFIT como un epicentro cultural, un espacio de creación, generación, circulación y encuentro en torno a la cultura que dialoga con públicos diversos, promueve el pensamiento crítico, estimula la imaginación y contribuye a consolidar a Medellín como una ciudad vibrante y transformada desde la dimensión amplia de la cultura”, puntualiza.

A continuación, en detalle, la agenda cultural con la que EAFIT celebra la cultura en este 2026

###### La fiebre del Mundial nos invita a hablar de fútbol, cultura y sociedad

Si hubiera que resumir el fútbol en su solo objeto sin duda alguna sería el balón. Pero si el caso es una exposición inspirada en el tema, estos pueden ser diversos. Es así como Campo en juego, la nueva exposición del Centro de Artes de EAFIT, tendrá fotografías, pinturas, instalaciones tridimensionales e interactivas, estampillas, así como textos y poesías. La exposición, que estará abierta al público entre finales de febrero y finales de julio, busca aprovechar esta efeméride deportiva para poner a dialogar a las personas alrededor de este tema.

Según Clara Cristina Acosta Ossa, programadora cultural de EAFIT, otra de las motivaciones para realizar esta exposición es “inducir al juego y a la conversación. Hablar de fútbol, como Universidad, es una excusa para hablar de democracia, de paz, de mujeres, de ciudad, de historia, de colores”.

La muestra exhibirá las obras de artistas como Fredy Serna, Juan Fernando Ospina y Esteban Zapata, entre otros; y de poetas como Helí Ramírez y Víctor Gaviria. Y contará con el acompañamiento curatorial de Universo Centro, la Biblioteca Pública Piloto, el Archivo Histórico de Medellín, la Biblioteca Nacional y el Museo de Antioquia. Así mismo, como complemento a la exposición Campo en Juego, está la muestra Campo y campus, una exhibición que desde ya puede visitarse en las inmediaciones de la Plazoleta del Estudiante.

###### Inteligencia musical para un tiempo de esperanza: la visión de la Orquesta Sinfónica EAFIT en 2026

En un momento global donde la conversación gira en torno a la inteligencia artificial, la Orquesta Sinfónica EAFIT propone una agenda musical para pensar en la inteligencia musical.

"Frente a la velocidad de la tecnología, nosotros proponemos la profundidad del arte. Nuestra apuesta para 2026 es la inteligencia musical: esa capacidad única de conectarnos, de generar esperanza y de construir tejido social a través de la excelencia sonora y la colaboración", explica Susana Palacios, jefa de la Orquesta.

Los más de 30 recitales de este semestre, y sus invitados, reflejarán esta filosofía de apertura y diálogo entre la tradición y la innovación. Con esta propuesta, la Orquesta Sinfónica EAFIT invita a la ciudadanía a redescubrir el poder de la música en vivo, como un espacio donde la técnica se subordina a la emoción y donde EAFIT reafirma su compromiso con el humanismo.

Imagen Noticia EAFIT

![Image 28: EAFIT presenta su agenda cultural 2026-1, una oportunidad para el encuentro, la conversación y el pensamiento crítico](https://universidadeafit.widen.net/content/4a4235ae-0a92-44a1-b916-d73990f41698/web/Expo-campo-y-campus.jpg)

Leyenda de la imagen

En la imagen la muestra Campo y Campus, con la que ya se vive el ambiente mundialista y la cultura en EAFIT.

###### **Los tres primeros conciertos de la Orquesta**

**Viernes 13 de febrero**

Concierto inaugural de temporada 2026

Pulsos. Un comienzo que respira antes de decidirse

_Concierto para piano y orquesta_, de Sergéi Rajmáninov

_El sombrero de tres picos_, de Manuel de Falla

_Pinos de Roma_ (Pini di Roma), de Ottorino Respighi

Auditorio Fundadores

7:00 p.m.

**Viernes, 27 de febrero de 2026**

II Concierto de temporada

Mozart y Danza

_Obertura de El rapto en el serrallo_, K. 384

_Concierto para corno n.º 1 en re mayor_, K. 412

_Suite de La rebambaramba_, Op. 1

Auditorio Fundadores

7:00 p. m.

**Viernes, 13 de marzo de 2026**

III Concierto de temporada

Borbones

_Danzas concertantes_, de Igor Stravinsky

_Concierto para arpa y orquesta_, de Edmar Castañeda:

Appalachian Spring, de Aaron Copland

Auditorio Fundadores

7:00 p. m.

La boletería para los recitales se puede comprar a través de [**Ticketexpress**](https://ticketexpress.com.co/event/mozart-y-danza/)

###### François Truffaut, protagonista del Cineclub EAFIT

El Cineclub EAFIT, que cuenta con más de 25 años de trayectoria, presenta una selección de 14 largometrajes que exploran, con sensibilidad y profundidad, temas como la infancia, el ciclo vital, la muerte y el amor, desde un tono marcado por la ternura y la melancolía.

Y lo que tienen en común estas películas es que su director es François Truffaut, figura central de la _nouvelle vague_, y quien proponía, en su obra, un recorrido íntimo por las emociones al mismo tiempo que rendía un homenaje a los que consideraba que eran los grandes maestros del séptimo arte.

“Este espacio dialoga perfectamente con el ciclo de 2024-2 que estuvo dedicado a Alfred Hitchcock, pues ambos directores mantuvieron una correspondencia frecuente, fueron amigos y compartieron visiones”, expresa Clara Cristina Acosta Ossa.

El ciclo comienza este 9 de febrero con la película _Los 400 golpes_. La cita con este director será todos los lunes, a las 5:00 p.m., en el Auditorio 38-110. La entrada es gratuita. Conoce toda la programación [**aquí**](https://www.instagram.com/culturaeafit/?hl=en).

###### Una cita semanal con los maestros de la ópera

Desde este miércoles 11 de febrero regresa la programación de Amar y Comprender la Ópera 2026-1, ciclo que, coordinado por la investigadora musical Luz Marina Monroy nos permitirá hacer un recorrido por las grandes efemérides y obras maestras de este género, denominado por muchos como el arte supremo por su capacidad de combinar música, teatro, canto y vestuario.

En la primera sesión se realizará una introducción a la programación. El encuentro del 18 de febrero estará dedicado a la obra _La Gioconda_, de Amilcare Ponchielli, una de las grandes óperas del repertorio italiano. Este encuentro se enmarca en dos efemérides significativas: los 140 años de la muerte del compositor y los 150 años del estreno de la obra en el teatro La Scala de Milán.

Amar y Comprender la Ópera se realiza todos los miércoles del semestre, a las 5:00 p.m., en la Sala de Audición Musical de la Biblioteca Luis Echavarría Villegas. Conoce toda la programación [**aquí**](https://www.instagram.com/culturaeafit/?hl=en).

###### Abro Hilo, el nuevo ciclo de poesía que EAFIT tiene para la ciudad

Abro Hilo será un espacio de conversación y análisis en torno a las formas breves de la literatura, como la poesía, el ensayo, la prosa poética y otros géneros similares. Este ciclo busca abrir preguntas, cruces y lecturas compartidas que permitan pensar la escritura desde su concisión y potencia expresiva.

A lo largo del semestre se abrirá un hilo distinto, en cada encuentro, con el propósito de tejer, con los asistentes, un paisaje diverso de voces y miradas. Esta nueva franja se realizará los martes, cada quince días, a las 5:00 p.m. El primer encuentro tendrá lugar el 10 de febrero, en el primer piso del bloque 18 y las primeras conversaciones estarán centradas en la conmemoración de los 50 años de la muerte de León de Greiff.

###### ¡Atentos en marzo y abril! Llega la nueva temporada de artes escénicas

En marzo, mes del teatro, se inaugurará un nuevo ciclo en EAFIT: la temporada Artes Vivas, que abre con la obra _Primer amor_, de Samuel Beckett. Esta puesta en escena, a cargo del Teatro Matacandelas, marca el inicio de la programación y propone un acercamiento contemporáneo a la obra de este dramaturgo, desde la palabra, la presencia escénica y la potencia de esta manifestación artística como experiencia viva.

De igual manera, como parte de este ciclo, en el mes abril, la temporada se amplía con _Balanceo en tres tiempos_, una obra que llega gracias a una colaboración con México y la Bienal de Danza de Cali, a propósito del mes de la danza. Será, en palabras de la programadora cultural Clara Cristina Acosta, “un espacio para celebrar la danza como lenguaje, encuentro y movimiento en escena”.

###### La Editorial EAFIT nos pondrá a hablar de literatura durante este semestre

Durante el primer semestre, la editorial llevará a cabo un conjunto amplio y diverso de actividades, que incluyen lanzamientos editoriales, participación en ferias del libro y presentaciones en diferentes espacios culturales.

En cuanto a las ediciones se destacan para este semestre la publicación de un nuevo título en la colección Biblioteca Fernando González; se trata de la tragicomedia del _Padre Elías y Martina la Velera_, un libro poco conocido de la obra del autor. Según Esteban Duperly, jefe de la Editorial, “este libro es una rareza de Fernando González, forma parte de esos textos donde ya empieza a escribir de forma muy extraña”.

También se publicará el libro _La Liturgia de los bosques_, de Darío Jaramillo Agudelo, ganador del premio León de Greiff. Esta edición tendrá ilustraciones originales y una introducción escita por el autor. Además, se tiene prevista la publicación de ocho libros a lo largo del semestre, que serán presentados progresivamente en librerías y actividades culturales.

Con respecto a la participación ferias y eventos, está confirmada la participación en la Feria Internacional de Libro de Bogotá (Filbo). Así mismo, en el mes de mayo la editorial también estará presente en la feria Popular del Libro en Carlos E. Restrepo. La agenda de la Editorial EAFIT se puede seguir a través de este [**enlace**](https://www.instagram.com/editorialeafit/?hl=en).

###### Un ciclo de conferencias para conmemorar el legado de Jorge Luis Borges

Con motivo de los cuarenta años de la muerte de Jorge Luis Borges, el ciclo de conferencias _Jorge Luis Borges y las ficciones del ensayo. 1986-2026_ propone un espacio de reflexión en torno al ensayo como género de creación y a su potencia imaginativa en la cultura contemporánea. La programación se articula como una conmemoración académica que invita a releer la obra borgeana desde los cruces entre pensamiento crítico y ficción.

El ciclo, a cargo del profesor Efrén Giraldo Quintero, de la Escuela de Artes y Humanidades, está compuesto por cuatro sesiones correspondientes a un curso del pregrado y la maestría en Literatura, que se realizarán de manera abierta al público.

A lo largo de las conferencias se abordarán temas como la hibridación entre ensayo y cuento, los límites difusos entre testimonio e invención, la docencia entendida como forma ensayística, y las artes plásticas como provocación para la escritura y la crítica.

La cita será una vez al mes, comenzando este lunes 16 de febrero, a las 6:00 p.m., en la Sala de Audición Musical de la Biblioteca Luis Echavarría Villegas. Y continuará el 16 de marzo, el 20 de abril y el 11 de mayo.

###### Lectura, patrimonio y encuentro en la Biblioteca de EAFIT

Durante el primer semestre de 2026, la Biblioteca Luis Echavarría Villegas presenta una agenda cultural amplia y diversa, articulada con su misión de fomentar la lectura, el acceso al conocimiento y la apropiación del patrimonio. La programación incluye espacios permanentes y eventos puntuales dirigidos tanto a la comunidad universitaria como a la ciudadanía, que consolidan a esta unidad como un lugar de formación, diálogo y encuentro.

Entre las actividades continuas se encuentra el Club de lectura, que iniciará el 19 de febrero y contará con 10 sesiones anuales, realizadas el tercer jueves de cada mes. La agenda también contempla el Trueque Literario, una iniciativa de intercambio de libros que se realizará en la tercera semana de abril, en el marco del Día del Libro y las Bibliotecas, y las actividades de patrimonio que visibilizan las colecciones históricas y documentales de la Institución. A través esta agenda, la Biblioteca refuerza su papel como punto de encuentro cultural.

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Esta es una vitrina para la proyección y divulgación del libro universitario](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/esta-es-una-vitrina-para-la-proyeccion-y-divulgacion-del-libro)

Septiembre 19, 2025

**Seguimos viviendo la Fiesta del Libro y la Cultura de Medellín y, antes de que se acabe este 21 de septiembre, recorrimos el Salón Iberoamericano del Libro Universitario (SILU) para conocer cómo se debate el futuro de las ediciones generadas por las editoriales de instituciones educativas de ocho países del continente y de España.**

**La Universidad, a través de la Editorial EAFIT, acude cada año a esta cita, afianzando los vínculos con otras instituciones de la ciudad y el país, y ayudando a consolidar este tipo de editoriales como generadoras de patrimonio intelectual, y actores estratégicos en la proyección internacional de la ciencia.**

*   [Lee más sobre Esta es una vitrina para la proyección y divulgación del libro universitario](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/esta-es-una-vitrina-para-la-proyeccion-y-divulgacion-del-libro "Esta es una vitrina para la proyección y divulgación del libro universitario")

Si bien el inglés continúa siendo la lengua predominante en la circulación del conocimiento científico, en los últimos años, desde Iberoamérica, ha surgido una propuesta que busca cambiar eso: el Acuerdo de Guadalajara. Este pacto, construido gracias a la colaboración y asociación entre editoriales universitarias de la región, busca visibilizar al español y al portugués como lenguas científicas, con más de 75 mil referencias, provenientes de 324 editoriales que evidencian que la producción científica en estos dos idiomas está llamada a tener un lugar destacado en el escenario internacional.

Sayri Karp Mitastein, directora de la Editorial de la Universidad de Guadalajara, y Esteban Duperly Posada, jefe de la Editorial EAFIT, guiaron una conversación sobre este tema, que hizo parte de la amplia programación del Salón Iberoamericano del Libro Universitario (SILU), uno de los espacios protagonistas de la Fiesta del Libro y la Cultura de Medellín.

Se trata de un espacio que surgió gracias a la participación de EAFIT y otras universidades de la región, y que se estrenó con la presentación de la Colección Bicentenario, en la que estas instituciones unieron esfuerzos para celebrar, con libros, los 200 años de la independencia del departamento.

###### ¿Qué hace especial el SILU?

La importancia del portugués y el español como lenguajes científicos no fue el único tema que se ha abordado en esta carpa, ubicada sobre la carrera Carabobo, justo a la entrada de la Fiesta. El papel de la inteligencia artificial en la edición de los libros, los derechos de autor en los tiempos actuales o la importancia de consolidar redes de trabajo en el continente también han sido protagonistas en este lugar que, desde su creación en 2015, está dedicado a tejer y fortalecer las relaciones en torno a los temas de edición, publicación, divulgación y circulación de los libros generados por las editoriales universitarias.

“Lo que hace especial este espacio universitario es que es una vitrina para los libros que siempre han sido considerados muy técnicos, especializados o de nicho, pero que también es necesario que existan y sean de utilidad para esas personas que se especializan en estos temas”, expresa Esteban Duperly, jefe de la Editorial EAFIT.

Además, el eafitense destaca que, si bien al comienzo los libros universitarios estaban orientados a saberes específicos, hoy en día la edición abarca diferentes frentes como la historia, la filosofía o la literatura. La Editorial EAFIT, por ejemplo, llega cada año a este encuentro con una selección de su catálogo, que abarca poesía, cuento, novela y otros géneros.

Y fruto de esa persistencia, Esteban señala que han surgido alianzas con las universidades de Los Andes, Nacional de Colombia o Externado, entre otras. Justamente algunas de las conversaciones este año estuvieron orientadas a la creación de una red iberoamericana de editoriales y de otra serie de plataformas que faciliten la circulación de las publicaciones, con el objetivo de resaltar el valor de las editoriales universitarias, no solo como productoras de libros, sino también como generadoras de patrimonio intelectual, y como actores estratégicos en la proyección internacional de la ciencia que se hace en la región, tanto en español como en portugués.

Este año, además, el Salón contó con un auditorio para charlas y conversaciones, y el tradicional túnel con la muestra comercial que reunió editoriales de diferentes universidades locales y nacionales, así como otros fondos similares de Brasil, Chile, Argentina, Ecuador, Perú, México y España.

Junto al SILU, la Fiesta del Libro cuenta con proyectos especiales como el Salón de las Editoriales Independientes, el Salón del Libro Infantil y Juvenil, y el Salón de Nuevas Lecturas.

###### Las voces de los participantes

Este es el primer año en el que Cristian Suárez Giraldo, jefe del Sello Editorial de la Universidad Católica de Oriente, participa en el Salón Iberoamericano del Libro Universitario.

Para él, se trata de una oportunidad única para reflexionar sobre los desafíos de su profesión, especialmente frente a temas como la inteligencia artificial, el avance de la tecnología o las mismas dinámicas de la edición universitaria.

“Pude encontrar una muestra enriquecida con el catálogo de tantas editoriales y fondos de instituciones nacionales e internacionales. Además de conversar sobre la importancia de fortalecer la Red de Editoriales Universitarias de Antioquia”, expresó el editor, quien además destacó la importancia de acercarse a diferentes tendencias del sector y establecer conversaciones con colegas editores para continuar apostándole a la literatura científica y cultural.

Imagen Noticia EAFIT

![Image 29: Seguimos viviendo la Fiesta del Libro y la Cultura de Medellín y, antes de que se acabe este 21 de septiembre, recorrimos el Salón Iberoamericano del Libro Universitario (SILU) para conocer cómo se debate el futuro de las ediciones generadas por las editoriales de instituciones educativas de ocho países del continente y de España.](https://universidadeafit.widen.net/content/051f5c85-200c-4398-99d1-51fa9b0e856b/web/Iberoamericano-2.jpg)

Leyenda de la imagen

El Salón Iberoamericano del Libro Universitario está ubicado en Carabobo, justo a la entrada de la Fiesta del Libro y la Cultura.

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

## [La vida poética de Darío Jaramillo y su encuentro con León de Greiff](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/la-vida-poetica-de-dario-jaramillo-y-su-encuentro-con-leon-de-greiff)

Septiembre 12, 2025

**El escritor colombiano recibe este viernes 12 de septiembre el Premio León de Greiff al Mérito Literario 2025, un homenaje a una obra que ha sabido entrelazar sensibilidad, memoria y palabra, dejando una huella profunda en generaciones de lectores.**

**En esta entrevista en video comparte la historia de cómo nació su amor por la literatura, los vínculos entrañables que lo han unido a León de Greiff desde la adolescencia y su manera de entender la inspiración como un misterio que irrumpe para transformar la vida.**

*   [Lee más sobre La vida poética de Darío Jaramillo y su encuentro con León de Greiff](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/la-vida-poetica-de-dario-jaramillo-y-su-encuentro-con-leon-de-greiff "La vida poética de Darío Jaramillo y su encuentro con León de Greiff")

Darío Jaramillo Agudelo tenía apenas 12 años cuando un libro de poesías completas de León de Greiff llegó a sus manos. Aunque confiesa que en ese entonces no entendía del todo lo que decían aquellos versos, recuerda con nitidez que lo invadía una extraña y poderosa satisfacción al leerlos, como si entre las palabras se abriera un territorio secreto en el que podía habitar.

Esa experiencia temprana sembró en él una necesidad de escribir que con los años se convertiría en vocación, y desde entonces la obra de De Greiff ha sido una presencia constante, un faro que lo ha acompañado en distintas etapas de su vida y de su carrera literaria.

Hoy, esas páginas que lo formaron en la adolescencia encuentran un eco renovado en la entrega del Premio León de Greiff al Mérito Literario, un galardón que la Universidad EAFIT y la Secretaría de Cultura Ciudadana de Medellín conceden, en el marco de la Fiesta del Libro y la Cultura, para reconocer la fuerza y la vigencia de una obra que ha enriquecido la tradición poética y narrativa de Colombia.

En esta conversación, Darío abre la puerta a su mundo creativo y evoca las lecturas y autores que lo marcaron, al tiempo que comparte su visión de la inspiración, que —según él mismo afirma— es “completamente arbitraria, surge cuando le da la gana”. Sus palabras nos recuerdan que la literatura es un espacio vital en el que lo cotidiano, lo íntimo y lo universal se entrelazan para dar forma a la experiencia humana.

[**Conoce a Darío Jaramillo**](https://www.youtube.com/watch?v=eyA29cyouAs&t=7s).

Imagen Noticia EAFIT

![Image 30: La vida poética de Darío Jaramillo y su encuentro con León de Greiff](https://universidadeafit.widen.net/content/1a3b5fe3-f575-4720-af5f-16eece7d7e61/web/Dario-Jaramillo-A.jpg)

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

## [Darío Jaramillo es el ganador del V Premio León de Greiff al Mérito Literario 2025​](https://www.eafit.edu.co/noticias/eafit-es-noticia/dario-jaramillo-es-el-ganador-del-v-premio-leon-de-greiff-al-merito)

Agosto 19, 2025

**• El galardón, organizado por EAFIT y la Secretaría de Cultura Ciudadana de Medellín, se le otorga a Darío Jaramillo por su obra poética consolidada y de amplio espectro, el trabajo renovador del lenguaje, su voz intimista y reflexiva, así como su influencia en generaciones de escritores, y su trayectoria en narrativa, ensayo y crítica.**

**• El anuncio se realizó este 19 de agosto y su entrega oficial se realizará en la inauguración de la Fiesta del Libro y la Cultura de Medellín, en septiembre. Este reconocimiento regresa para destacar a autores con una vida y obra consolidadas y reafirmar el compromiso de la ciudad con la literatura y la palabra escrita.**

*   [Lee más sobre Darío Jaramillo es el ganador del V Premio León de Greiff al Mérito Literario 2025​](https://www.eafit.edu.co/noticias/eafit-es-noticia/dario-jaramillo-es-el-ganador-del-v-premio-leon-de-greiff-al-merito "Darío Jaramillo es el ganador del V Premio León de Greiff al Mérito Literario 2025​")

El premio León de Greiff al mérito literario tiene un nuevo ganador: Darío Jaramillo Agudelo, una de las voces más reconocidas de la poesía colombiana contemporánea. Nacido en Santa Rosa de Osos en 1947, este poeta, narrador y crítico literario colombiano se ha convertido uno de los exponentes más reconocidos de la llamada generación de los desencantados, integrada por escritores que comenzaron a publicar en la década de 1970 y que, según la crítica, expresaron el desasosiego frente a la violencia bipartidista y las transformaciones sociales de la época.

Y como autor de más de 30 libros de poemas, entre los que se destacan _Historias_ (1974) y el célebre _Poemas de amor_(1986), ha incursionado también en la narrativa y en la crítica literaria, lo que le ha permitido obtener, a lo largo de su recorrido literario, distinciones como el Premio Nacional de Poesía, y el Premio Internacional de Poesía Federico García Lorca, entre otros.

El acta de este reconocimiento resalta, como méritos de Darío, “su obra poética consolidada y de amplio espectro; el trabajo renovador del lenguaje y su voz intimista y reflexiva; su trayectoria en la novela, el ensayo y la crítica literaria; el impacto de su obra en los ámbitos nacional e internacional y la influencia en generaciones posteriores de poetas; y su labor decidida como gestor, promotor cultural y editor”.​

###### La voz de los jurados​

Elkin Restrepo, poeta y ganador de este mismo reconocimiento en 2018; la escritora Andrea Cote Botero; y Alejandra Toro Murillo, doctora en estudios hispánicos y latinoamericanos y profesora del pregrado en Literatura de EAFIT, integraron el grupo de jurados del Premio León de Greiff. Su decisión se dio a conocer, este 19 de agosto, durante el lanzamiento de la Fiesta del Libro y la Cultura, en la terraza de la Casa de la Música, en el Parque de Los Deseos.

> La obra de Darío es muy importante para la literatura colombiana e internacional porque no se queda únicamente en la mirada histórica, sino que también explora una poesía profundamente interior, reflexiva y marcada por la conciencia de sí mismo, de la existencia y de la relación con el mundo”, expresa Alejandra Toro.

Y a estas palabras se suma Valeria Mejía Echeverría, directora de Narrativas y Cultura de EAFIT, quien lo define como “uno de los más grandes poetas colombianos y latinoamericanos, tanto del siglo XX como del XXI”.

> Creo que muchos, en momentos de despecho o soledad, hemos leído sus poemas, especialmente Poemas de amor. Pero Darío no solo es un referente de la poesía; también es una de las figuras más interesantes de la cultura en este país y un gran conocedor de la canción latinoamericana. Poesía y canción van de la mano, y él, además de su trayectoria poética con temas tan particulares como los gatos, ha sabido narrarnos muy bien a esa Latinoamérica a través de la música”, explica, Valería Mejía Echevarría.

###### Así se eligió al nuevo ganador del Premio León de Greiff​

En esta ocasión el Premio permitió que entidades culturales, academias, bibliotecas, editoriales y ONGs, entre otras instituciones de Colombia y el exterior, realizarán sus postulaciones. En el caso de Darío, este fue postulado por el Banco de la República y el Parque Biblioteca Tomás Carrasquilla-La Quintana.

Junto a Jaramillo también fueron tenidos en cuenta otros autores finalistas como Juan Manuel Roca, Felipe García Quintero, Inés Posada Agudelo, Marta Lucía Quiñonez, Rómulo Bustos Aguirre y Cristina Peri-Rossi.

Se trató, en palabras de los jurados que firmaron el acta, de un grupo excepcional de poetas con obras y trayectorias de cualidades suficientes para optar por este premio y que dan cuenta de la heterogeneidad y calidad de la poesía hispanoamericana en la actualidad.

La profesora y jurado Alejandra Toro resaltó el impacto que la obra _El cuerpo y otra cosa tuvo en su vida_: “Ese me pareció muy bueno e interesante, porque también muestra el progreso del escritor. Él siempre ha tenido temas para su poesía y no es alguien que se repita o caiga en fórmulas. Por el contrario, es un autor que se va renovando con las inquietudes de la existencia y de la experiencia misma”, señala.

Valeria Mejía Echeverría destaca el papel que tiene este premio para fortalecer el ecosistema cultural de la ciudad, especialmente ahora que Medellín está postulada a convertirse en Capital Mundial del Libro en 2027. Iniciativas como esta, dice, permiten avanzar en ese anhelo de convertir a la ciudad en epicentro de los libros y la literatura.

Además, resalta el hecho de que es un galardón que reconoce escritores con una vida y obra consolidadas, en un contexto que tiende a premiar únicamente a los jóvenes talentos. “Queremos que esos escritores que han dado tanto a la literatura y a la cultura del país y de Latinoamérica no se queden por fuera, y encontramos en la Alcaldía de Medellín a un aliado para seguir replicando sus voces. Lo que estamos diciendo a la sociedad es que nos importa la palabra escrita y que tenemos que seguir narrándonos y contándonos desde diferentes escenarios y perspectivas”.

> Con el apoyo de EAFIT hemos revivido el Premio León de Greiff, algo que nos llena de muchos orgullo porque el tema de este año es el mañana y que bueno que podamos seguir propiciando, juntos, la construcción de un mejor mañana a través de los libros, los encuentros y el reconocimiento de los autores nacionales y latinoamericanos", concluye Santiago Silva Jaramillo, secretario de Cultura Ciudadana.

Imagen Noticia EAFIT

![Image 31: Imagen premio León de Greiff Dario Jaramillo](https://universidadeafit.widen.net/content/f6a83864-97bb-4f8b-8ccd-831923f3ff1e/web/dariojaramillo.jpg)

Leyenda de la imagen

EAFIT y la Alcaldía de Medellín, a través de la Secretaría de Cultura Ciudadana y la Fiesta del Libro y la Cultura, unieron esfuerzos por traer de vuelta el reconocimiento. En la imagen Darío Jaramillo Agudelo. Fotografía: Juan Cristóbal Cobo​.

## Acerca de la quinta edición del Premio León de Greiff ​

En 2016, el primero en recibir este galardón fue el poeta venezolano Juan Calzadilla por su amplia trayectoria artística mezclando poesía y dibujo; en 2017 la argentina Luisa Valenzuela fue seleccionada por sus cuentos y novelas que cuestionaban el rol actual de la mujer en la sociedad y la realidad misma del lenguaje; en 2018 fue para el misterio, el amor, la cotidianidad y lo onírico en los poemas del antioqueño Elkin Restrepo; y, en 2019, el turno fue para Edgar Rodríguez y su particular visión de la identidad de Puerto Rico y el Caribe hispanohablante.

 Desde su creación el Premio León de Greiff reconoce, de manera intercalada, a un escritor en poesía y a un autor destacado en el campo de la narrativa. Este año el galardón premia, en su quinta edición, al poeta Darío Jaramillo con la oportunidad de publicar una antología representativa de su trayectoria, o una obra inédita, por parte de la Editorial EAFIT.

 En este 2025, EAFIT y la Alcaldía de Medellín (a través de la Secretaría de Cultura Ciudadana y la Fiesta del Libro y la Cultura) unieron esfuerzos por traer de vuelta el reconocimiento, que se entregará de manera oficial, al autor, en el evento de inauguración de la Fiesta del Libro y la Cultura, en septiembre.

![Image 32: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## ¿Por qué leer a Darío Jaramillo?​

“Como profesora de poesía siempre recomiendo leer poesía. Me parece que la poesía despierta el espíritu, nos invita a preguntarnos por más cosas y a mirar el mundo de otra manera, de forma contemplativa pero también reflexiva.

 En ese sentido, sugiero leer a todos los poetas posibles. Sin embargo, si hablamos de poetas colombianos Darío Jaramillo debe estar en la lista. Es un poeta en el que uno logra encontrarse a sí mismo, y ese es el gran impacto de su obra.

 Su lenguaje es sencillo; no abusa de la retórica, lo que permite que cualquier lector se acerque a sus textos. Aun así, sigue siendo una lectura inteligente y profunda, a pesar de la sencillez de su expresión”. 

 Alejandra Toro Murillo, profesora del pregrado en Literatura de EAFIT y jurado del V Premio León de Greiff.​​

![Image 33: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

Bloque para noticias recomendadas

Público Noticias

[Empleados administrativos](https://www.eafit.edu.co/taxonomy/term/1931)

[Estudiantes de posgrado](https://www.eafit.edu.co/taxonomy/term/1921)

[Graduados](https://www.eafit.edu.co/taxonomy/term/1936)

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Regresa el Cineclub EAFIT con lo mejor de Alfred Hitchcock](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/regresa-el-cineclub-eafit-con-lo-mejor-de-alfred)

Julio 10, 2025

**Desde este lunes 14 de julio, el Cineclub EAFIT regresa con una programación dedicada al maestro del suspenso: Alfred Hitchcock. Serán quince películas y una selección de episodios de la serie**_**Alfred Hitchcock presenta**_**.**

**Es la primera vez que el Cineclub EAFIT le rinde homenaje a un autor con una temporada completa. La cita será todos los lunes, a las 5:00 p.m., en el bloque 38, auditorio 110. La entrada es gratuita.**

*   [Lee más sobre Regresa el Cineclub EAFIT con lo mejor de Alfred Hitchcock](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/regresa-el-cineclub-eafit-con-lo-mejor-de-alfred "Regresa el Cineclub EAFIT con lo mejor de Alfred Hitchcock")

Dirigió 53 películas entre 1925 y 1976; le tocó el paso del cine mundo al sonoro; fue nominado cinco veces al Óscar, aunque no ganó ni una sola vez; y se convirtió en el más celebre director del género de suspenso. Con una carrera así, sorprende que uno de los datos más curiosos sobre Alfred Hitchcock es que nunca asistió a los estrenos de sus propias películas porque para él, como lo dijo en algunas entrevistas, “ya las había visto todas en su cabeza”.

Y fue gracias a ese nivel de cuidado en cada plano, reacción y emoción de los actores que, más de medio siglo después, algunas películas como _Psicosis_, _Los Pájaros o Vértigo_ se han convertido en clásicos de culto y siguen siendo revisitadas, de manera continua, por espectadores de todas las generaciones.

Ahora el turno, desde este lunes 14 de julio, será para los asistentes al Cineclub de EAFIT, que regresa este semestre con una programación completa dedicada a Hitchcock, el maestro del suspenso.

“Es, además, la primera vez que en más de 15 años de trayectoria este espacio cultural le rinde homenaje al cine de autor y lo hace con otra novedad, el regreso al auditorio 38-110, un lugar ligado al origen del Cineclub”, así lo expresa Clara Cristina Acosta Ossa, programadora Cultural de la Universidad.

En el ciclo llamado _Alfred Hitchcock, maestro del suspenso_, los asistentes tendrán la oportunidad de ver quince películas del inicio de este género, así como selección de episodios de la serie _Alfred Hitchcock presenta_, muy popular en los años 60s.

“Esta será una oportunidad para disfrutar en la pantalla grande imágenes clásicas y memorables, sonidos inolvidables, miedos inesperados. Esperamos que se animen, se apropien de este espacio y vengan a conocer otros mundos o a hacer amigos cinéfilos. El Cineclub de EAFIT tiene un público que se ha ido renovado, otros que son más asiduos y eso hace que para la Universidad sea una prioridad contar una programación que abarque todos esos intereses. Los esperamos”, puntualiza Clara.

La cita con la obra de Hitchcock será todos los lunes, a las 5:00 p.m., en el auditorio 38-110. La entrada es gratuita.

Imagen Noticia EAFIT

![Image 34: Regresa el Cineclub a EAFIT con lo mejor de Alfred Hitchcock](https://universidadeafit.widen.net/content/e43adfa5-cf31-4cdc-8773-0a675b63ea0b/web/Ciclo-de-cine.jpg)

Leyenda de la imagen

La imagen corresponde a una de las presentaciones del Cineclub EAFIT. 

#### Esta es la programación completa

###### Julio

14 _Los 39 escalones_, 1935

21 _La dama desaparece_, 1938

28 _Rebeca_, 1940

###### Agosto

4 _La sombra de una duda_, 1943

11 _El caso Paradine_, 1947

25 _Alfred Hitchcock presenta_ (selección de episodios)

###### Septiembre

1 _La soga_, 1948

8 _Extraños en un tren_, 1951

15 _Yo confieso_, 1953

22 _Con M de muert_ e, 1954

29 _Atrapa un ladrón_, 1955

###### 0ctubre

6 _¿Quién mató a Harry?_, 1955

20 _El hombre que sabía demasiado_, 1956

27 _Psicosis_, 1960

###### Noviembre

10 _Los pájaros_, 1963

24 _Frenesí_, 1972

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

## [Bienvenidos nuevos tesoros del maestro Carlos Vieco a la Sala de Patrimonio Documental de EAFIT](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/bienvenidos-nuevos-tesoros-del-maestro-carlos-vieco)

Junio 26, 2025

**Más de tres mil partituras, cartas, condecoraciones, documentos y fotografías del compositor colombiano se sumaron recientemente a los otros objetos del músico que ya eran custodiados por la Universidad. Los nuevos tesoros, entre los que se encuentra la partitura original de**_**Echen pal morro**_**, fueron donados por su familia.**

**Gloria Vieco y Tulia Marín Vieco, hija y sobrina nieta del maestro, respectivamente, nos cuentan en este video más sobre la vida del compositor y los documentos, mientras que el investigador musical Fernando Gil ayuda a entender su trascendencia para la historia cultural del país.**

*   [Lee más sobre Bienvenidos nuevos tesoros del maestro Carlos Vieco a la Sala de Patrimonio Documental de EAFIT](https://www.eafit.edu.co/noticias/eafit-es-noticia-lo-que-esta-pasando/bienvenidos-nuevos-tesoros-del-maestro-carlos-vieco "Bienvenidos nuevos tesoros del maestro Carlos Vieco a la Sala de Patrimonio Documental de EAFIT")

Imagen Noticia EAFIT

![Image 35: Bienvenidos nuevos tesoros del maestro Carlos Vieco a la Sala de Patrimonio Documental de EAFIT](https://universidadeafit.widen.net/content/aceaa4ef-f6c7-44d8-bc0b-fb087dd20e14/web/Partitura-Carlos-V1900.jpg)

Leyenda de la imagen

La más reciente donación complementa el Fondo Carlos Vieco, una colección que reúne miles de partituras y otros objetos de gran valor cultural.

Categoría de noticias EAFIT

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)

Sección de noticias EAFIT

[EAFIT es noticia](https://www.eafit.edu.co/taxonomy/term/1901)

[Lo que está pasando](https://www.eafit.edu.co/taxonomy/term/1876)

Bloque para noticias recomendadas

Dependencias

[EAFIT Medellín](https://www.eafit.edu.co/taxonomy/term/1986)

#### Paginación

*    Página 1 
*   [Siguiente página››](https://www.eafit.edu.co/taxonomy/term/1826?page=1 "Ir a la página siguiente")

[Suscribirse a Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826/feed)

![Image 36: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 37: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 38: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 39: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 40: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 41: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 42: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 43: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 44](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
