Title: Investigación

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion

Markdown Content:
# Investigación - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#main-content)

[![Image 4: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 5: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#)

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion# "Spanish")[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion# "English")

 Información para ti

[![Image 9: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 10: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 11: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 12: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 13: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 14: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 15: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 16: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 17: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 18: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 19: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 20: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 21: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 22: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 23: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 24: Imagen de banner estudiantes investigando ](https://universidadeafit.widen.net/content/fc3f0a92-541d-40df-9e49-0cf1bbd66cce/web/imagen-investiga.jpg?crop=yes&k=c&w=1920&h=788&itok=pulntC6S)

# Investigación

Somos conocimiento en acción

 Dinamizamos la generación de conocimiento que transforme la sociedad, potenciando las capacidades del ecosistema de ciencia, tecnología e innovación a través de la gestión del ciclo de vida de la investigación.

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*    Investigación 

Capacidades

![Image 25: Imagen Semilleros de investigación](https://universidadeafit.widen.net/content/6f345d3e-4ed3-450d-af7f-43c614961e31/web/imagen-semilleros-investigacion.jpg?crop=yes&k=c&w=409&h=193&itok=RgMh4J4x)

Semilleros de investigación

Buscan cultivar vocaciones científicas en estudiantes de pregrado a través de iniciativas y proyectos que inspiran el interés, promueven la investigación y desarrollan competencias para formar investigadores.

[Ver semilleros de investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/nuestros-semilleros)

![Image 26: Imagen Grupos de investigación](https://universidadeafit.widen.net/content/814cace7-7db5-4a34-a3fa-9ff4d90fc7af/web/imagen-grupos-investigacion.jpg?crop=yes&k=c&w=409&h=193&itok=TjZy-AcW)

Grupos de investigación

EAFIT cuenta con 30 grupos de investigación reconocidos por Minciencias, aportando a la generación de conocimiento que transforma la sociedad.

[Ver grupos de investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/grupos-investigacion)

![Image 27: Imagen Profesores e investigadores](https://universidadeafit.widen.net/content/edf9a18e-474b-40fc-aa61-4dfb75214f98/web/imagen-profesores.jpg?crop=yes&k=c&w=409&h=193&itok=qmtbXt7b)

Profesores e investigadores

Conoce a los profesores e investigadores que están transformando el mundo con sus descubrimientos.

[Ver profesores](https://www.eafit.edu.co/nuestros-profesores)

![Image 28: Imagen Lineamientos](https://universidadeafit.widen.net/content/8c65f6fc-44f5-4c3a-9dae-380a659344ae/web/imagen-lineamientos.jpg?crop=yes&k=c&w=397&h=253&itok=_y_BxKa6)

Lineamientos

Encuentra aquí información de tu interés para el desarrollo de las actividades en CTeI.

[Ver lineamientos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/lineamientos)

#### **Infraestructura para la investigación**

**En EAFIT, la investigación es un pilar fundamental.**

Contamos con una amplia infraestructura física y tecnológica, diseñada para apoyar el desarrollo de proyectos innovadores y de alto impacto.

[Sistemas de información para la investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#4257225834-711007752)

Sistemas de información para la investigación

![Image 29: Imagen Investiga ](https://universidadeafit.widen.net/content/260b4199-1861-4fb1-938b-f1d6887dca8c/web/banner-principal-investigacion.jpg?crop=yes&k=c&w=397&h=253&itok=2Lz1rMUI)

Investiga

[Ver Investiga](https://app.eafit.edu.co/investiga/)

![Image 30: Imagen Plataforma 𝝅 (PI)](https://universidadeafit.widen.net/content/15c01c13-e54d-441b-8456-73573c55324a/web/plataforma-pi.jpg?crop=yes&k=c&w=397&h=253&itok=gboeAkSs)

Plataforma 𝝅 (PI)

[Ver Plataforma 𝝅 (PI)](https://eafit.fundanetsuite.com/IFundanet/Identificacion/IdentificacionFrw.aspx)

[Laboratorios](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#4257225834-2835615176)

Laboratorios

![Image 31: Imagen Centro de Laboratorios ](https://universidadeafit.widen.net/content/8026c792-7c18-45bc-baba-b32bad754789/web/imagen-laboratorios.jpg?crop=yes&k=c&w=397&h=253&itok=AdR6SK5a)

Centro de Laboratorios

[Ver Centro de laboratorios](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#)

![Image 32: Imagen MercaLAB](https://universidadeafit.widen.net/content/2ed5a73b-8273-4bef-866f-606ec765d9f5/web/imagen-mercaLAB.jpg?crop=yes&k=c&w=397&h=253&itok=moiv5p72)

MercaLAB

[Ver MercaLAB](https://www.eafit.edu.co/escuela-administracion/mercalab)

![Image 33: Imagen MediaLAB](https://universidadeafit.widen.net/content/a8c30c27-d1ea-473e-99bf-e87eceedaaaf/web/imagen-mediaLAB.jpg?crop=yes&k=c&w=397&h=253&itok=tWnIMHnk)

MediaLAB

[Ver MediaLAB](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#)

[Apolo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#4257225834-3834459597)

Apolo

![Image 34: Imagen Centro de Computación Científica Apolo](https://universidadeafit.widen.net/content/0bad0013-22e0-4604-9d14-ee1b61645e4d/web/imagen-apolo.jpg?crop=yes&k=c&w=397&h=253&itok=BijJQrtE)

Centro de Computación Científica Apolo

[Ver Apolo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/apolo)

[Biblioteca](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#4257225834-1229808762)

Biblioteca

![Image 35: Imagen Centro Cultural Biblioteca Luis Echavarría Villegas](https://universidadeafit.widen.net/content/e06ba51c-0167-4893-ab3c-7f289995eea6/web/imagen-biblioteca.jpg?crop=yes&k=c&w=397&h=253&itok=K91sN1UI)

Centro Cultural Biblioteca Luis Echavarría Villegas

[Ver Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

#### **Cifras de impacto**

## 29

grupos de investigación reconocidos por Minciencias

## 86%

de los grupos en las máximas categorías de Minciencias

## 104

semilleros de investigación

![Image 36: Imagen 29](https://universidadeafit.widen.net/content/b48df7c9-56ec-4639-aecf-ef8108f61dec/web/banner-principal-portafolio-servicios.jpg)

## Servicios internos

[Gestión Grupos de investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#4257225834-1974262731)

Gestión Grupos de investigación

Acompañamos la actualización y gestión del CVLAC y GrupLac para el proceso de reconocimiento de grupos e investigadores ante Minciencias y facilitamos los recursos de apoyo, capacitación, orientación y generación de conexiones con los entornos para el desarrollo de investigaciones que transformen la sociedad.

[Actualiza tu currículo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/gestion-grupos-investigacion/actualizacion-gestion-cvlac)

[Comité de ética en investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#4257225834-1094634743)

Comité de ética en investigación

Si vas a realizar una actividad de investigación, te orientamos y apoyamos en la evaluación para que tu propuesta esté basada en principios éticos que garanticen la protección de los derechos y bienestar de los seres vivos participantes y el cuidado del entorno (medio ambiente).

[Conoce más sobre el Comité de ética en investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/comite-etica-investigacion)

[Permisos Biodiversidad](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion#4257225834-4062922329)

Permisos Biodiversidad

Si eres profesor y/o investigador y necesitas realizar prácticas de campo de asignaturas, o actividades que implican recolección de especímenes de especies silvestres te apoyamos para tramitar y gestionar adecuadamente los permisos.

[Conoce los Permisos de Biodiversidad](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/permisos-biodiversidad)

## Convocatorias

Descubre las convocatorias de la Universidad EAFIT y entidades externas que impulsan la producción científica.

[Ver nuestras convocatorias](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/convocatorias-eafit)

![Image 37: Imagen Convocatorias](https://universidadeafit.widen.net/content/bb04f3a9-ad84-43b5-bd6f-2a4369445a73/web/imagen-convocatorias.jpg?crop=yes&k=c&w=463&h=450&itok=j_XATbGm)

Contacto 

¿Quieres saber más?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono de contacto*? 

Correo electrónico*? 

Ciudad de residencia*? 

Contenido de interés 

Cuéntanos, ¿Qué deseas saber?*? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 38](https://universidadeafit.widen.net/content/6fad7dcb-aed6-449f-bd5e-53ca6e2d1934/web/formulario-registro-tecnologias.jpg?crop=yes&k=c&w=470&h=272&itok=zTW5wZ54)

![Image 39: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 40: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 41: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 42: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 43: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 44: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 45: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 46: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 49](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
