Title: Exploradores de la geología regional

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion/exploradores-de-la-geologia-regional

Markdown Content:
**Beatriz Elena García Nova**

**Colaboradora​ / Semilleros​**

Conjuntos de rocas cercan el escritorio de María Isabel Marín Cerón. Tal vez estén allí temporalmente estos paquetes y vayan camino a la colección de rocas, minerales y fósiles de la Universidad. Lo que sí es permanente es el interés de la investigadora por la historia de millones de años que es posible encontrar en estos elementos, que para ella no parecen inertes.

Este marcado interés desde el pregrado que Marín hizo en Ingeniería Geológica en la Universidad Nacional de Medellín la llevó hasta la isla de Honsh, en el Japón, becada por el Banco Interamericano de Desarrollo, y la trajo de vuelta tras finalizar su maestría y su doctorado.

En su maleta lo principal para llevar a ese viaje fueron rocas volcánicas de Nariño, que analizó desde la distancia con avanzadas técnicas. “Con lo que trabaja el geólogo es con la información que toma en el campo y con las rocas, entonces me las llevé, las analicé ¡y ya!”, dice haciendo parecer tan sencillo algo que no lo es realmente.

Ejemplo del tipo de estudios que desarrollan con el Grupo de investigación en Geología Ambiental e Ingeniería Sísmica y el Semillero en Geoquímica y Geología Regional son una serie de proyectos que les han permitido conocer la formación de la cuenca carboní- fera de Amagá (en conjunto con la profesora Gloria Sierra), durante lo que se conoce como orogenia andina, proceso formador de la cordillera de los Andes.

Alrededor de seis trabajos de grado tomaron forma a partir de un completo análisis sobre cómo se formó la cuenca. Unos se han centrado en cómo se depositaron los sedimentos –cómo se formó el carbón, las edades–, después otros en cómo ha variado, o se ha conformado esa cuenca, otros en cómo se levantó y, finalmente, en cómo eso ha afectado la formación de gas asociado al carbón y si se conservan o no cantidades importantes de gas que puedan ser explotados en el futuro.

​El foco de estos grupos está puesto especialmente en la geología regional. Todo estudiante que toma clases con María Isabel es invitado a hacer parte del Semillero en Geoquímica y Geología Regional, con el propósito de lograr que se establezca una cadena de investigación que inicie desde los primeros semestres hasta llegar al doctorado en Ciencias de la Tierra que ofrece EAFIT. “La cadena completa es: semillero, trabajo de grado, joven investigador, maestría y doctorado”, sintetiza ella.

###### Georrutas interactivas​

El semillero se centra en guiar a los estudiantes en el desarrollo de avances sobre geología regional y, adicionalmente, están incursionando en una línea de investigación en patrimonio geológico. Dos proyectos son representativos de este grupo, uno relacionado con georrutas y otro con la georreferenciación de rocas de la colección que tiene el Departamento. Ambos nacen de la necesidad que vio la investigadora de herramientas pedagógicas más proactivas y menos estáticas​​​.​​

El primer proyecto mencionado consiste en hacer georrutas, trabajo para el que primero deben identificar los sitios de interés y de importancia geológica en el ámbito nacional para luego ubicar toda la información en un libro interactivo que están sintetizando con ayuda de Proyecto 50, programa que apoya el desarrollo de competencias para la innovación educativa en EAFIT.

​“Consideramos que en Colombia hay muchos sitios de gran importancia a los que cuando los turistas van no tienen la posibilidad de conocer cómo se formó allí el territorio, como sí sucede en los Estados Unidos y en Europa donde los parques naturales cuentan con explicaciones muy sencillas. Será una forma de transferencia de conocimiento”, expone la investigadora.

Por ejemplo, la georruta hacia el Oriente antioque- ño incluye cómo se formó la Piedra del Peñol en Guatapé. La idea sería explicar cómo las placas se mueven, generan magmas que suben desde el interior de la Tierra, luego se enfrían y forman una roca que sale a la superficie, empiezan procesos erosivos y de meteorización, para dejar con el tiempo masas de rocas que sobresalen en el paisaje, conocidas como “Inselberg”.

“Ese proyecto nace de la iniciativa de uno de mis estudiantes que estaba muy interesado en la parte gráfica, fotográfica y patrimonio geológico. Por eso, estamos haciendo una especie de colección de georrutas, entre las cuales está el Oriente an​tioqueño”, cuenta Marín y agrega que, más allá de Antioquia, van a georrefenciar sitios como el Parque Nacional Natural de los Nevados.

Proyecto 50 les está colaborando en plasmar la información de forma que el libro interactivo sirva para que cualquier persona pueda seguir mediante enlaces las rutas de interés, que puedan contar con una guía, más que turística, científica e histórica.

###### Atlas de rocas metamórficas​

Un proyecto adicional es el Atlas de rocas metamórficas. Los estudiosos de la Geología escogen la roca y hacen secciones delgadas para ver los minerales que la conforman y sus texturas. Con base en esto describen cómo ha sido el proceso de formación y deformación de la roca en el tiempo.

Pero, según explica la docente, a veces no es fá- cil para los estudiantes entender estas conformaciones, puesto que hay rocas muy complejas. Por esto, se decidió emprender un proceso con el semillero que incluye tomar las rocas que hay en la colección de rocas del laboratorio de geología, con el fin de georreferenciarlas, organizarlas y ponerlas en un libro que se convierta en una herramienta pedagógica para el entendimiento de las rocas metamórficas.

En palabras de la docente: “se está construyendo un mapa completo de Colombia donde aparecen los sitios que nosotros tenemos de muestras, con su caracterización y análisis”.​

###### Un terreno bien abonado​

​​Además de trabajos de grado y de las actividades del semillero, han logrado llevar a varios estudiantes y profesores a prácticas y pasantías en universidades internacionales de países como Canadá, Japón y Francia.

Igualmente, los vínculos con semilleros de investigación de otras universidades colombianas han permitido intercambios entre estudiantes de EAFIT y de las universidades Nacional, Caldas e Industrial de Santander.​

Y aunque el semillero es el primer eslabón investigativo en el que se pueden involucrar los estudiantes de Geología en la Universidad, este grupo, conformado por entre 20 y 25 estudiantes, ha dado varias muestras de su madurez y calidad.

“Hemos tenido una mención de honor en el evento regional y de semilleros de investigación. La mención de honor que tuvimos en el ámbito nacional nos permitió a su vez la participación en el evento latinoamericano”, dice María Isabel, refiriéndose a los encuentros regionales de investigación y a la Mención de Honor que obtuvieron en el Encuentro Nacional de Semilleros de Investigación de 2013, con la que les fue otorgado el aval para participar de la VII Expo Ciencia Latinoamericana en la Universidad EAFIT en julio de 2014.

​Han sido cofinanciados por entidades como Colciencias, la Agencia Nacional de Hidrocarburos y el Departamento de Geología de la Universidad. Y aunque María Isabel se siente en época de siembra, pues está en EAFIT desde 2008, los proyectos emprendidos y los reconocimientos que han logrado parecen evidenciar una ruta clara.

###### Investigadora​

**María Isabel Marín Cerón**

Ingeniera geológica, Universidad Nacional; especialista y magíster en Ingeniería Sanitaria y Ambiental, Universidad del Valle; magíster en Ciencias de la Tierra, Universidad de Shimane, y PhD en Ciencias de la Tierra e Ingeniería Ambiental, Universidad de Okayama. Adicionalmente es coordinadora de la Red Nacional de Laboratorios de Geociencias (RNLG) y en EAFIT es docente, investigadora y coordinadora del Grupo de investigación Geología Ambiental e Ingeniería Sísmica y del Semillero en Geoquímica y Geología Regional.

###### Departamento de Geología

El Departamento de Geología administra y maneja los contenidos de la carrera de Geología, las especializaciones propias de esta área y la maestría en Ingeniería, común para todas las ingenierías. Cuenta con dos grupos de investigación: Ciencias del Mar y Geología Ambiental e Ingeniería Sísmica. También con un semillero de investigación: Geoquímica y Geología Regional.
