Title: 

URL Source: https://www.eafit.edu.co/sites/default/files/2026-04/Campoenjuegofoto%20(1).jpg

Warning: Target URL returned error 403: Forbidden
Warning: This page contains iframe that are currently hidden, consider enabling iframe processing.

Markdown Content:

