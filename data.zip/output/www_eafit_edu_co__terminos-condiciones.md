Title: Términos de uso

URL Source: https://www.eafit.edu.co/terminos-condiciones

Markdown Content:
Para publicar y hacer uso de cualquier tipo de contenido visual y/o informativo en el Sistema de Portales Web Institucionales, usted debe leer y aceptar los términos que se establecen en las presentes condiciones de uso. Además se compromete a adoptar las medidas que se mencionan, con el fin de hacer un buen uso del mismo.

El sitio será utilizado por personas capaces de responder por sus conductas. A continuación se enuncian algunas de las medidas que deben tener en cuenta los usuarios para el uso de la misma:

​No publique datos o información personal que no desea que conozcan terceros.

No tolere comportamientos que atenten contra el orden público y las buenas costumbres.

No añada contenidos pornográficos o alusivos a la violencia, racismo, terrorismo, y/o discriminación o en general que atenten contra los derechos humanos.

No envíe mensajes Spam, no distribuya virus informáticos, ni trate de eludir las medidas de protección tecnológica.

No realice publicidad de productos o servicios.

No contravenga la legislación, ni la propiedad intelectual de la Universidad EAFIT o de terceros.

Respete a los usuarios de la red, su privacidad y sus opiniones.

No divulgue su contraseña de acceso a la red y al Sistema de Portales Web Institucionales de la Universidad.

Proporcione información veraz.

El contenido publicado en el sitio es responsabilidad de cada usuario que publica.

Los usuarios expresamente manifiestan que se comprometen a respetar los derechos de propiedad intelectual de la Universidad EAFIT y/o de terceros, o que en caso de utilizar material de estos, deberán contar con la autorización necesaria para su uso y cumplir con la debida referenciación y hacer uso correcto del derecho de cita. En caso contrario, el usuario responderá por los daños y perjuicios que puedan causar, manteniendo en todo caso indemne a la Universidad.

La Universidad EAFIT no se hace responsable por los contenidos que alojen los usuarios en el Sistema de Portales Web Institucionales toda vez que no tiene ningún control ni puede garantizar la seguridad o legalidad de los contenidos que los usuarios alojen allí.

La Universidad EAFIT no se hace responsable de las opiniones o conductas que tengan sus usuarios, cada uno responderá por las mismas.

La Universidad EAFIT no garantiza que el contenido que se publique en el sitio, no pueda ser visto por personas no autorizadas, toda vez que estas, eventualmente, podrán violar las medidas de seguridad o privacidad establecidas, sin que la Universidad EAFIT tenga control sobre sus actividades.

Asimismo, la Universidad no se hace responsable por el uso que puedan dar los usuarios de la información depositada por otros usuarios de la red.

La Universidad no se hace responsable por ningún daño especial, indirecto o consecuente; originado, directa o indirectamente, por el uso del sitio, por ataques de terceros o por imposibilidad de uso de sitios, servicios y herramientas de la Universidad, entre otros.

Las demás acciones legales, por presunta violación a derechos propios o de terceros, deberán ser ejercidas por el directamente afectado, por lo tanto, la Universidad no adquiere ningún compromiso para esto.

En caso de generarse alguna disputa entre los usuarios o entre un usuario y terceros, usted manifiesta con la aceptación de las presentes condiciones de uso, que libera de toda responsabilidad a la Universidad EAFIT, manteniéndola por tanto indemne ante cualquier tipo de reclamación.

La Universidad EAFIT no podrá utilizar la información que se almacena en el sitio para fines diferentes a los académicos e institucionales establecidos para el uso del mismo, a no ser que el autor o usuario lo haya autorizado expresamente o que sea obligado por una autoridad judicial.

La Universidad no se hace responsable ni tiene control sobre links, enlaces o hipervínculos que los usuarios pongan en el sitio. Cada usuario deberá contar con la autorización para su uso.

Enlaces a sitios web de terceros por fuera del dominio www.eafit.edu.co, son ofrecidos como un servicio a los usuarios, pero la Universidad EAFIT no es responsable del contenido en dichas páginas.

Por favor informe oportunamente de problemas, contenidos ofensivos, y en general, las violaciones que se presenten a sus derechos o a derechos de la Universidad EAFIT y/o terceros, notificando a nuestro equipo a través del correo de contáctenos, para tomar las medidas necesarias.

Nuestro equipo, en caso de considerarlo pertinente, podrá suspender o poner fin al servicio cuando existan posibles responsabilidades legales o cuando se contravengan las condiciones de uso.

Cuando se han presentado posibles responsabilidades legales o cuando se contravengan las condiciones de uso, la Universidad EAFIT enviará un correo electrónico al destinatario para darle a conocer la razón.

Las condiciones establecidas podrán ser modificadas en cualquier momento, poniendo las condiciones nuevas en este sitio, las cuales entrarán en vigencia a partir de su publicación.

Las controversias que se susciten entre los usuarios y entre estos y la Universidad serán resueltas directamente por las partes, por tal razón, el usuario se comunicará al correo [comunicaciones@eafit.edu.co](mailto:comunicaciones@eafit.edu.co) a fin de poder aclarar la situación y llegar a un acuerdo.

En caso de no poder llegar a un acuerdo, la legislación aplicable para el efecto será la colombiana.

La información sobre la política de protección de datos personales la encuentra en esta [dirección](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales).

Los contenidos tales como textos, imágenes fijas o en movimiento, videos, gráficos, programas informáticos y demás que se encuentren en el sitio y que constituyan propiedad intelectual de la Universidad EAFIT, no podrán ser utilizados por los usuarios o por terceros, sin el consentimiento escrito y expreso de la Universidad y del autor. Esto aplica además, para las marcas, signos distintivos, enseñas y logos de su propiedad.

Por lo anterior, queda prohibida la reproducción, transformación, adaptación, uso, distribución, comunicación pública, traducción, en cualquier medio conocido o por conocer, de los contenidos propiedad de la Universidad.

La Universidad EAFIT vela porque su Sistema de Portales Web Institucionales sea fuente de información actualizada y de interés para los usuarios. Sin embargo, la Universidad no puede garantizar que esta información esté exenta de errores o información imprecisa. En tales casos, los usuarios pueden solicitar a EAFIT realizar las correcciones respectivas. De igual manera, la Universidad EAFIT no puede garantizar que la información del Sistema de Portales Web Institucionales sea suficiente y útil según las necesidades del usuario.

###### Términos y condiciones de uso del sitio web de donaciones

​**Con la utilización del sitio web de donaciones, de la Universidad EAFIT, el usuario declara expresamente que conoce y acepta los términos y condiciones de uso a continuación descritos.**

**Limitación de la responsabilidad**

La Universidad EAFIT no se hace responsable por los contenidos que alojen los usuarios en el sitio web de donaciones toda vez que no tiene ningún control ni puede garantizar la seguridad o legalidad de los contenidos que los usuarios alojen allí.

**Propiedad Intelectual**

Los contenidos tales como textos, imágenes fijas o en movimiento, videos, gráficos, programas informáticos y demás que se encuentren en el sitio web de donaciones y que constituyan propiedad intelectual de la Universidad EAFIT, no podrán ser utilizados por los usuarios o por terceros, sin el consentimiento escrito y expreso de la Universidad y del autor. Esto aplica, además, para las marcas, signos distintivos, enseñas y logos de su propiedad.

**Pagos en línea**

La Universidad EAFIT no es una entidad financiera, ni un intermediario financiero, ni ofrece un producto financiero. Por lo cual la utilización de la plataforma de pagos se hace de acuerdo con sus propias reglamentaciones, así como las del banco del usuario del servicio.

**Autorización para el tratamiento de datos personales**

La Universidad EAFIT como institución que almacena, y recolecta datos personales requiere obtener la autorización por parte del donante para que de manera libre, previa, expresa, voluntaria, y debidamente informada, permita a todas las dependencias académicas y/o administrativas, recolectar, recaudar, almacenar, usar, circular, suprimir, procesar, compilar, intercambiar, dar tratamiento, actualizar y disponer de los datos que han sido suministrados y que se han incorporado en distintas bases o bancos de datos, o en repositorios electrónicos de todo tipo con que cuenta la Universidad. Esta información es, y será utilizada en el desarrollo de las funciones propias de la Universidad en su condición de institución de educación superior.

Al aceptar estos términos y condiciones, el usuario autoriza de manera previa, expresa e inequívoca que sus datos personales sean tratados conforme a lo previsto en el presente documento y/o autorización y conforme a la política de protección de datos personales de la Universidad EAFIT la cual se encuentra en la dirección: [www.eafit.edu.co/datospersonales](https://www.eafit.edu.co/datospersonales).

**Declaración de origen de los recursos del donante**

El donante declara bajo la gravedad del juramento que los recursos que a título de donación entrega a la Universidad de EAFIT, provienen del giro ordinario de los negocios derivados de su actividad económica o su objeto social y que no son producto de actividades ilícitas. En el evento en que las autoridades competentes efectúen algún requerimiento a la Universidad con respecto a los recursos donados, el donante queda obligado a responder ante las mismas.

De igual forma el donante declara que es legalmente capaz de realizar el acto jurídico y que es el propietario y/o autorizado del medio de pago utilizado para realizar la donación.

Toda donación estará sujeta a una aceptación por parte de la Universidad EAFIT.

**Modificaciones en las condiciones de uso**

Las condiciones establecidas podrán ser modificadas en cualquier momento, poniendo las condiciones nuevas en este sitio, las cuales entrarán en vigencia a partir de su publicación.

En caso de dudas o de requerir más información le invitamos a contactar al Centro de Filantropía al teléfono 2619500 extensión 9297 o al correo [cfilantropia@eafit.edu.co](mailto:cfilantropia@eafit.edu.co).
