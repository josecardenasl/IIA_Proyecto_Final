Title: logo_EAFIT_negro.svg

URL Source: https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg

Published Time: Tue, 30 Jul 2024 20:27:15 GMT

Markdown Content:
# logo_EAFIT_negro.svg

A 134x50 small image, likely a logo, icon or avatar
