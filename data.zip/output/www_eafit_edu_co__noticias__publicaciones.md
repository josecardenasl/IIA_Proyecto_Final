Title: Publicaciones

URL Source: https://www.eafit.edu.co/noticias/publicaciones

Published Time: Fri, 08 May 2026 15:58:22 GMT

Markdown Content:
# Publicaciones - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/noticias/publicaciones#main-content)

[![Image 3: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 4: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/publicaciones#)

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/publicaciones# "Spanish")[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias/publicaciones# "English")

 Información para ti

[![Image 8: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 9: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 10: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 11: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 12: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 13: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 14: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 15: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 16: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 17: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 18: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 19: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 20: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 21: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 22: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

# Publicaciones

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

## Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar

En un momento en que el sistema energético atraviesa cambios profundos y acelerados, el sector se reunió el pasado 16 de abril en la Cámara de Comercio de Medellín para mirar hacia adelante.

[Ver noticia](https://www.eafit.edu.co/noticias/lo-que-esta-pasando-publicaciones/nueva-fase-para-la-energia-en-america-latina-ya-no-se "Ver noticia")

Abril 20, 2026

![Image 23: Imagen Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://universidadeafit.widen.net/content/1e26403e-34ad-44fd-98d4-b1ff716a698f/web/Nueva-fase-energia.jpg?crop=yes&k=c&w=944&h=540&itok=zaET0liV)

*   [Inicio](https://www.eafit.edu.co/)
*   [Noticias](https://www.eafit.edu.co/noticias)
*    Publicaciones 

Filtros

*   [Septiembre 2020](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2020-09)
*   [Enero 2022](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2022-01)
*   [Marzo 2021](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2021-03)
*   [Mayo 2022](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2022-05)
*   [Abril 2026](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2026-04)
*   [Julio 2025](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2025-07)
*   [Marzo 2026](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2026-03)
*   [Octubre 2025](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=fecha%3A2025-10)

Facet Fecha publicaciones 

*   [Graduados(2)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=publico_noticias%3A1936)
*   [Empleados administrativos(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=publico_noticias%3A1931)
*   [Estudiantes de posgrado(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=publico_noticias%3A1921)
*   [Estudiantes de pregrado(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=publico_noticias%3A1916)
*   [Profesores(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=publico_noticias%3A1926)

Facet Público Noticias publicaciones 

*   [Revista Descubre y Crea(27)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A2196)
*   [Sociedad y democracia(2)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1831)
*   [Arte y cultura(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1826)
*   [Educación y futuro(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1836)
*   [Empresas y negocios(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1856)
*   [Inclusión y diversidad(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1841)
*   [Investigación(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A2626)
*   [Revista El Eafitense(1)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A2231)
*   [Alcampus(0)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A3121)
*   [Cuidado y bienestar(0)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1821)
*   [Emprendimiento(0)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1851)
*   [Institucional(0)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1846)
*   [Medioambiente y cambio climático(0)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1816)
*   [Tecnología e innovación(0)](https://www.eafit.edu.co/noticias/publicaciones?f%5B0%5D=categoria_de_noticias_eafit%3A1811)

Facet Categoría de noticias EAFIT publicaciones 

![Image 24: Imagen Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://universidadeafit.widen.net/content/1e26403e-34ad-44fd-98d4-b1ff716a698f/web/Nueva-fase-energia.jpg?crop=yes&k=c&w=292&h=306&itok=hzGyIDP_)

## Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar

Abril 20, 2026

[Ver publicación](https://www.eafit.edu.co/noticias/lo-que-esta-pasando-publicaciones/nueva-fase-para-la-energia-en-america-latina-ya-no-se "Ver publicación")

![Image 25: Imagen Hacia dónde va el mercado laboral ](https://universidadeafit.widen.net/content/04ac971f-154b-402b-ac37-2743654aa525/web/MariaA-1500.jpg?crop=yes&k=c&w=292&h=306&itok=SN5sEOko)

## Hacia dónde va el mercado laboral

Marzo 10, 2026

[Ver publicación](https://www.eafit.edu.co/noticias/publicaciones/hacia-donde-va-el-mercado-laboral "Ver publicación")

![Image 26: Imagen Colombia crece, pero debe fortalecer la inversión para sostener el ritmo](https://universidadeafit.widen.net/content/bfd7c3f3-47a5-4179-b055-a318f66650bf/web/Perspectivas%20Economicas%20-47.jpg?crop=yes&k=c&w=292&h=306&itok=u38IvBHf)

## Colombia crece, pero debe fortalecer la inversión para sostener el ritmo

Octubre 31, 2025

[Ver publicación](https://www.eafit.edu.co/noticias/eafit-es-noticia-publicaciones/colombia-crece-pero-debe-fortalecer-la-inversion-para "Ver publicación")

![Image 27: Imagen Resultados de la Mesa de Empleo de Antioquia indican que la generación de empleo está en auge](https://universidadeafit.widen.net/content/2aa1ebca-160e-4981-b55b-5594d99c3081/web/resultados-mesa-de-empleo.jpg?crop=yes&k=c&w=292&h=306&itok=YtLkt1Mv)

## Resultados de la Mesa de Empleo de Antioquia indican que la generación de empleo está en auge

Julio 22, 2025

[Ver publicación](https://www.eafit.edu.co/noticias/eafit-es-noticia-publicaciones/resultados-de-la-mesa-de-empleo-de-antioquia-indican-que-la "Ver publicación")

## El reto de ser Distrito Especial de Ciencia, Tecnología e Innovación

Mayo 2, 2022

[Ver publicación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-178/el-reto-de-ser-distrito-especial-de-ciencia-recnologia-e-innovacion "Ver publicación")

## ¡Contemplen el Museo de los Esfuerzos Inútiles!

Mayo 2, 2022

[Ver publicación](https://www.eafit.edu.co/noticias/publicaciones/descubre-y-crea/edicion-178/contemplen-el-museo-de-los-esfuerzos-inutil "Ver publicación")

*   [Página actual 1](https://www.eafit.edu.co/noticias/publicaciones?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/noticias/publicaciones?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/noticias/publicaciones?label=&page=2 "Ir a la página 3")
*   [Página 4](https://www.eafit.edu.co/noticias/publicaciones?label=&page=3 "Ir a la página 4")
*   …
*   [Siguiente página›](https://www.eafit.edu.co/noticias/publicaciones?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/noticias/publicaciones?label=&page=5 "Ir a la última página")

Te puede interesar

Lo que está pasando

Historias y noticias acerca de la actualidad, logros, ránquines, programas, eventos e iniciativas de incidencia de la Universidad EAFIT a través de su comunidad.

[Ver historias y noticias](https://www.eafit.edu.co/noticias/lo-que-esta-pasando)

Nuestra comunidad de talento

Historias y noticias sobre las vidas y logros de las personas y colectivos que integran la comunidad de EAFIT en academia, investigación y proyección social.

[Ver historias y noticias](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento)

Nuestro impacto

Historias y noticias sobre investigaciones, proyectos e iniciativas que generan impacto en el entorno y aportan respuestas y soluciones a la sociedad.

[Ver historias y noticias](https://www.eafit.edu.co/noticias/nuestro-impacto)

Especiales

Historias que se abordan a fondo, desde EAFIT, con múltiples visiones y formatos sobre un mismo tema.

[Ver especiales](https://www.eafit.edu.co/noticias/especiales)

EAFIT es noticia

Estas son las noticias relacionadas con EAFIT que publican los medios de comunicación. ¡Así valoramos la labor que cumplen los medios!

[Ver historias y noticias](https://www.eafit.edu.co/noticias/eafit-es-noticia)

## Sala de prensa

Fuentes, fotografías, videos, audios y textos de la Universidad sobre historias, proyectos, logros y noticias de EAFIT para periodistas y medios de comunicación.

[Ir a Sala de prensa](https://www.eafit.edu.co/noticias/N%C2%BA)

![Image 28: Imagen Sala de prensa](https://universidadeafit.widen.net/content/9fc15555-fb1e-4e19-a258-b46db2574036/web/Pregrado-comunicacion-social-9.jpg)

![Image 29: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 30: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 31: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 32: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 33: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 34: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 35: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 36: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 37](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
