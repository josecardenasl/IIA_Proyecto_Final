Title: Estatuto profesoral

URL Source: https://www.eafit.edu.co/profes-que-inspiran/estatuto-profesoral

Markdown Content:
**​Capítulo I**

**Generalida​​des de la carrera profesoral**

**Artículo 28. Definición.** La carrera profesoral es la realización y crecimiento profesional que logra la persona vinculada como profesor durante su permanencia en la Institución. Está orientada al desarrollo de profesores, cuya formación, trayectoria, realización de actividades y resultados se concentran en las dimensiones del quehacer profesoral y contribuyen a las funciones sustantivas de la Institución y el reconocimiento tanto del profesor como de la Institución.

**Parágrafo.** Durante su vinculación a la Universidad EAFIT, el desarrollo de los profesores de carrera profesoral se expresa en su ascenso entre las categorías profesorales contempladas en este Estatuto y en el reconocimiento alcanzado entre las comunidades académicas y científicas de su disciplina o profesión y las agremiaciones profesionales.

**Artículo 29. Exclusividad.**La jornada laboral del profesor con vinculación laboral de tiempo completo con la Universidad EAFIT será dedicada exclusivamente al desempeño de las actividades asignadas por la Universidad.

**Parágrafo.** La realización de labores a título personal, de docencia e innovación educativa; ciencia, tecnología e innovación; y servicio y proyección social por cuenta propia o para otras personas jurídicas o naturales, durante la vigencia del contrato de trabajo, requerirá autorización escrita por parte de la decanatura de la Escuela a la que pertenece el profesor y deberá ser enviada al Departamento de Desarrollo de Empleados. Estas labores no podrán interferir con el cumplimiento adecuado de las responsabilidades del profesor de acuerdo con las obligaciones emanadas de los reglamentos, políticas, directrices institucionales, instrucciones o de su contrato de trabajo.

**Artículo 30. Retiro temporal y reintegro.** Los profesores de carrera profesoral podrán retirarse temporalmente de la Universidad para ocupar cargos en el sector público o en el privado. En este caso se suscribirá un mutuo acuerdo de terminación del contrato de trabajo con el fin de no generar conflicto de intereses. Ante este retiro temporal, la Universidad otorgará al profesor la posibilidad de contratarlo nuevamente en la plaza de planta que ocupaba, en los términos establecidos en el mutuo acuerdo.

El profesor deberá presentar la solicitud de retiro temporal ante la decanatura de la Escuela correspondiente y la Vicerrectoría de Aprendizaje, quienes la estudiarán y decidirán atendiendo a los intereses institucionales. Una vez el profesor ha concluido su servicio, podrá reintegrarse a las actividades académicas en la Universidad.

Todas las solicitudes y autorizaciones de las que trata esta sección deberán quedar formalizadas ante la dirección de Desarrollo Humano de la Universidad.

**Capítulo II**

**Ingreso a la carrera profesoral**

**Artículo 31. Inclusión en la carrera profesoral.** El ingreso a la carrera profesoral para la categoría Asistente queda en firme una vez cumplido el proceso de selección. Los profesores que son vinculados para las categorías Asociado o Titular ingresan a la carrera profesoral luego de cumplir con el proceso de selección y una vez se supere exitosamente la evaluación de méritos; en cuyo caso, el ingreso a la carrera profesoral queda en firme con la formalización del contrato de trabajo a término indefinido.

**Artículo 32. Evaluación de méritos.** Para efectos de ingreso a la carrera profesoral, y cuando la vinculación a la Institución se hace con la intención de ubicación en las categorías Asociado o Titular, la evaluación de méritos supone el cumplimiento de los requisitos de ascenso definidos para cada una de esas categorías; en cuyo caso esta podrá llevarse a cabo de dos formas:

Realizar la evaluación de méritos de manera previa a la contratación y si esta fuese exitosa efectuar la vinculación mediante contrato a término indefinido.

Vincular al profesor con un contrato a término fijo por un plazo no superior a un año y que éste se presente al proceso de evaluación de méritos con el objeto de ratificar la categoría y modificar el contrato a término indefinido.

**Capítulo I​II**

**De la clasificación de la carrera profesoral**

**Artículo 33. Clasificación de la carrera profesoral.** Es el conjunto ordenado y jerárquico de categorías que permiten apreciar el desarrollo de la carrera profesoral durante la vinculación del profesor en la Universidad, teniendo en cuenta los títulos universitarios, experiencia docente y profesional, producción intelectual, competencias en otros idiomas, participación en programas de formación y de cualificación profesoral, y evaluaciones de su desempeño.

**Artículo 34. Categorías de la carrera profesoral.** Previo el cumplimiento de los requisitos de ingreso o ascenso que se establecen más adelante en este Estatuto, los profesores de carrera profesoral de la Universidad EAFIT podrán ser clasificados en alguna de las siguientes categorías

Profesor Asistente

Profesor Asociado

Profesor Titular

Profesor Distinguido

**Parágrafo.** El ascenso de los profesores en las diferentes categorías de la carrera profesoral estará sujeto a los criterios para la promoción y al orden secuencial de ascenso aquí estipulado.

**Artículo 35. Profesor Asistente.** Es la categoría que inicia la carrera profesoral. Esta categoría alberga posiciones dirigidas a impulsar la carrera de profesores en formación doctoral o en una etapa temprana posterior a la formación doctoral, que se inician en la vida académica como trayectoria profesional o que ingresan por primera vez a una institución de educación superior. Esta categoría se caracteriza por reflejar avances prometedores, mas no necesariamente consolidados en las dimensiones de docencia e innovación pedagógica; y ciencia, tecnología e innovación; aunados a esfuerzos que contribuyan a la responsabilidad colectiva de servicio universitario y proyección social. En todas las tres dimensiones, los profesores y profesoras asistentes hacen contribuciones conmensurables a la experiencia acumulable en los tiempos establecidos para esta categoría.

Esta categoría tendrá dos subcategorías:

Profesor Asistente 1

Profesor Asistente 2

**Artículo 36. Requisitos de ingreso en la subcategoría de profesor asistente 1.**Son requisitos de ingreso a la subcategoría de profesor asistente 1:

1.   Poseer título de maestría, otorgado por una institución de educación superior reconocida por el Ministerio de Educación Nacional. En el caso de títulos expedidos en el exterior, estos deberán estar debidamente apostillados.
2.   Acreditar suficiencia en segunda lengua cuando sea de interés para el área o programa académico, requisito que se deberá especificar en la convocatoria pública.

**Artículo 37. Requisitos de ingreso o ascenso a la categoría de profesor asistente 2.** Son requisitos de ingreso o ascenso a la subcategoría de profesor asistente 2:

1.   Poseer título de doctorado (Ph.D. o su equivalente en estudios universitarios de tercer ciclo), otorgado por una institución de educación superior reconocida por el Ministerio de Educación Nacional. En el caso de títulos expedidos en el exterior, estos deberán estar debidamente apostillados.
2.   Acreditar suficiencia en segunda lengua cuando sea de interés para el área o programa académico, requisito que se deberá especificar en la convocatoria pública.
3.   Obtener la aprobación por parte de la decanatura de la Escuela a la que se vincula, desde donde se notificará la decisión al Comité de Desarrollo Profesoral.

**Artículo 38. Tiempo máximo.**El profesor asistente debe ascender a la categoría de Profesor Asociado en un plazo máximo de seis años, o de lo contrario será desvinculado de la Universidad. Este plazo máximo corresponde, a su vez, a la suma de dos períodos con un máximo de tres años cada uno, para las subcategorías profesor asistente 1 y profesor asistente 2.

**Artículo 39. Extensión.** En casos especiales, y cuando las circunstancias así lo ameriten, un profesor podrá solicitar una extensión en los plazos máximos para la categoría de profesor asistente mediante comunicación a la decanatura de la Escuela respectiva, desde donde se deberá elevar dicha solicitud al Comité de Desarrollo Profesoral para su aprobación. Estos casos especiales contemplan, pero no se limitan a las siguientes circunstancias:

licencias de maternidad, de paternidad y parental compartida;

licencia por estudios doctorales;

incapacidades médicas prolongadas debidamente justificadas;

calamidades domésticas prolongadas debidamente justificadas;

situaciones familiares como labores de cuidado de personas en situación de discapacidad, enfermedad o edad;

designaciones en entidades públicas o privadas sin pérdida del vínculo laboral con EAFIT;

y retiro temporal.

La extensión correspondiente será no menor a seis meses y por el tiempo que el Comité de Desarrollo Profesoral determine adecuado.

**Artículo 40. Profesor Asociado.** Es la categoría intermedia en la que transita quien está en proceso de consolidar una contribución distintiva del quehacer profesoral. A esta categoría pertenecen profesores y profesoras con una trayectoria universitaria o en el ámbito de centros de estudio e incidencia, que han logrado un reconocimiento propio que les distingue en su área de conocimiento y entorno profesional por aportes o contribuciones significativas en una o más de las dimensiones del quehacer profesoral para el beneficio institucional y profesional, así como el desarrollo propio de la persona, a la vez que contribuye a las demás dimensiones acorde con sus intereses y logros. Los profesores asociados superan a los profesores en la categoría de asistente en sus contribuciones en las dimensiones del quehacer profesoral por su experiencia y recorrido.

**​Artículo 41. Requisitos de ascenso a la categoría de profesor asociado.**Para ascender a la categoría de profesor asociado, se requiere:

1.   Poseer título de doctorado (Ph.D. o su equivalente en estudios universitarios de tercer ciclo), otorgado por una institución de educación superior reconocida por el Ministerio de Educación Nacional. En el caso de títulos expedidos en el exterior, estos deberán estar debidamente apostillados.
2.   Acreditar suficiencia en segunda lengua cuando sea de interés para el área o programa académico, requisito que se deberá especificar en la convocatoria pública.
3.   Obtener la aprobación por parte del Comité de Desarrollo Profesoral de ingreso o ascenso en la carrera profesoral.

**Artículo 42. Tiempo mínimo.** El profesor asociado deberá permanecer en esta categoría por un plazo mínimo de seis años antes de iniciar el proceso de ascenso a la categoría de profesor titular.

**Artículo 43. Profesor Titular.** Es la categoría en la que se consuma el recorrido académico en el quehacer profesoral. Esta categoría alberga profesores y profesoras cuyas trayectorias los han llevado a hacer contribuciones reconocidas a nivel institucional, con impacto local, nacional o internacional, en una o más de las dimensiones del quehacer profesoral, acrecentando el conocimiento propio de su área y, en un sentido más amplio, la disciplina académica y profesional, así como el desarrollo propio de la persona y de otros. Son profesores líderes en su entorno académico y de responsabilidad frente a la Institución, cuyas contribuciones impactan la Universidad y la trascienden. Los profesores y profesoras titulares superan a los profesores en la categoría de asociados por sus contribuciones en las dimensiones del quehacer profesoral dadas sus trayectorias y recorridos.

**Artículo 44. Requisitos de ascenso a la categoría de profesor titular.** Para ascender a la categoría de profesor titular, se requiere:

1.   Poseer título de doctorado (Ph.D. o su equivalente en estudios universitarios de tercer ciclo), otorgado por una institución de educación superior reconocida por el Ministerio de Educación Nacional. En el caso de títulos expedidos en el exterior, estos deberán estar debidamente apostillados.
2.   Acreditar suficiencia en segunda lengua cuando sea de interés para el área o programa académico, requisito que se deberá especificar en la convocatoria pública.
3.   Obtener la aprobación por parte del Comité de Desarrollo Profesoral de ingreso o ascenso a la carrera profesoral.

**Artículo 45. Tiempo mínimo.** El profesor titular deberá permanecer en esta categoría por un plazo mínimo de ocho años antes de iniciar el proceso de ascenso a la categoría de profesor distinguido.

**Artículo 46. Profesor Distinguido.** Es la categoría máxima de la carrera profesoral, que simboliza y exalta el éxito académico y los ideales que encarna el proyecto educativo institucional. Esta categoría alberga profesores cuya trayectoria y liderazgo trasciende su disciplina. Son ejemplo e inspiración del ejercicio profesoral en todas sus dimensiones y conforman una élite académica dentro de la comunidad universitaria. Los profesores distinguidos han hecho contribuciones únicas o extraordinarias en las dimensiones del quehacer profesoral con impacto nacional o internacional. Las designaciones a profesores distinguidos serán aprobadas por el Comité de Desarrollo Profesoral y otorgadas por el Consejo Directivo en acto solemne. Los cupos de ascenso serán fijados anualmente por el Comité de Desarrollo Profesoral.

**Artículo 47. Requisitos de ascenso a la categoría de profesor distinguido.** Para ascender a la categoría de profesor distinguido, se requiere:

1.   Poseer título de doctorado (Ph.D. o su equivalente en estudios universitarios de tercer ciclo), otorgado por una institución de educación superior reconocida por el Ministerio de Educación Nacional. En el caso de títulos expedidos en el exterior, estos deberán estar debidamente apostillados.
2.   Haber prestado servicios a la Universidad con dedicación de tiempo completo durante ocho años continuos, contados a partir de su vinculación a la Universidad o su último ascenso. Se tendrá en cuenta el tiempo de servicio público o empresarial debidamente autorizado por la Universidad.
3.   Obtener la aprobación por parte del Comité de Desarrollo Profesoral de ascenso en la carrera profesoral.

Artículo 48. Remuneración. El Consejo Directivo fijará, cada año, las remuneraciones correspondientes a las distintas categorías de la carrera profesoral.

**Capítulo IV ​**

**Comité de Desarrollo Profesoral**

**​Artículo 49. Comité de Desarrollo Profesoral.** El presente Estatuto Profesoral y los diferentes sistemas de clasificación y ascenso profesoral serán administrados por el Comité de Desarrollo Profesoral, por lo que queda sin efecto cualquier otro comité que tenga funciones iguales o similares.

**Artículo 50. Conformación.** El Comité de Desarrollo Profesoral estará integrado por:

el vicerrector de aprendizaje o quien haga sus veces, quien lo preside;

el vicerrector de ciencia, tecnología e innovación o quien haga sus veces;

los decanos;

tres representantes profesorales, pertenecientes a alguno de los sistemas de cla-sificación y ascenso profesoral vigentes, de las categorías profesoral: asociado, titular y distinguido, nombrados por los profesores, por mayoría de votos, para un período de dos años.

Estos miembros son quienes conforman el Comité de Desarrollo Profesoral y tienen voz y voto.

**Parágrafo 1.** Serán invitados permanentes a este comité con voz: el director de desarrollo humano, y el director de desarrollo académico.

**Parágrafo 2.** El Comité de Desarrollo Profesoral podrá tener invitados ocasionales en caso de considerarlo necesario. Los invitados tendrán voz.

**Parágrafo 3.** Cada uno de los tres representantes profesorales tendrá su respectivo suplente. Representantes titulares y suplentes serán elegidos y nombrados de conformidad con el Reglamento de Elecciones o el que haga sus veces.

**Parágrafo transitorio.** Mientras se llevan a cabo las elecciones de representantes profesorales al Comité de Desarrollo Profesoral, este lo integrarán el representante suplente al Consejo Directivo y dos representantes al Consejo Académico.

**Artículo 51.** Funciones del Comité de Desarrollo Profesoral. Las siguientes son funciones del Comité de Desarrollo Profesoral y sus miembros:

1.   Expedir el reglamento interno que garantice un buen funcionamiento del Comité de Desarrollo Profesoral y los reglamentos necesarios para hacer operativo y viable el desarrollo y la implementación del presente Estatuto Profesoral.
2.   Aprobar los catálogos de actividades y productos considerados en las dimensiones del quehacer profesoral.
3.   Revisar los reglamentos y catálogos de productos máximo una vez al año y mínimo una vez cada tres años.
4.   Aprobar el ingreso y promoción de los profesores en los sistemas de clasificación y ascenso, con base en los requisitos, criterios y procedimientos fijados en cada uno de los estatutos, según corresponda, y en los Reglamentos de Producción Intelectual.
5.   Aprobar los cupos de ascenso anuales para la categoría de profesor distinguido.
6.   Resolver los recursos de reposición de los profesores sobre las decisiones de su clasificación en los sistemas de clasificación y ascenso.
7.   Resolver los recursos de apelación de profesores por paso de categoría Asistente 1 a Asistente 2.
8.   Aprobar el apoyo económico institucional para programas de formación formal financiados total o parcialmente por la Universidad.
9.   Aprobar las solicitudes de período sabático.
10.   Proponer al Consejo Directivo la creación y regulación de nuevos tipos o nuevas categorías profesorales acordes con las necesidades institucionales.
11.   Proponer al Consejo Directivo cualquier modificación al Estatuto Profesoral.
12.   Otorgar la distinción de profesor afiliado de cortesía.
13.   Establecer el límite de contratación por Escuelas de profesores de cátedra que no tengan título de maestría.
14.   Velar que los procesos de ascenso estén alineados con las políticas de la Universidad sobre diversidad, equidad e inclusión.

**Parágrafo 1.** La participación de los miembros del Comité de Desarrollo Profesoral no será delegable, con excepción de los representantes profesorales que podrán delegar en sus suplentes.

**Parágrafo 2.** Con respecto a la función de aprobación de la promoción de los profesores en los sistemas de clasificación y ascenso, el decano de la Escuela a la que se encuentre adscrita el profesor aspirante deberá presentar el caso correspondiente ante el Comité de Desarrollo Profesoral.

**Artículo 52. Quórum.** Para todos los efectos el Comité de Desarrollo Profesoral tendrá un quórum deliberatorio y decisorio constituido por mínimo cinco miembros, donde tres de ellos deberán ser decanos, uno de ellos deberá ser vicerrector, y uno de ellos deberá ser representante profesoral. Las decisiones se tendrán que tomar por mayoría calificada, con un mínimo de cuatro votos en el mismo sentido. Será el vicerrector de aprendizaje (o quien haga sus veces) en calidad de presidente del Comité de Desarrollo Profesoral, el encargado de dirimir los casos ante empate. En caso de presentarse una votación fallida se citará a una nueva sesión y se disminuirá a mayoría simple.

**Artículo 53. Reuniones del Comité de Desarrollo Profesoral.** El Comité de Desarrollo Profesoral sesionará ordinariamente al menos cuatro veces al año, dos veces por semestre, garantizando el trámite oportuno de ascensos y autorizaciones acordes con el calendario académico anual y semestral de la Universidad. También podrá sesionar extraordinariamente por solicitud del presidente del comité o de los representantes profesorales para tratar un asunto específico; y su convocatoria estará a cargo de la Vicerrectoría de Aprendizaje. De cada reunión se levantará un acta.

**Parágrafo.** La Secretaría Técnica del Comité de Desarrollo Profesoral estará a cargo de la Dirección de Desarrollo Humano, quien deberá solicitar de las diferentes áreas de la Universidad EAFIT la información necesaria para producir las decisiones y recibir los dosieres de los profesores; asimismo, deberá alertar a los miembros del comité sobre el cumplimiento de las funciones y términos.

**Capítulo V**

**Proceso de ascenso en la carrera profesoral**

**Artículo 54. Catálogos.** El proceso de ascenso en la carrera profesoral será instrumentado a través de la existencia de catálogos en cada una de las dimensiones del quehacer profesoral. A su vez, estos catálogos consideran la existencia de actividades y productos clasificados con una taxonomía definida para cada una de las dimensiones de manera transversal o por Escuela, según sea el caso. Esa taxonomía se declara en este Estatuto en términos de tipos o familias de productos y actividades. Será potestad del Comité de Desarrollo Profesoral establecer dicha taxonomía al momento de aprobar los catálogos para cada una de las dimensiones del quehacer profesoral.

**Artículo 55. Criterios para el ascenso en la carrera profesoral.** El ascenso en la carrera profesoral estará mediado por el desempeño de cada profesor o profesora de acuerdo con los productos y actividades reconocidos dentro de las tres dimensiones del quehacer profesoral. Para ello, se tendrán en cuenta los siguientes criterios de manera tal que se garantice que el profesor o la profesora haya cumplido con:

actividades en las tres dimensiones: docencia e innovación educativa; ciencia, tecnología e innovación; y servicio y proyección social;

contribuciones en las diferentes dimensiones no caducarán;

continuidad o constancia en el desarrollo de las actividades;

contribuciones en dos o más familias/tipos en al menos en una de las dimensiones;

coherencia y equilibrio entre su producción y actividades en relación con su asignación académica.

A su vez, las instancias de evaluación velarán por que

cada producto o actividad se considerare solo en una dimensión/familia/etc.;

la valoración relativa de productos o actividades incluida en los catálogos (por ejemplo, en tipos A, B, C o D) se entiendancomo una guía o referencia;

se tenga en cuenta una perspectiva diferencial para superar las barreras basadas en género, sexualidad diversa, pertenencia étnica racial, vulnerabilidad económica, discapacidad y neurodiversidad.

**Artículo 56. Criterios para definir la producción intelectual.** La definición de los catálogos de producción intelectual deberá reflejar la diversidad propia de cada una de las dimensiones del quehacer profesoral en las diferentes disciplinas, y, a su vez, enriquecer el desarrollo institucional. La producción intelectual tendrá dinámicas de construcción de forma transversal y por Escuelas, según sea el caso. El Comité de Desarrollo Profesoral reconocerá la producción intelectual basándose en función de su calidad y cantidad, pertinencia e impacto.

**Artículo 57. Dimensiones del quehacer profesoral.** En consonancia con los objetivos propios de la educación superior y con la Misión de la Universidad EAFIT, la acción profesoral se orientará a la búsqueda de la excelencia en el desarrollo de las funciones sustantivas de la Institución, las cuales, para efectos del presente Estatuto, se definen así.

1.   Docencia e Innovación Educativa. Es el conjunto de acciones que contribuyen al aprendizaje. Cobija entonces la educación formal y la educación no formal o de extensión, el diseño y acompañamiento de cursos en sus distintas modalidades, el desarrollo de nuevos métodos o alternativas pedagógicas, así como otras acciones y actividades de pedagogía que contribuyan a la enseñanza y el aprendizaje. Esta dimensión se acompañará de un catálogo transversal a toda la Institución.
2.   Ciencia, Tecnología e Innovación. Es el conjunto de actividades que propician la interacción entre procesos, técnicas y prácticas creativas en la ciencia, tecnología e innovación, para que converjan las distintas áreas del conocimiento. En esta dimensión del quehacer profesoral, los méritos a considerar comprenderán las actividades y resultados que se establezcan en el Reglamento de Producción Intelectual o su equivalente. Esta dimensión se acompañará de catálogos definidos por Escuela.
3.   Servicio y Proyección Social. Servicio es el conjunto de actividades que se realizan al dentro de la Universidad y fuera de ella para contribuir al buen funcionamiento de la Institución e instituciones u organizaciones afines a los campos disciplinares académicos y profesionales; y se entiende por proyección social el conjunto de actividades, de diversa índole, mediante las cuales la Universidad interactúa con la sociedad para contribuir a la solución de problemas específicos de agentes particulares. En esta dimensión del quehacer profesoral, los méritos a considerar comprenden una amplia gama de actividades y resultados que se agrupan en tres modalidades: (i) Servicio interno no administrativo; (ii) Servicio interno de administración académica; y (iii) Servicio externo. Esta dimensión se acompañará de un catálogo transversal a toda la Institución.

**Artículo 58. Proceso de ascenso.** El proceso de ascenso en la carrera profesoral estará mediado por las recomendaciones motivadas emitidas por la decanatura de la Escuela a la que se encuentra adscrito el profesor aspirante, la dirección de área o quien haga sus veces, y el comité ad hoc de Escuela para evaluaciones y ascensos que se describe más adelante. Las Escuelas según lo consideren necesario y pertinente, podrán establecer la instancia adicional de un comité ad hoc de área.

El Comité de Desarrollo Profesoral aprobará el ascenso y motivará dicha decisión en caso de que la misma sea negativa. Para ello, el profesor aspirante deberá preparar un dosier que reúna las evidencias de su producción intelectual, evaluaciones de su desempeño, competencias en otros idiomas, participación en programas de formación y de cualificación profesoral que establezca la Universidad en el Plan General de Desarrollo Profesoral y otras labores destacadas en las tres dimensiones del quehacer profesoral.

**Parágrafo 1.** Es responsabilidad del decano de la Escuela correspondiente remitir al Comité de Desarrollo Profesoral el dosier junto con las recomendaciones del o de los comités ad hoc de Escuela o de área, la recomendación de la dirección del área o quien haga sus veces, y la suya propia en un período no inferior a dos meses antes de la fecha límite establecida por este comité para la consideración de ingresos o ascensos a la carrera profesoral.

**Parágrafo 2.** No se evaluará el ingreso ni el ascenso del paso de la categoría asistente, en este caso será la decanatura quien lo apruebe.

**Artículo 59. Inicio del proceso de ascenso.** El proceso de ascenso inicia con el envío del dosier por parte del profesor al decano de la Escuela a la que está adscrito. Este dosier deberá ser radicado la primera semana laboral del semestre académico durante el cual se llevará a cabo la evaluación para consideración de ingreso o ascenso, y en un lapso no inferior a cinco meses antes de la fecha límite establecida por el Comité de Desarrollo Profesoral para la evaluación de ingresos y ascensos.

**Parágrafo.** El Comité de Desarrollo Profesoral establecerá una fecha límite para consideración de ingresos y ascensos en la carrera profesoral para cada semestre académico (dos al año). Esta fecha se fijará teniendo en cuenta que el inicio del proceso pueda hacerse en la primera semana laboral del semestre, y de forma tal que la decisión sobre la solicitud de ascenso se pueda dar a conocer y hacerse efectiva al momento de inicio del siguiente semestre.

**Artículo 60. Dosier.** El dosier es el conjunto de documentos que dan cuenta de las actividades, producción y desempeño del profesor en el ejercicio de las dimensiones del quehacer profesoral para la consideración de ascenso y cambio de categoría en la carrera profesoral. Durante el tiempo de preparación del dosier, y con la idea de facilitar la búsqueda y consecución de certificados, evaluaciones o publicaciones, el profesor contará con el acompañamiento de la dirección de área y la decanatura de la Escuela a la que se encuentra adscrito, y recibirá apoyo de la dirección de Desarrollo Humano. El dosier deberá contener todas las evidencias relevantes sobre producción en las tres dimensiones del quehacer profesoral, evaluaciones de su desempeño, competencias en otros idiomas, participación en programas de formación y de cualificación profesoral que establezca la Universidad en el Plan General de Desarrollo Profesoral y otras labores destacadas.

**Artículo 61. Comité ad hoc de Escuela.** Es un cuerpo colegiado constituido por pares académicos, profesores de la Escuela, y con un rango o categoría igual o superior a la categoría a la que postula el profesor que desea ingresar o ascender en la carrera académica. Este comité analizará el dosier presentado por el profesor aspirante a ingresar o ascender en la carrera profesoral, con el fin de emitir una recomendación motivada, de acuerdo con los criterios establecidos en el presente Estatuto, sobre la conveniencia institucional de conceder o no el ingreso o ascenso solicitado.

**Parágrafo 1.** Las Escuelas tendrán libertad de establecer un comité ad hoc de área como instancia previa al comité ad hoc de Escuela si así lo consideran pertinente, necesario o conveniente. Esta decisión estará en cabeza de la decanatura de la Escuela respectiva.

**Parágrafo 2.** La conformación del comité o comités ad hoc es responsabilidad de la decanatura de la Escuela respectiva, quien consultará con la dirección de área o quien haga sus veces la idoneidad e independencia de los profesores.

Este comité o comités estarán conformados por un número impar de hasta cinco profesores de la Escuela a la que pertenezca el profesor aspirante.

En caso de ser necesario contar con profesores externos dentro de la conformación del comité, será la decanatura la responsable de gestionar su participación.

**Parágrafo 3.** El profesor aspirante tendrá la posibilidad de vetar anticipadamente la inclusión de profesores específicos en la conformación del comité o comités ad hoc de la Escuela, para lo cual deberá informar las razones académicas o personales que le asisten en ese veto. Este veto deberá ser expresado por escrito, en un documento confidencial dirigido a la decanatura, y que no será parte del dosier. Será responsabilidad de la decanatura definir la viabilidad del veto y preservar su confidencialidad.

**Artículo 62. Recomendación del comité ad hoc.** El comité o los comités ad hoc de Escuela o de área deberán remitir la recomendación de ingreso o ascenso a la decanatura de la Escuela respectiva con una antelación mínima de tres meses a la fecha límite establecida por el Comité de Desarrollo Profesoral para la consideración de ingresos o ascensos en la carrera profesoral.

**Parágrafo.** El sentido de la recomendación del comité o comités ad hoc de Escuela se decidirá por mayoría.

**Artículo 63. Sobre la confidencialidad del proceso.** Las recomendaciones emitidas por el comité o comités ad hoc de Escuela, la dirección de área o quien haga sus veces, y la decanatura, serán confidenciales en tanto la decisión sobre la postulación no sea apelada. Así mismo, la conformación del comité o comités ad hoc será confidencial, en tanto la decisión del Comité de Desarrollo Profesoral no sea apelada.

**Artículo 64. Comisión de Apelaciones.** La Comisión de Apelaciones resolverá en segunda instancia los recursos de los profesores sobre las decisiones de su clasificación en los sistemas de clasificación y ascenso; y del período sabático. La Comisión de Apelaciones estará conformada por el rector, el secretario general y el representante profesoral al Consejo Directivo; un integrante de la Secretaría General hará las veces de la Secretaría Técnica.

**Artículo 65. Recursos.** Frente a la decisión del paso de categoría asistente 1 a 2, procede el recurso de apelación ante el Comité de Desarrollo Profesoral.

Frente a la decisión del Comité de Desarrollo Profesoral en relación con la promoción de los profesores para las categorías Asociado, Titular y Distinguido de la carrera profesoral y en los demás sistemas de clasificación y ascenso procede el recurso de reposición y en subsidio el recurso de apelación ante la Comisión de Apelaciones.

**Parágrafo 1.** El profesor podrá interponer los recursos dentro de los cinco días hábiles siguientes a la notificación de la decisión.

**Parágrafo 2.** Se concede un término de hasta diez días hábiles para resolver los recursos de reposición y un término de hasta quince días hábiles para resolver los recursos de apelación.

**Artículo 66. Finalización del proceso de ascenso.** El ascenso se formalizará una vez esté en firme la decisión del Comité De Desarrollo Profesoral sobre la promoción de los profesores, esto es, por haberse resuelto los recursos interpuestos o por vencimiento del término para interponerlos.

**Parágrafo.** En el caso que no sea concedido el ascenso en la categoría de profesor Asistente 1 a Asistente 2, se puede negar la continuidad en la Institución o hacer recomendaciones para presentarse nuevamente en un plazo que no afecte el máximo establecido para pasar a la categoría de profesor asociado; en el ascenso de la categoría de profesor Asistente 2 a profesor Asociado, se comunicará la no continuidad en la Institución al aspirante; y en los demás pasos, se emitirá una recomendación para presentarse nuevamente.

**Capítulo VI**

**Asignación de la labor académ​ica y plan de trabajo profesoral**

**Artículo 67. Asignación de la labor académica.** Los profesores de la Universidad podrán desarrollar actividades en las dimensiones de docencia e innovación educativa; de ciencia, tecnología e innovación; y de servicio y proyección social, de acuerdo con las políticas de asignación de la labor académica fijadas por la rectoría y con los objetivos previstos en el Plan Estratégico de Desarrollo de la Institución.

**Artículo 68. Plan de trabajo profesoral.** La asignación de la labor académica del profesor, para un período calendario, constituye su plan de trabajo para el período indicado. Corresponde al decano o decana y a la dirección de área, o quien haga sus veces, definir los planes de trabajo del profesorado a su cargo, en consonancia con los objetivos previstos en el Plan Estratégico de Desarrollo de la Universidad.

**Artículo 69. Criterios para la asignación de la labor académica.** Para el desarrollo de su Misión institucional y el logro de su Visión, la Universidad EAFIT considera igualmente valiosas las distintas dimensiones del quehacer profesoral definidas en este Estatuto y, por ello, en la fijación de la asignación de la labor académica se podrán considerar criterios como las preferencias académicas, la experiencia, las competencias específicas del profesor y la categoría que ostenta dentro de la clasificación profesoral de la Institución.

**Artículo 70. Interacciones.** La dimensión de docencia e innovación educativa se articula estrechamente con la de ciencia, tecnología e innovación en la medida en que el profesor es un estudioso y conocedor profundo de su campo de conocimiento disciplinar o profesional, y se preocupa por contribuir a su desarrollo mediante la formulación de preguntas que generan proyectos de investigación.

Para todos los efectos del presente Estatuto, la pedagogía también constituye un campo propicio para el desarrollo de actividades de ciencia, tecnología e innovación que se evidencien en el mejoramiento de los procesos de aprendizaje y formación de los estudiantes. La investigación aplicada constituye una fuente de proyección social y de interacción con la comunidad.

Estas interacciones pueden darse en cualquiera de las direcciones, de la docencia a la investigación, y de la investigación a la docencia, pasando en cada caso por la transferencia y apropiación del conocimiento, la contribución a la ciencia y el desarrollo tecnológico, y permeando o siendo permeado por las labores de gestión y administración académica. Todas estas interacciones contribuyen al desarrollo integral de los profesores y a las actividades misionales de la Universidad.

**Artículo 71. Servicio interno y administración académica.** Como parte del desempeño profesoral en la Institución, el servicio interno se define como el conjunto de actividades relativas a la gestión curricular, la gestión académica, la administración académica, la gestión del talento humano y la utilización y administración de los recursos físicos y financieros requeridos para el buen conducir de la Universidad y el desempeño de los profesores en las dimensiones del quehacer profesoral. Estas labores de servicio y administración son asumidas por un profesor como parte de su asignación de la labor académica de manera voluntaria o por designación durante los períodos que para ello se definan.
