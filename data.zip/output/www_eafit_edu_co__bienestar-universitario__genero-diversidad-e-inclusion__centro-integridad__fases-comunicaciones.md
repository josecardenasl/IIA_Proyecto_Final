Title: Fases de comunicaciones

URL Source: https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones

Markdown Content:
[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones# "English")

Buscar

![Image 6: Imagen de banner posgrado maestria en comunicaciones](https://universidadeafit.widen.net/content/43e2d103-7016-432c-8a1f-b16c5830cf21/web/posgrado-maestria-en-comunicacion-transmedia.jpg?crop=yes&k=c&w=1920&h=788&itok=rsCveat8)

*   [Inicio](https://www.eafit.edu.co/)
*   [Bienestar Universitario](https://www.eafit.edu.co/bienestar-universitario)
*   [Género, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Centro de Integridad​​](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad)
*    Fases de Comunicaciones 

![Image 7: Imagen Integridad en tiempos de virtualidad (2020) ​​​ ](https://universidadeafit.widen.net/content/3052fb8a-0646-43e6-a583-6e4112163111/web/2020-destacado.jpg)

Integridad en tiempos de virtualidad (2020) ​​​

![Image 8: Imagen Cultura ciudadana: elecciones cotidianas (2019)](https://universidadeafit.widen.net/content/41427fd3-b163-4919-acdc-69dc38695f7e/web/2019-destacado.jpg)

Cultura ciudadana: elecciones cotidianas (2019)

![Image 9: Imagen ​Inauguración Proyecto Respeto en EAFIT (2018)](https://universidadeafit.widen.net/content/e5f414af-98e7-4338-963f-731a11b3e6e1/web/2018-destacado.jpg)

​Inauguración Proyecto Respeto en EAFIT (2018)

##### Inauguración – Centro de Integridad (2017)

###### Exposición en el campus​

![Image 10: Imagen Primera fase: Culto a la viveza](https://universidadeafit.widen.net/content/7faebd8b-a935-4187-84e5-a63cfb1ef063/web/fase-1-destacado.jpg)

Primera fase: Culto a la viveza

[Ver fase ​completa](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones)

![Image 11: Imagen Segunda fase: Ética y academia​​](https://universidadeafit.widen.net/content/1b5a2d60-5fa1-4a66-8874-e0d6ccddf407/web/fase-2-destacado.jpg)

Segunda fase: Ética y academia​​

[Ver fase ​completa](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones)

![Image 12: Imagen Tercera fase: Cultura ciudadana ](https://universidadeafit.widen.net/content/a6f8def1-f589-44b5-a419-ff74284f71a1/web/fase-3-destacado.jpg)

Tercera fase: Cultura ciudadana

[Ver fase ​completa](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones)

![Image 13: Imagen Cuarta fase: Ser mejor](https://universidadeafit.widen.net/content/0ecf707c-08b2-4c0f-911f-35cf9baa4114/web/fase-4-destacado.jpg)

Cuarta fase: Ser mejor

[Ver fase ​completa](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones)

![Image 14: Imagen ​Quinta fase: Integridad académica](https://universidadeafit.widen.net/content/228ad29a-42c9-4c23-be95-548c633d8005/web/fase-5-destacado.jpg)

​Quinta fase: Integridad académica

[Ver fase ​completa](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones)

![Image 15: Imagen Sexta fase: Atreverse a Pensar](https://universidadeafit.widen.net/content/be297119-ef9b-4c70-905b-62e20c9af8d1/web/fase-6.jpg)

Sexta fase: Atreverse a Pensar

[Ver fase ​completa](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-comunicaciones)

![Image 16: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 17: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 18: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 19: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 20: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 21: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 22: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 23: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
