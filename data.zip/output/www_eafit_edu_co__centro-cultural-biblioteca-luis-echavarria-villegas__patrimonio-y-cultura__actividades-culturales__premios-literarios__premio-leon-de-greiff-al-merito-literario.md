Title: Premio León de Greiff al Mérito Literario

URL Source: https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario

Markdown Content:
# Premio León de Greiff al Mérito Literario
[Pasar al contenido principal](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner premio leon de greiff ](https://universidadeafit.widen.net/content/717f0dec-aaf0-418b-97bd-d240f7c4d3a8/web/Banner_Leon_de_Greiff_2026.png?crop=yes&k=c&w=1920&h=788&itok=ROhw6U-y)

# Premio León de Greiff

*   [Inicio](https://www.eafit.edu.co/)
*   [Centro Cultural Biblioteca Luis Echavarría Villegas](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)
*   [Patrimonio y Cultura](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
*   [Actividades Culturales](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales)
*   [Premios Literarios](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios)
*    Premio León de Greiff Al Mérito Literario 

#### Sobre el Premio

El 16 de septiembre de 2015 se constituyó el "Premio León de Greiff al mérito literario". Este Premio busca celebrar la memoria del poeta León de Greiff y reconocer la vida y obra de un escritor como una forma de contribuir a la construcción de tejido social a través de la cultura al honrar el trabajo de nuestros creadores y darlo a conocer a las nuevas generaciones.

Es por esto, que el escritor o escritora ganador(a) debe haber cumplido con un periplo vital y profesional que amerite la entrega de este reconocimiento en el ámbito nacional y proyección territorial.

El premio se entregará durante la Fiesta del Libro y la Cultura de Medellín. Este cuenta con la colaboración de un jurado competente y autónomo, conformado por un escritor, un editor y un docente. Adicionalmente, un vocero de la Universidad Eafit y uno de la Fiesta del Libro y la Cultura que participarán en las deliberaciones y tendrán voz, pero no voto en la decisión final. El patrocinador no interviene en la reglamentación, convocatoria o gestión del Premio. El "Premio León de Greiff al mérito literario" es posible gracias a una alianza entre la Universidad Eafit, la Fiesta del Libro y la Cultura de la Secretaría de Cultura Ciudadana de Medellín y empresas comprometidas con la cultura: Grupo Argos, Celsia y Argos.

#### Bases del Premio

##### Categoría:

###### Narrativa

**Premio:**

40 millones de pesos colombianos.

Publicación de una antología representativa de la trayectoria o una obra inédita del autor, que será editada y publicada por la Editorial EAFIT.

**Bases:**

El premio se concede a un poeta en los años pares y en los impares a un narrador (cuentista o novelista).

El premio será concedido a un autor o autora vivos del ámbito latinoamericano.

Escritores con una obra consolidada en lengua española, mayores de 50 años.

Los finalistas deben tener una obra publicada de altísima calidad literaria, reconocida por los lectores, la crítica y la academia.

Las postulaciones podrán hacerlas entidades culturales (academias de la lengua, bibliotecas, universidades, editoriales, ONG) públicas o privadas de Colombia o del exterior que tenga alguna relación con el país.

Los postulantes deberán enviar una carta de justificación en la cual expliquen los méritos literarios por los cuales se postula el candidato, describiendo su obra, su trayectoria, e influencia en la sociedad. Ninguna de las entidades y empresas organizadoras, ni las personas vinculadas a la organización del concurso podrán hacer postulaciones de autores.

El nombre del ganador se dará a conocer en el lanzamiento de la Fiesta del Libro y la Cultura de cada año.

El autor galardonado debe aceptar de forma explícita el Premio y se compromete a asistir a la ceremonia de premiación en Medellín, Colombia y a otras actividades académicas durante su estadía y proporcionar a la Editorial EAFIT los escritos y la autorización para la publicación de la antología.

Los organizadores correrán con los gastos de alojamiento y traslado a la ciudad de Medellín del ganador.

El autor galardonado participará en la ceremonia de premiación con una intervención sobre el oficio literario.

La entidad cultural que postuló al ganador obtendrá un certificado de reconocimiento y se le darán los créditos de la postulación en la ceremonia y en la publicación.

## Indicaciones para la postulación

Género: Narrativa

 • Abierto a: autores vivos del ámbito latinoamericano

 Fechas 

 o Lanzamiento del premio: marzo 06 del 2026

 o Apertura de recepción de postulaciones: 06 de marzo del 2026

 o Cierre de recepción de postulaciones: 25 de mayo del 2026

 o Evaluación de populaciones y ganador: 25 de mayo y 17 de julio del 2026.

 o Anuncio del ganador: lanzamiento de la fiesta del libro. Agosto. 

 o Fecha de entrega del premio: mes de septiembre de 2026, durante la Fiesta del Libro y la Cultura de Medellín

 •Modo de recepción de postulaciones: diligenciar formulario y adjuntar la carta de justificación.

[Participa aquí](https://eafit.qualtrics.com/jfe/form/SV_8igZh8GDU9E16rs)

[Premio 2025](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario#4257225834-1724731104)

Premio 2025

###### Ganador: Darío Jaramillo Agudelo

En 2025, el poeta colombiano Darío Jaramillo Agudelo, postulado por el Banco de la República y el Parque Biblioteca Tomás Carrasquilla – La Quintana, fue distinguido con la obra Liturgia de los bosques (Editorial EAFIT, Medellín, 2026)

Nacido en Santa Rosa de Osos en 1947, este poeta, narrador y crítico literario colombiano se ha convertido uno de los exponentes más reconocidos de la llamada generación de los desencantados, integrada por escritores que comenzaron a publicar en la década de 1970 y que, según la crítica, expresaron el desasosiego frente a la violencia bipartidista y las transformaciones sociales de la época.

Y como autor de más de 30 libros de poemas, entre los que se destacan Historias (1974) y el célebre Poemas de amor (1986), ha incursionado también en la narrativa y en la crítica literaria, lo que le ha permitido obtener, a lo largo de su recorrido literario, distinciones como el Premio Nacional de Poesía, y el Premio Internacional de Poesía Federico García Lorca, entre otros.

#### Quién es Darío Jaramillo Agudelo, ganador del Premio León de Greiff

[Premio 2019](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario#4257225834-3735715693)

Premio 2019

###### Ganador: Edgardo Rodriguez

La natación, el béisbol, la gastronomía criolla como señas de identidad de Puerto Rico y el Caribe hispanohablante son algunos de los temas que aborda Edgardo Rodríguez Juliá. Ha publicado siete novelas, un libro de relatos y catorce libros de crónicas y ensayos. Su primera novela es La renuncia del héroe Baltasar (1974) y, más recientemente, ha escrito obras como Elogio de la fonda (2000), Caribeños (2002), Mapa de una pasión literaria (2003).

###### Jurados

Sergio Ramirez

Mario Jursich Alfonso Buitrago

Pilar Gutierrez

#### Edgardo Rodríguez Juliá recibirá el Premio León de Greiff al Mérito Literario, ¿por qué lo merece?

[Premio 2018](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario#4257225834-1496563410)

Premio 2018

###### Ganador: Elkin Restrepo

En 2018, el poeta colombiano Elkin Restrepo, postulado por el Parque Biblioteca Fernando Botero. Obra publicada: 

Antología Elkin Restrepo (Editorial EAFIT, Medellín, 2018)

El poeta antioqueño Elkin Restrepo, autor de más de una decena de libros de poesía y quien ha dedicado gran parte de su vida a las letras. Temas como el misterio, el amor, la cotidianidad y lo onírico se mezclan en la voz de este escritor, reconocido por ser una de las voces más originales de la poesía colombiana. Su creación artística también se extiende a otros campos como el dibujo y el grabado, expresión en la que ha realizado algunas exposiciones.

###### Jurados

Giovanni Quessep

Fabio Morábito

Catalina Gonzalez Ramón Cote

Diego Aristizabal

#### III Premio León de Greiff al Mérito Literario

[Premio 2017](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario#4257225834-889407240)

Premio 2017

###### Ganador: Luisa Valenzuela

La autora argentina Luisa Valenzuela fue seleccionada para el galardón gracias a una trayectoria en la que se ha destacado por una obra sincera y contestataria. A recibido destacados reconocimientos como el Gran Premio de Honor de la SADE, el doctorado Honoris Causa de la Universidad de Knox (Illinois) y de la Universidad Nacional de San Martín (Provincia de Buenos Aires), la Medalla Machado de Assis de la Academia Brasilera.

###### Jurados

Jorge Volpi

Santiago Gamboa

Octavio Escobar Claudia Ivonne Giraldo

Clemencia Ardila

#### Premio León de Greiff al Mérito Literario

[Premio 2016](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario#4257225834-955300088)

Premio 2016

###### Ganador: Juan Calzadilla

El escritor premiado es el poeta venezolano Juan Calzadilla, quien también es ensayista, crítico de arte y artista plástico. Calzadilla nació en 1931 y su obra poética, además de vasta, se reconoce como original y moderna. Está asociado a fenómenos de movimientos estéticos, vanguardia, artes plásticas, dibujo, y a una concepción muy amplia de la palabra y la ciudad.

###### Jurados

Juan Manuel Roca

Piedad Bonnet

Alberto Berrera Santiago Mutis

Juan Camilo Suarez

#### Lanzamiento del Premio León De Greiff al Mérito Literario

#### Juan Calzadilla: Yo soy un crítico de mí mismo

#### Galería

**2025**

[![Image 22: Dario jaramillo, ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/94ceecb4-c96f-49e5-9670-799edd2ac266/web/PremioLeondeGreiff-1-1536x1084.jpeg?crop=yes&k=c&w=740&h=510&itok=d8x6o8gx)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 23](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 24: Dario Jaramillo, ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/fe3483c0-f4c5-4902-a614-9d96cde21e53/web/PremioLeondeGreiff-3-1536x1031.jpeg?crop=yes&k=c&w=740&h=510&itok=6cvPvJbD)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 25](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 26: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/fe1348e5-9b5e-4b55-9da7-c758e783271f/web/PremioLeondeGreiff-5-1536x1024.jpeg?crop=yes&k=c&w=740&h=510&itok=6JdBWofu)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 27](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 28: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/149d77ea-0dd8-405b-b1ce-21b877dc3c0c/web/PremioLeondeGreiff-2-1536x1023.jpeg?crop=yes&k=c&w=740&h=510&itok=izZ8TeV_)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 29](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 30: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/d00e61f8-4edd-46fd-9ea0-9ffaa4ac1872/web/PremioLeondeGreiff-4-1536x1034.jpeg?crop=yes&k=c&w=740&h=510&itok=rJOIGJkU)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 31](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

**2019**

[![Image 32: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/dc6a71f6-bea4-4b45-af66-f084527c7663/web/edgardo-rodriguez-merito-literario3.png?crop=yes&k=c&w=740&h=510&itok=00kTiOu1)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 33](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 34: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/919b105d-9fd6-4cbd-a1e0-9f92f889a151/web/edgardo-rodriguez-merito-literario5.png?crop=yes&k=c&w=740&h=510&itok=V0B0aL9x)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 35](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 36: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/68bd05d8-897b-439a-901e-62298f170b18/web/edgardo-rodriguez-merito-literario2.png?crop=yes&k=c&w=740&h=510&itok=mLhgSMzT)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 37](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 38: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/ed462179-bf1f-4c49-a820-4de36460529e/web/edgardo-rodriguez-merito-literario1.png?crop=yes&k=c&w=740&h=510&itok=xQJDG0qP)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 39](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 40: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/2832eab8-77b4-4395-9755-2975a794fe59/web/edgardo-rodriguez-merito-literario4.png?crop=yes&k=c&w=740&h=510&itok=v1KmKUVT)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 41](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

**2018**

[![Image 42: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/65a5438c-0222-41ff-9e81-37f3204d0707/web/elkin-restrepo-poeta-ganador-pemio-leon-de-greiff-al-merito-literario.jpg?crop=yes&k=c&w=740&h=510&itok=1gNdtHi_)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 43](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 44: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/a5de1b4d-6fed-48e5-91ce-8e81d6816028/web/elkin-restrepo-poeta-ganador-premio-leon-de-greiff-al-merito-literario-2.jpg?crop=yes&k=c&w=740&h=510&itok=TWE7FMKq)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 45](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 46: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/57d13431-814d-487e-90e0-a06252ab4150/web/elkin-restrepo-poeta-ganador-premio-leon-de-greiff-al-merito-literario-3.jpg?crop=yes&k=c&w=740&h=510&itok=ouf5VsL7)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 47](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 48: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/baa44d15-8cad-4572-a571-44e343423f08/web/elkin-restrepo-poeta-ganador-premio-leon-de-greiff-al-merito-literario-4.jpg?crop=yes&k=c&w=740&h=510&itok=DZ1f17CQ)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 49](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 50: Elkin Restrepo, poeta ganador del Premio León de Greiff al mérito literario](https://universidadeafit.widen.net/content/da458082-b770-42d0-9df3-d425c1cbe88e/web/elkin-restrepo-poeta-ganador-premio-leon-de-greiff-al-merito-literario-5.jpg?crop=yes&k=c&w=740&h=510&itok=sHKdWSnq)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 51](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

**2017**

[![Image 52: imagen de luisa valenzuela ](https://universidadeafit.widen.net/content/7dd7ee9c-427d-4920-9882-59bb380cde41/web/luisa-valenzuela-premios-leon-de-greiff.jpg?crop=yes&k=c&w=740&h=510&itok=QY3I6DYC)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 53](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 54: Luisa Valenzuela Premios León de Greiff](https://universidadeafit.widen.net/content/f08b4375-850d-4b1b-88f9-a2a8d92a0453/web/luisa-valenzuela-premios-leon-de-greiff-festival-del-libro-y-la-cultura.jpg?crop=yes&k=c&w=740&h=510&itok=RSyMwbqQ)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 55](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 56: Imagen de luisa valenzuela ](https://universidadeafit.widen.net/content/d54bdb5f-66cb-48f7-b3c4-ca5089fcdc32/web/luisa-valenzuela-premios-leon-de-greiff-fira-autografos.jpg?crop=yes&k=c&w=740&h=510&itok=ke3bM3Xi)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 57](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 58: Imagen de luisa valenzuela ](https://universidadeafit.widen.net/content/7719b208-6899-4188-a813-81aaf5dad19b/web/luisa-valenzuela-premios-leon-de-greiff-juados.jpg?crop=yes&k=c&w=740&h=510&itok=JGyLc-0T)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 59](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 60: Luisa Valenzuela Premios León de Greiff](https://universidadeafit.widen.net/content/741a3e3c-e5bd-4eff-90fd-5f85ede95fa0/web/luisa-valenzuela-participante-premios-leon-de-greiff.jpg?crop=yes&k=c&w=740&h=510&itok=G6ImhuFz)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 61](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 62: Imagen de luisa valenzuela ](https://universidadeafit.widen.net/content/2956e4ad-d7db-4186-8221-5979adabdfb4/web/luisa-valenzuela-firma-de-libros.jpg?crop=yes&k=c&w=740&h=510&itok=ThLxlUVx)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 63](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

**2016**

[![Image 64: Imagen de premio 2016 leon de greiff ](https://universidadeafit.widen.net/content/0c092692-b4e2-4834-920c-943830a418af/web/premio-2016-leon-de-greiff-2.jpg?crop=yes&k=c&w=740&h=510&itok=MsgbSq1W)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 65](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 66: Premiación 2016 León de Greiff](https://universidadeafit.widen.net/content/eb14ae54-e052-42b9-b1c0-8620803320db/web/premio-2016-leon-de-greiff-3.jpg?crop=yes&k=c&w=740&h=510&itok=Bhx66EKF)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 67](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 68: Imagen de entrega premio 2016](https://universidadeafit.widen.net/content/dc6275d6-80db-4bb3-81ac-78a98ed893e3/web/entrega-premio-2016-leon-de-greiff.jpg?crop=yes&k=c&w=740&h=510&itok=9SjuOL1e)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 69](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 70: Imagen de entrega premio 2016](https://universidadeafit.widen.net/content/bf4ccf5d-9ecf-431e-8888-468d08ee0532/web/entrega-premio-2016-leon-de-greiff-2.jpg?crop=yes&k=c&w=740&h=510&itok=UJ0W3JxA)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 71](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 72: Imagen de juan calzadilla ganador ](https://universidadeafit.widen.net/content/cc1ad841-27a0-44f7-bf52-fdd97caf7d78/web/juan-calzadilla-ganador-premios-leon-de-greiff-2.jpg?crop=yes&k=c&w=740&h=510&itok=Kmf3kZLc)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 73](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

[![Image 74: Imagen de entrega premio 2016](https://universidadeafit.widen.net/content/fcff4c79-78eb-4ec8-afc5-ac43645cc415/web/entrega-premio-2016-leon-de-greiff-3.jpg?crop=yes&k=c&w=740&h=510&itok=ScQl7e8o)](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 75](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura/actividades-culturales/premios-literarios/premio-leon-de-greiff-al-merito-literario)

![Image 76: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 77: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 78: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 79: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 80: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 81: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 82: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 83: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 86](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
