Title: Urbam

URL Source: https://www.eafit.edu.co/centros-estudio-incidencia/urbam

Markdown Content:
# Urbam - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/centros-estudio-incidencia/urbam#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/urbam#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/urbam# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/centros-estudio-incidencia/urbam# "English")

*   [Spanish](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)
*   [Inglés](https://www.eafit.edu.co/en/centros-estudio-incidencia/urbam)

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[![Image 21](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

![Image 22](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

![Image 23: Imagen de banner centro de estudios urbanos ](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-07/urbameafit_centrodeestudiosurbanosyambientales_Mesa%20de%20trabajo%201.jpg?itok=pMHLbKlF)

# urbam

urbam EAFIT - Centro de Estudios Urbanos y Ambientales. Somos un laboratorio de investigación, formación y acción que trabaja desde el afecto y la confianza para construir, junto a las comunidades y las instituciones soluciones integrales a los desafíos urbanos y ambientales.

## Diseñamos transformaciones territoriales con conocimiento aplicado

Acompañamos la toma de decisiones con soporte técnico desde nuestros proyectos, integrando capacidades como el diseño de soluciones basadas en la naturaleza, el desarrollo de proyectos urbanos integrales con enfoque de inclusión, la ciencia de datos aplicada a las ciudades y la planeación orientada al transporte. Así conectamos la academia con la acción, generando impacto real en contextos urbanos complejos.

[Descúbrelo aquí](https://www.eafit.edu.co/centros-estudio-incidencia/urbam/que-es-urbam)

![Image 24: Imagen Diseñamos transformaciones territoriales con conocimiento         aplicado ](https://www.eafit.edu.co/sites/default/files/styles/imagen_banner_intermedio_v2/public/2025-07/latinoam%C3%A9rica_Mesa%20de%20trabajo%201.jpg?itok=n3dagGEb)

[![Image 25: Capacidades Urbam](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-07/capacidades%20urbam1-03-01-01.jpg?itok=yAzCe_ix)](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

![Image 26](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

## Los quince años de urbam EAFIT son ejemplo y referente en Barcelona

la revista D’Ur del Laboratorio de Urbanismo de Barcelona en su edición número 13, dedicó todas sus páginas a nuestro trabajo. Esta edición no es un catálogo de nuestros proyectos y procesos, sino la esencia con la que los abordamos: desde la ética, la empatía y la medición.

[Descúbrelo aquí](https://l.instagram.com/?u=https%3A%2F%2Fupcommons.upc.edu%2Fentities%2Fpublication%2F626f0314-2647-481b-b9e1-8ced4bece0a1%3Ffbclid%3DPAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQMMjU2MjgxMDQwNTU4AAGnAml6u8JIfTxskuifyGnMO_55YT3JcpKNzn_ZSJOgcPD0eNBT3KQI6n24ipk_aem_n22ROhfdtLPW_9Ka9bGpLg&e=AT4zNohv7qj3hdBcDTIVHvGfSNPfx0wxqO7OOhMUMipdIe71Zva-8GXCgVWtvTkL3exFaGfNzFTMLN8aqhvSMSo2PEJCNtOl6kVtDoJYyQ)

![Image 27: Imagen Los quince años de urbam EAFIT son ejemplo y referente en Barcelona](https://www.eafit.edu.co/sites/default/files/styles/imagen_banner_intermedio_v2/public/2026-04/WhatsApp%20Image%202026-03-23%20at%207.27.58%20AM.jpeg?itok=xAKkOm-O)

[![Image 28: Capacidades Urbam](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-07/capacidades%20urbam1-03-01-01.jpg?itok=yAzCe_ix)](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

![Image 29](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

### Nuestro portafolio

Academia urbam

![Image 30: Imagen Proyectos urbam ](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-07/proyectos%20urbam.jpg?itok=LzFH-xtU)

Proyectos urbam

[Leer proyectos urbam](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/proyectos)

![Image 31: Imagen Academia urbam ](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-07/241e72f7-0e33-43ca-ba21-a677ead8ad8a-01.jpg?itok=bVl2zndC)

Academia urbam

[Leer academia urbam](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/academia)

![Image 32: Imagen Comunicación urbam ](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-07/comunicaci%C3%B3nurbam.jpg?itok=wDkNMthu)

Comunicación urbam

[Leer comunicación urbam](https://www.eafit.edu.co/comunicacionurbam)

### Equipo de trabajo

![Image 33: Imagen Natalia Castaño Cárdenas](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2026-04/nataliacasta%C3%B1ourbameafit_2_0.jpg?itok=58gcmIYu)

Natalia Castaño Cárdenas

Directora Urbam EAFIT

[Leer más](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/natalia-castano)

![Image 34: Imagen Alejandro Echeverri](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-08/Sin%20t%C3%ADtulo-2-04.jpg?itok=cunbWIyw)

Alejandro Echeverri

Cofundador Urbam EAFIT

[Leer más](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/alejandro-echeverri)

![Image 35: Imagen Juliana Montoya Arango](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-08/Sin%20t%C3%ADtulo-2-01.jpg?itok=PMIL53mS)

Juliana Montoya Arango

Jefa del pregrado en Diseño Urbano y de la Maestría en Procesos Urbanos y Ambientales

[Leer más](https://www.eafit.edu.co/nuestros-profesores/juliana-montoya-arango)

![Image 36: Imagen Angélica Gaviria Agudelo](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-08/Sin%20t%C3%ADtulo-2-02.jpg?itok=P4bi-VmF)

Angélica Gaviria Agudelo

Líder de proyectos Urbam EAFIT

[Leer más](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/angelica-gaviria)

![Image 37: Imagen Juliana Gómez Aristizábal](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-08/Sin%20t%C3%ADtulo-2-07.jpg?itok=zXPZ-cjU)

Juliana Gómez Aristizábal

Coordinadora de proyectos Urbam EAFIT

[Leer más](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/juliana-gomez)

![Image 38: Imagen Luis Miguel Ocampo Marín](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-08/Sin%20t%C3%ADtulo-2-03.jpg?itok=_c4WPog-)

Luis Miguel Ocampo Marín

Líder gráfico urbam EAFIT

[Leer más](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

![Image 39: Imagen Idalia Bermúdez Chaverra](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-08/idaliabermudezurbameafit-06-05.jpg?itok=mg7np8wp)

Idalia Bermúdez Chaverra

Líder Administrativa Urbam EAFIT

[Leer más](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/idalia-bermudez)

![Image 40: Imagen Ana María Castaño Rodríguez](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-08/Sin%20t%C3%ADtulo-2-08.jpg?itok=YLZPpYAb)

Ana María Castaño Rodríguez

Comunicadora Urbam EAFIT

[Leer más](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/ana-castano)

Investigadores

Alejandra María Carmona Duque

Ph.D. en Ingeniería - Recursos Hidráulicos, profesora de la Maestría en Procesos Urbanos y Ambientales y del Pregrado en Diseño Urbano.

[Leer más](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

Carolina García Londoño

Reducción del Riesgo de Desastres PhD, Sistemas de Alerta Temprana, Soluciones basadas en la Naturaleza (NbS), Desarrollo Sostenible. Profesora, directora y asesora de trabajos de grado de la Maestría en Procesos Urbanos y Ambientales.

[Leer más](https://www.linkedin.com/in/carolina-garcia-londo%C3%B1o-41374815/?originalSubdomain=co)

Daniel Correa Botero

Ph.D. Ingeniería de sistemas e informática, coordinador del componente tecnológico de la plataforma Densurbam.

[Leer más](https://www.eafit.edu.co/nuestros-profesores/daniel-correa-botero)

Daniel Rojas Díaz

Magister, Matemática aplicada. Acompaña el componente matemático de la plataforma Densurbam.

[Leer más](https://www.linkedin.com/in/daniel-rojas-d%C3%ADaz-37a5841b4/?originalSubdomain=co)

Juan Pablo Ospina Zapata

Ph. D. Ingeniería en el área de Planeación en transporte, profesor de la maestría en Procesos Urbanos y Ambientales, el pregrado en Diseño Urbano y coordinador del componente de movilidad y transporte.

[Leer más](https://www.eafit.edu.co/nuestros-profesores/juan-pablo-ospina-zapata)

Maria Eugenia Puerta Yepes

Ph. D. Ciencias Matemáticas, coordina el componente matemático de la plataforma Densurbam.

[Leer más](https://www.eafit.edu.co/nuestros-profesores/maria-eugenia-puerta-yepes)

Nataly Montoya Restrepo

Abogada y estudiante de doctorado en Geografía, profesora de la maestría en Procesos Urbanos y Ambientales y del pregrado en Diseño Urbano, acompaña el componente jurídico de proyectos, hizo parte de la Hoja de Ruta del Atrato.

[Leer más](https://www.eafit.edu.co/nuestros-profesores/nataly-montoya-restrepo)

Nicolás Alberto Moreno Reyes

Ph. D. Estadística, acompaña el componente matemático de la plataforma Densurbam.

[Leer más](https://www.eafit.edu.co/nuestros-profesores/nicolas-alberto-moreno-reyes)

Nora Cadavid

Geóloga

[Leer más](https://www.linkedin.com/in/nora-cadavid-87347524/)

Úrsula Jaramillo

[Leer más](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

Santiago Ruíz Arenas

Ph. D. Ingeniería. | UX. Acompaña el componente de experiencia de usuario de la plataforma Densurbam.

[Leer más](https://www.eafit.edu.co/nuestros-profesores/santiago-ruiz-arenas)

[urbam EAFIT](https://www.eafit.edu.co/centros-estudio-incidencia/urbam/que-es-urbam)

## +40

Proyectos de consultoría en Colombia, Panamá, Costa Rica, Jamaica

## 145

Graduados de la Maestría en Procesos Urbanos y Ambientales

## 28

Alianzas internacionales con centros de pensamiento urbano

![Image 41: Imagen Nuestra herramienta Densurbam,  reconocida como investigación  de Mayor Impacto del Año](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2026-01/noticiasurbameafit1-01.jpg?itok=REvJaRAT)

Nuestra herramienta Densurbam, reconocida como investigación de Mayor Impacto del Año

[Leer más](https://www.eafit.edu.co/noticias/eafit-es-noticia/la-excelencia-de-cuatro-eafitenses-fue-reconocida-en-los-premios-medellin)

![Image 42: Imagen urbam llega a sus 15 años con  nuevos retos en la planificación territorial  y la ciencia de datos](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2026-01/noticiasurbameafit1-02.jpg?itok=gaqv_mdA)

urbam llega a sus 15 años con nuevos retos en la planificación territorial y la ciencia de datos

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/urbam-llega-sus-15-anos-con-nuevos-retos-en-la-planificacion-territorial-y)

![Image 43: Imagen urbam EAFIT aporta al Plan Nacional de  Desarrollo del Gobierno de Costa Rica](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2026-01/noticiasurbameafit1-03.jpg?itok=6gWcYDhP)

urbam EAFIT aporta al Plan Nacional de Desarrollo del Gobierno de Costa Rica

[Leer más](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

## Síguenos en nuestras redes sociales

### X

[Síguenos en X](https://x.com/i/flow/login?redirect_after_login=%2Furbam_EAFIT)

### Facebook

[Síguenos en Facebook](https://www.facebook.com/urbameafit/)

### Instagram

[Síguenos en Instagram](https://www.instagram.com/urbameafit/)

### YouTube

[Síguenos en YouTube](https://www.youtube.com/channel/UC996Sa8Rx2NVJVZPGRYdP8A)

[![Image 44](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)](https://www.eafit.edu.co/centros-estudio-incidencia/urbam)

![Image 45: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 46: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 47: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 48: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 49: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 50: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 51: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 52: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 53](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
