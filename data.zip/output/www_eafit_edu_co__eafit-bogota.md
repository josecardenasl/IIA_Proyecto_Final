Title: EAFIT Bogotá

URL Source: https://www.eafit.edu.co/eafit-bogota

Markdown Content:
# EAFIT Bogotá - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/eafit-bogota#main-content)

[![Image 8: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 9: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 10: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/eafit-bogota#)

[![Image 11: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/eafit-bogota# "Spanish")[![Image 12: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/eafit-bogota# "English")

 Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 14: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 15: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 16: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 17: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 18: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 19: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 20: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 21: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 22: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 23: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 24: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 25: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 26: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 27: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 28: Imagen de banner Espacios de esparcimiento EAFIT.](https://universidadeafit.widen.net/content/e93f72c9-32c4-484e-84d1-620f8026363f/web/otros-programas-publicos.jpg?crop=yes&k=c&w=1920&h=788&itok=2csullG7)

# EAFIT Bogotá

*   [Inicio](https://www.eafit.edu.co/)
*    EAFIT Bogotá 

###### ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​¡Estamos​​ en Bog​otá!​

Y desde nue​stra sede contrib​uímos al progreso de las organizaciones aliadas y a consolid​ar la presencia de la Universidad EAFIT en la región centro del país.

[​​​Conoce más sob​re EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota/nosotros)

![Image 29: Imagen Programas de posgrado](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=397&h=253&itok=kPCmGxvj)

Programas de posgrado

[Conoce programas de posgrado](https://www.eafit.edu.co/posgrados?f%5B0%5D=sedes_posgrados%3A111)

![Image 30: Imagen ​​Cursos y diplomados](https://universidadeafit.widen.net/content/badb69d5-222e-40e1-b2b0-eaf61e4cdba5/web/idiomas-fotos-eafit-28.jpg?crop=yes&k=c&w=397&h=253&itok=Dl0i3uTv)

​​Cursos y diplomados

[Conocer cursos y diplomados](https://www.eafit.edu.co/otros-programas)

![Image 31: Imagen ​Consultoría empresarial y proyectos](https://universidadeafit.widen.net/content/e61599a4-557b-4a32-b283-f57c418eb63a/web/nuestras-charlas.jfif)

​Consultoría empresarial y proyectos

[Conocer ​consultoría empresarial](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico)

###### Lo que dicen nuestros Estudiantes y Graduados​

##### ¿Qué inspiro a Andrés a hacer la maestría Financiera de EAFIT Bogotá?

##### Lorena Arrieta, su inspiración en saberes en EAFIT Bogotá

##### Ana María Ospina, su evolución profesional en EAFIT Bogotá

##### MBA, el posgrado de EAFIT Bogotá que transformó a Elías Omar Castillo

#### Nuestras historias

![Image 32: Imagen MasterTalk EAFIT Bogotá Pricing y estrategia de negocio para el 2025, la Guía definitiva para empresas](https://universidadeafit.widen.net/content/2e4c8a52-4bce-4533-a965-9022d6d3bd9a/web/mastertalk-eafit-bogota-pricing.jpg?crop=yes&k=c&w=397&h=253&itok=eEfHLvIX)

MasterTalk EAFIT Bogotá Pricing y estrategia de negocio para el 2025, la Guía definitiva para empresas

[Conocer MasterTalk EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota/mastertalk-eafit-bogota-pricing-y-estrategia-de-negocio-para-el-2025-la-guia-definitiva-para)

![Image 33: Imagen Hub Gremial, plataforma de cocreación para que el conocimiento se vuelva transformación.](https://universidadeafit.widen.net/content/81d5f187-897a-4b8a-9212-cc4951d9c5c3/web/hub-gremial-eafit.png?crop=yes&k=c&w=397&h=253&itok=h3q4nEd-)

Hub Gremial, plataforma de cocreación para que el conocimiento se vuelva transformación.

En Hub gremial, la academia y los gremios co- creamos programas y proyectos con conocimiento de vanguardia que buscan la cualificación del talento, el desarrollo de habilidades y el cierre de brechas de formación en cada sector.

[Conocer Hub Gremial](https://www.eafit.edu.co/eafit-bogota/hub-gremial-plataforma-de-cocreacion-para-que-el-conocimiento-se-vuelva-transformacion)

![Image 34: Imagen Finaliza el Diplomado en Gerencia de Clubes](https://universidadeafit.widen.net/content/42e42dfe-4b1e-4bd5-931d-a1228e060f5b/web/diplomado-gerencia-clubes-web.png?crop=yes&k=c&w=397&h=253&itok=-fR6QpXN)

Finaliza el Diplomado en Gerencia de Clubes

El diplomado en Gerencia de Clubes sociales fue diseñado con el objetivo de desarrollar y fortalecer las competencias necesarias para liderar y gerenciar equipos y proyectos de manera efectiva en este tipo de organizaciones.

[Finaliza el Diplomado](https://www.eafit.edu.co/eafit-bogota/finaliza-el-diplomado-en-gerencia-de-clubes)

Generamos valor y desarrollo para las empresas, los sistemas públicos, y el emprendimiento, a través de la formación, la ciencia, la tecnología y la innovación.​​

Networking de alto nivel que aporta al crecimiento profesional y personal de nuestros estudiantes y graduados.

Experiencias internacionales que complementan la formación y el crecimiento profesional con una perspectiva global.

Conocimiento aplicado y profesores que combinan lo mejor de la experiencia profesional con la producción académica.

Programas acreditados nacional e internacionalmente y que se renuevan con las necesidades de los mercados y las organizaciones.

Un modelo de atención orientado a la cercanía y a disminuir la complejidad para nuestros estudiantes.

Sedes EAFIT 

¿Quieres conocer más sobre nuestros programas y servicios​?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Sedes EAFIT

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfonos*? 

Ciudad de residencia*? 

Programa de interés*? 

Nivel de formación (Seleccione según tu estudio más reciente)* ? 

¿Qué desea saber de nuestro programa?*? 

Inicio del programa 

Canal origen 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 35](https://universidadeafit.widen.net/content/47feabff-d797-418a-a261-b87b409d955e/web/idiomas-eafit-sede-Poblado-1.jpg?crop=yes&k=c&w=470&h=272&itok=0RiCG_G5)

#### **Contacto**

![Image 36: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

​Norma Lasso, Gerente Regional.

Correo: [nlassor@eafit.edu.co](mailto:nlassor@eafit.edu.co)

**Teléfono:** (57) 601 6114618.

![Image 37: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

Carolina Páez Pedraza, Coordinadora de Mercadeo y Ventas.

**Correo:**[icpaezp@eafit.edu.co​](mailto:icpaezp@eafit.edu.co%E2%80%8B)

**Teléfono:** (57) 601 6114618 Ext. 9089.

![Image 38: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

María Victoria Mora, A nalista de Conexiones.

**Correo:**[mvmora@eafit.edu.co​](mailto:mvmora@eafit.edu.co%E2%80%8B)

**Teléfono:** (57) 601 6114618 Ext. 9089.

![Image 39: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

​Sandra Sarmiento, Coordinadora de Operaciones y Gestión Académica.

**Correo:**[smsarmien@eafit.edu.co​](mailto:smsarmien@eafit.edu.co%E2%80%8B)

![Image 40: Imagen ](https://universidadeafit.widen.net/content/aaed507d-ec39-4b22-ba6d-74004b0469e2/web/Foto-estudiantesRegresoclases-040.jpg?crop=yes&k=c&w=770&h=380&itok=f2oaW9g5)

Andrea Abril

**Correo:**[posgradosbogota@eafit.edu.co](https://www.eafit.edu.co/posgradosbogota@eafit.edu.co)

Teléfono: [(57) 3207278226](https://wa.me/573207278226)

![Image 41: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 42: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 43: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 44: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 45: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 46: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 47: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 48: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 49](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
