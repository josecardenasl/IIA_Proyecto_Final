Title: Principal - EAFIT+

URL Source: https://mas.eafit.edu.co/

Markdown Content:
[Modo Laboral | In-Sight:INFLUENCIA SOCIAL:¿Por qué algunos nunca son vistos para los grandes cargos? En este episodio de Modo Laboral, con Carolina Hernández @carolinah.academy, exploramos por qué algunas voces pesan más que otras en los equipos y cómo recuperar tu influencia sin manipular. Click aquí](https://youtu.be/SXDJVnFhPoQ)

[¿Cómo orientarnos ante el suicidio? HAZ UNA PAUSA Hablemos de Salud mental Click aquí](https://youtu.be/YWtanhs9ha8)

[El método Víctor Gaviria – Doctorado en Artes y Humanidades El método Víctor Gaviria – Doctorado en Artes y Humanidades Entrevista a Víctor Gaviria a cargo de Elena Acosta en el lanzamiento de la cohorte 2025 del Doctorado en Artes y Humanidades, el 24 de abril de 2025, a propósito de investigar y crear en poesía, narrativa y cine. Click aquí](https://youtu.be/2nw7xaX6O6Q)

[Modo Laboral | In-Sight:INFLUENCIA SOCIAL:¿Por qué algunos nunca son vistos para los grandes cargos? En este episodio de Modo Laboral, con Carolina Hernández @carolinah.academy, exploramos por qué algunas voces pesan más que otras en los equipos y cómo recuperar tu influencia sin manipular. Click aquí](https://youtu.be/SXDJVnFhPoQ)

[¿Cómo orientarnos ante el suicidio? HAZ UNA PAUSA Hablemos de Salud mental Click aquí](https://youtu.be/YWtanhs9ha8)

[El método Víctor Gaviria – Doctorado en Artes y Humanidades El método Víctor Gaviria – Doctorado en Artes y Humanidades Entrevista a Víctor Gaviria a cargo de Elena Acosta en el lanzamiento de la cohorte 2025 del Doctorado en Artes y Humanidades, el 24 de abril de 2025, a propósito de investigar y crear en poesía, narrativa y cine. Click aquí](https://youtu.be/2nw7xaX6O6Q)

[Modo Laboral | In-Sight:INFLUENCIA SOCIAL:¿Por qué algunos nunca son vistos para los grandes cargos? En este episodio de Modo Laboral, con Carolina Hernández @carolinah.academy, exploramos por qué algunas voces pesan más que otras en los equipos y cómo recuperar tu influencia sin manipular. Click aquí](https://youtu.be/SXDJVnFhPoQ)

[¿Cómo orientarnos ante el suicidio? HAZ UNA PAUSA Hablemos de Salud mental Click aquí](https://youtu.be/YWtanhs9ha8)

[El método Víctor Gaviria – Doctorado en Artes y Humanidades El método Víctor Gaviria – Doctorado en Artes y Humanidades Entrevista a Víctor Gaviria a cargo de Elena Acosta en el lanzamiento de la cohorte 2025 del Doctorado en Artes y Humanidades, el 24 de abril de 2025, a propósito de investigar y crear en poesía, narrativa y cine. Click aquí](https://youtu.be/2nw7xaX6O6Q)

## LíderJeans Episodio 7-Adolfo Meisel – Inteligencia, Caribe y el “Efecto Zapatero”

[General](https://mas.eafit.edu.co/category/general/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

abril 29, 2026

[Ver más](https://mas.eafit.edu.co/general/liderjeans-episodio-7-adolfo-meisel-inteligencia-caribe-y-el-efecto-zapatero/)

[![Image 1](https://mas.eafit.edu.co/wp-content/uploads/2026/04/maxresdefault-7-1.jpg)](https://mas.eafit.edu.co/general/liderjeans-episodio-7-adolfo-meisel-inteligencia-caribe-y-el-efecto-zapatero/)

## Lo más reciente

[![Image 2](https://mas.eafit.edu.co/wp-content/uploads/2026/04/maxresdefault-7.jpg)](https://mas.eafit.edu.co/general/diagnostico-y-tendencias-en-las-unidades-de-sostenibilidad-empresarial-en-colombia-2026/)

[General](https://mas.eafit.edu.co/category/general/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Diagnóstico y tendencias en las unidades de sostenibilidad empresarial en Colombia 2026](https://mas.eafit.edu.co/general/diagnostico-y-tendencias-en-las-unidades-de-sostenibilidad-empresarial-en-colombia-2026/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

abril 20, 2026

[![Image 3](https://mas.eafit.edu.co/wp-content/uploads/2026/04/maxresdefault-6.jpg)](https://mas.eafit.edu.co/general/catedra-innovacion-empresarial/)

[General](https://mas.eafit.edu.co/category/general/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Cátedra Innovación empresarial](https://mas.eafit.edu.co/general/catedra-innovacion-empresarial/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

abril 13, 2026

[![Image 4](https://mas.eafit.edu.co/wp-content/uploads/2026/04/maxresdefault-5.jpg)](https://mas.eafit.edu.co/general/liderjeans-episodio-6-cristina-velez-ni-pelotas-ni-tiranos/)

[General](https://mas.eafit.edu.co/category/general/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Líderjeans Episodio 6. Cristina Vélez: Ni pelotas, ni tiranos](https://mas.eafit.edu.co/general/liderjeans-episodio-6-cristina-velez-ni-pelotas-ni-tiranos/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

abril 13, 2026

[![Image 5](https://mas.eafit.edu.co/wp-content/uploads/2026/04/maxresdefault-4.jpg)](https://mas.eafit.edu.co/general/conversaciones-que-transforman-el-liderazgo-modo-laboral-in-sight/)

[General](https://mas.eafit.edu.co/category/general/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Conversaciones que transforman el liderazgo – Modo Laboral | In-Sight](https://mas.eafit.edu.co/general/conversaciones-que-transforman-el-liderazgo-modo-laboral-in-sight/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

abril 13, 2026

[![Image 6](https://mas.eafit.edu.co/wp-content/uploads/2026/04/Captura-de-pantalla-2026-04-13-163607.png)](https://mas.eafit.edu.co/general/tecnologia-capital-y-vida-la-biodiversidad-como-categoria-de-inversion/)

[General](https://mas.eafit.edu.co/category/general/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Tecnología, capital y vida: la biodiversidad como categoría de inversión](https://mas.eafit.edu.co/general/tecnologia-capital-y-vida-la-biodiversidad-como-categoria-de-inversion/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

abril 13, 2026

[![Image 7](https://mas.eafit.edu.co/wp-content/uploads/2026/04/Captura-de-pantalla-2026-04-13-163233.png)](https://mas.eafit.edu.co/general/liderjeans-episodio-5-daniel-gomez-como-decirle-no-al-presidente-con-argumentos-tecnicos/)

[General](https://mas.eafit.edu.co/category/general/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Líderjeans Episodio 5-Daniel Gómez ¿Cómo decirle “no” al Presidente con argumentos técnicos?](https://mas.eafit.edu.co/general/liderjeans-episodio-5-daniel-gomez-como-decirle-no-al-presidente-con-argumentos-tecnicos/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

abril 13, 2026

## Aprendizaje activo y experiencial

[![Image 8](https://mas.eafit.edu.co/wp-content/uploads/2025/03/Aprende-.png)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/webinar-metodologias-de-aprendizaje-experiencial/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/) | [Transmisiones en vivo](https://mas.eafit.edu.co/category/transmisiones/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Webinar: Metodologías de Aprendizaje Experiencial](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/webinar-metodologias-de-aprendizaje-experiencial/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:257

marzo 4, 2025

[![Image 9](https://mas.eafit.edu.co/wp-content/uploads/2024/08/Ciclo-de-formacion-en-IA-22Inteligencia-Artificial-para-la-lectura-y-la-escritura22.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/ciclo-de-formacion-en-ia-inteligencia-artificial-para-la-lectura-y-la-escritura/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/) | [Transmisiones en vivo](https://mas.eafit.edu.co/category/transmisiones/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Ciclo de formación en IA “Inteligencia Artificial para la lectura y la escritura”](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/ciclo-de-formacion-en-ia-inteligencia-artificial-para-la-lectura-y-la-escritura/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:487

agosto 30, 2024

[![Image 10](https://mas.eafit.edu.co/wp-content/uploads/2024/07/Internacionalizacion-en-el-aula-3-historias-de-exito-en-EAFIT.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/internacionalizacion-en-el-aula-3-historias-de-exito-en-eafit/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Internacionalización en el aula: 3 historias de éxito en EAFIT](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/internacionalizacion-en-el-aula-3-historias-de-exito-en-eafit/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:181

julio 29, 2024

[![Image 11](https://mas.eafit.edu.co/wp-content/uploads/2024/07/Catedra-G8-Etica-y-tecnologia-en-la-era-de-la-Inteligencia-Artificial.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/catedra-g8-etica-y-tecnologia-en-la-era-de-la-inteligencia-artificial/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/) | [Transmisiones en vivo](https://mas.eafit.edu.co/category/transmisiones/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Cátedra G8 – Ética y tecnología en la era de la Inteligencia Artificial](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/catedra-g8-etica-y-tecnologia-en-la-era-de-la-inteligencia-artificial/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:251

julio 23, 2024

[![Image 12](https://mas.eafit.edu.co/wp-content/uploads/2024/06/Aprende-EAFIT-%E2%80%93-IA-desde-una-mirada-didactica.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/aprende-eafit-ia-desde-una-mirada-didactica/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Aprende+ EAFIT – IA desde una mirada didáctica](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/aprende-eafit-ia-desde-una-mirada-didactica/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:509

junio 5, 2024

[![Image 13](https://mas.eafit.edu.co/wp-content/uploads/2024/05/Webinar-una-mirada-del-aprendizaje-experiencial-desde-la-teoria-de-David-Kolb.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/webinar-una-mirada-del-aprendizaje-experiencial-desde-la-teoria-de-david-kolb/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/) | [Transmisiones en vivo](https://mas.eafit.edu.co/category/transmisiones/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Webinar: una mirada del aprendizaje experiencial desde la teoría de David Kolb](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/webinar-una-mirada-del-aprendizaje-experiencial-desde-la-teoria-de-david-kolb/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:467

mayo 23, 2024

[![Image 14](https://mas.eafit.edu.co/wp-content/uploads/2025/03/Aprende-.png)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/webinar-metodologias-de-aprendizaje-experiencial/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/) | [Transmisiones en vivo](https://mas.eafit.edu.co/category/transmisiones/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Webinar: Metodologías de Aprendizaje Experiencial](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/webinar-metodologias-de-aprendizaje-experiencial/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:257

marzo 4, 2025

[![Image 15](https://mas.eafit.edu.co/wp-content/uploads/2024/08/Ciclo-de-formacion-en-IA-22Inteligencia-Artificial-para-la-lectura-y-la-escritura22.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/ciclo-de-formacion-en-ia-inteligencia-artificial-para-la-lectura-y-la-escritura/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/) | [Transmisiones en vivo](https://mas.eafit.edu.co/category/transmisiones/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Ciclo de formación en IA “Inteligencia Artificial para la lectura y la escritura”](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/ciclo-de-formacion-en-ia-inteligencia-artificial-para-la-lectura-y-la-escritura/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:487

agosto 30, 2024

[![Image 16](https://mas.eafit.edu.co/wp-content/uploads/2024/07/Internacionalizacion-en-el-aula-3-historias-de-exito-en-EAFIT.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/internacionalizacion-en-el-aula-3-historias-de-exito-en-eafit/)

[Aprendizaje experiencial](https://mas.eafit.edu.co/category/educacion-y-futuro/aprendizaje-experiencial/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Internacionalización en el aula: 3 historias de éxito en EAFIT](https://mas.eafit.edu.co/educacion-y-futuro/aprendizaje-experiencial/internacionalizacion-en-el-aula-3-historias-de-exito-en-eafit/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:181

julio 29, 2024

## Ciencia, tecnología e innovación

[![Image 17](https://mas.eafit.edu.co/wp-content/uploads/2021/12/Reconocimiento-graduados-que-inspiran-EAFIT-2021-1.png)](https://mas.eafit.edu.co/cuidado-y-bienestar/centro-de-egresados/el-acto-de-entrega-del-reconocimiento-graduados-que-inspiran-eafit-2021/)

[Dirección de Desarrollo Institucional y Egresados](https://mas.eafit.edu.co/category/cuidado-y-bienestar/centro-de-egresados/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [El acto de entrega del Reconocimiento graduados que inspiran EAFIT 2021](https://mas.eafit.edu.co/cuidado-y-bienestar/centro-de-egresados/el-acto-de-entrega-del-reconocimiento-graduados-que-inspiran-eafit-2021/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:1.815

diciembre 10, 2021

[![Image 18](https://mas.eafit.edu.co/wp-content/uploads/2021/07/La-Degradacion-ambiental-de-las-cuencas-hidrograficas-%C2%BFCambio-Climatico-impacto-Humano.png)](https://mas.eafit.edu.co/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/la-degradacion-ambiental-de-las-cuencas-hidrograficas-cambio-climatico-impacto-humano/)

[Ciencias](https://mas.eafit.edu.co/category/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [La Degradación ambiental de las cuencas hidrográficas: ¿Cambio Climático, impacto Humano?](https://mas.eafit.edu.co/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/la-degradacion-ambiental-de-las-cuencas-hidrograficas-cambio-climatico-impacto-humano/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:3.282

julio 25, 2021

[![Image 19](https://mas.eafit.edu.co/wp-content/uploads/2011/04/Grados-posgrados-escuelas-de-Ingenieria-Economia-y-Finanzas-Derecho-y-Ciencias-Universidad-EAFIT-27-de-noviembre-de-2020-500-p.m..png)](https://mas.eafit.edu.co/institucional/grados/graduandos-de-los-posgrados-de-las-escuelas-de-ingenieria-economia-y-finanzas-derecho-y-ciencias/)

[Grados](https://mas.eafit.edu.co/category/institucional/grados/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Graduandos de los posgrados de las escuelas de Ingeniería, Economía y Finanzas, Derecho y Ciencias.](https://mas.eafit.edu.co/institucional/grados/graduandos-de-los-posgrados-de-las-escuelas-de-ingenieria-economia-y-finanzas-derecho-y-ciencias/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:2.821

noviembre 27, 2020

[![Image 20](https://mas.eafit.edu.co/wp-content/uploads/2020/08/9.png)](https://mas.eafit.edu.co/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/inspiratorio-escuela-de-ciencias/)

[Ciencias](https://mas.eafit.edu.co/category/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Inspiratorio Escuela de Ciencias](https://mas.eafit.edu.co/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/inspiratorio-escuela-de-ciencias/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:2.490

agosto 11, 2020

[![Image 21](https://mas.eafit.edu.co/wp-content/uploads/2020/08/Tecnologi%CC%81a-e-innovacio%CC%81n-al-servicio-de-la-vida.png)](https://mas.eafit.edu.co/innovacion/tecnologia-e-innovacion-al-servicio-de-la-vida/)

[Innovación](https://mas.eafit.edu.co/category/innovacion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Tecnología e innovación al servicio de la vida](https://mas.eafit.edu.co/innovacion/tecnologia-e-innovacion-al-servicio-de-la-vida/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:1.383

agosto 5, 2020

[![Image 22](https://mas.eafit.edu.co/wp-content/uploads/2020/08/51.png)](https://mas.eafit.edu.co/cuidado-y-bienestar/cec/inspiratorio-educacion-permanente/)

[Educación para toda la vida](https://mas.eafit.edu.co/category/cuidado-y-bienestar/cec/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Inspiratorio Educación Permanente](https://mas.eafit.edu.co/cuidado-y-bienestar/cec/inspiratorio-educacion-permanente/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:1.017

agosto 3, 2020

[![Image 23](https://mas.eafit.edu.co/wp-content/uploads/2021/12/Reconocimiento-graduados-que-inspiran-EAFIT-2021-1.png)](https://mas.eafit.edu.co/cuidado-y-bienestar/centro-de-egresados/el-acto-de-entrega-del-reconocimiento-graduados-que-inspiran-eafit-2021/)

[Dirección de Desarrollo Institucional y Egresados](https://mas.eafit.edu.co/category/cuidado-y-bienestar/centro-de-egresados/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [El acto de entrega del Reconocimiento graduados que inspiran EAFIT 2021](https://mas.eafit.edu.co/cuidado-y-bienestar/centro-de-egresados/el-acto-de-entrega-del-reconocimiento-graduados-que-inspiran-eafit-2021/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:1.815

diciembre 10, 2021

[![Image 24](https://mas.eafit.edu.co/wp-content/uploads/2021/07/La-Degradacion-ambiental-de-las-cuencas-hidrograficas-%C2%BFCambio-Climatico-impacto-Humano.png)](https://mas.eafit.edu.co/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/la-degradacion-ambiental-de-las-cuencas-hidrograficas-cambio-climatico-impacto-humano/)

[Ciencias](https://mas.eafit.edu.co/category/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [La Degradación ambiental de las cuencas hidrográficas: ¿Cambio Climático, impacto Humano?](https://mas.eafit.edu.co/educacion-y-futuro/ciencias-aplicadas-ingenieria/ciencias/la-degradacion-ambiental-de-las-cuencas-hidrograficas-cambio-climatico-impacto-humano/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:3.282

julio 25, 2021

[![Image 25](https://mas.eafit.edu.co/wp-content/uploads/2011/04/Grados-posgrados-escuelas-de-Ingenieria-Economia-y-Finanzas-Derecho-y-Ciencias-Universidad-EAFIT-27-de-noviembre-de-2020-500-p.m..png)](https://mas.eafit.edu.co/institucional/grados/graduandos-de-los-posgrados-de-las-escuelas-de-ingenieria-economia-y-finanzas-derecho-y-ciencias/)

[Grados](https://mas.eafit.edu.co/category/institucional/grados/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Graduandos de los posgrados de las escuelas de Ingeniería, Economía y Finanzas, Derecho y Ciencias.](https://mas.eafit.edu.co/institucional/grados/graduandos-de-los-posgrados-de-las-escuelas-de-ingenieria-economia-y-finanzas-derecho-y-ciencias/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:2.821

noviembre 27, 2020

## Conexiones que transforman

[![Image 26](https://mas.eafit.edu.co/wp-content/uploads/2024/02/X-Encuentro-de-estudios-coreanos-en-America-Latina-Politica-y-relaciones-internacionales-Historia.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-politica-y-relaciones-internacionales-historia/)

[Escuela de Administración](https://mas.eafit.edu.co/category/educacion-y-futuro/administracion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [X Encuentro de estudios coreanos en América Latina-Política y relaciones internacionales-Historia](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-politica-y-relaciones-internacionales-historia/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:229

febrero 6, 2024

[![Image 27](https://mas.eafit.edu.co/wp-content/uploads/2024/02/X-Encuentro-de-estudios-coreanos-en-America-Latina-%E2%80%93-Historia.png)](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-historia/)

[Escuela de Administración](https://mas.eafit.edu.co/category/educacion-y-futuro/administracion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [X Encuentro de estudios coreanos en América Latina – Historia](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-historia/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:299

febrero 6, 2024

[![Image 28](https://mas.eafit.edu.co/wp-content/uploads/2024/02/X-Encuentro-de-estudios-coreanos-en-America-Latina-Politica-y-relaciones-internacionales-Historia.jpg)](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-politica-y-relaciones-internacionales-historia/)

[Escuela de Administración](https://mas.eafit.edu.co/category/educacion-y-futuro/administracion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [X Encuentro de estudios coreanos en América Latina-Política y relaciones internacionales-Historia](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-politica-y-relaciones-internacionales-historia/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:229

febrero 6, 2024

[![Image 29](https://mas.eafit.edu.co/wp-content/uploads/2024/02/X-Encuentro-de-estudios-coreanos-en-America-Latina-%E2%80%93-Historia.png)](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-historia/)

[Escuela de Administración](https://mas.eafit.edu.co/category/educacion-y-futuro/administracion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [X Encuentro de estudios coreanos en América Latina – Historia](https://mas.eafit.edu.co/educacion-y-futuro/administracion/x-encuentro-de-estudios-coreanos-en-america-latina-historia/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:299

febrero 6, 2024

## Institucional

[![Image 30](https://mas.eafit.edu.co/wp-content/uploads/2025/10/el_colombiano_1280x720-1.jpeg)](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/crisis-de-la-democracia-una-conversacion-para-afilar-la-mirada/)

[Departamento de Comunicación](https://mas.eafit.edu.co/category/institucional/departamento-de-comunicacion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [¿Crisis de la democracia? – Una conversación para afilar la mirada](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/crisis-de-la-democracia-una-conversacion-para-afilar-la-mirada/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

octubre 1, 2025

[![Image 31](https://mas.eafit.edu.co/wp-content/uploads/2025/05/How-is-the-us.png)](https://mas.eafit.edu.co/institucional/mercadeo-institucional/how-is-the-u-s-trade-war-shaping-latin-americas-future/)

[Mercadeo Institucional](https://mas.eafit.edu.co/category/institucional/mercadeo-institucional/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [How Is the U.S. Trade War Shaping Latin America’s Future?](https://mas.eafit.edu.co/institucional/mercadeo-institucional/how-is-the-u-s-trade-war-shaping-latin-americas-future/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:164

mayo 20, 2025

[![Image 32](https://mas.eafit.edu.co/wp-content/uploads/2025/05/Comunicacion-y-comportamiento.png)](https://mas.eafit.edu.co/institucional/mercadeo-institucional/la-maestria-en-estudios-del-comportamiento-invita-a-la-masterclass/)

[Mercadeo Institucional](https://mas.eafit.edu.co/category/institucional/mercadeo-institucional/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [La Maestría en Estudios del Comportamiento invita a la Masterclass:](https://mas.eafit.edu.co/institucional/mercadeo-institucional/la-maestria-en-estudios-del-comportamiento-invita-a-la-masterclass/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:122

mayo 20, 2025

[![Image 33](https://mas.eafit.edu.co/wp-content/uploads/2025/04/Necesitamos-mas-y-mejores-gerentes.png)](https://mas.eafit.edu.co/institucional/mercadeo-institucional/necesitamos-mas-y-mejores-gerentes-sociales-2/)

[Mercadeo Institucional](https://mas.eafit.edu.co/category/institucional/mercadeo-institucional/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Necesitamos más y mejores gerentes sociales](https://mas.eafit.edu.co/institucional/mercadeo-institucional/necesitamos-mas-y-mejores-gerentes-sociales-2/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:218

abril 25, 2025

[![Image 34](https://mas.eafit.edu.co/wp-content/uploads/2024/12/LOGO-EAFIT-2.jpeg)](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/induccion-a-estudiantes-viernes-17-de-enero-2025/)

[Departamento de Comunicación](https://mas.eafit.edu.co/category/institucional/departamento-de-comunicacion/) | [Transmisiones en vivo](https://mas.eafit.edu.co/category/transmisiones/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Inducción a estudiantes, viernes 17 de enero 2025](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/induccion-a-estudiantes-viernes-17-de-enero-2025/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:90

enero 16, 2025

[![Image 35](https://mas.eafit.edu.co/wp-content/uploads/2024/12/LOGO-EAFIT-2.jpeg)](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/induccion-a-estudiantes-miercoles-15-de-enero-2025/)

[Departamento de Comunicación](https://mas.eafit.edu.co/category/institucional/departamento-de-comunicacion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [Inducción a estudiantes, miércoles 15 de enero 2025](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/induccion-a-estudiantes-miercoles-15-de-enero-2025/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:161

enero 16, 2025

[![Image 36](https://mas.eafit.edu.co/wp-content/uploads/2025/10/el_colombiano_1280x720-1.jpeg)](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/crisis-de-la-democracia-una-conversacion-para-afilar-la-mirada/)

[Departamento de Comunicación](https://mas.eafit.edu.co/category/institucional/departamento-de-comunicacion/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [¿Crisis de la democracia? – Una conversación para afilar la mirada](https://mas.eafit.edu.co/institucional/departamento-de-comunicacion/crisis-de-la-democracia-una-conversacion-para-afilar-la-mirada/)

[0](https://mas.eafit.edu.co/# "Like this")

Lo han visto:0

octubre 1, 2025

[![Image 37](https://mas.eafit.edu.co/wp-content/uploads/2025/05/How-is-the-us.png)](https://mas.eafit.edu.co/institucional/mercadeo-institucional/how-is-the-u-s-trade-war-shaping-latin-americas-future/)

[Mercadeo Institucional](https://mas.eafit.edu.co/category/institucional/mercadeo-institucional/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [How Is the U.S. Trade War Shaping Latin America’s Future?](https://mas.eafit.edu.co/institucional/mercadeo-institucional/how-is-the-u-s-trade-war-shaping-latin-americas-future/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:164

mayo 20, 2025

[![Image 38](https://mas.eafit.edu.co/wp-content/uploads/2025/05/Comunicacion-y-comportamiento.png)](https://mas.eafit.edu.co/institucional/mercadeo-institucional/la-maestria-en-estudios-del-comportamiento-invita-a-la-masterclass/)

[Mercadeo Institucional](https://mas.eafit.edu.co/category/institucional/mercadeo-institucional/)

[Vídeo](https://mas.eafit.edu.co/type/video/)

## [La Maestría en Estudios del Comportamiento invita a la Masterclass:](https://mas.eafit.edu.co/institucional/mercadeo-institucional/la-maestria-en-estudios-del-comportamiento-invita-a-la-masterclass/)

[1](https://mas.eafit.edu.co/# "Like this")

Lo han visto:122

mayo 20, 2025
