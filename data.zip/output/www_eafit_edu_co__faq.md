Title: Preguntas Frecuentes

URL Source: https://www.eafit.edu.co/faq

Published Time: Thu, 07 May 2026 20:37:14 GMT

Markdown Content:
Aspirantes

## Pregrado

¿Cómo me inscribo a Pregrado?

Inscribirte a un programa de pregrado es muy facil, aquí te dejamos unos pasos que puedes seguir:

1. Ingresa a [Epik](https://Inscribirte a un programa de pregrado es muy facil, aquí te dejamos unos pasos que puedes seguir:  1. Ingresa a Epik, crea una cuenta o inicia sesión.  2. Selecciona el rol “Solicitante” → “Inscripción Pregradoy Posgrado”. 3. completa el formulario (datos personales, programa, documentos, etc.)  4. Paga la inscripción y, si aplica, agenda la entrevista.), crea una cuenta o inicia sesión.

2. Selecciona el rol “Solicitante” → “Inscripción Pregradoy Posgrado”.

3. completa el formulario (datos personales, programa, documentos, etc.)

4. Paga la inscripción y, si aplica, agenda la entrevista.

Aquí te dejamos una guía a seguir para saber el estado de tu inscripción:

Ingesa a [Epik](https://www.eafit.edu.co/epik) → “Inscrip. Pregrado y Posgrado” → “Resumen de Solicitudes” para verificar si tu solicitud está en estado registrada, en revisión, admitido, etc.

Si ya hiciste el pago, entrega de documentos (si aplica) entrevista o examen, solo debes esperar. Cuando el proceso de admisión finalice, recibirás un correo con tu resultado.

Revisa tu bandeja de entrada, spam u “Otros”. El correo llega desde notificaciones@eafit.edu.co, asunto “EAFIT - Tu usuario está listo - Cuenta creada”. Si no lo encuentras, contacta a [saul@eafit.edu.co](mailto:saul@eafit.edu.co) o Mesa de Ayuda: (604) 2619500 ext. 9433.

Si diligenciaste el registro en Epik, recibirás el correo con usuario y contraseña al correo personal registrado. Si no llega, comunícate con Mesa de Ayuda o escribe a [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

Sí. En la última página debes responder las preguntas finales y dar clic en “Finalizar”, luego serás redirigido automáticamente al inicio de sesión de Epik.

En caso de presentarse algún inconveniente con el registro de tu información, comunícate a través del correo electrónico [contacto@eafit.edu.co](mailto:contacto@eafit.edu.co) y descríbenos el detalle del error que se te ha generado y así te ayudarémos a que finalices tu inscripción exitosamente.

Durante la realización del formulario, en “Anexo de documentos”, puedes subirlos (PDF, JPG o Word). Si no los tienes listos en el momento, puedes adjuntarlos después en [Epik](https://www.eafit.edu.co/epik) → “Anexo de Documentos”.

Verifica que el archivo sea PDF, Word o JPG y que no supere el peso permitido. Si el error continúa, escribe a contacto@eafit.edu.co

Al pagar la inscripción, si el programa requiere entrevista, [Epik](https://www.eafit.edu.co/epik) te habilitará el servicio para agendarla desde “Servicios y Certificados” → “Cita de Entrevista de Admisión”.

1. Cambia la modalidad (virtual/presencial) y realiza la búsqueda, es posible que estés buscando en la modalidad que el coordinador no tiene disponibilidad.

2. Amplía el rango de búsqueda, es posible que las citas que estén disponibles no sean cercanas a la fecha actual.​

3) Si sigues sin citas, activa la opción “No encontré cita”, el programa creará disponibilidad.

Puedes reprogramar si faltan más de 4 horas para la cita. Si es menos tiempo, escribe a contacto@eafit.edu.co, WhatsApp [+573216420341](https://api.whatsapp.com/send/?phone=573216420341&text&type=phone_number&app_absent=0) o llamando al (604) 2619500.

No. Para primer semestre, la Universidad te asigna el horario de clases automáticamente.

Los admitidos nuevos reciben su horario asignado desde Admisiones y Registro. La matrícula se genera automáticamente. Consulta más detalles en la [Guía de Aspirantes.](https://www.eafit.edu.co/pregrados)

No. En el primer semestre la Universidad realiza el registro inicial de materias por ti.

Durante el diligenciamiento del formulario, encontrarás en cada sección de preguntas el ícono de Información, puedes dar clic en este para revisar los mensajes que te ayudarán a diligenciar más fácil tu formulario.

Es el trámite que permite a un aspirante admitido, que no realizó el pago de la matrícula, conservar su proceso de inscripció por máximo un año.

Beneficios de solicitarla:

Ahorro económico: No requiere pagar un nuevo formulario de inscripción.

Agilidad: Se omite la carga de documentos y la presentación de una nueva entrevista.

Continuidad: Los datos permanecen activos en el sistema para facilitar el ingreso futuro.

Importante: Si no realizas la reserva, tu proceso de admisión será anulado y deberás iniciar desde cero (pago de inscripción, documentos y entrevista) para el próximo periodo.

¿Cómo me inscribo a Posgrado?

Ingresa a [Epik](https://www.eafit.edu.co/epik), crea una cuenta o inicia sesión. Luego:

- Selecciona el rol “Solicitante” → “Inscripción Pregrado y Posgrado”.

- Diligencia la información del formulario (datos personales, programa, académicos, familiares, documentos, etc.).

- Envía la solicitud y realiza el pago en línea o descarga la liquidación para pagar en un banco aliado.

- Si tu programa requiere entrevista, agenda la cita en el módulo “Servicios y Certificados” → “Solicitud de Servicios” → “Cita de Entrevista de Admisión”.

- Una vez cumplas los pasos y seas admitido, podrás realizar la matrícula

Los requisitos varían según el programa, pero generalmente incluyen:

• Formulario completo en Epik

• Título profesional o acta de grado

• Hoja de vida actualizada

• Documento de identidad

• Entrevista o prueba (si aplica).

Consulta los requisitos específicos en la página del programa que te interesa. [Haz click aquí](https://www.eafit.edu.co/posgrados)

Ingresa al autoservicio de [Epik](https://www.eafit.edu.co/epik) → “Inscrip. Pregrado y Posgrado” → “Resumen de Solicitudes”, donde podrás ver si tu proceso está registrado, en revisión, admitido o pendiente.

Si ya pagaste y enviaste la documentación, debes esperar a que se procese tu solicitud. Cuando el área de Admisiones valide tus requisitos, recibirás por correo la confirmación o el resultado del proceso.

Una vez realizado el pago de tu inscripción, podrás ingresar a tu autoservicio de [Epik](https://www.eafit.edu.co/epik) para seleccionar la fecha y la hora de tu entrevista que más se acomode a tu disponibilidad.

Para realizar la cita de tu entrevista ingresa a Epik​ con tu usuario y contraseña. A continuación, sigue estos pasos:

- Ingresa al módulo de "Servicios y Certificados".

- Accede a la "Solicitud de Servicios".

- Elige la opción de "Cita de Entrevista de Admisión".

- Da clic en "Buscar Cita".

- Selecciona la modalidad que se ajuste a tu preferencia.

- Elige la fecha y hora de acuerdo a tu disponibilidad.

- Selecciona tu cita.

Es imporante que des clic en la opción "Guardar" y que te aparezca el resumen de tu solicitud

Activa la opción “No encontré cita” en [Epik](https://www.eafit.edu.co/epik). El sistema notificará al jefe del programa, quien generará nuevos espacios. Luego podrás volver a ingresar para seleccionarla.

Cuando activas esta opción, el jefe del programa recibe una notificación para habilitar nuevas fechas. Si necesitas una fecha o modalidad específica, comunícate directamente con el jefe del programa.

Cambia la modalidad (virtual/presencial) o amplía el rango de búsqueda de fechas. Es posible que las citas disponibles no estén cercanas a la fecha actual.

Puedes reprogramar si faltan más de 4 horas para la cita. Si faltan menos, escribe a contacto@eafit.edu.co

o comunícate vía WhatsApp ([573226783083](https://api.whatsapp.com/send?phone=573226783083)) o al (604) 2619500.

Durante el formulario de Epik, en “Anexo de documentos”, puedes subirlos en formato PDF, Word o JPG. Si no los tienes listos, puedes hacerlo después desde el módulo “Anexo de Documentos” en [Epik.](https://www.eafit.edu.co/epik)

Asegúrate de que el archivo sea PDF, Word o JPG y que no supere el tamaño permitido. Si el error continúa, escribe a [contacto@eafit.edu.co](mailto:contacto@eafit.edu.co) o comunícate al WhatsApp ([573226783083](https://api.whatsapp.com/send?phone=573226783083))

Envía un correo a [contacto@eafit.edu.co](mailto:contacto@eafit.edu.co) con una descripción del problema y una captura de pantalla. El equipo de Registro te ayudará a completar el proceso.

Es el trámite que permite a un aspirante admitido, que no realizó el pago de la matrícula, conservar su proceso de inscripción por máximo un año.

**Beneficios de solicitarla:**

Ahorro económico: No requiere pagar un nuevo formulario de inscripción.

Agilidad: Se omite la carga de documentos y la presentación de una nueva entrevista.

Continuidad: Los datos permanecen activos en el sistema para facilitar el ingreso futuro.

**Importante:** Si no realizas la reserva, tu proceso de admisión será anulado y deberás iniciar desde cero (pago de inscripción, documentos y entrevista) para el próximo periodo.

No. Los horarios son asignados por Registro Académico en tu primer semestre.

​Puedes consultar la oferta completa y los detalles de cada programa (modalidad, duración, requisitos, etc.) en la página de Programas de Posgrado EAFIT. [Aquí](https://www.eafit.edu.co/posgrados)

Si el sistema no carga o no puedes ingresar, comunícate con Mesa de Ayuda TI al correo saul@eafit.edu.co

o teléfono (604) 2619500 ext. 9433.

Puedes consultar todas las preguntas frecuentes actualizadas sobre Epik, admisiones, matrícula y soporte en el portal institucional.[Aquí](https://www.eafit.edu.co/epik)

Soy estudiante de Pregrado

Estudiantes nuevos: del 24 de febrero hasta el 19 de junio del 2026

Estudiantes activos:

• Registro de materias: del 11 de mayo al 22 de mayo del 2026.

• Selección de horario: del 16 al 23 de junio del 2026, desde las 8:00 a. m.

• Consulta del instructivo: 12 de junio del 2026, en la opción Notas de interés del Autoservicio.

Reintegros y reingresos: desde el 25 de junio del 2026 (2:00 p. m.).

Estudiantes que no registraron materias a tiempo: del 24 de junio al 6 de julio del 2026.

Consulta el cronograma completo haciendo [Clic Aquí](https://www.eafit.edu.co/cronograma-actividades-academicas)

Ingresa a [Epik](https://www.eafit.edu.co/epik) con tu usuario y contraseña → módulo “Mi Matrícula” → “Registro de Asignaturas” → “Iniciar Registro”.

Sigue el paso a paso para seleccionar tus materias según tu plan de estudios.

El registro estará disponible del 11 de mayo al 22 de mayo del 2026.

Si no hiciste el registro dentro del tiempo indicado, podrás hacerlo del 24 de junio al 6 de julio del 2026.

Ingresa a [Epik](https://www.eafit.edu.co/epik) → Mi Matrícula → Selección de Horario → Seleccionar Horario.

**La cita** de inscripción de clases es el turno asignado por la Universidad que define el día y la hora exacta a partir de los cuales se te habilita el sistema en EPIK para inscribir tus materias.

Ten en cuenta estos puntos clave:

**Prioridad:** El orden de las citas se asigna generalmente según el promedio académico. Entre más pronto sea tu cita, más opciones de cupos y horarios encontrarás disponibles.

**No es presencial ni asistido:** Todo el proceso se realiza de forma virtual a través del autoservicio de EPIK. Ten en cuenta que es un paso de**autogestión individual,** lo que significa que tú mismo eres responsable de elegir y registrar tus materias en el sistema; no contarás con un asesor en tiempo real para realizar el proceso por ti.

Entra a [Epik](https://www.eafit.edu.co/epik) → Mi Matrícula → Selección de Horario.

En la parte inferior verás la fecha y hora de tu cita, además de la oferta disponible de materias.

La programación académica está diseñada para evitar cruces dentro de un mismo semestre y carrera. Si se presentan, puede deberse a que estás tomando materias de distintos semestres o fuera del plan ideal. Te recomendamos revisar tu plan con tu asesor académico.

Se trata de un grupo unión, que luego se dividirá para actividades de práctica o laboratorio.

Es una materia programada como grupo unión; más adelante se separará en grupos específicos según las actividades o prácticas.

En la selección de horario, si el curso requiere asistencia al campus, el sistema mostrará una alerta indicando que es presencial. Si no aparece, será virtual o híbrido según el tipo de materia.

Ingresa a [Epik](https://www.eafit.edu.co/epik) → “Mis Pendientes” → “Retención”, donde podrás ver tus documentos o saldos pendientes.

En caso de documentos, puedes adjuntarlos en “Anexo de Documentos"

Te dejamos el paso a paso [aquí](https://www.instagram.com/tv/CVxzJt7lsnZ/?utm_medium=copy_link).

Entra a [Epik](https://www.eafit.edu.co/epik)→ “Progreso Académico” → “Mi Plan Académico”, selecciona tu nivel (Pregrado o Posgrado) y podrás ver todas tus materias, notas y progreso.

Las calificaciones no se entregan impresas. Puedes consultarlas a través de [EAFIT Interactiva](https://interactivavirtual.eafit.edu.co/d2l/loginh/) o directamente en [Epik](https://www.eafit.edu.co/epik), una vez sean publicadas por los docentes.

Si actualmente tienes clases, estás próximo a graduarte o acabas de finalizar un programa, tu cuenta seguirá activa.

Si no puedes acceder, comunícate con Mesa de Ayuda TI:

📞 (604) 2619500 ext. 9433

✉️ [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

Lunes a viernes, de 8:00 a. m. a 6:00 p. m., en jornada continua. Atención presencial en el Bloque 29, piso 1.

Soy estudiante de Posgrado

Estudiantes nuevos: el proceso de matrícula se habilita una vez recibes la notificación de admisión. Desde Admisiones y Registro te enviarán la información con los pasos y fechas específicas para tu programa.

Estudiantes activos: normalmente, el proceso se realiza a partir del 12 de junio del 2026, de acuerdo con el cronograma académico institucional.

Puedes consultar las fechas exactas en el calendario académico de posgrados dando [clic aquí](https://universidadeafit.widen.net/s/nlrz8zknx7/calendarios-academicos-posgrado-estudiantes)

Ingresa a [Epik](https://www.eafit.edu.co/epik) con tu usuario y contraseña → módulo “Mi Matrícula” → “Registro de Asignaturas” → “Iniciar Registro”.

Selecciona las materias correspondientes a tu plan de estudios.

Si tu programa tiene modalidad modular o intensiva, verifica con la coordinación académica los periodos en que se ofrecen los cursos.

Podrás hacer tu registro fuera del plazo inicial si tu coordinación académica lo autoriza. Comunícate con el área de Admisiones y Registro o con la coordinación de tu posgrado para reabrir la inscripción.

[contacto@eafit.edu.co](mailto:contacto@eafit.edu.co)

En [Epik](https://www.eafit.edu.co/epik), al ingresar al módulo “Mi Matrícula” → “Registro de Asignaturas”, podrás visualizar la oferta disponible.

También puedes solicitar la oferta directamente a la coordinación del programa, especialmente si tu posgrado maneja bloques modulares o electivas con cupos limitados.

La mayoría de programas de posgrado manejan horarios fijos según su modalidad (semanal, quincenal o modular). Sin embargo, si tu programa te permite elegir grupo u horario, podrás hacerlo en [Epik](https://www.eafit.edu.co/epik) → “Mi Matrícula” → “Selección de Horario”.

Ingresa a [Epik](https://www.eafit.edu.co/epik) → “Mis Pendientes” → “Retención”, allí podrás consultar si tienes documentos, pagos o compromisos pendientes. Si se trata de documentos, puedes adjuntarlos directamente en “Anexo de Documentos”. Puedes revisar también, el siguiente [enlace](https://www.instagram.com/tv/CVxzJt7lsnZ/?utm_medium=copy_link).

Una vez hayas realizado la inscripción de materias o confirmado tu matrícula, el sistema generará automáticamente tu liquidación en [Epik](https://www.eafit.edu.co/epik) → “Mi Matrícula” → “Liquidación de Matrícula”.

Podrás pagar en línea o descargar la liquidación para pagarla en un banco aliado de la Universidad.

Si el valor no aparece o presenta error, comunícate con Servicios Financieros por medio de su correo electrónico [serviciosfinancieros@eafit.edu.co](mailto:serviciosfinanciero@eafit.edu.co)

Verifica tu conexión y navegador (usa preferiblemente Google Chrome). Si el error persiste, envía un pantallazo del mensaje a [contacto@eafit.edu.co](mailto:contacto@eafit.edu.co), indicando tu número de documento, programa y descripción del problema.

Ingresa a [Epik](https://www.eafit.edu.co/epik) → “Progreso Académico” → “Mi Plan Académico”, selecciona tu programa de posgrado y podrás visualizar todas tus materias cursadas, notas y créditos acumulados.

Las calificaciones se publican en [Epik](https://www.eafit.edu.co/epik) una vez sean registradas por los docentes. También puedes revisarlas en [EAFIT Interactiva](https://interactivavirtual.eafit.edu.co/d2l/loginh/).

Si el inconveniente es técnico, comunícate con la Mesa de Ayuda TI:

- Medellín: (604) 2619500 ext. 9433

✉ [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

Si es un asunto académico o de registro, escribe a:

✉ [contacto@eafit.edu.co](mailto:contacto@eafit.edu.co)

Lunes a viernes, de 8:00 a. m. a 6:00 p. m., en jornada continua. Atención presencial en el Bloque 29, piso 1.

Reajustes

El reajuste de matrícula es el periodo en el que los estudiantes pueden modificar su carga académica después del registro inicial, ya sea adicionando, cancelando o cambiando materias u horarios. Este proceso solo está disponible durante las fechas establecidas en el calendario académico y siempre debe realizarse por [Epik](https://www.eafit.edu.co/epik).

Importante: Esta opción no aplica para estudiantes nuevos de pregrado, quienes deben mantener el horario asignado para su primer semestre.

Puedes adicionar materias en reajustes de matrícula, únicamente en las fechas establecidas y de acuerdo con la cita asignada, siempre y cuando haya pagado la matrícula.

PREGRADO

Estudiantes regulares:

Semestre 2026-2: del 9 al 17 de julio de 2026.

​

POSGRADO

Estudiantes regulares:

Semestre 2026-2: del 9 al 17 de julio de 2026.

Reajuste de horario, adiciones, siempre y cuando haya pagado la matrícula.

Solamente por el autoservicio de [Epik](https://www.eafit.edu.co/Epik).

Los reajustes se llevan a cabo en las fechas indicadas por la Universidad para cada semestre académico.

Para el semestre 2026-2 (pregrados): del 9 al 17 de julio de 2026.

Debes haber realizado el pago de matrícula antes de hacer cualquier cambio. (Recuerda revisar las fechas de pregrado en el [cronograma académico](https://www.eafit.edu.co/cronograma-actividades-academicas))

Sí. Durante el periodo de reajustes puedes cancelar materias directamente en [Epik](https://www.eafit.edu.co/Epik), siempre y cuando la asignatura no haya sido evaluada al 100%.

Si el sistema no te permite hacerlo, comunícate con tu profesor o con Registro Académico.

El pago de reajustes debe realizarse dentro de las fechas establecidas en el calendario académico vigente y una vez hayas efectuado la adición o modificación de materias en [Epik](https://www.eafit.edu.co/Epik).

Es importante realizar el pago oportunamente para evitar bloqueos en el sistema o recargos por pago extemporáneo.

Pago de reajustes: del 21 de julio al 24 de julio del 2026.

Puedes consultar las fechas oficiales en el [cronograma académico](https://www.eafit.edu.co/cronograma-actividades-academicas) publicado por la Universidad.

Línea de Énfasis

Es una ruta de profundización académica dentro de tu programa que te permite orientar tu formación hacia un tema o campo de especial interés. Cada programa define sus propias líneas de énfasis y los requisitos para elegirlas.

Puedes encontrarlas en el pensum de tu [pregrado](https://www.eafit.edu.co/pregrados).

Generalmente, la selección se realiza a partir de los semestres intermedios o avanzados, según lo establecido por cada programa académico. Te recomendamos revisar tu plan de estudios o consultar con tu director de programa.

Te contamos los pasos para elegir tu línea de énfasis

Ingresa a [Epik](https://www.eafit.edu.co/epik) con tu usuario y contraseña

En el módulo ""Información académica""

Da clic en el botón línea de énfasis

Escoge el programa académico

Da clic en el botón continuar

Clic en la lupa

Escoge la línea de énfasis que estas interesado

Clic en el botón aceptar

Conoce como realizar el proceso [aquí](https://www.youtube.com/watch?v=IkWGSj6KHbc)

Sí, puedes solicitar el cambio, pero depende de la disponibilidad de cupos y de que cumplas los requisitos del nuevo énfasis. El trámite se realiza a través de [Epik](https://www.eafit.edu.co/Epik) → Solicitud de Servicios → Cambio de Línea de Énfasis.

Pago de matrícula

Conoce los programas y los semestres a cursar en cada programa ingresando [aquí​](https://www.eafit.edu.co/pregrados)

El valor de la matrícula puede variar según el programa. Puedes consultar el listado completo y actualizado de las tarifas de los programas de pregrado [aquí](https://www.eafit.edu.co/tarifas-de-programas-de-pregrado).

Conoce los programas y los semestres a cursar en cada programa ingresando [aquí​](https://www.eafit.edu.co/posgrados?utm_source=google&utm_medium=paid&utm_campaign=Julius_SEM_Posgrados_Brand_MED_PER_BOG&utm_term=posgrados%20eafit&utm_content=&gad_source=1&gad_campaignid=22278052033&gbraid=0AAAAADM65Od-OJii69)

Al igual que en pregrado, la información de costos de posgrados se actualiza por semestre. Puedes ver el listado oficial de tarifas vigentes en el siguiente [enlace](https://www.eafit.edu.co/tarifas-de-programas-de-posgrado).

El costo de la matrícula se ajusta anualmente según el índice de inflación y las políticas institucionales. Te recomendamos revisar las tarifas publicadas cada período académico.

Como estudiante, puedes encontrar tu liquidación o recibo de matrícula ingresando a la plataforma [Epik](https://www.eafit.edu.co/Epik) con tu usuario y contraseña. Dirígete al módulo "Mis Finanzas" y luego a la opción "Centro de Pagos".

EAFIT ofrece varias modalidades de pago para tu comodidad:

1. Pago en línea (PSE): a través de la plataforma [Epik](https://www.eafit.edu.co/Epik) usando tu tarjeta débito o crédito.

2. Pago en bancos: puedes descargar e imprimir el recibo de pago para consignar en las entidades bancarias autorizadas (Davivienda, Bancolombia, Occidente, Bogotá, AV Villas).

Sí. La universidad ofrece varias líneas de financiación, incluyendo opciones a corto y largo plazo, para ayudarte a gestionar el pago de tu matrícula. Te invitamos a simular tu crédito y conocer los requisitos. [Clic aquí](https://www.eafit.edu.co/simulador-de-eafit-tu-alcance)

No te preocupes. Debes comunicarte lo antes posible con el área de Servicios Financieros de la Universidad. Ellos actualizarán la fecha de tu documento de pago para que puedas descargarlo nuevamente en PDF o realizar el pago en línea a través de [Epik](https://www.eafit.edu.co/Epik). Contáctalos enviando un correo a: [serviciosfinancieros@eafit.edu.co](mailto:serviciosfinancieros@eafit.edu.co)

Por lo general, los pagos en línea se reflejan de inmediato, pero si realizaste el pago en una sucursal bancaria, puede tardar hasta 48 horas. Si pasado ese tiempo tu pago sigue sin aparecer, contacta al área de Servicios Financieros con el comprobante de pago. Correo: [serviciosfinancieros@eafit.edu.co](mailto:serviciosfinancieros@eafit.edu.co)

Becas y Financiación

EAFIT dispone de diferentes modalidades de becas y estímulos, incluyendo apoyos por mérito académico, deportivos y socioeconómicos, para ayudarte a iniciar o continuar tus estudios de pregrado. [Ver aquí](https://www.eafit.edu.co/becas-para-estudiantes-activos-en-programas-de-pregrado)

La Universidad cuenta con diversas modalidades de estímulos, reconocimientos y becas condonables, tanto para estudiantes nuevos como para activos, que buscan continuar sus estudios de posgrado. [Ver aquí](https://www.eafit.edu.co/becas-y-financiacion)

Sí. Puedes acceder a descuentos en la matrícula si tienes familiares directos estudiando en EAFIT (consanguinidad). También existen convenios con empresas e instituciones. [Ver aquí](https://universidadeafit.widen.net/s/ddhfsdxdsl/descuento-por-consanguinidad)

¡Claro! EAFIT ofrece convenios y descuentos específicos que aplican a programas de cursos, diplomados y educación continua. [Ver aquí​](https://www.eafit.edu.co/descuentos-y-convenios)

Para más información, contacta al número: (57) ​604 2619500 opción 1 - opción 3 o dirígete al Bloque 29 primer piso , también, puedes escribir al correo electrónico [educacioncontinua@eafit.edu.co](mailto:educacioncontinua@eafit.edu.co)

EAFIT ofrece opciones de financiación propias a través del programa "EAFIT a tu Alcance", así como convenios externos con entidades financieras como el ICETEX. Nuestro objetivo es brindarte flexibilidad y condiciones favorables. Para más información haz [Clic aquí](https://www.eafit.edu.co/becas-y-financiacion/eafit-a-tu-alcance).

EAFIT a tu Alcance tiene diversas líneas de financiación diseñadas para adaptarse a tus necesidades de pago, permitiéndote financiar un porcentaje de tu matrícula a corto o largo plazo.

[Ingresa aquí​](https://www.eafit.edu.co/becas-y-financiacion/eafit-a-tu-alcance)

Puedes utilizar nuestro simulador en línea para estimar el valor aproximado de tus cuotas y el plan de pagos según el tipo y monto de financiación que requieras. [Clic aquí](https://www.eafit.edu.co/simulador-de-eafit-tu-alcance)

Puedes realizar tus pagos de manera oportuna a través de Pagos en Línea (PSE), o con tu recibo en las entidades bancarias autorizadas. Da [Clic aquí](https://www.eafit.edu.co/alternativas-de-financiacion-y-pago)

Es crucial. La solicitud del crédito (ya sea EAFIT o externo) debe realizarse con la debida anticipación para que la aprobación y el desembolso se hagan antes de la fecha límite de pago establecida en el calendario académico. Esto evita incurrir en recargos por pago extemporáneo.

Certificados

Certificado de inscrito:

Lo puedes solicitar ingresando a [Epik](https://www.eafit.edu.co/Epik) en la opción "Servicios y Certificados" y allí sigue el paso a paso para solicitar tu certificado que te explicamos a continuación:

- Haz clic en el botón ""Nueva Solicitud""

- Elige el certificado que requieras

- Selecciona el idioma del certificado

- Haz clic en ""Acciones"" para ver la versión preliminar

- Cuando estés seguro del certificado, nuevamente haz clic en ""Acciones""

- Haz clic en la opción ""Solicitar Certificado"".

Certificado de Contenidos de Materias:

Lo puedes solicitar ingresando a Epik con usuario y contraseña, en el módulo ""Servicios y Certificados"", ""Solicitud de Servicios"".

Si olvidaste o tienes deshabilitado el usuario y clave de la Universidad:

Lo puedes solicitar escribiendo al correo admisiones.registro@eafit.edu.co, o directamente en la taquilla #1 de Admisiones y Registro, ubicada en el bloque 29, primer piso.

Si te encuentras en el exterior o no puedes acercarte a la universidad, escribe un correo a Saul saul@eafit.edu.co para que te ayuden con tu correo y con [Epik](https://www.eafit.edu.co/Epik).

Aquellos que corresponden a la información académica de estudiantes activos, egresados, graduados o retirados.

Características:

Están categorizados por temas, según el tipo de solicitante y su estado actual con la Universidad.

Los traducidos al idioma inglés no son realizados por traductor oficial.

Son expedidos en hoja con logo de la Universidad, sello seco de Admisiones y Registro y la firma original de la Jefa de Admisiones y Registro.

Consulta los pasos para solicitar un certificado a través de [Epik](https://www.eafit.edu.co/Epik).

Escribe al correo [adm.certificados@eafit.edu.co](mailto:adm.certificados@eafit.edu.co), indicando el tipo de certificado o información que necesitas. El equipo de Registro Académico te orientará.

Revisa el estado de tu solicitud en [EPIK](https://www.eafit.edu.co/epik). El estado debe estar en “Por Generar”.

Recuerda que el pago puede tardar algunos minutos en verse reflejado.

Si ya figura como entregado y no lo recibiste en tu correo, comunícate con Registro Académico:

[contacto@eafit.edu.co](mailto:contacto@eafit.edu.co)

WhatsApp: +57 310 8992908

(604) 2619500

En EPIK puedes generar una versión preliminar del certificado antes de confirmarlo. Esto te ayudará a identificar cuál se ajusta a tu caso. También puedes revisar este [instructivo.](https://universidadeafit.widen.net/s/fg5qgdphbh/instructivo-certificados)

Debes hacerlo en EPIK, así:

Duplicado de diploma:

1. Ingresa a EPIK → Servicios y Certificados → Solicitud de Servicios.

2. Selecciona Duplicado de diploma.

3. Adjunta tu documento de identidad ampliado al 150%.

Duplicado de acta de grado:

1. Ingresa a EPIK → Servicios y Certificados → Solicitud de Certificados.

2. Selecciona Duplicado del acta.

Ten en cuenta: si no recuerdas tu usuario, acércate al Bloque 18 o escribe a [saul@eafit.edu.co](mailto:saul@eafit.edu.co).

El duplicado tiene un costo y la entrega es de 3 a 10 días hábiles.

Usuarios y Claves - EPIK

Cuando diligencias el formulario de registro en [EPIK](https://www.eafit.edu.co/epik), recibirás un correo con tu usuario y contraseña desde notificaciones@eafit.edu.co (asunto: “EAFIT - Tu usuario está listo - Cuenta creada”). Revisa tu bandeja de entrada, spam o “otros”. Si no lo encuentras, comunícate con la Mesa de ayuda: Tel. Medellín (604) 2619500 ext. 9433, Línea nacional 01 8000 515 900 ext. 9433, Correo: [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

Ingresa a la página principal de [EPIK](https://www.eafit.edu.co/epik) y haz clic en “Inscríbase” o en la opción “Ingreso”. Si el problema persiste, escribe a [inscripciones-ep@eafit.edu.co](mailto:inscripciones-ep@eafit.edu.co) explicando tu caso.

En la última página del formulario debes responder las preguntas y dar clic en “Finalizar”. Esto te llevará al inicio de sesión de EPIK. Si no funciona, intenta ingresar directamente desde [aquí](https://www.eafit.edu.co/epik)

Restablécelos a través del portal O365: Da [clic aquí](https://passwordreset.microsoftonline.com/).

Debes haber registrado un correo alternativo, celular u otra opción de seguridad. Si no configuraste métodos, contacta la Mesa de ayuda: Tel. Medellín (604) 2619500 ext. 9433, Línea nacional 01 8000 515 900 ext. 9433, Correo: [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

Para reestablecer tu clave da clic [Aquí](https://passwordreset.microsoftonline.com/).

Si no tienes métodos alternativos configurados, comunícate con la Mesa de ayuda, Correo: [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

El correo debe llegarte desde notificaciones@eafit.edu.co

Revisa en spam o bandeja de “otros”. Si no lo encuentras, comunícate con la Mesa de ayuda o escribe a [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

Primero valida tus datos en O365. Si accedes allí, completa tu registro en EPIK.

Si tampoco ingresas en O365, restablece tu clave en [Aquí](https://passwordreset.microsoftonline.com/).

Si el problema persiste, contacta la [Mesa de ayuda](https://mcu.azureedge.net/#/management/request/44228ced-a692-4034-b8cb-1f7287d6b3f7).

Debe tener mínimo 8 caracteres, al menos una mayúscula, una minúscula, un número y un carácter especial (+,*,-,)). No usar datos personales ni series como 123 o 321, ni palabras fáciles como EAFIT o años recientes.

Usa versiones actualizadas de navegadores: Chrome 90+, Firefox 85+, Edge 89+, Safari 14.0.3+. Si persiste, ingresa desde: [https://www.eafit.edu.co/epik](https://www.eafit.edu.co/epik)

Si ingresas mal tu contraseña varias veces consecutivas, tu cuenta se bloqueará.

Sí, actualmente si se ingresa cinco veces consecutivas una contraseña incorrecta el usuario se bloqueará. Cuando esto pase, puedes desbloquear tu cuenta por medio del siguiente link: [Desbloqueo cuenta.](https://passwordreset.microsoftonline.com/?ru=https://login.microsoftonline.com/common/reprocess?ctx%3drQIIAYWSz2vTcBjGm3ar20TdRMTT2MGDONJ-86NpMvCQNl36K2mbNMmSS0mbtE3SJlmakDV4FcTTEEHYcccNBT0NT-66085epngRDzIEwaPdX-Dlgefhw_Me3mdthcghSA7kwNMMkkN2HuMYXtCLfQqmdAKDcQoBsI6jBIwVMAJDAWIUABbcX1t_d359nPr2q_5C3bCkr6dvTqDNcRj6s518Po7jnDccWgMzN_Cm-YnuGpY7OoOgSwj6AUFH6bTpnqRnBFYkChhCkQRVXNwpkGROsyWMYyu4atOh1h1POAsAVanFTaW2yAahxlZAS-ngatcYc8nE4RXNaSmVOcdIocZwOL_gOVSd3_D8Dc_ItqZwmLro4m0n-ZK-16KjcIzeiBdYifk7vTr0gmnP92bhUeY0vT9AlbLANaM4aNKgs6dqJVRH9hqsZ0RiIBtMCWabrNz3cSDHHB2YsyLJOn7ZR2heLQ0NLPL9qcS4joKUuYavV1tFQ2xFzKynk43SWKzDjVE_ZkaTA9ER_P1mUo09mwpJW63DlTmA7c6-kMj-iKt6TZZTmpUk0BMCkSSvXUIngqyUEYQrFmQzNt32rsvOKaPrymOGFAeRP-Gru3BdoKmuM9-rkYorCQQGGK4egSC2-oWRUx1bjT4p9WwRa-NkAg_QgsZTEttG_Y4td03QiwGuEB1kPGybYqiTo7YS2VpZYKvJIOLKwqhhIhW8l4jdzsdMdvHeqedeZO56vulaxpYfeENrYl4uQT-XHq5k128_Sm2lnjwAmZ2VlbX11I37uwQdLy_28_3q6vnZ-yvuw-u3rzb_nKculvOzqdokvSQ_V_WpI85a-_OijkVog5XyRXl7UtdaOO1tb08HB7Vn2A5ymIUOs9mL7EaN6fGVrtileYYWGLQHrrPQy1upT6v_WeTnO)

Si tienes cursos activos, estás próximo a graduarte o acabas de finalizar, tu cuenta seguirá habilitada. Si no logras ingresar, contacta la Mesa de ayuda.

Comunícate vía telefónica desde la ciudad de Medellín al 2619500 o línea nacional: 01 8000 515 900. Y luego a la extensión 9433.

​Escribe un correo a [saul@eafit.edu.co](mailto:saul@eafit.edu.co)

No, el usuario no puede ser modificado ya que se genera automáticamente y no puede modificarse.

Mesa de ayuda: Tel. Medellín (604) 2619500 ext. 9433, Línea nacional 01 8000 515 900 ext. 9433, Correo: saul@eafit.edu.co

. Educación Continua: inscripciones-ep@eafit.edu.co

. Graduados: centro.egresados@eafit.edu.co

. Página oficial [Aquí](https://www.eafit.edu.co/epik).

Intersemestrales

Los intersemestrales se registran a través de EPIK. Para el semestre 2026-2, las fechas clave son:

- Publicación de cursos: 28 de abril de 2026

- Consulta de programación: 15 de mayo de 2026

- Inscripciones y pago: del 19 al 29 de mayo 2026

- Gestión de lista de espera: 24 al 28 de noviembre 2026

- Clases: el 16 de junio de 2026 al 3 de julio del 2026

- Cancelación: hasta el penúltimo día de clases

- Evaluación final: 4 de julio de 2026

- Reporte de notas: 8 de julio de 2026

- Balance académico: 9 de julio de 2026 (mañana).

¿Dónde encuentro la lista de cursos intersemestrales disponibles?Puedes consultar las asignaturas ofrecidas en el enlace de [cursos intersemestrales](https://www.eafit.edu.co/instructivo-intersemestrales).

La matrícula se realiza a través de EPIK, siguiendo el [instructivo](https://www.eafit.edu.co/instructivo-intersemestrales) oficial. Allí se explican los pasos para la inscripción, la selección de materias y la forma de pago.

El listado oficial de materias para los intersemestrales de 2026-2 estará disponible en el enlace correspondiente. Revisa periódicamente para ver la [oferta](https://www.eafit.edu.co/instructivo-intersemestrales) actualizada.

1. Ingresa a [EPIK](https://www.eafit.edu.co/epik)con tu usuario y contraseña.

2. Ve al módulo de matrícula e inscribe las materias disponibles.

3. Descarga el recibo de pago en el Centro de Pagos.

4. Realiza el pago en línea o en las entidades autorizadas.

5. Verifica en EPIK que tu matrícula esté activa.

Puedes cancelar una asignatura hasta el penúltimo día de clases del curso intersemestral. Ten en cuenta que aplican las políticas de devolución y retención definidas en el reglamento académico y financiero.

Atención al Visitante

[Aquí](https://www.eafit.edu.co/centrodevisitantes) puedes encontrar más información relacionada con Atención al Visitante. Por ejemplo: la reserva del Domo, recorridos a instituciones educativas, recorridos familiares interesados en ingresar a la universidad y conocer las instalaciones.

Para más información ingresa aquí o escribe en las líneas de atención.

También puedes escribirnos a [atencionalvisitante@eafit.edu.co](mailto:atencionalvisitante@eafit.edu.co)

Teléfono: (57) 6042619500 ​ext 9373

En Atención al visitante encuentras información personalizada, oportuna y pertinente relacionada con la experiencia de estar en el campus Medellín de la Universidad EAFIT.

Para programar una visita a la Universidad EAFIT puedes escribir al correo atencionalvisitante@eafit.edu.co. Realizamos recorridos de lunes a viernes entre las 9:00 a.m. a 11:00 a.m. o entre las 2:00 p.m. y 5:00 p.m.

Para conocer más sobre nosotros ingresa [aquí](https://www.eafit.edu.co/centro-visitantes)

Idiomas

En Idiomas EAFIT creemos que compartir el conocimiento a través de las experiencias inspira vidas y transforma realidades.

Contamos con una amplia oferta para adultos, niños y jóvenes.

Nuestros programas son:

* Inglés

* Inglés virtual para adultos

* Francés

* Alemán

* Italiano

* Portugués

* Chino mandarín

* Español para extranjeros

Para conocer más sobre nuestros programas, horarios e inversión, ingresa en el siguiente enlace.

[Ingresa aquí](https://www.eafit.edu.co/idiomas/Paginas/menu-idiomas-linea.aspx?_ga=2.228475550.2028860426.1679925997-560455001.1678908156)

En Idiomas EAFIT manejamos diferentes horarios que dependen de la intensidad y la sede, por esta razón te invitamos a ingresar al programa de tu interés y verificar los horarios disponibles.

Programas para adultos:

Los programas para adultos ofrecen cursos de 38 horas que podrán tomarse con una intensidad horaria de 10 semanales durante un mes, 6 horas semanales durante un mes y medio o 4 horas semanales durante dos meses y medio.

Programas para jóvenes:

Los programas para jóvenes ofrecen cursos de 42,5 horas que podrán tomarse con una intensidad horaria de 5 horas semanales durante dos meses y medio o de 2,5 horas semanales durante cinco meses y medio.

Programas para niños:

El programa de Inglés invita al aprendizaje a través de clases lúdicas y experiencias divertidas en cada uno los 14 cursos de 42,5 horas que podrán tomarse con una intensidad horaria de 2,5 horas semanales durante cinco meses y medio.

[Ingresa aquí](https://www.eafit.edu.co/idiomas/Paginas/menu-idiomas-linea.aspx?_ga=2.228475550.2028860426.1679925997-560455001.1678908156) para conocer más sobre nuestros horarios y sedes.

Tenemos cuatro sedes, tres de ellas ubicadas en Medellín y una en Llanogrande.

**Sede Poblado:**

Ubicada en el campus de la Universidad EAFIT, en Parque de los Guayabos.

Dirección: Calle 5 sur # 43c 80, bloque 1.

Horario de atención: de lunes a viernes, de 7:30 a.m. a 6:30 p.m. en jornada continua, y sábados: 8:00 a.m. a 2:00 p.m. en jornada continua.

Teléfono: 6042619500 opción 2

E- mail: [idiomas.sedepoblado@eafit.edu.co](mailto:idiomas.sedepoblado@eafit.edu.co)

**Sede Sur:**

Ubicada en el Centro Comercial Mayorca Mega Plaza, etapa 2, piso 6.

Dirección: Calle 51 Sur # 48 – 57

Horario de atención: de lunes a viernes de 10:00 a.m. a 7:00 p.m. en jornada continua, y sábados de 8:00 am a 2:00 p.m. en jornada continua.

Teléfono: 6042619500 opción 2

E- mail:[idiomas​.sedesur@eafit.edu.co](mailto:idiomas%E2%80%8B.sedesur@eafit.edu.co)

**Sede Belén:**

Ubicada en el Colegio San Carlos de la Salle sobre la Avenida 80.

Dirección: Diagonal 79 No 15-123.

Horarios de atención: jueves y viernes de 10:00 a.m. a 1:00 p.m. y de 2:00 p.m. a 7:00 p.m. y los sábados de 8:00 a.m. a 2:00 p.m.

Teléfono: 6042619500 opción 2

E- mail:[idiomas.sedebelen@eafit.edu.co](mailto:idiomas.sedebelen@eafit.edu.co)​​​

**Sede Norte:**

Ubicada en I. E. Suárez de la Presentación.

Dirección: Carrera 55 #35 - 41, Barrio Obrero

Horarios de atención presencial:

Miércoles, jueves y viernes: 10:00 a.m. a 1:00 p.m. / 2:00 p.m. a 6:30 p.m. / Sábados: 8:00 a.m. a 1:00 p.m.

Atención remota:

Martes: 8:00 a.m. a 12:00 m y de 1:00 p.m. a 5:00 p.m., lunes no hay atención al público.

Correo: [idiomas​.sedenorte@eafit.edu.co](mailto:idiomas%E2%80%8B.sedenorte@eafit.edu.co)

Teléfono: (57) 604 261 9500 ext. 8419 / 300 261 9500

**Sede Llanogrande:**

Ubicada en el kilómetro 3.5 vía Don Diego, Rionegro.

Horarios de atención: Lunes a viernes de 8:00 a.m. a 5:00 p.m. y sábados de 8:00 a.m. a 12:00 m.

Teléfono: 604 261 9500 opc. 3 ext. 8919

​E- mail: [idiomas.llanogrande@eafit.edu.co](mailto:idiomas.llanogrande@eafit.edu.co)

Para registrarte a un programa de idiomas sigue los siguientes pasos:

1. Ingresa a [Epik](https://www.eafit.edu.co/epik) con tu usuario y contraseña

2. Selecciona el módulo ""Iniciar nuevo programa Idiomas""

3. Completa el formulario de registro

Realiza los siguientes pasos para hacer tu inscripción en un curso de idiomas:

Da [clic aquí](https://www.eafit.edu.co/idiomas#:~:text=Ver%20programas%20corporativos-,Proceso,-de%20inscripci%C3%B3n)

Debes ingresar a nuestra plataforma [Epik](https://www.eafit.edu.co/epik) y diligenciar el formulario de Inscripción en la opción ""Crear una cuenta"".

Una vez tengas usuario y contraseña puedes ingresar al autoservicio del estudiante, donde podrás gestionar tu inscripción, ver tu información académica, financiera, realizar pagos, entre otros.

Si tienes conocimiento previo del idioma que quieres estudiar, debes realizar una prueba de clasificación sin costo que nos permitirá definir el curso que corresponde a tu nivel de suficiencia en el idioma. Para programarla ingresa a [Epik](https://www.eafit.edu.co/epik) en el módulo de "Servicios y Certificados".

[Ingresa aquí](https://view.genially.com/683493012034b378cff3aed5/guide-clasificaciones)

Este servicio lo ofrecemos a los estudiantes que identifican que no se encuentran en el curso idóneo para sus conocimientos en idiomas, ya sea por que deberían estar en un curso más avanzado, o por el contrario, consideran que el curso está muy avanzado para ellos.

En este caso, el estudiante o acudiente debe comunicarle al asistente académico de la sede la necesidad de realizar la evaluación correspondiente.

Si ya diligenciaste el formulario de Inscripción y no recuerdas tu contraseña, puedes seleccionar la opción ""Olvidó su contraseña"" ingresar el usuario asignado inicialmente y el sistema te enviará un correo electrónico con la nueva información.

Si no recuerdas tu usuario, puedes buscar en tu correo electrónico la notificación inicial o comunicarte a nuestra línea de atención 604 2619500 opción 1-2 o al correo [idiomas@eafit.edu.co](mailto:idiomas@eafit.edu.co)Con gusto te ayudamos con tu gestión.

Los cursos de preparación para exámenes internacionales están dirigidos a participantes de 17 años en adelante y constan de 38 horas cada uno.

A través de los cursos los participantes conocerán la estructura de los exámenes, las instrucciones específicas y el tipo de lenguaje que encontrarán. Además de familiarizarse con la prueba, los participantes practicarán con pruebas de simulacro y estrategias para responder las preguntas.

Contamos con una serie de descuentos para estudiar en Idiomas EAFIT, además brindamos la opción de financiación para facilitar el pago de los cursos.

Ingresa [aquí](https://www.eafit.edu.co/idiomas/por-que-estudiar-idiomas-eafit) para conocer los descuentos, convenios y opciones de financiación vigentes.

Ten presente que la aplicación del descuento al que apliques lo debes realizar con antelación al pago presentando la constancia correspondiente y que no son acumulables entre sí.

La Universidad EAFIT ofrece un programa de becas que comprende los servicios de apoyo para el aprendizaje, el desempeño académico y el crecimiento personal de los estudiantes, acompañando su proceso de integración a la vida universitaria, su sostenimiento y permanencia a nivel académico, social y económico.

Ingresa a [EPIK](https://www.eafit.edu.co/epik) → Mis Finanzas → Centro de pagos.

Recuerda realizar el pago de tu liquidación antes de la fecha límite de pago para conservar tu cupo.

Si requieres certificar tus conocimientos en un idioma, visita nuestro Testing Center, ingresando [aquí](https://www.eafit.edu.co/idiomas/testing-center).

El Testing Center de Idiomas EAFIT es un espacio adecuado para la administración de exámenes y certificaciones nacionales e internacionales en la ciudad. Actualmente contamos con cerca de 12 exámenes en idiomas como IELTS, TOEFL, DELE, CELPE entre otros, así como certificaciones tipo GRE.

Ingresa aquí para conocer sobre la oferta de exámenes internacionales o escribe a testingcenter@eafit.edu.co para recibir asesoría.

Este servicio le permite a los estudiantes de los programas para niños ponerse al día con actividades evaluativas que no presentaron en la fecha programada.

Este servicio tiene un costo de $31.500 y puede ser programado a través de Epik.

Solicita el servicio siguiendo estos pasos:

1. Ingresa a [Epik](https://www.eafit.edu.co/epik)

2. Selecciona la opción ""Ingreso/Registro""

3. Inicia sesión en Epik con el usuario y contraseña asignado

4. Selecciona el módulo de ""Servicios y Certificados""

5. Ve al ítem de ""Solicitud de Servicios""

6. Diligencia tu ciclo actual y programa activo y da clic en ""Buscar""

7. Selecciona tu servicio de interés (Supletorio oral u escrito)

8. El sistema te generara una liquidación de pago, el cual se debe realizar para habilitar la agenda de supletorios.

9. Una vez realizado el pago, podrás agendar el servicio, de acuerdo a la agenda disponible.

Si requieres apoyo para programar un examen supletorio puedes contactarnos al 2619500 opción 1 y luego opción 2, al correo [idiomas@eafit.edu.co](mailto:idiomas@eafit.edu.co) o al WhatsApp 310 8992908​.

Desde Epik puedes descargar constancias de estudio, asistencia, pago, entre otros, siguiendo estos pasos:

1. Ingresa a [Epik](https://www.eafit.edu.co/Epik)

2. Selecciona la opción ""Ingreso / Registro""

3. Inicia sesión en Epik con el usuario y contraseña asignado

4. Selecciona el módulo de ""Servicios y Certificados""

5. Ve al ítem de ""Solicitud certificado idiomas""

6. Selecciona el idioma cursado actual y descarga en formato PDF el tipo de certificado requerido

Si requieres apoyo para generar un certificado puedes contactarnos al 2619500 opción 1 y luego opción 2, al correo [idiomas@eafit.edu.co](mailto:idiomas@eafit.edu.co) o al WhatsApp 310 8992908​.

Consulta la Política de Bilingüismo ingresando [aquí](http://www.eafit.edu.co/bilinguismo?_ga=2.72533779.1609663474.1675797241-1001233797.1675797241).

Una vez tengas identificado el nivel del Marco Común Europeo requerido, consulta en la Política de los exámenes/cursos válidos para cumplir con el control. Si decides presentar un examen visita nuestro Testing center [ingresando aquí](https://www.eafit.edu.co/idiomas/testing-center).

Para solicitar un cambio de grupo te puedes acercar a una de nuestras sedes o puedes contactarnos al 2619500 opción 1 y luego opción 2, al correo [idiomas@eafit.edu.co](mailto:idiomas@eafit.edu.co) o al WhatsApp 310 8992908​.

The Spanish foreigner program offers a methodology focused on the four communication skills: speaking, writing, listening and reading. The program has 15 courses of 38 hours each that can be taken at our main location in Poblado. These courses have an intensity of 10 hours per week for 4 weeks, or 20 hours per week for 2 weeks. If you have prior knowledge of the language, you will need to take a free classification test. This will allow us to determine your level of proficiency in the language and in which course you will start the program. The group courses cost $1.663.000 Colombian pesos, and have between 3 and 8 students per group. Individual private classes have a cost of $5.029.000 Colombian pesos and require a guide text to support the learning process.

[Click here](http://www.eafit.edu.co/spanishprogram?_ga=2.34721569.1609663474.1675797241-1001233797.1675797241).

El Servicio de Club de conversación busca ofrecer espacios a los estudiantes de Idiomas y a la comunidad universitaria para el fortalecimiento de las habilidades de habla y escucha según el programa de estudio y nivel de suficiencia en que se encuentre.

Asistir a un club de conversación puede ser la mejor opción cuando se trata de querer practicar inglés o cualquier otro idioma; es un espacio en el que las personas se reúnen en función de dialogar y practicar lo que se ha aprendido, sea con hablantes locales o nativos.

[Ingresa aquí](https://www.eafit.edu.co/clubes-de-conversacion) para conocer los horarios y programación

Si requieres apoyo para inscribirte al club de conversación puedes contactarnos al 2619500 opción 1 y luego opción 2, al correo [idiomas@eafit.edu.co](mailto:idiomas@eafit.edu.co) o al WhatsApp 310 8992908​.

Lamentamos que estés considerando postergar la oportunidad de aprender un nuevo idioma.

Para cancelar tu inscripción en un curso debes tener presente nuestra política de ""Cancelaciones y Devoluciones"". Para conocerlas haz [clic aquí](https://uvirtual.eafit.edu.co/es-co/politicas-de-cancelacion-y-devolucion-eafit-virtual)

Para cancelar tu inscripción debes seguir estos pasos en Epik:

1. Ingresa a [Epik](https://www.eafit.edu.co/Epik)

2. Selecciona la opción ""Ingreso / Registro""

3. Inicia sesión en Epik con el usuario y contraseña asignado

4. Selecciona el módulo de ""Servicios y Certificados""

5. Ve al ítem de ""Solicitud de Servicios""

6. Diligencia tu ciclo actual y programa activo y da clic en ""Buscar""

7. Selecciona tu servicio de interés (cancelación de cursos)

8. Selecciona la clase a cancelar e ingresa el motivo por el cual estás haciendo la solicitud de cancelación de curso.

Ten en cuenta que la gestión del proceso tardará de 5 a 6 días hábiles y se aplicará la devolución de acuerdo a la política.

Llevamos nuestros programas de inglés, francés, portugués, italiano, alemán y español a empresas que buscan propiciar espacios de aprendizaje, práctica y perfeccionamiento de uno o varios idiomas para sus colaboradores, logrando potenciar sus habilidades para que puedan comunicarse de forma efectiva.

Escribe a [kvilla@eafit.edu.co](mailto:kvilla@eafit.edu.co) para recibir asesoría.

Educación continua

Una diplomatura es un programa de más de 100 horas, estructurado por módulos, que puede usar ese nombre siempre que en esa área no exista un posgrado en EAFIT. Quien culmina y cumple los requisitos recibe un diploma. Los programas incluyen cursos, talleres y otras ofertas con diferentes duraciones.

Es un programa de más de 100 horas, estructurado por módulos, con un formato muy similar al de una diplomatura, orientado a profesionales que buscan formación aplicada.

EAFIT certifica la asistencia del participante cuando cumple al menos el 80 % de las horas programadas.

En programas realizados en convenio, pueden existir requisitos adicionales como exámenes, trabajos o actividades finales.

Sí. EAFIT ofrece descuentos para ciertas poblaciones y convenios empresariales. Puedes revisar las opciones disponibles [aquí](https://www.eafit.edu.co/descuentos-y-convenios).

Puedes gestionar créditos educativos con entidades como Sufi, Bancolombia, Inversora Pichincha, entre otras. La Universidad puede emitir una constancia de inscripción para agilizar tu trámite con la entidad financiera.

Revisa las alternativas [aquí.](https://www.eafit.edu.co/alternativas-de-financiacion-y-pago)

Ingresa a la página de [Educación Continua](https://www.eafit.edu.co/otros-programas), busca el programa de tu interés y selecciona “Inscríbete”. Esto te llevará a Epik, donde deberás completar el formulario.

Si presentas inconvenientes creando usuario o contraseña, comunícate con el área de inscripciones: [inscripciones-ep@eafit.edu.co](mailto:inscripciones-ep@eafit.edu.co) ó (604) 261 9500, opción 3.

Busca nuevamente el curso en la página de [Educación Continua](https://www.eafit.edu.co/otros-programas) y da clic en “Inscríbete”, lo que te llevará al formulario correspondiente en Epik. También puedes ingresar directamente a [Epik](https://www.eafit.edu.co/Epik) y seleccionar Inscripción Educación Continua.

Ingresa a [Educación Continua](https://www.eafit.edu.co/otros-programas), busca tu curso y selecciona “Inscríbete”. Epik reconocerá tu usuario y mostrará el programa de interés para continuar el proceso.

Si ya estás en [Epik](https://www.eafit.edu.co/Epik), ve a Inscripción Educación Continua y usa los criterios de búsqueda para encontrar tu curso.

Si terminaste el formulario, puedes descargar tu recibo en: Solicitante → Mis Finanzas → Centro de pagos. Allí podrás pagar en línea o descargar el documento.

Si no has terminado el formulario, complétalo primero para que aparezca la opción de pago.

No. Una vez realizas el pago, quedas oficialmente matriculado. Mantente atento al correo que registraste, donde recibirás notificaciones importantes sobre tu curso.

Antes de llenar el formulario de inscripción, debes solicitar la aplicación del descuento con: [inscripciones-ep@eafit.edu.co](mailto:inscripciones-ep@eafit.edu.co) ó (604) 261 9500, opción 3.

Ingresa a [EPIK](https://www.eafit.edu.co/epik) con tu perfil de estudiante, selecciona Mi Información Académica, y luego elige Lista de asistencia o Consulta de calificaciones, según lo que deseas revisar.

Ingresa a [Epik](https://www.eafit.edu.co/Epik) → Estudiante → Servicios y certificados → Solicitud de certificados. Allí podrás solicitar:

a) Certificado de matriculado

b) Certificado de horas del curso o diplomado

Para certificados físicos de “asistió y aprobó”, comunícate con el área para validar el trámite.

Sí. [Educación Continua](https://www.eafit.edu.co/otros-programas) ofrece asesoría académica para diseñar propuestas formativas a la medida de las organizaciones.

Puedes consultar más preguntas y detalles de los programas [aquí.](https://www.eafit.edu.co/otros-programas)

Atención al público:

- Lunes a viernes: 8:00 a.m. a 6:00 p.m. (jornada continua)

- Sábados: 8:00 a.m. a 12:00 m.

EAFIT Interactiva

Podrás acceder a la plataforma una vez hayas realizado el pago de tu matrícula.

Si ya pagaste y aún no tienes acceso 8 días antes del inicio de tus materias, por favor contacta a Soporte Interactiva a través de [soporteinteractiva@eafit.edu.co](mailto:soporteinteractiva@eafit.edu.co) o por el canal de Teams.

Puedes acceder haciendo clic en el siguiente enlace: [EAFIT Interactiva](https://www.eafit.edu.co/interactiva?_ga=2.102353665.1609663474.1675797241-1001233797.1675797241)

También puedes buscar EAFIT Interactiva directamente en tu navegador.

Para iniciar sesión, ingresa con tu usuario institucional, es decir, con los datos de tu correo @eafit.edu.co.

Tu usuario es el correo institucional @eafit.edu.co que te fue asignado al ingresar a la Universidad.

Tus cursos estarán visibles:

8 días antes de la fecha de inicio programada.

Hasta 30 días después de la fecha final del curso.

Si ya realizaste el pago de la matrícula y no ves alguno de tus cursos:

Contacta a Soporte Interactiva: [soporteinteractiva@eafit.edu.co](mailto:soporteinteractiva@eafit.edu.co) o en Teams.

Incluye en tu solicitud: código del curso y número de clase (datos esenciales para la verificación).

Revisa primero si te encuentras dentro de los tiempos establecidos (8 días antes del inicio del curso). Si ya deberías verlos, comunícate con Soporte Interactiva por correo [soporteinteractiva@eafit.edu.co](mailto:soporteinteractiva@eafit.edu.co) o Teams e incluye:

- Código del curso

- Número de clase

- Tu identificación y programa

Esto agilizará la gestión de tu caso.

Tienes varias opciones de atención:

- Correo: soporteinteractiva@eafit.edu.co

- Teams: canal de Soporte Interactiva

- Atención presencial: Bloque 15, piso 2 – Oficina de Gestión Digital del Aprendizaje

El horario es:

Lunes a viernes:

- 8:00 a.m. – 12:00 m.

- 2:00 p.m. – 6:00 p.m.

El tiempo de respuesta a las solicitudes es de 0 a 48 horas hábiles.

Para temas de acceso a tu cuenta institucional (contraseña, recuperación, problemas de ingreso, etc.), comunícate con la Mesa de Servicios SAUL a través de cualquiera de los siguientes canales:

- Teléfono: 2619500 ext. 9433

- Correo: saul@eafit.edu.co

- Teams: TEAMS SAUL

- BOT SAUL

Oficinas presenciales:

- Medellín: Bloque 18 – Oficina 416

- Bogotá: Recepción

La plataforma funciona correctamente en los navegadores más utilizados, como Google Chrome, Microsoft Edge y Mozilla Firefox.

Se recomienda mantenerlos actualizados para evitar errores de visualización.

Puedes recuperarla usando los métodos de verificación que hayas configurado con anterioridad, en caso de tener métodos de verificación configurados, comunícate con la Mesa de Servicios SAUL o utilizando sus canales digitales (Teams, BOT SAUL o correo saul@eafit.edu.co).

Sí. La plataforma es compatible con dispositivos móviles, aunque para actividades académicas se recomienda usar un computador para una mejor experiencia de navegación.

Internacionalización

Es una oportunidad para que los estudiantes de pregrado cursen materias en universidades extranjeras con convenio vigente, conservando la matrícula en EAFIT. Los créditos aprobados podrán ser homologados según criterios de tu programa.

EAFIT tiene convenios con instituciones en América, Europa, Asia y Oceanía. Puedes consultar el [listado actualizado](https://app.powerbi.com/view?r=eyJrIjoiYjVmNTk3M2YtMjdmZi00MDI2LWFiZWItZDJhMWZkOTEyNjdlIiwidCI6Ijk5ZjdiNTVlLTljYmUtNDY3Yi04MTQzLTkxOTc4MjkxOGFmYiIsImMiOjR9) de universidades en la página oficial de Movilidad Internacional.

Sí. Cada convenio establece un número de cupos semestrales o anuales. Estos cupos pueden variar según la demanda y disponibilidad de cada institución.

Debes:

- Tener promedio acumulado igual o superior al exigido por tu escuela.

- Haber aprobado mínimo el 20 % del programa (o el porcentaje definido por tu programa).

- No estar en prueba académica ni tener sanciones disciplinarias.

- Cumplir los requisitos propios de la universidad de destino (idioma, GPA, documentación).

Sí, puedes hacerlo siempre que cumplas los requisitos y cuentes con el aval de ambos programas.

Sí, siempre que no estés en prueba académica y mantengas el promedio mínimo requerido.

Depende del país y la universidad:

- Español: no exige certificación en la mayoría de instituciones.

- Inglés, francés, portugués, alemán, entre otros: se requiere certificado oficial (TOEFL, IELTS, DELE, DALF, etc.) según la institución.

Las convocatorias para movilidad se abren dos veces al año y son anunciadas en la página de Relaciones Internacionales y los canales institucionales.

Generalmente:

- Formulario de Movilidad Internacional.

- Certificado de notas o récord académico.

- Carta de motivación.

- Hoja de vida.

- Certificado de idioma (si es requerido).

- Acuerdo académico preliminar.

Debes considerar:

- Convenios activos con tu programa.

- Oferta de cursos compatibles con tu plan de estudios.

- Requisitos de idioma.

- Costos estimados.

- Fechas de convocatoria.

Es el documento donde seleccionas los cursos que deseas estudiar en la universidad destino y propones su equivalencia con materias de tu programa en EAFIT.

Debe ser validado por:

- Coordinación de pregrado

- Secretaría de la Escuela

- Oficina de Relaciones Internacionales

Debes contactar a tu coordinador para ajustar el acuerdo académico antes de iniciar las clases.

Si requieres certificar tus conocimientos en un idioma, visita nuestro Testing Center, ingresando [aquí](https://www.eafit.edu.co/idiomas/testing-center).

El Testing Center de Idiomas EAFIT es un espacio adecuado para la administración de exámenes y certificaciones nacionales e internacionales en la ciudad. Actualmente contamos con cerca de 12 exámenes en idiomas como IELTS, TOEFL, DELE, CELPE entre otros, así como certificaciones tipo GRE.

Ingresa aquí para conocer sobre la oferta de exámenes internacionales o escribe a testingcenter@eafit.edu.co para recibir asesoría.

Pagas únicamente tu matrícula en EAFIT, no en la universidad de destino (salvo prácticas especiales o programas sin convenio).

- Alojamiento

- Alimentación

- Seguro médico internacional

- Visado

- Transporte

- Materiales de estudio

Sí. Algunas universidades y entidades externas ofrecen becas parciales o totales. La disponibilidad varía por convocatoria.

Depende del país. Una vez seas aceptado, la universidad de destino te indicará el tipo de visa y los documentos necesarios. Te invitamos a consultar la información en la página oficial de cada consulado

Debes adquirir un seguro internacional que cubra:

- Urgencias

- Hospitalización

- Repatriación

- Accidentes

- Enfermedades

Cada universidad puede exigir coberturas específicas.

Sí, pero debes contar con autorización de tu coordinador de programa y de Relaciones Internacionales.

La materia no será homologada en EAFIT. Solo se homologan asignaturas aprobadas.

Debes enviar tu certificado de notas de la universidad destino a la Oficina de Relaciones Internacionales.

Una vez validado, se realizará la homologación en tu historial académico.

El proceso de homologación se realizará en cuanto recibamos el documento oficial.

Un Convenio Marco es una estructura jurídica para regular actividades generales entre dos instituciones. En el caso de estos convenios, siempre sugerimos que vayan acompañados de un convenio específico o un plan de acción tangible a corto plazo para que tengamos convenios que tengan impacto en nuestra comunidad.

Es un acuerdo particular que desarrolla acciones concretas del convenio marco, como intercambios, dobles titulaciones o proyectos de investigación.

Profesores, directivos o unidades académicas pueden proponer convenios, siguiendo los procedimientos de la Dirección de Relaciones Internacionales.

- Información institucional de la universidad aliada

- Justificación académica

- Borrador de convenio

- Validación jurídica

El tiempo varía según la complejidad del acuerdo y las revisiones jurídicas. Puede tomar entre 4 y 12 semanas.

Deben ser coordinadas con Relaciones Internacionales, quienes programarán agenda, recorridos y reuniones estratégicas.

Acreditación internacional

- Calidad académica

- Intereses de investigación

- Compatibilidad curricular

- Proyección internacional de EAFIT

Es un programa que permite a los estudiantes cursar materias en universidades colombianas con convenio vigente, manteniendo su matrícula en EAFIT.

Con instituciones acreditadas en alta calidad como:

- Universidad de los Andes

- Universidad Nacional

- Universidad del Rosario

- Universidad del Norte

- Universidad Javeriana

Y otras instituciones del país.

- Estar activo en tu programa académico

- Tener mínimo 20 % de créditos aprobados

- Contar con promedio acumulado mínimo según tu escuela

- Presentar acuerdo académico preliminar

Generalmente entre 2 y 4 materias, según tu disponibilidad y acuerdo académico.

Una vez finalices, la universidad destino envía tus notas y se procesan según los criterios de tu programa.

Sí, pero debes notificar a Relaciones Internacionales antes del inicio de clases.

No será homologada. Podrás repetirla en EAFIT bajo las reglas del programa.

Taquillas Virtuales

Las Taquillas Virtuales son una herramienta que permite a aspirantes, estudiantes, padres de familia, acudientes, profesores, proveedores y público en general recibir atención virtual de varias áreas de la Universidad. A través de esta plataforma podrás:

- Solicitar un turno ingresando tus datos personales.

- Elegir el servicio de tu interés.

- Ser atendido por un asesor mediante videollamada, llamada o chat.

- Adjuntar y descargar documentos necesarios para tu trámite.

Puedes acceder a través del siguiente enlace: [Taquillas Virtuales EAFIT](https://taquillavirtualeafit.sistemasentry.com.co/visionweb)

Si presentas dificultades técnicas para acceder a la herramienta o generar un turno, comunícate con:

Correo: [contacto@eafit.edu.co](mailto:contacto@eafit.edu.co)

- Línea de atención: (604) 261 9500, opción 1

Debes ingresar los datos de la persona que realizará el trámite.

Los datos requeridos son:

- Nombre completo

- Número de identificación

- Teléfono fijo o celular

- Correo electrónico

- Servicio de consulta

- Motivo de la solicitud

Sí, es posible gestionar varios trámites durante la misma atención, siempre y cuando correspondan al área en la cual solicitaste el turno.

El tiempo de espera y de atención puede variar según el tipo de solicitud y el área que te atienda.

Sin embargo, el equipo siempre buscará ofrecerte la mayor agilidad posible.

Sí. Durante la atención podrás adjuntar los archivos necesarios para realizar tu trámite.

La plataforma permite adjuntar los siguientes formatos:

- PDF

- JPG

- PNG

- Word

- Excel

- PowerPoint

Las siguientes áreas cuentan con atención por este medio:

- Admisiones y Registro

- Apoyo Financiero

- Tesorería

- Idiomas EAFIT

- Centro de Gestión Documental

Algunos de los servicios más comunes que podrás gestionar son:

- Atención general

- Solicitud y expedición de certificados

- Información y orientación sobre financiación (EAFIT a tu alcance)

- Asesoría y solicitudes relacionadas con ICETEX

- Asesoría sobre cursos de Idiomas EAFIT

- Apoyo para agendar citas de clasificación

- Asesoría con el autoservicio Epik

- Orientación para realizar pagos

- Acompañamiento en temas de clases en línea

- Solicitudes relacionadas con exámenes de certificación internacional

No. Puedes conectarte desde tu navegador utilizando videollamada, chat o llamada.

Solo asegúrate de tener buena conexión a internet.

Sí, la plataforma es compatible con dispositivos móviles. Sin embargo, para trámites que requieren adjuntar documentos o revisar información detallada, se recomienda usar un computador.

Información General

Sí, la Universidad cuenta con parqueaderos para visitantes, estudiantes y demás usuarios. Sin embargo, debido a la alta demanda, la disponibilidad varía según el día y la hora. Se recomienda llegar con anticipación para asegurar el ingreso.

Para más información sobre tarifas y formas de pago, visita: [Instrucciones de pago de parqueaderos](https://www.eafit.edu.co/instrucciones-pago-parqueaderos)

El ingreso vehicular se realiza por las porterías habilitadas. Ten en cuenta:

- La disponibilidad de cupo está sujeta a demanda.

- En EAFIT aplica la medida de pico y placa durante todo el día.

Puedes consultar las porterías y [lineamientos de ingreso](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-245218310) en el reglamento institucional.

Sí. La Universidad sigue la programación establecida por la Alcaldía de Medellín.

Consulta la rotación actual en: [Pico y placa EAFIT](https://www.eafit.edu.co/pico-y-placa)

EAFIT es un campus vivo donde puedes aprender, investigar, crear, recorrer espacios culturales y disfrutar de servicios diseñados para el bienestar.

Conoce más sobre su historia, espacios, zonas verdes y servicios ingresando [aquí](https://www.eafit.edu.co/campus-eafit)

La Universidad ofrece una amplia variedad de restaurantes y cafeterías, tanto propios como concesionados, con oferta gastronómica para todos los gustos.

Consulta el listado actualizado ingresando [aquí](https://www.eafit.edu.co/negocios-institucionales).

Si estás interesado en ofrecer productos o servicios dentro del campus, puedes enviar tu solicitud a través del siguiente formulario: [Formulario para concesiones](https://www.eafit.edu.co/contacto-para-concesiones)

La Universidad requiere que tu información esté siempre actualizada. Puedes hacerlo a través de la plataforma Epik siguiendo estos pasos:

- Ingresa a [Epik](https://www.eafit.edu.co/Epik) con tu usuario y contraseña institucionales.

- Selecciona el módulo Datos personales.

- Actualiza los documentos y la información requerida.

- Acceso a Epik: [https://www.eafit.edu.co/Epik](https://www.eafit.edu.co/Epik)

Si necesitas apoyo adicional, puedes escribir a [datospersonales@eafit.edu.co](mailto:datospersonales@eafit.edu.co)

o comunicarte con la línea de atención:

- Medellín: (604) 261 9500

- Línea nacional: 01 8000 515900

- Marca la opción 1 para ser atendido por un asesor.

Sí. EAFIT es un campus abierto, aunque algunos espacios requieren registro o autorización previa. Los visitantes deben acatar las normas de ingreso y las recomendaciones de seguridad.

Sí. La Universidad está ubicada cerca de estaciones de metro, rutas integradas y paraderos de buses que facilitan el acceso. Puedes planear tu ruta a través de los sistemas de transporte público del Valle de Aburrá.

Sí. EAFIT tiene amplias zonas verdes, senderos ecológicos, teatros, auditorios y espacios culturales disponibles para estudiantes, empleados y visitantes.
