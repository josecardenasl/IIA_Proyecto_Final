Title: Conexión con los asuntos públicos

URL Source: https://www.eafit.edu.co/conexion-asuntos-publicos

Published Time: Thu, 07 May 2026 20:48:28 GMT

Markdown Content:
# Conexión con los asuntos públicos - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/conexion-asuntos-publicos#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/conexion-asuntos-publicos#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/conexion-asuntos-publicos# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/conexion-asuntos-publicos# "English")

*   [Spanish](https://www.eafit.edu.co/organizaciones/conexion-asuntos-publicos)
*   [Inglés](https://www.eafit.edu.co/en/organizaciones/conexion-asuntos-publicos)

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner sistemas publicos ](https://universidadeafit.widen.net/content/afa06ba3-d284-44b0-a483-01219c5d73a9/web/Sistemas-publicos-banner-principal-3.jpeg?crop=yes&k=c&w=1920&h=788&itok=tzUfhoy5)

# Sistemas Públicos y Sociales

EAFIT es un epicentro de creación y transferencia de conocimiento sobre asuntos públicos.

 Aquí emergen conversaciones, ideas y herramientas que inciden y fomentan la construcción colectiva. Somos un actor central en las agendas de país, participando en el diseño e implementación de políticas, la operación de sistemas de gobernanza, el fortalecimiento de las instituciones democráticas, la generación de valor social, el impacto de los emprendimientos en los sistemas públicos y la formación en nuevas tecnologías, respondiendo así a los retos presentes y futuros de la humanidad.

*   [Inicio](https://www.eafit.edu.co/)
*   [Organizaciones](https://www.eafit.edu.co/organizaciones)
*    Conexión Con Los Asuntos Públicos 

[![Image 22](https://universidadeafit.widen.net/content/14a09ac4-ff12-4844-acb7-cc48d582b22a/web/sistemas-publicos-banner-principal.jpeg?crop=yes&k=c&w=1920&h=788&itok=VfEDEFnm)](https://www.eafit.edu.co/conexion-asuntos-publicos)

![Image 23](https://www.eafit.edu.co/conexion-asuntos-publicos)

[![Image 24](https://universidadeafit.widen.net/content/44151be8-b1f4-452b-868b-1cecf78ca2c3/web/sistemas-publicos-banner-principal-2.jpg?crop=yes&k=c&w=1920&h=788&itok=PF4Qykbf)](https://www.eafit.edu.co/conexion-asuntos-publicos)

![Image 25](https://www.eafit.edu.co/conexion-asuntos-publicos)

[![Image 26](https://universidadeafit.widen.net/content/afa06ba3-d284-44b0-a483-01219c5d73a9/web/Sistemas-publicos-banner-principal-3.jpeg?crop=yes&k=c&w=1920&h=788&itok=tzUfhoy5)](https://www.eafit.edu.co/conexion-asuntos-publicos)

![Image 27](https://www.eafit.edu.co/conexion-asuntos-publicos)

![Image 28: Imagen ¿Cómo nos conectamos e impactamos los Sistemas Públicos y Sociales?](https://universidadeafit.widen.net/content/72fe144b-8706-4fc3-9ca8-990b0f44297e/web/sistemas-publicos-5.jpg?h=480&itok=rpKaXc6X)

## ¿Cómo nos conectamos e impactamos los Sistemas Públicos y Sociales?

EAFIT incide en los asuntos públicos a través de sus centros de estudio, grupos de investigación de las escuelas y programas de formación, que se encargan de abordar los desafíos de la sociedad mediante la creación de soluciones e implementación de herramientas en diversos entornos. 

 A través de un intercambio de ideas y posiciones, establecemos una conexión con los sistemas públicos que se traduce en impacto y soluciones efectivas. Nuestras conversaciones académicas trascienden y afectan la realidad, generando conocimiento en torno a las problemáticas sociales. 

 Al conectar capacidades y esfuerzos internos, fomentamos el diálogo entre el sector público, la academia, las empresas y los emprendimientos, materializando proyectos que ofrecen respuestas reales e innovadoras a los problemas presentes y futuros de la sociedad.

## Conectémonos

Conéctate con los mejores expertos del país, la solución a la problemática puede estar en EAFIT.

## Identificar el problema

Analizamos a fondo la situación que nos planteas para identificar las necesidades, desafíos y oportunidades específicas, buscando darle solución y generar una verdadera incidencia.

## Propuesta de solución

Basándonos en el diagnóstico realizado previamente, elaboramos una propuesta detallada que aborda las necesidades y desafíos identificados.

## Ejecución y aprendizaje

En esta fase, implementamos las estrategias y las acciones definidas. Materializamos y ejecutamos la propuesta de intervención mediante el diseño y la ejecución de un proyecto donde se articularán todas las capacidades de la organización a través de la investigación, consultoría, asesoría, transferencia de tecnología, formación de talento especializado y apropiación social del conocimiento.

## +40

posgrados enfocadas en formar tomadores de decisiones y los principales actores dentro de los asuntos públicos.

## +200

proyectos de Ciencia, Tecnología e Innovación llevados a cabo en los últimos 10 años.

## +50

líderes de opinión y creadores de conocimiento en las principales plataformas y medios de comunicación del país

## +100

columnas escritas por profesores e investigadores eafitenses en medios de comunicación locales, nacionales e internacionales.

#### **Proyectos de impacto**

## Plan Estratégico Río Atrato, hoja de ruta para el futuro

Este proyecto, financiado por el Departamento Administrativo de Planeación de la Gobernación de Antioquia y liderado por Urbam EAFIT, desarrolló una Hoja de Ruta integral para los municipios de Murindó, Vigía del Fuerte, Turbo y Mutatá, ubicados en la cuenca del río Atrato, Antioquia.

![Image 29: Imagen Plan Estratégico Río Atrato, hoja de ruta para el futuro ](https://universidadeafit.widen.net/content/f939245b-4b6b-4c80-a03f-65bb08cb6d43/web/sistemas-publicos-6.jpg)

## Sistema de Alerta Temprana de Medellín y el Valle de Aburrá

SIATA es un proyecto de Ciencia, Tecnología e Innovación del Área Metropolitana del Valle de Aburrá que aplica ciencia avanzada para la gestión del riesgo de desastres, la variabilidad climática y la calidad del aire. Con un enfoque en la ciencia aplicada y la apropiación social del conocimiento, SIATA conecta la investigación con las necesidades del territorio, generando información esencial para la toma de decisiones en emergencias, como inundaciones y deslizamientos.

![Image 30: Imagen Sistema de Alerta Temprana de Medellín y el Valle de Aburrá](https://universidadeafit.widen.net/content/5c3947de-3df5-40ef-9bab-a5c66cef240d/web/sistemas-publicos-8.JPG)

## Centros de Interés en Ciencia, Tecnología e Innovación

Los Centros de Interés en Ciencia, Tecnología e Innovación (CTI) son una iniciativa del Ministerio de Educación Nacional con el objetivo de transformar la educación en Colombia, fortaleciendo la formación integral de niños, niñas, adolescentes y jóvenes en instituciones educativas públicas de Colombia. Con un enfoque STEM+, el proyecto promueve el desarrollo de vocaciones y habilidades en ciencia, tecnología e innovación, incorporando de manera transversal la educación CRESE, el enfoque de género y la Alfabetización Mediática e Informacional.

![Image 31: Imagen Centros de Interés en Ciencia, Tecnología e Innovación](https://universidadeafit.widen.net/content/830f9c14-d337-4281-aabc-450eeabb67d8/web/sistemas-publicos-7.jpg)

## OCENSA, un proyecto para el fortalecimiento local de capacidades institucionales y comunitarias

El convenio con OCENSA tiene como objetivo promover el desarrollo de capacidades y habilidades a nivel institucional y comunitario, a partir del desarrollo de acciones de formación, impulso del liderazgo y fomento de espacios comunitarios seguros dirigidos a funcionarios públicos, y comunidad educativa en el área de influencia de Ocensa.

![Image 32: Imagen OCENSA, un proyecto para el fortalecimiento local de capacidades institucionales y comunitarias](https://universidadeafit.widen.net/content/cce547c4-bc67-488a-9573-474f82f60d24/web/sistemas-publicos-10.png)

## Investigación en Crimen Organizado

Esta iniciativa investiga la organización del crimen organizado para entender las dinámicas internas de estas estructuras y su impacto en las comunidades. Además, se enfoca en la recolección y análisis de datos de fuentes administrativas y encuestas, lo que permitirá generar evidencia empírica robusta para la toma de decisiones. También se investiga las trayectorias de las carreras criminales a largo plazo, con el fin de prevenir el reclutamiento de nuevas generaciones en estos grupos.

![Image 33: Imagen Investigación en Crimen Organizado](https://universidadeafit.widen.net/content/72fe144b-8706-4fc3-9ca8-990b0f44297e/web/sistemas-publicos-5.jpg)

Centros de estudios

![Image 34: Imagen Valor Público, centro de estudios e incidencia](https://universidadeafit.widen.net/content/f6c71399-1c40-417e-a708-20bf40b0e52e/web/card-valor-publico.jpg?crop=yes&k=c&w=397&h=253&itok=Na_IYo5i)

Valor Público, centro de estudios e incidencia

Valor Público diseña, implementa y evalúa programas y políticas de seguridad y justicia, gobierno y democracia, desarrollo económico e inclusión social y diversidad, elaborando propuestas que aportan a la toma de decisiones basadas en evidencia que aporten a soluciones de corto, mediano y largo plazo.

[Conoce Valor Público](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico)

![Image 35: Imagen Urbam, centro de estudios urbanos y ambientales ](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-07/comunicaci%C3%B3nurbam.jpg?itok=wDkNMthu)

Urbam, centro de estudios urbanos y ambientales

Urbam promueve entornos urbanos y rurales sostenibles e incluyentes que buscan el bienestar humano. Aborda territorios emergentes y en transición que se caracterizan por procesos acelerados de cambio, con problemáticas urbanas y ambientales de alta complejidad en el contexto de la región tropical. 

 Se enfoca en diseño de soluciones basadas en la naturaleza, en proyectos urbanos integrales e inclusivos, en prospectivas territoriales y en proyectos de desarrollo urbano orientados al transporte.

[Conoce Urbam](https://www.eafit.edu.co/centros-estudio-incidencia/urbam/que-es-urbam)

![Image 36: Imagen In-sight, centro de estudios e incidencia en liderazgo de impacto](https://universidadeafit.widen.net/content/c28a7c55-4aa0-4755-a3ce-91850264bbe5/web/banner2-insight.jpg?crop=yes&k=c&w=397&h=253&itok=-sEWgX7O)

In-sight, centro de estudios e incidencia en liderazgo de impacto

Estudiamos a fondo el liderazgo, generamos conversaciones, acompañamos a las organizaciones y contribuimos a la formación de líderes que generen impacto.

[Conoce In-sight](https://www.eafit.edu.co/in-sight)

##### **Nuestros programas**

Nuestras capacidades

![Image 37: Imagen Innovación EAFIT](https://universidadeafit.widen.net/content/7a1024de-a242-435a-8ada-1db3dec2e95c/web/sistemas-publicos-9.jpg?crop=yes&k=c&w=397&h=253&itok=B_BvytDE)

Innovación EAFIT

Somos la plataforma que conecta el conocimiento de EAFIT con las necesidades de las organizaciones, las industrias y la sociedad, tejiendo vínculos entre nuestras escuelas, grupos de investigación y centros de estudio e incidencia con el mundo. A través de la ciencia, la tecnología y la innovación, aplicamos y transferimos el conocimiento generado en la Universidad para ofrecer soluciones que contribuyen al desarrollo y la transformación social y económica del país, generando resultados efectivos y medibles.

[¿Qué hacemos y cómo impactamos desde Innovación EAFIT?](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)

![Image 38: Imagen NODO](https://universidadeafit.widen.net/content/161e6b58-35ab-46ae-8f28-5e134697ea31/web/imagen-web-becas-fraternidad.png?crop=yes&k=c&w=397&h=253&itok=W7IvXXjj)

NODO

Nodo es el centro de formación en tecnologías de la Universidad EAFIT, creado para ofrecer experiencias de aprendizaje prácticas y orientadas a los desafíos reales. Acompañamos a personas en todas las etapas de su desarrollo —desde el skilling hasta el re-skilling y upskilling— a través de formatos como bootcamps, aceleradores y boosters, que impulsan la adopción de tecnologías y habilidades digitales para hackear el futuro.

[¿Qué hacemos y cómo impactamos desde NODO?](https://es.nodoeafit.com/)

![Image 39: Imagen On.going](https://universidadeafit.widen.net/content/e6bb22ca-0665-423f-b90d-016da779d94f/web/y-si-nos-dejamos-ayudar-por-la-ia.jpg?crop=yes&k=c&w=397&h=253&itok=BEVfxWv-)

On.going

Somos el Centro de Emprendimiento de Impacto de la Universidad EAFIT. Un universo donde creamos el nuevo tejido empresarial y dinamizamos la comunidad emprendedora de Colombia y América Latina.

[¿Qué hacemos y cómo impactamos desde On.going?](https://www.eafit.edu.co/ongoing)

#### **Experiencias destacadas**

## EAFIT Global Leaders y EAFIT Global Thinkers

EAFIT Global Leaders/Thinkers es una iniciativa enfocada en atraer líderes, pensadores, referentes e investigadores - o todas las anteriores – más potentes a nivel nacional e internacional enfocados en impactar y construir futuro.

[Quiero saber más sobre EAFIT Global Leaders/Thinkers](https://www.eafit.edu.co/eafit-global-leaders-y-eafit-global-thinkers)

![Image 40: Imagen EAFIT Global Leaders y EAFIT Global Thinkers](https://universidadeafit.widen.net/content/2b967b15-ab60-4db5-a795-6650ce006409/web/sistemas-publicos-23.jpg?crop=yes&k=c&w=463&h=450&itok=iMyd1gpk)

## EAFIT presente en los medios

Más de 40 de nuestros investigadores son líderes de opinión y creadores de conocimiento en las principales plataformas y medios de comunicación del país.

![Image 41: Imagen EAFIT presente en los medios](https://universidadeafit.widen.net/content/68e84c9d-7694-438c-9ab7-805369de0415/web/sistemas-publicos-15.jpg?crop=yes&k=c&w=463&h=450&itok=KAV53QOj)

## Algunos de nuestros graduados destacados

1. María José Gaviria, Directora de FENALCO Antioquia.

 2. Andrés Julián Rendón, Gobernador de Antioquia. 

 3. Laura Gallego, Vicepresidenta Ejecutiva de Proantioquia.

![Image 42: Imagen Algunos de nuestros graduados destacados](https://universidadeafit.widen.net/content/38a34695-ce6c-4147-9aad-32186513d1a1/web/rectora.jpg?crop=yes&k=c&w=463&h=450&itok=Sr7QMf3X)

![Image 43: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 44: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 45: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 46: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 47: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 48: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 49: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 50: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
