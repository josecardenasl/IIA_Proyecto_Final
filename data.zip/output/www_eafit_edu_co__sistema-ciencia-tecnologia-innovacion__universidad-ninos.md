Title: Universidad de los Niños EAFIT

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos

Markdown Content:
# Universidad de los Niños EAFIT - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos#main-content)

[![Image 3: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 4: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos#)

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos# "Spanish")[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos# "English")

 Información para ti

[![Image 8: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 9: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 10: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 11: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 12: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 13: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 14: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 15: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 16: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 17: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 18: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 19: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 20: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 21: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 22: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 23: Imagen de fotografía universidad de los niños](https://universidadeafit.widen.net/content/e5daeb19-2fef-4372-9790-cc85fa807403/web/ZoomRobin18_2024.jpg?crop=yes&k=c&w=1920&h=788&itok=s0K89LZH)

# Universidad de los Niños EAFIT

Estimulamos el descubrimiento y el conocimiento por medio de la pregunta, el juego, la experimentación y la conversación.

[¿Qué es la Universidad de los Niños?](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/que-es-universidad-ninos)

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*    Universidad de Los Niños EAFIT 

Desplegar menú
*   [Niños y niñas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Ancla menú")
*   [Adolescentes](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Ancla menú")
*   [Mediadores](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Ancla menú")
*   [Colegios](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Ancla menú")
*   [Organizaciones](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Ancla menú")

## Nos mueve el asombro

Desde 2005 abrimos las puertas del asombro para que infancias, juventudes y familias vivan experiencias de aprendizaje únicas.

[Descubre cómo lo hacemos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/que-es-universidad-ninos)

## 105.000

Infancias y juventudes que despertaron su curiosidad

## 130

Proyectos para aprender jugando con la ciencia

## 2.600

Instituciones que transformaron su forma de aprender

### **¿Qué nos hace diferentes?**

Tenemos una metodología única y patentada basada en 4 pilares: la pregunta, el juego, la conversación y la experimentación.

Contamos con laboratorios especializados: nos tomamos el Campus EAFIT y otros territorios como aulas abiertas y experienciales.

Nuestras experiencias cuentan con el acompañamiento y guía de investigadores de EAFIT y de otras instituciones de la ciudad.

#### **Experiencia y oferta para niñas y niños**

![Image 24: Imagen Encuentros con la pregunta](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-05/uninos.jpg?itok=qbZLlofT)

Encuentros con la pregunta

Este año, niños y niñas de 7 a 11 años descubrirán el mundo a través del juego, la experimentación y la conversación para resolver las siguientes preguntas

[Conoce encuentros con la pregunta](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/encuentros-con-la-pregunta)

![Image 25: Imagen Zoom Ciencia](https://www.eafit.edu.co/sites/default/files/styles/card_generica_397px_253px/public/2025-05/uninos2.jpg?itok=XK_4bTj6)

Zoom Ciencia

Del 6 al 10 de octubre, tus hijos de 3 a 11 años pueden vivir una semana llena de ciencia, creatividad, movimiento y diversión en el campus de la Universidad EAFIT.

[Conoce Zoom Ciencia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/zoom-ciencia)

### **Experiencias y oferta para adolescentes**

![Image 26: Imagen Retos de Ciencia](https://universidadeafit.widen.net/content/85e0f050-ca86-4a26-9fb6-1f6decfed831/web/retos.jpg?crop=yes&k=c&w=397&h=253&itok=BRrs6UoB)

Retos de Ciencia

Los participantes resuelven retos basados en problemáticas actuales a partir de las diferentes áreas de la ciencia.

[Conoce retos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/retos-de-ciencia)

![Image 27: Imagen Expediciones Científicas](https://universidadeafit.widen.net/content/56cd1a52-5161-4ab1-be73-d393ba1ad9e7/web/Expediciones.jpg?crop=yes&k=c&w=397&h=253&itok=L-0gDmod)

Expediciones Científicas

Los participantes exploran diversas metodologías de investigación para aplicar en el desarrollo de un proyecto basado en una problemática actual.

[Conoce expediciones](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/expediciones-cient%C3%ADficas)

### **Experiencias y oferta para colegios**

Fortalecemos la oferta educativa de las instituciones a través de consultorías en diseño curricular y realización de programas extracurriculares como talleres y semilleros con metodologías activas e integradas al PEI para que las niñas, los niños y adolescentes desarrollen vocaciones científicas.

![Image 28: Imagen Diseño de talleres](https://universidadeafit.widen.net/content/60487119-2891-4e68-a6e4-984f5a37103f/web/dise%C3%B1o-de-talleres.jpg?crop=yes&k=c&w=397&h=253&itok=P2JAsEB9)

Diseño de talleres

Desarrollamos experiencias de aprendizaje dentro y fuera de la Universidad, de acuerdo con las necesidades de las instituciones.

[Conoce Diseño de talleres](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/diseno-de-talleres)

![Image 29: Imagen Jornada escolar complementaria](https://universidadeafit.widen.net/content/75214d97-55a5-4057-b879-4ec7e0ffb306/web/jornada-escolar-complementaria.jpg?crop=yes&k=c&w=397&h=253&itok=ur5F_9tW)

Jornada escolar complementaria

Diseñamos e implementamos jornadas escolares complementarias para extender el conocimiento en diferentes áreas de la ciencia.

[Conoce Jornada escolar complementaria](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/jornada-escolar-complementaria)

![Image 30: Imagen Diseño curricular](https://universidadeafit.widen.net/content/27587070-5c12-4af7-8f01-23c521cba552/web/dise%C3%B1o-curricular.jpg?crop=yes&k=c&w=397&h=253&itok=UxgPI6IB)

Diseño curricular

Realizamos consultoría y acompañamiento en el fortalecimiento de currículos escolares a través de metodologías innovadoras.

[Conoce Diseño curricular](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/diseno-curricular)

![Image 31: Imagen Extracurriculares](https://universidadeafit.widen.net/content/a1fb0fad-f5bf-4636-9e46-d3a7722ce054/web/extracurriculares.jpg?crop=yes&k=c&w=397&h=253&itok=CYTYooOn)

Extracurriculares

Diseño e implementación de experiencias de aprendizaje con metodologías activas para jornada extracurriculares de las instituciones.

[Conoce Extracurriculares](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/extracurriculares)

## Red de las preguntas

Nos obsesionan las preguntas y, aunque sabemos que no todas tienen respuesta, nos gusta indagar al máximo. Conoce las preguntas realizadas por participantes y la respuesta de los investigadores.

[Conoce la red de las preguntas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/red-preguntas)

![Image 32: Imagen Red de las preguntas](https://universidadeafit.widen.net/content/1d4db802-254e-44fc-83ca-15320915d326/web/Red-de-las-preguntas.jpg)

## Participación e incidencia

Acompañamos y guiamos a niños, niñas y adolescentes en procesos de participación y liderazgo.

[Ver participación e incidencia](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/prototipo-participacion-e-incidencia)

![Image 33: Imagen Participación e incidencia](https://universidadeafit.widen.net/content/de29ccce-c68a-4d88-a913-209a2ed088e9/web/participacion-e-incidencia.jpg)

### **Experiencias y oferta para mediadores**

En la Universidad de los Niños acompañamos a los mediadores para que impulsen su creatividad e innovación en el aula. Juntos exploramos herramientas y metodologías activas que fortalecen sus habilidades de liderazgo y les ayudan a ser facilitadores de conocimiento.

![Image 34: Imagen Nuestra metodología](https://universidadeafit.widen.net/content/3d0bce39-fb8e-4f73-a790-59e541fb63ba/web/nuestra-metodologia.jpg?crop=yes&k=c&w=397&h=253&itok=wSDJiOGH)

Nuestra metodología

En la Universidad de los Niños contamos con una Metodología única basada en el juego, la pregunta, la conversación y la experimentación

[Conoce Nuestra metodología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/que-es-universidad-ninos/metodologia-universidad-de-los-ninos-eafit)

![Image 35: Imagen Talleristas UNI](https://universidadeafit.widen.net/content/e552edac-054c-4f74-be70-e124ebbac772/web/talleristas.jpg?crop=yes&k=c&w=397&h=253&itok=RUWkp6rk)

Talleristas UNI

Formamos a estudiantes de pregrado de EAFIT para que guíen y motiven la realización de las actividades de niños, niñas o jóvenes desde nuestra metodología.

[Conoce talleristas UNI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/talleristas)

# Experiencias y oferta para organizaciones

[Sistemas públicos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos#4257225834-3500944752)

Sistemas públicos

![Image 36: Imagen Ciencia Entre Montañas](https://universidadeafit.widen.net/content/96203c80-2633-4e02-9d14-1fce74da7c38/web/universidad-de-los-niin%CC%83os-talleres-en-ciencia-entre-montan%CC%83as.jpg?crop=yes&k=c&w=397&h=253&itok=o3TwUGtF)

Ciencia Entre Montañas

Buscamos fortalecer habilidades científicas, tecnológicas y de innovación en niños, niñas y maestros de los centros educativos rurales de la provincia Cartama, Antioquia.

[Conoce Ciencia Entre Montañas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/ciencia-entre-montanas)

![Image 37: Imagen Inspiración Talento TI](https://universidadeafit.widen.net/content/51090198-e16b-4e00-bc2a-4956b46ce864/web/inspiracion-talento-ti.jpg?crop=yes&k=c&w=397&h=253&itok=TaYLGMr8)

Inspiración Talento TI

Desarrollo e implementación de los pilotos para fomentar la sensibilización y el acercamiento a las tecnologías transversales de la Cuarta Revolución Industrial en jóvenes de Medellín.

[Conoce Inspiración Talento TI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/talento-en-ti)

[Empresas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos#4257225834-1874401559)

Empresas

![Image 38: Imagen Inspiración Comfama](https://universidadeafit.widen.net/content/ea8629ee-436a-44e7-89eb-6bfb5a0f9b41/web/inspiracion-comfama.jpg?crop=yes&k=c&w=397&h=253&itok=dp_XJvi5)

Inspiración Comfama

Fortalecemos habilidades para la vida en sociedad y permitir a niños y niñas explorar posibilidades para su futuro desde la ciencia y la investigación.

[Conoce Inspiración Comfama](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/jornada-escolar-complementaria/inspiracion-comfama)

![Image 39: Imagen  Cafam](https://universidadeafit.widen.net/content/1f3841fa-8dbb-41fa-bfdf-a72914a0b428/web/cafam.jpg?crop=yes&k=c&w=397&h=253&itok=lE1reo1V)

Cafam

fortalecemos la educación de calidad para innovar a través de actividades en ciencia y tecnología para niños, niñas y jóvenes en los municipios de Cajicá y de Tabio, Cundinamarca.

[Conoce Cafam](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/jornada-escolar-complementaria/robotica-cafam)

![Image 40: Imagen Aprendamos con Eloísa Latorre](https://universidadeafit.widen.net/content/060efd86-470e-486f-abd2-8d7d0e685f01/web/IMG_20250826_112233562.jpg?crop=yes&k=c&w=397&h=253&itok=q8Ap1OZ7)

Aprendamos con Eloísa Latorre

Programa pedagógico de ISA Intercolombia y la Universidad de los Niños EAFIT que fortalece el aprendizaje rural mediante experiencias que inspiran asombro, curiosidad y trabajo colaborativo.

[Leer más](node::59886)

![Image 41: Imagen Saberes de Monte](https://universidadeafit.widen.net/content/88ae12dd-7e90-433a-9998-cf9bd86857cb/web/Saberes-de-Monte-eafit.jpg?crop=yes&k=c&w=397&h=253&itok=t9BGcDTN)

Saberes de Monte

Es una iniciativa que nació en el corazón de las comunidades afrodescendientes e indígenas de Nuquí para abrir un diálogo de saberes que permitió crear herramientas pedagógicas y de planeación territorial.

[Conoce Saberes de Monte](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/saberes-de-monte)

![Image 42: Imagen Phereclos](https://universidadeafit.widen.net/content/ffc5baab-1733-4511-9c3c-2a9d5e3f7148/web/phereclos.jpg?crop=yes&k=c&w=397&h=253&itok=XDurJRmf)

Phereclos

Proyecto realizado con 15 universidades europeas para contribuir a la articulación del sistema escolar con los sectores empresarial, académico y de educación no formal.

[Conoce Phereclos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/phereclos)

![Image 43: Imagen  Material didáctico educativo para la conservación de la rana arlequín](https://universidadeafit.widen.net/content/851a89ce-5d91-4a28-b687-dac91cddda1b/web/rana-arlequin.jpg?crop=yes&k=c&w=397&h=253&itok=y0YCEnnL)

Material didáctico educativo para la conservación de la rana arlequín

​Desarrollamos material didáctico educativo enfocado en la visibilización y conservación de las ranas arlequín en Colombia y acompañamos la formación de 25 mediadores para liderar actividades educativas con comunidades rurales del país.

[Conoce Material didáctico educativo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/material-didactico-conservacion-rana-arlequin)

## Nuestros investigadores

Contamos con el acompañamiento y guía de investigadores de la Universidad EAFIT y de otras instituciones que aportan los contenidos académicos que inspiran las actividades que se realizan en la Universidad de los Niños.

[Conoce nuestros investigadores](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/investigadores)

![Image 44: Imagen Nuestros investigadores](https://universidadeafit.widen.net/content/8c24a5a8-a31d-4e87-b724-7feaf8e70036/web/investigadores.jpg?crop=yes&k=c&w=463&h=450&itok=90gQuvKr)

## Nuestros aliados

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 45: Imagen de logo Alcaldía de Medellín](https://universidadeafit.widen.net/content/bd1cf5dd-22a7-42ec-9c3e-5dd73b5080da/web/alcaldiademedellin_logo.jfif)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 46: Imagen de logo The Amazon Conservation Team](https://universidadeafit.widen.net/content/7b4f7f02-f735-40f4-9f35-85b3e5080248/web/Amazon-conversation-Team.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 47: Imagen de logo Cafam](https://universidadeafit.widen.net/content/66aa7560-3131-4c79-999e-1a482ef84845/web/Cafam.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 48: Imagen de logo Comfama](https://universidadeafit.widen.net/content/f13a0f6e-647e-44f2-8ee4-2bfade3050ca/web/Comfama.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 49: Imagen de logo Acua Activos culturales](https://universidadeafit.widen.net/content/1e93de2f-9770-4b41-a7b1-0b3944a8248d/web/Fundaci%C3%B3n-Acua.jfif)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 50: Imagen de logo Unidos](https://universidadeafit.widen.net/content/56ed6423-6889-417a-a9fc-f149aa175f09/web/Gobernaci%C3%B3n-de-Antioquia.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 51: Imagen de logo Isa Intercolombia](https://universidadeafit.widen.net/content/bc46785f-885f-4757-b370-fe57c3eb1fce/web/isa-intercolombia-1.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 52: Imagen de logo LowCarbonCity](https://universidadeafit.widen.net/content/db0ceae7-7863-4e86-9c0d-0db41ea828a6/web/Lowcarboncity.jpg)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 53: Imagen de logo Ciencias](https://universidadeafit.widen.net/content/0c8098ab-e97c-4567-908b-e664a366dcc9/web/logo-ministerio-ciencias.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 54: Imgen de logo Educación](https://universidadeafit.widen.net/content/0cdd43a7-1f2e-44f5-b8fb-5bbdb792662e/web/logo-ministerio-educacion.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 55: Imagen de logo Parque explora](https://universidadeafit.widen.net/content/fb0759c1-b448-40eb-951a-4a848a0d4430/web/logo-parque-explora.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 56: Imagen de logo Ruta Medellín](https://universidadeafit.widen.net/content/d275fd61-eaef-4834-a979-dcca9fba2820/web/RutaN.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

## Redes a las que pertenecemos

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 57: Imagen de logo Eucunet](https://universidadeafit.widen.net/content/9f164f11-3160-4a2c-89f7-bce10a8eba18/web/logo-eucunet.png.webp)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 58: Imagen de logo Niñez YA](https://universidadeafit.widen.net/content/6d6597a4-aaa6-4ebf-a88a-77bba4f0aae4/web/logo-ninez-ya.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[![Image 59: Imagen de logo Red pop ](https://universidadeafit.widen.net/content/63f76148-c091-442f-a006-e03117fb70ec/web/logo-red-pop.png)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

[](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

## Conócenos en nuestras redes sociales

### Instagram

[Ver perfil](https://www.instagram.com/uninoseafit/)

### LinkedIn

[Ver perfil](https://www.linkedin.com/company/universidad-de-los-ni%C3%B1os-eafit)

### WhatsApp

[Contáctanos](https://api.whatsapp.com/send?phone=573003646814)

Contacto 

¿Quieres saber más?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono de contacto*? 

Correo electrónico*? 

Ciudad de residencia*? 

Contenido de interés 

Cuéntanos, ¿Qué deseas saber?*? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 60](https://universidadeafit.widen.net/content/e297cf6c-b30d-4b41-8328-05f3c4c66906/web/Banner-4-uni-de-los-ni%C3%B1os.jpg?crop=yes&k=c&w=470&h=272&itok=gxpIewN2)

![Image 61: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 62: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 63: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 64: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 65: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 66: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 67: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 68: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 69](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
