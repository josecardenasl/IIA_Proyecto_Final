Title: Escuela Finanzas Economía y Gobierno

URL Source: https://www.eafit.edu.co/escuela-finanzas-economia-gobierno

Markdown Content:
# Escuela Finanzas Economía y Gobierno - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno#main-content)

[![Image 43: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 44: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno#)

[![Image 45: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno# "Spanish")[![Image 46: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno# "English")

*   [Spanish](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno)
*   [Inglés](https://www.eafit.edu.co/en/escuela-finanzas-economia-gobierno)

 Información para ti

[![Image 47: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 48: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 49: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 50: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 51: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 52: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 53: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 54: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 55: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 56: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 57: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 58: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 59: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 60: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 61: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 62: Imagen de banner estudiantes de EAFIT en el campus universitario](https://universidadeafit.widen.net/content/638b8290-0fb7-4cc2-894b-0202f3d960f5/web/Economia2.jpg?crop=yes&k=c&w=1920&h=788&itok=1ZRCR19R)

# Escuela de Finanzas, Economía y Gobierno

Esta es la escuela para aprender a hacer más próspera a la sociedad. Nuestros programas orbitan en torno a preguntas sobre cómo entre todos nos ponemos reglas, tanto económicas, de mercado, como sociales, para asignar equitativamente los recursos en ella.

*   [Inicio](https://www.eafit.edu.co/)
*    Escuela Finanzas Economía y Gobierno 

Filtros

*   [Posgrados(22)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=tipo_de_programa_finanzas%3Aposgrados)
*   [Pregrados(3)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=tipo_de_programa_finanzas%3Apregrados)

Facet Tipo de programa finanzas 

*   [Macroeconomía y Sistemas Financieros(16)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=area_de_conocimiento_pre_pos_finanzas%3A1631)
*   [Políticas y Desarrollo(4)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=area_de_conocimiento_pre_pos_finanzas%3A1636)
*   [Mercados y Estrategia Financiera(3)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=area_de_conocimiento_pre_pos_finanzas%3A1626)
*   [Derecho y economía(1)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=area_de_conocimiento_pre_pos_finanzas%3A1561)
*   [​Territorios y Ciudades(1)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=area_de_conocimiento_pre_pos_finanzas%3A1651)

Facet Área de conocimiento pre pos finanzas 

*   [Presencial(23)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=modalidad_pre_pos_finanzas%3A101)
*   [Virtual(2)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=modalidad_pre_pos_finanzas%3A106)

Facet Modalidad pre pos finanzas 

*   [Medellín(16)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=sedes_pre_pos_finanzas%3A121)
*   [Bogotá(4)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=sedes_pre_pos_finanzas%3A111)
*   [Cali(2)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=sedes_pre_pos_finanzas%3A191)
*   [Pereira(2)](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?f%5B0%5D=sedes_pre_pos_finanzas%3A126)

Facet Sedes pre pos finanzas 

#### Especialización en Economía para las Organizaciones

![Image 63: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 Semestres

![Image 64: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 65: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Intensivo

Más información

Intensivo, alineado con la Maestría en Economía Aplicada

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 67: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 68: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 69: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$28.722.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-finanzas-economia-gobierno/especializacion-en-economia-para-las-organizaciones "Ver posgrado")

#### Maestría en Finanzas Analíticas y Cuantitativas - Medellín

![Image 70: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 Semestres

![Image 71: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 72: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Martes y jueves

Más información

Martes y Jueves de 6:00p.m. a 10:00p.m. 

 En los semestres 2 y 3 los cursos de Seminarios serán los miércoles de 6:00p.m. a 10:00 p.m. a lo largo del semestre. 

 Las Electivas pertenecen a otros programas y tienen sus propios horarios según disponibilidad. 

![Image 73: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 74: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 75: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 76: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$54.400.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-finanzas-economia-gobierno/maestria-en-finanzas-analiticas-y-cuantitativas-medellin "Ver posgrado")

#### Especialización en Finanzas Analíticas - Medellín

![Image 77: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 Semestres

![Image 78: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 79: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Martes, miércoles y jueves

Más información

Martes y Jueves de 6:00p.m. a 10:00p.m. 

 En el semestre 2, el curso de Seminario Profesional podrá ser ofrecido los Miércoles de 6:00p.m. a 10:00p.m. a lo largo del semestre. 

 Las electivas pertenecen a otros programas y tienen sus propios horarios según disponibilidad. 

![Image 80: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 81: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 82: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

![Image 83: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$34.000.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-finanzas-economia-gobierno/especializacion-en-finanzas-analiticas-medellin "Ver posgrado")

#### Maestría en Finanzas Sostenibles y Cambio Climático - Bogotá

![Image 84: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 Semestres

![Image 85: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Bogotá

![Image 86: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y Sábado

Más información

Combinado: Clases presenciales cada 2 semanas, viernes de 18:30 a 22:00 y sábados de 7:30 a.m. a 12:30 p.m. y 13:30 p.m. a 17:00 p.m. 

 Clases sincrónicas por plataforma MS Teams en el horario de viernes de 18:30 a 22:00 p.m. y sábados de 7:30 a.m. a 12:00 p.m

![Image 87: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 88: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Híbrida

![Image 89: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 

![Image 90: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$51.508.800

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-finanzas-economia-gobierno/maestria-en-finanzas-sostenibles-y-cambio-climatico-bogota "Ver posgrado")

#### Especialización en Finanzas Sostenibles - Bogotá

![Image 91: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 Semestres

![Image 92: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Bogotá

![Image 93: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y Sábado

Más información

Combinado: Clases presenciales cada 2 semanas en el horario de viernes de 18:30 a 22:00 y sábados de 7:30 a.m. a 12:30 p.m. y 13:30 p.m. a 17:00 p.m. 

 Clases sincrónicas por plataforma MS Teams en el horario de viernes de 18:30 a 22:00 p.m. y sábados de 7:30 a.m. a 12:00 p.m

![Image 94: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 95: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Híbrida

![Image 96: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 

![Image 97: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$32.193.000

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-finanzas-economia-gobierno/especializacion-en-finanzas-sostenibles-bogota "Ver posgrado")

#### Especialización en Finanzas Sostenibles - Medellín

![Image 98: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

2 Semestres

![Image 99: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 100: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y Sábado

Más información

Viernes 06:00 p.m - 09:00 p.m y Sábado 08:00 a.m - 01:00 p.m 

![Image 101: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 102: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Híbrida

![Image 103: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 118132

![Image 104: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$28.743.750

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-finanzas-economia-gobierno/especializacion-en-finanzas-sostenibles-medellin "Ver posgrado")

*   [Página actual 1](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?label=&page=2 "Ir a la página 3")
*   [Página 4](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?label=&page=3 "Ir a la página 4")
*   [Página 5](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?label=&page=4 "Ir a la página 5")
*   [Siguiente página›](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno?label=&page=4 "Ir a la última página")

## Lo que hace única a esta Escuela

[Calidad y excelencia](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno#4257225834-1884321909)

Calidad y excelencia

**Somos top en el mundo**

Como institución estamos acreditados por AACSB (Association to Advance Collegiate Schools of Business), lo que nos convierte en la primera universidad en Antioquia en obtener este reconocimiento, la sexta en Colombia y nos hace parte del menos del 6% de las escuelas de negocios del mundo que cuentan con ella.

Nuestra MAF (Maestría en Administración Financiera), para la que puedes homologar créditos con nuestros pregrados, lleva cinco años siendo socia del CFA (Chartered Financial Analyst), y es la única con este reconocimiento en Colombia. Además, hacemos parte de la GARP, la asociación de expertos en las áreas de riesgos, siendo los únicos en el país con esta acreditación en pregrado y posgrado.

Y somos la mejor Escuela de Finanzas, Economía y Gobierno de Antioquia, según el Ranking QS.

[Campus transformador](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno#4257225834-1840715852)

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar:**

Nuestra Escuela cuenta con el respaldo de un gran ecosistema de laboratorios: DataPol, un laboratorio de datos método y análisis político; Laboratorio y consultorio financiero, que ofrece consultorías en finanzas empresariales, personales y educación financiera.

**Tenemos una agenda académica, cultural y social activa**

El conocimiento es visible y permea todos los rincones de la Universidad.

Contamos con una agenda de conocimiento y cultura viva: Lo mejor de la academia, la ciencia y las artes converge en EAFIT.

**Tenemos proyección y presencia nacional**

Estamos en Bogotá con nuestros programas de maestría en: Administración Financiera (MAF), Administración (MBA), Gerencia de Proyectos y Especialización en Finanzas. Y llegamos a Pereira con las maestrías en: Administración (MBA), Administración de Riesgos. También con las maestrías y especializaciones en: Mercadeo, Gerencia de Proyectos, Administración Financiera; y con la Especialización en Finanzas. En ambas sedes con flexibilidad de clases presenciales cada quince días y cada mes, según el programa.

**Somos actor clave de una ciudad universitaria.**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe cientos de estudiantes de más de 15 países y 446 de otros territorios de Colombia.

[Aprendizaje vivo y activo](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno#4257225834-493453012)

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

Contamos con más de 20 líneas de énfasis para que elijas cómo complementar tu desarrollo profesional.

Podrás enfocar tu carrera en temas como: mercadeo, economía aplicada, economía cuantitativa, finanzas, gerencia de proyectos, relaciones internacionales, ciencia de los datos, construcción de paz, comunicación política o gobierno y políticas públicas.

[Innovación y liderazgo](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno#4257225834-1967780437)

Innovación y liderazgo

**Somos innovación en educación**

Contamos con herramientas de alto nivel utilizadas por las bancas de inversión, comisionistas y grandes aseguradoras del mundo: Bloomberg, un software especializado al que nuestros estudiantes tienen acceso y por medio del que se pueden certificar. Y Refinitiv, software de la bolsa de Londres.

Además, nuestros estudiantes se exponen continuamente a conversaciones y procesos con casos reales y con los graduados. También tienen una formación multidisciplinar gracias a las cinco escuelas de EAFIT y a las tres áreas (mercados y estrategia financiera, macroeconomía y sistemas financieros, y políticas y desarrollo) que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

En EAFIT tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica.Como Escuela tenemos siete semilleros y tres grupos de investigación, todos en la máxima categoría A1 en Colciencias.

[Conexiones e incidencia](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno#4257225834-2405433558)

Conexiones e incidencia

**Somos un universo de trabajo por lo público, las organizaciones y de emprendimiento activo:**

Contamos con centro de estudios e incidencia, Valor Público y con un espacio de innovación y desarrollo social: EAFIT Social.

En EAFIT tenemos una línea especial de Gerencia y empresa que presta consultoría y, también, a ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.

Nuestros profesores están en relación permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan nuestra sociedad.

**Somos una puerta al mundo**

Contamos con 260 convenios internacionales, 190 instituciones aliadas en 30 países, más de 56 estudiantes internacionales activos en nuestra Escuela, aproximadamente 200 estudiantes que se van de intercambio al mundo cada año. Tenemos también programas de intercambio profesoral e investigativo.

Tenemos una relación estrecha con la Brandeis University, Carlos III de Madrid y la Universidad Pompeu Fabra, la Universidad Católica de Lovaina y la Universidad La Salle Ramón Llull, para salidas profesionales, proyectos investigativos conjuntos y prácticas remuneradas.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado en EAFIT y 103 de posgrados han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores start-ups de Colombia.

Áreas de conocimiento

## Mercados y Estrategia Financiera

El área de Mercados y Estrategia financiera está conformada por un equipo de trabajo multidisciplinario especializado en economía y finanzas de las organizaciones con los más altos estándares de calidad. Su sólida fundamentación teórica y experiencia en estas temáticas, ​unido al riguroso manejo de técnicas en ciencias de datos, econométricas, y computacionales, apalanca​ su capacidad de solución de problemas de las organizaciones privadas, públicas y sociales. Director​: Diego Téllez Falla.

## Macroeconomía y Sistemas Financieros

El á​rea de Macroeconomía y Sistemas Financieros lidera la generación y aplicación de nuevos conocimientos para resolver problemas relacionados con el progreso económico de los países y el desarrollo y funcionamiento de sus mercados e instituciones financieras. El área cuenta con profesores e investigadores quienes se ocupan de estar a la vanguardia en sus respectivos campos de especialización relacionados con el crecimiento económico, la inflación, el empleo, los ​ciclos económicos, entre otros. Director: Diego A. Agudelo Rueda.

## Políticas​​ y Desarrollo

El área de Políticas y Desarrollo recoge las capacidades académicas en torno al diseño, seguimiento y evaluación de políticas públicas en el marco de las restricciones y posibilidad​e​s políticas y administrativas, y su relación con el desarrollo económico y social de los territorios. Se conecta con la comprensión del funcionamiento de los sistemas políticos y su interacción entre los actores sociales y políticos, con los análisis aplicados en economía con el fin de generar valor público en la resolución de problemas sociales tanto para el sector público como en el sector privado. Director:​ Juan Carlos Muñoz​ ​

![Image 105: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Centro de Valor Público

[Ver Centro de Valor Público](https://www.eafit.edu.co/centros-estudio-incidencia/valor-publico)

## EAFIT Social

[Ver EAFIT Social](https://www.eafit.edu.co/centros-estudio-incidencia/eafit-social)

## Laboratorio Financiero

[Ver Laboratorio Financiero](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/laboratorio-financiero)

## Consultorio Financiero

[Ver Consultorio Financiero](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/consultorio-financiero)

## Laboratorio de datos, métodos y análisis político - DataPOL

[Ver DataPOL](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno/datapol)

## Profesores

[Ver profesores](https://www.eafit.edu.co/profesores?f%5B0%5D=escuelas_profesores%3A331)

### **Noticias**

![Image 106: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=397&h=250&itok=MKSJ4A11)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 107: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=397&h=250&itok=Ai1Iyv7S)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

![Image 108: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=397&h=250&itok=jKshJMEj)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-laboratorio-vivo-para-aprender-haciendo "Ver noticia")

Marzo 12, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias)

![Image 109: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 110: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 111: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 112: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 113: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 114: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 115: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 116: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
