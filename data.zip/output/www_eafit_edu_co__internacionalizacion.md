Title: Internacionalización

URL Source: https://www.eafit.edu.co/internacionalizacion

Markdown Content:
# Internacionalización - EAFIT

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 2: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 3: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 4: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 5: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 6: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 8: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 9: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 10: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 11: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 12: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 13: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 14: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 15: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Pasar al contenido principal](https://www.eafit.edu.co/internacionalizacion#main-content)

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Idioma

[![Image 17: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/internacionalizacion#)

[![Image 18: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/internacionalizacion# "Spanish")[![Image 19: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/internacionalizacion# "English")

*   [Spanish](https://www.eafit.edu.co/internacionalizacion)
*   [Inglés](https://www.eafit.edu.co/en/internacionalizacion)

 Información para ti

Buscar 

Búsqueda

Menú

![Image 20: Imagen de banner jóvenes estudiantes caminando por el campus de la Universidad EAFIT](https://universidadeafit.widen.net/content/cfa60993-ead8-4c4e-82b8-6ed8656d705f/web/Banner-Home.jpg?crop=yes&k=c&w=1920&h=788&itok=VnbZmfNs)

# Internacionalización

Como parte de la Vicerrectoría de Aprendizaje, Internacionalización EAFIT desarrolla relaciones internacionales y construye capacidades transversales en la Universidad, generando experiencias para la comunidad eafitense. Dichas experiencias tienen como objetivo el desarrollo de una visión global y competencias interculturales que faciliten su inserción en contextos nacionales e internacionales, y su participación propositiva como profesionales y ciudadanos del mundo.

*   [Inicio](https://www.eafit.edu.co/)
*    Internacionalización 

# Experiencias

*   [Para quienes ya son eafitenses](https://www.eafit.edu.co/internacionalizacion#4257225834-1771184078)
*   [Para quienes quieren venir a EAFIT](https://www.eafit.edu.co/internacionalizacion#4257225834-3375020470)

[Para quienes ya son eafitenses](https://www.eafit.edu.co/internacionalizacion#4257225834-1771184078)

Para quienes ya son eafitenses

## Intercambio académico internacional

[Ver intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)

## Intercambio académico nacional

[Ver intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)

## Convenios

[Conoce nuestros convenios](https://www.eafit.edu.co/internacionalizacion/convenios)

## Oportunidades para profesores

[Ver oportunidades](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria/convocatorias-de-profesores)

## Prácticas en el exterior

[Ver prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)

## Pasantías de investigación

[Ver pasantías](https://www.eafit.edu.co/pasantias-investigativas)

## Misiones – programas a la medida

[Ver misiones](https://www.eafit.edu.co/internacionalizacion/misiones-academicas-salientes)

## Aprendizaje global

[Conoce aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

## Cooperación Internacional en CteI

[Ver cooperación internacional](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

![Image 21: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

[Para quienes quieren venir a EAFIT](https://www.eafit.edu.co/internacionalizacion#4257225834-3375020470)

Para quienes quieren venir a EAFIT

## Intercambio académico internacional / Exchange

[Ver intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/international-exchange-students)

## Intercambio académico nacional

[Ver intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional-eafit)

## Convenios / Partnerships

[Conoce nuestros convenios](https://www.eafit.edu.co/internacionalizacion/convenios)

## Spanish program

[Conoce Spanish program](https://www.eafit.edu.co/idiomas/spanish-program)

## Oportunidades para profesores / Opportunities for faculty

[Ver oportunidades](https://www.eafit.edu.co/internacionalizacion#)

## Pasantías de investigación / Research internships

[Ver pasantías](https://www.eafit.edu.co/pasantias-investigativas)

## Misiones – programas a la medida / Tailor-made programs

[Ver misiones](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)

## Aprendizaje global / Global Learning

[Conoce Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

## Cooperación Internacional en CteI / International Cooperation STI

[Ver cooperación internacional](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

## EAFIT, tu próximo destino / EAFIT, your next destination

[Conoce EAFIT, tu próximo destino](https://www.eafit.edu.co/internacionalizacion/eafit-next-destination)

![Image 22: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

Nuestras capacidades

![Image 23: Imagen Campus](https://universidadeafit.widen.net/content/a4e11f6e-fa26-476c-b59d-9014341c8950/web/Campus1.png?crop=yes&k=c&w=397&h=253&itok=-OmwEECV)

Campus

Conoce nuestra Universidad Parque.

[Ver campus](https://www.eafit.edu.co/campus)

![Image 24: Imagen CTeI](https://universidadeafit.widen.net/content/0c3b26f7-5763-403f-a1d5-8a10a27e8dff/web/CTei.jpg?crop=yes&k=c&w=397&h=253&itok=vJID7Rcr)

CTeI

Promover la investigación y generamos proyectos dinámicos e interdisciplinarios para responder a los desafíos de la sociedad.

[Ver Ctel](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

![Image 25: Imagen Nuestras escuelas y programas](https://universidadeafit.widen.net/content/ef886cc7-c5cb-409a-b3f8-49e824a93496/web/EscuelasyProgramas.png?crop=yes&k=c&w=397&h=253&itok=1lQqcnpA)

Nuestras escuelas y programas

[Ver nuestras escuelas y programas](https://www.eafit.edu.co/nuestras-escuelas)

![Image 26: Imagen Centros de estudio e incidencia](https://universidadeafit.widen.net/content/5a49b2b9-8609-43f2-a08d-12be4d13f84f/web/Centros.jpg?crop=yes&k=c&w=397&h=253&itok=EW747AAK)

Centros de estudio e incidencia

[Ver Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)

## Convenios

## Para estudiantes eafitenses

Encuentra aquí los convenios disponibles para realizar intercambios o dobles titulaciones a nivel nacional e internacional.

[Ver convenios](https://apps.powerapps.com/play/e/default-99f7b55e-9cbe-467b-8143-919782918afb/a/5e285a8a-44ab-4dbc-99f9-440be6b54d14?tenantId=99f7b55e-9cbe-467b-8143-919782918afb&source=AppSharedV3&hint=bb28e263-a0e5-453a-bac9-2ecb2bc81d4c)

## Para usuarios externos

Conoce nuestros aliados nacionales e internacionales.

[Ver usuarios externos](https://www.eafit.edu.co/internacionalizacion/convenios)

## Aprendizaje global

Promovemos la formación de los eafitenses como ciudadanos del mundo, con competencias globales e interculturales.

[Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

![Image 27: Imagen Aprendizaje global](https://universidadeafit.widen.net/content/a697cb73-ebf5-4462-81ff-efb349111b2b/web/rutas-aprendizaje-educacion-continua.jpg)

Casos y experiencias

![Image 28: Imagen La noche internacional](https://universidadeafit.widen.net/content/c7337902-b9bb-42e8-a269-cf0d65f6c006/web/NocheInternacional.jpg?crop=yes&k=c&w=397&h=253&itok=pSW3Umv2)

La noche internacional

Un espacio para vivir la cultura y la gastronomía del mundo de la mano de nuestros estudiantes internacionales.

[Ver Video](https://www.youtube.com/watch?time_continue=5&v=clSKjTOyvHM&embeds_referring_euri=https%3A%2F%2Fwww.eafit.edu.co%2F&source_ve_path=MTM5MTE3LDIzODUx)

![Image 29: Imagen Harvard Business School – FIELD Global Immersion Course](https://universidadeafit.widen.net/content/4f586014-d422-48d3-94b4-77441251f2eb/web/HBS.jpg?crop=yes&k=c&w=397&h=253&itok=4xXlGWIo)

Harvard Business School – FIELD Global Immersion Course

[Ver video](https://www.youtube.com/watch?v=S9_x6JSeEzM)

![Image 30: Imagen EAFIT](https://universidadeafit.widen.net/content/b5742992-26e2-437d-8e53-9065539e4088/web/EAFIT%20tu%20proximo%20destino.jpg?crop=yes&k=c&w=397&h=253&itok=u62stJ36)

EAFIT

Conoce los testimonios de nuestros estudiantes de intercambio nacional e internacional y elige EAFIT como tu próximo destino.

[Ver video](https://www.instagram.com/internacionalizacion.eafit/reel/C9vN3bOyQ2w/)

![Image 31: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 32: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 33: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 34: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 35: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 36: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 37: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 38: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
