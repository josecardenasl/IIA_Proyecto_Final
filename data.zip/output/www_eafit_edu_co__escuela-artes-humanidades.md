Title: Escuela Artes y Humanidades

URL Source: https://www.eafit.edu.co/escuela-artes-humanidades

Markdown Content:
# Escuela Artes y Humanidades - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/escuela-artes-humanidades#main-content)

[![Image 45: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 46: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 47: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-artes-humanidades#)

[![Image 48: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/escuela-artes-humanidades# "Spanish")[![Image 49: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/escuela-artes-humanidades# "English")

*   [Spanish](https://www.eafit.edu.co/escuela-artes-humanidades)
*   [Inglés](https://www.eafit.edu.co/en/escuela-artes-humanidades)

 Información para ti

[![Image 50: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 51: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 52: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 53: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 54: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 55: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 56: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 57: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 58: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 59: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 60: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 61: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 62: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 63: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 64: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 65: Escuela de Artes y Humanidades EAFIT](https://universidadeafit.widen.net/content/9fc15555-fb1e-4e19-a258-b46db2574036/web/Pregrado-comunicacion-social-9.jpg?crop=yes&k=c&w=1920&h=788&itok=xQDf3gXq)

# Escuela de Artes y Humanidades

Este es el lugar donde el talento y el conocimiento artístico y humanista se conectan con la sociedad.

*   [Inicio](https://www.eafit.edu.co/)
*    Escuela Artes y Humanidades 

Filtros

*   [Posgrados(8)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=tipo_de_programa_artes%3Aposgrados)
*   [Pregrados(5)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=tipo_de_programa_artes%3Apregrados)

Facet Tipo de programa artes 

*   [Creación(6)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=area_de_conocimiento_pre_pos_artes%3A1601)
*   [Cultura(3)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=area_de_conocimiento_pre_pos_artes%3A1591)
*   [Lenguaje(2)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=area_de_conocimiento_pre_pos_artes%3A1596)
*   [Políticas y Desarrollo(1)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=area_de_conocimiento_pre_pos_artes%3A1636)
*   [​Diseño de Productos y Experiencias(1)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=area_de_conocimiento_pre_pos_artes%3A1646)

Facet Área de conocimiento pre pos artes 

*   [Presencial(11)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=modalidad_pre_pos_artes%3A101)
*   [Blended(1)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=modalidad_pre_pos_artes%3A96)
*   [Virtual(1)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=modalidad_pre_pos_artes%3A106)

Facet Modalidad pre pos artes 

*   [Medellín(13)](https://www.eafit.edu.co/escuela-artes-humanidades?f%5B0%5D=sedes_pre_pos_artes%3A121)

Facet Sedes pre pos artes 

[Artes y Humanidades](https://www.eafit.edu.co/taxonomy/term/1531)

#### Psicología

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 Semestres

![Image 67: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 68: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 69: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 70: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 71: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 90978

![Image 72: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$15.442.901

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 73: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$15.099.725

![Image 74: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Becas y financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-artes-humanidades/psicologia "Ver pregrado")

#### Maestría en Música

![Image 75: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

4 semestres

![Image 76: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín​

![Image 77: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Clases sincrónicas

Más información

Clases de énfasis, por acordar con la/el profesor(a).

 Las clases de la línea de profundización se pueden programar entre semana, a partir de las 6:00 p. m. en modalidad híbrida.

![Image 78: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 79: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Híbrido

![Image 80: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 53159

![Image 81: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$58.027.282

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-artes-humanidades/maestria-musica "Ver posgrado")

#### Maestría en Estudios Humanísticos

![Image 82: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

4 semestres

![Image 83: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín​

![Image 84: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Horario

Lunes y miércoles

Más información

Lunes y miércoles de 6:00 p.m. a 10:00 p.m. Se podrán programar algunas sesiones los martes o los sábados, de 8:00 a.m. a 12:00 m.

![Image 85: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 86: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

Más información

Con algunas clases sincrónicas en línea.

![Image 87: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 53502

![Image 88: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$48.947.926

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-artes-humanidades/maestria-estudios-humanisticos "Ver posgrado")

#### Maestría en Lectura y Escritura - Virtual

![Image 89: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 90: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín (virtual)​

![Image 91: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Sincrónico y asincrónico (virtual)

![Image 92: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 93: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Virtual

![Image 94: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 108744

![Image 95: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$32.783.253

[Conocer otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-artes-humanidades/maestria-lectura-escritura-virtual "Ver posgrado")

#### Maestría en Estudios del Comportamiento

![Image 96: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 97: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín​

![Image 98: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábado

Más información

Viernes de 6:00 p.m. a 10:00 p.m. y sábados de 8:00 a.m. a 12:00 m.

![Image 99: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 100: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 101: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 108699

![Image 102: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$40.249.678

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-artes-humanidades/maestria-estudios-comportamiento "Ver posgrado")

#### Maestría en Literatura

![Image 103: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 104: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 105: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Martes y jueves

Más información

Martes y jueves de 8:00 a 10:00 p.m.

![Image 106: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 107: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Combinada

![Image 108: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 116836

![Image 109: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$32.805.080

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-artes-humanidades/maestria-literatura "Ver posgrado")

*   [Página actual 1](https://www.eafit.edu.co/escuela-artes-humanidades?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/escuela-artes-humanidades?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/escuela-artes-humanidades?label=&page=2 "Ir a la página 3")
*   [Siguiente página›](https://www.eafit.edu.co/escuela-artes-humanidades?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/escuela-artes-humanidades?label=&page=2 "Ir a la última página")

## Lo que hace única a esta Escuela

[Calidad y excelencia](https://www.eafit.edu.co/escuela-artes-humanidades#4257225834-2313966186)

Calidad y excelencia

**Somos top en el mundo**

Nuestros profesores están conectados con los problemas que afectan a nuestra sociedad. Así, hemos recibido reconocimientos como el Premio Nacional de Periodismo Simón Bolívar, el Premio Mujeres Directoras de la Orquesta Filarmónica de Bogotá, el Premio Cipa en Periodismo Universitario, el primer puesto en el Concurso Nacional de Piano, el Premio Capital del Periodismo de Impacto Social y Ambiental, entre otros.

**Nos respalda la experiencia y la tradición**

Nuestra Escuela se creó en 1997 y representó una de las transformaciones más importantes de la estructura académica que ha vivido la Universidad, pues se planteó una comprensión más integral de la multidisciplinariedad, con una base filosófica y científica representada en los dos departamentos con los que se creó: Humanidades y Ciencias Básicas.

De los 55 docentes de planta con los que cuenta nuestra Escuela, 36 tienen un título de doctorado. Además, en el área de Creación - Música, el profesor Felipe Tovar está cursando su segundo posdoctorado.

[Campus transformador](https://www.eafit.edu.co/escuela-artes-humanidades#4257225834-34293456)

Campus transformador

**Nos respalda un ecosistema de laboratorios para crear y experimentar**

MediaLab, un laboratorio de innovación en cultura digital y convergencia; Bitácora, un escenario de contenidos convergentes; Acústica, un espacio para experimentar lo sonoro; Celee, un lugar para desarrollar las habilidades y competencias en lectoescritura; Centro Multimedial y estudio de producción audiovisual, dos espacios equipados para crear, experimentar y producir contenidos multimedia.

**Tenemos una agenda académica, cultural y social activa**

Hacemos parte de un ecosistema cultural activo: Editorial EAFIT, Centro de artes y exposiciones con alcance regional y nacional, programación viva y activa, Orquesta sinfónica profesional EAFIT y orquesta de estudiantes.

Contamos con una de las bibliotecas más importantes de la región, que incluye una sala patrimonial que salvaguarda la memoria, con acceso a más de 79 bases de datos bibliográficas, entre artículos, libros, casos, normas, datos estadísticos, videos y partituras musicales disponibles para consulta en línea desde cualquier lugar, más de 452 mil ejemplares en formato impreso y aproximadamente 644 mil títulos disponibles.

La Escuela ha liderado y sido sede de eventos como el Seminario Internacional de Narrativas, el Festival Internacional de Series Web, el Concurso de Debate Crítico, y el Primer Congreso Iberoamericano de Argumentación.

Participamos en eventos como el Salón Iberoamericano del Libro Universitario y el Salón de Nuevas Lecturas de la Fiesta del Libro y la Cultura de Medellín. Nos conectamos con nuestro campus y desarrollamos acciones en él: el conocimiento es visible y permea todos los rincones de la Universidad.

**Tenemos proyección y presencia nacional**

Nuestra Universidad cuenta con sedes en Bogotá y Pereira. Ha operado y acompañado proyectos de diversa índole en el territorio nacional.

**Somos actor clave de una ciudad universitaria**

Medellín ocupa el segundo puesto como mejor ciudad universitaria a nivel regional, según el ICU (Índice de ciudades universitarias); y es la primera ciudad de Latinoamérica en ingresar a la Red PASCAL de ciudades del aprendizaje. Cada año EAFIT recibe x estudiantes de más de 15 países del planeta y x de otras ciudades de Colombia.

[Aprendizaje vivo y activo](https://www.eafit.edu.co/escuela-artes-humanidades#4257225834-3326131826)

Aprendizaje vivo y activo

**Nuestros estudiantes están en el centro y configuran su plan de estudios**

En la Escuela, cada estudiante tiene la libertad de elegir entre las líneas de énfasis para configurar su propio plan de estudios.

Creamos, lideramos e implementamos proyectos y programas de innovación educativa, como el trabajo colaborativo entre nuestra Escuela con instituciones como el Hospital San Vicente Fundación o la Secretaría de Educación de Bogotá.

En nuestros cursos, desarrollamos y resolvemos retos sociales, ambientales, organizacionales y culturales: estamos conectados con los problemas de nuestra sociedad y procuramos alternativas de solución para estos, que se enrutan desde las aulas de clase.

[Innovación y liderazgo](https://www.eafit.edu.co/escuela-artes-humanidades#4257225834-2332436856)

Innovación y liderazgo

**Somos innovación en educación**

Contamos con plataformas de vanguardia para el aprendizaje virtual y digital.

Nuestros estudiantes están continuamente expuestos a conversaciones y procesos con casos reales y con los graduados. También reciben una formación multidisciplinaria gracias a las cinco escuelas de EAFIT y las áreas de conocimiento que las configuran.

**Cultivamos el liderazgo temprano y la investigación**

En la Universidad contamos con más de 30 semilleros, grupos y proyectos de investigación. Tenemos 14 grupos estudiantiles, con más de 1500 integrantes, en los que se desarrollan habilidades de liderazgo desde la práctica. Los estudiantes de nuestra Escuela pueden desarrollar en ellos sus habilidades para la investigación, la creación y la divulgación de conocimiento diverso, complementando su aprendizaje en las aulas con experiencias significativas para su carrera profesional.

[Conexiones e incidencia](https://www.eafit.edu.co/escuela-artes-humanidades#4257225834-2102834693)

Conexiones e incidencia

**Somos un universo empresarial y de emprendimiento activo**

Tenemos a ON.going, el centro de emprendimiento de alto impacto de EAFIT, que se conecta con los problemas y la sociedad; en nuestra universidad tienen sede más de 21 landing empresariales y emprendimientos de impacto.Contamos con el Centro Humanista, un espacio desde el que se estudia e incide, donde se desarrollan proyectos y se proponen conversaciones alrededor de las artes, la creación, el lenguaje, la cultura, la educación, el diálogo y el comportamiento. Además, estamos conectados con el ecosistema de Centros de EAFIT: Gerencia y Empresa, Valor Público, Urbam, EAFIT Social.

Nuestros profesores están en contacto permanente con las organizaciones, la investigación y con las mejores universidades del mundo. También, con los problemas que afectan a nuestra sociedad.

**Somos una puerta al mundo**

Estamos en contacto continua con el país y con el mundo. Tenemos intercambios y transferencias con más de 147 universidades, contamos con acuerdos, proyectos de investigación y 61 entidades académicas que representan programas de intercambio profesoral e investigativo.

**Representamos excelencia para los empleadores**

El 79.4% de nuestros graduados están laborando en las organizaciones donde hicieron las prácticas. Y el 89% de nuestros graduados están empleados.

Nuestros egresados se desempeñan en sectores tan versátiles y variados como los medios, el cine, las editoriales, las orquestas nacionales e internacionales, y las organizaciones privadas y públicas.

**Formamos emprendedores**

Desde 2018 hasta 2022, 782 de nuestros graduados de pregrado y 103 de posgrado han empezado sus emprendimientos. 12 de ellos están en la lista de las 100 mejores startups de Colombia.

Áreas de conocimiento

## Cultura

Esta área se dedica a interpretar y cuestionar sistemas de pensamiento, relaciones de poder, formas de conocimiento, tradiciones y prácticas históricamente situadas que influyen en los modos de vida de las comunidades. Utiliza una diversidad metodológica para proponer diagnósticos, mediaciones e intervenciones que aborden las demandas actuales y promuevan el cambio cultural.

## Lenguaje

Estudia textos, discursos y prácticas en diversos contextos sociales, políticos, estéticos y científicos. Emplea métodos y perspectivas como la gramática, el análisis del discurso, la teoría de la argumentación y la hermenéutica para comprender y analizar la comunicación humana en sus diversas manifestaciones.

## Creación

Se ocupa de comprender, experimentar, comunicar y transformar saberes, prácticas y conocimientos en los ámbitos de la obra-proyecto, la curaduría-intermediación y la circulación-apropiación de procesos y productos creativos y culturales. Promueve la innovación y la expresión artística en diversas áreas como las artes, la música y la literatura, así como en los ecosistemas de las industrias creativas y la cultura digital.

![Image 110: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Centro Humanista

[Ver Centro Humanista](https://www.eafit.edu.co/centro-humanista)

## Grupos de investigación

[Ver grupos de investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion/grupos-investigacion)

Sistema de laboratorios

![Image 111: Imagen Medialab](https://universidadeafit.widen.net/content/4ec5b8d7-5953-4eab-bd34-3189654ee7d4/web/Medialab-05592.jpg?crop=yes&k=c&w=397&h=253&itok=M45YQP70)

Medialab

[Ver Medialab](https://medialab.eafit.edu.co/medialab-eafit/)

![Image 112: Imagen Bitácora - Laboratorio de contenidos convergentes](https://universidadeafit.widen.net/content/55d12337-e523-496e-9032-53a721114499/web/eventos-educacion-continua.jpg?crop=yes&k=c&w=397&h=253&itok=7QZVWzj9)

Bitácora - Laboratorio de contenidos convergentes

[Ver Bitácora](https://bitacora.eafit.edu.co/)

![Image 113: Imagen Acústica - Laboratorio de producción sonora](https://universidadeafit.widen.net/content/d8627982-4c67-4f54-8530-52750e75b404/web/Pregrado-musica-24.jpg?crop=yes&k=c&w=397&h=253&itok=NneRmFDu)

Acústica - Laboratorio de producción sonora

[Ver Acústica](https://acustica.eafit.edu.co/)

![Image 114: Imagen Cámara de Gesell](https://universidadeafit.widen.net/content/bbe23fa5-1c11-4bbc-b844-b0490e2e1892/web/pregrado-derecho-5.jpg?crop=yes&k=c&w=397&h=253&itok=hDNLkAsl)

Cámara de Gesell

[Ver Cámara de Gesell](https://www.eafit.edu.co/escuela-artes-humanidades#)

![Image 115: Imagen Celee - Laboratorio de lectura y escritura](https://universidadeafit.widen.net/content/c59cd9b5-2741-4c3f-b78f-197f9cadd666/web/Negocios%20Internacionales-3.jpg?crop=yes&k=c&w=397&h=253&itok=stxDA-FL)

Celee - Laboratorio de lectura y escritura

[Ver laboratorio de lectura y escritura](https://www.eafit.edu.co/escuela-artes-humanidades/laboratorio-lectura-y-escritura)

![Image 116: Imagen Laboratorio de Psicometría](https://universidadeafit.widen.net/content/6fc87fb2-82f1-43cc-b7e5-18bf1fd75e4f/web/pregrado-geologia-escuela-ciencias-aplciadas-ingenieria-1.jpg?crop=yes&k=c&w=397&h=253&itok=TSBXzi__)

Laboratorio de Psicometría

[Ver Laboratorio de Psicometría](https://www.eafit.edu.co/escuela-artes-humanidades#)

### **Noticias**

![Image 117: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=397&h=250&itok=MKSJ4A11)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 118: Imagen EAFIT me cambió la perspectiva de lo que puedo lograr: Brahian Yamid Suaza Bedoya, graduado de música](https://universidadeafit.widen.net/content/20089e51-7a31-4b94-a517-da7bbe2bdc30/web/graduado-brahian-yamid-suaza-bedoya.jpg?crop=yes&k=c&w=397&h=250&itok=2KW4nNEZ)

[Institucional](https://www.eafit.edu.co/taxonomy/term/1846)

## EAFIT me cambió la perspectiva de lo que puedo lograr: Brahian Yamid Suaza Bedoya, graduado de música

[Ver noticia](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-me-cambio-la-perspectiva-de-lo-que-puedo-lograr-brahian "Ver noticia")

Marzo 24, 2026

![Image 119: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=397&h=250&itok=Ai1Iyv7S)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias)

![Image 120: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 121: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 122: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 123: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 124: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 125: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 126: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 127: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 130](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
