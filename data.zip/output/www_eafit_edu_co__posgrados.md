Title: Posgrados

URL Source: https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96

Markdown Content:
# Posgrados - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#main-content)

[![Image 43: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 44: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 45: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#)

[![Image 46: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96# "Spanish")[![Image 47: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96# "English")

*   [Spanish](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96)
*   [Inglés](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=modalidad_posgrado%3A96)

 Información para ti

[![Image 48: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 49: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 50: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 51: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 52: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 53: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 54: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 55: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 56: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 57: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 58: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 59: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 60: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 61: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 62: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 63: Imagen de banner profesores en aula ](https://universidadeafit.widen.net/content/5e9bd541-f577-4029-b060-e3382ea54151/web/POSGRADOS.jpg?crop=yes&k=c&w=1920&h=788&itok=laAuXcW-)

## **Inscripciones abiertas Posgrados**

## **2026-2**

Conoce los más de 90 programas que tenemos para ti y haz parte de la Universidad que es hogar de una comunidad con el poder de transformarlo todo.

[Déjanos tus datos](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#formulario)

*   [Inicio](https://www.eafit.edu.co/)
*    Posgrados 

##### Programas de posgrado que te han interesado recientemente

Filtros

*   [Administración(8)](https://www.eafit.edu.co/posgrados?f%5B0%5D=escuelas_posgrados%3A1536&f%5B1%5D=modalidad_posgrado%3A96)
*   [Artes y Humanidades(1)](https://www.eafit.edu.co/posgrados?f%5B0%5D=escuelas_posgrados%3A1531&f%5B1%5D=modalidad_posgrado%3A96)

Facet Escuelas Posgrados 

*   [Organización, Dirección y Estrategia(8)](https://www.eafit.edu.co/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1606&f%5B1%5D=modalidad_posgrado%3A96)
*   [Lenguaje(1)](https://www.eafit.edu.co/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1596&f%5B1%5D=modalidad_posgrado%3A96)

Facet Área de conocimiento pre pos 

*   [Maestría(7)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=tipo_de_programa_posgrado%3A141)
*   [Doctorado(1)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=tipo_de_programa_posgrado%3A131)

Facet Tipo de programa Posgrado 

*   [Presencial(96)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=modalidad_posgrado%3A101)
*   [Virtual(8)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=modalidad_posgrado%3A106)
*   [(-)Blended(9)](https://www.eafit.edu.co/posgrados)

Facet Modalidad Posgrado 

*   [Medellín(6)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=sedes_posgrados%3A121)
*   [Bogotá(1)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=sedes_posgrados%3A111)
*   [Pereira(1)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=sedes_posgrados%3A126)
*   [Popayán(1)](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&f%5B1%5D=sedes_posgrados%3A186)

Facet Sedes Posgrados 

#### Maestría en ​Gerencia de la Innovación y el Conocimiento - Popayán

![Image 64: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 65: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Popayán

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábados

Más información

Viernes de 6:00 p.m. a 10:00 p.m., y sábados de 8:00 a.m. a 12:00 m. En algunos casos se programarán sesiones entre semana de 6:00 p.m. a 10:00 p.m. con previa información.

![Image 67: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 68: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Blended

![Image 69: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES

![Image 70: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$45.225.971

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/maestria-gerencia-innovacion-conocimiento-popayan "Ver posgrado")

#### Maestría en ​Gerencia de la Innovación y el Conocimiento - Bogotá

![Image 71: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 72: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Bogotá

![Image 73: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábados

Más información

Viernes 6:00p.m. a 10:00p.m. y sábado 8:00am a 5:00p.m.

![Image 74: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 75: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Blended

![Image 76: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 111717

![Image 77: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$56.886.354

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/maestria-gerencia-innovacion-conocimiento-bogota "Ver posgrado")

#### Maestría en ​Gerencia de la Innovación y el Conocimiento - Pereira

![Image 78: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 79: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Pereira

![Image 80: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábados

Más información

Una vez al mes presencial: viernes de 2:00 p.m. a 10:00 p.m. y sábados de 8:00 a.m. a 5:00 p.m. 

 Una vez al mes remoto: viernes 5:00 p.m. a 9:00 p.m. y sábados de 8:00 a.m. a 12:00 p.m. 

![Image 81: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 82: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Blended

![Image 83: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 111739

![Image 84: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$45.099.391

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/maestria-gerencia-innovacion-conocimiento-pereira "Ver posgrado")

#### Maestría en ​Gerencia de la Innovación y el Conocimiento - Medellín

![Image 85: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 86: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 87: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Viernes y sábados

Más información

Viernes de 5:00 p.m. a 8:00 p.m. y sábados de 7:00 a.m. a 12:00 m. En algunas ocasiones se programan sesiones los días jueves de 5:00 p.m. a 9:00 p.m. pero se informan previamente.

![Image 88: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 89: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Blended

![Image 90: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 103100

![Image 91: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$57.214.064

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/maestria-gerencia-innovacion-conocimiento-medellin "Ver posgrado")

#### Maestría en Ciencias de la Administración

![Image 92: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

4 semestres

![Image 93: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 94: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Martes y jueves - Sábados

Más información

Martes y jueves de 6:00 a. m. a 10:00 a. m. o de 5:00 p. m a 9:00 p. m.

 Sábados de 8:00 a. m. a 12:00m.​

![Image 95: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma 

Español

![Image 96: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 97: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 14912

![Image 98: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$66.705.714

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/maestria-ciencias-administracion "Ver posgrado")

#### Master of International Business- MIB

![Image 99: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

3 semestres

![Image 100: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 101: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Lunes a sábado

Más información

Lunes a viernes de 6:00 p.m. a 10:00 p.m. y sábados de 8:00 a.m. a 12:00 m. (Cada 2 semanas) 

![Image 102: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma 

Inglés

![Image 103: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Blended (semanas 1 y 3 remotas y semana 2 presencial)

![Image 104: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 106533

![Image 105: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Precio total del programa

$54.582.316

[Conocer tarifas](https://www.eafit.edu.co/tarifas)

[Ver más](https://www.eafit.edu.co/posgrados/escuela-administracion/maestria-master-international-business-mib "Ver posgrado")

*   [Página actual 1](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&label=&page=1 "Ir a la página 2")
*   [Siguiente página›](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/posgrados?f%5B0%5D=modalidad_posgrado%3A96&label=&page=1 "Ir a la última página")

## **Guía de aspirantes posgrados**

[Inscripción](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-4023747369)

Inscripción

###### Realiza tu inscripción y efectúa el pago

**Fechas de inscripción: a partir del 24 de febrero.**

###### a. Proceso de inscripción

Puede solicitar admisión a los programas de posgrado, todo profesional que haya terminado estudios de nivel universitario o de licenciatura, en una universidad nacional o extranjera reconocida, por autoridades estatales educativas competentes. Técnicos, tecnólogos o tecnólogos especializados, no podrán inscribirse en EAFIT para un programa de posgrado. Si ya has estado matriculado en una institución de educación superior, diferente a EAFIT, en un programa de posgrado, debes solicitar el tipo de admisión **Transferencia externa**, independientemente de si deseas o no solicitar reconocimiento de asignaturas. Si es la primera vez que vas a cursar un posgrado, selecciona tipo de solicitante**Estudios primera vez**, en el [**autoservicio EPIK**](https://www.eafit.edu.co/epik), módulo “**Inscripciones Pregrado y Posgrado**”.

Si ya has estado matriculado en un pregrado o posgrado en EAFIT, el sistema te mostrará la lista de los tipos de admisión que aplican, de acuerdo con el programa seleccionado; si el sistema no te muestra ningún tipo de admisión, por favor ponte en contacto a través del correo electrónico ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) con tu nombre completo, tipo y número de documento de identificación, el programa al cual te vas a inscribir, la ciudad donde lo vas a cursar y el nombre del programa cursado en EAFIT.

Para realizar tu inscripción, ingresa al módulo**Inscripciones** haciendo clic [**aquí**](https://www.eafit.edu.co/inscripciones), pulsa el botón Inicia aquí tu inscripción, y procede a diligenciar el formulario. Digita todos los datos requeridos.

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados y conoce nuestros programas disponibles** para el semestre **2026-2**.

###### b. Pago de inscripción

Valor de la inscripción: **$360.500 COP.**

Luego de haber enviado exitosamente tu solicitud de inscripción, dirígete al final del formulario y procede a efectuar tu pago. Si diligenciaste el formulario y vas a realizar el pago de inscripción de forma posterior, ingresa al [Autoservicio EPIK](https://www.eafit.edu.co/epik), módulo “**Mis Finanzas**”, opción “**Centro de Pagos**”, y donde el sistema presenta el documento de pago, selecciónalo y activa el botón **Pagar en Línea**.

El valor de tu inscripción lo puedes pagar por comercio electrónico, con tarjeta de crédito o mediante débito a una cuenta en uno de los bancos que se encuentren inscritos en PSE. No cierres la página hasta que el banco informe que tu transacción fue exitosa, busque la opción regresar.

Si no puedes hacer uso del comercio electrónico, da clic en Descargar PDF, imprímelo en láser y llévalo a uno de nuestros bancos autorizados a nivel nacional: Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.

Si tiene algún problema para generar el documento de pago, puede enviar un correo a [**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)

Si su dificultad está relacionada con el pago, puedes enviar un correo a [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

El pago de la inscripción desde el exterior se recibe a través de transferencia bancaria; para obtener los datos de la cuenta de la Universidad, contacte al área de Apoyo Financiero por medio del correo electrónico [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co)

Una vez que recibamos el pago de tu inscripción, el sistema te enviará al correo electrónico registrado al diligenciar tu formulario de inscripción, una notificación informando la confirmación de la inscripción y los trámites que debes seguir para continuar con tu proceso de admisión.

[Anexa tus documentos](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-1328898390)

Anexa tus documentos

###### Anexa tus documentos a través del formulario de inscripción

###### a. Relación de documentos

Si ya realizaste tu pago de inscripción, puedes adjuntar tus documentos digitalmente a través del [**Autoservicio EPIK**](https://www.eafit.edu.co/epik), ingresando al módulo “**Anexo de documentos**”. El sistema te mostrará los documentos que debes anexar, según el programa y tipo de admisión; ten presente que sean tipo JPG, TIF o PDF, y que el tamaño esté entre 1 Kb y 12 Mb.

**Documento****Estudios por primera vez****Transferencia externa****Graduado de la Universidad EAFIT**
Acta de grado de pregrado, original escaneada o emitida digitalmente por la Universidad con las respectivas firmas. Si obtuvo el título en el extranjero, anexe el diploma de grado además, y su respectiva traducción al español.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.No.
Fotocopia del documento de identidad, ampliada al 150%, en sentido vertical y en una misma página ambas caras o documento digital.SÍ. Se requiere para la admisión.SÍ. Se requiere para la admisión.Si aún no la tiene actualizada en Admisiones y Registro
Para la solicitud de transferencia externa: Carta personal dirigida a Admisiones y Registro en la que exponga claramente, los motivos por los cuales desea hacer la transferencia externa e indique si es con reconocimiento o sin reconocimiento de asignaturas. En caso de reconocimiento, relacione las asignaturas que desea le sean reconocidas.No.Sí. Se anexa a través del módulo; Anexo de documentos. Se requiere para la admisión.No

###### b. Requisitos adicionales

Ingresa [**aquí**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), da clic en el botón **Conoce nuestra oferta de Posgrados** y conoce nuestros programas disponibles para el semestre 2026-2, horarios y requisitos adicionales si aplican.

###### c. Transferencias externas con reconocimiento de asignaturas

Para el reconocimiento de asignaturas, los solicitantes de transferencia externa deben llevar a la entrevista los certificados que se enumeran a continuación; y anexar por el formulario de inscripción los especificados:

**Documento****Transferencia Externa**
Certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, en el que se indiquen las asignaturas cursadas con su nota e intensidad horaria.SÍ. Anexa en el formulario de inscripción
Programas con los contenidos detallados de las asignaturas que desea le sean reconocidas por EAFIT, debidamente certificados con firma y sello de la universidad de procedencia.SÍ. Se entrega al entrevistador
Para el reconocimiento de asignaturas que cursa en el actual semestre, debe anexar un certificado de la universidad de procedencia, en papel membrete y las respectivas firmas, la intensidad horaria y los programas con los contenidos detallados, debidamente certificados; en este caso, el reconocimiento está condicionado a la nota definitiva que obtenga en el curso, por lo que debe anexar el certificado de calificaciones.SÍ. Anexa en el formulario de inscripción. Entregar antes del 10 de enero de 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

[Entrevista](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-2915221919)

Entrevista

###### **Selecciona tu cita de entrevista (si aplica para el programa)**

Una vez que recibamos el pago de tu inscripción, programa tu entrevista. Para ello, ingresa al Autoservicio [**aquí**](https://www.eafit.edu.co/epik), dirígete al módulo “**Servicios y certificados**”, ingresa a la opción “**Solicitud de servicios**”, allí, en la sección “**Solicitudes Realizadas**”, accede al servicio “**Cita de entrevista de admisión**”, selecciónalo y solicita la cita de entrevista que deseas.

**Importante: Por favor revisa la disponibilidad tanto presencial como virtual.**

Si no encuentras citas disponibles, activa la opción “**No encontré cita**”, con esto procederemos a crear nuevos espacios para que, posteriormente, ingreses y selecciones uno.

**Si el programa no requiere entrevista, el sistema no le presentará el servicio "Cita de entrevista de admisión" para la selección.**

[Admisión](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-2048125946)

Admisión

###### **Consulta tu resultado de admisión**

El proceso de admisión inicia el 24 de marzo de 2026, a partir de esta fecha te notificaremos sobre tu admisión al correo electrónico que registraste al diligenciar tu formulario de inscripción.

También puedes consultar tu estado ingresando al [**Autoservicio Epik**](https://www.eafit.edu.co/epik), módulo "**Inscripción Pregrado Posgrado**" y dando clic en el campo "**Estado**".

Para ser admitido es requisito indispensable haber entregado toda la documentación requerida y de ser el caso haber presentado tu entrevista de admisión.

**Nota:** si eres aspirante extranjero, una vez seas admitido en la Universidad, debes presentar, para poder matricularte formalmente, tu visa de estudiante con vigencia en el período académico que vas a cursar.

[Homologación](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-3486650419)

Homologación

###### **Homologación de créditos (si aplica para tu tipo de admisión)**

Para todo lo relacionado con el reconocimiento de asignaturas en los programas de posgrado, consulta [aquí](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) el Reglamento académico de posgrado de la Universidad EAFIT o con la jefatura del programa de su elección.

[Horario de clases](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-1341125043)

Horario de clases

###### **Consulta tu horario de clases y documento de pago**

Una vez tu estado sea admitido y cumpla con la documentación requerida, realizaremos tu inscripción de clases de acuerdo con la información brindada por el programa al cual fuiste admitido.

Consulta tu horario a través del Autoservicio EPIK, dando clic [**aquí**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) e ingresando al módulo “**Mi Matrícula**” y luego ingresando a la opción “**Mis Clases**”.

Los horarios serán asignados a partir del mes de mayo con base en la programación académica de cada posgrado.

[Matrícula](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-2477669287)

Matrícula

###### **Realiza tu pago de la matrícula**

Una vez realizada la inscripción de clases y generado el documento de pago de la matrícula, consulta las fechas de pago en el mismo.

###### Consulta la liquidación

Ingresa al Autoservicio EPIK dando clic [aquí](https://www.eafit.edu.co/epik), selecciona el módulo “Mis Finanzas”, ingresa a la opción “Centro de Pagos” y donde el sistema presenta el documento de pago de matrícula, selecciona el documento.

Si tienes alguna dificultad con el pago de la matrícula, puedes escribir al correo electrónico [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago en línea

Consulta previamente con tu banco si tus tarjetas se encuentran autorizadas para hacer transacciones por internet y los montos que tengas asociados a las mismas, esto con el fin de evitar que la transacción pueda ser rechazada.

Para realizar el pago de tu matrícula ingresa a través del [**Autoservicio de Epik**](https://www.eafit.edu.co/epik) con usuario y contraseña; en el módulo “**Mis finanzas**”, en la opción “**Centro de pagos**” y en el botón “**Pago en Línea**”, en el cual podrás ir directamente a la plataforma PlacetoPay para realizar el pago. A través de este medio puede pagar utilizando una o varias tarjetas débito (PSE) o crédito.

Deberá pagar el 100% del valor la liquidación de la matrícula para que el proceso finalice de manera exitosa y adquiera la calidad de estudiante.

No cierres la página cuando el banco te informe que la transacción fue exitosa; busca la opción regresar que te llevará nuevamente a la página de la Universidad para confirmar tu pago, de lo contrario, la información no llegará a nuestra base de datos.

###### Pago en bancos

Es importante que conozcas las oficinas de las entidades financieras autorizadas a nivel nacional, estas son: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas y Banco de Occidente.**

Debes presentar la liquidación de matrícula impresa para la lectura del código de barras (impresión láser) únicamente en las oficinas del Banco de Bogotá, puede presentar la matrícula de manera digital a través del celular o tablet.

Los bancos reciben pago en efectivo y/o cheque a nombre de Universidad EAFIT.

Cuando realices pago en cheque deberá diligenciar al reverso de este el código o número de identificación del estudiante, teléfono y el número de la liquidación de matrícula.

Los Bancos sólo aceptarán pagos por el valor total de la liquidación, es decir, no recibirán pagos por un monto menor o mayor al valor de la matrícula.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

Cualquier solicitud, inquietud o comentario, puedes comunicarlo a través de nuestra línea de atención (604) 2619500 o al siguiente correo electrónico: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Pago facturación a empresa

Si vas a realizar el pago de tu matrícula en una empresa y te exige factura a nombre de esta, ten en cuenta lo siguiente: Existe dos tipos de factura a empresa:

**Contado:** Para este tipo de facturación la empresa debe realizar el pago de forma inmediata.

**Crédito:** La empresa requiere 30 días de plazo para pagar previo a una aprobación de crédito.

El proceso de facturación a empresa se debe realizar **aquí**.

Los documentos que se deben de anexar son:

1.   El estudiante debe anexar la carta en papel membrete en donde la empresa autorice a la Universidad EAFIT a facturar por concepto de matrícula, reajustes, matricula adicional, intersemestrales o validación de práctica, dicha carta debe estar firmada por el Representante Legal o el jefe de Recursos Humanos de la empresa, en ningún caso por el mismo estudiante.
2.   El Rut.
3.   Cámara de Comercio de la empresa.
4.   La carta debe contener información como Nit, Nombre de la empresa, dirección, correo donde reciben la facturación electrónica, valor a facturar, e indicar si es factura de contado o a crédito. Por ninguna razón debes pagar con tu liquidación a título personal, es decir con el documento de pago a nombre del estudiante, si realizas el pago, no podremos realizar la factura a nombre de la empresa.

Para conocer otros de métodos de pago ingresa [aquí](https://www.eafit.edu.co/becas-y-financiacion)

Si necesitas acompañamiento en algún método de pago escríbenos al correo [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co)

###### Pago en caja – Tesorería EAFIT

En nuestra caja de Tesorería recibimos los pagos que no se puedan gestionar a través de los canales descritos anteriormente (pago en línea o pago en bancos), es decir, los pagos mixtos que incluyen tarjeta de crédito, así:

1.   Tarjeta de crédito + cheque
2.   Tarjeta de crédito + efectivo

###### Financiación educativa ‘EAFIT a tu alcance’

Los admitidos que requieren financiación del semestre, podrán solicitar financiación de corto y largo plazo.

Esta iniciativa, también contempla un cupo semestral en el que se dará prioridad a quienes muestren méritos académicos.

Si requieres financiación y más información, puedes enviar un e-mail [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co); también, puedes comunicarte a la línea de atención al cliente (604) 2619500 o consultar en el siguiente sitio web [ingresa aquí](https://www.eafit.edu.co/becas-y-financiacion).

[Carné de estudiante](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96#4257225834-3543329415)

Carné de estudiante

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

[![Image 106: Imagen de tres personas estudiando](https://universidadeafit.widen.net/content/29e06c8a-654b-40c5-8a52-333f32ff6a5c/web/Artes-y-Humanidades-9.jpg?crop=yes&k=c&w=1920&h=788&itok=XjghgIiQ)](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96)

![Image 107](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96)

## Inicia tu proceso de inscripción

El valor es de $360.500.

[Inscríbete aquí](https://mcu.azureedge.net/?site=MCU_003&cmd=login)

Nuestras escuelas

## Administración

[Ver Escuela de Administración](https://www.eafit.edu.co/escuela-administracion)

## Ciencias Aplicadas e Ingeniería

[Ver Escuela de Ciencias Aplicadas](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria)

## Artes y Humanidades

[Ver Escuela de Artes](https://www.eafit.edu.co/escuela-artes-humanidades)

## Derecho

[Ver Escuela de Derecho](https://www.eafit.edu.co/escuela-derecho)

## Finanzas, economía y gobierno

[Ver Escuela de Finanzas](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno)

![Image 108: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## 3.500

estudiantes activos

## 42.000

graduados

![Image 109: Imagen 3.500 ](https://universidadeafit.widen.net/content/fd916074-852d-4f19-a53f-427811c609a9/web/posgrados-fotos-generales20.jpg?itok=t2mcXqjW)

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​  

¿Des​eas​ ​​conocer m​​ás a​cerca de ​EAFIT y sus ​posgrados?​

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Nivel de formación*? 

Ciudad* 

Inicio del programa 

Canal origen 

Programa? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)*

![Image 110](https://www.eafit.edu.co/posgrados?f[0]=modalidad_posgrado:96)

![Image 111: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 112: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 113: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 114: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 115: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 116: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 117: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 118: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 121](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
