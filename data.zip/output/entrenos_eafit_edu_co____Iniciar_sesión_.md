Title: Sign in to your account

URL Source: https://entrenos.eafit.edu.co/%20%22Iniciar%20sesi%C3%B3n%22

Markdown Content:
# Sign in to your account

![Image 1: Organization banner logo](https://aadcdn.msauthimages.net/dbd5a2dd-65s8oof-hryu8jr5oebivpprmrny7cmi-apqnc6o2xc/logintenantbranding/0/bannerlogo?ts=638119192849187044)

Sign in

[Can’t access your account?](https://entrenos.eafit.edu.co/%20%22Iniciar%20sesi%C3%B3n%22#)

Inicio de sesión de correo - Universidad EAFIT

![Image 2](https://aadcdn.msauth.net/shared/1.0/content/images/signin-options_3e3f6b73c3f310c31d2c4d131a8ab8c6.svg)

Sign-in options

[Terms of use](https://www.microsoft.com/en-US/servicesagreement/)[Privacy & cookies](https://privacy.microsoft.com/en-US/privacystatement)[...](https://entrenos.eafit.edu.co/%20%22Iniciar%20sesi%C3%B3n%22#)
