Title: Celebramos el poder de la inspiración ¡Estos son los ganadores de la cuarta edición de los Premios Inspiradores EAFIT!

URL Source: https://www.eafit.edu.co/noticias/eafit-es-noticia-nuestra-comunidad-de-talento/celebramos-el-poder-de-la-inspiracion-estos

Markdown Content:
# Celebramos el poder de la inspiración ¡Estos son los ganadores de la cuarta edición de los Premios Inspiradores EAFIT! - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/noticias/eafit-es-noticia-nuestra-comunidad-de-talento/celebramos-el-poder-de-la-inspiracion-estos#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/eafit-es-noticia-nuestra-comunidad-de-talento/celebramos-el-poder-de-la-inspiracion-estos#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/eafit-es-noticia-nuestra-comunidad-de-talento/celebramos-el-poder-de-la-inspiracion-estos# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias/eafit-es-noticia-nuestra-comunidad-de-talento/celebramos-el-poder-de-la-inspiracion-estos# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Institucional](https://www.eafit.edu.co/taxonomy/term/1846)

# Celebramos el poder de la inspiración ¡Estos son los ganadores de la cuarta edición de los Premios Inspiradores EAFIT!

**Estos siete graduados y cinco organizaciones, desde diferentes campos, están dejando huella y aportando a la sociedad con su inspiración y liderazgo. Y por eso fueron reconocidos, este 5 de noviembre, en la más reciente edición de los premios Inspiradores EAFIT.**

**Una de las novedades de esta edición es que, además de distinguir a los graduados de la Universidad, incluyó la modalidad Organizaciones de Impacto, creada en alianza con el diario**_**Portafolio**_**, para premiar a las entidades que, con sus proyectos, están contribuyendo a la solución de los desafíos globales.**

*   [Inicio](https://www.eafit.edu.co/)
*   [Noticias](https://www.eafit.edu.co/noticias)
*    Eafit Es Noticia Nuestra Comunidad de Talento 
*    Celebramos El Poder de La Inspiración ¡Estos Son Los Ganadores de La Cuarta Edición de Los Premios Inspiradores EAFIT! 

![Image 21: Imagen Celebramos el poder de la inspiración ¡Estos son los ganadores de la cuarta edición de los Premios Inspiradores EAFIT!](https://universidadeafit.widen.net/content/acc26ea1-5c5c-4189-960b-75a1917fd27d/web/inspiradores-eafit2025.jpg?crop=yes&k=c&w=823&h=450&itok=E-xxNWIl)

Las orquídeas son símbolo del campus eafitense y por eso los galardonados recibieron una orquídea de la especie dendrobium, recolectada en Barbosa (Antioquia) y después convertida en una joya para ser inmortalizada. En la imagen los galardonados de la noche.

La inspiración se gesta en la cotidianidad, en las ideas que trascienden a la acción, y en la acción que, con principios, se convierte en legado y en huella para la sociedad. Y eso lo evidencian los siete graduados eafitenses y las cinco organizaciones que, este 5 de noviembre, recibieron reconocimiento en los Premios Inspiradores EAFIT 2025.

En la cuarta edición de este galardón, que se entregó en el marco de la conmemoración de los 65 años de EAFIT, además de distinguir a los graduados de la Universidad, también se resaltó por primera vez a las empresas, fundaciones e instituciones que, con sus iniciativas, están aportando soluciones a los desafíos globales. Por eso contó con dos modalidades: Líderes Inspiradores, y Organizaciones de Impacto, esta última en alianza con el diario _Portafolio_.

Por el lado de los eafitenses el evento permitió conocer y destacar la inspiración de profesionales que están aportando desde diversos campos como la seguridad alimentaria, la innovación educativa apalancada en las nuevas tecnologías, la cultura, la ciencia o el liderazgo de empresas. Y, por el de las organizaciones, fue una oportunidad para exaltar el impacto de proyectos orientados hacia el fortalecimiento del acceso a la educación y la bancarización en la ruralidad; el transporte de carga sostenible; la innovación en los procesos o la construcción de viviendas dignas para las familias colombianas.

En ese sentido, la modalidad **Líderes inspiradores**, el galardón exaltó a **Catalina Isaza Falla**, ingeniera de Diseño de Producto y fundadora de Innmetec, en **Ciencia y Tecnología**; a **Natalia De Greiff Cadavid**, ingeniera de Producción y vicepresidenta de Automatización en IBM Américas, en**Innovación educativa y futuros del trabajo**; a **Marcela Giraldo Muñoz**, abogada y **magistrada de la JEP**, y a **David Escobar Arango**, ingeniero de Producción y director de Comfama, en **Cultura, ciudadanía e inclusión**; a **María Josef Lopera Acosta**, ingeniera física y magíster en Física Aplicada, en **Liderazgo emergente**; a **Claudia Cecilia Restrepo Múnera**, ingeniera de Producción y socia de Sostenibilidad y Cambio Climático de Deloitte SLatam, en **Sostenibilidad y cambio climático**; y a **Juan Carlos Mora Uribe**, administrador de negocios y presidente de Bancolombia, en **Liderazgo empresarial, público o emprendedor**.

En la modalidad **Organizaciones de Impacto** fueron distinguidas**Alianza Team** por su proyecto Ecosistema de Innovación y Transformación (**Ciencia y Tecnología**); **Postobón** por su proyecto Innovación para la movilidad sostenible (**Sostenibilidad y cambio climático**); **Cementos Argos** por Hogares Saludables (**Cuidado y bienestar**); **Fundación Bancolombia** por Sistemas Rurales Emergentes (SRE) (**Cultura, ciudadanía e inclusión**); y la **Alianza ERA – Fundación Secretos para Contar**por La U en el Campo (**Innovación educativa y futuros del trabajo**). [Ver recuadro con los perfiles de los ganadores](https://www.eafit.edu.co/noticias/eafit-es-noticia-nuestra-comunidad-de-talento/celebramos-el-poder-de-la-inspiracion-estos#ganadores).

“El propósito superior de EAFIT es inspirar, crear y transformar, y por eso lo que hoy estamos celebrando aquí es el espíritu que nos convoca como Universidad. Y lo hacemos reconociendo a las personas y a las organizaciones por su liderazgo, innovación y sentido de comunidad”, comentó Claudia Restrepo Montoya, rectora de EAFIT, durante el saludo que dio a los asistentes, a los nominados y premiados, y a sus familias.

La directiva destacó, además, la alianza con _Portafolio_ para premiar a los proyectos e iniciativas de las organizaciones. Un hecho que destacó como una muestra de que la Universidad es fiel a sus principios y a su ADN funcional. “Esta Institución se entreteje en relación con los ecosistemas de las organizaciones, con las empresas, los sistemas públicos y los emprendimientos”.

Para Omar Ahumada Rojas, editor de _Portafolio_, esta intención del reconocimiento también se alinea con los objetivos del diario, que son generar consenso, critica, debate, reflexión y aprendizajes a partir de las iniciativas que están generando valor para transformar la sociedad. “Y nos inspiramos en eso, y en EAFIT, para premiarlas”.

Andrea Salazar, representante de los jurados de la modalidad de Eafitenses inspiradores, destacó la importancia de que existan este tipo de galardones como un recordatorio del que en el país existe un liderazgo que trasciende los resultados, construye con los otros, y moviliza sostiene las transformaciones en el tiempo.

Así mismo, Andrea Escobar, en representación del panel evaluador de la modalidad de Organizaciones de Impacto, señaló: “Cada idea que vamos a ver acá, sea en las empresas, en el campo, en el sector financiero, en el acceso a la educación o en otros campos, tienen algo en común: nacieron de unas personas que se atrevieron a sembrar diferente y que entendieron que el cambio no se espera, sino que se construye”.

**181 postulaciones de graduados y 157 de proyectos de organizaciones** hicieron parte de esta edición del reconocimiento. En la categoría de eafitenses inspiradores, el panel de jurados estuvo integrado por Juan Manuel Velasco, deputy CEO de Colombia en BTG Pactual y presidente del Consejo Superior de EAFIT; Cristina Vélez Valencia, decana de la Escuela Administración de la Universidad; Andrea Salazar, directora de la Fundación Origen Red de Liderazgo; y Daniel Uribe, director ejecutivo de la Fundación Corona.

Para el caso de las organizaciones, la selección estuvo a cargo de Julián Mora, vicepresidente corporativo de Grupo Cibest/Bancolombia; Ana Fernanda Maiguashca, presidenta del Consejo Privado de Competitividad (CPC); Ricardo Sierra Fernández, presidente de Celsia; Andrea Escobar Vilá, directora ejecutiva de Empresarios por la Educación; Pablo Santos, CEO de Finaktiva; y Antonio Celia, empresario y expresidente de Promigas. La firma Ernst & Young (EY) fue la observadora del proceso del reconocimiento Inspiradores EAFIT en sus dos modalidades.

“Estamos muy felices y orgullosos de haber exaltado a siete graduados y cinco organizaciones que reflejan el liderazgo y la capacidad transformadora de nuestra comunidad. Cada historia fue una muestra del impacto que los eafitenses y las empresas están generando en el país, desde distintos sectores y propósitos. Esta edición fue una gran noche de liderazgo: de los graduados, de las organizaciones y de EAFIT misma, que sigue consolidando su propósito de inspirar, crear y transformar”, concluyó Isabel Gómez Yepes, directora de Desarrollo Institucional y Vínculos.

#### Estos son los graduados y las organizaciones reconocidas:

##### Eafitenses inspiradores

###### Catalina Isaza Falla – Ingeniera de Diseño de Producto

**Ciencia y Tecnología**

La categoría de Ciencia y Tecnología exalta la contribución de nuestros graduados eafitenses en proyectos de investigación con enfoque aplicado, publicaciones indexadas, patentes, producción científica o por sus aportes a la ciencia. Y esa es una descripción en la que encaja Catalina Isaza Falla, ingeniera de Diseño de Producto.

Primero quiso ser médica, pero luego se dio cuenta de que, desde la ingeniería, también podía ayudar a las personas y al sector de la salud. Por eso tuvo claro, desde que comenzó los estudios del pregrado, que ese sería el campo en el que quería desempeñarse. Lo visionó y lo cumplió. Hizo parte del Grupo de Investigación en Biotecnología, cursó la especialización en Gerencia de Diseño de Producto y la maestría en Ingeniería, y creó Innmetec, una _start-up_ especializada en el diseño de implantes óseos a partir de biomateriales similares a los huesos y que no necesitan ser reemplazados en el futuro.

“Le agradezco a la Universidad EAFIT porque en estos 15 años de trayectoria me enseñó a ser líder inspiradora, y me mostró que para serlo siempre debía tener a la mano empatía, coherencia, convicción y capacidad de aprender, escuchar y seguir soñando”, expresó.

###### Natalia De Greiff Cadavid – Ingeniera de Producción

**Innovación educativa y futuros del trabajo**

Un auditorio lleno de personas y, de repente, un celular comienza a sonar. Es el de la conferencista, quien en medio de la charla se dirige a los asistentes: “Es mi hijo, y yo siempre le contesto”. Ese gesto breve encarna parte de la filosofía de una líder como Natalia De Greiff Cadavid, quien está convencida de que, antes que ejecutivos o directivos, los líderes son ante todos seres humanos.

> “Los líderes tenemos una responsabilidad con la sociedad, y es comenzar a devolver. Agradezco este reconocimiento que me muestra que, para hacerlo, debemos aprender a escuchar y tener un interés genuino por las personas y por los propósitos a los que servimos”, expresó la eafitense galardonada.

Esta ingeniería de Producción y hoy vicepresidenta de Automatización en IBM Américas vive inmersa entre algoritmos, pero ha entendido que más allá de la tecnología, cuando se trata de liderar -y sobre todo de inspirar- hay que volver a lo esencial, escuchar, aprender y construir culturas que pongan a las personas en el centro. Esa es una filosofía se complementa con la descripción de esta categoría, que valora y resalta a graduados eafitenses en la implementación de nuevas ideas, enfoques, tecnologías y metodologías que transforman las prácticas de enseñanza y aprendizaje para hacerlas más relevantes, inclusivas, efectivas y sostenibles, anticipándose a los desafíos emergentes y respondiendo a los cambios sociales, culturales, tecnológicos y ambientales.

###### Marcela Giraldo Muñoz - Abogada

**Cultura, ciudadanía e inclusión**

Con una sólida trayectoria internacional y un compromiso profundo con los derechos humanos, Marcela Giraldo Muñoz ha convertido su experiencia académica y profesional en un ejemplo de liderazgo ético y transformador. Esta abogada de la Universidad y magíster en Derecho Internacional Humanitario de la Geneva Academy, ha dedicado su carrera a la defensa de la dignidad humana y al fortalecimiento de la justicia, desde espacios como la Corte Interamericana de Derechos Humanos, el Comité Internacional de la Cruz Roja y diversos tribunales internacionales, y como magistrada de la Justicia Especial para la Paz.

Su historia profesional refleja la convicción de que el liderazgo también se ejerce desde el Servicio, la empatía y el compromiso con el país y la construcción de una justicia que escuche a todas las personas y garantice sus derechos. “La Universidad y el pregrado en Derecho me enseñaron que para liderar hay que proponer soluciones, ser creativos, abrir caminos, cuestionar con argumentos, debatir con respeto, escuchar y tener convicción. Y, sobre todo, estar comprometidos con aportar y generar impactos positivos que permitan transformar la realidad de nuestro país”.

###### David Escobar Arango – Ingeniero de Producción

**Cultura, ciudadanía e inclusión**

David es un ingeniero de producción al que no solo lo habitan los conocimientos propios del campo, sino también otros como la literatura, la poesía, la filosofía, la sociología, las políticas públicas o el urbanismo, entre otros, que le han permitido configurar el perfil humanista necesario para creer y trabajar por la educación, el mismo por el que es reconocido en la categoría de Cultura, ciudadanía e inclusión, que reconoce el aporte de nuestros graduados con la democracia, el arte, la cultura, los programas sociales, la inclusión y la diversidad.

Su recorrido profesional como secretario privado y director del Departamento Administrativo de Planeación de Medellín; vicepresidente de Mercados Corporativos de UNE EPM Telecomunicaciones; director ejecutivo de Interactuar; y actual director administrativo de la caja de compensación familiar Comfama, evidencian su compromiso con estos temas. Entre 2022 y 20224 tuvimos la fortuna de contar con su guía como presidente del Consejo Superior de la Universidad.

Durante el evento el eafitense envió un video en el que expresó que, para él, el verdadero liderazgo es “el que emerge de la introspección, la reflexión y la preguntar por cómo ser mejor. No hay liderazgo sino está acompañado de una vocación por hacer que otra persona, una empresa, una organización o una comunidad pase de un punto a otro logrando evolución”, puntualizó.

###### María Josef Lopera Acosta – Ingeniera Física

**Liderazgo emergente**

Como parte de su recorrido investigativo María Josef Lopera Acosta, graduada del pregrado en Ingeniería Física y de la maestría en Física Aplicada desarrolló un prototipo de microscopía holográfica sin lentes que llega a los máximos niveles de resolución. El objetivo de esta eafitense era lograr captar objetos muy pequeños con la misma resolución de un microscopio común y lo logró gracias a su dedicación, a su compromiso y a su recorrido, por tres años, como líder del grupo de investigación en Óptica Aplicada.

Con esta invención fue reconocida con los premios Medellín Investiga en 2024, de la Alcaldía de Medellín; y la distinción Antioqueña de Oro, de la Gobernación de Antioquia. Hoy, a ese palmarés, se suma un nuevo, el de Eafitense Inspiradora en la categoría Liderazgo emergente, que destaca a graduados o graduadas de hasta 30 años, que buscan soluciones creativas a problemáticas de la sociedad a partir de un liderazgo innovador, inspirador y que se adapta a las necesidades cambiantes de los equipos y de la sociedad.

> “Hoy puedo afirmar que en EAFIT se inventa el futuro y me siento orgullosa de ser reconocida por una Universidad que crece en ese propósito. Ser llamada líder inspiradora me hace sentir útil, valiente y auténtica”.

###### Claudia Cecilia Restrepo Múnera - Ingeniera de Producción

**Sostenibilidad y cambio climático**

El encadenamiento productivo, el acceso al empleo y a la educación, la prevención del embarazo adolescente, el apoyo a las economías naranja y plateada, la seguridad alimentaria y el campo de la salud, son temas que, además de ser prioritarios para esta ingeniera de producción, son frente en los que ha tenido la fortuna y el orgullo de trabajar para, como ella misma sostiene, “servir y construir puentes”.

Hoy, como socia de Sostenibilidad y Cambio Climático de Deloitte SLatam, esta eafitense continúa destacándose por su compromiso con el liderazgo inclusive y la promoción de mecanismos innovadores para la equidad y el futuro de la alimentación. “No sé a cuántas personas haya inspirado en mi camino, lo que sí sé es que este camino me ha inspirado a mí, y me ha enseñado a ser coherente entre lo que creo y lo que hago”.

###### Juan Carlos Mora Uribe – Administrador de Negocios

**Liderazgo empresarial, público o emprendedor**

Con su trayectoria como presidente de Bancolombia y del Grupo Cibest, y graduado de EAFIT Juan Carlos Mora Uribe, ha convertido su historia personal y profesional en una fuente de aprendizajes para nuevas generaciones de líderes. Su manera de entender el liderazgo combina la reflexión profunda con la acción responsable y resalta la convicción de que liderar implica conocerse, ser coherente y construir confianza. No en vano, este año, fue reconocido como el líder número uno del país en el ranquin Merco Líderes.

Y es que, bajo su visión, las organizaciones que ha liderado trascienden los negocios y se convierten en agentes de transformación social. Y esta categoría reconoce, justamente, a los graduados o graduadas que han tenido incidencia e impacto positivo en los ecosistemas públicos y sociales, en las organizaciones o en los emprendimientos, por su espíritu innovador, y su habilidad para inspirar e iniciativas creativas que aporten a la construcción del tejido social y económico del país.

> “El liderazgo auténtico se refleja en el impacto que generamos y no en el cargo que tenemos. Es inspirar y transformar; es promover el bienestar colectivo, construir confianza y movilizar cambios positivos. También es escuchar activamente, articular esfuerzos, trabajar por entornos de crecimiento para todos, e impulsar acciones que generen desarrollo. Me voy con este reconocimiento y con el compromiso de seguir trabajando por un país más justo y sostenible”, manifestó Juan Carlos.

##### Organizaciones de impacto

###### Alianza Team

###### Ecosistema de Innovación y transformación Alianza Team

**Categoría: Ciencia y tecnología**

Se trata de un ecosistema vivo de innovación y transformación, donde la ciencia y la tecnología actúan como palancas transversales en tres dimensiones que operan en paralelo: gente y cultura; eficiencias tecnológicas; y valor para los clientes-alianzas. Esta arquitectura integrada convierte ideas en valor medible, sostenible y escalable, asegurando continuidad en el tiempo y capacidad de adaptación frente a los cambios del sector.

“En Alianza Team celebramos este reconocimiento porque la inspiración es parte de la innovación, y la innovación está en nuestro ADN, es como actuamos y conversamos con la sociedad”, expresó Cristhel Hiller, corporate innovation manager.

###### Postobón

###### Innovación para la movilidad sostenible

**Categoría: Sostenibilidad y cambio climático**

Este proyecto se distingue por su carácter pionero y su enfoque integral en la transformación del transporte de carga hacia modelos más sostenibles, combinando innovación tecnológica, eficiencia operativa y gestión inteligente del talento humano. El proyecto también se destaca por su uso de analítica avanzada, digitalización de la operación logística y la incorporación de un componente de innovación abierta con el desarrollo de un prototipo del proyecto Kratos (en alianza con EAFIT), demostrando el potencial de la colaboración entre empresa y academia para crear soluciones sostenibles de última milla.

“Cuando en Postobón nos preguntamos cómo inspirar y dejar un legado, el primer tema que se nos viene a la cabeza es la sostenibilidad y el cambio climático Es una de nuestras prioridades y así lo entendemos los más de 12.000 empleados que hacemos parte de esta organización. Recibir este reconocimiento, en esta categoría, es una muestra de que estamos haciendo las cosas bien”, señaló Santiago Giraldo Gómez, director de Transporte Primario de Postobón.

###### Cementos Argos

###### Hogares Saludables

**Categoría: Cuidado y bienestar**

Hogares Saludables integra de manera única mejoramiento físico de la vivienda, formación en construcción básica y acompañamiento social, generando un modelo de intervención integral y sostenible que no solo entrega soluciones físicas, sino que empodera a las familias para seguir transformando sus hogares y comunidades. Su impacto se refleja en la salud, el bienestar integral y la dignidad, al mismo tiempo que contribuye a reducir el déficit cualitativo de vivienda y deja en los territorios capacidad instalada y tejido social, esperando que los aprendizajes y logros permanezcan y se multipliquen en el tiempo.

> “En el mundo hay dos billones de personas sin acceso a vivienda digna y en Colombia son cinco millones de familias. En Cementos Argos estamos tratando de cambiar eso, de ser parte de la solución, y este proyecto le apuesta a eso, a ser una semilla que comience a transformar realidades. En ese camino hemos logrado beneficiar a 10.000 familias”, señaló Juan Esteban Calle, presidente de Cementos Argos, al recibir el reconocimiento.

###### Fundación Bancolombia

###### Sistemas Rurales Emergentes (SRE)

**Categoría: Cultura, ciudadanía e inclusión**

Los SRE son un modelo territorial que combina educación financiera de la Fundación con el sistema financiero, apalancados en Bancolombia y Nequi. A través de un ciclo de inclusión financiera se busca desarrollar soluciones con las comunidades rurales del país para enfrentar la exclusión y promover bienestar multidimensional apalancados en el acceso y manejo adecuado de los recursos, y permitiendo que las personas accedan a herramientas tradicionalmente negadas como créditos, tarjetas de crédito, seguros, inversiones, entre otros.

> “Los sistemas financieros rurales tienen unas realidades muy diferentes a la nuestra. El liderazgo allí emerge desde las mismas comunidades campesinas, en quienes hemos visto un verdadero ejemplo de liderazgo. Ha valido cada minuto de este proyecto porque sabemos que estamos trabajando juntos por disminuir la exclusión financiera”, comentó María Camila Osorio, directora ejecutiva de la Fundación Bancolombia.

###### Alianza ERA- Fundación Secretos para Contar

###### La U en el campo

**Categoría: Innovación educativa y futuros del trabajo**

La U en el Campo se da en la tercera etapa del programa ERA, posterior a la implementación de pedagogías activas desde el nivel preescolar a la media, y transforma las dinámicas educativas rurales al llevar programas técnicos y tecnológicos directamente a las instituciones educativas rurales. El programa integra educación media y superior en un mismo espacio formativo; responde a necesidades productivas y vocacionales de los territorios rurales; prepara a los jóvenes para el mundo laboral con pertinencia, evitando desplazamientos y reduciendo la deserción; y utiliza mecanismos de acompañamiento integral (bienestar, liderazgo estudiantil, pedagogías activas) que fortalecen competencias técnicas y socioemocionales.

> “Hoy como líderes inspiradores queremos resaltar a quienes nos inspiran, que son los habitantes del campo. Personas que, a diferencia de los de la ciudad, no siempre encuentran la manera o los mecanismos para acceder a la educación superior. Con nuestro proyecto estamos tratando de cambiar eso y, hasta el momento, lo hemos logrado con más de 2.140 jóvenes. Eso es lo que más nos llena de Orgullo hoy”, apuntó Vanessa Escobar, directora de educación en la Fundación Secretos para Contar.

#### Historias y noticias recomendadas

![Image 22: Imagen En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg?crop=yes&k=c&w=823&h=450&itok=2I2kS4Ud)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)
###### En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones

Una red de agua helada con pérdidas de eficiencia, una selladora industrial que requería mejorar su confiabilidad, sistemas energéticos con alto consumo y procesos que podían automatizarse: esos son algunos de los retos de empresas del sector productivo que cruzaron la puerta del aula y que hoy cuentan con propuestas desarrolladas por estudiantes de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "Leer más")

Mayo 7, 2026

![Image 23: Imagen Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://universidadeafit.widen.net/content/c5dd5394-7a1b-46bc-93d4-e01ffbbe080a/web/Patente-caminador.png?crop=yes&k=c&w=823&h=450&itok=elgTvZ7o)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano

La movilidad es uno de los factores que más influye en la autonomía y la calidad de vida de las personas, especialmente en quienes enfrentan procesos de rehabilitación o dificultades para caminar.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado "Leer más")

Abril 30, 2026

![Image 24: Imagen EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://universidadeafit.widen.net/content/9e97e1f2-ee3f-46aa-a923-d0b06278bd58/web/campus-vivo-1500.jpg?crop=yes&k=c&w=823&h=450&itok=ET4zIEwS)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología

La Plazoleta del Estudiante se transformó este miércoles 22 de abril en un espacio de experimentación y conexión con la _Muestra de iniciativas inspiradoras de aprendizaje experiencial_. Prototipos en impresión 3D, simuladores, juegos interactivos y modelos matemáticos se encontraron en una misma escena para dejar a un lado la teoría abstracta y permitir que estudiantes, profesores y colaboradores activaran los sentidos alrededor de diferentes proyectos.

[Leer más](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y "Leer más")

Abril 23, 2026

[Ver todas las historias y noticias](https://www.eafit.edu.co/noticias)

##### Nuestros programas

[Conoce los pregrados](https://www.eafit.edu.co/pregrados)[Conoce los posgrados](https://www.eafit.edu.co/posgrados)

_**Última actualización**_

Noviembre 6, 2025

![Image 25: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 26: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 27: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 28: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 29: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 30: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 31: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 32: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 35](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
