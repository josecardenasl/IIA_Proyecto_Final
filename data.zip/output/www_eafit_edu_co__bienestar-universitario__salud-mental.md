Title: ¡Cuidémonos!

URL Source: https://www.eafit.edu.co/bienestar-universitario/salud-mental

Markdown Content:
# ¡Cuidémonos! - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/bienestar-universitario/salud-mental#main-content)

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 6: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/salud-mental#)

[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/salud-mental# "Spanish")[![Image 9: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/bienestar-universitario/salud-mental# "English")

 Información para ti

[![Image 10: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 11: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 12: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 13: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 14: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 15: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 17: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 18: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 19: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 20: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 21: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 22: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 23: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 24: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 25: Imagen de banner experiencia integral transformadora ](https://universidadeafit.widen.net/content/3f841156-aed9-4712-9cb8-fbac074a1d41/web/saludmentalestudiantes2.jpg?crop=yes&k=c&w=1920&h=788&itok=smj7z6F4)

# ¡Cuidémonos!

*   [Inicio](https://www.eafit.edu.co/)
*   [Bienestar Universitario](https://www.eafit.edu.co/bienestar-universitario)
*    ¡Cuidémonos! 

### Si necesitas ayuda psicológica, comunícate con:

En la U

![Image 26: Imagen Línea Calma, atención 24/7 para estudiantes](https://universidadeafit.widen.net/content/29795122-d59f-40a4-bc9f-8edb97bd0eac/web/l%C3%ADnea-empleados.jpg?crop=yes&k=c&w=397&h=253&itok=a4gH3lof)

Línea Calma, atención 24/7 para estudiantes

Asesoría en salud mental y violencia basada en​​​ género.

 018000521021

[Comunícate al 3166011106](https://api.whatsapp.com/send?phone=573166011106)

![Image 27: Imagen Línea 24/7 de ARL Sura para empleados](https://universidadeafit.widen.net/content/4a02ce9a-a974-445a-b55a-6ab406d4679e/web/saludmentalimagenbanner.jpg?crop=yes&k=c&w=397&h=253&itok=mUZehbOb)

Línea 24/7 de ARL Sura para empleados

Linea telefónica nacional 018000 511 414 opción 1- opción 4

[Llamanos al 3152767888](https://api.whatsapp.com/send?phone=573152767888)

![Image 28: Imagen Directorio de convenios de servicios en salud mental](https://universidadeafit.widen.net/content/61931a3f-d59e-486a-bb49-edefa3887a83/web/Bloque%2018%203.jpg?crop=yes&k=c&w=397&h=253&itok=A552xcHh)

Directorio de convenios de servicios en salud mental

[Conócelo aquí](https://universidadeafit.widen.net/s/qlwgglqtr5/directorio-de-aliados-salud-mental)

![Image 29: Imagen ¿Necesitas ayuda?](https://universidadeafit.widen.net/content/f9115661-2fe5-40fd-8b7e-d57db5ebfe45/web/abrohilo-imagen1.jpg?crop=yes&k=c&w=397&h=253&itok=-k4R5E9R)

¿Necesitas ayuda?

Canal de atención para citas psicológicas para estudiantes y empleados.

[Leer más](https://www.eafit.edu.co/necesitas-ayuda)

![Image 30: Imagen de estudiatnes](https://universidadeafit.widen.net/content/521d9716-15be-4773-8014-229d77bea7ca/web/iduccion-pregrado-00918.jpg?w=480&itok=h36vE5kF)

## Bienestar Universitario

​​​​​​​​​​​La filosofía ​​de Bienestar Universitario

 La Dirección de Desarrollo Humano y Bienestar pretende hacer del bienestar un valor individual y colectivo en la comunidad eafitense. Desde la conciencia del mutuo cuidado, con base en los valores institucionales invita a que la vida sea un vivir bien. Que las acciones sean una oportunidad para el recto actuar en un ambiente solidario y respetuoso de la diversidad y del entorno.

[Conoce más](https://www.eafit.edu.co/bienestar-universitario)

![Image 31: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

### Notas sobre Salud Mental

### Cuidar la mente también es cuidar la vida

[Ver video de instagram](https://www.instagram.com/p/DPoV2XbDW3K/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==)

### Pequeños cambios por tu salud mental

[Ver video de instagram](https://www.instagram.com/reel/DPoS3q-jz4l/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==)

### Sostener y ciudad la vida es un acto cotidiano

[Ver video de instagram](https://www.instagram.com/reel/DOb9LJiCpBS/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==)

### Cuando lo normal deja de ser “normal”

[Ver video de instagram](https://www.instagram.com/p/DNTO7_nthfl/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==)

### ¿Te cuesta concentrarte o descansar bien?

[Ver video de instagram](https://www.instagram.com/p/DM-hQw6Rnxo/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==)

### ¿Y si la vida no es solo una carrera?

[Ver video de instagram](https://www.instagram.com/p/DO_gfboDxvR/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==)

#### Este primero de octubre tenemos una invitación a conversar sobre salud mental y productividad

#### Fuera del consultorio: estos son los profesionales que cuidan nuestra salud mental en la U

#### ¿Qué nos mueve?

#### Movernos por los sueños y metas

#### ¿Qué pasa en nuestros cuerpos cuando dejamos de fumar o vapear?

### Rutas

## Ruta de atención para el manejo de crisis emocionales

[Conoce la ruta](https://universidadeafit.widen.net/s/mkzvrsj6xt/ruta-de-atencion-alteracion-emocional)

## Ruta de atención para personas con conducta suicida​​​​​​

[Conoce la ruta](https://universidadeafit.widen.net/s/krs2sw8dgn/ruta-de-atencion-riesgo-conducta-suicida)

![Image 32: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

### Educación emocional

##### Ciclo de conversaciones

#### Haz una pausa: hablemos de salud mental

#### Apoyos en salud mental, ¿qué debemos saber?

#### Profe, estoy en crisis - Hablemos sobre la promoción de la seguridad, la calma y las redes de apoyo

#### Con-sumo-cuidado

#### Salud mental y formas del lazo social

#### ¿Cómo inciden los imperativos de la época en nuestra salud mental?

#### Campus Global: ¿Pueden las redes sociales afectar la construcción de identidad la comprensión del mundo y el aprendizaje?

#### La confianza en la época de la inteligencia artificial

#### Suicidio: riesgo, estigma y prevención

#### En la U también hablamos de ansiedad

## Guías de Salud Mental

### Gestión emocional

[Conoce la guia](https://universidadeafit.widen.net/s/qkjzjbtcpv/guia-de-gestion-emocional)

### Un camino para afrontar las adversidades

[Conoce la guia](https://universidadeafit.widen.net/s/hkdvvdfbgc/camino-para-afrontar-las-adversidades)

### ¿Sabes manejar el duelo?

[Conoce la guia](https://universidadeafit.widen.net/s/rcffzkgsjm/guia-proceso-de-duelo)

### Primeros Auxilios Psicológicos para profesores y empleados

[Conoce la guia](https://universidadeafit.widen.net/s/djcrzlq5hs/guia-primeros-auxilios-psicologicos)

### Gestionar tu tiempo y concentrarte

[Conoce la guia](https://universidadeafit.widen.net/s/nlw2tlgfpf/guia-para-gestionar-el-tiempo)

### Orientación para estudiantes foráneos

[Conoce la guia](https://universidadeafit.widen.net/s/lrh7sjmzms/guia-de-apoyo-para-estudiantes-)

[![Image 33: Banner de franja](https://universidadeafit.widen.net/content/0860355f-632f-47a7-bbe7-dd38de20f167/web/estudiandoenlabiblio-bannerpeque-2026.jpg)](https://www.eafit.edu.co/bienestar-universitario/salud-mental)

![Image 34](https://www.eafit.edu.co/bienestar-universitario/salud-mental)

### III Concurso de Microcuento

#### ExpresARTE: Elogio a lo simple

Las palabras permiten expresar lo que sentimos y pensamos sobre aquello que vivimos, son un recurso a través del cual podemos encontrarnos con lo más íntimo de nosotros y conectar con algo de la intimidad del otro. Las palabras son refugio, son camino, son encuentro. Las palabras dan vida, tienen efecto en quien las escucha, las lee, las da y las recibe.

En la prisa de la sociedad actual parece que queda poco espacio para detenerse y contemplar, los días inician con premura y los propósitos cada vez son más robustos. Las exigencias de rendimiento, producción, consumo y éxito piden ir a toda velocidad, parecemos absortos en el ruido incesante de un mundo que no deja de acelerar, de demandar, de complejizar lo simple, vivir.

Bajo este panorama y siendo la palabra un recurso primordial para la vida humana, extendemos la invitación a todos los miembros de la Comunidad Universitaria a participar de la Tercera Edición del Concurso de Microcuento ExpresArte: elogio a lo simple. Para que por medio de la escritura elogiemos lo simple de la vida, esas cosas que por su sutileza conmueven, serenan o nos hacen sentir vivos

## Microcuentos Ganadores del Tercer Concurso de Microcuento:

[Primer lugar](https://www.eafit.edu.co/bienestar-universitario/salud-mental#4257225834-4114969241)

Primer lugar

###### **Primer Lugar**

###### Soplando la Espuma

**Autora: Victoria Eugenia Giraldo Henao**

Crecí aprendiendo a leer el silencio. Cuando mi padre alzaba la voz y cerraba la puerta con fuerza, mi hermano y yo sabíamos que había que guardar los cuadernos y contener la respiración. Mi madre, siempre de pie, parecía más frágil que la loza que temblaba en la cocina.

Nos mudamos tantas veces que dejé de desempacar del todo. En cada ciudad aprendí algo distinto: a no hacer ruido, a proteger a mis hermanas, a mirar al suelo.

Pero también aprendí otra cosa.

Una noche, después de una discusión interminable, mi madre nos sirvió chocolate caliente. Afuera el mundo seguía siendo un grito; en la mesa, éramos mi madre y cuatro hermanos soplando la espuma. Nadie habló de lo que había pasado. Solo partimos el pan y lo compartimos.

Con el tiempo entendí que no era el chocolate ni el pan. Era mi madre quien, en medio del miedo, nos regalaba un momento de calma…

[Segundo lugar](https://www.eafit.edu.co/bienestar-universitario/salud-mental#4257225834-735251406)

Segundo lugar

###### **Segundo lugar**

###### Canoa

**Autor: Valentín Vélez.**

Había llegado el día.

Después de la fiesta y el trasnocho, cuando el cielo todavía olía a ceniza y guarapo, con la salida del sol todos los hombres del pueblo entramos al bosque. Íbamos en fila, callados, como si el monte nos estuviera escuchando. El Caracolí me esperaba desde antes de que yo naciera: lo decía mi padre, lo repetían los viejos en la cantina, lo juraban las sombras largas al pie de su tronco. Era un árbol con memoria.

Entre todas las manos, talaríamos el árbol y llevaríamos su tronco corriente abajo. El filo mordía la madera y cada golpe tenía algo de promesa y algo de despedida. La savia nos salpicó como si el bosque también sangrara. Nadie hablaba, pero todos entendíamos: era una ceremonia.

En la desembocadura nos esperaba el pueblo, pequeño, pero nuestro, con las mujeres reunidas como un círculo de agua quieta, listas para bendecir lo que se desprendía del monte y se volvía camino.

Ahora yo tenía 18 años.

Ahora tendría mi propia canoa.

Un tronco tallado por todos los hombres y bendecido por todas las mujeres.

Ahora soy un pescador.

[Tercer lugar](https://www.eafit.edu.co/bienestar-universitario/salud-mental#4257225834-775409951)

Tercer lugar

###### **Tercer Lugar**

Viaje en la Máquina del Tiempo

**Autora: Luz María Garcés Flórez.**

¡Qué aguacero! La lluvia forma cortinas blancas que se mueven impulsadas por las ráfagas de viento. ¡Sssssssss! Me envuelve ese sonido sibilante, que cambia de tono e intensidad, mezclado con el chocar de las gotas contra el pavimento. Los carros dejan de circular. Estoy de pie, en el andén. Trato de evitar que el agua me moje. ¡Sssssssss! Veo una niña que está parada en la calle, a dos metros de mí, junto al andén. En su cabeza recibe un chorro continuo y ruidoso, que cae a borbotones, proveniente de una canoa que desagua un techo alto, cubierto de tejas. Una joven está tras de ella, pero conserva la distancia. Se protege bajo el alero y trata de evitar el contacto con el agua. Le chilla, suplicante: “Negrita, no se moje que doña Rocío me va a regañar.” La niña está empapada. Le escurre agua por todas partes. Levanta los brazos, brinca, se ríe y da vueltas como una bailarina, en el mismo punto, sin salirse del chorro. La veo. Me veo. En mi mente, le digo: “Negrita, mójese. Tranquila que doña Rocío no va a regañar a nadie.”

![Image 35: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 36: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 37: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 38: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 39: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 40: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 41: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 42: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 43](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
