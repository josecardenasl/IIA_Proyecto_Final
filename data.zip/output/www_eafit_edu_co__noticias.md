Title: Noticias

URL Source: https://www.eafit.edu.co/noticias

Markdown Content:
# Noticias - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/noticias#main-content)

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias#)

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias# "Spanish")[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias# "English")

 Información para ti

[![Image 9: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 10: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 11: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 12: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 13: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 14: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 15: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 16: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 17: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 18: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 19: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 20: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 21: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 22: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 23: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

# Historias y noticias

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

## En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones

Una red de agua helada con pérdidas de eficiencia, una selladora industrial que requería mejorar su confiabilidad, sistemas energéticos con alto consumo y procesos que podían automatizarse: esos son algunos de los retos de empresas del sector productivo que cruzaron la puerta del aula y que hoy c

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "Ver noticia")

Mayo 7, 2026

![Image 24: Imagen En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg?crop=yes&k=c&w=944&h=540&itok=qU5B_bcT)

*   [Inicio](https://www.eafit.edu.co/)
*    Noticias 

Desplegar menú
*   [Lo que está pasando](https://www.eafit.edu.co/noticias "Ancla menú")
*   [Nuestra comunidad de talento](https://www.eafit.edu.co/noticias "Ancla menú")
*   [Especiales](https://www.eafit.edu.co/noticias "Ancla menú")
*   [Nuestro impacto](https://www.eafit.edu.co/noticias "Ancla menú")
*   [EAFIT es noticia](https://www.eafit.edu.co/noticias "Ancla menú")
*   [Publicaciones](https://www.eafit.edu.co/noticias "Ancla menú")

### **Lo que está pasando**

Estas son las noticias acerca de la actualidad, los logros y las iniciativas de incidencia de EAFIT a través de su comunidad. Una selección de la información relacionada con los eventos en los que participa y organiza la Universidad, su posición en ránquines académicos, sus logros institucionales, las novedades académicas, el relacionamiento y las actividades culturales.

![Image 25: Imagen La Editorial EAFIT llevará su catálogo a la Filbo 2026](https://universidadeafit.widen.net/content/06775a08-60ca-4910-be81-9ede92d51066/web/Catalogo-la-Filbo2026.jpg?crop=yes&k=c&w=427&h=464&itok=-EdA7qmB)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)
###### La Editorial EAFIT llevará su catálogo a la Filbo 2026

La Feria Internacional del Libro de Bogotá (Filbo) es el escenario para el encuentro entre lectores, autores, editores, bibliotecas y distribuidores. En su edición de 2026, que se llevará a cabo entre el 21 de abril y el 4 de mayo, la Editorial EAFIT fortalecerá su proyección comercial y académica, así como el relacionamiento con actores clave del sector editorial universitario y cultural.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/la-editorial-eafit-llevara-su-catalogo-la-filbo-2026 "Leer más")

Abril 22, 2026

![Image 26: Imagen EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario](https://universidadeafit.widen.net/content/7560b375-a4ab-4d45-adb8-1b969563953a/web/premio-literario-1500.jpg?crop=yes&k=c&w=427&h=464&itok=1Meaql9E)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)
###### EAFIT y la Alcaldía de Medellín tienen abierta la convocatoria para la sexta edición del Premio León de Greiff al Mérito Literario

[**Las postulaciones deberán ser presentadas**](https://eafit.qualtrics.com/jfe/form/SV_8igZh8GDU9E16rs) por entidades culturales, editoriales públicas o privadas, de Colombia o del exterior que mantengan vínculo con el país, hasta el lunes 25 de mayo.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-y-la-alcaldia-de-medellin-tienen-abierta-la-convocatoria-para-la "Leer más")

Abril 21, 2026

![Image 27: Imagen Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://universidadeafit.widen.net/content/1e26403e-34ad-44fd-98d4-b1ff716a698f/web/Nueva-fase-energia.jpg?crop=yes&k=c&w=427&h=464&itok=aqxiQGn0)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar

En un momento en que el sistema energético atraviesa cambios profundos y acelerados, el sector se reunió el pasado 16 de abril en la Cámara de Comercio de Medellín para mirar hacia adelante.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando-publicaciones/nueva-fase-para-la-energia-en-america-latina-ya-no-se "Leer más")

Abril 20, 2026

![Image 28: Imagen Recorrer la cancha, la tribuna y la calle es la invitación de la nueva exposición de EAFIT](https://universidadeafit.widen.net/content/94c78b4d-8131-4055-b050-34f6b0d6954a/web/Recorrer-cancha.jpg?crop=yes&k=c&w=427&h=464&itok=9s6eUHr1)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)
###### Recorrer la cancha, la tribuna y la calle es la invitación de la nueva exposición de EAFIT

Puede que un partido de fútbol dure noventa minutos, pero las historias que deja pueden permanecer durante décadas. Más que un deporte, el fútbol es un fenómeno cultural capaz de atravesar la vida cotidiana y de instalarse en la memoria colectiva.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/recorrer-la-cancha-la-tribuna-y-la-calle-es-la-invitacion-de-la-nueva "Leer más")

Abril 15, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/lo-que-esta-pasando)

### **Nuestra comunidad de talento**

Las historias de vida y logros que alcanzan las personas que integran la comunidad eafitense, de manera individual o colectiva, en asuntos relacionados con la academia, la investigación y la proyección social. Son los éxitos que cosechan estudiantes, profesores, directivos, graduados, semilleros, grupos de investigación, entre otros.

![Image 29: Imagen EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://universidadeafit.widen.net/content/9e97e1f2-ee3f-46aa-a923-d0b06278bd58/web/campus-vivo-1500.jpg?crop=yes&k=c&w=823&h=450&itok=ET4zIEwS)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología

La Plazoleta del Estudiante se transformó este miércoles 22 de abril en un espacio de experimentación y conexión con la _Muestra de iniciativas inspiradoras de aprendizaje experiencial_. Prototipos en impresión 3D, simuladores, juegos interactivos y modelos matemáticos se encontraron en una misma escena para dejar a un lado la teoría abstracta y permitir que estudiantes, profesores y colaboradores activaran los sentidos alrededor de diferentes proyectos.

[Leer más](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y "Leer más")

Abril 23, 2026

![Image 30: Imagen Soñar: una capacidad necesaria en el emprendimiento](https://universidadeafit.widen.net/content/9aedf98a-a7a1-479d-8c86-7a402b97568e/web/imagen-de-graduado-julian-oquendo.jpg?crop=yes&k=c&w=823&h=450&itok=r0pUl1AV)

[Emprendimiento](https://www.eafit.edu.co/taxonomy/term/1851)
###### Soñar: una capacidad necesaria en el emprendimiento

[Leer más](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/sonar-una-capacidad-necesaria-en-el-emprendimiento "Leer más")

Abril 7, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento)

### **Especiales**

Algunos fenómenos, eventos o temáticas requieren que se aborden desde diferentes perspectivas, visiones y formatos divulgativos. En esta sección encuentras contenidos escritos y audiovisuales que se crean alrededor de un solo tema para enriquecer y proponer nuevas visiones. Son, por ejemplo, efemérides, temas de tendencia o divulgación científica.

![Image 31: Imagen La universidad que se atrevió a imaginar diferente](https://universidadeafit.widen.net/content/ec97e97d-0209-4d5d-9816-e861c57b5112/web/columna-de-tomas-rios-ongoin-abril7.jpg?crop=yes&k=c&w=944&h=540&itok=vAloCGd4)

[Emprendimiento](https://www.eafit.edu.co/taxonomy/term/1851)

###### La universidad que se atrevió a imaginar diferente

Hace unos años, un grupo de graduados emprendedores se reunió con las directivas de la Universidad EAFIT, liderado por la rectora Claudia Restrepo, con una preocupación compartida: el ecosistema emprendedor se había desconectado de la Universidad y sus posibilidades. Había ganas, energía, talento, pero faltaba articulación.

[Leer más](https://www.eafit.edu.co/noticias/especiales/la-universidad-que-se-atrevio-imaginar-diferente "Leer más")

Abril 7, 2026

![Image 32: Imagen Encuentros improbables que tejen hilos de confianza: así avanza la Tejeduría Territorial](https://universidadeafit.widen.net/content/d0aec917-ddde-4041-bc13-41597abf081f/web/Tejeduria-comuna10.jpg?crop=yes&k=c&w=944&h=540&itok=FeypyJ8A)

[Sociedad y democracia](https://www.eafit.edu.co/taxonomy/term/1831)

###### Encuentros improbables que tejen hilos de confianza: así avanza la Tejeduría Territorial

Conversar y tejer tienen mucho en común. En ambos actos se requiere paciencia, atención y la disposición de entrelazar hilos distintos para crear algo nuevo. Con esa convicción nació la Tejeduría Territorial, una iniciativa que, desde 2021, promueve encuentros improbables entre líderes territoriales, organizaciones sociales, empresarios, y académicos, con el propósito de construir confianza a partir de la palabra y la acción colectiva.

[Leer más](https://www.eafit.edu.co/noticias/especiales/encuentros-improbables-que-tejen-hilos-de-confianza-asi-avanza-la-tejeduria "Leer más")

Marzo 16, 2026

![Image 33: Imagen Las empresas ya no buscan ejecutores, sino estrategas con habilidades tecnológicas ](https://universidadeafit.widen.net/content/78b08b95-ef6d-42c6-bc09-edb600433d51/web/las-empresas-ya-no-buscan-ejecutores.jpg?crop=yes&k=c&w=944&h=540&itok=xZIik7qz)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

###### Las empresas ya no buscan ejecutores, sino estrategas con habilidades tecnológicas

Reclutadores y líderes empresariales coinciden en una misma idea: el talento que hoy se necesita es distinto. El mercado laboral en Colombia y la región atraviesa una transformación acelerada, impulsada por la integración de nuevas tecnologías y un cambio en las expectativas tanto de empresas como de trabajadores.

[Leer más](https://www.eafit.edu.co/noticias/especiales/las-empresas-ya-no-buscan-ejecutores-sino-estrategas-con-habilidades "Leer más")

Marzo 10, 2026

![Image 34: Imagen En época de elecciones, ¿cómo analizar un debate para votar con criterio?](https://universidadeafit.widen.net/content/5f35e878-711e-47c1-ac3d-d204d0c3cca7/web/Debates-EAFIT.jpg?crop=yes&k=c&w=944&h=540&itok=8DJIkVVg)

[Sociedad y democracia](https://www.eafit.edu.co/taxonomy/term/1831)

###### En época de elecciones, ¿cómo analizar un debate para votar con criterio?

Los debates electorales vuelven a ocupar un lugar importante en la agenda pública. Se comentan en familia, se difunden fragmentados en redes sociales y se discuten en medios y grupos de chat. Entre gestos, frases contundentes y momentos virales, estos encuentros suelen presentarse como un pulso entre candidatos, más que como un espacio para contrastar ideas.

[Leer más](https://www.eafit.edu.co/noticias/especiales/en-epoca-de-elecciones-como-analizar-un-debate-para-votar-con-criterio "Leer más")

Febrero 17, 2026

## Sala de prensa

Te invitamos a nuestra Sala de prensa si te dedicas al periodismo o la comunicación y necesitas fuentes de información, contactos de personas expertas, fotografías, videos, audios y textos de la Universidad asociados a los proyectos y eventos en los que la Institución participa u organiza, para crear contenidos para medios.

[Conoce más](https://www.eafit.edu.co/noticias/sala-de-prensa)

![Image 35: Imagen Sala de prensa](https://universidadeafit.widen.net/content/9fc15555-fb1e-4e19-a258-b46db2574036/web/Pregrado-comunicacion-social-9.jpg)

### **Nuestro impacto**

Las investigaciones, los proyectos y las iniciativas institucionales que generan impacto en el entorno también son historias para contar. Esta es la evidencia de cómo la Universidad afronta con preguntas los desafíos más apremiantes de la sociedad para ofrecer respuestas y soluciones.

![Image 36: Imagen En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg?crop=yes&k=c&w=409&h=193&itok=kVwbe0UQ)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

###### En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "Ver noticia")

Mayo 7, 2026

![Image 37: Imagen Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://universidadeafit.widen.net/content/c5dd5394-7a1b-46bc-93d4-e01ffbbe080a/web/Patente-caminador.png?crop=yes&k=c&w=409&h=193&itok=N3zWjM7U)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

###### Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado "Ver noticia")

Abril 30, 2026

![Image 38: Imagen ¡Nace Energy Valley! Un centro que impulsará la innovación y el talento en el sector energético de Colombia](https://universidadeafit.widen.net/content/19af2040-a199-422b-b134-a4b03a5b0c77/web/EnergyValley-1500.jpg?crop=yes&k=c&w=409&h=193&itok=PR67ZSPn)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

###### ¡Nace Energy Valley! Un centro que impulsará la innovación y el talento en el sector energético de Colombia

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/nace-energy-valley-un-centro-que-impulsara-la-innovacion-y-el-talento-en "Ver noticia")

Abril 17, 2026

![Image 39: Imagen Simens Energy implementará en Estados Unidos un aislador sísmico desarrollado en alianza con EAFIT](https://universidadeafit.widen.net/content/3301aa23-0d65-4f97-aed3-d1165112fe7d/web/SimensEnergy-1500.jpg?crop=yes&k=c&w=409&h=193&itok=RtqGXsWH)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)

###### Simens Energy implementará en Estados Unidos un aislador sísmico desarrollado en alianza con EAFIT

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/simens-energy-implementara-en-estados-unidos-un-aislador-sismico "Ver noticia")

Abril 9, 2026

![Image 40: Imagen Así se están formando los emprendedores eafitenses](https://universidadeafit.widen.net/content/b02f3799-03a8-423c-b1e2-2489a8ad0c85/web/articulo-talento-abril7.jpg?crop=yes&k=c&w=409&h=193&itok=oXigue-P)

[Emprendimiento](https://www.eafit.edu.co/taxonomy/term/1851)

###### Así se están formando los emprendedores eafitenses

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/asi-se-estan-formando-los-emprendedores-eafitenses "Ver noticia")

Abril 7, 2026

![Image 41: Imagen EAFIT acompaña conflictos socioambientales con su Clínica Jurídica de Participación Ambiental](https://universidadeafit.widen.net/content/59292436-06c1-49a6-a285-d70686b6baaa/web/Clinica_jur%7Bidica_Suroeste.jpeg?crop=yes&k=c&w=409&h=193&itok=Se5Fp_91)

[Medioambiente y cambio climático](https://www.eafit.edu.co/taxonomy/term/1816)

###### EAFIT acompaña conflictos socioambientales con su Clínica Jurídica de Participación Ambiental

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-acompana-conflictos-socioambientales-con-su-clinica-juridica-de "Ver noticia")

Abril 7, 2026

![Image 42: Imagen EAFIT fortalece su posicionamiento global: pasa de tres a siete áreas en el QS by Subject 2026](https://universidadeafit.widen.net/content/8f9c463e-3320-4279-950b-32f95dea181f/web/QS-by-Subjects2026.jpg?crop=yes&k=c&w=409&h=193&itok=31MBxLIr)

[Institucional](https://www.eafit.edu.co/taxonomy/term/1846)

###### EAFIT fortalece su posicionamiento global: pasa de tres a siete áreas en el QS by Subject 2026

[Ver noticia](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-fortalece-su-posicionamiento-global-pasa-de-tres-siete-areas-en-el "Ver noticia")

Marzo 27, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/nuestro-impacto)

### **EAFIT es noticia**

Colección de enlaces y contenidos destacados de las noticias relacionadas con la Universidad que los medios de comunicación publican o amplifican en sus audiencias. Esta es nuestra forma de valorar la labor que cumplen los medios para conectar a EAFIT con sus grupos de interés.

![Image 43: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=409&h=193&itok=JkRzgs7h)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/debate-global-con-sello-estudiantil "Ver noticia")

Abril 7, 2026

![Image 44: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=409&h=193&itok=NgUwJ00O)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/de-una-inspiracion-la-competencia-internacional "Ver noticia")

Marzo 16, 2026

![Image 45: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=409&h=193&itok=Y_JcZf72)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/noticias/eafit-es-noticia/un-laboratorio-vivo-para-aprender-haciendo "Ver noticia")

Marzo 12, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/eafit-es-noticia)

### **Publicaciones**

Colección de enlaces y contenidos destacados de las noticias relacionadas con la Universidad que los medios de comunicación publican o amplifican en sus audiencias. Esta es nuestra forma de valorar la labor que cumplen los medios para conectar a EAFIT con sus grupos de interés.

![Image 46: Imagen Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar](https://universidadeafit.widen.net/content/1e26403e-34ad-44fd-98d4-b1ff716a698f/web/Nueva-fase-energia.jpg?crop=yes&k=c&w=292&h=306&itok=hzGyIDP_)

## Nueva fase para la energía en América Latina: ya no se trata de generar, sino de gobernar

Abril 20, 2026

[Ver publicación](https://www.eafit.edu.co/noticias/lo-que-esta-pasando-publicaciones/nueva-fase-para-la-energia-en-america-latina-ya-no-se "Ver publicación")

![Image 47: Imagen Hacia dónde va el mercado laboral ](https://universidadeafit.widen.net/content/04ac971f-154b-402b-ac37-2743654aa525/web/MariaA-1500.jpg?crop=yes&k=c&w=292&h=306&itok=SN5sEOko)

## Hacia dónde va el mercado laboral

Marzo 10, 2026

[Ver publicación](https://www.eafit.edu.co/noticias/publicaciones/hacia-donde-va-el-mercado-laboral "Ver publicación")

![Image 48: Imagen Colombia crece, pero debe fortalecer la inversión para sostener el ritmo](https://universidadeafit.widen.net/content/bfd7c3f3-47a5-4179-b055-a318f66650bf/web/Perspectivas%20Economicas%20-47.jpg?crop=yes&k=c&w=292&h=306&itok=u38IvBHf)

## Colombia crece, pero debe fortalecer la inversión para sostener el ritmo

Octubre 31, 2025

[Ver publicación](https://www.eafit.edu.co/noticias/eafit-es-noticia-publicaciones/colombia-crece-pero-debe-fortalecer-la-inversion-para "Ver publicación")

![Image 49: Imagen Resultados de la Mesa de Empleo de Antioquia indican que la generación de empleo está en auge](https://universidadeafit.widen.net/content/2aa1ebca-160e-4981-b55b-5594d99c3081/web/resultados-mesa-de-empleo.jpg?crop=yes&k=c&w=292&h=306&itok=YtLkt1Mv)

## Resultados de la Mesa de Empleo de Antioquia indican que la generación de empleo está en auge

Julio 22, 2025

[Ver publicación](https://www.eafit.edu.co/noticias/eafit-es-noticia-publicaciones/resultados-de-la-mesa-de-empleo-de-antioquia-indican-que-la "Ver publicación")

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/publicaciones)

![Image 50: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 51: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 52: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 53: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 54: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 55: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 56: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 57: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
