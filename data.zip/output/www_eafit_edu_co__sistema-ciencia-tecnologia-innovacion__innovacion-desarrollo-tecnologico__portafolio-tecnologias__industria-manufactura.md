Title: Industria y manufactura

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura

Markdown Content:
# Industria y manufactura - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura#main-content)

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 6: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura#)

[![Image 8: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura# "Spanish")[![Image 9: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura# "English")

 Información para ti

[![Image 10: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 11: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 12: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 13: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 14: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 15: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 17: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 18: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 19: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 20: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 21: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 22: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 23: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 24: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 25: Imagen de banner industria y manufactura](https://universidadeafit.widen.net/content/b89f75d3-257a-4c7c-b6a4-af1a7595d3c5/web/cofinanciados.png?crop=yes&k=c&w=1920&h=600&itok=0W42oHVN)

# Industria y manufactura

Soluciones tecnológicas que mejoran la eficiencia industrial, optimizando el uso de materias primas, innovando en procesos de producción y desarrollando nuevos materiales para diversas aplicaciones industriales.

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Innovación y Transferencia Tecnológica EAFIT](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
*   [Portafolio de Tecnologías](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias)
*    Industria y Manufactura 

Desplegar menú
*   [Portafolio de tecnologías](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias "Enlace menú")
*   [Agrotech](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/agrotech "Enlace menú")
*   [Healthtech](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/healthtech "Enlace menú")
*   [Medio ambiente y desarrollo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/medio-ambiente-desarrollo "Enlace menú")
*   [Software y servicios](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/software-servicios "Enlace menú")

#### **Tecnologías**

![Image 26: Imagen Membranas de nanofiltración](https://universidadeafit.widen.net/content/f2d10df6-4aa9-47f6-b71e-a1cddea5cb42/web/Banner-Bottom.jpg?crop=yes&k=c&w=397&h=253&itok=hYlkkkyZ)

Bottom

Creamos soluciones basadas en nanotecnología que transforman la industria.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/bottom)

![Image 27: Imagen Aislador sísmico para estructuras esbeltas](https://universidadeafit.widen.net/content/5c43a3f3-5de5-4fd2-8812-ecaf0e07e30f/web/aislador-sismico-para-subestaciones.jpg?crop=yes&k=c&w=397&h=253&itok=4JE3I8uN)

Aislador sísmico para estructuras esbeltas

Dispositivo de protección contra movimientos telúricos.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/aislador-sismico)

![Image 28: Imagen Arcillas industriales](https://universidadeafit.widen.net/content/cfadbf1b-db81-4c6b-a029-3e51cc3b00d2/web/Banners-Arcilla-Industrial.jpg?crop=yes&k=c&w=397&h=253&itok=lwW2xjgP)

Arcillas industriales

Diseño y modelado de productos de una forma versátil y a bajo costo.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/arcillas-industriales)

![Image 29: Imagen Asesoría técnica en proyección térmica](https://universidadeafit.widen.net/content/203b854f-e3b8-41a0-8542-ed8629faeab3/web/banner-proyeccion-termica.jpg?crop=yes&k=c&w=397&h=253&itok=i0LtcmQu)

Asesoría técnica en proyección térmica

Aprovecha las aplicaciones y beneficios de la proyección térmica con asesoría especializada de la Universidad EAFIT.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/proyeccion-termica)

![Image 30: Imagen ATTA](https://universidadeafit.widen.net/content/2aaa578e-3579-472d-a4ba-bec6498fbeff/web/BANNER-TRANSPORTE-PUBLICACION.jpg?crop=yes&k=c&w=397&h=253&itok=g44orfFZ)

ATTA

Dispositivo que facilita el transporte​ de elementos pesados y/o de​ gran longitud, disminuyendo el riesgo laboral.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/atta)

![Image 31: Imagen CelluGen](https://universidadeafit.widen.net/content/ec019916-c53f-4048-bb9c-13eb936cccc7/web/banner-cellugen.jpg?crop=yes&k=c&w=397&h=253&itok=84j-S2CM)

CelluGen

Innovación biotecnológica para un futuro sostenible.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/healthtech/cellugen)

![Image 32: Imagen Membranas de nanofiltración](https://universidadeafit.widen.net/content/f2d10df6-4aa9-47f6-b71e-a1cddea5cb42/web/Banner-Bottom.jpg?crop=yes&k=c&w=397&h=253&itok=hYlkkkyZ)

Membranas de nanofiltración

Sistemas de filtración de alta eficiencia.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/membranas-de-nanofiltracion)

![Image 33: Imagen Pick to light](https://universidadeafit.widen.net/content/eaba4d90-3abd-44ca-9d28-51431a271c89/web/banner-pick-to-light.jpg?crop=yes&k=c&w=397&h=253&itok=vdMYy0z7)

Pick to light

Asiste su proceso de picking e incrementa su productividad.

[Ver tecnología](node::38851)

![Image 34: Imagen Proceso de dispersión de nanopartículas](https://universidadeafit.widen.net/content/a3a43cef-7de7-4e37-9df6-dc13500bb34f/web/Banner-dispercion-interna.jpg?crop=yes&k=c&w=397&h=253&itok=9l6jo-6N)

Proceso de dispersión de nanopartículas

Telas con capacidades antibacteriales y autolimpiantes.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/proceso-de-dispersion-de-nanoparticulas)

![Image 35: Imagen Recubrimiento por plasma](https://universidadeafit.widen.net/content/282c249d-7de1-4556-afda-f0a8bf472847/web/banner-recubrimiento-plasma.jpg?crop=yes&k=c&w=397&h=253&itok=rUnxqE81)

Recubrimiento por plasma

Mejora de condiciones tribológicas de piezas y maquinaria en diferentes industrias.

[Ver tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/industria-manufactura/recubrimiento-por-plasma)

![Image 36: Imagen Serena](https://universidadeafit.widen.net/content/16ac8fee-e646-4488-afd1-47356f3f57b5/web/banner-serena.jpg?crop=yes&k=c&w=397&h=253&itok=pCuP_DkL)

Serena

Movilidad fluvial sostenible.

[Ver tecnología](node::39091)

#### Novedades

![Image 37: Imagen Proyección térmica: una tecnología prometedora en Colombia](https://universidadeafit.widen.net/content/203b854f-e3b8-41a0-8542-ed8629faeab3/web/banner-proyeccion-termica.jpg?crop=yes&k=c&w=823&h=450&itok=timlWtaz)

[Tecnología e innovación](https://www.eafit.edu.co/taxonomy/term/1811), [Industria y manufactura](https://www.eafit.edu.co/taxonomy/term/2171)
###### Proyección térmica: una tecnología prometedora en Colombia

###### Una técnica versátil con aplicación en diversas industrias

La proyección térmica es una tecnología versátil que permite aplicar capas protectoras de materiales, tanto metálicos como no metálicos, sobre distintas superficies. Utilizando temperaturas y energías controladas, estas técnicas generan recubrimientos de alta resistencia que ofrecen soluciones personalizadas, adecuándose a un amplio rango de industrias.

[Leer más](https://www.eafit.edu.co/noticias/proyeccion-termica-una-tecnologia-prometedora-en-colombia "Leer más")

Noviembre 14, 2024

![Image 38: Imagen Látex y caucho sin amoniaco](https://universidadeafit.widen.net/content/b5a80267-0829-48a3-9d8b-873144d9754d/web/BANNER-LLANTA.png?crop=yes&k=c&w=823&h=450&itok=fr3MwfV7)

[Tecnología e innovación](https://www.eafit.edu.co/taxonomy/term/1811), [Industria y manufactura](https://www.eafit.edu.co/taxonomy/term/2171)
###### Látex y caucho sin amoniaco

Un dato que no muchos saben es que para la producción de látex se usan grandes cantidades de amoniaco. El amoniaco es un gas incoloro que puede incorporarse a líquidos; se encuentra en diversos elementos que vemos en la cotidianidad como productos de limpieza o abonos. En pequeñas cantidades no es dañino para el ser humano, pero existen situaciones particulares en las cuales puede llegar a ser altamente tóxico.

[Leer más](https://www.eafit.edu.co/noticias/latex-y-caucho-sin-amoniaco "Leer más")

Febrero 1, 2023

![Image 39: Imagen Arcilla reutilizable para usos diversos](https://universidadeafit.widen.net/content/3321a7b7-623c-46f8-918e-01dc6aa15be3/web/BANNER-ARCILLA.png?crop=yes&k=c&w=823&h=450&itok=Two5h3_u)

[Tecnología e innovación](https://www.eafit.edu.co/taxonomy/term/1811), [Industria y manufactura](https://www.eafit.edu.co/taxonomy/term/2171)
###### Arcilla reutilizable para usos diversos

Tanto en la industria como en el sector del arte, la realización de productos y obras a partir de ciertos materiales como cementos o metales pueden significar largos procesos, poca flexibilidad y costos elevados. Arcillas de altas calidades, que son el recurso más usado para estos fines, en muchas ocasiones son de difícil obtención, para artistas y medianas empresas. ¿Debemos conformarnos con arcillas de baja calidad o existen otros materiales posibles?

[Leer más](https://www.eafit.edu.co/noticias/arcilla-reutilizable-para-usos-diversos "Leer más")

Octubre 31, 2022

[Ver más novedades](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/portafolio-tecnologias/novedades)

![Image 40: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 41: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 42: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 43: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 44: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 45: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 46: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 47: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 50](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
