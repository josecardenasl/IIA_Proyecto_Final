Title: Campus EAFIT

URL Source: https://www.eafit.edu.co/campus-eafit

Markdown Content:
# Campus EAFIT​​​
[Pasar al contenido principal](https://www.eafit.edu.co/campus-eafit#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/campus-eafit#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/campus-eafit# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/campus-eafit# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner campus general](https://universidadeafit.widen.net/content/4017c055-d6d5-41de-ab60-4d7dc590a30e/web/campusgeneral3.jpg?crop=yes&k=c&w=1920&h=788&itok=xS6c9SQ4)

# Campus EAFIT​​​

Los espacios físicos y virtuales, así como todos los demás recursos disponibles, se adaptan y conectan etre sí para potenciar y enriquecer la experiencia integral de aprendizaje. De este modo, los retos y los proyectos integradores tienen un papel preponderante en nuestros espacios, lo que los convierte en un valioso recurso pedagógico. En EAFIT tenemos más que salones o aulas. Contamos con un laboratorio vivo, un ecosistema en el que se aprende con la vivencia y se proponen s​oluciones replicables en materia pedagógica, tecnológica, científica, ambiental, artística y social. Un campus conectado con la naturaleza, un escenario de interacciones mediadas por el cuidado; que se proyecta más allá de sus límites y que encuentra en la ciudad y en otros territorios y entornos oportunidades de aprendizaje e interacción con otros. ​​​

*   [Inicio](https://www.eafit.edu.co/)
*    Campus EAFIT 

Área de nuestra Universidad Parque​​

### Área

126.052,06 m2

### Zonas verdes

48.346,15 m2​

### Área construida

96.260,97 m2

### Biblioteca

6.232,5 m2

### Espacios deportivos

15.849,39 m2

### Área construida

96.260,97 m2

## Mapa del campus EAFIT

[Recorre el campus de EAFIT](https://www.eafit.edu.co/campus-eafit/mapa)

![Image 22: Imagen Mapa del campus EAFIT](https://universidadeafit.widen.net/content/a4e11f6e-fa26-476c-b59d-9014341c8950/web/Campus1.png)

## EAFIT, un lugar para el encuentro y la conversación con otras personas y con la natura​​​leza​​​​​

## Premio Lápiz de Acero

¡Es el reconocimiento más importante del diseño colombiano! Se trata del Premio Lápiz de Acero y EAFIT lo recibió, en mayo de 2008, en la categoría de espacios públicos, gracias a la apuesta institucional denominada Universidad Parque, y que incluyó en sus inicios la apertura de senderos peatonales, el levantamiento de esculturas, la reubicación de árboles y la transformación física que se convirtió en uno de los grandes hitos de la historia eafitense. El premio lo recibieron los paisajistas Carlos Uribe y Jorge Mesa. En el concepto de Universidad Parque también participaron los arquitectos Carlos Julio Calle y Juan Fernando Forero.

![Image 23: Imagen  Premio Lápiz de Acero](https://universidadeafit.widen.net/content/7955a5f6-55cd-4bca-9ebe-afdf4293543b/web/premiolapizdeacero.jpg)

## **Esculturas**

## Ágora​​

Este conjunto de bloques de piedra de diferentes dimensiones es el espacio escultórico de El Ágora de EAFIT, creado por el escultor colombiano Hugo Zapata y donado a la Universidad en el año 2000. Está inspirado en la polis griega y, además de ser un lugar de confluencia, su disposición evoca aspectos como los ritmos del tiempo, de las olas, de los días, y de los encuentros y las despedidas. Es una obra que invita a interactuar, a la contemplación y la apropiación del espacio. Algunas clases y eventos académicos se desarrollan aquí.​

![Image 24: Imagen  Ágora​​](https://universidadeafit.widen.net/content/a2d5ae32-4788-4bb9-84e8-95483c20e65c/web/el-agora.jpg)

## Propileos​​

Un imponente pórtico que conecta lo clásico con lo contemporáneo. La obra Propileos, del escultor Ronny Vayda, recuerda los antiguos ingresos a los principales grupos de edificios de la ciudad, propios de la arquitectura egipcia y griega. Y es también un anuncio de renovación de que toda unidad está en constante transformación. Construida entre 2005 y 2006, esta estructura se ubica entre el bloque 38 y el Centro Cultural Biblioteca Luis Echavarría Villegas, y su simbología, acorde con los conceptos del saber, acompaña a los eafitenses que caminan por este sector del campus.

![Image 25: Imagen Propileos​​](https://universidadeafit.widen.net/content/1adb008d-8bc8-4462-815e-a01348cc3a10/web/propileos.jpg)

## **Plazoletas, parques y jardines**

## Plazoleta del Estudiante​​​

De un lado está la Biblioteca, de otro El Ágora y el edificio del bloque 29, en su frente oriental se ubica el Domo del Centro de Visitantes, y hacia el sur un rosal y la quebrada La Volcana. La que se impone en el centro es la Plazoleta del Estudiante, un espacio al aire libre de 55 metros de largo por 14 metros de ancho que, desde 1999, sirve de escenario a actividades artísticas y de bienestar, y que aparte de ser un lugar de tránsito permite que la comunidad, ya sea de día o de noche, interrumpa su rutina para conversar, leer o tomarse un café. Árboles de diversos tamaños dan sombra a quienes transitan por este sitio, el corazón de la Universidad Parque y el homenaje a la razón de ser de EAFIT: sus estudiantes.

![Image 26: Imagen Plazoleta del Estudiante​​​](https://universidadeafit.widen.net/content/ebd53f36-b197-4911-aab8-a36d89806d2a/web/plazoleta-del-estudiante.jpg)

## Parque de La Ceiba

Por muchas décadas fue la centralidad de la Institución. Las imágenes de entonces, de hace más de 30 años, muestran un parque en el que arbustos y árboles —un tanto más grandes— sobresalían entre los viejos bloques de edificios y los autos de la época. Hoy, al amparo de una gran ceiba, con un sendero peatonal y un mobiliario para el descanso, este espacio verde es testigo de cómo la infraestructura actual habla de una EAFIT vanguardista en la que tecnología y la naturaleza convergen. Variadas especies colman este lugar de paso y de permanencia, ubicado de forma estratégica en el campus.

![Image 27: Imagen Parque de La Ceiba](https://universidadeafit.widen.net/content/36a7112f-723b-4c8d-8a45-a0d0757b2d85/web/la-ceiba.jpg)

## Parque Los Guayabos​

Siglos atrás, cuando aún el Valle de Aburrá no había sido colonizado por el imperio español, el hoy Parque Los Guayabos ya tenía quien lo protegiera. Los hallazgos arqueológicos encontrados allí, en 2012, datan también de la ocupación de este terreno en otros periodos históricos, lo que hace tan especial este lugar donde se levanta el edificio en el que habitan Idiomas EAFIT y On.going, el Centro de Emprendimiento de Impacto de la Universidad. En la parte inferior, que se ubica cerca de la avenida Las Vegas, los eafitenses tienen la opción de disfrutar de diversas especies de plantas nativas y de un coliseo cubierto, así como de bancas y senderos.

![Image 28: Imagen Parque Los Guayabos​](https://universidadeafit.widen.net/content/5496b008-0cd3-4b1a-b652-d6391e09dd63/web/parque-los-guayabos.jpg)

## Patio de los Pimientos​​​

Caminar por este lugar de la Universidad Parque es conversar con melodías y acordes; entablar diálogos con interpretaciones; compartir con pimientos, anturios, orquídeas y heliconias; y conectarse con uno de los espacios del campus donde convergen arte, naturaleza y academia. Es el Patio de los Pimientos, uno de los primeros referentes de la transformación eafitense, punto que comunica el Centro Cultural Biblioteca Luis Echavarría Villegas con El Ágora, el Área de Música y el bloque 29. Se construyó en lo que fue un antiguo parqueadero de la Institución.

![Image 29: Imagen Patio de los Pimientos​​​](https://universidadeafit.widen.net/content/2cc4228d-c461-4e0a-b49b-9175313f5acc/web/pimientos.jpg)

## El Jardín de Cachi (bloque 38)​​

Lo conocen como el Jardín de Cachi, el espacio que se ubica entre el bloque 38 y la Biblioteca Luis Echavarría Villegas. Sí, el de ‘Cachi’, como le decían los amigos al paisajista Carlos Uribe, quien junto a Jorge Mesa diseñó, en los orígenes de la Universidad Parque, esta intervención que tenía como fin que ambas infraestructuras conversaran sin competir. Unas bancas donadas por la Sociedad de Mejoras Públicas de Medellín, pequeñas plantas y árboles característicos del campus permiten que, en la actualidad, los eafitenses hagan un alto en el camino y disfruten tanto del jardín como del recuerdo de ‘Cachi’.

![Image 30: Imagen El Jardín de Cachi (bloque 38)​​](https://universidadeafit.widen.net/content/3c303b93-0466-48aa-9144-429e67eac92d/web/el-jardin-de-cachi.jpg)

[![Image 31](https://universidadeafit.widen.net/content/1ecd6819-457d-4ae7-966e-942e9808db92/web/faunayflora.jpg)](https://www.eafit.edu.co/campus-eafit)

![Image 32](https://www.eafit.edu.co/campus-eafit)

## **Especies de fauna y flora​​​**

Acacias, almendros, búcaros, cámbulos, ceibas, guayacanes, hobos, mandarinos, samanes, urapanes… Tipos, variedades y colores; grandes y pequeños; jóvenes y ancestrales. EAFIT es un pulmón verde en el sur de Medellín, con seres enormes que dan sombra mientras se conversa y se vive, y que han sido testigos, muchos de ellos, de la transformación de la Universidad Parque. Por estos territorios de gigantes verdes caminan ardillas y vuelan diversas especies de aves, desde loros y pequeños colibríes, hasta gavilanes y currucutúes. Peces en el lago del Parque Los Guayabos e insectos coloridos conforman también el inventario de vida que habita este campus.

[Conoce el inventario biótico​​​ ​](https://www.eafit.edu.co/universidad-parque/inventario-biotico)

[Conoce el Plan Maestro- Universidad Parque​](https://www.eafit.edu.co/informes-de-gestion-y-sostenibilidad/informe-sostenibilidad-2020/universidad-parque)[Recorre el campus desde cualquier ​disposi​tivo y cualquier lugar](https://www.eafit.edu.co/campus-eafit/recorre-eafit)[Descarga el mapa del campus](https://universidadeafit.widen.net/s/mwmp7vjwt7/mapa-eafit)[Conoce la ubicación del campus en Google Maps](https://universidadeafit.widen.net/s/mwmp7vjwt7/mapa-eafit)[Conoce el protocolo para el ingreso​​ y la permanencia de mascotas en el campus de EAFIT​​​](https://www.eafit.edu.co/mascotas)

## **EAFIT en C​o​​​lombia​​​**

En Medellín, así como en Bogotá, Pereira y Llanogrande, la Universidad le aporta al progreso del país con una formación pertinente e innovadora que se refrenda con la Acreditación Institucional de alta calidad.​

[Conoce más sobre EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)[​Conoce más sobre EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)[​Conoce más sobre EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

![Image 33: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 34: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 35: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 36: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 37: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 38: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 39: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 40: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 41](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
