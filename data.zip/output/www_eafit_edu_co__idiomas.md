Title: Idiomas

URL Source: https://www.eafit.edu.co/idiomas

Published Time: Thu, 07 May 2026 20:25:58 GMT

Markdown Content:
# Idiomas - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/idiomas#main-content)

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 12: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/idiomas#)

[![Image 13: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/idiomas# "Spanish")[![Image 14: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/idiomas# "English")

*   [Spanish](https://www.eafit.edu.co/idiomas)
*   [Inglés](https://www.eafit.edu.co/en/idiomas)

 Información para ti

[![Image 15: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 16: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 17: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 18: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 19: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 20: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 21: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 22: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 23: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 24: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 25: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 26: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 27: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 28: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 29: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 30: Imagen de banner estudiantes caminando por campus EAFIT](https://universidadeafit.widen.net/content/a0f83264-8f55-4294-bb47-d403a538faba/web/idiomas-fotos-eafit-25.jpg?crop=yes&k=c&w=1920&h=788&itok=UYpveFlg)

# Transforma tu vida aprendiendo un nuevo idioma

Cursos de inglés, portugués, francés, alemán, italiano y español.

*   [Inicio](https://www.eafit.edu.co/)
*    Idiomas 

## Prueba tus conocimientos

Mide tus habilidades en el idioma y descubre desde qué nivel comienzas tu proceso de aprendizaje. 

 Esta prueba no es válida como examen de certificación. 

 * No aplica para programas de educación virtual

[Asigna tu cita de clasificación](https://view.genially.com/683493012034b378cff3aed5/guide-clasificaciones%20)

![Image 31: Imagen Prueba tus conocimientos](https://universidadeafit.widen.net/content/f9f360f2-800c-493a-8e5b-95532331d015/web/idiomas-fotos-eafit-13.jpg)

Filtros

*   [Inglés(8)](https://www.eafit.edu.co/idiomas?f%5B0%5D=Idioma%3A261)
*   [Alemán(2)](https://www.eafit.edu.co/idiomas?f%5B0%5D=Idioma%3A266)
*   [Francés(2)](https://www.eafit.edu.co/idiomas?f%5B0%5D=Idioma%3A271)
*   [Italiano(1)](https://www.eafit.edu.co/idiomas?f%5B0%5D=Idioma%3A281)
*   [Portugués(1)](https://www.eafit.edu.co/idiomas?f%5B0%5D=Idioma%3A276)
*   [Spanish program(1)](https://www.eafit.edu.co/idiomas?f%5B0%5D=Idioma%3A286)

Facet Idioma 

*   [Sede Poblado - Universidad EAFIT(10)](https://www.eafit.edu.co/idiomas?f%5B0%5D=sedes%3A306)
*   [Sede Llanogrande - Universidad EAFIT(3)](https://www.eafit.edu.co/idiomas?f%5B0%5D=sedes%3A321)
*   [Sede Norte - I.E Suárez de La Presentación, Bello(3)](https://www.eafit.edu.co/idiomas?f%5B0%5D=sedes%3A3186)
*   [Sede Sur - Centro Comercial Mayorca(3)](https://www.eafit.edu.co/idiomas?f%5B0%5D=sedes%3A316)
*   [Sede Belén - Instituto San Carlos de la Salle(2)](https://www.eafit.edu.co/idiomas?f%5B0%5D=sedes%3A311)
*   [Sede Laureles - Colegio Bethlemitas(2)](https://www.eafit.edu.co/idiomas?f%5B0%5D=sedes%3A1911)

Facet Sedes 

*   [Adultos(7)](https://www.eafit.edu.co/idiomas?f%5B0%5D=publico%3A301)
*   [Niños y niñas(5)](https://www.eafit.edu.co/idiomas?f%5B0%5D=publico%3A291)
*   [Jóvenes(3)](https://www.eafit.edu.co/idiomas?f%5B0%5D=publico%3A296)

Facet Público 

![Image 32: Idiomas EAFIT Sede Bello](https://universidadeafit.widen.net/content/cpca2gcakl/web/ingles_BELLO.png?crop=yes&k=c&w=823&h=450&itok=jzCnfrGL)

## ¡Idiomas EAFIT llega a Bello!

Aprende inglés con educación de calidad y una metodología efectiva.

[Ver programa](https://www.eafit.edu.co/idiomas-eafit-llega-bello)

![Image 33: Idiomas EAFIT, virtual. Personas realizan actividades académicas en una plataforma virtual con diferentes dispositivos tecnológicos.](https://universidadeafit.widen.net/content/4wghan4uq1/web/idiomas-eafit-virtual-12.jpg?crop=yes&k=c&w=823&h=450&itok=kd7P_URP)

## Alemán para adultos

### Edad +17

Aprende con una metodología efectiva y práctica y descubre la riqueza cultural del alemán, sumérgete en su historia y tradiciones.

[Ver programa](https://www.eafit.edu.co/idiomas/aleman-adultos)

![Image 34: Idiomas EAFIT, virtual. Personas realizan actividades académicas en una plataforma virtual con diferentes dispositivos tecnológicos.](https://universidadeafit.widen.net/content/str9tpwymb/web/idiomas-eafit-virtual-54.jpg?crop=yes&k=c&w=823&h=450&itok=0BZ2A6LF)

## Alemán para Jóvenes

### Edad 12 a 16 años

Descubre la riqueza cultural del alemán y atrévete a sumergirte en su historia y tradiciones.

[Ver programa](https://www.eafit.edu.co/idiomas/aleman-jovenes)

![Image 35: English stars inglés para niños de 4 años](https://universidadeafit.widen.net/content/pllfjr37aj/web/english-stars-cards-.jpg?crop=yes&k=c&w=823&h=450&itok=3YpAOtPg)

## English Stars - niños de 4 años

### Edad 4 años

Un programa para aprender inglés y fortalecer habilidades clave para el desarrollo cognitivo, social y comunicativo en la primera infancia.

[Ver programa](https://www.eafit.edu.co/idiomas/ingles-ninos/english-stars)

![Image 36: Curso de Francés para adultos](https://universidadeafit.widen.net/content/t9in3jwomi/web/Idiomas%202-11%20(1).jpg?crop=yes&k=c&w=823&h=450&itok=UZ6Hl5XU)

## Francés para adultos

### Edad +17

Aprende una de las lenguas más fascinantes y sumérgete en una cultura artística y rica.

[Ver programa](https://www.eafit.edu.co/idiomas/frances-adultos)

![Image 37: Idiomas EAFIT, virtual. Personas realizan actividades académicas en una plataforma virtual con diferentes dispositivos tecnológicos.](https://universidadeafit.widen.net/content/xkovcxbdwd/web/idiomas-eafit-virtual-48.jpg?crop=yes&k=c&w=823&h=450&itok=s8v33dpg)

## Francés para jóvenes

### Edad 12 a 16 años

Domina una lengua romance fascinante y explora una cultura artística y rica.

[Ver programa](https://www.eafit.edu.co/idiomas/frances-jovenes)

*   [Página actual 1](https://www.eafit.edu.co/idiomas?idiomas=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/idiomas?idiomas=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/idiomas?idiomas=&page=2 "Ir a la página 3")
*   [Siguiente página›](https://www.eafit.edu.co/idiomas?idiomas=&page=1 "Ir a la página siguiente")
*   [Última página»](https://www.eafit.edu.co/idiomas?idiomas=&page=2 "Ir a la última página")

## Inglés

[Ver programas de inglés](https://www.eafit.edu.co/idiomas/ingles)

## Otros idiomas

[Ver programas](https://www.eafit.edu.co/idiomas/otros-idiomas)

## Spanish program

[Find out more](https://www.eafit.edu.co/idiomas/spanish-program)

![Image 38: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## Testing center

[Conoce el Testing Center](https://www.eafit.edu.co/idiomas/testing-center)

## Global explorers

[Conoce Global explorers](https://www.eafit.edu.co/idiomas/global-explorers)

## Portafolio corporativo

[Ver programas corporativos](https://www.eafit.edu.co/idiomas/portafolio-corporativo)

![Image 39: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

# Proceso de inscripción

Para autogestionar tu inscripción en Idiomas, primero debemos conocer cuál es el nivel ideal para ti. Para ello debes realizar una cita de clasificación, solicítala así:

### 1

[Ingresa aquí](https://view.genially.com/683493012034b378cff3aed5/guide-clasificaciones)

### 2

### Selecciona la edad del estudiante

### 3

### Selecciona el idioma que deseas estudiar

### 4

### Elige la sede

### 5

### Elige la fecha y hora para presentar tu cita de clasificación

¡Es completamente gratis!

### 6

### Diligencia tu datos y dale clic en reservar

### 7

### Asiste a tu cita de clasificación

En la sede y horario seleccionado.

 Cuando finalice tu prueba de clasificación, acércate al módulo de Información y Matrículas para realizar tu inscripción.

![Image 40: Imagen ¿Por qué estudiar en Idiomas EAFIT?](https://universidadeafit.widen.net/content/61f0e0fb-92ca-4c63-b201-9287e4056b20/web/idiomas-eafit-virtual-36.jpg?crop=yes&k=c&w=397&h=253&itok=khjMIFww)

¿Por qué estudiar en Idiomas EAFIT?

Más de 30 años de experiencia en la enseñanza de idiomas. 

 Transformamos vidas y propiciamos oportunidades para interactuar efectivamente en un mundo intercultural.​

[Descúbrelo aquí](https://www.eafit.edu.co/idiomas/por-que-estudiar-idiomas-eafit)

##### **Espacios de interés**

## Vacaciones en inglés para niños

Happy Time: Una semana perfecta para disfrutar y conocer el mundo mientras aprenden un nuevo idioma.

 Próxima fecha: del 1 al 5 de diciembre

[Conoce más información](https://www.eafit.edu.co/idiomas/ingles-ninos/happy-time)

![Image 41: Imagen Vacaciones en inglés para niños](https://universidadeafit.widen.net/content/27de5dcc-1b75-46eb-8434-8460d3a6c0e9/web/happy-time-cards-.jpg)

## Clubes de conversación

Mejora tu fluidez en inglés y otros idiomas en nuestros clubes de conversación. Practica con hablantes locales y nativos en un entorno dinámico y real.

[Ver clubes de conversación](https://www.eafit.edu.co/clubes-de-conversacion)

![Image 42: Imagen Clubes de conversación](https://universidadeafit.widen.net/content/80e32c44-9a80-4526-ac6e-f39fa6348b57/web/club-de-conversacion.jpg)

## Clases de prueba

Prográmate para una clase de prueba gratuita para conocer a detalle nuestra metodología con enfoque participativo.

[Conocer clases de prueba](https://www.eafit.edu.co/idiomas/clases-prueba)

![Image 43: Imagen Clases de prueba](https://universidadeafit.widen.net/content/78c559ee-72fe-431b-8a82-dc3b0e2aa90f/web/idiomas-fotos-eafit-9.jpg)

## Agenda cultural

Participa de actividades que te permitirán tener otra mirada del mundo y sus diferentes culturas.

[Ver agenda cultural](https://www.eafit.edu.co/idiomas/agenda-cultural)

![Image 44: Imagen Agenda cultural](https://universidadeafit.widen.net/content/2f5ab271-8524-4ccb-b658-cb8c11464e55/web/idiomas-eafit-virtual-28.jpg)

## Curso de iniciación Portugués

¡Tu pasaporte al portugués! 

 Jóvenes de 12 a 17 años. 

 Aprende las bases del idioma y explora la riqueza cultural de Brasíl y otros países lusófonos. 

 Duración corta

 Ideal para jóvenes curiosos

![Image 45: Imagen Curso de iniciación Portugués](https://universidadeafit.widen.net/content/e99dab61-229a-4fca-a032-c3ffd9aff850/web/curso-iniciacion-portugues.png)

Idiomas 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Idiomas

Nombres/Name*? 

Apellidos/Last name*? 

Tipo de documento/Type of ID*? 

Número de documento/ID number*? 

E-mail*? 

Teléfono de contacto/Phone number*? 

¿Cuál de nuestros programas le interesa? / What program are you interested in?? 

¿Dónde te enteraste de nosotros?? 

¿Por qué medio quiere ser contactado?? 

¿Qué desea saber?? 

Inicio del programa 

Canal origen 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 46](https://www.eafit.edu.co/idiomas)

Sedes

![Image 47: Imagen Sede Poblado - Universidad EAFIT](https://universidadeafit.widen.net/content/8bb254c4-3997-401b-97f8-a0d94af03a15/web/sede-poblado-idiomas-eafit)

Sede Poblado - Universidad EAFIT

Calle 5 sur No 43C - 80 bloque 1 Parque Los Guayabos

 Horarios de atención presencial: lunes a viernes de 7:30 a.m. a 6:30 p.m. y sábados de 8:00 a.m. a 2:00 p.m.

 Correo: idiomas.sedepoblado@eafit.edu.co 

 Teléfono: (57) 604 261 9500

![Image 48: Imagen Sede Belén - ​Instituto San Carlos de la Salle](https://universidadeafit.widen.net/content/b24c9b6f-0ac0-4f0d-bffb-fbc75d81bd2e/web/Sede-belen-idiomas-eafit.JPG?crop=yes&k=c&w=397&h=253&itok=eEOmP9Ly)

Sede Belén - ​Instituto San Carlos de la Salle

Diagonal 79 No 15 – 123.

 Horarios de atención presencial: miércoles de 2:00 p.m. a 6:30 p.m., jueves y viernes de 10:00 a.m. a 1:00 p.m. y de 2:00 a 6:30 p.m., y sábados de 8:00 a.m. a 1:00 p.m.

 Atención remota por correo electrónico y línea telefónica de martes a sábado. 

 Correo: idiomas.sedebelen@eafit.edu.co

 Teléfono: (57) 604 261 9500 ext 9355

![Image 49: Imagen Sede Sur - Centro Comercial Mayorca](https://universidadeafit.widen.net/content/d1e270a7-0045-4fb3-bb56-8a3d1f4b1103/web/Sede-sur-centro-comercial-mayorca.jpg?crop=yes&k=c&w=397&h=253&itok=yJs2Fyhn)

Sede Sur - Centro Comercial Mayorca

Carrera 48 No 50 sur 128 - piso 6 etapa 2.

 Horarios de atención presencial: de lunes a viernes de 10:00 a.m. a 7:00 p.m. y sábados de 8:00 a.m. a 2:00 p.m.

 Correo: idiomas​.sedesur@eafit.edu.co

 Teléfono: (57) 604 261 9500

![Image 50: Imagen Sede Llanogrande](https://universidadeafit.widen.net/content/01b0bddb-7fe9-4bdc-a500-940f55b98b53/web/Sede-llanogrande-idiomas-eafit.jpg?crop=yes&k=c&w=397&h=253&itok=6SubQhv3)

Sede Llanogrande

Vía Llanogrande Km.3.5 desde Don Diego – Rionegro.

 Horarios de atención no presencial: de lunes a viernes de 8:00 a.m. a 5:00 p.m. y sábados de 8:00 a.m. a 1:00 p.m.

 Correo: idiomas.llanogrande@eafit.edu.co 

 Teléfono: (57) 604 261 9500 opc 3 ext. 8919

![Image 51: Imagen Sede Laureles - Colegio Bethlemitas](https://universidadeafit.widen.net/content/40338426-d667-4504-a1f5-af6a09b57454/web/Idiomas-eafit-sede-laureles-colegio-bethlemitas.png?crop=yes&k=c&w=397&h=253&itok=Wlmht7D_)

Sede Laureles - Colegio Bethlemitas

Diagonal 75C No. 33B - 93

 Horarios de atención: 

 Martes a viernes online: 9:00 a.m. a 12:00 m.

 Martes a viernes presencial: 2:00 p.m. a 7:00 p.m.

 ​Sábado presencial: 8:00 a.m. a 1:00 p.m.​

 Correo: idiomas​.laureles@eafit.edu.co

 Teléfono: (57) 604 261 9500 ext. 8681

![Image 52: Imagen Sede Norte - I. E. Suárez de la Presentación](https://universidadeafit.widen.net/content/6ab6d5a4-e934-43fb-9388-9c3ee5802b85/web/vocabulario_en_ingles_BELLO.png?crop=yes&k=c&w=397&h=253&itok=UR-_Yqg6)

Sede Norte - I. E. Suárez de la Presentación

Carrera 55 #35 - 41, Barrio Obrero

 Horarios de atención presencial: 

 Miércoles, jueves y viernes: 10:00 a.m. a 1:00 p.m. / 2:00 p.m. a 6:30 p.m. / Sábados: 8:00 a.m. a 1:00 p.m. 

 Atención remota:

 Martes: 8:00 a.m. a 12:00 m y de 1:00 p.m. a 5:00 p.m., lunes no hay atención al público.

 Correo: idiomas​.sedenorte@eafit.edu.co

 Teléfono: (57) 604 261 9500 ext. 8419 / 300 261 9500

## Convenios y descuentos

Accede a beneficios exclusivos para estudiar el idioma de tu preferencia.

[Ver convenios y descuentos](https://universidadeafit.widen.net/view/pdf/eqicqaydae/politica-descuentos-convenios.pdf)

## Políticas de Lengua Extranjera

Controles de bilingüismo para los estudiantes de la Universidad.

[Ver políticas](https://www.eafit.edu.co/idiomas/politica-lengua-extranjera)

[![Image 53: Imagen de dos mujeres en una conferencia virtual](https://universidadeafit.widen.net/content/8db0a1ab-e9b8-423a-9913-e9d8679cb3aa/web/idiomas-fotos-eafit-24.jpg?crop=yes&k=c&w=1920&h=600&itok=2iPamxWR)](https://www.eafit.edu.co/idiomas)

![Image 54](https://www.eafit.edu.co/idiomas)

## Políticas Idiomas EAFIT

Encuentra las políticas y reglamentos de Idiomas EAFIT.

[Ver políticas](https://www.eafit.edu.co/idiomas/por-que-estudiar-idiomas-eafit)

## ¡Nuestro Protocolo de Asistencia cambió!

Diseñado para garantizar tu éxito académico y lingüístico.

[Conoce nuestro protocolo](https://universidadeafit.widen.net/s/rgfcdtsd2z/politica-asistencia-y-reposicion-de-clase)

![Image 55: Imagen ¡Nuestro Protocolo de Asistencia cambió!](https://universidadeafit.widen.net/content/b7daad35-b902-482f-bcaf-b879d20ace55/web/idiomas-eafit-virtual-20.jpg)

![Image 56: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 57: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 58: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 59: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 60: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 61: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 62: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 63: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
