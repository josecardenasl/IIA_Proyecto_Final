Title: Posgrados

URL Source: https://www.eafit.edu.co/en/posgrados

Markdown Content:
# Posgrados - Universidad EAFIT
[Skip to main content](https://www.eafit.edu.co/en/posgrados#main-content)

[![Image 43: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 44: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 45: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/posgrados#)

[![Image 46: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/posgrados# "Spanish")[![Image 47: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/en/posgrados# "English")

*   [Spanish](https://www.eafit.edu.co/posgrados)
*   [Inglés](https://www.eafit.edu.co/en/posgrados)

 Información para ti

[![Image 48: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 49: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 50: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 51: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 52: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 53: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Search 

Búsqueda

Menú

Información para ti

[![Image 54: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/en/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/en/node/42116)
    *   [Vida en el campus](https://www.eafit.edu.co/en/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/en/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/en/node/45896)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/en/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/en/node/45926)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/en/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/en/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/en/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/en/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/en/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/en/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/en/registrars-office)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/en/node/31081)
    *   [Cultura CTeI](https://www.eafit.edu.co/en/node/31171)
    *   [Formación](https://www.eafit.edu.co/en/node/31201)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/en/node/39301)
    *   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/en/node/30186)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/en/node/29776)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Transforma con nosotros](https://www.eafit.edu.co/en/node/43361)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/en/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/en/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/en/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/en/node/1151)
    *   [Intercambios nacionales](https://www.eafit.edu.co/en/node/1146)
    *   [Convenios](https://www.eafit.edu.co/en/node/1111)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/en/node/16436)
    *   [Misiones internacionales](https://www.eafit.edu.co/en/node/1136)
    *   [Aprendizaje global](https://www.eafit.edu.co/en/node/1131)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/en/node/45976)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/en/node/43446)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/en/node/47981)
    *   [Centro de artes](https://www.eafit.edu.co/en/node/47976)
    *   [Sala patrimonial](https://www.eafit.edu.co/en/node/39836)
    *   [Bienestar universitario](https://www.eafit.edu.co/en/bienestar)
    *   [Salud mental](https://www.eafit.edu.co/en/node/45826)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/en/node/38366)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/en/node/38196)
    *   [Sala de prensa](https://www.eafit.edu.co/en/node/38391)
    *   [Agenda y eventos](https://www.eafit.edu.co/en/node/18151)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 55: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 56: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 57: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 58: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 59: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 60: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 61: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 62: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 63: Imagen profesores](https://universidadeafit.widen.net/content/04385468-e2a8-4e86-97d2-a4afe3622f1d/web/posgrados-fotos-generales18.jpg?crop=yes&k=c&w=1920&h=788&itok=leyT0jsq)

# Study your postgraduate program at EAFIT

Learn about the more than 90 programs we have for you. Be part of a University that is home to a community with the power to transform everything.

*   [Inicio](https://www.eafit.edu.co/en)
*    Posgrados 

##### Programas de posgrado que te han interesado recientemente

Filtros

*   [Management(42)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=escuelas_posgrados%3A1536)
*   [Applied Sciences and Engineering(24)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=escuelas_posgrados%3A1541)
*   [Finance, Economy and Government(19)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=escuelas_posgrados%3A1546)
*   [Law(13)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=escuelas_posgrados%3A1526)
*   [Arts and Humanities(10)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=escuelas_posgrados%3A1531)

Facet Escuelas Posgrados 

*   [Organization, Management and Strategy(31)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1606)
*   [Macroeconomics and Financial Systems(13)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1631)
*   [Fundamental Sciences(12)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1641)
*   [Policies and Development(8)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1636)
*   [Law(6)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1551)
*   [Creation(5)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1601)
*   [Industry, Materials and Energy(4)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1656)
*   [Marketing and Innovation(4)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1621)
*   [Public Law(3)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1556)
*   [Criminal Law(2)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1576)
*   [Culture(2)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1591)
*   [Law and Economy(2)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1561)
*   [Markets and Financial Strategy(2)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1626)
*   [Product and Experience Design(2)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1646)
*   [Business and Commercial Law(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1566)
*   [Care and Life Sciences(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1671)
*   [Computing and Analytics(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1666)
*   [Global Management(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1611)
*   [Information and Risk Management(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1616)
*   [Labor Law(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1571)
*   [Language(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1596)
*   [Natural and Sustainability Systems(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1661)
*   [Territories and Cities(1)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=area_de_conocimiento_posgrado%3A1651)

Facet Área de conocimiento pre pos inglés 

*   [Master's(54)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=tipo_de_programa_posgrado%3A141)
*   [Specialization(47)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=tipo_de_programa_posgrado%3A136)
*   [Doctorate(6)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=tipo_de_programa_posgrado%3A131)

Facet Tipo de programa Posgrado 

*   [In Person(93)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=modalidad_posgrado%3A101)
*   [Blended(9)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=modalidad_posgrado%3A96)
*   [Virtual(6)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=modalidad_posgrado%3A106)

Facet Modalidad Posgrado 

*   [Medellin(88)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=sedes_posgrados%3A121)
*   [Pereira(9)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=sedes_posgrados%3A126)
*   [Bogota(5)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=sedes_posgrados%3A111)
*   [Popayan(3)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=sedes_posgrados%3A186)
*   [Cali(2)](https://www.eafit.edu.co/en/posgrados?f%5B0%5D=sedes_posgrados%3A191)

Facet Sedes Posgrados 

#### Specialization in Mechanical Design

![Image 64: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duration

2 semesters

![Image 65: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Location

Medellin

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Schedule

According to the semester

Más información

First semester: Tuesday from 6:00 p.m. at 9:00 p.m., Friday from 6:00 p.m. at 10:00 p.m. and Saturdays from 8:00 a.m. at 12:00 m.

 Second semester: Tuesday to Friday from 6:00 a.m. at 8:00 a.m.

![Image 67: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Language

Spanish

![Image 68: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modality 

In Person 

![Image 69: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 8707

![Image 70: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Total Program Cost

$ 31,973,664

[Know other rates](https://www.eafit.edu.co/en/node/1171)

[Ver más](https://www.eafit.edu.co/en/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-diseno-mecanico "Ver posgrado")

#### Specialization in Industrial Maintenance

![Image 71: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duration

2 semesters

Más información

Two academic semesters with face -to -face dedication of twelve (12) hours per week.

![Image 72: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Location

Medellin

![Image 73: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Schedule

Wednesday, Friday and Saturday

Más información

Wednesday and Friday from 6:00 p.m. at 10:00 p.m. and Saturdays from 7:00 a.m. at 11:00 a.m.

![Image 74: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Language

Spanish

![Image 75: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modality 

In Person 

![Image 76: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 14021

![Image 77: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Total Program Cost

$ 31,787,717

[Know other rates](https://www.eafit.edu.co/en/node/1171)

[Ver más](https://www.eafit.edu.co/en/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-mantenimiento-industrial "Ver posgrado")

#### Specialization in Information Systems

![Image 78: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duration

2 semesters

![Image 79: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Location

Medellin

![Image 80: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Schedule

Fridays and Saturdays

Más información

Friday from 6:00 p.m. at 10:00 p.m. and Saturdays from 8:00 a.m. at 12:00 m.

 Elective subjects: Monday to Thursday from 6:00 p.m. at 10:00 p.m.

![Image 81: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Language

Spanish

![Image 82: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modality 

In Person 

![Image 83: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 1261

![Image 84: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Total Program Cost

$ 27,052,177

[Know other rates](https://www.eafit.edu.co/en/node/1171)

[Ver más](https://www.eafit.edu.co/en/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-sistemas-informacion "Ver posgrado")

#### Specialization in Soil and Foundation Mechanics

![Image 85: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duration

2 semesters

![Image 86: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Location

Medellin

![Image 87: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Schedule

Fridays and Saturdays

Más información

Friday from 3:00 p.m. at 9:00 p.m. and Saturdays from 8:00 a.m. at 2:00 p.m. The second semester schedule may vary, according to the chosen electives.

![Image 88: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Language

Spanish

![Image 89: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modality 

In Person 

![Image 90: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 10703

![Image 91: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Total Program Cost

$ 32,336,015

[Know other rates](https://www.eafit.edu.co/en/node/1171)

[Ver más](https://www.eafit.edu.co/en/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-mecanica-suelos-cimentaciones "Ver posgrado")

#### Specialization in Seismic - Resistant Engineering

![Image 92: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duration

2 semesters

![Image 93: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Location

Medellin

![Image 94: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Schedule

Monday to Friday

Más información

Monday to Friday from 6:00 a.m. at 9:00 a.m. and Friday from 3:00 p.m. at 6:00 p.m. The schedule is subject to programming and will be reported after the start of the semester.

![Image 95: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Language

Spanish

![Image 96: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modality 

In Person 

![Image 97: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 1264

![Image 98: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Total Program Cost

$ 32,589,944

[Know other rates](https://www.eafit.edu.co/en/node/1171)

[Ver más](https://www.eafit.edu.co/en/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-ingenieria-sismo-resistente "Ver posgrado")

#### Specialization in Construction Management

![Image 99: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duration

2 semesters

![Image 100: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Location

Medellin

![Image 101: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Schedule

Fridays and Saturdays

Más información

Fridays from 2:00 p.m. to 8:00 p.m. and Saturdays from 8:00 a.m. to 2:00 p.m.

![Image 102: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Language

Spanish

![Image 103: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modality 

In Person 

![Image 104: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 14869

![Image 105: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Total Program Cost

$ 34.912.378

[Know other rates](https://www.eafit.edu.co/en/node/1171)

[Ver más](https://www.eafit.edu.co/en/posgrados/escuela-ciencias-aplicadas-ingenieria/especializacion-gestion-construccion "Ver posgrado")

*   [Current page 1](https://www.eafit.edu.co/en/posgrados?label=&page=0 "Current page")
*   [Page 2](https://www.eafit.edu.co/en/posgrados?label=&page=1 "Go to page 2")
*   [Page 3](https://www.eafit.edu.co/en/posgrados?label=&page=2 "Go to page 3")
*   [Page 4](https://www.eafit.edu.co/en/posgrados?label=&page=3 "Go to page 4")
*   [Page 5](https://www.eafit.edu.co/en/posgrados?label=&page=4 "Go to page 5")
*   …
*   [Next page›](https://www.eafit.edu.co/en/posgrados?label=&page=1 "Go to next page")
*   [Last page Último »](https://www.eafit.edu.co/en/posgrados?label=&page=17 "Go to last page")

## **Guía de aspirantes posgrados**

[Registration](https://www.eafit.edu.co/en/posgrados#4257225834-4023747369)

Registration

###### Register and make the payment

**Registration dates: August 26 to November 29, 2024.**

###### a. Registration process

Any professional who has completed bachelor level studies or a program at a national or foreign university recognized by competent state educational authorities may apply for admission to postgraduate programs, while technicians, technologists or specialized technologists are not eligible. If you have been enrolled in a higher education institution, other than EAFIT, in a postgraduate program, you must apply for **External Transfer** admission, regardless of whether you wish to request subject recognition. First time applicants should select **First time studies** in type of applicant box, in [**EPIK self-service**](https://www.eafit.edu.co/epik), module **"Undergraduate and Postgraduate Registration"**.

If you have been enrolled in an undergraduate or graduate program at EAFIT, the system will provide you with a list of the types of admission that will apply, depending on the program selected. If the system does not show you any type of admission, please contact us via email ([**posgrados@eafit.edu.co**](mailto:posgrados@eafit.edu.co)) with your full name, identification document type and number, and indicate the program of interest, the city where you are going to study and the name of the program you will be taking at EAFIT.

To register, enter the **Registration** module by clicking [**here**](https://www.eafit.edu.co/inscripciones), press the P.I button. Start your registration here, and proceed to fill out the form. Enter all the required data.

Enter [**here**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), click on the button **Learn about our Postgraduate offering and learn about our programs available** for the **2025-1** semester.

###### b. Registration payment

**Registration fee:****$341.700** (approximately $82 USD).

After successfully submitting your registration request, go to the end of the form and proceed to make your payment. If you filled out the form and are going to make the registration payment later, enter the [**EPIK self-service**](https://www.eafit.edu.co/epik), **"My Finances"** module, **"Payment Center"** option, where the system shows the payment document. Select it and activate the **Pay Online** button.

You can pay the registration fee online, with a credit or debit card through one of the banks registered in PSE. Do not close the page until the bank reports that your transaction was successful. Afterwards, look for the return option.

If you cannot pay online, click on Download PDF, print receipt on a laser printer and and make an in-person payment at any authorized bank nationwide: Bancolombia, Davivienda, Banco de Bogotá, AV Villas and Banco de Occidente.

If you have difficulty generating the payment document, send an email to [posgrados@eafit.edu.co](mailto:posgrados@eafit.edu.co)

If you have trouble making the payment, send an email to [**apoyofinanciero@eafit.edu.co**](mailto:apoyofinanciero@eafit.edu.co)

Payments abroad can be made through bank transfer; to obtain the University account information, contact the Support area, contact the finance department at [**tesoreria@eafit.edu.co**](mailto:tesoreria@eafit.edu.co).

Once the payment is made, the system will send it to the email registered to the dilig. Send your registration form, a notification informing you of the confirmation of registration and the procedures you must follow to continue with your admission process.

[Requirements](https://www.eafit.edu.co/en/posgrados#4257225834-1328898390)

Requirements

###### Attach your documents with your registration form

###### a. List of documents

If you have made your registration payment, attach your documents online through the [**EPIK self-service**](https://www.eafit.edu.co/epik), in the **"Document Annex"** module. The system will show you the documents that you must attach, depending on the program and type of admission; files should be JPG, TIF or PDF type, with a size is between 1 Kb and 12 Mb.

**Document****First time applicant****External Transfer****EAFIT University Graduate**
Original or scanned Undergraduate degree certificate issued by the University with the corresponding signatures. If your degree is from abroad, attach your diploma as well, and its translation into Spanish.Yes. It is required  for admission.Yes. It is required  for admission.No.
Photocopy of both sides of identification document amended vertically at 150% on the same page or sides or on the digital document.Yes. It is required  for admission.Yes. It is required  for admission.Only if you do not already have it updated in Admissions and Records.
For external transfer request: Personal letter addressed to Admissions and Records that clearly states the reasons why you wish to make the external transfer and indicates if you are requesting subject recognition. In case of recognition, list the subjects you wish to be recognized.No.Yes. It can be attached online in the module Annex of documents. Required for admission.No

###### b. Additional requirements

Click [**here**](https://universidadeafit.widen.net/s/tcmfxjrtvm/programas-posgrado-20251), click on the button **Learn about our Graduate Programs** and learn about the available programs for the 2025-1 semester, schedules and additional requirements if applicable.

###### c. External transfers with subject recognition

For the recognition of subjects, applicants for external transfer must bring the certificates listed below to the interview; and attach the following to the registration form:

**Document****External Transfer**
Certificate from the university of origin, with letterhead and corresponding signatures, indicating the subjects taken with their grade and time intensity.Yes. Attached to the Registration.
Syllabus with detailed contents of the subjects to be recognized by EAFIT, duly certified with the signature and seal of the university of origin.Yes. To be handed in person to the interviewer.
For recognition of subjects currently being studied, a duly certified letter from the university of origin, on letterhead with the corresponding signatures must be attached, indicating hour intensity, syllabus with detailed contents. Recognition is conditional on the final grade obtained in the course, which must be attached with the certificate of qualifications.Yes. Attached to the registration form To. be submitted by January 10, 2025.

Si no deseas homologación, debes adjuntar desde el formulario o desde el módulo Anexo de documentos, la carta personal dirigida a Registro Académico, en la que indiques si tu transferencia externa es sin reconocimiento de asignaturas, y finalmente informar a tu entrevistador.

**Importante: la información suministrada en la inscripción debe coincidir con los documentos entregados, de lo contrario, se anulará cualquier proceso adelantado en la Universidad.**

[Interview](https://www.eafit.edu.co/en/posgrados#4257225834-2915221919)

Interview

###### Select your interview appointment (if applicable for the program)

Once we receive your registration payment, schedule your interview. To do this, enter the Self-service [**here**](https://www.eafit.edu.co/epik), go to the **"Services and certificates"** module, enter the **"Request for services"** option, and in the **"Requests Made"** section, access the **"Admission interview appointment"** service, select it and request your interview appointment.

**Important: please check both in-person and online availability.**

If no appointments are available, select the option **"I did not find an appointment"**, so we can proceed to create new spaces for you to later come and select one.

**If the program does not require an interview, the system will not present you with the "Admission Interview Appointment" service for selection.**

[Admission](https://www.eafit.edu.co/en/posgrados#4257225834-2048125946)

Admission

###### Check your admission result

The admission process begins on September 19, 2024, after which you will be notified regarding your admission status to the email provided in registration form.

You can also check your status by entering the [**EPIK Self-service**](https://www.eafit.edu.co/epik), **"Undergraduate Graduate Registration"** module and clicking on the **"Status"** field.

To be admitted, it is an essential requirement to have submitted all the required documentation and, if applicable, to have submitted your admission interview.

**Note:**foreign applicants who are admitted, must present their student visa that is valid for the academic period to which they will enroll.

[Credit recognition](https://www.eafit.edu.co/en/posgrados#4257225834-3486650419)

Credit recognition

###### Credit recognition(if applicable for your type of admission)

For information regarding recognition of subjects in graduate programs, consult [**here**](https://www.eafit.edu.co/institucional/reglamentos/reglamente-academico-de-los-programas-de-prosgrado) the Graduate Academic Regulations of EAFIT University or with the director of the program to which you are applying.

[Class Schedule](https://www.eafit.edu.co/en/posgrados#4257225834-1341125043)

Class Schedule

###### Check your class schedule and receipt

Once you are admitted and submit the required documentation, you will be registered based on the information provided by the program to which you were admitted.

Check your schedule through the EPIK Self-Service, by clicking [**here**](https://servicios.eafit.edu.co/psc/EACS92PD_11/EMPLOYEE/SA/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL?&) and entering the "My Registration" module and then entering the "My Certificates" option.

Schedules will be assigned beginning May, based on the syllabus of each postgraduate program.

[Tuition](https://www.eafit.edu.co/en/posgrados#4257225834-2477669287)

Tuition

###### Pay your tuition

Once you have registered for classes and generated the payment document, verify payment dates.

###### Check your payment document

Enter the EPIK Self-Service by clicking [**here**](https://www.eafit.edu.co/epik), select the **"My Finances"** module, go to **"Payment Center"**option and select the document under registration payment document.

If you have any difficulty with the payment, write to email [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Online payment

Verify in your bank if your debit or credit cards are authorized for online transactions as well the amounts allowed to prevent the transaction from being rejected.

To make the payment of your registration, enter through the [**EPIK Self-service**](https://www.eafit.edu.co/epik) with username and password; in the **"My finances"** module, go to the **"Payment Center"**option and in the **"Online payment"** button, go directly to the PlacetoPay platform which allows payment with multiple credit and/or debit cards.

Full payment must be made to conclude the process successfully and be registered as an active student.

Do not close the page after the bank confirms your transaction, and return to the University website to confirm your payment, otherwise, the information will not be recorded in our database.

###### Payment in banks

In person payment can be made at the following authorized banks nationwide: **Bancolombia, Davivienda, Banco de Bogotá, AV Villas and Banco de Occidente.**

A laser printed copy of the payment document that allows barcodes to be scanned must be presented at Banco de Bogotá offices, or a digital registration copy on your cell phone or tablet.

Banks receive payment in cash and/or checks made payable to EAFIT University.

If payments are made with checks, student identification number, phone number and the amount to be payed must be written on the reverse side of the check.

Banks will only accept payments for the total tuition fee stipulated on the document.

Tuition must be paid in full in order to acquire the status of active student.

Dirigirte al campus principal bloque 29 primer piso, taquilla de Tesorería – Caja en horario de 8:00 am a 5:00 pm de lunes a viernes. En caso de que no puedas desplazarte a la Universidad escribe al correo electrónico [pagos@eafit.edu.co](mailto:pagos@eafit.edu.co), informando que vas a realizar un pago mixto.

En cualquier caso, se debe pagar el 100% del valor generado en el documento de pago de matrícula, para que puedas adquirir la calidad de estudiante activo.

For additional information, call our service line (604) 2619500 or write to: [apoyofinanciero@eafit.edu.co](mailto:apoyofinanciero@eafit.edu.co)

###### Payment of invoices by a Company

If payment is made a Company that requires an invoice in its name, keep in mind the types of invoices that can be issued to a Company:

**Cash:**in this case, the Company must make the payment immediately.

**Credit:**the company requires a 30-day term to pay prior to a credit approval.

The company invoicing process must be carried out here.

Los documentos que se deben de anexar son:

1.   Letter on company stationery with letterhead in which the Company authorizes  EAFIT University to send them an invoice for tuition, readjustments, additional enrollment, inter-semestral course or internship validation signed by the **Legal Representative** or the head of **Human Resources**, and in no case, by the student.
2.   RUT (Tax Registración Number).
3.   Certificate of existence of the Company issued by the Chamber of Commerce.
4.   The letter must contain information such as Tax identification number (NIT), Company name, address, email where they receive electronic invoice, amount to be billed, and indicate if invoice is to be paid by cash or credit.

Under no circumstances, should payments be made in a personal capacity, that is, in the name of the student, In such cases we will not be able to issue a receipt or register the payment in the name of the Company.

To learn about other payment methods, click [**here**](https://www.eafit.edu.co/becas-y-financiacion).

If you need support with any payment method, please write to [apoyofianciero@eafit.edu.co](mailto:apoyofianciero@eafit.edu.co).

###### Payment at the cash teller - EAFIT Treasury

Mixed Payments that include cards and checks can be made at the Treasury Offices as follows:

1.   Credit Card + Check.
2.   Credit Card + Cash.

###### Educational financial aid 'EAFIT at your fingertips'

Applicants admitted who financial aid may apply for short and long-term loans.

This initiative also contemplates a semester quota in which priority will be given to those with the best academic merits.

For more information on financial aid, write to [**financiacion@eafit.edu.co**](mailto:financiacion@eafit.edu.co), contact our customer service line (604) 2619500 or consult the following website [**here**](https://www.eafit.edu.co/becas-y-financiacion).

[Student ID](https://www.eafit.edu.co/en/posgrados#4257225834-3543329415)

Student ID

###### **Tramita tu carné de estudiante**

Para nosotros eres muy importante y nos alegra que seas parte de nuestros Eafitenses.

Te informamos el paso a paso para que solicites tu carné y puedas disfrutar de nuestro campus.

1.   Asegúrate que tu documento de identidad este actualizado en el sistema EPIK, de lo contrario debes tráelo al bloque 29, 1 piso, ¡En Registro Académico!
2.   Presenta el documento de identidad en la oficina de Carnetización, ubicada en el bloque 3, oficina 106. el día que te corresponda.
3.   ¡Prepárate para la foto! No debes traer prendas blancas.

**Horarios de atención de Carnetización:** lunes a viernes de 8:00 a.m. a 12:00 m. y de 2:00 p.m. a 6:00 p.m. y los sábados de 8:00 a.m. a 12:00 p.m.

**El carné se puede reclamar, a los 4 días de haberlo tramitado, en las taquillas de Registro Académico.**

Horarios de atención de Registro: lunes a viernes de **8:00 a.m. a 6:00 p.m.** jornada continua.

**¡Te esperamos!**

**Nota: Recuerda que para realizar el trámite de tu carné primero debes realizar el pago de tu matrícula. Para más información da clic**[**aquí**](https://www.tiktok.com/@eafit/video/7250107461535943942)**.**

[![Image 106](https://universidadeafit.widen.net/content/9fc15555-fb1e-4e19-a258-b46db2574036/web/Pregrado-comunicacion-social-9.jpg?crop=yes&k=c&w=1920&h=788&itok=xQDf3gXq)](https://www.eafit.edu.co/en/posgrados)

![Image 107](https://www.eafit.edu.co/en/posgrados)

## Begin your registration process

The process has a cost of $341.700 COP.

[Register here](https://mcu.azureedge.net/?site=MCU_003&cmd=login)

Our Schools

## Management

[See more about our Management school](https://www.eafit.edu.co/escuela-administracion)

## Applied Sciences and Engineering

[See more about our Applied Sciences and Engineering school](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria)

## Arts and Humanities

[See more about our Arts and Humanities school](https://www.eafit.edu.co/escuela-artes-humanidades)

## Law

[See more about our Law school](https://www.eafit.edu.co/escuela-derecho)

## Finance, Economy and Government

[See more about our Finance, Economy and Government school](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno)

![Image 108: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## 3.500

active students

## 42.000

graduates

![Image 109: Imagen 3.500 ](https://universidadeafit.widen.net/content/fd916074-852d-4f19-a53f-427811c609a9/web/posgrados-fotos-generales20.jpg?itok=t2mcXqjW)

![Image 110: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 111: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 112: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 113: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 114: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 115: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 116: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 117: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Our undergraduates](https://www.eafit.edu.co/en/pregrados)
*   [Our postgraduates programs](https://www.eafit.edu.co/en/posgrados)
*   [Other programs](https://www.eafit.edu.co/en/otros-programas)
*   [Learn about tuition and fees](https://www.eafit.edu.co/en/node/1171)
*   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

Conéctate con EAFIT

*   [Transform with us](https://www.eafit.edu.co/en/node/43361)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/en/node/30186)
*   [Work with us](https://www.eafit.edu.co/en/node/45751)

Contáctanos

*   [Register a PQRSF](https://www.eafit.edu.co/en/node/45736)
*   [Visitor center](https://www.eafit.edu.co/en/node/45661)
*   [Transparency line](https://www.eafit.edu.co/en/node/42081)

Información de ley

*   [Legal Status](https://www.eafit.edu.co/en/node/42106)
*   [Regulations and statutes](https://www.eafit.edu.co/en/node/35101)
*   [Gender, diversity and inclusion](https://www.eafit.edu.co/en/node/38366)
*   [Legal notices and certificates](https://www.eafit.edu.co/en/node/42111)
*   [Update your information](https://www.eafit.edu.co/en/node/45776)
*   [Data protection policy](https://www.eafit.edu.co/en/node/15276)
*   [Terms of use](https://www.eafit.edu.co/en/node/42146)

[Map of the website](https://www.eafit.edu.co/en/posgrados#mapa-del-sitio)

Institutional Accreditation until 2026.

Supervised by Ministry of Education.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/en/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Our campuses

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellin](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

National line: 01 8000 515 900

Service line: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Service line: (57) 606 3214115, 606 3214119

[EAFIT Bogota](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Service line: (57) 601 6114618

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego – Rionegro

![Image 118](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
