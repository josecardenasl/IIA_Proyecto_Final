Title: ​​Apropiación Social del Conocimiento (ASC)​

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social

Markdown Content:
# ​​Apropiación Social del Conocimiento (ASC)​
[Pasar al contenido principal](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 2: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social#)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social# "Spanish")[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social# "English")

 Información para ti

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 6: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 7: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 8: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 9: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 10: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 12: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 13: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 14: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 15: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 16: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 17: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 18: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 19: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 20: Imagen de banner estudiantes felices ](https://universidadeafit.widen.net/content/4e70dd4a-8e9b-4443-9dfd-2dc74651de71/web/estudiantes2.jpg?crop=yes&k=c&w=1920&h=788&itok=f_KMjKG0)

# ​​Apropiación Social del Conocimiento (ASC)​

Es un proceso participativo e intencionado en el que diferentes actores dialogan e intercambian saberes para transformar realidades.

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*    ​​Apropiación Social del Conocimiento (ASC)​ 

###### ¿Qué es ASC?

De acuerdo con la [Política Pública de Apropiación Social del Conocimiento](https://universidadeafit.widen.net/s/6ggg9szm56/resolucion-0643-2021), la ASC es un proce​​so intencionado q​ue convoca a todos los actores sociales a participar de prácticas de intercambio, diálogo, análisis, reflexión y negociación que promueven la comprensión e intervención de sus contextos.

La ASC se genera mediante la gestión, producción y aplicación de la ciencia, la tecnología y la innovación (CTeI)​ en entornos de confianza, equidad e inclusión, haciendo posible la transformación de realidades y la generación de bienestar social. La ASC es un concepto clave del Sistema Nacional de CTeI colombiano, transversal a las actividades de investigación, desarrollo y transferencia tecnológica, innovación, comunicación pública de la ciencia y formación de talento científico.

La ASC se relaciona, pero no se limita, a conceptos como: divulgación científica, democratización del conocimiento, impacto social de la investigación, investigación participativa, innovación social, extensión universitaria, science engagement, translative research, outreach, entre otros.

En el más reciente [Modelo de Medición de Grupos de Investigación](https://minciencias.gov.co/sistemas-informacion/modelo-medicion-grupos) de Minciencias, los procesos de ASC se posicionan como componentes centrales del quehacer investigativo y científico de nuestro país. En la Universidad EAFIT, son los [catálogos de ciencia, tecnología e innovación](https://www.eafit.edu.co/profes-que-inspiran/estatuto-profesoral) los que definen los procesos de ASC que incentiva el más reciente estatuto profesoral de la Universidad.

Minciencias​ reconoce cuatro procesos específicos de **ASC**, que están relacionados pero no se reducen a los productos de divulgación publica de la ciencia (**DPC**) y circulación de conocimiento especalizado (**CCE**):​

###### Procesos específicos ASC:

Fortalecimiento o solución de asuntos de interés social​ (FIS).

Trabajo conjunto entre un Centro de Ciencia y un grupo de investigación (TCCG).

Generación de insumos de política pública y normatividad (GPP).

Fortalecimiento de cadenas productivas (FCP)​​​​.

[Descarga aquí el Manual de procesos ASC para su reporte en la Plataforma SCIENTI](https://universidadeafit.widen.net/s/zfzqlzpxph/procesos-apropiacion-social-conocimiento-2023)

###### Productos de divulgacion pública de la ciencia (DPC):

Publicaciones editoriales no especializadas (PEE).

Producciones de contenido digital (audiovisual, sonoro, gráfico) (PCD).

Producción de estrategias y contenidos transmedia (TRM).

Desarrol​los web (DW).

[Descarga aquí el Manual de productos DPC para su reporte en la Plataforma SCIENTI](https://universidadeafit.widen.net/s/gnmtcqkxpx/productos-divulgacion-publica-ciencia-2023)

###### Productos de circulación de conocimiento especializado (CCE):​​​​​

Consultoría científico tecnológica.

Documento de trabajo.

Edición.

Evento científico.

Informes.

Nueva secuencia genética.

Red de conocimiento especializado.

[Experiencias dest​acadas de ASC en EAFIT](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social#230548828-2845972241)

[![Image 21: Portada Intercambios horizontales y bidireccionales: Apropiacion Social del Conocimiento](https://universidadeafit.widen.net/content/82db5322-be1b-41aa-a6cc-fa4c704aacb6/web/intercambios-horizonlales-bidirrecionales-eafit.jpg)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social)

![Image 22](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social)

###### Libro "Intercambios horizontales y bidireccionales: Apropiacion Social del Conocimiento"

Esta publicación del Área de ASC y Divulgación de EAFIT busca servir a diversas comunidades, ya sean académicas o no, para concebir, diseñar y gestionar proyectos de CTeI que fomenten la cocreación de conocimientos con poder transformador.​

Contiene definiciones, casos de estudio de procesos ASC, contexto histórico y político sobre ASC, recomendaciones para la gestión de proyectos y las comunicaciones en proyectos de CTeI, etc.

**Consulta en:**[https://doi.org/10.17230/9789587208788lr0](https://repository.eafit.edu.co/items/2ba465fc-b28e-432f-938f-cc6ec99cb375)

[Proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social#230548828-9078052)

[Tenemos que hablar Colombia](https://tenemosquehablarcolombia.co/).

[SIATA: Sistema de Alertas Tempranas del Valle de A​​burrá](https://siata.gov.co/siata_nuevo/) (proyecto del Área Metropolitana del Valle de Aburrá operado por EAFIT).

[Gobernanza climática en el Valle de Aburrá.](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-social-de-conocimiento-sobre-cambio-climatico)

[Laboratorio de Cultura​ Ciudadana de Medellín​.](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacionlaboratorio-cultura-ciudadana-medellin)

[Actualización Política Pública de Cultura Ciudadana de Medellín.](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion/la-politica-publica-de-cultura-ciudadana-avanza-hacia-la-consolidacion)

[Actualización Política Pública de Igualdad de Género de Medellín.​](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion/politica-publica-de-mujeres)

[Actualización Política Pública de Juventud de Medellín.​​​​](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/recursos-informacion/revistas)

[Expedición Colombia BioAnorí.​​​](https://www.eafit.edu.co/noticias/con-tesoros-cientificos-termino-la-expedicion-colombia-bio-anori)

[Saberes de Monte​​​](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/saberes-de-monte): mecanismos para la protección de la común-unidad. El caso de Nuquí, Chocó.

[Ciencia entre montañas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/ciencia-entre-montanas-transferencia-metodologica-en-la-provincia-cartama): transferencia metodológica de la Universidad de los niños en la Provincia Cartama​.​

[Exploradores de la geología regional​.​](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion/exploradores-de-la-geologia-regional)

[Las Georutas graníticas en el Museo Histórico del municipio de El Peñol​.](http://www.scielo.org.co/scielo.php?script=sci_arttext&pid=S0120-36302020000100005)

[Geografía de la guerra.](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion/geografia-de-la-guerra-para-la-apropiacion-social-del-conocimiento)

[Re-habitar la ladera.](https://www.eafit.edu.co/conexion-asuntos-publicos/centros-estudio-incidencia/urbam/produccion-urbam)

[​Gu​ardianes de historias](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/con-la-ciencia-en-la-cabeza-el-radiality/guardianes-de-historias-apropiacion-de-tecnologias-con-ninos-zenu): apropiación de tecnologías con niños Zenú en Caucasia, Antioquia​.

​[Documental "Sin bata y con botas".](https://www.eafit.edu.co/noticias/sin-bata-y-con-botas-asi-exploraron-eafitenses-el-parque-nacional-las-orquideas)

[Con la ciencia en la cabeza, ¡el radiality!](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos/con-la-ciencia-en-la-cabeza-el-radiality)

[Hermilda: divulgación de las ciencias de la vida para niños​.](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion/hermilda)

[Caja de herramientas](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social#230548828-2888074699)

[Haz clic aquí para acceder a la caja de herramientas.](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion#4257225834-1111474546)

[Asesoría sobre ASC y DPC​](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/apropiacion-conocimiento-social#230548828-3702072628)

###### Asesoría sobre ASC y DPC​

El Área de ASC y Divulgación de la [Vicerrectoría de Ciencia Tecnología e Innovación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion) ofrece el servicio de asesoría​s especializadas para el desarrollo de actividades académicas e investigativas con enfoque de ASC y DPC, para fortalecer capacidades para co-crear conocimiento trasformador con otros.

Con la asesoría especializada en ASC y DPC, podrás identificar retos y oportunidades en tus procesos académicos e investigativos que convoquen la participación de públicos no especializados, organizaciones de base comunitaria, comunidades campesinas, pueblos indígenas y afro, niños, niñas y adolescentes, entre otros. Además, podrás priorizar acciones a corto, mediano y largo plazo para alcanzar tus objetivos de investigación con enfoque o componentes de ASC y DPC.

Para solicitar una asesoría​​​ escribe al correo: [clopezot@eafit.edu.co​](mailto:clopezot@eafit.edu.co%E2%80%8B)

###### Conoce más sobre ​​ASC

​Libro "Intercambios horizontales y bidireccionales: Apropiacion Social del Conocimiento".

[Revista Universidad EAFIT Vol. 55 Núm. 176 (2020)](https://publicaciones.eafit.edu.co/index.php/revista-universidad-eafit/issue/view/598): "Apropiación​ Social del Conocimiento: democratización de los saberes"​.

[Politica Nacional de Ciencia Tecnología e Innovación (CTeI)](https://minciencias.gov.co/sites/default/files/documento_conpes_ciencia_tecnologia_e_innovacion.pdf)​.

[Política Pública de Apropiación Social del Conocimiento (ASC)](https://minciencias.gov.co/sites/default/files/upload/reglamentacion/resolucion_0643-2021.pdf)​.

[Modelo de Medición de Grupos de Investigación 2021](https://minciencias.gov.co/sistemas-informacion/modelo-medicion-grupos).

Portal web "[Apropia con sentido](https://apropiaconsentido.minciencias.gov.co/)" del Ministerio de Ciencia, Tecnología e Innovación.

Documento [Estrategia Nacional de ASC](https://minciencias.gov.co/sites/default/files/ckeditor_files/estrategia-nacional-apropiacionsocial.pdf) en Colombia.

Repositorio de documentos para​ el [Diseño de politicas de CTeI de Minciencias](https://minciencias.gov.co/portafolio/unidad-politica/lineas-trabajo/documentos-politica-ctei).

Documento "[Ciencia, tecnología y democracia: Reflexiones en torno a la apropiación social del conocimiento](https://universidadeafit.widen.net/s/zvl2fp87wz/ciencia-tecnologia-democracia)".​

Revista ​[Apropiación Social del Conocimiento: el papel de la comunicación](https://issuu.com/mauriciocastanograjales/docs/memorias_diplomado_virtual).

Artículo "​[Conectar comunid​ades para construir sentidos sociales en torno al conocimiento](https://revistas.itm.edu.co/index.php/trilogia/article/view/400)".

Artículo "[Cuando la apropiación social de la ciencia y tecnología es objeto de 'gestión'. Una reflexión desde el caso colombiano](https://revistas.itm.edu.co/index.php/trilogia/article/view/401)".

Artículo "[Iniciativas de Apropiación Social de la Ciencia y la Tecnología en Colombia: tendencias y retos para una comprensión más amplia de estas dinámicas](https://www.scielo.br/j/hcsm/a/6VqqGmrNfbZgKxrnmLMZmXR/?lang=es)".

![Image 23: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 24: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 25: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 26: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 27: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 28: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 29: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 30: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
