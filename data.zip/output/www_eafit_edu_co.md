Title: ¡Te damos la bienvenida a la Universidad EAFIT!

URL Source: https://www.eafit.edu.co/

Published Time: Fri, 08 May 2026 14:35:17 GMT

Markdown Content:
# ¡Te damos la bienvenida a la Universidad EAFIT! - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/#main-content)

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 12: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 13: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/#)

[![Image 14: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/# "Spanish")[![Image 15: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/# "English")

 Información para ti

[![Image 16: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 17: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 18: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 19: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 20: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 21: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 22: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 23: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 24: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 25: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 26: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 27: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 28: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 29: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 30: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 31: 66 razones](https://universidadeafit.widen.net/content/9d72eb34-2190-4db6-b924-9d59fd27baab/web/66razoneseafitenses.jpg?crop=yes&k=c&w=1920&h=788&itok=jq4U091j)

#### 66 razones que hoy nos llenan de orgullo eafitense y seguimos contando.

# ¡Ya son 66 años impactando!

[Conócelas aquí](https://www.youtube.com/watch?v=T474AZyc-BA)

![Image 32: Becas Talento y Aliados pregrado (Nutresa, Santa Ana y Aurelio Llano)](https://universidadeafit.widen.net/content/fd7396ab-bd36-4e74-9356-106f34e127ef/web/Digitales-Becas-Talento-2025_AS_banner.jpg?crop=yes&k=c&w=1920&h=788&itok=11hG0cGt)

# **Becas Talento y Aliados pregrado**

###### **(Nutresa, Santa Ana, F.E. Suiza y Aurelio Llano)**

Postúlate del 10 de marzo al 24 de mayo de 2026

[Conoce los detalles](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit)

![Image 33: Imagen de estudiantes de posgrado](https://universidadeafit.widen.net/content/f085808c-7a94-4731-8edc-a63b1505d5c0/web/bannerinscripcionesposgrado2025.jpg?crop=yes&k=c&w=1920&h=788&itok=NJUXfaZL)

# Inscripciones abiertas posgrado 2026-2

[Ingresa aquí](https://www.eafit.edu.co/posgrados)

[Pregrados](https://www.eafit.edu.co/pregrados)[Posgrados](https://www.eafit.edu.co/posgrados)[Otros programas](https://www.eafit.edu.co/otros-programas)[Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)[Transforma con nosotros](https://www.eafit.edu.co/filantropia)

Buscar 

En EAFIT somos...

## Conexiones que transforman

[Conoce las conexiones](https://www.eafit.edu.co/organizaciones)

![Image 34: Propileos ](https://universidadeafit.widen.net/content/1adb008d-8bc8-4462-815e-a01348cc3a10/web/propileos.jpg?w=480&itok=g_YURu6e)

## Excelencia

[Conoce más sobre la acreditación](https://www.eafit.edu.co/institucional/acreditacion)

![Image 35: Estudiantes de biotecnología en laboratorio](https://universidadeafit.widen.net/content/554ba457-a4d0-4297-8d6c-87605fbe513c/web/foto-articulo-tres-promesas-biotecnologia-1.jpg?w=480&itok=Jfv2v5ID)

## Campus vivo

[Conoce Campus vivo](https://www.eafit.edu.co/universidad-parque)

![Image 36: Imagen panorámica del campus EAFIT](https://universidadeafit.widen.net/content/fdb933da-5748-41a7-aef3-082e6489aede/web/Campus-PanoramicaFundadores-Bloque29-10.jpg?w=480&itok=GRWaDY9-)

## Ciencia, Tecnología e Innovación

[Conoce CTeI](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

![Image 37: Imagen autoevaluación estudiantes](https://universidadeafit.widen.net/content/c0d56ea9-b44f-4d0a-a5c7-3f32a5a6c843/web/estudiantes-autoevaluacion.jpg?w=480&itok=O-qimbno)

## Aprendizaje activo y experiencial

[Conoce nuestro PEI](https://www.eafit.edu.co/institucional/pei)

![Image 38: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

[Conoce más ![Image 39: Centro de ayuda](https://universidadeafit.widen.net/content/ffd74f6b-7395-49d8-b43a-aa1abb7467b9/web/sticky-CDA2.png)](https://www.eafit.edu.co/centro-de-ayuda "Botón sticky")[Contáctanos ![Image 40: Whatsapp](https://www.eafit.edu.co/sites/default/files/2024-09/sticky.svg)](https://api.whatsapp.com/send?phone=573108992908 "Botón sticky")

[Historias y noticias](https://www.eafit.edu.co/#4257225834-2385443158)

Historias y noticias

![Image 41: Imagen En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg?crop=yes&k=c&w=944&h=540&itok=qU5B_bcT)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)
###### En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones

Una red de agua helada con pérdidas de eficiencia, una selladora industrial que requería mejorar su confiabilidad, sistemas energéticos con alto consumo y procesos que podían automatizarse: esos son algunos de los retos de empresas del sector productivo que cruzaron la puerta del aula y que hoy c

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "Leer más")

Mayo 7, 2026

![Image 42: Imagen Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://universidadeafit.widen.net/content/c5dd5394-7a1b-46bc-93d4-e01ffbbe080a/web/Patente-caminador.png?crop=yes&k=c&w=944&h=540&itok=FBBbjkNw)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano

La movilidad es uno de los factores que más influye en la autonomía y la calidad de vida de las personas, especialmente en quienes enfrentan procesos de rehabilitación o dificultades para caminar.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado "Leer más")

Abril 30, 2026

![Image 43: Imagen EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://universidadeafit.widen.net/content/9e97e1f2-ee3f-46aa-a923-d0b06278bd58/web/campus-vivo-1500.jpg?crop=yes&k=c&w=944&h=540&itok=nVY7so_E)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología

La Plazoleta del Estudiante se transformó este miércoles 22 de abril en un espacio de experimentación y conexión con la _Muestra de iniciativas inspiradoras de aprendizaje experiencial_.

[Leer más](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y "Leer más")

Abril 23, 2026

![Image 44: Imagen La Editorial EAFIT llevará su catálogo a la Filbo 2026](https://universidadeafit.widen.net/content/06775a08-60ca-4910-be81-9ede92d51066/web/Catalogo-la-Filbo2026.jpg?crop=yes&k=c&w=944&h=540&itok=RwWozP6S)

[Arte y cultura](https://www.eafit.edu.co/taxonomy/term/1826)
###### La Editorial EAFIT llevará su catálogo a la Filbo 2026

La Feria Internacional del Libro de Bogotá (Filbo) es el escenario para el encuentro entre lectores, autores, editores, bibliotecas y distribuidores.

[Leer más](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/la-editorial-eafit-llevara-su-catalogo-la-filbo-2026 "Leer más")

Abril 22, 2026

[Conoce todas las historias y noticias](https://www.eafit.edu.co/noticias)

[Agenda y eventos](https://www.eafit.edu.co/#4257225834-156214721)

Agenda y eventos

![Image 45: Imagen Beca Excelencia y Liderazgo Nutresa–EAFIT: postulaciones abiertas](https://universidadeafit.widen.net/content/3366cbdb-33ee-4ae0-b306-5a6b823a8615/web/69becas-Nutresa.jpg)

## Beca Excelencia y Liderazgo Nutresa–EAFIT: postulaciones abiertas

Dom, 10/05/2026 - 09:00

[Conoce más](https://www.eafit.edu.co/calendario-eventos/beca-excelencia-y-liderazgo-nutresa-eafit-postulaciones-abiertas)

![Image 46: Imagen Game Over: cuando la danza se convierte en juego](https://universidadeafit.widen.net/content/67cf29fa-0fd5-4b5b-9b29-1837d02e1b86/web/game-over-evento-bienestar.jpg)

## Game Over: cuando la danza se convierte en juego

Mar, 12/05/2026 - 07:00

Auditorio Fundadores

[Conoce más](https://www.eafit.edu.co/calendario-eventos/game-over-cuando-la-danza-se-convierte-en-juego)

![Image 47: Imagen Cátedra Hidroituango S.A.](https://universidadeafit.widen.net/content/330cae34-ca0a-4f3b-bd12-36840e4ffbdd/web/Banner-portafolio.jpg)

## Cátedra Hidroituango S.A.

Mar, 12/05/2026 - 15:00

Bloque 19, aula 501

[Conoce más](https://www.eafit.edu.co/calendario-eventos/catedra-hidroituango-sa)

[Conoce más eventos](https://www.eafit.edu.co/calendario-eventos)

[Publicaciones](https://www.eafit.edu.co/#4257225834-2259898159)

Publicaciones

## Revista El Eafitense

Edición 122

 ¿Cómo hackear el futuro?

[Conoce la edición](https://www.eafit.edu.co/noticias/publicaciones/el-eafitense/edicion-122)

## Descubre y Crea

Edición 180

[Conoce la edición](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/descubre-y-crea/edicion-180)

## Somos Futuro

Edición 180

[Conoce la publicación](https://www.eafit.edu.co/somos-180)

![Image 48: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

[Canal EAFIT+](https://www.eafit.edu.co/#4257225834-885112434)

Canal EAFIT+

#### **Lo más reciente**

#### Explorar, experimentar y escalar: la receta de Nequi para innovar

#### In-Sight: ¿Conversaciones difíciles con tu jefe? ¿Cómo abordarlas?

#### Modo Laboral | In-Sight: ¿Por qué el poder daña a los buenos líderes?

[Conoce EAFIT+](https://mas.eafit.edu.co/)

![Image 49: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 50: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 51: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 52: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 53: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 54: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 55: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 56: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 59](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
