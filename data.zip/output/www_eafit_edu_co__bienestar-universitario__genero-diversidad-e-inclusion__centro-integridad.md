Title: Centro de Integridad​​

URL Source: https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad

Markdown Content:
# Centro de Integridad​​ - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner estudiantes regreso clases ](https://universidadeafit.widen.net/content/485234a3-95cd-4a6e-8529-655b86bdecc3/web/Foto-estudiantesRegresoclases-027.jpg?crop=yes&k=c&w=1920&h=788&itok=_8ko34yZ)

# Centro de Integridad​​

###### El Centro fue una dependencia que promovió la reflexión ética, fomentando la educación con sentido y generó procesos edificantes. Hoy se ha transformado en la oficina de Género y Diversidad. Aquí la memoria de esta dependencia

*   [Inicio](https://www.eafit.edu.co/)
*   [Bienestar Universitario](https://www.eafit.edu.co/bienestar-universitario)
*   [Género, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*    Centro de Integridad​​ 

[![Image 22: Imagen de Gráfico Centro de integridad](https://universidadeafit.widen.net/content/46454ee9-f2bd-4e23-9155-1d65e52705d1/web/centro-integridad-4.png)](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad)

![Image 23](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad)

###### ​​​¿Qué era el Centro de Integridad?

## Misión

Fomentar una reflexión ética –individual y colectiva– en la comunidad eafitense que permita una formación humana y profesional, y a su vez contribuya a edificar una cultura de integridad en la Universidad y en la sociedad.​

## Visión

En el 2030 el Centro de Integridad de la Universidad EAFIT habrá inspirado la reflexión ética en la comunidad eafitense y su entorno, creado los cimientos necesarios para el desarrollo de una cultura de integridad y transformado los paradigmas que obstaculizan la coherencia entre el pensar, el sentir y el actuar de manera virtuosa.​​​​

## Ejes

El Centro desarrollaba sus acciones en tres ejes:​​​

 ​Educativo

 Investigativo

 De proyección

###### Objetivos del Centro de Integridad​​

Propiciar una deliberación colectiva y multidisciplinaria sobre la ética y la integridad académica en los diferentes ámbitos, tanto internos como externos a la Universidad.

​Incidir desde los principios de la ética discursiva en aquellas acciones, paradigmas y estereotipos que afectan los principios de la cultura ciudadana y la integridad académica.

Fomentar la apropiación de los Valores Institucionales de la Universidad EAFIT por medio de la interiorización consciente de las normas morales, legales y culturales, encaminada a la edificación de una cultura de integridad.

Acompañar a los docentes y estudiantes de la Universidad a lograr una excelencia en el ámbito académico e investigativo, caracterizada por la integridad.

Contribuir al campo de la ética aplicada a través del estudio de los retos morales contemporáneos, desde la investigación y la divulgación científica

###### ¿Qué es integridad?​

La integridad es el valor supremo de nuestra Universidad, en cuanto le provee horizonte moral a los demás valores institucionales. Integridad da cuenta de completud, de excelencia moral, de un actuar honesto y transparente, en el que la persona -consciente de su limitación humana- intenta cada día vivir de una manera respetuosa y generadora de bienestar para sí, para otros y para la naturaleza. La integridad es la coherencia entre el pensar, el decir y el hacer, siempre bajo principios éticos universales que buscan la justicia, la equidad y la inclusión. Tomado de: Valores Institucionales

###### ¿Qué es integridad académica?​

La integridad académica es un compromiso constante frente a la honestidad, la confianza, la justicia, el respeto, la responsabilidad y el coraje. Incluso en tiempos de adversidad.

**Tomado de: Centro Internacional de Integridad Académica​ - ICAI (1999:4) ​​​​​**

##### Atreverse a pensar​​

###### ¿Qué fue Atreverse a Pensar?​​​

Atreverse a Pensar inicia su construcción hacia finales de 2010 a raíz de la preocupación de representantes estudiantiles, directivas y docentes de la Universidad EAFIT, en torno al incremento en las prácticas deshonestas en las diferentes comunidades académicas en el país y en el mundo. Adicionalmente, en los últimos años las diferentes instituciones de educación superior en Colombia han visto cómo el plagio, manifestado sobre todo en copiar y pegar de Internet o de libros, sin la apropiada citación, se ha vuelto una práctica frecuente entre los estudiantes, e incluso, entre algunos pocos docentes.​

Para esto, se decidió abordar el fraude académico más ampliamente partiendo de la tesis de que éste es una manifestación de un problema sociocultural y de un sistema de valores y creencias de los colombianos, y no obedece solo una conducta específica. En ese sentido, se planteó la siguiente hipótesis: El culto a la viveza, tan imperante en esta sociedad, lleva a justificar en gran medida el incumplimiento de normas, aludiendo a decenas de razones, que en últimas hacen que cada quien defina su código moral y que la ética termine siendo relativa a cada individuo. En ese contexto, la ética, la integridad y la responsabilidad son valores que se ven amenazados diariamente, tanto en el contexto académico como en el de la vida cotidiana.

Aunque no hay evidencia científica de que quien comete fraude académico necesariamente será un corrupto, o quien tira basura a la calle llegará a ser un empleado deshonesto, no es aventurado afirmar que quien no acata las normas y a menudo encuentra caminos para evadirlas – tengan éstas o no sanción de alguna naturaleza – desarrolla dentro de sí un sistema de creencias y unos hábitos que lo influenciarán en distintos momentos y contextos de su vida a actuar en forma poco íntegra, incluso sin ser consciente de que lo está haciendo.​

Por lo tanto, se crea este programa institucional​ orientado a la prevención y erradicación de cualquier forma de fraude académico o administrativo, y a garantizar el pleno respeto de los derechos de autor por parte de estudiantes y profesores, en todas las actividades académicas, a través de la deliberación y reflexión sobre estos diferentes fenómenos que tanto daño le están haciendo al país.

Según Juan Luis Mejía, exrector de EAFIT, la Universidad, en su papel de formador de profesionales y educador de ciudadanos, cree que debe hacer un alto en el camino y abrir un espacio para poner estos asuntos en la conversación y el análisis de la comunidad eafitense. Si bien la Universidad es consciente de que en la ética de los ciudadanos influyen un sinnúmero de factores, sí cree urgente que la posición de nuestra comunidad universitaria frente​ a conductas como la corrupción, la deshonestidad, la mal entendida viveza paisa y el engaño, sea cuestionada.

Fases​

![Image 24: Imagen Primera​​ fase: Culto a la viveza​](https://universidadeafit.widen.net/content/7faebd8b-a935-4187-84e5-a63cfb1ef063/web/fase-1-destacado.jpg)

Primera​​ fase: Culto a la viveza​

El culto a la viveza es un fenómeno con el que conviven los colombianos día a día. Se manifiesta en diversos contextos: la manera agresiva al conducir para pasarse al otro, la compra y venta de películas piratas, la evasión de impuestos por parte de personas naturales y jurídicas, la actitud ventajosa en los negocios,​ y la compra y venta de artículos de contrabando, entre muchos otros.

[Leer más](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-de-comunicacion-y-dialogos)

![Image 25: Imagen Segunda fase: Ética y academia](https://universidadeafit.widen.net/content/1b5a2d60-5fa1-4a66-8874-e0d6ccddf407/web/fase-2-destacado.jpg)

Segunda fase: Ética y academia

En septiembre de 2011 inició una nueva etapa que se concentró en la ética y la academia, una relación que por la naturaleza y la responsabilidad del acto educativo en la universidad debería ser armoniosa pero que, lamentablemente, se rompe con bastante frecuencia. Ahora, ¿qué tiene que ver el culto a la viveza con el fraude académico? Todo.

[Leer más](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-de-comunicacion-y-dialogos)

![Image 26: Imagen Tercera fase: Cultura ciudadana](https://universidadeafit.widen.net/content/a6f8def1-f589-44b5-a419-ff74284f71a1/web/fase-3-destacado.jpg)

Tercera fase: Cultura ciudadana

El proyecto Atreverse a Pensar llega a su tercera fase: cultura ciudadana, entendida esta como el conjunto de costumbres, acciones y reglas mínimas compartidas que generan sentido de pertenencia, facilitan la convivencia urbana y conducen al respeto del patrimonio común, y al reconocimiento de los derechos y deberes ciudadanos.

[Leer más](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-de-comunicacion-y-dialogos)

![Image 27: Imagen Cuarta fase: Ser mejor](https://universidadeafit.widen.net/content/0ecf707c-08b2-4c0f-911f-35cf9baa4114/web/fase-4-destacado.jpg)

Cuarta fase: Ser mejor

La Universidad EAFIT, en 2012, decidió apostar por la transformación cultural de la comunidad universitaria a través de la definición de Atreverse a Pensar como un programa institucional permanente "orientado a la prevención y erradicación de cualquier forma de fraude académico o administrativo, y a garantizar el pleno respeto de los derechos de autor por parte de estudiantes y profesores, en todas las actividades académicas" (i).

[Leer más](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-de-comunicacion-y-dialogos)

![Image 28: Imagen Quinta fase: Integridad acadé​mica](https://universidadeafit.widen.net/content/228ad29a-42c9-4c23-be95-548c633d8005/web/fase-5-destacado.jpg)

Quinta fase: Integridad acadé​mica

La quinta fase del programa institucional Atreverse a Pensar tiene como tema la integridad académica. Este componente es el eje central de esta parte de la iniciativa que, a través de nuevas frases, imágenes y reflexiones, plantea y refuerza en la comunidad​ académica y universitaria el propósito de esta propuesta permanente de la Universidad que surgió hacia fines de 2010.

[Leer más](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-de-comunicacion-y-dialogos)

![Image 29: Imagen Sexta fase: Atreverse a Pensar​](https://universidadeafit.widen.net/content/be297119-ef9b-4c70-905b-62e20c9af8d1/web/fase-6.jpg)

Sexta fase: Atreverse a Pensar​

"En esta fase se busca una reflexión para mostrar que esas situaciones que tienen un tinte problemático para la ética académica hay que saberlas resolver, pues muchas veces no nos tocan como estudiantes, sino como amigos y consejeros de otros que pueden estar enfrentándolas", comenta Juan Rafael Peláez Arango, analista de Atreverse a Pensar.

[Leer más](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion/centro-integridad/fases-de-comunicacion-y-dialogos)

![Image 30: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 31: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 32: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 33: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 34: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 35: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 36: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 37: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 40](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
