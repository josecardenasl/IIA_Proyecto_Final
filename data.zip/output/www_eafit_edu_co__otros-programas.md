Title: Otros programas

URL Source: https://www.eafit.edu.co/otros-programas

Published Time: Thu, 07 May 2026 20:25:54 GMT

Markdown Content:
# Otros Programas - EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/otros-programas#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/otros-programas#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/otros-programas# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/otros-programas# "English")

*   [Spanish](https://www.eafit.edu.co/otros-programas)
*   [Inglés](https://www.eafit.edu.co/en/otros-programas)

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner Grupo de cinco personas sonrientes posando en un ambiente moderno con fondo de plantas y estructuras metálicas](https://universidadeafit.widen.net/content/25c92bb3-5edf-4867-ba0e-9e2c5348efcf/web/otros-programas-v2.jpg?crop=yes&k=c&w=1920&h=788&itok=i74L36l6)

# Otros programas

Un espacio creado para la transformación del conocimiento y el desarrollo de nuevas habilidades y competencias.

*   [Inicio](https://www.eafit.edu.co/)
*    Otros Programas 

## Cursos y diplomados

Desarrolla capacidades clave y actualiza tu conocimiento de manera flexible y accesible.

[Conoce los cursos y diplomados](https://ecommerce.eafit.edu.co/es/cursos-y-diplomados)

## Alta Dirección

Acompañamos a directivos y empresas en el fortalecimiento de capacidades estratégicas y competitivas con programas que equilibran conocimiento, práctica y valores.

[Conoce Alta Dirección](https://ecommerce.eafit.edu.co/es/alta-direccion)

## Saberes de Vida

Saberes de Vida cultiva curiosidad y nuevos sentidos de vida, fomentando la interacción con el entorno, la integridad, la excelencia, el pluralismo y la inclusión.

[Conoce Saberes de Vida](https://ecommerce.eafit.edu.co/es/saberes-de-vida)

## Música

La música es una herramienta invaluable para el desarrollo de la sensibilidad, la creatividad y la socialización del ser humano.

[Conoce los programas de música](https://ecommerce.eafit.edu.co/es/musica)

## Rutas de Aprendizaje

Representan el camino hacia un perfil laboral deseado, con cursos que desarrollan, fortalecen y certifican competencias, habilidades y conocimientos específicos.

[Conoce Rutas de Aprendizaje](https://ecommerce.eafit.edu.co/es/rutas-de-aprendizaje)

## Eventos

Ofrecemos una variedad de eventos, con y sin recaudación, diseñados para enriquecer la experiencia académica y cultural de la comunidad en general.

[Conoce nuestros eventos](https://www.eafit.edu.co/otros-programas/eventos)

## Universidad de los Niños

Fomentamos el descubrimiento de niños, niñas y adolescentes de manera inclusiva y divertida a través del juego, la pregunta, la experimentación y la conversación.

[Conoce nuestra oferta para niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)

## Idiomas

Con más de 30 años en la enseñanza de idiomas, transformamos vidas y creamos oportunidades para una comunicación efectiva en un mundo intercultural.

[Conoce idiomas](https://www.eafit.edu.co/idiomas)

## On.going

Somos el centro de emprendimiento de impacto de la Universidad EAFIT, un universo donde potenciamos ideas capaces de transformar el mundo.

[Conoce On.going](https://ecommerce.eafit.edu.co/es/ongoing)

## Nodo

Somos el centro de formación en nuevas tecnologías de EAFIT. Aprendizaje real, práctico y colaborativo para transformar vidas y comunidades.

[Conoce Nodo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/nodo)

## Cursos para empresas

Sabemos que tu organización necesita equipos capacitados; por eso, ofrecemos programas de formación adaptados al contexto de tu sector.

[Ver cursos para empresas](https://www.eafit.edu.co/otros-programas/cursos-para-empresas)

![Image 22: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

### Nuestra oferta virtual

## Virtual

Diplomados virtuales e inglés virtual para adultos

[Conoce más](https://virtual.eafit.edu.co/?utm_source=University+Site&utm_medium=Banner_home)

## Cursos cortos virtuales

Para mentes curiosas

[Conoce más](https://formacion.eafit.edu.co/cursos)

[¿Qué es educación continua?](https://www.eafit.edu.co/otros-programas#4257225834-945470082)

¿Qué es educación continua?

Educación Continua es un área que fomenta el aprendizaje a lo largo de la vida a través de conferencias, cursos, diplomados y programas de educación de corta y mediana duración, que se encuentran dentro de la modalidad de “educación no formal”, la cual, según el Ministerio de Educación, se ofrece con el objetivo de complementar, actualizar, suplir conocimientos y formar en aspectos académicos o laborales sin sujeción al sistema de niveles y grados establecidos para la educación formal, y está regulada por la Ley 115 de 1994 y los Decretos 114 de 1996 y 3011 de 1997. Estos programas son conducentes a certificaciones de asistencia y de competencias.

[Modalidades](https://www.eafit.edu.co/otros-programas#4257225834-3126382169)

Modalidades

1.   **Presencial:** en esta modalidad, el participante recibirá clases 100% presenciales en las instalaciones de EAFIT. No habrá opción para conexión en línea.
2.   **Online:**en esta modalidad, todos los encuentros serán sincrónicos a través de la plataforma Microsoft Teams.
3.   **Blended:** esta modalidad incluye una combinación de momentos sincrónicos y asincrónicos. Los momentos asincrónicos son horas de autogestión con contenidos virtuales que se impartirán en nuestra plataforma Interactiva Virtual. Los momentos sincrónicos serán encuentros a través de la plataforma Microsoft Teams o clases presenciales en las instalaciones de EAFIT, según sea el caso.
4.   **Bimodal:** en esta modalidad, el participante podrá recibir todas las clases de manera presencial en las instalaciones de EAFIT o tendrá la posibilidad de conectarse en línea a través de Microsoft Teams de manera sincrónica.
5.   **Virtual:** en la modalidad virtual solo se tienen estipulados momentos asincrónicos e implica la autogestión del participante, quien podrá encontrar el contenido del programa en la plataforma seleccionada para ello y recibirá la asesoría de un tutor o docente, quien se encargará de guiarlo a través del programa que esté realizando.

[Áreas de conocimiento](https://www.eafit.edu.co/otros-programas#4257225834-1958565416)

Áreas de conocimiento

###### **Administración**

1.   Organización, dirección y estrategia.
2.   Marketing e innovación.
3.   Gestión de la información y de riesgos.
4.   Gestión global.

###### **Finanzas, Economía y Gobierno**

1.   Políticas y desarrollo.
2.   Mercados y estrategia financiera.
3.   Macroeconomía y sistemas financieros.

###### **Ciencias Aplicadas e Ingeniería**

1.   Ciencias fundamentales.
2.   Sistemas naturales y sostenibilidad.
3.   Territorios y ciudades.
4.   Industria, materiales y energía.
5.   Computación y analítica.
6.   Diseño de producto y experiencias.
7.   Ciencias del cuidado y de la vida.

###### **Artes y humanidades**

1.   Lenguaje.
2.   Cultura.
3.   Creación.
4.   Música.

###### **Derecho**

1.   Ciencias jurídicas.

[Programas homologables](https://www.eafit.edu.co/otros-programas#4257225834-1449639768)

Programas homologables

Diplomados, cursos y otros programas de educación continua que pueden ser reconocidos por créditos en programas de pregrado o posgrado en laUniversidad EAFIT

[Conoce más](https://www.eafit.edu.co/otros-programas/programas-homologables)

Contacto 

¿Quieres saber más?

¡Déjanos tus datos!

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono de contacto*? 

Correo electrónico*? 

Ciudad de residencia*? 

Contenido de interés 

Cuéntanos, ¿Qué deseas saber?*? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 23](https://universidadeafit.widen.net/content/47feabff-d797-418a-a261-b87b409d955e/web/idiomas-eafit-sede-Poblado-1.jpg?crop=yes&k=c&w=470&h=272&itok=0RiCG_G5)

![Image 24: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 25: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 26: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 27: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 28: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 29: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 30: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 31: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 34](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
