Title: Campoenjuegofoto%20(3).jpg

URL Source: https://www.eafit.edu.co/sites/default/files/2026-04/Campoenjuegofoto%20(3).jpg

Published Time: Tue, 14 Apr 2026 22:19:11 GMT

Markdown Content:
# Campoenjuegofoto%20(3).jpg

Yellow pvc soccer figures of 5 weers with numerals 17 to 18
