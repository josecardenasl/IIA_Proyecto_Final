Title: ig.svg

URL Source: https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg

Published Time: Wed, 31 Jul 2024 02:33:37 GMT

Markdown Content:
# ig.svg

A 52x48 small image, likely a logo, icon or avatar
