Title: Empresas y negocios

URL Source: https://www.eafit.edu.co/taxonomy/term/1856

Published Time: Fri, 08 May 2026 15:41:34 GMT

Markdown Content:
## [En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en)

Mayo 7, 2026

**Optimizar el consumo energético, mejorar la confiabilidad de equipos y rediseñar procesos industriales son algunos de los retos que empresas del sector productivo llevan al aula y que hoy cuentan con soluciones desarrolladas por estudiantes de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT.**

**Desde la automatización de sistemas hasta la evaluación de alternativas sostenibles, los proyectos evidencian resultados clave: propuestas aplicables que impactan la operación empresarial y convierten el trabajo académico en respuestas prácticas para la industria.**

*   [Lee más sobre En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones")

Una red de agua helada con pérdidas de eficiencia, una selladora industrial que requería mejorar su confiabilidad, sistemas energéticos con alto consumo y procesos que podían automatizarse: esos son algunos de los retos de empresas del sector productivo que cruzaron la puerta del aula y que hoy cuentan con propuestas desarrolladas por estudiantes de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT. No se trata de ejercicios simulados, sino de necesidades reales que exigían diagnóstico, análisis técnico y soluciones viables.

En ese camino, compañías como [Alico](https://alicoempaques.com/), una empresa del sector alimenticio dedicada al diseño y producción de empaques flexibles, han convertido estos desafíos en proyectos conjuntos con estudiantes y profesores eafitenses que dejan capacidades instaladas en su operación. Los desarrollos incluyen diagnósticos para reducir ineficiencias, la evaluación de un sistema fotovoltaico, una propuesta de aislamiento térmico para selladoras, mejoras en el desempeño de maquinaria y análisis de viabilidad para incorporar nuevas tecnologías.

“La academia permite profundizar en análisis que, en el día a día operativo, no siempre es posible desarrollar con el mismo nivel de detalle. Los estudiantes y profesores aportan conocimiento actualizado, herramientas de análisis y enfoques innovadores que impulsan el desarrollo de soluciones tecnológicas y mejoras operativas”, afirma Ana Karenina García Barbarán, coordinadora de Innovación de la compañía. Desde su experiencia, la claridad en los retos y el seguimiento a los proyectos son determinantes para que este trabajo conjunto genere resultados.

Una experiencia similar comparte [Forjas Bolívar](https://www.forjasbolivar.com/), empresa de la industria metalmecánica que ha desarrollado seis proyectos estratégicos junto a estudiantes eafitenses. En su caso, las soluciones se han orientado al diseño mecánico, la automatización y la eficiencia energética. “Este vínculo permite una transferencia de conocimiento bidireccional de alto impacto. La Universidad nos permite enfrentar a estudiantes de nivel avanzado con dinámicas y retos reales, lo que se traduce en ganancias tangibles, desde la mejora de productos existentes hasta la resolución de problemas técnicos complejos”, señala Eddy Lara Bedoya, director de Ingeniería y Operaciones de la empresa.

Este tipo de experiencias evidencia cómo la relación entre universidad y empresa se proyecta más allá del aula y se transforma en un aporte directo al entorno productivo y social. Como lo menciona Eddy, “el impacto es trascendental: los estudiantes se anticipan a los retos de la industria nacional y las empresas contribuimos activamente a formar el talento del futuro”, quien además destaca que abrir estos espacios de colaboración, a partir de problemas reales y con confianza en las capacidades de los estudiantes, es clave para seguir fortaleciendo una relación que genera valor para todos los actores involucrados.

###### Aprender resolviendo

Tanto Alico como Forjas Bolívar se han vinculado a EAFIT a través de la asignatura Proyectos de trayectorias, que cuenta con cuatro rutas profesionalizantes: sistemas energéticos, sistemas mecánicos, Sistemas de potencia y control, y mantenimiento de sistemas. En este espacio, los estudiantes de la Escuela de Ciencias Aplicadas e Ingeniería se han enfrentado a aproximadamente 25 retos que nacen en la industria y que exigen aplicar, cuestionar y adaptar lo aprendido. Cada proyecto abre una conversación en la que participan estudiantes, profesores y empresas, todos con un mismo objetivo: encontrar soluciones viables.

“Buscamos un pretexto y ese pretexto es tener unos retos que se puedan implementar en la asignatura de Proyectos de trayectorias, en el pregrado de Ingeniería mecánica. Siempre soñé que fueran en empresa, que fueran problemas reales, retos empresariales palpables que los estudiantes puedan evidenciar y en los que puedan aplicar todo lo que han visto hasta el momento de la carrera”, explica Jaime Leonardo Barbosa Pérez, jefe del pregrado de Ingeniería Mecánica de EAFIT y director de ingeniería del programa Kratos.

Así, este enfoque tiene un impacto directo en la formación de los estudiantes, quienes no solo fortalecen sus competencias técnicas, sino que también desarrollan habilidades para la resolución de problemas, el trabajo en equipo y la adaptación a entornos reales. Además, estas experiencias abren puertas a prácticas profesionales y a futuras oportunidades laborales, cerrando el ciclo entre formación académica y ejercicio profesional.

Imagen Noticia EAFIT

![Image 1: En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg)

Leyenda de la imagen

Retos empresariales llevados al aula permiten a los estudiantes desarrollar soluciones con impacto en la industria. En la imagen, estudiantes, profesores y aliados en la socialización de la muestra de proyectos de trayectorias de sistemas energéticos y de mantenimiento.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [¡Nace Energy Valley! Un centro que impulsará la innovación y el talento en el sector energético de Colombia](https://www.eafit.edu.co/noticias/nuestro-impacto/nace-energy-valley-un-centro-que-impulsara-la-innovacion-y-el-talento-en)

Abril 17, 2026

**Impulsar el talento, consolidar una comunidad activa y potenciar la investigación y la transferencia de conocimiento son los principales focos de esta iniciativa que articula empresa, Estado, academia y**_**startups**_**para promover investigación aplicada, ofrecer formación especializada y fortalecer la transición energética en Colombia.**

[**El Centro**](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley)**, que fue presentado este 16 de abril en el marco de los 20 años del Clúster de Energía Sostenible, fue creado gracias a una alianza entre EAFIT, la Universidad EIA, la Cámara de Comercio de Medellín para Antioquia, Celsia, ISA, EPM, Isagén, ERCO, Novatio, Azimut y la Alcaldía de Medellín.**

*   [Lee más sobre ¡Nace Energy Valley! Un centro que impulsará la innovación y el talento en el sector energético de Colombia](https://www.eafit.edu.co/noticias/nuestro-impacto/nace-energy-valley-un-centro-que-impulsara-la-innovacion-y-el-talento-en "¡Nace Energy Valley! Un centro que impulsará la innovación y el talento en el sector energético de Colombia")

El lanzamiento oficial de [**Energy Valley**](https://www.eafit.edu.co/centros-estudio-incidencia/energy-valley) se realizó el jueves 16 de abril, en el marco de la celebración de los 20 años del Clúster Energía Sostenible. En la imagen Ricardo Mejía, director centro, durante el lanzamiento.

Desarrollar soluciones tecnológicas, formar talento especializado y fortalecer la transición energética en Colombia son algunos de los objetivos de Energy Valley, el centro que fue presentado este 16 de abril con el objetivo de reunir capacidades para impactar el clúster energético del país. Se trata de una iniciativa que articula a la empresa, la academia, las _startups_ y el Estado, creada en alianza entre EAFIT, la Universidad EIA, la Cámara de Comercio de Medellín para Antioquia, Celsia, ISA, Grupo EPM, Isagén, ERCO, Novatio, Azimut y la Alcaldía de Medellín.

Más que un centro, explicó Claudia Restrepo Montoya, rectora de EAFIT, Energy Valley es una plataforma de articulación donde el conocimiento se encuentra con la industria, la investigación se traduce en soluciones concretas, el emprendimiento conecta con los mercados y la formación ocurre en diálogo con los desafíos del entorno. “Esta iniciativa se inscribe, además, en un momento de ciudad que busca consolidarse como Distrito de Ciencia, Tecnología e Innovación. Un momento que nos recuerda que el desarrollo no ocurre por acumulación de esfuerzos aislados, sino por el criterio de conectarlos con sentido”, dijo.

Otra de las condiciones que favorecen la creación del centro es la fortaleza de Antioquia en este sector. El departamento concentra cerca del 46 % de la generación de energía del país y cuenta con un ecosistema empresarial consolidado, con aproximadamente 30.000 empleos. También hay potencia en los antecedentes de trabajo en equipo, tal como quedó en evidencia durante la conmemoración de los 20 años de historia del Clúster Energía Sostenible, que fue el marco en el que se presentó Energy Valley.

Además de las ventajas, también hay oportunidades, tal como mencionó Ricardo Mejía, director del Centro. “La idea es que esto sea un centro de investigación aplicada, de desarrollo tecnológico. De hecho, EAFIT tiene una gran capacidad de materializar ideas, y la propuesta es que todo vaya conectado con las necesidades del sector, que impacte y que se generen nuevos emprendimientos”, afirmó y agregó que existe una alta dependencia tecnológica de terceros, por lo que resulta clave activar las capacidades locales y conectarlas con las necesidades del sector.

El directivo destacó durante el lanzamiento que la demanda global de energía sigue en aumento, solo en diciembre de 2025 creció un 4,03 %, y que el consumo de electricidad podría crecer 2,5 veces más rápido que la demanda energética total. También advirtió que la región no está preparada para responder a este ritmo, por eso resaltó el papel estratégico de Antioquia, que cuenta con una capacidad instalada de 8 GW, de los casi 20 GW del país, y señaló que el sector energético representa el 12,5 % del PIB nacional.

###### Un punto de encuentro para construir el futuro de la energía

El Centro Avanzado de Energía (CAE), eje de esta iniciativa, planea contar con un espacio físico de encuentro desde el que se promoverán proyectos en áreas como almacenamiento energético, digitalización de redes, electrificación industrial, mercados de energía, hidrógeno, gemelos digitales y nuevas tecnologías de generación.

El proyecto incluye laboratorios compartidos, investigación aplicada, programas de formación y el desarrollo de emprendimientos _deeptech_ que permitan reducir la dependencia tecnológica y fortalecer la industria nacional. Además, este espacio buscará consolidar una comunidad en la que confluyan empresas, investigadores y estudiantes, facilitando la co-creación de soluciones y el desarrollo de capacidades alineadas con las necesidades del sector energético.

Ricardo Sierra Fernández, CEO de Celsia, afirmó que “la principal expectativa con el Centro es cerrar la brecha de talento humano y de capacidades tecnológicas que hoy enfrenta el sector energético, formando nuevos perfiles profesionales acordes con los desafíos de la transición energética”, con lo que se fortalece una industria estratégica que, aunque esencial, suele ser invisible para el ciudadano.

De esta forma, Energy Valley operará bajo un modelo que integra membresías empresariales, ejecución de proyectos, prestación de servicios especializados y la consolidación de una comunidad activa alrededor de la energía. A través de este esquema se habilitarán procesos como el testeo de nuevas tecnologías, misiones de innovación para la industria, formación técnica avanzada e investigación aplicada, así como la conexión entre actores y el mapeo de oportunidades.

“La idea es que podamos vincular muchas empresas de energía y que en el Centro empecemos a incubar ideas, investigaciones y talento que puedan crear las próximas empresas del futuro, las próximas soluciones que necesita la industria, o las personas que necesitamos para trabajar, y crear ese ecosistema que ha venido creciendo, pero que queremos hacer crecer mucho más”, señaló Juan Esteban Hincapié, graduado de EAFIT y cofundador de la comercializadora de energía ERCO, quien ve en la iniciativa un camino para acelerar la innovación.

Para los actores del ecosistema regional, Energy Valley también representa una oportunidad para fortalecer la articulación institucional y el desarrollo económico del territorio. “Considero que Antioquia cada vez se consolida más como el corazón energético del país y Energy Valley será un ingrediente adicional, la cereza en el postre, para apuntalar a la región como una gran potencia energética y un referente para toda la región”, expresó Jaime Arenas Plata, director del Clúster Energía Sostenible de la Cámara de Comercio de Medellín para Antioquia.

Energy Valley se proyecta como una plataforma para anticipar los desafíos del sistema energético y responder a ellos con soluciones concretas desde el territorio. Más allá de la infraestructura y los proyectos, el Centro busca consolidar una comunidad que permita acelerar la transferencia de conocimiento, dinamizar la innovación y abrir nuevas oportunidades para empresas, investigadores y estudiantes. En ese camino, Medellín y Antioquia se posicionan como escenarios clave para experimentar, validar y escalar soluciones que podrían marcar la ruta del desarrollo energético en el país.

En ese mismo sentido, María Fernanda Galeano Rojo, secretaria de Desarrollo Económico de Medellín, consideró que Energy Valley “influirá directamente al fortalecer el ecosistema de innovación y los clústeres empresariales. Este Centro permite que la normativa de Distrito se traduzca en hechos territoriales, impulsando la innovación y la investigación para lograr una transición energética exitosa hacia fuentes renovables”. El Centro, concluyó, será un pilar fundamental del Clúster de Energía Sostenible, del que se espera un liderazgo en transición energética, consolidándose como un _hub_ de conocimiento y proyectarse como un laboratorio vivo de soluciones escalables.

Imagen Noticia EAFIT

![Image 2: El lanzamiento oficial de Energy Valley [SG2.1]se realizó el jueves 16 de abril, en el marco de la celebración de los 20 años del Clúster Energía Sostenible. En la imagen Ricardo Mejía, director centro, durante el lanzamiento.](https://universidadeafit.widen.net/content/19af2040-a199-422b-b134-a4b03a5b0c77/web/EnergyValley-1500.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Dependencias

## [Por primera vez en América Latina, la AREUEA International Conference 2026 se realizará en EAFIT](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/por-primera-vez-en-america-latina-la-areuea-international-conference)

Febrero 24, 2026

**La**_**American Real Estate and Urban Economics Association**_**(AREUEA) celebrará su Conferencia Anual Internacional de 2026 en Medellín, del 23 al 25 de julio, con la Universidad EAFIT como anfitriona. El encuentro reunirá a investigadores, expertos del sector inmobiliario y responsables de política pública de diferentes países.**

**Vivienda, economía urbana, finanzas inmobiliarias y sostenibilidad serán algunas de las temáticas de la agenda. La programación incluirá la presentación de cerca de 100 investigaciones, paneles con expertos y espacios de networking.**

*   [Lee más sobre Por primera vez en América Latina, la AREUEA International Conference 2026 se realizará en EAFIT](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/por-primera-vez-en-america-latina-la-areuea-international-conference "Por primera vez en América Latina, la AREUEA International Conference 2026 se realizará en EAFIT")

Los investigadores interesados podrán postular sus trabajos hasta el 2 de marzo de 2026. Más información [**aquí**](https://www.eafit.edu.co/en/calendario-eventos/areuea-international-conference-2026#230548828-1510227486). El sector inmobiliario será el tema principal de esta conferencia.

Del 23 al 25 de julio de 2026, Medellín se convertirá en punto de encuentro para quienes investigan, diseñan y toman decisiones sobre el futuro de las ciudades. Durante tres días, EAFIT y su Escuela de Finanzas, Economía y Gobierno abrirá sus puertas a académicos, expertos del sector inmobiliario y responsables de política pública que llegarán desde distintos continentes para participar en la AREUEA International Conference 2026, el evento más importante a nivel global en economía urbana y mercados inmobiliarios.

Por primera vez en su historia, la _American Real Estate and Urban Economics Association_ (AREUEA) realizará su conferencia internacional en América Latina. En años anteriores, el encuentro tuvo lugar en ciudades como Barcelona (2025) y Cambridge (2023), y lo que da cuenta de su carácter global y de alto nivel académico.

Para Gustavo García Cruz, profesor de la Escuela de Finanzas, Economía y Gobierno de EAFIT y miembro del comité organizador, la llegada del evento a Colombia tiene un significado especial. “La realización de esta conferencia va a poner a Colombia y a Medellín en el centro mundial de la conversación sobre los retos que enfrentan las ciudades en términos de vivienda, financiación en el sector inmobiliario y las políticas públicas para hacer más productivas las ciudades”, afirma.

La conferencia reunirá a investigadores de universidades de primer nivel, economistas de bancos centrales, expertos de los sectores financiero e inmobiliario, responsables de política pública y estudiantes de doctorado de distintas regiones del mundo. Se espera la presentación de cerca de 100 investigaciones en sesiones paralelas, además de paneles con representantes de la academia, la industria y el sector público.

###### Tres días para pensar el futuro de las ciudades

Carlos Hurtado, profesor de la Universidad de Richmond e integrante del comité organizador internacional, destaca que este encuentro será un espacio privilegiado para el intercambio de ideas y la construcción de redes globales de colaboración. “La conferencia busca aportar evidencia empírica rigurosa y un debate informado que contribuyan a mejores políticas públicas y a decisiones más sólidas en el sector privado, fortaleciendo el diálogo entre la academia, las empresas e instituciones públicas”.

En cuanto a la agenda, el profesor Carlos explica que la programación combinará presentaciones académicas en sesiones paralelas con dos plenarias a cargo de expertos de los sectores público y privado. Además, se ofrecerán espacios estructurados de networking y dos visitas guiadas por la ciudad, que permitirán a los asistentes conocer de primera mano la experiencia urbana de Medellín.

Por su parte, el profesor Gustavo señala que, “al ser la primera vez que se realiza esta conferencia internacional en América Latina, se espera que las discusiones aborden las principales problemáticas que se viven en la región”, como el déficit de vivienda, el aumento en el precio del suelo, la baja cobertura de servicios públicos y la escasa planificación urbana.

El evento contará con distintas modalidades de participación. Por un lado, cualquier persona interesada podrá asistir registrándose a través de la [página web oficial](https://www.eafit.edu.co/en/calendario-eventos/areuea-international-conference-2026#230548828-1510227486). A su vez, la convocatoria para presentar investigaciones estará abierta hasta el 2 de marzo y no es necesario ser miembro de la AREUEA para postular un trabajo. Investigadores, profesionales y responsables de política pública están invitados a enviar sus propuestas y a ser parte de un foro de clase mundial que, por primera vez, tendrá como escenario a América Latina y a EAFIT como anfitriona.

###### Colombia y EAFIT, un laboratorio urbano para el debate global

De acuerdo con los organizadores, el país fue seleccionado como sede de la AREUEA International Conference 2026 por ofrecer múltiples casos de estudio en temas como movilidad, transporte público integrado, renovación urbana e inclusión social, que han despertado el interés de la comunidad académica. En ese sentido, Medellín se ha consolidado como un referente por sus procesos de transformación y su capacidad para articular desarrollo social, infraestructura y planificación territorial.

EAFIT, como institución anfitriona, aporta una trayectoria sólida en investigación y una estrecha relación con el sector productivo y las políticas públicas. Para el profesor Carlos, integrante del comité organizador internacional, el contexto fue determinante en la elección: “Colombia fue seleccionada como sede porque es una economía dinámica con una agenda urbana activa y altamente relevante”. La combinación entre excelencia académica y un entorno urbano con experiencias significativas convierten a Medellín y a EAFIT en un escenario ideal para un encuentro que busca pensar el futuro de las ciudades desde una perspectiva global.

Imagen Noticia EAFIT

![Image 3: Los investigadores interesados podrán postular sus trabajos hasta el 2 de marzo de 2026. Más información aquí. El sector inmobiliario será el tema principal de esta conferencia.](https://universidadeafit.widen.net/content/07723fb7-4122-4f55-8d32-ac999e8b2238/web/Tejeduria-comuna.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Escuela o área Noticia

Dependencias

## [EAFIT, certificación en liderazgo, más de 100 líderes, gestión humana, empresas colombianas](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-certificacion-en-liderazgo-mas-de-100-lideres-gestion-humana)

Noviembre 24, 2025

**Se trata de la certificación del programa Talento 100+, orientado a fortalecer competencias para transformar organizaciones, ofrecido por la Universidad a través de su Dirección de Estrategia y de In-sight, su centro de estudios e incidencia en liderazgo de impacto.**

**En la**_**masterclass**_**de cierre, Claudia Restrepo Montoya, rectora de EAFIT, invitó a los asistentes a reflexionar sobre el papel del poder en el ejercicio del liderazgo. El encuentro también contó con la presencia de Fernando Quijano, director del diario**_**La República**_**.**

*   [Lee más sobre EAFIT, certificación en liderazgo, más de 100 líderes, gestión humana, empresas colombianas](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-certificacion-en-liderazgo-mas-de-100-lideres-gestion-humana "EAFIT, certificación en liderazgo, más de 100 líderes, gestión humana, empresas colombianas")

Este encuentro con el liderazgo fue una alianza entre la Dirección de Estrategia e Insight, el _Centro de estudios e incidencia en liderazgo de impacto_ de EAFIT.

Influencia, inspiración, responsabilidad, guía, transformación y ejemplo fueron algunas de las palabras que surgieron desde el público cuando Claudia Restrepo Montoya, rectora de EAFIT, invitó a los asistentes a definir el liderazgo en una sola expresión. Aunque todas conectaban con el acto de liderar, su propósito era conducir hacia otra palabra: poder. Con esta idea inició la _masterclass_ que cerró la primera edición del programa Talento 100+, un componente formativo de In-sight, el centro de estudios e incidencia en liderazgo de impacto de la Universidad.

Talento 100+ es una iniciativa que surgió desde In-sight y la Dirección de Estrategia de EAFIT con el propósito de fortalecer las capacidades de liderazgo de los equipos de talento humano, tanto de empresas consolidadas como de entidades públicas, y promover espacios de aprendizaje colaborativo entre gerentes, directores y vicepresidentes del área.

Así lo explicó Mariana Correa, líder del Ecosistema de Empresas de esa Dirección, quien agregó que “uno de los objetivos era contrastar las definiciones y retos que enfrentan los líderes de talento humano, y propiciar espacios de trabajo conjunto para que ese conocimiento circule entre pares”. Esa posibilidad de intercambio directo entre quienes toman decisiones sobre liderazgo en sus instituciones es justamente uno de los diferenciadores del curso.

Juan Pablo Villegas, director de desarrollo humano y organizacional de Isagen, resaltó que uno de los aprendizajes que le quedan de esta experiencia es que el liderazgo es algo dinámico, “pero ese dinamismo, llevado a reflexiones diarias que se preguntan por la forma de relacionarnos con los demás, puede inducir a los otros a desarrollar sus propias competencias. Es un mensaje que me gustó mucho”, afirma.

Algunas de las empresas que se vincularon a este programa son: Postobón, Protección, Industrias Haceb, Isagen, Colegio Pinares, Grupo Argos, Metro de Medellín, entre otras.

###### Una conversación sobre retos y transformaciones del liderazgo

La clausura del curso, que se realizó este 18 de noviembre con una certificación, incluyó la _masterclass_ de la rectora Claudia Restrepo, y después un espacio de conversación entre la directiva y Fernando Quijano, director del diario _La República_.

En el primer espacio la Rectora se refirió a las diversas expresiones del poder, entre estas el fetichismo, la representación, la reflexión, lo social, lo técnico y lo artístico, y a cómo estas evolucionan a medida que el liderazgo se vuelve más sofisticado. En el plano organizacional explicó tres modelos de ejercicio del poder: el unitario, el radical y el pluralista, y destacó este último por su capacidad de enriquecer la interacción entre las personas y fomentar entornos más creativos.

También señaló que el poder actúa como un reflector que revela lo que cada líder lleva dentro, y subrayó la importancia de la ética y del cuidado personal para evitar que este se convierta en un factor de corrupción. En su mensaje, invitó a los líderes asistentes a irradiar sus virtudes hacia los demás y ejercer el poder con responsabilidad, pues son custodios de una luz capaz de transformar los entornos y generar esperanza.

Durante la conversación _Retos y transformaciones del liderazgo en la actualidad_, Fernando Quijano destacó que “el liderazgo no es un tema de cifras, sino dimensiones del ser y del hacer que se construyen en la educación permanente”, e insistió en que la innovación, la coherencia y la capacidad de generar impacto son rasgos esenciales en los líderes de hoy.

También explicó que no existe una fórmula única para identificar un buen líder, pero sí criterios orientadores: hechos positivos, presencia femenina en roles estratégicos y la capacidad de movilizar transformaciones. “Los liderazgos van cambiando. No es lo mismo ser poderoso que ser influyente”, afirmó, al subrayar que una persona influyente no necesariamente ejerce un liderazgo ético o inspirador.

El cierre del evento estuvo a cargo de Alex Garzón Lasso, director de In-sight, quien retomó la reflexión de la Rectora para recordar que un liderazgo auténtico reconoce y comprende el ejercicio del poder. Advirtió que, cuando ese poder no se entiende, puede terminar corrompiendo a quien lo ejerce. Por eso invitó a los asistentes a ser conscientes de su impacto: “No nos olvidemos de eso. Siempre que ejercemos poder recordemos que dejamos huella en los demás, pero ojalá no marcas”, concluyó.

Imagen Noticia EAFIT

![Image 4: Este Encuentro con el liderazgo fue una alianza entre EAFIT, La República e Insight, el Centro de estudios e incidencia en liderazgo de impacto de EAFIT.](https://universidadeafit.widen.net/content/853f17b5-4c12-4b7f-af2c-363487ad19c9/web/In-sight-liderazgo.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [16 eafitenses están entre los 100 líderes con mejor reputación en Colombia](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/16-eafitenses-estan-entre-los-100-lideres-con-mejor)

Octubre 21, 2025

**En la medición de Merco Líderes 2025 aparecen Juan Carlos Mora, Ricardo Sierra, Carlos Ignacio Gallego, Claudia Restrepo, Miguel Fernando Escobar, Juan Esteban Calle, David Escobar, Juan David Escobar, Ignacio Calle, Juan David Correa, Luis Alberto Botero,****Santiago Londoño Aguilar**, **Jaime Alberto Ángel, Gabriel Jaime Melguizo, Juan Camilo Vélez y Andrés Aguirre Martínez.**

**Cuatro de estos eafitenses, incluyendo a la rectora Claudia Restrepo, están en el top 20 del ranquin. Además, tres integrantes del Consejo Superior de la Institución están en la lista. Esto se suma al más reciente Merco Empresas, en el que EAFIT figura como la primera universidad de Antioquia en la lista y segunda del país.**

*   [Lee más sobre 16 eafitenses están entre los 100 líderes con mejor reputación en Colombia](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/16-eafitenses-estan-entre-los-100-lideres-con-mejor "16 eafitenses están entre los 100 líderes con mejor reputación en Colombia")

Son 16 los graduados eafitenses destacados en Merco Líderes 2025, un escalafón que mide la reputación de los principales referentes empresariales y sociales de Colombia. En el top 20 figuran Juan Carlos Mora Uribe, presidente de Bancolombia, quien está en el primer lugar del ranking; Ricardo Sierra Fernández, presidente de Celsia (14); Carlos Ignacio Gallego Palacio, ex presidente del Grupo Nutresa (15); Claudia Restrepo Montoya, rectora de EAFIT (18).

También sobresalen Miguel Fernando Escobar Penagos, presidente de Postobón (21); Juan Esteban Calle Restrepo, presidente de Cementos Argos (27); David Escobar Arango, director de Comfama (31); Juan David Escobar Franco, presidente de Seguros Sura (44); e Ignacio Calle Cuartas, presidente de Sura Asset Management (54); Juan David Correa Solórzano, presidente de Protección (62); Luis Alberto Botero Botero, presidente de Alianza Team (68); Santiago Londoño Aguilar, gerente general de Industrias Haceb (76); Jaime Alberto Ángel Mejía, presidente de Corona Industrial (77); Gabriel Jaime Melguizo Posada, vicepresidente de ISA (85); Juan Camilo Vélez Arango, gerente general de SUFI (94); y Andrés Aguirre Martínez, consultor (96), entre los líderes que reafirman su influencia en los sectores financiero, industrial y social del país.

Además de la Rectora, en el listado figuran tres integrantes del Consejo Superior de EAFIT: Carlos Ignacio Gallego, Ignacio Calle Cuartas, Andrés Aguirre.

Para Isabel Gómez Yepes, directora de Desarrollo Institucional y Vínculos de EAFIT, la presencia de los 15 egresados en el listado “es motivo de orgullo porque nuestros graduados son el reflejo de la calidad institucional y de la capacidad transformadora de la comunidad eafitense”. Agregó que “ver a los eafitenses en posiciones de liderazgo, incluido el primero del ranking y nuestra rectora entre los 20 más reputados, confirma la incidencia que tienen nuestros profesionales en la sociedad y nos anima a seguir fortaleciendo la formación que ofrecemos desde la excelencia y la conexión con los retos del entorno”.

Desde la metodología del estudio, Catalina Londoño, directora general de Merco Colombia, explicó que en su edición 18 la medición se basó en un modelo multistakeholder que combina la percepción de más de 2.000 directivos, 400 expertos y 249.000 menciones digitales. En su análisis consideró seis grandes ejes: perfil reputacional, liderazgo, estrategia y gestión, referencia social y empresarial, liderazgo digital e indicadores objetivos de gestión.

###### Del círculo virtuoso entre el liderazgo y la reputación institucional

Catalina Londoño destacó que Merco identifica un “círculo virtuoso” entre la reputación del líder y la de su organización, en el que ambos se fortalecen mutuamente mediante la coherencia, la visión y la comunicación efectiva.

Ese equilibrio entre liderazgo personal y reputación institucional se refleja también en EAFIT. Así lo considera Catalina Suárez Restrepo, jefa del Departamento de Comunicación de EAFIT, quien compartió que “la presencia de la rectora Claudia Restrepo entre los 20 líderes con mejor reputación del país, y el reconocimiento de EAFIT como la primera universidad privada de Antioquia y la segunda en Colombia en el más reciente ranquin Merco Empresas, evidencian ese círculo virtuoso entre el liderazgo coherente del CEO y el de la organización. En nuestro caso, esa coherencia es parte esencial de la reputación que construimos día a día”.

De esta forma, los resultados de Merco 2025 reafirman el papel de EAFIT como una Institución que forma y proyecta líderes capaces de incidir, transformar y generar confianza, al tiempo que consolida su reputación corporativa en el ámbito nacional.

###### Los líderes con mejor reputación de Colombia: una nueva era del liderazgo empresarial

**Por Alex Garzón Lasso, director de In-sight de EAFIT, centro de liderazgo de impacto**

“El más reciente ranking Merco Líderes Colombia 2025 reconoce a los líderes con mayor reputación y admiración en el país. Este listado se ha convertido en una referencia clave para entender cómo el liderazgo colombiano está evolucionando hacia modelos más humanos, sostenibles y con propósito. Estar entre los primeros lugares no solo representa éxito empresarial, sino también la capacidad de inspirar confianza, generar impacto positivo y construir valor compartido.

Estos líderes encarnan un cambio profundo en la manera de dirigir las organizaciones. Han pasado de un liderazgo basado en la autoridad y el control a uno centrado en la inspiración, la coherencia y la ética. Demuestran que la innovación, la sostenibilidad y el bienestar de las personas son hoy pilares inseparables de la competitividad empresarial. En sus empresas, los resultados financieros caminan de la mano con la responsabilidad social y la transformación cultural.

Sobresale la presencia de líderes que trascienden el ámbito corporativo tradicional, como Claudia Restrepo Montoya, rectora de EAFIT, quien representan el papel del conocimiento, la educación y la investigación en la construcción de una sociedad más ética y consciente.

En conjunto, los primeros 20 del ranking Merco representan una generación de líderes que entienden la organización como un agente de transformación social. Su influencia se mide no solo por la magnitud de sus empresas, sino por la capacidad de movilizar confianza, inspirar propósito y dejar huella positiva. Son líderes que actúan con visión de largo plazo, promueven culturas organizacionales centradas en las personas y asumen su rol con autenticidad y responsabilidad. Líderes que impulsan un liderazgo que combina la inspiración, visión compartida, adaptabilidad, desarrollo y liderazgo de sí misma.

En una época donde la reputación se ha convertido en el activo más valioso, estos líderes demuestran que el verdadero éxito empresarial se construye sobre la base de la coherencia, la ética y el impacto. Su ejemplo invita a repensar la manera de liderar en Colombia: no como un ejercicio de poder, sino como una oportunidad de inspirar, crear y transformar”.

Imagen Noticia EAFIT

![Image 5: Entre los 15 graduados de EAFIT reconocidos por Merco Líderes están tres integrantes del Consejo Superior de la Universidad y la rectora Claudia Restrepo Montoya.](https://universidadeafit.widen.net/content/6c636b23-2c70-4a97-ba87-1363d3819c41/web/Mercolideres-agencia.jpg)

Leyenda de la imagen

Entre los 16 graduados de EAFIT reconocidos por Merco Líderes están tres integrantes del Consejo Superior de la Universidad y la rectora Claudia Restrepo Montoya.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [EAFIT está en el top 3 de las universidades colombianas que mejor atraen y retienen talento](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-esta-en-el-top-3-de-las-universidades-colombianas-que-mejor-atraen)

Junio 5, 2025

**Así lo establece el ranquin Merco Talento 2025 que divulgó Monitor Empresarial de Reputación Corporativa (Merco) este 5 de junio, y en el que la Institución se ubicó como la tercera del país y primera en Antioquia en el sector educación.**

**En la medición general EAFIT mejoró con respecto a la edición de 2024, pasando del puesto 35 al 28. Para la realización de la medición, se aplicaron 74.851 encuestas, distribuidas en 13 fuentes de información desde 6 perspectivas diferentes.**

*   [Lee más sobre EAFIT está en el top 3 de las universidades colombianas que mejor atraen y retienen talento](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-esta-en-el-top-3-de-las-universidades-colombianas-que-mejor-atraen "EAFIT está en el top 3 de las universidades colombianas que mejor atraen y retienen talento")

De acuerdo con los resultados de la más reciente encuesta Merco Talento, publicada este 5 de junio, EAFIT es la tercera universidad en Colombia que mejor atrae y retiene el talento en las entidades del sector educación, subiendo dos puestos en el escalafón. En cuanto a la medición general, la Institución se ubicó en el puesto 28 del ranquin, aumentando 7 puestos con respecto a 2024.

Para evaluar el poder de las empresas para atraer y fidelizar el talento, Monitor Empresarial de Reputación Corporativa (Merco) tiene en cuenta variables como la coherencia entre el salario y la función desempeñada, el desarrollo profesional, la motivación, el sector al que pertenece la empresa y sus valores éticos, la reputación, entre otros.

Ricardo Uribe Marín, director de Desarrollo Humano y Bienestar de EAFIT, expresó que “este logro lo recibimos con alegría, entusiasmo y compromiso para seguir trabajando como Universidad en nuestros procesos de atracción y retención del talento. Esta mejora se debe al trabajo serio, decidido y responsable entre la Dirección, la alta dirección de la Universidad y todas las áreas académicas y administrativas a lo largo de varios años”.

Por su parte, Cristina Vélez Valencia, decana de la Escuela de Administración, complementó que “estar entre las tres universidades con mayor reconocimiento organizacional es un orgullo para EAFIT. Implica que nuestra promesa de conectarnos con las organizaciones, de hacer investigación relevante, de formar el mejor talento gerencial, se está cumpliendo y lo están reconociendo nuestros pares. Asimismo, haber subido en el ranquin general también habla de una noción de las universidades como actores relevantes del entramado empresarial y organizacional del país”.

###### Sobre la medición actual

En la edición número 16 de esta medición en Colombia, se realizaron un total de 74.851 encuestas, distribuidas en 13 fuentes de información entre universitarios, egresados, catedráticos, cazadores de talentos, responsables de equipos de recursos humamos, entre otros.

“Lo que hace Merco Talento es realizar una evaluación global de atractivo de las empresas y marcas empleadoras para atraer y fidelizar talento, considerando la opinión de diferentes targets. Esto se analiza comparativamente con todas las grandes empresas”, expresó Elena Orden, responsable de Merco Talento España, durante la socialización de los resultados.

Garantizar la transparencia de esta medición es un factor relevante, por eso “la presencia de las empresas en el ranquin es gratuita. Merco talento es un monitor de referencia para la empleabilidad y evaluación, y además analiza y compara otras empresas. Eso hace que sea un monitor de referencia”, afirmó Catalina Londoño Moreno, directora de Merco Colombia.

Como novedad en la presente edición de Merco, la encuesta incluyó preguntas como ¿Tu empresa tiene definido un propósito corporativo?, ¿el propósito se refleja en la actividad actual de la empresa?, ¿crees que el propósito es una buena apuesta o camino para el futuro de la empresa?, ¿en qué medida te identificas con el propósito?

Una de las conclusiones de esta medición es que los departamentos de recursos humanos, además de seguir trabajando en estrategias de atracción y fidelización, deben tener propuestas de valor adaptadas de acuerdo con los diversos públicos internos, pues los intereses o motivaciones varían según el rango de edad o la posición en la compañía.

En el caso de EAFIT, y en palabras de la decana Cristina Vélez, “como marca empleadora es coherente con lo que hacemos, es decir, es un reflejo de una organización que reta y acompaña a sus colaboradores. En donde la gente trabaja feliz”.

En ese sentido, Ricardo Uribe, manifestó que los resultados muestran que la Universidad es un referente como institución empleadora, lo que se ratifica con una mejora año a año en Merco Talento. Agregó, además, que este logro, a propósito de los 65 años de EAFIT, demuestra que somos “una Institución seria, madura y comprometida no solo con la atracción sino también con el desarrollo y retención del talento humano clave para el logro de nuestro propósito superior de transformar sociedad”.

Imagen Noticia EAFIT

![Image 6: Campus](https://universidadeafit.widen.net/content/6e0d40f1-1bd8-45e5-bf3f-253b3eb1076e/web/el-podio.jpg)

Leyenda de la imagen

EAFIT se ubica en el lugar 28 de ranquin, aumentando 7 puestos con respecto a 2024.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [El liderazgo de las eafitenses entre las mujeres más poderosas de Colombia 2025 según Forbes](https://www.eafit.edu.co/noticias/eafit-es-noticia/el-liderazgo-de-las-eafitenses-entre-las-mujeres-mas)

Mayo 13, 2025

**Claudia Restrepo, Natalia Gutiérrez, Luz María Correa y Natalia de Greiff, graduadas de EAFIT, hacen parte del listado anual que reconoce a las mujeres que lideran la transformación del país.**

**Esta no es la primera vez que sus nombres aparecen en esta publicación, lo que ratifica su constancia, influencia y compromiso con el desarrollo empresarial, social y público de Colombia.**

*   [Lee más sobre El liderazgo de las eafitenses entre las mujeres más poderosas de Colombia 2025 según Forbes](https://www.eafit.edu.co/noticias/eafit-es-noticia/el-liderazgo-de-las-eafitenses-entre-las-mujeres-mas "El liderazgo de las eafitenses entre las mujeres más poderosas de Colombia 2025 según Forbes")

El liderazgo femenino con sello eafitense está presente nuevamente en el listado de las 100 mujeres más poderosas de Colombia 2025, que publica cada año la revista _Forbes_. Entre las seleccionadas figuran cuatro graduadas de EAFIT que han construido trayectorias sólidas en el sector público, privado y social.

Se trata de Claudia Restrepo Montoya, rectora de la Universidad EAFIT y administradora de negocios; Natalia Gutiérrez, presidenta de Acolgen y también administradora de negocios; Luz María Correa Vargas, integrante de la Junta Directiva de Construcciones El Cóndor y egresada del mismo pregrado; y Natalia de Greiff, vicepresidenta de Automatización de IBM para las Américas y egresada de Ingeniería de Producción.

“La presencia de nuestras graduadas en este grupo no solo es motivo de orgullo para la Universidad, sino también una confirmación del compromiso que tenemos con la formación de líderes transformadores que inciden de manera significativa en el país. Que estas mujeres se mantengan en este tipo de publicaciones demuestra su coherencia, visión estratégica y capacidad de impactar con propósito”, expresa Isabel Gómez Yepes, directora de Desarrollo Institucional y Vínculos de EAFIT.

Las cuatro han incidido en la sociedad desde distintos escenarios: la educación, la energía, la infraestructura y la tecnología. Todas son ejemplo de una formación que se proyecta con ética, humanismo y pensamiento crítico.

Este tipo de distinciones reafirman el papel de las universidades como espacios que potencian capacidades y valores. En este caso, también evidencian el poder de las redes de graduados que generan impacto desde altos niveles de influencia nacional.

La lista, según explica Forbes, replica el esquema de su casa matriz en Estados Unidos, pero con la diferencia de que no se hace a manera de escalafón. Tiene en cuenta criterios como el “poder duro (los recursos que administran y gestionan como Producto Interno Bruto -PIB-, ingresos, activos o patrimonio neto); su impacto (número de colaboradores o población que lideran); o sus esferas de influencia. 2) su poder dinámico (audiencias, comunidades e influencia creativa). 3) el poder blando (aquello que hacen con su influencia y que impacta comunidades enteras)”.

Las mujeres seleccionadas inciden en diferentes esferas de la vida pública: filantropía, política, finanzas, academia, sector empresarial, arte, gastronomía, tecnología, medios de comunicación, entretenimiento, entre otros.

“Los liderazgos que necesitamos hoy son aquellos que comprenden la complejidad del mundo y se comprometen con causas que impactan positivamente a la sociedad. Las mujeres han demostrado ser protagonistas clave en la movilización de agendas de desarrollo, sostenibilidad, equidad y transformación cultural. Desde la Universidad celebramos que nuestras graduadas estén liderando esos procesos con visión, sensibilidad y una capacidad para generar resultados”, concluye Isabel Gómez Yepes.

Imagen Noticia EAFIT

![Image 7: El listado anual que publica Forbes se replica en 60 países.](https://universidadeafit.widen.net/content/b4a0b86b-0ea5-4a06-b612-f82691e92a3d/web/liderazgo-eafitenses%201.jpg)

Leyenda de la imagen

El listado anual que publica Forbes se replica en 60 países.

Categoría de noticias EAFIT

Sección del especial EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Idioma Noticias

Público Noticias

Dependencias

## [Hacia dónde va el mercado laboral](https://www.eafit.edu.co/noticias/publicaciones/hacia-donde-va-el-mercado-laboral)

Marzo 10, 2026

**El Fin del Gestor Operativo: Liderazgo, inteligencia artificial y la ventaja humana**

**Por:**María Adelaida Mesa

Especialista en Economía de EAFIT

Headhunter C-level | Fundadora y socia mánager de Jugada Maestra

*   [Lee más sobre Hacia dónde va el mercado laboral](https://www.eafit.edu.co/noticias/publicaciones/hacia-donde-va-el-mercado-laboral "Hacia dónde va el mercado laboral ")

El debate sobre si la inteligencia artificial reemplazará a los directivos está mal planteado. La IA no es simplemente una herramienta de software; es una nueva infraestructura cognitiva. Las organizaciones ya no necesitan mandos medios cuya función principal sea recopilar datos, supervisar el cumplimiento de tareas rutinarias o generar reportes predecibles. Un modelo de lenguaje avanzado puede hacer eso con mayor precisión y a una fracción del costo.

Si el trabajo analítico y procedimental está siendo delegado a los algoritmos, la pregunta crítica para cualquier profesional universitario que aspire a dirigir en la próxima década es: ¿Cuál es mi valor residual cuando la máquina puede pensar tácticamente mejor que yo?

Las juntas directivas están reevaluando radicalmente sus matrices de talento. Ya no se contrata por la capacidad de almacenar conocimiento técnico, sino por la habilidad de orquestar ecosistemas donde humanos y algoritmos colaboran.

El liderazgo que se impone domina tres frentes: la orquestación de inteligencia híbrida, la gestión de la ansiedad tecnológica y el cambio, y la auditoría de criterio.

Para no ser reemplazado por un algoritmo, un profesional debe sobresalir en aquello que es matemáticamente incomputable. Las competencias que hoy dictan quién asciende y quién se estanca son quienes demuestran y fomentan resiliencia, optimismo fundamentado, esperanza y autoeficacia. Entender cómo propiciar el florecimiento humano (_flourishing_) y mantener a los equipos mentalmente ágiles bajo presión extrema no es una habilidad "blanda", es el núcleo de la productividad moderna. La capacidad de entender cómo interactúan los sistemas (economía, psicología, tecnología) y de cuestionar las premisas fundamentales de un modelo de negocio marca la diferencia en las promociones ejecutivas. En la era del contenido generado por IA, la verbosidad pierde valor. La habilidad escasa es la comunicación sintética, persuasiva y adaptada a la psicología del interlocutor, capaz de alinear a inversionistas, clientes y empleados hacia una visión común.

El futuro del _management_ no pertenece al tecnócrata puro, sino al estratega que entiende que, a medida que la inteligencia artificial se vuelve más ubicua, la comprensión profunda de la condición y el potencial humano se vuelve el activo más escaso y valioso del mercado.

Lo que las empresas están contratando hoy no son "graduados en X carrera", sino roles profesionales de frontera que nacen de la intersección de dos o más disciplinas duras.

Imagen Noticia EAFIT

![Image 8: Hacia dónde va el mercado laboral](https://universidadeafit.widen.net/content/04ac971f-154b-402b-ac37-2743654aa525/web/MariaA-1500.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Idioma Noticias

Público Noticias

Dependencias

## [Las empresas ya no buscan ejecutores, sino estrategas con habilidades tecnológicas](https://www.eafit.edu.co/noticias/especiales/las-empresas-ya-no-buscan-ejecutores-sino-estrategas-con-habilidades)

Marzo 10, 2026

**De acuerdo con consultoras especializadas en talento, el mercado laboral está girando hacia perfiles estratégicos con alto componente tecnológico. Las empresas ya no priorizan funciones operativas, sino profesionales capaces de integrar herramientas digitales a los procesos del negocio, analizar datos y convertirlos en decisiones.**

**En materia de contratación y ascensos, las habilidades humanas marcan la diferencia. Liderazgo, pensamiento crítico, comunicación asertiva, trabajo en equipo y adaptabilidad se imponen como criterios clave para identificar potencial.**

*   [Lee más sobre Las empresas ya no buscan ejecutores, sino estrategas con habilidades tecnológicas](https://www.eafit.edu.co/noticias/especiales/las-empresas-ya-no-buscan-ejecutores-sino-estrategas-con-habilidades "Las empresas ya no buscan ejecutores, sino estrategas con habilidades tecnológicas ")

Reclutadores y líderes empresariales coinciden en una misma idea: el talento que hoy se necesita es distinto. El mercado laboral en Colombia y la región atraviesa una transformación acelerada, impulsada por la integración de nuevas tecnologías y un cambio en las expectativas tanto de empresas como de trabajadores. Las reglas de juego están evolucionando y ya no basta con cumplir funciones operativas, sino que se exige una mirada estratégica capaz de generar valor en entornos dinámicos y altamente digitalizados.

Desde su experiencia acompañando procesos de selección en distintos sectores, Andrea Estrada Lopera, gerente general de Arquitectura del Talento y profesora de Educación continua de EAFIT, advierte que el cambio no está únicamente en las áreas más demandadas, sino en el enfoque de los perfiles. “Actualmente se buscan perfiles en prácticamente todas las áreas, pero con un fuerte componente tecnológico. Por ejemplo, líderes comerciales digitales, directores de transformación digital, coordinadores de soluciones o cargos con gran capacidad para gestionar información y convertir datos en decisiones estratégicas”, afirma.

La inteligencia artificial y la automatización siguen marcando la pauta, pero no se trata únicamente de saber programar. Las empresas valoran profesionales que entiendan el negocio y sepan integrar herramientas digitales para hacer más eficientes los procesos. Por eso, se entiende que la tecnología es un medio, no un fin, y su impacto depende de la capacidad humana para orientarla estratégicamente.

###### Habilidades diferenciales

Natalia Betancur Cadavid, mánager en Michael Page y graduada de la maestría en Sostenibilidad de EAFIT, señala que el mercado está migrando hacia perfiles con pensamiento crítico, capacidad de comunicación y adaptabilidad. “Se buscan personas que entiendan el negocio y que sean capaces de traducir esa comprensión en procesos internos concretos. No es solo llegar a operar, sino pensar estratégicamente y articular, desde el propio rol, el trabajo con distintas áreas, apoyándose en la tecnología para ser más eficientes, más rentables y asegurar que el modelo de negocio siga funcionando”, señala.

Más allá de los conocimientos técnicos, las _soft skills_ ganan protagonismo. Liderazgo, comunicación asertiva y trabajo en equipo son hoy criterios decisivos en los procesos de selección. Natalia lo resume con claridad: “Para cargos de liderazgo se fijan demasiado en esa capacidad de ‘ser persona’, más allá de lo técnico”. En un entorno automatizado, la dimensión humana se convierte en ventaja competitiva.

El ascenso dentro de las organizaciones también responde a nuevos parámetros. De acuerdo con Andrea Estrada, ya no basta con un buen desempeño individual; las empresas buscan señales de potencial, capacidad de influencia y visión de mediano y largo plazo. Curiosidad intelectual, rapidez para aprender y habilidad para comunicar ideas estratégicas son rasgos que marcan la diferencia al momento de promover talento interno.

En paralelo, las compañías enfrentan trabajadores que demandan mayor transparencia y coherencia entre discurso y práctica. Las nuevas generaciones quieren claridad sobre planes de carrera, propósito organizacional y condiciones laborales. El vínculo entre empresa y empleado se redefine en torno a la experiencia integral, no solo a la remuneración.

Estas transformaciones locales dialogan con tendencias globales. En un análisis [publicado por Forbes en 2025](https://forbes.es/empresas/808992/siete-tendencias-laborales-que-marcaran-2026/), Bernard Marr señala que “en 2026 y más allá, los empleadores valorarán especialmente aquellas habilidades en las que las personas siguen siendo innegablemente superiores, como la comunicación interpersonal, la empatía, la creatividad, el trabajo en equipo y el liderazgo”.

En este contexto, el aprendizaje continuo se convierte en condición de permanencia. La apertura al cambio, la disposición para desaprender prácticas tradicionales y la capacidad de incorporar nuevas herramientas tecnológicas son rasgos cada vez más valorados. La empleabilidad ya no depende solo del título universitario, sino de la actualización constante.

Así, el mercado laboral de 2026 perfila un escenario más exigente y competitivo, pero también más amplio en oportunidades para quienes logren combinar mentalidad digital con liderazgo y pensamiento crítico. Las empresas buscan talento capaz de entender el negocio, integrar tecnología y movilizar equipos. En esa convergencia entre habilidades técnicas y humanas se define hoy el verdadero diferencial profesional.

Imagen Noticia EAFIT

![Image 9: Las empresas ya no buscan ejecutores, sino estrategas con habilidades tecnológicas](https://universidadeafit.widen.net/content/78b08b95-ef6d-42c6-bc09-edb600433d51/web/las-empresas-ya-no-buscan-ejecutores.jpg)

Leyenda de la imagen

En un entorno cada vez más automatizado, la combinación entre mentalidad digital y capacidades interpersonales define el crecimiento profesional. En la imagen, la más reciente edición de la Feria de Talento EAFIT.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Idioma Noticias

Público Noticias

Dependencias

## [EAFIT es la segunda universidad de Colombia con mejor reputación, según Merco Empresas 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-es-la-segunda-universidad-de-colombia-con-mejor-reputacion-segun)

Octubre 15, 2025

**• En la más reciente edición del monitor Merco Empresas 2025, la Universidad EAFIT se ubicó en el puesto 27 en la clasificación general, ascendiendo una posición frente al año anterior.**

**• En el sector Educación–Universidades, EAFIT ocupa el segundo lugar, después de la Pontificia Universidad Javeriana, consolidándose como la primera universidad en Antioquia y en el top 30 de las instituciones más reputadas del país.**

*   [Lee más sobre EAFIT es la segunda universidad de Colombia con mejor reputación, según Merco Empresas 2025](https://www.eafit.edu.co/noticias/eafit-es-noticia/eafit-es-la-segunda-universidad-de-colombia-con-mejor-reputacion-segun "EAFIT es la segunda universidad de Colombia con mejor reputación, según Merco Empresas 2025")

La segunda universidad del país, la primera en Antioquia y una de las 30 organizaciones con mejor reputación corporativa en Colombia. Así se posiciona la Universidad EAFIT en la más reciente edición del Ranking Merco Empresas 2025, un monitor que desde hace 25 años mide la reputación corporativa en 20 países.

De acuerdo con los resultados presentados por el Monitor Empresarial de Reputación Corporativa (Merco), EAFIT subió una posición en el escalafón general al pasar del puesto 28 al 27, y se mantuvo entre las universidades con mejor reputación del país, ocupando el segundo lugar en el sector educación–universidades.

En esta categoría, el top 10 quedó conformado por: Pontificia Universidad Javeriana, Universidad EAFIT, Universidad de La Sabana, Universidad Nacional de Colombia, Universidad de los Andes, Universidad EIA, Universidad del Rosario, Universidad de Antioquia, Universidad Pontificia Bolivariana (UPB) y Universidad Icesi.

Para Alexander Garzón Lasso, director de Insight, Centro de Estudios e Incidencia en Liderazgo de Impacto de EAFIT, estar entre las 30 empresas top del país en esta medición adquiere un sentido que, sumado a la reputación, representa el reconocimiento a una forma de liderazgo que inspira, actúa con estrategia, impulsa la adaptabilidad, desarrolla personas y lidera con el ejemplo.

> El posicionamiento de EAFIT evidencia que la organización no solo obtiene resultados, sino que los logra generando valor para la sociedad, movilizando a sus equipos desde un propósito superior y cultivando relaciones basadas en la confianza y la coherencia ética. Ser parte del top 30 implica haber convertido la gestión reputacional en una práctica de liderazgo consciente, donde cada decisión refleja responsabilidad, integridad y visión de largo plazo”, agregó el directivo.

Por su parte, Catalina Londoño, directora general de Merco en Colombia, destacó que, con 25 años de trayectoria y presencia en 20 países, el monitor Merco se ha consolidado como un referente en la evaluación de un valor intangible de las empresas: su reputación, como base para construir confianza, transparencia y rigor.

Este año, explicó Catalina, la metodología de Merco Empresas convocó a 2.000 directivos de 35 sectores, quienes seleccionaron 800 empresas como las más reputadas. Luego, se realizaron más de 81.000 encuestas a catedráticos, analistas financieros, periodistas, social media managers, expertos y representantes de ONG, entre otros, para contrastar la percepción con datos objetivos provenientes de 28 fuentes de información.

> Lo que buscamos con esta metodología fue entender que gestionar y medir la reputación implica mantener un equilibrio entre lo que se reconoce y la realidad de las organizaciones. Fue así como pudimos establecer el top 200 de las empresas mejor reputadas del país”, puntualizó la directiva durante la presentación.

De acuerdo con la medición, el top 10 general de empresas con mejor reputación en Colombia lo encabezan Postobón, Grupo Éxito, Ramo, Davivienda, Grupo Argos, Crepes & Waffles, Sura, Bavaria, Alpina y Bancolombia.

Imagen Noticia EAFIT

![Image 10: Imagen para resultados Merco Talento 2025](https://universidadeafit.widen.net/content/83f6c22c-708a-4e02-896e-a39ac547ccd8/web/mercotalento2025-2.jpg)

Leyenda de la imagen

Con esta posición, EAFIT continúa ratificando su compromiso con la excelencia, la confianza y el liderazgo responsable.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Público Noticias

Dependencias

[Suscribirse a Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856/feed)
