Title: cierre.jpg

URL Source: https://www.eafit.edu.co/sites/default/files/2025-07/cierre.jpg

Published Time: Fri, 25 Jul 2025 19:55:50 GMT

Markdown Content:
# cierre.jpg

Tables with three cups of coffee, one electronic device and another laptop opened near it
