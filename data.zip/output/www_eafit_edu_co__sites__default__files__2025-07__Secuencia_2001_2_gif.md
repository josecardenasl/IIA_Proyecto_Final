Title: Secuencia%2001_2.gif

URL Source: https://www.eafit.edu.co/sites/default/files/2025-07/Secuencia%2001_2.gif

Published Time: Fri, 25 Jul 2025 16:13:55 GMT

Markdown Content:
# Secuencia%2001_2.gif

A man thinks to himself while looking down
