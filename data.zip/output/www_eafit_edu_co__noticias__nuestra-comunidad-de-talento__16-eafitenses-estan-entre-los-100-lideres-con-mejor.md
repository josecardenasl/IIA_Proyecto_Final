Title: 16 eafitenses están entre los 100 líderes con mejor reputación en Colombia

URL Source: https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/16-eafitenses-estan-entre-los-100-lideres-con-mejor

Markdown Content:
# 15 eafitenses están entre los 100 líderes con mejor reputación en Colombia
[Pasar al contenido principal](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/16-eafitenses-estan-entre-los-100-lideres-con-mejor#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/16-eafitenses-estan-entre-los-100-lideres-con-mejor#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/16-eafitenses-estan-entre-los-100-lideres-con-mejor# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/16-eafitenses-estan-entre-los-100-lideres-con-mejor# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)

# 16 eafitenses están entre los 100 líderes con mejor reputación en Colombia

**En la medición de Merco Líderes 2025 aparecen Juan Carlos Mora, Ricardo Sierra, Carlos Ignacio Gallego, Claudia Restrepo, Miguel Fernando Escobar, Juan Esteban Calle, David Escobar, Juan David Escobar, Ignacio Calle, Juan David Correa, Luis Alberto Botero,****Santiago Londoño Aguilar**, **Jaime Alberto Ángel, Gabriel Jaime Melguizo, Juan Camilo Vélez y Andrés Aguirre Martínez.**

**Cuatro de estos eafitenses, incluyendo a la rectora Claudia Restrepo, están en el top 20 del ranquin. Además, tres integrantes del Consejo Superior de la Institución están en la lista. Esto se suma al más reciente Merco Empresas, en el que EAFIT figura como la primera universidad de Antioquia en la lista y segunda del país.**

*   [Inicio](https://www.eafit.edu.co/)
*   [Noticias](https://www.eafit.edu.co/noticias)
*   [Nuestra Comunidad de Talento](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento)
*    16 Eafitenses Están Entre Los 100 Líderes Con Mejor Reputación En Colombia 

![Image 21: Imagen 16 eafitenses están entre los 100 líderes con mejor reputación en Colombia](https://universidadeafit.widen.net/content/6c636b23-2c70-4a97-ba87-1363d3819c41/web/Mercolideres-agencia.jpg?crop=yes&k=c&w=823&h=450&itok=JSlTT9Y-)

Entre los 16 graduados de EAFIT reconocidos por Merco Líderes están tres integrantes del Consejo Superior de la Universidad y la rectora Claudia Restrepo Montoya.

Son 16 los graduados eafitenses destacados en Merco Líderes 2025, un escalafón que mide la reputación de los principales referentes empresariales y sociales de Colombia. En el top 20 figuran Juan Carlos Mora Uribe, presidente de Bancolombia, quien está en el primer lugar del ranking; Ricardo Sierra Fernández, presidente de Celsia (14); Carlos Ignacio Gallego Palacio, ex presidente del Grupo Nutresa (15); Claudia Restrepo Montoya, rectora de EAFIT (18).

También sobresalen Miguel Fernando Escobar Penagos, presidente de Postobón (21); Juan Esteban Calle Restrepo, presidente de Cementos Argos (27); David Escobar Arango, director de Comfama (31); Juan David Escobar Franco, presidente de Seguros Sura (44); e Ignacio Calle Cuartas, presidente de Sura Asset Management (54); Juan David Correa Solórzano, presidente de Protección (62); Luis Alberto Botero Botero, presidente de Alianza Team (68); Santiago Londoño Aguilar, gerente general de Industrias Haceb (76); Jaime Alberto Ángel Mejía, presidente de Corona Industrial (77); Gabriel Jaime Melguizo Posada, vicepresidente de ISA (85); Juan Camilo Vélez Arango, gerente general de SUFI (94); y Andrés Aguirre Martínez, consultor (96), entre los líderes que reafirman su influencia en los sectores financiero, industrial y social del país.

Además de la Rectora, en el listado figuran tres integrantes del Consejo Superior de EAFIT: Carlos Ignacio Gallego, Ignacio Calle Cuartas, Andrés Aguirre.

Para Isabel Gómez Yepes, directora de Desarrollo Institucional y Vínculos de EAFIT, la presencia de los 15 egresados en el listado “es motivo de orgullo porque nuestros graduados son el reflejo de la calidad institucional y de la capacidad transformadora de la comunidad eafitense”. Agregó que “ver a los eafitenses en posiciones de liderazgo, incluido el primero del ranking y nuestra rectora entre los 20 más reputados, confirma la incidencia que tienen nuestros profesionales en la sociedad y nos anima a seguir fortaleciendo la formación que ofrecemos desde la excelencia y la conexión con los retos del entorno”.

Desde la metodología del estudio, Catalina Londoño, directora general de Merco Colombia, explicó que en su edición 18 la medición se basó en un modelo multistakeholder que combina la percepción de más de 2.000 directivos, 400 expertos y 249.000 menciones digitales. En su análisis consideró seis grandes ejes: perfil reputacional, liderazgo, estrategia y gestión, referencia social y empresarial, liderazgo digital e indicadores objetivos de gestión.

###### Del círculo virtuoso entre el liderazgo y la reputación institucional

Catalina Londoño destacó que Merco identifica un “círculo virtuoso” entre la reputación del líder y la de su organización, en el que ambos se fortalecen mutuamente mediante la coherencia, la visión y la comunicación efectiva.

Ese equilibrio entre liderazgo personal y reputación institucional se refleja también en EAFIT. Así lo considera Catalina Suárez Restrepo, jefa del Departamento de Comunicación de EAFIT, quien compartió que “la presencia de la rectora Claudia Restrepo entre los 20 líderes con mejor reputación del país, y el reconocimiento de EAFIT como la primera universidad privada de Antioquia y la segunda en Colombia en el más reciente ranquin Merco Empresas, evidencian ese círculo virtuoso entre el liderazgo coherente del CEO y el de la organización. En nuestro caso, esa coherencia es parte esencial de la reputación que construimos día a día”.

De esta forma, los resultados de Merco 2025 reafirman el papel de EAFIT como una Institución que forma y proyecta líderes capaces de incidir, transformar y generar confianza, al tiempo que consolida su reputación corporativa en el ámbito nacional.

###### Los líderes con mejor reputación de Colombia: una nueva era del liderazgo empresarial

**Por Alex Garzón Lasso, director de In-sight de EAFIT, centro de liderazgo de impacto**

“El más reciente ranking Merco Líderes Colombia 2025 reconoce a los líderes con mayor reputación y admiración en el país. Este listado se ha convertido en una referencia clave para entender cómo el liderazgo colombiano está evolucionando hacia modelos más humanos, sostenibles y con propósito. Estar entre los primeros lugares no solo representa éxito empresarial, sino también la capacidad de inspirar confianza, generar impacto positivo y construir valor compartido.

Estos líderes encarnan un cambio profundo en la manera de dirigir las organizaciones. Han pasado de un liderazgo basado en la autoridad y el control a uno centrado en la inspiración, la coherencia y la ética. Demuestran que la innovación, la sostenibilidad y el bienestar de las personas son hoy pilares inseparables de la competitividad empresarial. En sus empresas, los resultados financieros caminan de la mano con la responsabilidad social y la transformación cultural.

Sobresale la presencia de líderes que trascienden el ámbito corporativo tradicional, como Claudia Restrepo Montoya, rectora de EAFIT, quien representan el papel del conocimiento, la educación y la investigación en la construcción de una sociedad más ética y consciente.

En conjunto, los primeros 20 del ranking Merco representan una generación de líderes que entienden la organización como un agente de transformación social. Su influencia se mide no solo por la magnitud de sus empresas, sino por la capacidad de movilizar confianza, inspirar propósito y dejar huella positiva. Son líderes que actúan con visión de largo plazo, promueven culturas organizacionales centradas en las personas y asumen su rol con autenticidad y responsabilidad. Líderes que impulsan un liderazgo que combina la inspiración, visión compartida, adaptabilidad, desarrollo y liderazgo de sí misma.

En una época donde la reputación se ha convertido en el activo más valioso, estos líderes demuestran que el verdadero éxito empresarial se construye sobre la base de la coherencia, la ética y el impacto. Su ejemplo invita a repensar la manera de liderar en Colombia: no como un ejercicio de poder, sino como una oportunidad de inspirar, crear y transformar”.

#### Historias y noticias recomendadas

![Image 22: Imagen En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones](https://universidadeafit.widen.net/content/5efee09c-1aeb-4505-b893-e415936a4fcf/web/Desafios-empresariales.jpg?crop=yes&k=c&w=823&h=450&itok=2I2kS4Ud)

[Empresas y negocios](https://www.eafit.edu.co/taxonomy/term/1856)
###### En EAFIT los desafíos empresariales llegan al aula y se transforman en soluciones

Una red de agua helada con pérdidas de eficiencia, una selladora industrial que requería mejorar su confiabilidad, sistemas energéticos con alto consumo y procesos que podían automatizarse: esos son algunos de los retos de empresas del sector productivo que cruzaron la puerta del aula y que hoy cuentan con propuestas desarrolladas por estudiantes de la Escuela de Ciencias Aplicadas e Ingeniería de EAFIT.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/en-eafit-los-desafios-empresariales-llegan-al-aula-y-se-transforman-en "Leer más")

Mayo 7, 2026

![Image 23: Imagen Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano](https://universidadeafit.widen.net/content/c5dd5394-7a1b-46bc-93d4-e01ffbbe080a/web/Patente-caminador.png?crop=yes&k=c&w=823&h=450&itok=elgTvZ7o)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### Caminador para personas con dificultades de movilidad le fue patentado a EAFIT y la Fundación Universitaria María Cano

La movilidad es uno de los factores que más influye en la autonomía y la calidad de vida de las personas, especialmente en quienes enfrentan procesos de rehabilitación o dificultades para caminar.

[Leer más](https://www.eafit.edu.co/noticias/nuestro-impacto/caminador-para-personas-con-dificultades-de-movilidad-le-fue-patentado "Leer más")

Abril 30, 2026

![Image 24: Imagen EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología](https://universidadeafit.widen.net/content/9e97e1f2-ee3f-46aa-a923-d0b06278bd58/web/campus-vivo-1500.jpg?crop=yes&k=c&w=823&h=450&itok=ET4zIEwS)

[Investigación](https://www.eafit.edu.co/taxonomy/term/2626)
###### EAFIT es un campus vivo donde aprender conecta manos, mente y tecnología

La Plazoleta del Estudiante se transformó este miércoles 22 de abril en un espacio de experimentación y conexión con la _Muestra de iniciativas inspiradoras de aprendizaje experiencial_. Prototipos en impresión 3D, simuladores, juegos interactivos y modelos matemáticos se encontraron en una misma escena para dejar a un lado la teoría abstracta y permitir que estudiantes, profesores y colaboradores activaran los sentidos alrededor de diferentes proyectos.

[Leer más](https://www.eafit.edu.co/noticias/nuestra-comunidad-de-talento/eafit-es-un-campus-vivo-donde-aprender-conecta-manos-mente-y "Leer más")

Abril 23, 2026

[Ver todas las historias y noticias](https://www.eafit.edu.co/noticias)

##### Nuestros programas

[Conoce los pregrados](https://www.eafit.edu.co/pregrados)[Conoce los posgrados](https://www.eafit.edu.co/posgrados)

_**Última actualización**_

Octubre 23, 2025

![Image 25: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 26: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 27: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 28: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 29: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 30: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 31: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 32: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 35](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
