Title: Convenios graduados

URL Source: https://www.eafit.edu.co/bienestar-universitario/convenios/graduados

Markdown Content:
# Graduate agreements - EAFIT University

Display content with high contrast for people with visual impairments.

A- Reduce the font size.

A. Restore the original font size.

A+ Increase the font size.

Enable audio for users with visual impairments or other similar needs.

Customer service in sign language.

Configure the website language.

Close modal

[![Image 1: Start](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Discover your profile at EAFIT

Are you a student, professor, graduate, or part of an organization? Explore the options and find the personalized information EAFIT has for you. Click on your profile and access resources, news, and events designed especially for you. Your EAFIT experience starts here!

**Your EAFIT experience starts here!**

Students and graduates

![Image 2: Image of students and graduates](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Employees

[Login](https://entrenos.eafit.edu.co/ "Login")

![Image 3: Employee Image](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Teachers

[Learn more](https://www.eafit.edu.co/profes-que-inspiran "Learn more")

![Image 4: Image of Teachers](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Children and young people

[Learn more](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Learn more")

![Image 5: Image of children and young people](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizations

[Learn more](https://www.eafit.edu.co/organizaciones "Learn more")

![Image 6: Image of Organizations](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Close profiles

Information for you

[![Image 7: Start](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   That's EAFIT

Return
    *   [Institutional Information](https://www.eafit.edu.co/institucional)
    *   [This is how we learn at EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Campus Life](https://www.eafit.edu.co/universidad-parque)
    *   [Schools and academic areas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Headquarters](https://www.eafit.edu.co/nuestras-sedes)
    *   [Academic achievements and excellence](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Environmental sustainability](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Study at EAFIT

Return
    *   [Undergraduate](https://www.eafit.edu.co/pregrados)
    *   [Postgraduate studies](https://www.eafit.edu.co/posgrados)
    *   [Continuing education](https://www.eafit.edu.co/otros-programas)
    *   [Languages](https://www.eafit.edu.co/idiomas)
    *   [Children's University](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Events, conferences and seminars](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Scholarships and funding](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Registration and enrollment](https://www.eafit.edu.co/registro-academico)

*   Science, Technology and Innovation

Return
    *   [CTel System](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigation](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovation, transfer and technology](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Science, Technology, and Innovation Culture](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Training](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Children's University](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Study and impact centers](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Project portfolio](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Library](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Connecting with organizations

Return
    *   [Connections and services](https://www.eafit.edu.co/organizaciones)
    *   [Companies](https://www.eafit.edu.co/empresas)
    *   [Public systems](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Startups / Ongoing](https://www.eafit.edu.co/ongoing)
    *   [Center for emerging technologies / Node](https://es.nodoeafit.com/)
    *   [Study and impact centers](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transform with us](https://www.eafit.edu.co/filantropia)
    *   [Talent pathways and internships](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduates](https://www.eafit.edu.co/graduados)
    *   [Research and consulting](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internationalization

Return
    *   [Internationalization at EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [International exchanges](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [National exchanges](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Agreements](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Internships abroad](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [International missions](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Global learning](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Culture and Wellbeing

Return
    *   [Culture](https://www.eafit.edu.co/vida-cultural)
    *   [EAFIT Symphony Orchestra](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [EAFIT Publishing House and Bookstore](https://www.eafit.edu.co/editorial)
    *   [Arts center](https://www.eafit.edu.co/centro-de-artes)
    *   [Heritage Room](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [University welfare](https://www.eafit.edu.co/bienestar-universitario)
    *   [Mental health](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 8: EAFIT University logo in white](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 9: Facebook icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 10: Instagram icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 11: LinkedIn icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 12: YouTube icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 13: White X icon](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 14: Spotify icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 15: TikTok icon in white](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

[Skip to main content](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#main-content)

[![Image 16: Start](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accessibility

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Language

Powered by [![Image 17: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[Español](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#)

[Español](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados# "Spanish")[Inglés](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados# "English")

Information for you

Look for 

Search

Menu

![Image 18: Banner image with blue background for courses](https://universidadeafit.widen.net/content/5b3897fe-c326-414b-acfc-c41a4f335389/web/Fondo_azul_cursos.png?crop=yes&k=c&w=1920&h=788&itok=FTV0nOBb)

# Agreements

*   [Start](https://www.eafit.edu.co/)
*   [University Welfare](https://www.eafit.edu.co/bienestar-universitario)
*   [Agreements](https://www.eafit.edu.co/bienestar-universitario/convenios)
*    Graduate Agreements 

*   [PadelHub](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-2862718160)
*   [Colmédica](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-2240000526)
*   [CEM – Medical Emergency](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-521618204)
*   [VetPlus](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-3396691555)
*   [Foresee](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-158050060)
*   [Directory of health services](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-419417897)

[PadelHub](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-2862718160)

PadelHub

[![Image 19](https://universidadeafit.widen.net/content/4a6f6a49-5149-4794-b246-0a73b3425903/web/padel-hub-logo.jpg)](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

![Image 20](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

Padel is a racket sport played in pairs on an enclosed court, combining elements of tennis and squash. It is distinguished by its dynamism and strategy, using glass walls and metal mesh to keep the ball in play.

With rules and scoring similar to tennis, padel is accessible to all ages and skill levels, promoting both physical exercise and competitiveness in a social environment.

Physical and mental benefits.

A key ally for personal well-being.

It improves physical fitness and endurance.

It regulates blood pressure.

It helps maintain good bone density.

Improves flexibility.

Strengthens muscles, tendons, ligaments and joints.

It helps with weight loss.

It is not a contact sport, it has a minimal risk of injury.

Through our partnership with the University, you will have the following benefits:

Padel court rental with 20% discounts.

Ticket sales for individual classes with a 10% to 15% discount.

Access to sports training programs in padel, in order to provide spaces for recreation and physical activity.

Purchase a basic package for organizing padel tournaments, tailored to your objectives and execution requirements, including souvenirs, meals, and other services.

###### Contact

Andrés Correa

[gerencia@padelhub.com.co](mailto:gerencia@padelhub.com.co%E2%80%8B)

3162384458

Contact headquarters PADEL FASHION HUB: 3235117565

To redeem the benefit you must book through the EASY CANCHA APP and pay at least 25% of the booking.

When making the reservation, you will need to pay the remaining balance. The discount will be applied by the advisor at the venue once you present your EAFIT University ID.

For more information about the company and the products it offers, visit https://www.padelhub.com.co/[](https://www.padelhub.com.co/)

*Applies to the PADEL HUB DE MODA, PADEL HUB BOLIVARIANA, and PADEL HUB PREMIUM PLAZA locations.

[Colmédica](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-2240000526)

Colmédica

[![Image 21: Imagen de logo Col Médica](https://universidadeafit.widen.net/content/bef4848e-7bfd-4649-9765-6712d24ce1e9/web/logo-colmedica-370.jpg)](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

![Image 22](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

Colmedica Medicina Prepagada ofrece el plan de beneficios para los egresados de la Universidad, el cual aplica para los padres, parejas e hijos de los egresados. Dicho beneficio es directo para el egresado que desee tener otra alternativa de Salud diferente al plan de beneficios en Salud. Las tarifas aplican para cualquier sede nacional.

###### Contacto​

**Call Center**

301 394 45 40

[www.felizconcolmedica.com](https://www.felizconcolmedica.com/)

[CEM – Emergencia Médica](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-521618204)

CEM – Emergencia Médica

[![Image 23](https://universidadeafit.widen.net/content/f269c5bf-0e23-40ce-8e7c-edefb8176901/web/logo-coomeva.jpg)](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

![Image 24](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

​Es un servicio de atención médica para aquellas personas que deseen ser atendidas en la comodidad de su hogar o en el lugar donde se encuentren, ofrece la atención de urgencias, emergencias y consultas médicas.

Solicitar el servicio a la persona de Marsh que está asignada como contacto.

**Empleados planta:** Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

**Empleados cátedra:** El empleado deberá realizar el pago directamente en Sura.

**Empleados temporales:** El empleado deberá realizar el pago directamente en Sura.

**Estudiantes de pregrado:** El estudiante deberá realizar el pago directamente en Coomeva.

**Estudiantes de idiomas:** El estudiante deberá realizar el pago directamente en Coomeva.

**Egresados:** El egresado deberá realizar el pago directamente en Coomeva.

**Pensionados:** El pensionado deberá realizar el pago en la caja de la Universidad o transferir a una cuenta el valor correspondiente a los seguros, en los primeros 10 días calendario de cada mes.

_* Aplica a nivel nacional._

###### Contacto​

[delima​​@eafit.edu.co​](mailto:delima%E2%80%8B%E2%80%8B@eafit.edu.co%E2%80%8B)

310236​​6526

[VetPlus](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-3396691555)

VetPlus

[![Image 25: Imagen de logo Vetplus](https://universidadeafit.widen.net/content/522b0d71-5fa7-43ed-856d-930ea74d7973/web/logo-vetplus.jpg)](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

![Image 26](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

​​​​​​​​​Servicio de Medicina Prepagada Veterinaria con cobertura a nivel nacional. Presta servicios de medicina preventiva, atención y tratamiento de urgencias, enfermedades y accidentes.

En convenio con la Universidad, se obtiene descuento sobre la tarifa de los diferentes planes ofrecidos por VetPlus.

Aplica para perros y gatos.

_* Aplica a nivel nacional.​_

###### Contacto​​

Tomás Restrepo

[tomas.restrepo@guiabien.com​](mailto:tomas.restrepo@guiabien.com%E2%80%8B)

3126985599

Para mayor información de la Compañía y de los productos que ofrece.

Visita la página [www.vetpluscolombia.com](https://www.vetpluscolombia.com/)

[Prever](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-158050060)

Prever

[![Image 27: Imagen de logo Prever](https://universidadeafit.widen.net/content/3909d86c-afc5-448b-8cb2-b6ad31a47ffe/web/logo-prever.gif?animate=true)](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

![Image 28](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

Plan de servicio exequial no reembolsable en dinero que otorga tarifas preferenciales sin límite en lazos de consanguinidad o afinidad.

También incluye servicio exequial para mascotas (perros y gatos).

[Conoce la cobe​rtura](https://universidadeafit.widen.net/s/fg69dgvxx6/cobertura-prever-2024-2025)

**Pago por nómina****

$ 3.650​ por afiliado.

**Pago por directo**

Plan Previ familia Clásico $5.800 por cliente.

Plan Previ familia Especial $7.400 por cliente.

* Cancelando el trimestre obtiene 20% de descuento o si cancela semestre o anualidad, tiene el 25% de descuento.

* Aplica a nivel nacional.

** Para acceder al servicio de descuento por nómina, el empleado deberá contar con capacidad de deducción que corresponde al 50% de su salario y deberá cumplir con las políticas de deducción.

***Pago por nómina solo aplica para empleados de planta

###### Contacto​

**Ángela María García**

Teléfono: (57) 3218383205​

E-mail: [angela.garcia@prever.com.co](mailto:angela.garcia@prever.com.co)

[Directorio de servicios de salud](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados#4257225834-419417897)

Directorio de servicios de salud

##### Directorio de servicios de salud

​​​​​​​​​​​Este servicio es atendido por un grupo de médicos especialistas e instituciones recomendados por la universidad que ofrecen excelentes servicios tarifas diferenciales a: estudiantes de educación formal, empleados con contrato laboral con EAFIT, estudiantes extranjeros, personas con contrato por prestación de servicios

[![Image 29: Imagen de directorio convenios de salud mental](https://universidadeafit.widen.net/content/1cc3c28a-8a1b-43a7-9e35-d3d8b1a3ae5e/web/NEWS.jpg)](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

![Image 30](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

###### AO_DIRECTORIO_SALUD_MENTAL.pdf

[Conoce](https://universidadeafit.widen.net/s/s8zx6lhsjn/ao-directorio-salud-mental)

En el momento se estan actualizando los convenios con nuestros aliados médicos, las tarifas aún pueden variar

###### DIRECTORIO 2024.pdf

[Conoce más](https://universidadeafit.widen.net/s/kgdh2dl25z/directorio-2024)

**EAFIT University, through its Human Development Department, has entered into agreements with external entities to provide benefits, which may include discounts or a value proposition, among others, depending on the campaign activated and differentiated for the beneficiaries of each agreement, to whom the following conditions and restrictions apply:**

1.   Those benefiting from the agreements must validate the terms of the agreements and the procedures established for accessing the benefits; additionally, they must bear in mind that to acquire said benefits they must present the original of the card and/or other documents that prove the required link.
2.   Será la respectiva Entidad Externa la que le facturará directamente a los beneficiarios, y estos últimos deberán cancelar las sumas debidas al momento de la facturación o cuando así lo determine la mencionada Entidad. Por lo anterior, la Universidad EAFIT no asumirá la responsabilidad por los pagos realizados.
3.   La Universidad EAFIT no se hará responsable por el cumplimiento de las obligaciones asumidas por los beneficiarios, ya que se precisa que éstos actuarán en todo momento a título personal y en ningún caso bajo representación de la Universidad EAFIT.
4.   Si la Universidad EAFIT llegare a recibir un reclamo de los beneficiarios, con ocasión de los convenios aquí relacionados, direccionará el mismo a la correspondiente Entidad Externa, quien será el responsable directo de atenderlo y darle una oportuna respuesta.
5.   La Universidad EAFIT no adquiere obligación alguna por la prestación de los servicios por parte de las Entidades Externas aquí mencionadas. En caso de presentarse algún daño, deficiencia o perjuicio a los beneficiarios, durante o después de la prestación del servicio, será responsabilidad únicamente de la respectiva Entidad Externa el resarcimiento del mismo.Para el caso de los beneficiarios que ostenten la condición de empleados de la Universidad EAFIT, se advierte que los beneficios derivados de los convenios aquí mencionados, son de carácter discrecional, los cuales no constituyen salario en tanto no están retribuyendo el servicio que prestan los empleados a la Institución.
6.   La Universidad EAFIT y las Entidades Externas aquí mencionadas, declaran que rechazan todas las clases de Explotación Sexual Comercial de Niños y Adolescentes (ESCNA), reconociendo, implementando y apoyando las medidas necesarias para la prevención de la ESCNNA.

![Image 31: EAFIT University logo in white](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 32: Facebook icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 33: Instagram icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 34: LinkedIn icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 35: YouTube icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 36: White X icon](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 37: Spotify icon in white](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 38: TikTok icon in white](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 via Don Diego – Rionegro

Customer service line: (57) 604 2619500, ext. 9188

Email: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 39](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate

## We use cookies on this website to improve your user experience.

By clicking Accept, you consent to our use of cookies. [See our privacy policy .](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

Accept No, thanks
