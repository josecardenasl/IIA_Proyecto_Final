Title: Reglamento ingreso peatonal vehicular

URL Source: https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular

Markdown Content:
# Reglamento ingreso peatonal vehicular - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 3: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular# "English")

 Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 8: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 9: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 10: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 11: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 12: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 14: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 15: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 16: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 17: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 18: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 19: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 20: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 21: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 22](https://universidadeafit.widen.net/content/2cf87443-2409-4bbc-847b-e01a2fc5c0e3/web/campus-universitario-bloque-biblioteca.jpg?crop=yes&k=c&w=1920&h=788&itok=dvqtPeuf)

# ​​​​​​​Reglamento de ingreso peatonal y vehicular a la Universidad EAFIT

Consulta el reglamento de ingreso peatonal y vehicular de EAFIT. Normas para acceso seguro al campus en vehículos y a pie.

*   [Inicio](https://www.eafit.edu.co/)
*    Reglamento Ingreso Peatonal Vehicular 

*   [Principios generales​](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2632900448)
*   [Definiciones](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-3135293451)
*   [Ingreso Peatonal](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-811331795)
*   [Ingreso Vehicular](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-3725221582)
*   [Zonas de parqueo vehicular](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2528359569)
*   [Ingreso de bicicletas](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1341240390)
*   [Ingreso de patinetas eléctricas](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2319734641)
*   [Ingreso​ de visitantes](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-3112969669)
*   [Ingreso d​e personal con esquemas de protección](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-556947986)
*   [Ingreso de Proveedores](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1449451125)
*   [Ingreso de vehículos de Transpor​te de Valores](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2947835891)
*   [Ingreso de vehíc​ulos de transporte público](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-97476773)
*   [Pago del ser​vicio de parqueadero](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-245218310)
*   [Condiciones de uso del ser​​vicio de parqueadero](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1654882410)
*   [Reporte de daño y/o robo en las instalaciones de la universidad](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2340752066)
*   [Causale​s para la suspensión del servicio de parqueo](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1279547934)
*   [Consideraciones​​ para todo tipo de usuario​​](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1242834420)
*   [Consideraciones para el alquiler de espacios del parqueadero a terceros en cualquiera de las sedes](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2734724839)

[Principios generales​](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2632900448)

El presente reglamento establece las normas e instrucciones dirigidas a todo el personal que hace uso de las porterías, parqueaderos y áreas físicas de la Universidad EAFIT.

Todas las personas que ingresan a las instalaciones de la Universidad EAFIT, aceptan cumplir la presente reglamentación, acatar las indicaciones de los vigilantes, autoridades administrativas de la Universidad y autoridades oficiales competentes. La Universidad EAFIT cuenta con porterías para el acceso peatonal y vehicular a través de las cuales la comunidad eafitense puede ingresar usando el carné que le fue asignado por la Universidad o como visitante.

Independientemente de tener vínculo activo o no con la universidad EAFIT, cualquier persona podrá ingresar por las porterías de la universidad según las normas aquí contenidas.

[Definiciones](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-3135293451)

**Carné:** Documento de identificación expedido por la Universidad EAFIT que acredita a su propietario como miembro activo de algún programa y/o dependencia de la universidad.

**Celda:** Espacio delimitado, señalizado autorizado y destinado al uso del servicio de parqueadero vehicular.

Concesionario: Negocio comercial con marca propia ubicado dentro de la universidad EAFIT al cual se le ha otorgado el derecho de explotación de bienes y servicios por un periodo determinado. Ejemplo: cafeterías, papelerías, bancos, etc.

**Contratista:** Persona que labora en las instalaciones de la Universidad EAFIT pero tiene contrato laboral con otra empresa.

**Bicicleta:** Vehículo no motorizado de dos (2) o más ruedas en línea, el cual se desplaza por el esfuerzo de su conductor accionado por medio de pedales.

Bicicleta con pedaleo asistido: Bicicleta equipada con un motor auxiliar que actúa como apoyo al esfuerzo muscular del conductor.

**Bicicletero:** Espacio habilitado para el parqueo de bicicletas y su amarre mediante una guaya de seguridad de propiedad del usuario.

**Empleado:** Cualquier persona con contrato laboral directo con la Universidad EAFIT.

**Excedente:** Materiales de propiedad de la Universidad EAFIT resultantes de obras, reformas, reparaciones, demoliciones o actividades académicas que no serán reutilizados.

**Esquema de protección:**Conjunto de medidas tangibles e intangibles tendientes a la protección de una persona específica cuya integridad física se encuentra amenazada por un tercero. Hacen parte de este conjunto los escoltas, los carros blindados, el protegido y las actividades necesarias para su operación.

**Lectora vehicular:** Dispositivo electrónico ubicado en las entradas y salidas vehiculares al cual debe acercarse el carné o tiquete de parqueo para permitir la salida o ingreso vehicular.

**Proveedor:** Cualquier persona que requiera ingresar insumos, mercancías, papelería o cualquier elemento necesario para el funcionamiento de las dependencias de la universidad.

**Punto de pago automático:** Máquina automática de autoservicio con la cual se puede cargar saldo en el carné para diferentes usos y comprar de tiquetes de parqueo.

**Talanquera:**Dispositivo de señalización ubicado en las entradas y salidas vehiculares que a través de la elevación de una vara indica al conductor el momento de transitar a través de una puerta vehicular.

**Tiquete de parqueo:**Documento con código de barras que valida el pago del servicio de uso del parqueadero adquirido en uno de los puntos de pago automáticos de la universidad EAFIT.

**Vehículo:** Medio de locomoción que permite el traslado de un lugar a otro de personas o cosas, se consideran vehículos los carros, las motocicletas, las bicicletas y demás medios de locomoción.

**Visitante:**Cualquier persona que ingrese a la Universidad EAFIT sin utilizar el carné de ingreso expedido por esta.

**Zona de circulación:** Cualquier área diferente a una celda habilitada para el parqueo vehicular.

[Ingreso Peatonal](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-811331795)

El ingreso peatonal se realizará mediante el uso del carné institucional en los torniquetes peatonales o a través del registro en calidad de visitante.

**a) En el caso del uso de carné:**

El peatón debe acercar el carné al lector de carnés del torniquete y esperar que este se active para permitir el paso.

En el caso de menores de 14 años con acudiente, se permite que con el carné del menor de edad, ingrese también hasta un acompañante. El resto de acompañantes deben ingresar en calidad de visitante.

**b) En el caso ingreso como visitante:**

Se permitirá el ingreso mediante el registro del visitante de acuerdo al procedimiento de "registro de visitante" relacionado en el numeral 7 del presente reglamento.

**Portería peatonal principal ubicada en la avenida Las Vegas:**

**Lunes a viernes​​​****Sábados, domingos y festivos**
Ingreso 5:00 a.m. – 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m. – 6:00 p.m.

Salida hasta las 6:00 p.m.

**Portería peatonal de la calle 4 sur:**

**Lunes a viernes​​****Sábado****Domingos y festivos**
Ingreso 5:00 a.m. – 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m. – 6:00 p.m.

Salida hasta las 6:00 p.m.Cerrada

**Portería peatonal Las Vegas sector la Aguacatala:**

**​Lunes ​a viernes****Sábado****Domingos y festivos**
Ingreso 5:00 a.m.– 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 7:00 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.

**Portería peatonal Edificio de Ingenierías:**

**Lunes a viernes​​​****Sábado****Domingos y festivos**
Ingreso 5:00 a.m.– 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.Cerrada

**Portería peatonal avenida Regional / edificio Argos:**

**Lunes a viernes****Sábado, domingos y festivos**
Ingreso 5:00 a.m.– 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.

**Portería peatonal Parque los Guayabos (calle 5 sur):**

**Lunes a viernes****Sábado****Domingos y festivos**
Ingreso 5:00 a.m.– 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.Cerrada

**Portería peatonal Parque los Guayabos (avenida las vegas):​​**

Lunes a viernes Sábado Domingos y festivos
Ingreso 5:00 a.m.– 08:30 p.m

Salida hasta las 08:30 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.Cerrada

EAFIT Bogotá, Pereira, Llanogrande, Laureles, Belén, Balsos y sede Sur serán autónomas para la definición y modificación de horarios de acuerdo al flujo de actividades.

[Ingreso Vehicular](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-3725221582)

El ingreso vehicular se realizará mediante el uso del carné del conductor, lectura de placas asignadas a personal carnetizado o tiquete de parqueadero para el personal no carnetizado. ​

**a. ​​En el caso del uso de carné:**

​​El ingreso se permitirá siempre y cuando el último movimiento vehicular con el carné haya sido una salida en la misma zona de parqueo, de lo contrario el lector vehicular indicará que el usuario aún está dentro del parqueadero y negará el intento de ingreso.

La salida se permitirá siempre y cuando el último movimiento vehicular con el carné haya sido una entrada en la misma zona de parqueo, de lo contrario el lector vehicular indicará que el usuario ya está fuera del parqueadero y negará el intento de salida.

**b. En el caso del uso de lectura de placas (LPR):**

El ingreso se permitirá siempre y cuando el último movimiento vehicular con la placa haya sido una salida en la misma zona de parqueo, de lo contrario el lector de placa indicará que el usuario aún está dentro del parqueadero y negará el intento de ingreso.

La salida se permitirá siempre y cuando el último movimiento vehicular con la placa haya sido una entrada en la misma zona de parqueo, de lo contrario el lector de placa indicará que el usuario ya está fuera del parqueadero y negará el intento de salida. ​

Recomendaciones para el uso del sistema de lectura de placas (LPR):

El sistema de lectura de placas (LPR) no funciona en el 100% de los casos en ninguna instalación porque factores externos tales como lluvia, suciedad, luz, obstáculos, velocidad de aproximación, ángulo visual, etc pueden afectar dicha lectura. En estos casos, será el método alternativo (el carné) el que podrá suplir esta identificación. 

El carné y la placa no son excluyentes sino complementarios porque ambos están asignados a un solo usuario. 

Para que una placa sea reconocida por el sistema, el usuario deberá solicitar el registro de esta al correo [parqueadero@eafit.edu.co](mailto:parqueadero@eafit.edu.co) o presencialmente en la oficina de parqueaderos. Sólo se podrán registrar placas de personal carnetizado. 

La placa deberá estar ubicada correctamente en el vehículo, sin modificaciones ni obstáculos visuales que impidan su correcta lectura. 

El sistema únicamente lee placas con seis dígitos. 

Dado que la placa es un método de identificación para el control de acceso vehicular, el sistema no permitirá que una placa identifique a varios usuarios. 

La placa registrada siempre deberá estar asignada a un usuario con carné. Ambos métodos descontarán el saldo que el usuario tenga cargado en el sistema de parqueadero. 

En el caso de un usuario con varias placas inscritas, que ya esté dentro del parqueadero con alguna de ellas, el sistema no permitirá el ingreso simultáneo de más placas hasta que haya salido del parqueadero. 

No se recomienda el método de lectura de placas para vehículos compartidos ya que en caso de una lectura correcta de placa en el ingreso pero errónea en el momento de salir, únicamente el carné del titular de la placa será reconocido por la lectora vehicular.

**c. ​En el caso ingreso como visitante:**

El usuario deberá presionar el botón “TIQUETE” en la lectora de ingreso vehicular, a continuación le será emitido un tiquete con código de barras que será el medio de pago del servicio en cualquiera de los puntos automáticos.

[Zonas de parqueo vehicular](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2528359569)

Se cuenta con celdas para carros, celdas para motos y 22 bicicleteros que están al servicio de los usuarios del Campus principal. ​

La Universidad EAFIT cuenta con las siguientes áreas de parqueo para carros y motos:​

**a. Parqueadero vehicular de e​​mpleados:**

Ubicado en el Campus principal, cuenta con 110 celdas para parqueo de carros distribuidas de la siguiente forma:

3 celdas para personas en condición de movilidad reducida.

5 celdas para carros 100% eléctricos.

2 celdas para carros de baja emisión.

5 celdas para uso de proveedores de las cafeterías ubicadas detrás del bloque 7.

4 celdas para uso de motos de proveedores de las cafeterías ubicadas detrás del bloque 7.

91 celdas de uso general ubicadas entre los bloques 3, 7 y la malla de la avenida las vegas.​

Se permitirá el ingreso de vehículos hacia esta zona así:

**Portería vehicular avenida Regional / edificio Argos:**

**Lunes a viernes****Sábados, domingos y festivos**
Ingreso 5:00 a.m.– 10:30p.m

Salida hasta las 10:30p.m.Ingreso 6:00a.m.– 6:00p.m.

Salida hasta las 6:00 p.m.

**Portería vehicular de empleados avenida Las Vegas (puerta ubicada en la parte posterior del bloque 7):**

**Lunes a viernes****Sábado****Domingos y festivos**
Ingreso 5:00a.m.– 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.Cerrada

El ingreso a este parqueadero de lunes a viernes de 05:00 a 18:00 está restringido únicamente a empleados y proveedores. Entre las 18:00 y las 22:00, así mismo los sábados y domingos, se habilitará para todo tipo de público.

**b. ​Parqueadero vehic​​ular norte:**

Ubicado en el Campus principal, cuenta con 435 celdas para parqueo de carros distribuidas de la siguiente forma:

8 celdas para personas en condición de movilidad reducida.

4 celdas para vehículo de baja emisión

423 celdas de uso general

Se encuentra ubicado entre la avenida Las Vegas, cancha de fútbol principal, Biblioteca y el parque efímero.​

Se permitirá el ingreso y salida en este parqueadero así:

**Portería de ingreso vehicular Instituto del Plástico y del Caucho:**

**Lunes a viernes****Sábado****Domingos y festivos**
Ingreso 5:00 a.m. - 10:30 p.m Ingreso 6:00 a.m.– 6:00p.m.Cerrada

**Portería de salida vehicular norte ubicada en la Avenida las Vegas:**

**Lunes a viernes****Sábado****Domingos y festivos**
Salida 5:00 a.m. – 10:30 p.m Salida 6:00 a.m. – 6:00 p.m.Cerrada

A este parqueadero sólo se permite el ingreso de motos de proveedores de las dependencias y concesionarios ubicados en el área norte del campus en el horario de ingreso de proveedores establecido en el presente reglamento.

**c. Parqueadero ve​​hicular sur:**

Cuenta con 514 celdas para parqueo de carros y motos distribuidas de la siguiente forma:

4 celdas para personas con movilidad reducida.

4 celdas para vehículo de baja emisión.

8 celdas para motocicleta 100% eléctrica.

178 celdas de carro.

320 celdas para motocicleta.

Se encuentra ubicado entre el Barrio la Aguacatala II, la Avenida Las Vegas y el Edificio de Ingenierías, incluido el sótano del Edificio de Ingenierías.

A esta zona de parqueo podrá ingresar personal carnetizado y visitantes.

El ingreso de vehículos a este parqueadero se podrá hacer a través de las siguientes porterías:

**Portería vehicular la avenida Las Vegas sector La Aguacatala:**

**Lunes a viernes****Sábado****Domingos y festivos**
Ingreso 5:00 a.m.–10:30p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m.–6:00p.m.

Salida hasta las 7:00 p.m.Ingreso 6:00 am.–6:00 p.m.

Salida hasta las 6:00 p.m.

**Portería vehicular Edificio de Ingenierías:**

**Lunes a viernes****Sábado****Domingos y festivos**
Ingreso 5:00 a.m.–10:30 p.m.

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.Cerrada

**d. Parqueadero vehicular Parque los Guayabos**

Cuenta con 376 celdas para parqueo de carros y motos distribuidas de la siguiente forma:

4 celdas de carro para personas con movilidad reducida.

3 celdas de carro para proveedores.

249 celdas de carro de uso general.

120 celdas para motocicleta de uso general.

Se encuentra ubicado entre las calles 4 sur, 5 sur y avenida las Vegas; el personal exento de cobro deberá hacer uso de esta zona de parqueo.

El resto de la comunidad universitaria también podrá hacer uso de esta zona.

El ingreso de vehículos a este parqueadero se podrá hacer a través de la siguiente portería:

**Portería vehicular Parque los Guayabos ​**

**​Lunes a viernes****Sábado****Domingos y festivos**
Ingreso 5:00 a.m.– 10:30 p.m

Salida hasta las 10:30 p.m.Ingreso 6:00 a.m.– 6:00 p.m.

Salida hasta las 6:00 p.m.Cerrada

**e. Parquead​ero sede Llanogrande:**

Cuenta con 133 celdas distribuidas así:

90 celdas para carros.

40 celdas para motocicletas.

3 celdas para personas en condición de movilidad reducida.

El ingreso hacia esta zona se podrá hacer a través de la entrada vehicular de EAFIT Llanogrande en los horarios que tenga estipulados para tal fin.​

[Ingreso de bicicletas](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1341240390)

El ingreso y salida de bicicletas, incluidas aquellas de pedaleo asistido, se podrá realizar por cualquier portería peatonal de la Universidad EAFIT a través de las talanqueras acondicionadas para este tipo de vehículos y haciendo uso del carné. En caso de no portarse el carné, será necesario realizar el procedimiento de registro de visitante. Las bicicletas deben parquearse en cualquiera de los bicicleteros y ser asegurada al mismo por cualquier dispositivo de seguridad que suministre el propietario.

[Ingreso de patinetas eléctricas](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2319734641)

El ingreso y salida de patinetas eléctricas se podrá realizar por cualquier portería peatonal de la Universidad EAFIT a través de las talanqueras acondicionadas para este tipo de vehículos y haciendo uso del carné. En caso de no portarse el carné, será necesario realizar el procedimiento de registro de visitante. Las patinetas deben ser parqueadas en los bicicleteros.

[Ingreso​ de visitantes](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-3112969669)

Toda persona que no porte el carné institucional de EAFIT activo podrá ingresar y salir de las instalaciones de la Universidad EAFIT en calidad de visitante.

**Ingreso peatonal de visitantes:**

Para llevar a cabo el proceso de registro de ingreso peatonal en calidad de visitante, será necesario el registro en porterías de la siguiente información en el momento de ingresar:

Nombre completo del visitante.

Número de documento de identidad del visitante.

Fotografía de rostro del visitante que lo identifique plenamente.

Placa del vehículo en que ingresa el visitante.

Lugar de la universidad al cual el visitante manifiesta dirigirse.

Descripción de las herramientas de construcción declaradas como propias y mostradas por el visitante.

Descripción de la bicicleta para el caso de ciclistas.

Los visitantes deberán identificarse en la portería de ingreso con un documento de identidad original válido (cédula, tarjeta de identidad, pasaporte o contraseña); una vez hecho el registro de la visita se devolverá el documento al propietario, para este proceso no se retendrá el documento de identidad en la portería. No se permitirá el ingreso con documentos de identidad prestados, ilegibles o diferentes a los enunciados. El vigilante registrará para cada visitante los datos del documento de identidad, fotografía y descripción del vehículo y herramientas de trabajo que ingresa.

Si en el momento de salir, el visitante porta equipos tales como herramientas, materiales de construcción, bicicletas, equipos de cómputo o mobiliario será necesaria la demostración de posesión lícita sobre el bien a retirar, para esto; el vigilante podrá verificar en sus sistemas de información de apoyo si el visitante tiene autorización para retirar el elemento; en caso negativo, el supervisor de seguridad verificará la posesión de los elementos con un responsable de la dependencia visitada; si no es posible se tomarán nuevamente los datos del visitante, números de teléfono, fotografías y descripción de los elementos, y se permitirá la salida dejando nota en la minuta del puesto.

En caso que requiera ingresar un menor de 14 años con acudiente y el menor no porte carné, se registrará al acudiente.

En caso que requiera ingresar un menor de 14 años que esté solo y porte la tarjeta de identidad, se registrará su visita normalmente.

En caso que requiera ingresar un menor de 14 años que esté solo y no porte su tarjeta de identidad, el vigilante preguntará al menor su nombre completo y consultará el número de documento con la central de monitoreo para hacer el registro de la visita.

En el caso de menores de edad carnetizados y acudiente no carnetizado, el acudiente podrá ingresar con el carné del menor de edad.

La Universidad EAFIT cuenta con porterías habilitadas para registrar el ingreso de visitantes en el sistema de registro de visitantes así:

Portería peatonal principal avenida Las Vegas.

Portería peatonal edificio de Ingenierías.

Portería peatonal avenida Regional (Edificio Argos)

Portería peatonal calle 4 sur.

Portería peatonal y vehicular Parque los Guayabos (Calle 5 sur)

Portería peatonal Parque los Guayabos (Avenida las Vegas)

Portería peatonal Casas Aguacatala

Portería peatonal EAFIT sede Sur.

Portería peatonal EAFIT Pereira.

El horario de ingreso de visitantes a EAFIT Bogotá, Pereira, Llanogrande, Laureles, Belén, Balsos y sede Sur será estipulado por cada dependencia de acuerdo al flujo de actividades.

**Ingreso vehicular de visitantes:**

En el caso de visitantes en vehículo, el usuario debe presionar en botón “TIQUETE” en la lectora de ingreso vehicular, a continuación le será expedido el tiquete físico con código de barras y posteriormente la talanquera de ingreso se levantará.

En el momento del ingreso el sistema tomará registro fotográfico del vehículo, placa y ocupantes.

El horario de ingreso de visitantes a EAFIT Bogotá, Pereira, Llanogrande, Laureles, Belén, Balsos y sede Sur será estipulado por cada dependencia de acuerdo al flujo de actividades.

[Ingreso d​e personal con esquemas de protección](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-556947986)

El personal que hace uso de esquemas de protección está exento de medida de pico y placa; para gestionar dicha autorización debe ponerse en contacto con la Coordinación de Seguridad para realizar el trámite correspondiente.

El personal organizador de eventos con presencia de personas protegidas debe solicitar al Coordinador de Seguridad con mínimo 24 horas hábiles de anticipación la reserva de celdas para uso de los miembros del esquema de protección. Así mismo debe poner en contacto al jefe de dicho esquema con el Coordinador de Seguridad de la universidad para establecer los detalles de ingreso, permanencia y salida según las políticas de protección de cada esquema.

El armamento de escoltas debe permanecer oculto y debe ser manipulado siempre bajo las medidas del decálogo de seguridad para el manejo de armas de fuego. Adicionalmente debe cumplir con todas las normas legales para su uso, tenencia y porte en el territorio de Colombia.

[Ingreso de Proveedores](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1449451125)

El ingreso de los proveedores podrá realizarse en las siguientes porterías:

Portería vehicular de empleados avenida las Vegas, portería vehicular edificio Argos y portería peatonal avenida las Vegas para los locales ubicados el área central del campus principal.

Portería de la avenida regional, contigua al Instituto del Plástico y portería 4 sur para los locales ubicados en el área norte del campus principal.

Portería vehicular las vegas sector la Aguacatala (Ubicada antes del puente de la Aguacatala) y portería peatonal de Ingenierías. para los locales ubicados en el área sur del campus principal.

Portería vehicular Guayabos calle 5 sur y portería peatonal Guayabos avenida las Vegas para los locales ubicados en el Parque los Guayabos.

**El horario de ingreso de proveedores será el siguiente:**

**Lunes a viernes****Sábados**
5:00 a.m. a 4:30 p.m.6:00 a.m. a 2:00 p.m.

El horario de ingreso de proveedores para EAFIT Bogotá, Pereira, Llanogrande, Laureles, Belén, Balsos y sede Sur será estipulado por cada dependencia de acuerdo al flujo de actividades.

Los proveedores que se dirigen al almacén general podrán ingresar en cualquier horario.

Durante su estadía dentro del campus, los vehículos de proveedores que no estén dentro de una celda de parqueo no deben estar abandonados, el conductor debe evitar todo el tiempo obstaculizar el flujo vehicular y peatonal en los parqueaderos. En caso tal de obstaculizar el flujo, el personal de seguridad del campus solicitará mover el vehículo y este deberá ser movido.

Una vez dentro de las instalaciones de la universidad, los vehículos de proveedores deberán iniciar de inmediato el cargue/descargue y proceder con el retiro del vehículo.

[Ingreso de vehículos de Transpor​te de Valores](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2947835891)

El horario para el ingreso de vehículos de transporte de valores podrá realizarse en cualquier horario.

Estos vehículos podrán ingresar por cualquier portería de ingreso vehicular que se encuentre en servicio. Para facilitar la agilidad en la operación se recomienda el ingreso por la portería Argos o por la portería vehicular de empleados de las Vegas y parquear frente al bloque 18. Si este personal prefiere dejar el vehículo afuera del campus, podrá ingresar por cualquier portería peatonal que se encuentre en servicio, en todos los casos el personal y vehículos que ingresen deberán identificarse en porterías.

Durante su estadía dentro del campus, los vehículos de transporte de valores no deben estar abandonados, el conductor debe evitar todo el tiempo obstaculizar el flujo vehicular y peatonal en los parqueaderos. En caso tal de obstaculizar el flujo, el personal de seguridad del campus solicitará mover el vehículo y este deberá ser movido.

No se permitirá el ingreso de vehículos de transporte de valores ni personal de empresas de transporte de valores que no estén debidamente autorizados por la empresa correspondiente.

El personal que ingresa a realizar labores de transporte de valores debe extremar las medidas de seguridad con el uso de las armas de fuego y el buen trato a la comunidad universitaria.

Durante su estadía dentro de la universidad está prohibido bloquear y/o evacuar ascensores, pasillos, puertas, parqueaderos o realizar cualquier conducta que obstaculice el libre flujo peatonal y vehicular en las áreas comunes del campus.

Durante su estadía dentro del campus, el personal y vehículos de transporte de valores se acogen al contenido del presente reglamento; por lo anterior, deben seguir las recomendaciones y solicitudes realizadas por el personal de seguridad del campus en los casos en los que se detecten conductas que vayan en contravía de las instrucciones contenidas en el mismo.

[Ingreso de vehíc​ulos de transporte público](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-97476773)

Los vehículos de transporte público podrán ingresar a recoger los pasajeros por cualquier portería. Se recomienda su ingreso por la portería del Bloque 7 y portería Regional/Argos.

El ingreso por fuera del horario de funcionamiento de porterías deberá ser autorizado por el pasajero o el encargado de la dependencia contratante del servicio con 12 horas de anticipación al correo vigilancia@eafit.edu.co o a la línea de ayuda 2619500 extensión 8744. Así mismo, se podrá solicitar a esta línea la reserva de espacio para el parqueo de busetas y así facilitar su ingreso y recogida de pasajeros.

El ingreso de busetas contratadas por la universidad deberá realizarse por la portería de empleados de la avenida las vegas y portería regional edificio Argos. El ingreso de estas está sujeto a disponibilidad de espacio dentro del parqueadero y amplitud de los carriles de ingreso de las porterías.

[Pago del ser​vicio de parqueadero](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-245218310)

El servicio de parqueadero de la Universidad EAFIT está estipulado en un valor único por usuario durante todo el día de lunes a sábado. Los días domingos y festivos, servicio de parqueadero es gratuito.

Este servicio se cobra al personal que hace uso de vehículos motorizados.

Las tarifas del servicio de parqueo, periodos de cobro y no cobro, políticas de cobro y sus modificaciones serán informadas mediante comunicado a toda la comunidad universitaria.

Los usuarios son responsables, al ingresar a los parqueaderos, de contar con los recursos económicos necesarios para el pago del servicio de parqueadero por lo cual el personal de vigilancia no podrá hacer excepción alguna.

La universidad cuenta con presencia constante de técnicos para atender los casos de problemas relacionados con el funcionamiento de las lectoras vehiculares de ingreso, salida y puntos de pago. Para ponerse en contacto con alguno de ellos reporte la novedad al empleado de vigilancia más cercano o a la extensión 8744.

Los parqueaderos de la Universidad EAFIT tienen configurado un tiempo de gracia de 30 minutos para la comunidad en general y 60 minutos para vehículos de proveedores, tiempo durante el cual no habrá cobro del servicio.

Los vehículos que pernoctan, deberán cancelar a la Universidad EAFIT el valor correspondiente a cada día de uso del servicio de parqueo.

El pago del servicio de parqueadero en la Universidad EAFIT se efectúa de dos formas:

Mediante el uso del carné expedido por la Universidad EAFIT y recargado en los puntos de pago.​

Mediante la lectura de placas que descontará el saldo que el usuario titular de la placa tenga cargado en el carné.

Mediante el pago de tiquete de parqueadero en el caso de los visitantes.

**a) Pago del servicio de parqueadero con carné**

Si el usuario hace uso del carné para ingresar y salir, el cobro del servicio de parqueadero se llevará a cabo en el momento de la salida del parqueadero descontando del carné el valor correspondiente; para esto el usuario deberá acercar el carné a la lectora de salida vehicular y esperar que la talanquera se eleve, a lo cual debe iniciar la marcha inmediatamente.

Para realizar el ingreso al parqueadero, el sistema verificará que el usuario haya salido previamente del mismo con su carné, de no ser así, el sistema no permitirá el ingreso con carné.

El sistema permitirá la salida si el usuario ingresó previamente al parqueadero con su carné y dispone de saldo suficiente para el pago del servicio utilizado. De lo contrario el sistema impedirá la salida y será necesario el uso de tiquete de parqueadero para salir del mismo.

El uso del carné es personal e intransferible; si no se dispone de este, es necesario el uso del tiquete de parqueadero.

En caso de pérdida del carné, debe avisarse de inmediato a la línea de ayuda 8744 o 2619307 para el respectivo bloqueo. En ningún caso la Universidad EAFIT se hará responsable por los débitos realizados con este antes del reporte de pérdida.

**b) Pago del servicio de parqueadero con tiquete**

Este es el método de ingreso, pago del servicio y salida del parqueadero para el personal que no tiene un carné activo con la universidad. 

Para obtener el tiquete, el usuario debe presionar el botón “TIQUETE” en la lectora de ingreso vehicular, a continuación le será expedido el tiquete físico con código de barras y posteriormente la talanquera de ingreso se levantará.

En el momento del ingreso el sistema tomará registro fotográfico del vehículo, placa y ocupantes.

Una vez el usuario termina su actividad entro de la institución deberá pagar el servicio en cualquiera de los puntos de pago automáticos. Una vez pagado el servicio, el susuario dispone de 30 minutos para salir.

En la lectora de salida vehicular, el sistema verificará la validez del tiquete a través de los lectores de código de barras instalados en la salida vehicular. En cualquier caso de evasión o intento de evasión de pago del servicio, la universidad podrá iniciar las acciones administrativas, penales o disciplinarias correspondientes.

El tiquete sólo será válido para el vehículo que lo utilice por primera vez.

**c) Puntos de pago**

Los puntos de pago son máquinas automáticas de interacción con el usuario que ofrecen los siguientes servicios:

Carga de saldo en el carné en efectivo o con tarjetas débito/crédito​

Consulta de saldo de un carné

Pago de tiquete de parqueo​

Se han dispuesto puntos de pago en las siguientes ubicaciones:

Bloque 20 piso 1

Bloque 18 piso 1

Bloque 33 piso 1

Bloque 1 piso 5 ​

Bloque 38 piso 1

**d) Exentos de pago del servicio de parqueadero**

El personal exento de pago de servicio de parqueo en la Universidad EAFIT podrá hacer extensivo este privilegio a los familiares que sean miembros de la comunidad eafitense que utilicen el mismo vehículo del empleado exento y se encuentren cobijados por las políticas de vigentes de beneficios de la universidad. Para hacer uso de este beneficio deberá demostrarse la propiedad del vehículo por parte del exento y su vínculo con los familiares a quienes desee extender la exención. Sólo se autoriza extender este beneficio a padres, hijos y cónyuges.

El préstamo de un carné exento de cobro a cualquier persona, será causal para perder el beneficio, con independencia de las acciones disciplinarias y legales correspondientes.

El usuario que haga uso gratuito del servicio de parqueadero sin contar con autorización, será suspendido para el uso de este servicio hasta que cancele el valor adeudado a la Universidad EAFIT. En todos los casos, la Universidad EAFIT podrá reclamar el pago de cada día que el vehículo permanezca dentro de los parqueaderos de la Universidad.

Las solicitudes de exención de cobro de parqueo estarán sujetas a las políticas vigentes de beneficios de la universidad y deberán hacerse al correo vigilancia@eafit.edu.co, una vez procesada la solicitud se enviará una respuesta al solicitante.

[Condiciones de uso del ser​​vicio de parqueadero](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1654882410)

El manejo, la asignación, la interventoría y el control de los parqueaderos de la Universidad será responsabilidad de la Dirección Administrativa y Financiera, a través del Departamento de Planta Física.

El servicio de parqueadero prestado por la Universidad EAFIT se regirá por la normatividad Colombiana vigente, adicionalmente otorgará a las autoridades competentes la información disponible en aras de facilitar la investigación de hechos denunciados formalmente.

Las siguientes normas básicas deben ser atendidas por todo el personal que haga uso del servicio de parqueadero de la Universidad EAFIT:

El periodo de vigencia de la garantía del servicio de parqueadero en la universidad EAFIT es igual al tiempo de permanencia del vehículo dentro del parqueadero. Una vez retirado el vehículo de las instalaciones de la universidad, se entenderá expirado el periodo de vigencia de la garantía.

Cualquier reclamo deberá presentarse dentro del periodo de vigencia de la garantía, esto es, antes de retirar el vehículo de las instalaciones de la Universidad, de lo contrario se entenderá presentado por fuera del periodo de vigencia de la garantía.

La Universidad EAFIT no asumirá la responsabilidad por pérdida, hurto, daño o deterioro cuando estos se deban a fuerza mayor, caso fortuito, el hecho de un tercero, uso indebido del servicio por parte del usuario o no atender las instrucciones del presente reglamento.

Todos los vehículos que ingresen a las zonas de parqueo están sujetos al acatamiento de la normatividad legal vigente en el territorio nacional.

El estado de los vehículos podrá ser registrado en el momento de su ingreso y/o permanencia a través del uso de medios tecnológicos.

Una vez se levante la vara de la talanquera, el vehículo debe iniciar inmediatamente la marcha.

Los peatones tienen la prelación en todo momento y en todo lugar.

Los peatones, conductores de vehículos y maquinaria deberán extremar las medidas de seguridad y respeto por la vida, la integridad física y los bienes de los peatones, la universidad y ocupantes de otros vehículos.

Los vehículos deben dejarse dentro del parqueadero con todos sus mecanismos de seguridad activados.

Los vehículos deben parquearse en las zonas destinadas para cada tipo de vehículo.

Las bicicletas deben permanecer parqueadas en las zonas de parqueo de bicicletas de la universidad con guayas, candados o cualquier mecanismo de seguridad suministrado por el usuario. Las bicicletas parqueadas en sitios diferentes a los bicicleteros o detectadas sin guaya de seguridad podrán ser aseguradas temporalmente por el personal a seguridad, la guaya tendrá un letrero que informe al usuario a quien recurrir para desasegurar la bicicleta.

El ingreso y salida de bicicletas de visitantes deberá ser validado por el personal de vigilancia.

La Universidad EAFIT declara que no recibe objetos diferentes a aquellos que hacen parte de la estructura del vehículo dejados en este cualquiera que sea su naturaleza tales como computadores, teléfonos, bolsos, billeteras, joyas, dinero, títulos valores, equipos electrónicos, electrodomésticos, prendas de vestir, lentes, cámaras, navegadores GPS, llaves, cascos, impermeables, paquetes, etc. Por lo anterior, al no asumir la Universidad EAFIT la custodia, conservación y/o restitución de este tipo de elementos, no se responderá por su daño, pérdida o deterioro y se entenderá que el usuario o propietario de estos elementos ha decidido personalmente asumir el riesgo de custodia de los mismos bajo sus propias medidas de seguridad.

Está prohibido dejar en el vehículo computadores, teléfonos, bolsos, billeteras, joyas, dinero, títulos valores, equipos electrónicos, electrodomésticos, prendas de vestir, lentes, cámaras, llaves, cascos, impermeables, paquetes, etc. Antes de abandonar el vehículo deben ser retirados y llevados por el usuario.

La Universidad aplica la medida de Pico y Placa durante todo el día. El acceso vehicular estará restringido de acuerdo con la numeración, exenciones y condiciones dictadas por la alcaldía del Municipio de Medellín para la aplicación del pico y placa.

En EAFIT Llanogrande no aplica la medida de Pico y Placa.

La velocidad máxima permitida para todo tipo de vehículo dentro de las instalaciones es de diez (10) kilómetros por hora.

Está prohibida la realización de cualquier tipo de maniobra acrobática durante la conducción de un vehículo dentro de las instalaciones de la universidad EAFIT.

Está prohibida la utilización de dispositivos móviles de comunicación mientras se conduce.

El uso del cinturón de seguridad (o casco en el caso de los motociclistas) asegurado mediante el correcto uso de su sistema de retención, es obligatorio para todos los ocupantes del vehículo mientras el mismo se encuentre en movimiento.

En caso de colisión dentro de los parqueaderos, si no hay acuerdo entre las partes, se procederá a llamar a las autoridades de tránsito.

Todos los vehículos se deben estacionar en reversa y deberán quedar completamente cerrados y engranados.

En caso de pérdida de las llaves del vehículo, se deberá reportar la situación con el empleado de vigilancia más cercano o a la línea de ayuda extensión 8744 y 2619307. No se permitirá la apertura del vehículo con medios diferentes a copia de las llaves, o en caso de ser necesario, se autorizará a su propietario la apertura del vehículo por intermedio de un cerrajero; esta operación será asistida por el supervisor de seguridad con el fin de verificar que el carro corresponda a la persona que lo hace abrir; en caso de inconsistencia no se permitirá la salida del vehículo y se procederá a llamar a las autoridades competentes.

No se permite entregar las llaves del vehículo al personal de seguridad.

Las personas en condición de movilidad reducida están exentas de pico y placa.

Las celdas de color azul aplican para personas en condición de movilidad reducida, adultos mayores y mujeres gestantes.

Los espacios demarcados y destinados para personas en condición de movilidad reducida están regulados por la ley colombiana. Ante el mal uso de estas, la Universidad EAFIT podrá reportar el caso a las autoridades competentes.

Quienes no presenten condición de movilidad reducida deberán respetar las celdas exclusivas para las personas bajo dicha condición, así como las líneas que las demarcan.

Está prohibido el parqueo no autorizado en celdas de uso exclusivo de proveedores o celdas reservadas para el desarrollo de algún evento. En todos los casos, estas celdas estarán señalizadas.

La dependencia que por razón de la realización de alguna actividad requiera reservar celdas de parqueo, deberá hacer la solicitud con dos días hábiles de anticipación al correo monitoreo@eafit.edu.co; es importante tener en cuenta que el envío de esta solicitud no garantiza la reserva de parqueaderos. El equipo de seguridad confirmará la disponibilidad de los mismos y ofrecerá alternativas en caso de que no se cuente con estos.

Está prohibido el parqueo en zonas de circulación o vías perimetrales. El único sitio establecido para el parqueo de vehículos son las celdas de parqueo habilitadas. El vehículo que se estacione en zonas de circulación o zonas restringidas deberá responder por los daños y perjuicios que ocasione dicha conducta. La universidad EAFIT podrá acudir a las autoridades de tránsito para el retiro del vehículo.

Los vehículos que se dejen pernoctando en la Universidad deben tener autorización previa por parte del coordinador de seguridad. Los vehículos que sean dejados en el parqueadero pernoctando sin la debida autorización serán notificados a las autoridades competentes para que retiren el vehículo.

En todos los casos, el usuario deberá cancelar a la Universidad EAFIT el valor correspondiente a cada día de servicio de parqueadero utilizado.

Cuando se alcanza el máximo de ocupación, el parqueadero se cerrará y se habilitará el ingreso de vehículos en la medida en que se desocupen celdas.

Está prohibida la realización de trabajos de mecánica dentro del parqueadero. En tal caso, el vehículo deberá ser retirado con grúa al taller correspondiente. Los costos serán a cargo del propietario o conductor del vehículo.

[Reporte de daño y/o robo en las instalaciones de la universidad](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2340752066)

​Para el reporte de daño o hurto ocurrido dentro de las instalaciones de la Universidad, el usuario deberá realizar el siguiente procedimiento:

Avisar al personal de seguridad más cercano o llamar a la línea segura, extensión 8744 y 2619307.

El supervisor de seguridad de la empresa de vigilancia atenderá caso, dejando registro fotográfico de las novedades que le fueron reportadas.

El afectado deberá enviar comunicación escrita al correo monitoreo@eafit.edu.co informando los detalles la novedad ocurrida, como hora de ingreso a los parqueaderos, lugar de parqueo, descripción del vehículo (color, placas, marca), etc.

Una vez recibido el correo, se procederá a revisar las grabaciones de las cámaras de circuito cerrado de televisión y al término de cuatro días hábiles se dará respuesta al afectado, de lo observado.

En caso de daños a bienes de propiedad de la universidad o particulares ocasionados por un peatón o vehículo, se procederá a identificar al autor del daño y a informar a las instancias correspondientes.

En caso que la universidad así lo solicite, el afectado tendrá 15 días calendario para hacer entrega de cotización de reparación solicitada por la universidad; pasado este tiempo, la reclamación del afectado perderá validez.

[Causale​s para la suspensión del servicio de parqueo](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1279547934)

Serán causales de suspensión del servicio de parqueo las siguientes acciones:

**a) Entre 1 y 8 días calendario**

No identificarse con el respectivo documento al ingreso (carné o documento de identificación original).

Exceder el límite de velocidad dentro del Campus principal (10 kilómetros por hora)

Hacer uso innecesario de bocinas.

Hacer uso de equipos de sonido sin autorización que interrumpan las actividades académicas y/o administrativas de la universidad.

No parquear el vehículo en reversa.

No acatar las indicaciones de la vigilancia cuando se cierre el ingreso vehicular por cualquier razón.

Parquear sin autorización en celdas de directivos en celdas debidamente reservadas.​

Parquear sin autorización en las celdas de proveedores de las cafeterías centrales.

Inhabilitar el uso de celdas adyacentes mediante uso innecesario de dos o más celdas con un solo vehículo.

Conducir dentro de las instalaciones con uno o más ocupantes del vehículo sin el uso del cinturón de seguridad o casco asegurados mediante el correcto uso del sistema de retención de estos.

Conducir dentro de las instalaciones y utilizar simultáneamente elementos de comunicación.

**b) Entre 8 y 15 días calendario, las siguientes acciones:**

No respetar la medida de Pico y Placa.

Transitar peatonalmente por las vías de acceso/salida vehicular de las porterías.

No respetar los espacios destinados para personas en condición de movilidad reducida (En este caso la Universidad, además de aplicar la respectiva sanción relacionada en el presente reglamento, podrá informar a las autoridades de tránsito para que ejecuten el procedimiento legal respectivo)

Parquear un vehículo de gasolina o híbrido en celdas para vehículos 100% eléctricos.

**c) Entre 15 y 30 días calendario, las siguientes acciones:**

Agredir física o verbalmente al personal de seguridad.

Parquear en zonas de circulación, o áreas no destinadas a parqueo.

Presentar un tiquete falso o adulterado para el pago de parqueadero. (no aplica para EAFIT Llanogrande)

Prestar el tiquete de parqueadero o el carné para el ingreso o salida.

Ingresar o salir del parqueadero con un carné o tiquete prestado.

Ingresar o salir del parqueadero en el vehículo sin pasar la tarjeta o tiquete por la lectora.

Negarse a pagar el servicio de parqueo sin justificación. (no aplica para EAFIT Llanogrande)

Evadir el sistema de control de acceso vehicular y/o pago del servicio ingresando o saliendo detrás de un vehículo en marcha.

Evadir por cualquier medio el pago del servicio de parqueadero.

Para imponer las sanciones correspondientes al personal de estudiantes se recurrirá al reglamento estudiantil.

Para imponer las sanciones correspondientes al personal de empleados se recurrirá al reglamento interno de trabajo.

Para el caso de contratistas, outsourcing, empleados de los concesionarios, se procederá a notificarles a los respectivos ordenadores de gasto.

En todos los casos, la Universidad EAFIT actuará respetando el debido proceso, adicionalmente podrá acudir a las autoridades competentes para el cumplimiento del presente reglamento.

Para la ubicación e identificación del usuario infractor, la universidad EAFIT podrá, en casos de mal parqueo o abandono de vehículos, inmovilizar temporalmente el vehículo.

En caso de reincidencias se podrá suspender el ingreso vehicular de manera indefinida. Para este control, se llevará registro escrito de las personas que incumplan con el presente reglamento, notificándoles por escrito de cada decisión tomada por parte de la universidad. Las reincidencias serán sancionadas en todos los casos con 8 días calendario adicionales a la sanción correspondiente; la tercera reincidencia será sancionada con prohibición indefinida para el uso de servicio de parqueadero.​

[Consideraciones​​ para todo tipo de usuario​​](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-1242834420)

El uso del carné del personal carnetizado es obligatorio para el ingreso y salida de la Universidad.

El porte del documento de identificación original es obligatorio para el ingreso de visitantes.

El uso del carné es personal e intransferible, cualquier operación efectuada con un carné se entiende como realizada por su titular.

El uso del tiquete de parqueo es personal e intransferible, cualquier operación efectuada con un tiquete se entiende como realizada por la persona que lo utilizó por primera vez.

En caso de que algún miembro de la comunidad eafitense extravíe o pierda el carné, deberá reportarlo inmediatamente al teléfono (57) (4) 2619307 o a la extensión 8744; adicionalmente debe formular el denuncio de pérdida de documento ante las autoridades competentes.

En caso de pérdida de carné y necesidad de ingreso a algún sitio interno de la Universidad protegido mediante control de acceso con carné; será un empleado de seguridad quien validará la identidad y personalmente abrirá la puerta requerida. Esta solicitud deberá hacerse a la central de monitoreo.

En caso que un eafitense requiera permisos especiales de acceso a espacios restringidos protegidos mediante sistema de control de acceso con carné, será el responsable de dicho espacio quien solicitará la asignación de permisos al correo [monitoreo@eafit.edu.co](mailto:monitoreo@eafit.edu.co), así mismo será el responsable del espacio quien a través del mismo canal solicitará la des asignación de permisos en caso que la persona ya no deba tenerlos.

En caso de pérdida de carné, el usuario debe realizar el trámite de reposición en la oficina de carnetización.

El peatón, conductor u operario que ocasione daños y/o lesiones a personas, instalaciones y/o otros vehículos dentro de la Universidad EAFIT deberá asumir los costos por el tratamiento médico y/o por las reparaciones correspondientes.

Dentro de las instalaciones de la Universidad no se permite el uso sin autorización de bocinas, ni equipos de sonido con altos niveles de volumen.

Está prohibido el tránsito peatonal a través de las puertas vehiculares de las porterías. En todos los casos se aplicarán los reglamentos disciplinarios correspondientes y la sanción consignada en este reglamento.

Está prohibido el ingreso peatonal o vehicular con un carné prestado. En caso de detectarse un carné prestado, el personal de seguridad retendrá el carné y elaborará un informe al supervisor de seguridad. Posteriormente se contactará al propietario del carné para su devolución. Adicionalmente, la universidad EAFIT podrá efectuar las acciones disciplinarias y legales correspondientes.

Está prohibido saltar por encima de los torniquetes, mallas, rejas, talanqueras o cualquier otro tipo de cerramiento. Si se requiere ingresar o salir de un espacio cerrado, debe solicitarse el apoyo a la línea de ayuda 2619500 extensión 8744.

Está prohibido forzar mallas, puertas, ventanas, muros, techos y cualquier tipo de acceso irregular para ingresar a los espacios de la universidad, adicionalmente está prohibido causar daños a las instalaciones de la Universidad EAFIT. En caso de detectarse este comportamiento la Universidad EAFIT podrá iniciar las acciones legales correspondientes ante las autoridades judiciales y de policía.

Si se requiere ingresar a un espacio bajo llave, se debe llamar a la línea de ayuda de la central de monitoreo 2619500 extensión 8744.

Las puertas y ventanas de oficinas, aulas, laboratorios y demás espacios de la universidad deben ser dejadas con seguro en el momento en que el usuario encargado requiera retirarse. Así mismo todos los computadores deben estar asegurados a las mesas con guaya de seguridad.

Cada usuario es responsable por la custodia de los bienes personales o de propiedad de la universidad que tiene a su cargo.

Los elementos de todo tipo (prendas, celulares, libros, billeteras, dinero, documentos, cuadernos, etc) que sean encontrados abandonados dentro de la universidad, se presume que pertenecen a alguien que los olvidó y deben ser entregados al personal de seguridad ubicado en el piso 1 del bloque 18 quien procederá a rotularlos y almacenarlos en la bodega de elementos perdidos. Adicionalmente entregará un comprobante de recibo del elemento a la persona que lo ha devuelto.

En caso de pérdida de elementos, el afectado podrá verificar con el personal de seguridad del piso 1 bloque 18 si alguien ha encontrado y devuelto el elemento. En caso de encontrarse el elemento, el reclamante será relacionado con sus datos en la planilla de elementos devueltos y el elemento le será entregado.

En caso de pérdida de elementos y/o documentos a su cargo, el usuario deberá formular el denuncio correspondiente ante las autoridades competentes.

Está prohibido el hurto o robo de elementos en la Universidad EAFIT. En caso de hurto y/o robo de elementos, la Universidad EAFIT procederá a identificar al presunto autor e iniciar las acciones correspondientes ante las autoridades competentes.

Está prohibido el consumo de sustancias alucinógenas, psicoactivas o estupefacientes dentro de la institución.

El personal que se disponga a retirar bienes de propiedad de la universidad y excedentes de obra, deberá enseñar al portero el formato de salida de bienes de propiedad de la universidad.

El ejercicio de actividades comerciales y/o publicitarias dentro de las instalaciones de la universidad deberá contar con la autorización institucional, de lo contrario, el personal de seguridad podrá suspender la actividad.

En caso de detectarse actividades de volanteo, mendicidad, vandalismo, perifoneo, o cualquier otra actividad no autorizada que interrumpa las actividades sustantivas de la institución, el personal de seguridad procederá a suspender la actividad, en caso que la persona sea externa será retirada de las instalaciones, en caso que la persona sea de la comunidad universitaria, se procederá a informar al responsable de la dependencia a la cual pertenece, adicionalmente se podrá reportar la situación a las autoridades competentes.

Cualquier persona que detecte comportamientos sospechosos o actuaciones indebidas deberá reportar de inmediato la novedad al personal de seguridad más cercano o a la central de monitoreo a las líneas 9911 – 8744 para proceder con las acciones correspondientes.

En caso de cualquier situación que se considere de urgencia, la comunidad podrá reportarla a la extensión 9911.

En caso de pérdida de llaves o fallas de funcionamiento en las cerraduras de las áreas de trabajo, deberá solicitarse a la central de monitoreo la visita respectiva por parte del supervisor de seguridad para iniciar la gestión de apertura, reemplazo y/o arreglo correspondiente de llaves y/o cerraduras.

Las dependencias que requieran laborar en horarios adicionales a los horarios de funcionamiento de la universidad deberán informar de esta situación a la central de monitoreo al correo [monitoreo@eafit.edu.co](mailto:monitoreo@eafit.edu.co) o a la línea 8744, y 2619307.

La Universidad EAFIT podrá modificar el horario de apertura de porterías en cualquier momento según las necesidades. En todos los casos siempre habrá al menos una portería con operación las 24 horas para el ingreso de personal carnetizado sin necesidad de permisos especiales.

Durante los horarios de cierre de las porterías, los requerimientos de ingreso y salida vehicular o peatonal deberán hacerse al correo [vigilancia@eafit.edu.co](mailto:vigilancia@eafit.edu.co) o a la línea 8744, 9911 y 2619307.

El cumplimiento de los protocolos de bioseguridad es obligatorio para el ingreso a aquellos espacios que así lo requieran.

Con excepción de las autoridades en servicio, empresas de vigilancia y esquemas de protección, está prohibido el ingreso de armas a la institución.

[Consideraciones para el alquiler de espacios del parqueadero a terceros en cualquiera de las sedes](https://www.eafit.edu.co/reglamento-ingreso-peatonal-vehicular#230548828-2734724839)

La Universidad EAFIT podrá realizar el préstamo gratuito o en calidad de alquiler de espacios de parqueadero bajo las siguientes consideraciones:

La solicitud no es garantía de préstamo.

La entidad solicitante deberá asegurarse de conocer el área requerida.

No se puede inhabilitar el uso de celdas de discapacidad.

Si el préstamo es a título de alquiler, debe quedar por escrito las condiciones entre las partes donde se establezca, entre otras, el método de pago, responsabilidades de cada una de las partes, tiempo, valor. En estos casos, el prestatario debe asumir todas las responsabilidades derivadas del uso del espacio.

En el proceso de formalización del alquiler de espacios del parqueadero debe tenerse en cuenta el aval y sugerencias de las siguientes autoridades universitarias:

Seguridad y salud en el trabajo

Departamento de compras (pólizas)

Dirección administrativa y financiera

Coordinación de seguridad

Secretaría General.

El prestatario debe establecer por sus propios medios el método de validación del estado de los vehículos que ingresan y salen del parqueadero mientras el parqueadero esté a su cargo.

El alquiler de las áreas de parqueo deberá tener el aval de la Dirección Administrativa y Financiera.

**La Universidad EAFIT permite el ingreso a las instalaciones y permanencia del público según los procedimientos y horarios aquí establecidos, no obstante podrá impedir el ingreso o permanencia de personas que afecten el curso normal de las actividades institucionales. En todos los casos, estas situaciones podrán ser reportadas a las autoridades competentes.**

**La Universidad EAFIT de acuerdo a la Ley 1581 del 2012, informa que los datos personales solicitados en el momento de ingreso, así como la grabación de la permanencia con sistemas de videovigilancia, tienen como finalidad propender por la seguridad de las personas e instalaciones de la institución.**

**El personal que ingresa no está obligado a suministrar sus datos personales; en tal caso no podrá continuar con el proceso de ingreso a la institución.**

**Por anterior, el ingreso de la persona se entiende como su autorización a la Universidad EAFIT y sus aliados para el tratamiento de sus datos personales, su declaración que es titular de la información reportada y que la ha suministrado de forma voluntaria, completa, confiable, veraz, exacta y verídica.**

**El contenido de la política de tratamiento de protección de datos personales podrá verificarse en la página**[**www.eafit.edu.co**](https://www.eafit.edu.co/)

**El cumplimiento de los protocolos de bioseguridad de la Universidad EAFIT es obligatorio para todo público.**

![Image 23: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 24: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 25: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 26: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 27: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 28: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 29: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 30: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 33](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
