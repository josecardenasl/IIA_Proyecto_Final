Title: Educación y futuro

URL Source: https://www.eafit.edu.co/taxonomy/term/1836

Published Time: Fri, 08 May 2026 16:10:06 GMT

Markdown Content:
## [EAFIT tiene abierta su convocatoria de Becas Talento y Aliados para estudiar pregrado](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-tiene-abierta-su-convocatoria-de-becas-talento-y-aliados-para)

Marzo 18, 2026

**La Universidad abrió la séptima convocatoria de esta iniciativa que busca apoyar a bachilleres con excelencia académica, liderazgo y talento que requieren apoyo económico para acceder a la educación superior. El**[**formulario**](https://forms.office.com/pages/responsepage.aspx?id=XrX3mb6ce0aBQ5GXgpGK-7eXmzQySqBIjG-wl2JS4HhUMDFSMDRaN0paUk5ZR0paRlVXMFU3UjQzUi4u&route=shorturl)**de aplicación estará disponible hasta el 24 de mayo.**

**Las becas cubren entre el 40 % y el 100 % del valor de la matrícula de programas de pregrado y cuentan con el apoyo de aliados como el Grupo Nutresa, la Fundación Benéfica Santa Ana y la Fundación Aurelio Llano Posada. Los resultados se publicarán el 12 de junio.**

*   [Lee más sobre EAFIT tiene abierta su convocatoria de Becas Talento y Aliados para estudiar pregrado](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-tiene-abierta-su-convocatoria-de-becas-talento-y-aliados-para "EAFIT tiene abierta su convocatoria de Becas Talento y Aliados para estudiar pregrado ")

Para conocer los requisitos, fechas clave y el proceso de postulación, se puede consultar la información completa en este [**enlace**](https://www.eafit.edu.co/becas-y-financiacion/becas-talento-eafit).

Para muchos jóvenes en Colombia, acceder a la educación superior implica superar barreras económicas que pueden frenar sus proyectos de vida. Con el propósito de ampliar las oportunidades de formación profesional y acompañar a quienes se destacan por su liderazgo y excelencia académica, EAFIT abrió la séptima convocatoria de las Becas Talento y Aliados, una iniciativa que busca apoyar a bachilleres del país en su camino hacia la universidad.

Las becas cubren entre el 40 % y el 100 % del valor de la matrícula del programa de pregrado al que el estudiante sea admitido y cuentan con el apoyo de organizaciones aliadas como el Grupo Nutresa, la Fundación Benéfica Santa Ana y la Fundación Aurelio Llano Posada. Estas entidades se suman al propósito de ampliar el acceso a la educación superior, fortalecer el programa y ampliar su alcance. Esta es una de las iniciativas que permiten que la Institución cuente actualmente con cerca del 30 % de sus estudiantes con algún tipo de beca.

“Con estas becas brindamos oportunidades a jóvenes que quieren superarse, estudiar y proyectar su futuro, pero que no siempre cuentan con los recursos para hacerlo. A través de este programa pueden acceder a una educación de alta calidad y avanzar en la construcción de su proyecto de vida”, afirma Ricardo Uribe Marín, director de Desarrollo Humano y Bienestar de EAFIT.

Con esta convocatoria, que estará abierta hasta el 24 de mayo de 2026, la Universidad continúa consolidando un programa que en los últimos años ha permitido que más estudiantes ingresen a la educación superior. Hasta ahora, las Becas Talento y Aliados han beneficiado a más de 1.450 jóvenes provenientes de diferentes regiones de Colombia, quienes han encontrado en este apoyo una oportunidad para para construir su futuro a través de la educación.

El proceso de postulación se realiza de manera virtual y gratuita a través de un formulario único que permite aplicar a las diferentes opciones de beca disponibles en la convocatoria. Para participar, los aspirantes deben estar previamente admitidos a un programa de pregrado eafitense y diligenciar el formulario con la información solicitada, además de adjuntar los documentos requeridos dentro de las fechas establecidas.

De acuerdo con Cindy Jazmín Caicedo Patiño, coordinadora de Estímulos Estudiantiles de EAFIT, “estas becas buscan apoyar a jóvenes que han decidido construir su proyecto de vida a través de la educación. Les brindan la oportunidad de estudiar en nuestro campus y vivir una experiencia de aprendizaje activo, retador y con enfoque en la sostenibilidad”.

Por su parte, Ana María Gil Zapata, líder del programa Becas Talento pregrado, destaca que la convocatoria está dirigida a estudiantes con vocación de transformación social. “Estamos buscando a personas curiosas por el conocimiento, con compromiso, resiliencia y determinación para transformar su realidad y la de sus comunidades a través de la educación, y donde lo económico no sea una barrera para seguir desarrollando su potencial”.

El impacto del programa también se refleja en las experiencias de sus beneficiarios. Miguel Ángel Ortiz Puerta, estudiante de sexto semestre de Ingeniería de Sistemas, destaca que esta oportunidad ha sido decisiva en su trayectoria. “Para mí, ser beneficiario de Becas Talento es la oportunidad más importante de mi vida, porque me permite transformar mi realidad personal, familiar y económica. La beca te cambia la vida: abre oportunidades, te permite acceder a conocimiento y romper barreras sociales, además de motivarte a aportar a la sociedad y a inspirar a otros”, afirma.

Los resultados del proceso de selección se darán a conocer el 12 de junio, una vez el Comité de Becas evalúe las postulaciones con base en criterios académicos, familiares, económicos y personales. Con esta iniciativa, la Universidad ratifica su apuesta por abrir más caminos de acceso a la educación superior para jóvenes que quieren avanzar en su formación y aportar al desarrollo del país.

Imagen Noticia EAFIT

![Image 1: EAFIT tiene abierta su convocatoria de Becas Talento y Aliados para estudiar pregrado](https://universidadeafit.widen.net/content/c4e83701-40d6-4d6f-87d3-6e9de0e73b59/web/becastalento-18-marzo-26.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Dependencias

## [Los jóvenes deben cocrear la educación del presente y la del futuro, ¿cómo lograrlo?](https://www.eafit.edu.co/noticias/especiales/los-jovenes-deben-cocrear-la-educacion-del-presente-y-la-del-futuro-como)

Enero 23, 2026

**Este 24 de enero se celebra el Día Internacional de la Educación y la invitación de la Organización de las Naciones Unidas, a través de Unicef, es a celebrar el poder de la juventud en la educación del futuro.**

**A propósito de esta efeméride, expertos eafitenses, estudiantes y profesores profundizan sobre la importancia de convertir al estudiante en protagonista de su proceso y transformar las clases en laboratorios de cocreación.**

*   [Lee más sobre Los jóvenes deben cocrear la educación del presente y la del futuro, ¿cómo lograrlo?](https://www.eafit.edu.co/noticias/especiales/los-jovenes-deben-cocrear-la-educacion-del-presente-y-la-del-futuro-como "Los jóvenes deben cocrear la educación del presente y la del futuro, ¿cómo lograrlo?")

Tradicionalmente, una de las funciones principales de las universidades, en todo el mundo, es formar profesionales con las habilidades necesarias para responder a las demandas que requiere la industria. Pero ¿qué ocurre cuando el conocimiento que reciben está orientado a profesiones que, debido a los cambios constantes del entorno, tienen una vigencia de cerca de dos años y medio?

El foco, entonces, no puede estar centrado en habilidades técnicas específicas, sino en formar personas capaces de discernir, trabajar en equipo, cuestionar y adaptarse a entornos cambiantes. Y ese proceso empieza desde la clase, cuando los estudiantes se convierten en protagonistas y cocreadores en estos espacios de aprendizaje.

Así lo considera José Alejandro Betancur Álvarez, director del centro Imaginar Futuros de EAFIT, quien señala que la educación del futuro se debe cocrear con quienes la habitan. Se trata de una reflexión coherente con la conmemoración de este 24 de enero, Día Internacional de la Educación, en la que la Organización de las Naciones Unidas invita a reconocer a los jóvenes como agentes en el diseño en la educación.

El eafitense señala que hay tres tendencias clave para construir, de manera colectiva, los escenarios educativos del mañana. La primera tiene que ver con la personalización del aprendizaje, apoyada en el uso de la inteligencia artificial como complemento de la educación formal. Una segunda le debe apuntar al cierre de brechas educativas, especialmente mediante el uso de nuevas tecnologías. Y, finalmente, el tercer eje plantea la necesidad de diseñar experiencias de aprendizaje que fortalezcan el vínculo humano y el sentido de comunidad.

Para Paola Podestá Correa, vicerrectora de Aprendizaje de EAFIT, la idea de que los jóvenes sean cocreadores del aprendizaje tiene total sentido si se tiene en cuenta que, en la actualidad, se estima que poco más de la mitad de la población mundial tiene 30 años o menos. Son ellos, en palabras de la directiva, quienes se ven impactados por las decisiones actuales.

La Vicerrectora afirma que la fuerza de los jóvenes en la educación ha existido desde siempre, permitiendo que temas como la sostenibilidad, la crisis climática, la transformación de la democracia o las desigualdades sociales sean puestos en la agenda. Pero el rol de las universidades, ahora, debe estar enfocado en garantizar el acceso desde edades tempranas, y mediante acciones claras para permitir su participación en escenarios de toma decisiones.

“Para nosotros es fundamental la presencia de los jóvenes en los estamentos de representación estudiantil, pero también en todos los espacios de conversación disciplinar y en aquellos donde se discuten los grandes temas que hoy afectan a la humanidad”, explica.

###### El estudiante como protagonista y cocreador

Justamente, como representante del Comité de Pregrado de su carrera y coordinadora del semillero de investigación y Creación en Narrativas Periodísticas, Isabella Ruiz Alarcón, de sexto semestre de Comunicación Social de EAFIT, es un ejemplo de cómo poner al estudiante en el centro lo convierte en cocreador de la educación.

Isabella destaca que, en ese camino, estos espacios de participación y liderazgo han sido fundamentales. Allí, la cocreación juega un papel clave pues le permite enriquecer el aprendizaje a partir de múltiples miradas, experimentando, equivocándose, reflexionando o resolviendo retos y problemas reales.

Para José Alejandro Betancur, la experiencia de Isabella es la evidencia de un cambio en la forma de concebir el aprendizaje hoy, pasando de rutas predefinidas a trayectorias flexibles, en las que cada estudiante puede tomar decisiones sobre su proceso formativo y construir su propio camino con otras experiencias.

En este enfoque, más que seguir un listado de contenidos predeterminados, el aprendizaje se orienta por preguntas, descubrimientos y retos que surgen en el aula, y que hacen de la experiencia educativa un ejercicio vivo, experiencial y situado.

“Hoy, los estudiantes cuentan con múltiples fuentes de información y herramientas fuera del entorno académico que les permiten complementar, contrastar y ampliar contenidos. Esa experiencia externa se integra al espacio de clase y enriquece las conversaciones, que dejan de ser monólogos para convertirse en diálogos argumentados y colectivos”.

###### El reto de convertir las clases en laboratorios cocreadores

La cocreación también plantea un mayor nivel de exigencia para el docente, quien debe preparar la clase no solo desde los contenidos, sino desde la experiencia que se va a vivir. Eso es lo que hace Edwin Sepúlveda Cardona, del área de Marketing e Innovación de la Escuela de Administración, y quien ha convertido sus clases en un laboratorio cocreador. “Hoy la ecuación cambia: ya no somos solo profesores y estudiantes, sino aliados, socios, consultores y cocreadores”, explica.

Por eso en sus clases asume este rol y acompaña a los estudiantes en la construcción de proyectos reales. Este acompañamiento se concreta en experiencias como _showfests, shark tanks_, pasantías, laboratorios, procesos de investigación cualitativa con marcas reales, campañas sobre problemáticas actuales, licitaciones y concursos, en los que los estudiantes trabajan con retos reales del mercado. El aprendizaje se basa en desafíos, proyectos y servicios, conectados con los dolores reales de las organizaciones y las marcas.

“Pasamos de un ecosistema de excepción a uno de producción real. De esta manera realizamos campañas completas en un solo semestre bajo un modelo de células creativas que simulan el funcionamiento de una agencia. Cada equipo asume roles reales (dirección, arte, copy, planeación) y esto les permite fortalecer muchos otros aspectos más allá de los contenidos teóricos. Los mejores estudiantes avanzan luego a una agencia in house, donde trabajan con clientes reales. El impacto de este modelo se refleja no solo en la experiencia formativa, sino también en la generación de propiedad intelectual y activos intangibles.

Como este ejemplo, EAFIT ha desarrollado otras experiencias que preparan a los estudiantes para los desafíos del presente y del futuro, y que los convierten en protagonistas activos de su proceso formativo, tal como lo declara en su Modelo Educativo, que pone al estudiante en el centro.

Imagen Noticia EAFIT

![Image 2: En la imagen, el laboratorio makers, uno de los espacios de aprendizaje de EAFIT donde se pone en práctica la cocreación entre profesores y estudiantes.](https://universidadeafit.widen.net/content/d7852bcd-7891-440a-aa24-840891747477/web/Jovenes-cocrear-2026.jpg)

Leyenda de la imagen

En la imagen, el laboratorio Makers, uno de los espacios de aprendizaje de EAFIT donde se pone en práctica la cocreación entre profesores y estudiantes.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Dependencias

## [¡El mundo en EAFIT! Este 2026-1 recibimos a 101 nuevos estudiantes de intercambio](https://www.eafit.edu.co/noticias/nuestro-impacto/el-mundo-en-eafit-este-2026-1-recibimos-101-nuevos-estudiantes-de)

Enero 14, 2026

**65 estudiantes internacionales provenientes de Alemania, Francia, Dinamarca, Estados Unidos, México, Finlandia, Italia, Bolivia, Perú, Japón, entre otros, llegaron a EAFIT para cursar un semestre académico.**

**Además, llegaron 36 estudiantes colombianos, pertenecientes a 11 universidades de ciudades como Medellín, Cartagena, Barranquilla, Popayán, Cali y Santa Marta. Como parte del intercambio, 96 estudiantes eafitenses cursarán el semestre académico en diferentes universidades del mundo.**

*   [Lee más sobre ¡El mundo en EAFIT! Este 2026-1 recibimos a 101 nuevos estudiantes de intercambio](https://www.eafit.edu.co/noticias/nuestro-impacto/el-mundo-en-eafit-este-2026-1-recibimos-101-nuevos-estudiantes-de "¡El mundo en EAFIT! Este 2026-1 recibimos a 101 nuevos estudiantes de intercambio")

Podría decirse que la japonesa y la colombiana son especies de antípodas culturales pues no solo las separa un océano con sus millas, sino aspectos como la comida y el idioma. ¿Qué decir de las costumbres finlandesas en contraste con las bolivianas? ¿O la danesa con la estadounidense? Resulta que estas y otras nacionalidades confluyen en Medellín, al mismo tiempo, en el cuerpo de los 101 estudiantes provenientes de diferentes países y de algunas regiones de Colombia, que eligieron a EAFIT para realizar un semestre de intercambio académico.

Uno de esos jóvenes es Ryo Kato, estudiante de la universidad de estudios extranjeros, en Tokio, Japón, quien quiso viajar hasta Latinoamérica para entender mejor una realidad que llega a veces como un eco lejano a su país. La motivación de Liliana Hinestroza Flórez, proveniente de la ciudad de Santa Marta, Colombia y estudiante de Negocios Internacionales de la Universidad Sergio Arboleda, es la posibilidad de realizar conexiones y poner a prueba el idioma inglés.

Ryo hace parte de los 65 estudiantes internacionales, mientras que Liliana integra el listado de 36 estudiantes colombianos que eligieron a EAFIT para realizar un semestre académico. Ambos jóvenes llegaron a la Universidad gracias al Programa de movilidad nacional e internacional, en el que estudiantes de pregrado y posgrado de diferentes universidades del mundo vienen para realizar estancias académicas, pasantías o investigaciones.

Según lo explica Diana Nieto Ramírez, coordinadora de movilidad y convenios, “actualmente tenemos un repositorio de 310 convenios, 167 de los cuáles están orientados a movilidad estudiantil y opciones de doble titulación. Ahí es donde nace lo que hoy materializamos. Se trata de mantener ese relacionamiento vivo con las universidades extranjeras, lo que implica enviar correos, realizar _webinars_ e ir a visitarlos”.

Y fue precisamente en ferias organizadas por sus universidades de origen como Ryo y Liliana se enteraron de la posibilidad de viajar a Medellín, específicamente a la Universidad EAFIT. Aunque “podía elegir en universidades latinoamericanas ubicadas en México o Argentina, me interesa mucho más la cultura de países caribeños. Elegí Colombia porque en Japón mucha gente no sabe nada de Latinoamérica y es muy importante conocer las condiciones políticas de estos países que tienen muchos problemas que resolver por estos días”, explica Ryo. De acuerdo con sus intereses eligió cursar materias del pregrado de Comunicación Social como fotografía, diseño interactivo y periodismo.

Mientras que Ryo asumirá el reto de ver materias en español, como parte del propósito de perfeccionar este idioma, Liliana espera mejorar sus habilidades en inglés, lengua en la que verá algunas de las asignaturas elegidas por ella para este semestre académico: legislación, gerencia, analítica de negocio, proyectos y selección de mercados internacionales, son algunos de los contenidos que complementarán el plan de estudios de esta samaria en EAFIT.

Con respecto a los estudiantes de movilidad nacional Cristina Robledo Ardila, jefa de internacionalización, explica que “realmente eso hace parte de esa diversidad cultural que muchas veces se piensa que es inherente a lo internacional, pero realmente Colombia nos ofrece una riqueza inmensa. Entonces los estudiantes de movilidad nacional entran a ser parte de ese grupo que ayuda a transformar la comunidad eafitense y a exponer las diferentes culturas y formas de pensar”.

Imagen Noticia EAFIT

![Image 3: ¡El mundo en EAFIT! Este 2026-1 recibimos a 101 nuevos estudiantes de intercambio](https://universidadeafit.widen.net/content/88371648-636e-47a3-b42f-6e4799017f17/web/Bienvenida-foraneos2.jpg)

Leyenda de la imagen

Los intercambios de estudiantes internacionales en EAFIT comenzaron en el año 1997.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Dependencias

## [¡Jornada de excelencia! 69 becas para estudiar en EAFIT fueron entregadas en un solo día](https://www.eafit.edu.co/noticias/nuestro-impacto/jornada-de-excelencia-69-becas-para-estudiar-en-eafit-fueron-entregadas-en)

Diciembre 10, 2025

**Este 9 de diciembre fue una jornada dedicada al talento y a la excelencia, gracias a las 69 becas que se entregaron y que permitirán que jóvenes de diferentes sectores de Medellín, y de diferentes regiones del país, puedan cursar sus estudios de pregrado en la Institución.**

**La ANDI otorgó 10 becas; Nutresa entregó 21 de acceso y 5 de liderazgo; Grupo Argos aportó 7 becas; y otros 26 apoyos educativos fueron posibles gracias a la alianza con otra fundación. Estos programas refuerzan el compromiso con la movilidad y la transformación social a través de la educación.**

*   [Lee más sobre ¡Jornada de excelencia! 69 becas para estudiar en EAFIT fueron entregadas en un solo día](https://www.eafit.edu.co/noticias/nuestro-impacto/jornada-de-excelencia-69-becas-para-estudiar-en-eafit-fueron-entregadas-en "¡Jornada de excelencia! 69 becas para estudiar en EAFIT fueron entregadas en un solo día")

Una jornada dedicada a la excelencia y el talento, y también a la emotividad, la gratitud y el orgullo. Eso fue lo que se vivió este 9 de diciembre cuando EAFIT, en alianza con la ANDI, Grupo Nutresa, Grupo Argos y la alianza con otra fundación, entregó 69 becas para que bachilleres de diferentes territorios del país puedan cursar sus estudios de pregrado en la Universidad, desde 2026.

“EAFIT se creó gracias al esfuerzo de un grupo de empresarios que tenían una visión para esta región y para el país. Su acta de fundación se firmó en las oficinas de la ANDI, por lo que estar hoy, 65 años después, entregando estas becas con este gremio empresarial, y también en alianza con otras organizaciones es ratificar ese vínculo y ese compromiso que tenemos con nuestro ADN”, expresó Claudia Restrepo Montoya, rectora de EAFIT, durante la primera de las tres ceremonias de entrega que se realizaron a lo largo del día.

Durante toda la jornada los aspirantes, acompañados de sus familias, llegaron desde diferentes barrios de Medellín, así como desde otros lugares como Cartagena, Armenia, Tolú, Manizales, Fredonia, San José de la Montaña, Bello e Itagüí, entre otros territorios, para contar un poco de sus vidas y exponer las razones por las que se sentían merecedores del reconocimiento. Al final de cada acto todos se fueron con una carpeta bajo el brazo confirmando que habían obtenido la beca, y una buena noticia para celebrar en esta Navidad.

“Escuchar sus historias llenas de liderazgo, y sus ganas de transformar sus proyectos de vida, sus familias y sus comunidades, es una confirmación de que ustedes no están acá porque sí, sino por su excelencia y su talento, que son las cualidades que los hacen merecedores de este reconocimiento. En EAFIT queremos esa excelencia y ese talento para seguir inspirando vidas, creando conocimiento y transformando sociedad”, enfatizó la Rectora.

En la actualidad, cerca del 27 % de los estudiantes de EAFIT cuenta con algún tipo de beca o apoyo. Y el sueño es que, en los próximos años, esa cifra aumente a un 50 % gracias a las gestiones que la Universidad adelanta, a través de la Dirección de Desarrollo Institucional y Vínculos, con otras empresas, fundaciones, con el sector público y con donantes particulares.

Así mismo este año, el 27 de noviembre, se entregaron las becas Programa Nivelatorio con Aportes de Empleados y Volemos Juntos, las de las alianzas con Fundación Renault, Corporación Amigos de EAFIT y Fundación Educación; y las becas Perpetua de Jorge Iván Rodríguez, uno de los fundadores de la Universidad; Eskole, de la rectora Claudia Restrepo Montoya; y Álvaro Uribe Moreno, en nombre del expresidente del Consejo Superior. Los 15 beneficiarios se suman a los 277 que ya han obtenido este logro en los más de 20 años de esta iniciativa.

###### 10 bachilleres se formarán en la U gracias a las Becas ANDI

Luego de un proceso de selección, 10 aspirantes obtuvieron este reconocimiento que cubrirá el 100 por ciento de su proceso de formación en la Universidad. Entre ellos está, por ejemplo, Salomé Palacio, quien quiere explotar su creatividad en el pregrado en Ingeniería de Sistemas; o Eva Medrano, quien se destacó por su liderazgo como personera en su colegio y quiere continuar fortaleciendo este valor en Administración de Negocios.

Así mismo, Emanuel Salazar quiere trabajar por la protección de los animales y el medioambiente, y cree que el programa de Biología le puede brindar las herramientas necesarias para hacerlo y, junto a él, Juan Pablo Vega se decantó por la Ingeniería Matemática después de ganar varias olimpiadas nacionales durante su etapa escolar.

“Desde hace varios años encontramos, en EAFIT, un propósito mediante estas becas. Las empresas estamos llamadas a ayudar a crecer a la sociedad, pero no podemos hacerlo sino tenemos en cuenta una variable muy importante que es la educación. Por eso creemos en esta beca, porque sabemos que cuando ustedes se gradúen, van a transformar sus comunidades”, expresó, durante el acto, María Paula Platero, coordinadora del Fondo Social ANDI.

###### Nutresa y EAFIT entregaron 21 becas de acceso y cinco de liderazgo

“De 10 jóvenes que terminan el bachillerato, solo cuatro acceden a la educación superior. Los otros seis no pueden hacerlo porque no cuentan con los recursos. Esta beca quiere transformar eso y brindar oportunidades para jóvenes que tienen todas las capacidades”, expresó la rectora Claudia Restrepo, durante su saludo.

A estas palabras se sumó -Jairo González, vicepresidente secretario general y director de la Fundación Nutresa, quien señaló que lo que busca este tipo de apoyos es exaltar la excelencia. “Tiene mucho sentido para nosotros, como empresa, que tengamos nuestro foco en la salud, la nutrición y, por supuesto, en la educación superior. Está comprobado que cuando se invierte en educación, se beneficia la sociedad entera y por eso entregamos estas becas con la convicción de que detrás de cada beneficiario habrá un efecto multiplicador”.

Y así lo demostraron los aspirantes. Como es el caso de Ana Sofía Álvarez, quien desde el Mercadeo quiere ayudar a transformar la imagen de su barrio en Bello; Miguel Ángel Cano, quien espera trabajar por el futuro alimenticio del país desde Ingeniería Agronómica; o Ana Sofía Puerta, quien escogió el Derecho para continuar con su labor como lideresa social de su comunidad.

###### Generación A entregó 21 becas entre EAFIT, CES y EIA

A de Argos, de Antioquia y, sobre todo de Aprendizaje. Esa es la letra que guía este programa -Generación A-, liderado por el Grupo Argos y que, este año otorgó 21 becas para que estudiantes de diferentes municipios de Antioquia puedan cursar sus estudios en EAFIT, CES o EIA.

Siete de los seleccionados lo harán, justamente, en EAFIT, y lo supieron durante un almuerzo que tuvo lugar en las instalaciones de Argos, este 9 de diciembre.

“Soy un convencido de que la construcción de la sociedad depende de la inversión que las empresas hagamos en educación. Entre más jóvenes se puedan educar, más vamos a transformar este país y el mundo”, señaló Jorge Mario Velásquez, presidente del Grupo Argos, durante el acto de entrega.

Junto a los aspirantes y sus familias, también estuvo presente la rectora Claudia Restrepo, quien destacó que, entre los beneficiarios, hay estudiantes de San Luis, Apartadó y Turbo, evidenciando el verdadero alcance de región que tiene este programa. “En EAFIT nos sentimos orgullosos de quedarnos con el mejor talento del departamento”, puntualizó.

Imagen Noticia EAFIT

![Image 4: En la imagen los beneficiarios de las becas Nutresa, la última ceremonia del día.](https://universidadeafit.widen.net/content/3366cbdb-33ee-4ae0-b306-5a6b823a8615/web/69becas-Nutresa.jpg)

Leyenda de la imagen

En la imagen los beneficiarios de las becas Nutresa, la última ceremonia del día.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

Dependencias

## [¡Ciencia en tiempo récord! la investigación y la educación se transforman con los supercomputadores](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/ciencia-en-tiempo-record-la-investigacion-y-la-educacion-se)

Noviembre 7, 2025

**Los supercomputadores han cambiado la escala del conocimiento. Procesos que antes requerían décadas ahora se completan en días o incluso horas, lo que permite a investigadores de distintas áreas generar hallazgos que antes eran impensables sin estas infraestructuras.**

**Expertos coinciden en que, más allá de la máquina, el reto está en la formación y el uso responsable. La supercomputación plantea desafíos éticos, energéticos y humanos, como la necesidad de formar nuevas generaciones de científicos, disminuir el consumo de recursos y garantizar un manejo adecuado de los datos.**

*   [Lee más sobre ¡Ciencia en tiempo récord! la investigación y la educación se transforman con los supercomputadores](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/ciencia-en-tiempo-record-la-investigacion-y-la-educacion-se "¡Ciencia en tiempo récord! la investigación y la educación se transforman con los supercomputadores")

En el pasado, un análisis genético podía tardar décadas; hoy, un sistema de procesadores y memorias interconectadas puede resolverlo en cuestión de días. Los supercomputadores se han convertido en herramientas clave para el desarrollo científico y tecnológico. Su capacidad de procesamiento permite analizar volúmenes masivos de datos y abordar problemas que, simplemente, no podrían resolverse sin este tipo de infraestructuras. Sin embargo, esta aceleración del conocimiento también plantea preguntas profundas sobre los límites, los riesgos y las implicaciones de depender cada vez más del cálculo automatizado.

El profesor Edison Valencia Díaz, coordinador científico del Centro de Computación Científica Apolo de EAFIT, explica: “Históricamente, la ciencia tenía dos pilares: la teoría (las ideas) y la experimentación (el laboratorio). Los supercomputadores nos han dado un tercer pilar: la simulación. Ahora, podemos crear laboratorios virtuales. Un científico puede simular la colisión de dos galaxias, probar miles de compuestos para un nuevo fármaco o modelar cómo se propaga una pandemia, todo sin salir de su escritorio”.

Desde la predicción del clima y el estudio del cambio climático hasta la simulación de nuevos materiales, el diseño de medicamentos, la exploración energética y el entrenamiento de modelos de inteligencia artificial, las aplicaciones de la supercomputación son cada vez más amplias. Según Esteban de Jesús Hernández Barragán, director ejecutivo de SCALAC y encargado de la cooperación científica en CyberColombia, “los supercomputadores son el laboratorio digital donde la ciencia moderna experimenta, valida hipótesis y anticipa escenarios”.

###### Los dilemas de la supercomputación

El debate sobre estas infraestructuras va más allá de la fascinación por su potencia. Aprender a utilizarlas de manera crítica, responsable y sostenible es uno de los grandes retos de la supercomputación. “El desafío no es solo tener la máquina, sino crear la comunidad de científicos, ingenieros y analistas que sepan hablar el idioma del paralelismo para exprimir todo su potencial. Debemos cerrar la brecha entre el poder de la máquina y las personas que pueden usarla para generar impacto”, afirma el profesor Edison.

La expansión de estos sistemas plantea, además, un desafío ambiental. De acuerdo con los expertos, los supercomputadores demandan altos consumos energéticos y sistemas de enfriamiento especializados. En un contexto global de emergencia climática, la sostenibilidad de estas infraestructuras se convierte en una prioridad. Por ello, desde distintos sectores se impulsan propuestas de innovación en computación verde (green computing) orientadas a aumentar la eficiencia de los sistemas.

En el plano ético, Esteban advierte sobre la importancia del acceso equitativo y el uso con propósito. “La ciencia abierta y la cooperación internacional son esenciales para que estos recursos no amplíen brechas, sino que impulsen el desarrollo equitativo. De alguna manera, cuando se analiza la relación entre supercomputación y desarrollo, se puede determinar que existe un vínculo muy estrecho”, señala.

Si bien las universidades que cuentan con supercomputadores avanzan más rápido en investigación, las brechas entre instituciones con y sin esta tecnología pueden ampliarse. Por eso, es necesario promover redes colaborativas y proyectos conjuntos que garanticen que la capacidad de cómputo esté al servicio del conocimiento colectivo y no de unos pocos grupos.

En este sentido, EAFIT ha consolidado una de las infraestructuras más avanzadas del país. Con la reciente incorporación de la versión 3 de la supercomputadora Apolo, el Centro de Computación Científica amplió su potencia, incrementó su capacidad de procesamiento y mejoró su eficiencia energética. Esta actualización busca atender a un número creciente de usuarios y fortalecer proyectos en áreas como la inteligencia artificial, las predicciones climáticas y el análisis de datos complejos.

El profesor Javier Correa, de la Escuela Ciencias Aplicadas e Ingeniería de EAFIT, ha sido usuario de Apolo desde sus inicios con un proyecto de investigación sobre el genoma del insecto _Tecia solanivora_, del cual recuerda: “La sorpresa fue que para esa época calculamos que, de no haber utilizado Apolo, nos hubiéramos demorado alrededor de 100 años haciendo ese análisis”. Esa experiencia marcó un punto importante para la investigación en biología molecular: procesos de secuenciación genética y análisis filogenético que antes eran inviables se volvieron posibles gracias a la capacidad de cómputo.

Finalmente, persiste el reto del uso responsable de los datos en la supercomputación. A medida que se procesan volúmenes crecientes de información personal o sensible, es indispensable garantizar la trazabilidad, la privacidad y la transparencia en los resultados. Estos riesgos, particularmente en el ámbito comercial, son hoy una preocupación constante en el debate sobre la ética del dato y el futuro de la ciencia abierta.

Imagen Noticia EAFIT

![Image 5: EAFIT cuenta con Apolo 3, su propio supercomputador, una infraestructura que impulsa proyectos de investigación en diferentes áreas del conocimiento.](https://universidadeafit.widen.net/content/22a90c28-29ce-43fb-af56-8de5617c4725/web/Apolo-nov7.jpg)

Leyenda de la imagen

EAFIT cuenta con Apolo 3, su propio supercomputador, una infraestructura que impulsa proyectos de investigación en diferentes áreas del conocimiento.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [EAFIT presentó su séptimo doctorado: el de Derecho](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-presento-su-septimo-doctorado-el-de-derecho)

Octubre 23, 2025

**A los doctorados en Administración, Ingeniería, Ingeniería Matemática, Ciencias de la Tierra, Artes y Humanidades, y Economía, se sumó un nuevo desde este 20 de octubre: el de Derecho, que llega para enriquecer la oferta de posgrados de la Universidad, articulando el saber jurídico y la investigación crítica e interdisciplinaria.**

**El lanzamiento se realizó con una conversación en la que los jefes de los doctorados en derecho de las universidades Austral de Chile y Universidad de Antioquia, Gabriel Ignacio Gómez y Leticia Morales, respectivamente, hablaron sobre la realidad actual y los retos de la investigación jurídica en Latinoamérica.**

*   [Lee más sobre EAFIT presentó su séptimo doctorado: el de Derecho](https://www.eafit.edu.co/noticias/lo-que-esta-pasando/eafit-presento-su-septimo-doctorado-el-de-derecho "EAFIT presentó su séptimo doctorado: el de Derecho")

La imagen corresponde al lanzamiento del doctorado en Derecho, que se realizó en el Centro de Artes de EAFIT. Para conocer más sobre este programa se puede consultar este [**enlace**](https://www.eafit.edu.co/posgrados/escuela-derecho/doctorado-en-derecho).

Pensar el derecho hoy en América Latina exige mirarlo desde una nueva perspectiva: la del territorio, la interdisciplinariedad y el diálogo entre saberes. En eso coincidieron Gabriel Ignacio Gómez, jefe del doctorado en Derecho de la Universidad de Antioquia, y Leticia Morales, directora del doctorado en Derecho de la Universidad Austral de Chile, durante la conferencia _Perspectivas de la Investigación Jurídica en América Latina_, que se realizó el 20 de octubre, en el centro de Artes de EAFIT.

La conversación se realizó a propósito del lanzamiento del doctorado en Derecho de EAFIT y, en este espacio, ambos académicos coincidieron en que el derecho latinoamericano debe nutrirse de múltiples enfoques, como las ciencias sociales y la economía hasta los estudios de género, el arte o la administración, para responder a los desafíos actuales en materia de justicia, equidad y derechos humanos, una mirada con que, justamente, ofrece el nuevo programa eafitense.

“Las condiciones están dadas para establecer relaciones con otros saberes y miradas que nos permitan ver el mundo del derecho de manera diferente”, señaló Gabriel Ignacio Gómez, al insistir en que la producción jurídica debe ser un ejercicio colectivo, interdisciplinario y comprometido con la transformación social.

Leticia Morales, por su parte, subrayó que la región cuenta hoy con programas de doctorado consolidados que apuestan por una formación de excelencia sin necesidad de mirar únicamente al norte global. “Formarse en el país, en su ciudad y con un enfoque de región es posible, y cada vez más doctorandos latinoamericanos están construyendo conocimiento desde aquí, en diálogo con las problemáticas locales y regionales”, sostuvo la académica, quien además destacó el hecho de que cada vez hay más claustros de derecho soportados por profesores con una alta capacidad interdisciplinar.

Durante el lanzamiento, el decano de la Escuela de Derecho de EAFIT, Esteban Hoyos Ceballos, explicó que este posgrado representa un punto de partida para fortalecer las capacidades de investigación, la calidad académica y la internacionalización de la Escuela. “Nos permitirá potenciar lo que ya hacemos bien: la formación rigurosa de nuestros estudiantes, la articulación con semilleros y clínicas jurídicas, y la creación de espacios donde el conocimiento se construya desde el diálogo”, afirmó.

En ese mismo sentido, Nathaly Montoya Restrepo, jefa del doctorado, agregó que el programa nace como un espacio de convergencia entre distintas áreas del conocimiento y entre diversas perspectivas del derecho. “Y qué mejor manera de lanzarlo que con la participación de tres jefes de doctorados en derecho, como un mensaje de que el diálogo, la construcción colectiva y la apertura de saberes son el camino para fortalecer el pensamiento jurídico latinoamericano”, señaló.

La presentación cerró con una invitación, por parte del decano y de Nataly, a consolidar una comunidad académica regional que piense el derecho desde el contexto de América Latina. Un propósito que implica reconocer las realidades del territorio, incluir a todos los actores sociales y construir conocimiento jurídico que dialogue con las necesidades, retos y transformaciones de la región.

###### Sobre el doctorado

El nuevo doctorado en Derecho de EAFIT articula el saber jurídico con la investigación crítica e interdisciplinaria. Este programa, de ocho semestres en modalidad de tiempo completo, busca formar investigadores capaces de generar nuevo conocimiento y de proponer soluciones innovadoras a los retos jurídicos y sociales del país.

El enfoque plural e interdisciplinario, junto con una flexibilidad curricular que permite conectar distintas áreas del conocimiento, lo convierten en un espacio idóneo para los profesionales que deseen profundizar en los fundamentos del derecho desde perspectivas críticas, contemporáneas y diversas.

Además, se integra con grupos, líneas y proyectos de investigación consolidados, y cuenta con una planta profesoral diversa y con una red de vínculos efectivos con los sectores público, privado, académico y comunitario. Todo ello refuerza su propósito de contribuir a la formación jurídica avanzada y a la consolidación de comunidades académicas comprometidas con el desarrollo del país.

Para ingresar, se requiere título de maestría en derecho o en ciencias sociales y humanas afines, o una experiencia investigativa equivalente y acreditada. Los aspirantes también deben presentar una entrevista, una carta de motivación en la que expongan sus intereses investigativos, una recomendación académica, y demostrar competencia lectora en inglés o en otro idioma pertinente a la disciplina o enfoque de estudio.

Imagen Noticia EAFIT

![Image 6: La imagen corresponde al lanzamiento del doctorado en Derecho, que se realizó en el Centro de Artes de EAFIT.](https://universidadeafit.widen.net/content/1576d3e7-dd36-43c9-93c3-ac63b5f41980/web/Lanzamiento-doc-Derecho.jpeg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [Nueva convocatoria de Fondo Futuro para facilitar el acceso y la permanencia en la educación superior](https://www.eafit.edu.co/noticias/nuestro-impacto/nueva-convocatoria-de-fondo-futuro-para-facilitar-el-acceso-y-la)

Octubre 22, 2025

**Los interesados en estudiar un pregrado ya pueden postularse a la convocatoria 2026-1 del Fondo Futuro, una alternativa de crédito educativo flexible sin intereses durante el tiempo de estudio. Los aspirantes pueden inscribirse**[**aquí**](https://fondofuturo.co/home)**, adjuntar los documentos requeridos y recibir acompañamiento durante el proceso.**

**El Fondo es una solución al desafío nacional de ampliar el acceso a la educación superior y fue creado por la Universidad EAFIT, la Universidad Pontificia Bolivariana, la Universidad EIA, la Universidad de Medellín y la Universidad CES. Esta es su segunda convocatoria; en la primera se beneficiaron cerca de 100 estudiantes.**

*   [Lee más sobre Nueva convocatoria de Fondo Futuro para facilitar el acceso y la permanencia en la educación superior](https://www.eafit.edu.co/noticias/nuestro-impacto/nueva-convocatoria-de-fondo-futuro-para-facilitar-el-acceso-y-la "Nueva convocatoria de Fondo Futuro para facilitar el acceso y la permanencia en la educación superior")

Fondo Futuro abrió su nueva convocatoria para jóvenes interesados en cursar un pregrado en la universidad y que requieran una alternativa de financiación flexible. Se trata de un modelo en el que se paga el 30 % del valor de la matrícula durante el semestre y el 70 % restante se difiere hasta después de la graduación, sin intereses durante el tiempo de estudio y con un plazo de hasta 1.5 veces la duración del programa.

La plataforma de inscripción ya está disponible en este [**enlace**](https://fondofuturo.co/home) y permite diligenciar el formulario, adjuntar los documentos y recibir acompañamiento durante el proceso a través de Credyty. Para postularse, se debe ingresar el documento de identidad y la orden de matrícula, y completar un formato virtual que requiere menos de 10 minutos.

El Fondo —conformado por una alianza entre la Universidad EAFIT, la Universidad Pontificia Bolivariana (UPB), la Universidad EIA, la Universidad de Medellín y la Universidad CES— presenta como novedad en esta segunda convocatoria la posibilidad de que estudiantes que ya cursan un pregrado en alguna de las cinco universidades aliadas también puedan postularse.

Para José Manuel Restrepo Abondano, rector de la Universidad EIA, la nueva convocatoria demuestra que el Fondo Futuro sigue cumpliendo con su propósito esencial de derribar las barreras económicas que limitan el acceso al conocimiento. En sus palabras, “el Fondo está hecho para estudiantes con alto potencial académico que merecen estar en la universidad, pero no cuentan con los recursos suficientes”.

Claudia Restrepo Montoya, rectora de EAFIT, destaca que la creación del Fondo Futuro responde al compromiso de las universidades con el acceso y la equidad educativa. Según la Rectora, el país está en un momento decisivo para garantizar la formación de su talento joven y fortalecer su competitividad. “Colombia vive una ventana de oportunidad única: tenemos una generación de jóvenes con talento que necesita formarse. Si no les abrimos caminos, perdemos también competitividad como país. Por eso, desde estas instituciones estamos creando mecanismos como Fondo Futuro, que no solo facilita el acceso, sino que también promueve la permanencia, y está acorde con la necesidad de una política nacional que priorice la educación superior como motor de desarrollo”, afirma.

Y es que además del acceso, la iniciativa busca acompañar la permanencia y brindar tranquilidad a las familias. Así lo considera Claudia Helena Arenas Pajón, rectora de la Universidad CES: “Sabemos que muchos sueños se enfrentan a barreras económicas, y por eso seguimos creyendo en este modelo solidario y sostenible, que abre caminos de acceso y permanencia en la educación superior”. En su opinión, el Fondo reafirma la capacidad de las universidades de actuar unidas por un mismo propósito.

###### Una oportunidad para impulsar proyectos de vida

El padre Diego Alonso Marulanda Díaz, rector de la Universidad Pontificia Bolivariana, complementa esta visión al señalar que el Fondo no solo financia matrículas, sino que impulsa proyectos de vida. “Es una oportunidad para que los jóvenes entiendan que, de la mano del Fondo Futuro, pueden desarrollar todo su potencial y contribuir al desarrollo del país”, afirma. En sus palabras se refleja la convicción de que la educación sigue siendo el camino más poderoso para transformar realidades.

Ese impacto del que habla el rector de UPB ya se evidencia en los resultados de la primera edición del programa, en la que se recibieron 653 solicitudes, de las cuales 273 se completaron y 97 fueron aprobadas. El 79 % de los beneficiarios pertenece a los estratos 1, 2, 3 y 4, y más de la mitad reside en Medellín. Los pregrados con mayor número de postulaciones fueron Derecho, Negocios Internacionales, Medicina, Mercadeo y varias ingenierías, reflejando la diversidad de intereses y vocaciones de los jóvenes que buscan construir su futuro desde la educación.

El sentido de transformación también lo destaca Néstor Raúl Posada Arboleda, rector de la Universidad de Medellín, quien considera que el Fondo Futuro “ha cambiado la vida de decenas de jóvenes que sueñan con una educación de calidad, pero enfrentaban barreras económicas”. Para el directivo, la alianza entre universidades permite que los estudiantes se concentren en su formación, respaldados por un sistema de apoyo que combina rigor académico y compromiso social.

De esta manera, Fondo Futuro por la Educación quiere seguir consolidándose como una acción conjunta por el talento, la equidad y el desarrollo del país. En su segunda edición, reafirma que cuando las universidades se unen por el bien común, las oportunidades se convierten en realidades que transforman vidas.

**María Clara Zuluaga**

**Estudiante de primer semestre**

**Negocios Internacionales**

> Estudiar es una de las cosas que más me apasiona y el Fondo Futuro me pareció la mejor alternativa por ser mucho más rentable. Además, es directamente con la Universidad y tiene más beneficios. Realmente fue muy fácil todo. Es una muy buena alternativa para financiar a largo plazo, la mejor posibilidad que tenemos para poder seguir estudiando y alcanzar los estudios superiores.

**David Castaño**

**Estudiante de primer semestre**

**Mercadeo**

> Decidí estudiar en EAFIT porque quería una universidad de altos estándares, pero tenía inconvenientes con el pago de la matrícula. Afortunadamente encontré el Fondo Futuro y pude iniciar mi proceso de aprendizaje en la universidad, a los plazos que yo quería. De no ser por el Fondo Futuro, tal vez habría me habría atrasado un semestre. Además, el proceso fue muy ágil, en una semana ya tenía respuesta y eso me favoreció demasiado para iniciar el proceso.

Imagen Noticia EAFIT

![Image 7: Cada crédito de Fondo Futuro por la Educación cuenta con administración fiduciaria y subcuentas individuales para garantizar la transparencia de los recursos.](https://universidadeafit.widen.net/content/be729139-a8e9-41a4-93f6-3a0d036d7642/web/campus-gral-estudiantes.jpg)

Leyenda de la imagen

Cada crédito de Fondo Futuro por la Educación cuenta con administración fiduciaria y subcuentas individuales para garantizar la transparencia de los recursos.

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [Nueva convocatoria de las Becas Talento Público para fortalecer la gestión en el Estado](https://www.eafit.edu.co/noticias/nuestro-impacto/nueva-convocatoria-de-las-becas-talento-publico-para-fortalecer-la-gestion)

Octubre 9, 2025

**EAFIT abrió la segunda convocatoria de las Becas Talento Público, un programa que busca fortalecer las capacidades de los servidores y contratistas del Estado a través de estudios de posgrado.**

**Las postulaciones estarán abiertas hasta el 15 de noviembre de 2025, y los interesados podrán aplicar a una beca del 30 % en programas de especialización y maestría de las cinco escuelas de la Universidad.**

*   [Lee más sobre Nueva convocatoria de las Becas Talento Público para fortalecer la gestión en el Estado](https://www.eafit.edu.co/noticias/nuestro-impacto/nueva-convocatoria-de-las-becas-talento-publico-para-fortalecer-la-gestion "Nueva convocatoria de las Becas Talento Público para fortalecer la gestión en el Estado")

Los interesados pueden consultar los requisitos, programas elegibles y formulario de postulación en el [**sitio web de la beca**](https://www.eafit.edu.co/becas-y-financiaci%c3%b3n/becas-talento-funcionarios-publicos).

En el marco de la celebración de sus 65 años, EAFIT abrió la segunda convocatoria de las Becas Talento Público, una iniciativa que reconoce la vocación de servicio de quienes trabajan por el bienestar colectivo desde las instituciones públicas del país. En esta nueva edición, los funcionarios y contratistas del Estado podrán postularse a una beca del 30 % para cursar programas de posgrado en áreas como gobierno, economía, gerencia, estudios urbanos y ambientales, innovación social del conocimiento, entre otros.

Esta convocatoria, que estará abierta hasta el 15 de noviembre, da continuidad a una primera edición que permitió que más de 70 servidores públicos de distintas regiones del país iniciaran su formación en EAFIT, reafirmando el compromiso de la Universidad con el fortalecimiento del Estado y con la formación técnica y basada en la evidencia de quienes lideran procesos de transformación pública.

“En EAFIT cerramos con éxito la primera convocatoria de las Becas Talento Público, enfocadas en servidores y funcionarios que hoy trabajan en entidades del Estado. Cuando las creamos, nos imaginamos cómo entregar un beneficio a todas esas personas que han dedicado su vida al servicio del país, con vocación y sentido de propósito, aportando a la construcción de instituciones más sólidas y cercanas a los ciudadanos”, explica Isabel Gutiérrez Ramírez, directora de Estrategia de la Universidad.

Durante la primera edición, se recibieron postulaciones de más de veinticinco municipios del país y ahora se acompaña la formación de alcaldes, secretarios de despacho, directores de oficinas y otros servidores comprometidos con la transformación de sus territorios.

“Escuchamos historias maravillosas en sectores como educación, vivienda, niñez y juventud. Ver ese entusiasmo y compromiso nos llenó de satisfacción y nos motivó a continuar. Por eso, volvemos a abrir esta convocatoria, esperando a todos los funcionarios y contratistas del Estado que quieran seguir aprendiendo, fortalecer sus capacidades y poner ese conocimiento al servicio del bienestar colectivo”, agrega Isabel.

Uno de los beneficiarios de la primera cohorte es José Esteban Bello Pedraza, abogado de la Secretaría de Minas y Medio Ambiente de Remedios y asesor de la Secretaría de Minas y Desarrollo Económico de Segovia, quien cursa la Maestría en Gobierno y Políticas Públicas.

“La Beca Talento Público nos ha abierto puertas a muchos. En mi maestría somos veintinueve personas y la mayoría contamos con beca. Este programa nos ha reunido a líderes de diferentes municipios y profesiones —abogados, economistas, gestores culturales, periodistas, científicos— que encontramos aquí un espacio para pensarnos desde otro lugar, entendernos, inspirarnos y crear algo nuevo para nuestras regiones. Nos sentimos agradecidos por la acogida y el acompañamiento de la Universidad; ha sido una experiencia transformadora”, comenta José Esteban.

Por su parte, Lucía Jaramillo, líder de Alianzas y Ecosistemas de la Dirección de Estrategia, explica que esta iniciativa nació en el marco de los 65 años de la Universidad y en línea con la agenda del Ecosistema de Asuntos Públicos y Sociales, como un compromiso de EAFIT con la construcción de un Estado fortalecido y con líderes públicos formados en evidencia y gestión. “Con base en la experiencia de la primera edición decidimos abrir nuevamente la convocatoria, esta vez con un beneficio del 30 % que incluye a funcionarios y contratistas del Estado”, detalla.

La selección de los beneficiarios incluye un proceso de inscripción, entrevista con los jefes de programa y verificación de la vinculación actual con el sector público.

Con este esfuerzo, la Universidad reafirma su compromiso con el fortalecimiento del sector público, la formación de líderes para el país y el propósito de seguir conectando la educación superior con los desafíos del desarrollo institucional y territorial.

Imagen Noticia EAFIT

![Image 8: Nueva convocatoria de las Becas Talento Público para fortalecer la gestión en el Estado](https://universidadeafit.widen.net/content/ca833c01-c823-4fb4-bb4d-4060bea33147/web/Bloque%20_26_Ceiba.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [EAFIT abrió la segunda convocatoria de las Becas Talento Público, un programa que busca fortalecer las capacidades de los servidores y contratistas del Estado a través de estudios de posgrado.](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-abrio-la-segunda-convocatoria-de-las-becas-talento-publico-un)

**EAFIT abrió la segunda convocatoria de las Becas Talento Público, un programa que busca fortalecer las capacidades de los servidores y contratistas del Estado a través de estudios de posgrado.**

**Las postulaciones estarán abiertas hasta el 15 de noviembre de 2025, y los interesados podrán aplicar a una beca del 30 % en programas de especialización y maestría de las cinco escuelas de la Universidad.**

*   [Lee más sobre EAFIT abrió la segunda convocatoria de las Becas Talento Público, un programa que busca fortalecer las capacidades de los servidores y contratistas del Estado a través de estudios de posgrado.](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-abrio-la-segunda-convocatoria-de-las-becas-talento-publico-un "EAFIT abrió la segunda convocatoria de las Becas Talento Público, un programa que busca fortalecer las capacidades de los servidores y contratistas del Estado a través de estudios de posgrado.")

Los interesados pueden consultar los requisitos, programas elegibles y formulario de postulación en el [**sitio web de la beca**](https://www.eafit.edu.co/becas-y-financiaci%C3%B3n/becas-talento-funcionarios-publicos).

En el marco de la celebración de sus 65 años, EAFIT abrió la segunda convocatoria de las Becas Talento Público, una iniciativa que reconoce la vocación de servicio de quienes trabajan por el bienestar colectivo desde las instituciones públicas del país. En esta nueva edición, los funcionarios y contratistas del Estado podrán postularse a una beca del 30 % para cursar programas de posgrado en áreas como gobierno, economía, gerencia, estudios urbanos y ambientales, innovación social del conocimiento, entre otros.

Esta convocatoria, que estará abierta hasta el 15 de noviembre, da continuidad a una primera edición que permitió que más de 70 servidores públicos de distintas regiones del país iniciaran su formación en EAFIT, reafirmando el compromiso de la Universidad con el fortalecimiento del Estado y con la formación técnica y basada en evidencia de quienes lideran procesos de transformación pública.

“En EAFIT cerramos con éxito la primera convocatoria de las Becas Talento Público, enfocadas en servidores y funcionarios que hoy trabajan en entidades del Estado. Cuando las creamos, nos imaginamos cómo entregar un beneficio a todas esas personas que han dedicado su vida al servicio del país, con vocación y sentido de propósito, aportando a la construcción de instituciones más sólidas y cercanas a los ciudadanos”, explica Isabel Gutiérrez Ramírez, directora de Estrategia de la Universidad.

Durante la primera edición, se recibieron postulaciones de más de veinticinco municipios del país y ahora se acompaña la formación de alcaldes, secretarios de despacho, directores de oficinas y otros servidores comprometidos con la transformación de sus territorios.

“Escuchamos historias maravillosas en sectores como educación, vivienda, niñez y juventud. Ver ese entusiasmo y compromiso nos llenó de satisfacción y nos motivó a continuar. Por eso, volvemos a abrir esta convocatoria, esperando a todos los funcionarios y contratistas del Estado que quieran seguir aprendiendo, fortalecer sus capacidades y poner ese conocimiento al servicio del bienestar colectivo”, agrega Isabel.

Uno de los beneficiarios de la primera cohorte es José Esteban Bello Pedraza, abogado de la Secretaría de Minas y Medio Ambiente de Remedios y asesor de la Secretaría de Minas y Desarrollo Económico de Segovia, quien cursa la Maestría en Gobierno y Políticas Públicas.

“La Beca Talento Público nos ha abierto puertas a muchos. En mi maestría somos veintinueve personas y la mayoría contamos con beca. Este programa nos ha reunido a líderes de diferentes municipios y profesiones —abogados, economistas, gestores culturales, periodistas, científicos— que encontramos aquí un espacio para pensarnos desde otro lugar, entendernos, inspirarnos y crear algo nuevo para nuestras regiones. Nos sentimos agradecidos por la acogida y el acompañamiento de la Universidad; ha sido una experiencia transformadora”, comenta José Esteban.

Por su parte, Lucía Jaramillo, líder de Alianzas y Ecosistemas de la Dirección de Estrategia, explica que esta iniciativa nació en el marco de los 65 años de la Universidad y en línea con la agenda del Ecosistema de Asuntos Públicos y Sociales, como un compromiso de EAFIT con la construcción de un Estado fortalecido y con líderes públicos formados en evidencia y gestión. “Con base en la experiencia de la primera edición decidimos abrir nuevamente la convocatoria, esta vez con un beneficio del 30 % que incluye a funcionarios y contratistas del Estado”, detalla.

La selección de los beneficiarios incluye un proceso de inscripción, entrevista con los jefes de programa y verificación de la vinculación actual con el sector público.

Con este esfuerzo, la Universidad reafirma su compromiso con el fortalecimiento del sector público, la formación de líderes para el país y el propósito de seguir conectando la educación superior con los desafíos del desarrollo institucional y territorial.

Imagen Noticia EAFIT

![Image 9: Nueva convocatoria de las Becas Talento Público para fortalecer la gestión en el Estado](https://universidadeafit.widen.net/content/ca833c01-c823-4fb4-bb4d-4060bea33147/web/Bloque%20_26_Ceiba.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

## [EAFIT abre la convocatoria a las Becas Talento y Aliados](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-abre-la-convocatoria-las-becas-talento-y-aliados)

Octubre 8, 2025

**Esta iniciativa busca reconocer la excelencia académica, el liderazgo y el talento de jóvenes bachilleres de todo el país. Las becas cubren entre el 40 % y el 100 % del valor de la matrícula y representan una oportunidad para acceder a educación superior de calidad en EAFIT.**

**Para postularse, el aspirante debe haber sido admitido en un programa de pregrado antes del cierre de la convocatoria. El**[**formulario**](https://forms.office.com/pages/responsepage.aspx?id=XrX3mb6ce0aBQ5GXgpGK-7eXmzQySqBIjG-wl2JS4HhUMDFSMDRaN0paUk5ZR0paRlVXMFU3UjQzUi4u&route=shorturl)**de aplicación, gratuito y virtual, estará disponible hasta el 17 de noviembre de 2025, e incluye opciones como las Becas Talento, Nutresa Acceso, ANDI, Ver + Beca Tech y Fundación Educación Suiza.**

*   [Lee más sobre EAFIT abre la convocatoria a las Becas Talento y Aliados](https://www.eafit.edu.co/noticias/nuestro-impacto/eafit-abre-la-convocatoria-las-becas-talento-y-aliados "EAFIT abre la convocatoria a las Becas Talento y Aliados")

Para conocer los requisitos de las becas y obtener más información sobre la convocatoria, se puede ingresar a este **enlace**.

Con el propósito de seguir abriendo caminos para que más jóvenes accedan a la educación superior, EAFIT tiene abierta la convocatoria a las **Becas Talento y Aliados**, una iniciativa que reconoce el mérito académico, el liderazgo y el talento de bachilleres destacados en el país. Esta convocatoria, que recibirá postulaciones hasta el 17 de noviembre de 2025, representa una oportunidad para transformar vidas a través del conocimiento y fortalecer la formación de los futuros profesionales.

Este programa de becas ofrece la posibilidad de cubrir entre el 40 % y el 100 % del valor de la matrícula en programas de pregrado, lo que reduce las barreras económicas y promueve la equidad en el acceso a la educación superior. Con esta apuesta, EAFIT busca que el talento no se vea limitado por factores financieros y que más jóvenes con alto potencial puedan construir su proyecto de vida desde la academia.

“La invitación es a que todos los estudiantes que cumplan con los requisitos y el proceso de admisión, y que estén interesados en ser parte de esta gran comunidad de talento que es EAFIT, se presenten a la convocatoria. El 27 % de nuestros estudiantes cuentan actualmente con algún tipo de beca, así que tenemos las puertas abiertas para que nos acompañen”, destaca Isabel Gómez Yepes, directora de Desarrollo Institucional y Vínculos de EAFIT.

Para postularse a las becas es indispensable haber sido admitido en un programa de pregrado de la Universidad antes del cierre de la convocatoria. Quienes cumplan con este requisito serán considerados como posibles beneficiarios. El proceso de postulación es completamente gratuito y virtual, y el formulario de aplicación está disponible en [**línea**](https://forms.office.com/r/iD24wbnybh).

Entre las opciones disponibles se encuentran las Becas Talento, Nutresa Acceso, ANDI, Ver + Beca Tech y Fundación Educación Suiza, cada una con criterios y beneficios específicos que se ajustan a los diferentes perfiles de los aspirantes. La asignación dependerá del cumplimiento de los requisitos establecidos y del proceso de evaluación realizado por la Universidad y sus aliados.

Sobre el impacto de esta iniciativa, Esteban Hoyos Ceballos, decano de la Escuela de Derecho de EAFIT destaca que “Un programa como Becas Talento y Aliados responde a ese problema social de accesibilidad a la educación superior al crear oportunidades para que jóvenes con trayectorias académicas destacadas y que provienen de entornos no tan privilegiados puedan acceder a una educación de calidad. Usualmente, son la primera generación de sus familias en llegar a la universidad, lo que les permite insertarse al mercado laboral y construir redes personales”.

Con iniciativas como las Becas Talento y Aliados, EAFIT reafirma su compromiso con la formación integral de las nuevas generaciones, al brindar herramientas para que el talento florezca sin limitaciones. La Universidad invita a todos los interesados a consultar la oferta académica, realizar su proceso de admisión y diligenciar el formulario en línea antes de la fecha límite, para ser parte de esta oportunidad que puede marcar un antes y un después en sus trayectorias personales y profesionales.

Imagen Noticia EAFIT

![Image 10: Para conocer los requisitos de las becas y obtener más información sobre la convocatoria, se puede ingresar a este enlace.](https://universidadeafit.widen.net/content/2fb20b34-dc5b-4312-b3ee-a9b16be3e626/web/Becas-Talento-Aliados.jpg)

Categoría de noticias EAFIT

Sección de noticias EAFIT

Bloque para noticias recomendadas

[Suscribirse a Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836/feed)
