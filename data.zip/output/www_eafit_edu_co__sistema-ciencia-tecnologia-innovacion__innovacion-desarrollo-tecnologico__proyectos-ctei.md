Title: Proyectos CTeI

URL Source: https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei

Published Time: Thu, 07 May 2026 20:51:23 GMT

Markdown Content:
# Proyectos CTeI - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#main-content)

[![Image 2: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner maestria gerencia proyectos](https://www.eafit.edu.co/sites/default/files/styles/prueba_crop/public/2025-07/banner-principal-Unidad%20de%20proyectos.png?itok=gqoBWjMM)

# Unidad de proyectos CTeI

Servicios para expertos e investigadores de EAFIT

*   [Inicio](https://www.eafit.edu.co/)
*   [Sistema Ciencia, Tecnología e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Innovación y Transferencia Tecnológica EAFIT](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
*    Proyectos CTeI 

#### **Conectamos tu conocimiento con los problemas de las organizaciones**

**Tu conocimiento puede redefinir el futuro de las empresas y los territorios**

En la dirección de Innovación y Desarrollo Tecnológico, trabajamos para que eso que sabes hacer bien… se transforme en impacto.

Damos vida a proyectos de ciencia, tecnología e innovación que responden a desafíos concretos de empresas, sistemas públicos y comunidades.

**Conoce nuestros servicios para expertos e investigadores.**

## **Servicios**

## Identificación y atracción de proyectos

Reconocemos que nuestros expertos e investigadores son la columna vertebral de nuestra comunidad, y los acompañamos en la búsqueda constante de nuevos desafíos y oportunidades para aplicar su conocimiento y experiencia. Identificamos oportunidades y alineamos nuestras capacidades con las demandas específicas del sector, facilitando la colaboración estratégica.

![Image 22: Imagen Identificación y atracción de proyectos](https://www.eafit.edu.co/sites/default/files/2025-07/Secuencia%2001_2.gif)

[Identificación de oportunidades](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-2359303506)

Identificación de oportunidades

Nuestro equipo especializado identifica necesidades y oportunidades en el ecosistema CTeI y trabaja en estrecha colaboración con expertos e investigadores de la Universidad para enlazar las capacidades con las necesidades específicas rastreadas del sector. Esto nos permite encontrar proyectos que se ajusten a sus áreas de experiencia y permitan aplicar el conocimiento de manera efectiva.

[Estrategias de relacionamiento y mercadeo](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-3807953496)

Estrategias de relacionamiento y mercadeo

Co-creamos con expertos y aliados estrategias efectivas que destaquen en el mercado y establezcan conexiones que perduren en el tiempo. Nuestra experiencia permite que las habilidades de expertos e investigadores sean reconocidas y valoradas por entidades financiadoras y aliados.

## Formulación de propuestas

Colaboramos con expertos e investigadores de la Universidad para transformar sus ideas en propuestas de valor para organizaciones, sistemas públicos y la sociedad. Nuestro valor agregado es convertir ideas en propuestas realizables bajo los estándares de calidad de EAFIT, logrando los retornos académicos, sociales, financieros y de divulgación esperados por la Universidad.

![Image 23: Imagen Formulación de propuestas](https://www.eafit.edu.co/sites/default/files/2025-07/banner-proyectos-ctei.jpg)

[Estructuración de la propuesta](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-1655687639)

Estructuración de la propuesta

Trabajamos en estrecha colaboración con expertos e investigadores para desarrollar una propuesta sólida, clara y oportuna. Esto incluye la definición de los objetivos, el alcance, los productos, la metodología, los recursos y un plan de trabajo que dé respuesta a las necesidades identificadas.

[Seguimiento y ajuste](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-2261199292)

Seguimiento y ajuste

Durante todo el proceso, proporcionamos seguimiento constante para garantizar que las propuestas se ajusten a las necesidades y objetivos, manteniendo una comunicación continua con nuestros aliados y clientes.

[Gestión administrativa](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-1752186373)

Gestión administrativa

Nos encargamos de realizar los trámites administrativos y el cumplimiento de requisitos institucionales con el fin de liberar las capacidades de nuestros expertos e investigadores.

[Negociación con el cliente](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-3022121070)

Negociación con el cliente

Apoyamos a los investigadores y expertos durante el proceso de negociación y gestión con los clientes externos o entidades financiadoras, asegurándonos de que todas las partes involucradas estén alineadas

y comprometidas.

[Adjudicación/Aceptación de la propuesta](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-1201604810)

Adjudicación/Aceptación de la propuesta

Aportamos desde nuestra experiencia para que las propuestas sean seleccionadas y aceptadas. Utilizamos estrategias efectivas de presentación y argumentación para destacar la importancia y el valor de los proyectos.

[Formalización Contractual](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-1731965535)

Formalización Contractual

Una vez que un proyecto ha sido adjudicado o aceptado, gestionamos la formalización de los contratos y acuerdos, garantizando que todos los términos estén claramente definidos y cumplan con las expectativas de todas las partes.

## Ejecución de proyectos

Materializamos las propuestas innovadoras en resultados e impactos transformadores para la sociedad. Nuestro compromiso es garantizar que los proyectos se ejecuten de manera integral y confiable, simplificando la ejecución para que las Escuelas, Centros y Grupos de Investigación se concentren en su core.

![Image 24: Imagen Ejecución de proyectos](https://www.eafit.edu.co/sites/default/files/2025-07/FRT_1397-Editar.JPG)

[Kick off](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-1186400957)

Kick off

Coordinamos reuniones de inicio para establecer claramente los objetivos, roles, y expectativas con todos los participantes del proyecto. Esto incluye la definición de metas, plazos y responsabilidades, asegurando un entendimiento común y compromiso desde el comienzo.

[Creación financiera y contable](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-747345891)

Creación financiera y contable

Gestionamos con la Dirección Administrativa y financiera, la creación de los centros de costos para cada proyecto, con su respectiva asignación de presupuesto para el inicio de las actividades y la ejecución de los recursos.

[Gestión integral](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-839976140)

Gestión integral

Coordinamos los diferentes aspectos administrativos de los proyectos para asegurar su correcto funcionamiento, incluyendo: contratación de personal, adquisiciones, gestión financiera y contable, gestión de activos, aspectos legales y comunicación.

[Supervisión y seguimiento técnico](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-3881315919)

Supervisión y seguimiento técnico

Realizamos un seguimiento continuo a la ejecución técnica de los proyectos, velando por el cumplimiento de los objetivos, identificando alertas y ofreciendo soluciones para asegurar su correcta implementación. Monitoreamos la generación de productos de Ciencia, Tecnología e Innovación (CTeI) y, junto con el área de Transferencia de Tecnología y Conocimiento, gestionamos su certificación y protección.

[Fidelización y desarrollo de clientes](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-2085867167)

Fidelización y desarrollo de clientes

Nuestro compromiso va más allá de la ejecución de proyectos. Nos enfocamos en ofrecer un valor continuo a nuestros clientes y aliados, optimizando los proyectos actuales e identificando nuevas oportunidades que impulsen su desarrollo. Trabajamos con una visión de largo plazo, anticipando sus necesidades futuras para que puedan alcanzar sus objetivos estratégicos.

## Cierre de proyectos

Lideramos el cierre efectivo de los proyectos, garantizando que todos los aspectos se realicen de manera adecuada y que se aprovechen al máximo las lecciones aprendidas.

![Image 25: Imagen Cierre de proyectos](https://www.eafit.edu.co/sites/default/files/2025-07/cierre.jpg)

[Cierre con el cliente](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-2960550412)

Cierre con el cliente

Coordinamos las actividades necesarias para la finalización de los proyectos de manera satisfactoria, garantizando la entrega de productos e informes y la realización de eventos de cierre.

Nos aseguramos de cumplir todas las expectativas y mantener una relación positiva con el cliente, aliado o entidad financiadora.

[Actividades post proyecto](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-691547196)

Actividades post proyecto

Una vez finalizados los proyectos, gestionamos la liquidación y evaluamos el feedback del cliente o aliado. Recopilamos toda la documentación necesaria para respaldar la experiencia de la Universidad en futuros proyectos. Respondemos a las solicitudes de entidades de control, tanto internas como externas.

[Cierre interno](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei#4257225834-1395225424)

Cierre interno

Gestionamos el cierre completo de los aspectos administrativos, financieros y legales del proyecto dentro de la Universidad. Esto incluye la legalización de activos de cada proyecto, la conclusión contable y financiera, y la implementación de directrices para el fortalecimiento institucional a través de la CTeI.

Tipologías de proyectos

Proyectos comerciales

Proyectos 100% financiados por empresas que buscan soluciones a la medida. Aportamos conocimiento y experiencia para el diseño e implementación, garantizando que la inversión se enfoque en el desarrollo de la solución.

Proyectos sociales y de desarrollo

Proyectos desarrollados para el beneficio de las comunidades y las regiones, mediante la financiación de entidades públicas, agencias de cooperación internacional, ONGs y pequeñas empresas.

Proyectos co-financiados

Proyectos desarrollados en asocio con entidades públicas, privadas o de cooperación internacional, donde se comparten recursos, responsabilidades y propiedad intelectual para alcanzar objetivos comunes.

Proyectos cooperados

Proyectos desarrollados con aliados estratégicos, donde EAFIT aporta sus capacidades y experiencia para lograr objetivos comunes, sin intercambio de recursos financieros. Estos proyectos requieren la autorización de la Dirección de Investigación.

Fondos ejecutables

Proyectos financiados por convocatorias públicas, como las de regalías, donde EAFIT actúa como ejecutor, sin recibir financiación directa. La entidad otorgante gestiona los recursos y EAFIT se encarga de la ejecución del proyecto.

#### **Únete a nuestra red en LinkedIn**

Descubre cómo el conocimiento de EAFIT se convierte en acciones que transforman realidades desde la ciencia, la tecnología y la innovación.

[Únete a nuestra red en LinkedIn](https://www.linkedin.com/showcase/innovaci%C3%B3n-eafit)

[![Image 26: Imagen de Mujer con micrófono en la mano sonriendo y detrás de ella mujer con gafas de realidad virtual y otra mujer mirando por una lupa](https://universidadeafit.widen.net/content/f67fc677-626c-48d2-839b-df58fba144f9/web/banner-redes-sociales-tecnologias.jpg?crop=yes&k=c&w=645&h=245&itok=YWWY8ksS)](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

![Image 27](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)

![Image 28: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 29: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 30: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 31: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 32: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 33: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 34: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 35: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
