Title: Pregrados

URL Source: https://www.eafit.edu.co/pregrados

Markdown Content:
# Pregrados - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/pregrados#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 2: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/pregrados#)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/pregrados# "Spanish")[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/pregrados# "English")

*   [Spanish](https://www.eafit.edu.co/pregrados)
*   [Inglés](https://www.eafit.edu.co/en/pregrados)

 Información para ti

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 6: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 7: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 8: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 9: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 10: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 12: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 13: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 14: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 15: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 16: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 17: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 18: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 19: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 20: Imagen de banner tres personas mirando un libro ](https://universidadeafit.widen.net/content/09ed04ec-93d0-40e1-9e8c-57839260f658/web/primer-dia-clase-2025.jpg?crop=yes&k=c&w=1920&h=788&itok=aWK6v1C8)

# Inscripciones abiertas Pregrado 2026-2

Conoce los 26 programas que tenemos para ti y haz parte de la Universidad que es hogar de una comunidad con el poder de transformarlo todo.

[Déjanos tus datos](https://www.eafit.edu.co/pregrados#formulario)

*   [Inicio](https://www.eafit.edu.co/)
*    Pregrados 

##### Programas de pregrado que te han interesado recientemente

## **Conoce nuestros 26 programas de pregrado**

Filtros

*   [Sistemas Naturales y Sostenibilidad(4)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1661)
*   [Creación(3)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1601)
*   [Mercados y Estrategia Financiera(3)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1626)
*   [​Diseño de Productos y Experiencias(3)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1646)
*   [​​Industria​, Materiales y Energía(3)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1656)
*   [​Territorios y Ciudades(2)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1651)
*   [Ciencias Fundame​ntales(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1641)
*   [Cultura(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1591)
*   [Derecho(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1551)
*   [Lenguaje(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1596)
*   [Macroeconomía y Sistemas Financieros(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1631)
*   [Marketing e Innovación(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1621)
*   [Organización, Dirección y Estrategia(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1606)
*   [Políticas y Desarrollo(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1636)
*   [​​​Computación y Analítica(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=area_de_conocimiento_pregrado%3A1666)

Facet Área de conocimiento Pregrado 

*   [Ciencias Aplicadas e Ingeniería(14)](https://www.eafit.edu.co/pregrados?f%5B0%5D=escuelas_pregrados%3A1541)
*   [Artes y Humanidades(5)](https://www.eafit.edu.co/pregrados?f%5B0%5D=escuelas_pregrados%3A1531)
*   [Administración(4)](https://www.eafit.edu.co/pregrados?f%5B0%5D=escuelas_pregrados%3A1536)
*   [Finanzas, Economía y Gobierno(3)](https://www.eafit.edu.co/pregrados?f%5B0%5D=escuelas_pregrados%3A1546)
*   [Derecho(1)](https://www.eafit.edu.co/pregrados?f%5B0%5D=escuelas_pregrados%3A1526)

Facet Escuelas Pregrados 

[Ciencias Aplicadas e Ingeniería](https://www.eafit.edu.co/taxonomy/term/1541)

#### Ingeniería de Construcción

![Image 21: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 semestres

![Image 22: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 23: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 24: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 25: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 26: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES

![Image 27: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$16.060.617

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 28: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$15.717.441

Becas y financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-ciencias-aplicadas-ingenieria/ingenieria-de-construccion "Ver pregrado")

[Ciencias Aplicadas e Ingeniería](https://www.eafit.edu.co/taxonomy/term/1541)

#### Ingeniería Industrial

![Image 29: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 semestres

![Image 30: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín​

![Image 31: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 32: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 33: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 34: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 117373

![Image 35: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$16.060.617

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 36: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$15.580.171

![Image 37: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Becas y financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-ciencias-aplicadas-ingenieria/ingenieria-industrial "Ver pregrado")

[Artes y Humanidades](https://www.eafit.edu.co/taxonomy/term/1531)

#### Psicología

![Image 38: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 Semestres

![Image 39: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 40: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 41: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 42: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 43: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 90978

![Image 44: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$15.442.901

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 45: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$15.099.725

![Image 46: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Becas y financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-artes-humanidades/psicologia "Ver pregrado")

[Ciencias Aplicadas e Ingeniería](https://www.eafit.edu.co/taxonomy/term/1541)

#### Biología

![Image 47: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 semestres

![Image 48: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 49: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 50: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 51: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 52: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 101947

![Image 53: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$16.060.617

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 54: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$16.060.617

![Image 55: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Becas y Financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-ciencias-aplicadas-ingenieria/biologia "Ver pregrado")

[Ciencias Aplicadas e Ingeniería](https://www.eafit.edu.co/taxonomy/term/1541)

#### Ingeniería de Sistemas

![Image 56: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

9 semestres

![Image 57: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 58: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 59: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 60: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 61: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 1248

![Image 62: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$15.442.901

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 63: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$15.717.441

![Image 64: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Becas y Financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-ciencias-aplicadas-ingenieria/ingenieria-sistemas "Ver pregrado")

[Ciencias Aplicadas e Ingeniería](https://www.eafit.edu.co/taxonomy/term/1541)

#### Ingeniería Agronómica

![Image 65: Íconos pregrados](https://universidadeafit.widen.net/content/250979b6-89eb-4202-8cce-a952479b651d/web/icono-duracion.svg)

Duración

10 semestres

![Image 66: Íconos pregrados](https://universidadeafit.widen.net/content/6895dbe1-1793-44f2-a54d-3cfe6917f719/web/icono-lugar.svg)

Lugar

Medellín

![Image 67: Íconos pregrados](https://universidadeafit.widen.net/content/8bbbdb4f-75f0-46fd-8b5f-06b095b08c8c/web/icono-horario.svg)

Horario

Tiempo completo

![Image 68: Íconos pregrados](https://universidadeafit.widen.net/content/f161b4c5-b22b-4036-b21d-9d89db70383b/web/icono-idioma.svg)

Idioma

Español

![Image 69: Íconos pregrados](https://universidadeafit.widen.net/content/ea928c58-98d2-454f-9551-934a8a5d6cc4/web/icono-modalidad.svg)

Modalidad

Presencial

![Image 70: Íconos para información de pregrados](https://universidadeafit.widen.net/content/1b93062e-1dd7-46a7-874a-6733738f25cb/web/qr.svg)

SNIES

SNIES 107709

![Image 71: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor del primer semestre

$16.060.617

[Conoce otras tarifas](https://www.eafit.edu.co/tarifas)

![Image 72: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Valor promedio de los semestres

$14.207.469

![Image 73: Íconos pregrados](https://universidadeafit.widen.net/content/1d5bdbc0-e288-4124-bd28-c7b95abfcfbc/web/icono-precio.svg)

Becas y Financiación

[Ver opciones de financiación](https://www.eafit.edu.co/becas-y-financiacion)

[Ver más](https://www.eafit.edu.co/pregrados/escuela-ciencias-aplicadas-ingenieria/ingenieria-agronomica "Ver pregrado")

*   [Página actual 1](https://www.eafit.edu.co/pregrados?label=&page=0 "Página actual")
*   [Página 2](https://www.eafit.edu.co/pregrados?label=&page=1 "Ir a la página 2")
*   [Página 3](https://www.eafit.edu.co/pregrados?label=&page=2 "Ir a la página 3")
*   [Página 4](https://www.eafit.edu.co/pregrados?label=&page=3 "Ir a la página 4")
*   [Página 5](https://www.eafit.edu.co/pregrados?label=&page=4 "Ir a la página 5")
*   [Siguiente página›](https://www.eafit.edu.co/pregrados?label=&page=1 "Ir a la página siguiente")
*   [Última página Último »](https://www.eafit.edu.co/pregrados?label=&page=4 "Ir a la última página")

## Guía de aspirantes a pregrado

[Fechas y guía de inscripción](https://www.eafit.edu.co/pregrados#4257225834-1315358045)

Fechas y guía de inscripción

##### 1. Fechas y guía de inscripción

Tu camino en EAFIT comienza aquí. Para asegurar que tu proceso de admisión sea exitoso, es fundamental cumplir con los requisitos y entregables en las fechas definidas por la Universidad.

###### Convocatoria Beca Talento y Aliados

Si aspiras a una beca para el semestre 2026-2, completa y paga tu inscripción para participar en el proceso de selección de estos beneficios.

**Postulación a la beca:** del 9 de marzo al 24 de mayo.

**Entrega de resultados Saber 11:** 15 de mayo.

###### **Hitos importantes de la inscripción**

**Cortes de admisión y resultados**

Las inscripciones están abiertas según la disponibilidad de cada programa. Una vez completes tu proceso, evaluaremos tu perfil en los siguientes cortes para que recibas tu respuesta oportunamente:

**Primer corte:** Entrega documentos y realiza tu entrevista hasta el 6 de marzo. Recibe tu resultado el 11 de marzo.

**Segundo corte:** Entrega documentos y realiza tu entrevista hasta el 20 de marzo. Recibe tu resultado el 25 de marzo.

**Tercer corte:** Entrega documentos y realiza tu entrevista hasta el 10 de abril. Recibe tu resultado el 15 de abril.

**Cuarto corte:**Entrega documentos y realiza tu entrevista hasta el 24 de abril. Recibe tu resultado el 29 de abril.

**Quinto corte:** Entrega documentos y realiza tu entrevista hasta el 8 de mayo. Recibe tu resultado el 13 de mayo.

**Sexto corte:** Entrega documentos y realiza tu entrevista hasta el 22 de mayo. Recibe tu resultado el 27 de mayo.

**Séptimo corte:** Entrega documentos y realiza tu entrevista hasta el 6 de junio. Recibe tu resultado el 10 de junio.

**Hitos de cierre e inicio de semestre**

Recibirás la notificación oficial de tu admisión directamente en el correo personal que registraste en el formulario.

**Límite de pago de matrícula:** 13 de julio.

**Jornadas de inducción:** 15, 16 y 17 de julio.

**Inicio de clases:** 21 de julio.

**Prepárate para tu vida universitaria**

Te acompañamos en cada paso de tu ingreso. Consulta nuestra guía de inscripción y conoce cómo acceder a tu horario de clases, participar en las jornadas de inducción, tramitar tu carné estudiantil y gestionar los procesos clave para tu inicio en la Universidad.

[Descarga la guía de inscripción completa](https://universidadeafit.widen.net/s/xjmmtpgk9v/guia_aspirantes_pregrado_2026-2_con_programae-2)

[Aplica a tu pregrado](https://www.eafit.edu.co/pregrados#4257225834-2487737533)

Aplica a tu pregrado

##### 2. Sigue los pasos para aplicar a tu pregrado

1.   [Ingresa aquí y crea tu usuario y contraseña](https://www.eafit.edu.co/epik) para poder acceder al formulario de inscripción en este enla​ce. (Si ya has participado en un curso de Idiomas o Educación Continua, es posible que ya tengas un usuario institucional y contraseña).
2.   ​​[Ingresa a Epik​](https://www.eafit.edu.co/epik) y comp​leta el formulario. (Conoce la oferta académica de Bienestar Universitario [aquí](https://universidadeafit.widen.net/s/jrhwqh7k9x/03-folleto-bienestar-universitario-2026-1))
3.   Realiza el pago de $224.300 COP. ​​​
4.   Adjunta los siguientes documentos:
    1.   Cer​tificado de notas de los dos últimos años cursados y aprobados emitido por tu colegio​.

Importante: Si tu colegio tiene hasta el grado 11, adjunta las notas de los grados 9º y 10º. Si tu colegio tiene hasta el grado 12, adjunta las notas de los grados 10º y 11º.​
    2.   Documento de identidad.
    3.   Resultado de tus Pruebas Saber 11 o el número​ de registro (código ​AC).

Si aún no tienes los resultados de tus pruebas puedes [ingresar aquí](https://resultados.icfes.edu.co/resultados-saber2016-web/pages/publicacionResultados/autenticacion/consultaSnp.jsf#No-back-button) consultar tu número de registro de las pruebas.

**Nota:** Si estás aplicando a **Transferencia Externa (TEX)**, te invitamos a revisar los documentos requeridos [aquí](https://universidadeafit.widen.net/s/wclktvgnp9/guia_aspirantes_pregrado_2026-2_con_programae) y descargar el formato de carta requerido para el proceso [aquí](https://universidadeafit.widencollective.com/assets/share/asset/ohamebpxrl)

Si estás aplicando a Negocios Internacionales adjunta el certificado de bilingüismo avalado por EAFIT. [Aquí puedes consultar](https://www.eafit.edu.co/idiomas/testing-center) los exámenes avalados por la institución.

[Prepárate para tu entrevista](https://www.eafit.edu.co/pregrados#4257225834-2183763748)

Prepárate para tu entrevista

##### 3. Prepárate para tu entrevista

Debes estar pendiente de la citación que llegará​ al correo que registraste en tu formulario de inscripción​. Para prepararte ten en cuenta las siguientes recomendaciones:

**Define** lo que te mueve.

**Infórmate** sobre la Universidad y sobre tu programa. Te​n claro por qué te interesa, pero evita respuestas genéricas. Lo importante es expresarte con naturalidad.

**Muestra** quién eres más allá de tus notas.

**Comparte** tus intereses, experiencias y aprendizajes. Más que lo que te gusta, cuéntanos lo que te inspira y cómo quieres aportar al mundo.

**Comunica** con confianza y seguridad.

**Habla** con claridad, escucha atentamente y organiza tus ideas. Cuida tu lenguaje corporal: mantén contacto visual, proyecta seguridad y muestra una actitud positiva.

[Consulta los resultados de admisión](https://www.eafit.edu.co/pregrados#4257225834-2602530155)

Consulta los resultados de admisión

##### 4. Consulta los resultados de admisión

Te informaremos los resultados al correo electrónico que registraste en el formulario de inscripción. Recuerda que tu admisión dependerá del cumplimiento de todos los requisitos establecidos dentro de los plazos indicado​s.

Recuerda, si tus notas del colegio o los resultados de las Pruebas Saber Pro no cumplen con el puntaje mínimo, ¡no te preocupes! Serás admitido a Programa E. [Conoce más aquí](https://www.eafit.edu.co/programa-e)

¡Ya est​​ás más cerca de hacer parte de una comunidad de talento con el poder de transformarlo todo!

[![Image 74: Imagen de tres personas estudiando ](https://universidadeafit.widen.net/content/29e06c8a-654b-40c5-8a52-333f32ff6a5c/web/Artes-y-Humanidades-9.jpg?crop=yes&k=c&w=1920&h=788&itok=XjghgIiQ)](https://www.eafit.edu.co/pregrados)

![Image 75: Pregrados EAFIT](https://www.eafit.edu.co/pregrados)

## Inicia tu proceso de inscripción

El valor es de $224.300.

[Inscríbete aquí](https://mcu.azureedge.net/?site=MCU_003&cmd=login)

Nuestras escuelas

## Administración

[Ver Escuela de Administración](https://www.eafit.edu.co/escuela-administracion)

## Ciencias Aplicadas e Ingeniería

[Ver Escuela de Ciencias Aplicadas](https://www.eafit.edu.co/escuela-ciencias-aplicadas-ingenieria)

## Artes y Humanidades

[Ver Escuela de Artes](https://www.eafit.edu.co/escuela-artes-humanidades)

## Derecho

[Ver Escuela de Derecho](https://www.eafit.edu.co/escuela-derecho)

## Finanzas, Economía y Gobierno

[Ver Escuela de Finanzas](https://www.eafit.edu.co/escuela-finanzas-economia-gobierno)

![Image 76: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

## 9.500

estudiantes activos

## 40.000

graduados

![Image 77: Imagen 9.500 ](https://universidadeafit.widen.net/content/5f57f59e-4bba-449f-8d29-2ba6c7b416c6/web/Posgrado-Especializacion-en-responsabilidad-civil-10.jpg?itok=DmmnRYkq)

## Estudios generales

Si aún no sabes que estudiar, la Universidad tiene para ti una alternativa que te ayudará a conocer las carreras mientras disfrutas la vida universitaria.

[Conoce más aquí](https://www.eafit.edu.co/estudios-generales)

![Image 78: Imagen Estudios generales](https://universidadeafit.widen.net/content/fb01cbf3-312c-4284-933b-22f7d0c6461c/web/Pregrado-comunicacion-social-4.jpg)

¿Deseas más información so​bre este​ p​rograma? 

¿Deseas más información so​bre este​ p​rograma?

Diligencia el formulario, chatea con nosotros o escríbenos a través de Whatsapp para contarte más sobre cómo cumplir tus sueños en EAFIT.

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Pregrados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Correo electrónico*? 

Teléfono*? 

Inicio del programa? 

Canal origen 

Programa? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 79: Pregrados EAFIT](https://www.eafit.edu.co/pregrados)

![Image 80: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 81: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 82: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 83: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 84: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 85: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 86: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 87: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
