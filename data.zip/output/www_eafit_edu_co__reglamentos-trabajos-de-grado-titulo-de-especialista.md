Title: Reglamentos trabajos de grado, título de especialista

URL Source: https://www.eafit.edu.co/reglamentos-trabajos-de-grado-titulo-de-especialista

Markdown Content:
###### Capítulo Preliminar: Justificación

**Artículo 1.**

Para optar al título de Especialista, además de los requisitos que establece el reglamento académico de los programas de posgrado, el estudiante deberá desarrollar y presentar una monografía, la cual se regirá por el presente reglamento.

###### Capítulo I. El concepto de trabajo monográfico

**Artículo 2.**

Se entiende por trabajo monográfico el resultado del esfuerzo de indagación, análisis y presentación de conclusiones sobre un tema aprobado por la Universidad a través del Comité de Especialización, o del organismo que las directivas determinen, para aplicar, validar, elaborar y enriquecer los conocimientos recibidos durante el ejercicio académico. Dicho trabajo debe incorporar las guías metodológicas establecidas por el ICONTEC

###### **Capítulo II. Las fuentes de los temas de trabajo monográfico**

**Artículo 3.**

Los trabajos pueden ser originados en los grupos líneas de investigación de la Universidad, entendiendo por líneas de investigación aquellas áreas del saber teórico o práctico en las cuales Eafit tiene interés investigativo; investigaciones que adelanten los profesores de la Universidad y que hayan sido aprobadas por ésta; temas articulados con proyectos de investigación conducentes a título de doctorado o maestría.

###### Capítulo III. Parámetros para determinar la categoría de trabajo monográfico

**Artículo 4.**

Los siguientes son los parámetros para determinar cuándo un trabajo se considera como "trabajo monográfico":

La temática que se ha de investigar ha de aludir a la problemática del saber de la especialización correspondiente.

Deberá emplear metodologías reconocidas por la comunidad académica.

Deberá contemplar una revisión del estado de arte -nacional e internacional- en el tema de estudio, la formulación de hipótesis y el planteamiento de posibles soluciones.

Deberá ser un trabajo que profundice, con originalidad y referido el campo teórico o práctico, con posibles aplicaciones y sustentado en una bibliografía suficiente sobre el tema de estudio.

###### Capítulo IV. El concepto de profesor asesor

**Artículo 5.**

Podrá ser "Profesor asesor" del trabajo de la monografía el docente que participa en una línea académica, investigativa y/o desarrolle su tesis doctoral o un  proyecto de investigación institucional y se compromete activamente en el proceso de ejecución de un trabajo de investigación.

Parágrafo: A criterio del Comité de Especialización, se podrá aceptar como Profesor Asesor a profesionales externos que cumplan con los requisitos señalados en el presente Artículo.

###### Capítulo V. Funciones del asesor del trabajo monográfico

**Artículo 6. A continuación se presentan las funciones básicas del Profesor Asesor:**

Acompañar y dirigir al estudiante en la definición y elaboración del proyecto, sugerir temas, bibliografías y metodología.

Discutir y avalar la propuesta de monografía que el estudiante somete a consideración del Comité de Especialización. En el momento en que el asesor considere que el proyecto está suficientemente elaborado, deberá firmar el documento entregado como manifestación expresa de su aceptación de los términos y de su responsabilidad como Profesor Asesor del trabajo.

Verificar que el proyecto se desarrolle de acuerdo con los objetivos y requisitos aprobados por el Comité de Especialización, e informar al mismo de cualquier situación anormal que se presente.

Autorizar la presentación del trabajo ante el Comité de Especialización para que éste designe lectores para el mismo.

###### Capítulo VI. Elaboración del proyecto para el trabajo de monografía

**Artículo 7.**

Elaboración del proyecto. Una vez el estudiante haya seleccionado con el Profesor Asesor el tema del trabajo de monografía, deberá presentar una propuesta la cual deberá contemplar los siguientes puntos:

Tema de la monografía.

Tabla del contenido de la propuesta, desarrollando los siguientes puntos:

Planteamiento del problema

Presentación

Objeto de estudio

Objetivo principal

Objetivos específicos

Formulación del problema

Justificación

Estado del arte y marco teórico

Hipótesis general

Metodología y fuentes de información.

Expectativas y alcance

Cronograma de actividades

Bibliografía

Nombre del profesor asesor

**Artículo 8.**

Presentación del proyecto. El estudiante deberá entregar dos copias del proyecto en la secretaría de la Escuela respectiva, una de las cuales se le entregará al Comité de Especialización y la otra se archivará en el folder correspondiente al proyecto.

**Artículo 9.**

El estudiante deberá llenar y entregar una ficha del proyecto para clasificarlo, la cual deberá contener un resumen de la información señalada en el Artículo 7 del presente reglamento.

**Artículo 10.**

Entrega y recepción del proyecto de monografía. Una vez terminados y aprobados todos los cursos, según los requisitos de cada programa, el estudiante dispondrá de doce (12) meses para entregar el proyecto de monografía.

Este plazo podrá ser prorrogado hasta por seis (6) meses más, a criterio del Comité de Especialización, cuando así lo solicite el estudiante antes del vencimiento del plazo inicialmente establecido.

Parágrafo. La monografía deberá ser entregada dentro de los diez y ocho (18) meses siguientes a la fecha de aprobación por parte del Comité de Especialización del proyecto monográfico. Durante el plazo que el estudiante esté realizando el trabajo de monografía podrá utilizar todas las instalaciones de la Universidad, teniendo la obligación de cancelar en las oficinas de la Institución, de manera semestral, una suma de dinero equivalente a dos (2) salarios mínimos mensuales vigentes.

###### Capítulo VII. Mecanismos para la aprobación y evaluación de los trabajos de monografía

**Artículo 11.**

La evaluación se hará por el Comité de Especialización. El Comité delegará hasta en dos profesores la lectura del trabajo. Los profesores encargados de la lectura rendirán concepto escrito sobre el trabajo, recomendando al Comité de Especialización, en forma motivada, su aprobación o rechazo; y en caso de aprobación, si la misma se hace merecedora a recibir mención de honor o ser laureada.

Los profesores que realizarán la lectura del trabajo podrán ser sugeridos tanto por el estudiante como por el Profesor Asesor.

**Artículo 12.**

**El lector, o los lectores, según el caso, deberán tener como criterios para la evaluación del trabajo de investigación los siguientes**:

El cumplimiento de los objetivos y del alcance propuesto.

La profundidad y claridad en el análisis del tema.

Vigencia o actualidad.

Desarrollo lógico del tema y de sus componentes.

Respaldo y sustentación bibliográfica.

Claridad de la argumentación y manejo idiomático.

**Desde el punto de vista metodológico, deberá tenerse en cuenta:**

Rigurosidad en la aplicación de la metodología de la investigación.

Rigurosidad en la aplicación de las normas ICONTEC

Orden en la presentación.

**Artículo 13.**

Calificación del trabajo monográfico. Por escrito y en formato de la Universidad, el Comité de Especialización dará a conocer su decisión sobre la calificación del trabajo dentro del mes siguiente a su entrega o sustentación, la cual será aprobado o rechazado.

###### Capítulo VIII. Incentivos al trabajo monográfico

**Artículo 14.**

La calificación "Aprobado" debe ser concedida por mayoría cuando el jurado está por más de un docente como jurado.

Cuando un estudiante recibe del Consejo Académico la mención de "Laureada" o tiene mención de "Honor", el Profesor asesor y/o los lectores, podrán sugerir a la Universidad su publicación.

###### **​**Capítulo IX. Sanciones

**Artículo 15.**

Si se comprueba fraude de información, apropiación indebida de creación intelectual o violación de confidencialidad en la información utilizada, o cualquier otra anomalía en la elaboración del trabajo, la Universidad aplicará el reglamento vigente."
