Title: Bienestar Universitario

URL Source: https://www.eafit.edu.co/bienestar-universitario

Markdown Content:
# Bienestar Universitario - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/bienestar-universitario#main-content)

[![Image 3: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario#)

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/bienestar-universitario# "Spanish")[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/bienestar-universitario# "English")

 Información para ti

[![Image 7: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 8: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 9: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 10: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 11: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 12: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 13: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 14: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 15: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 16: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 17: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 18: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 19: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 20: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 21: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 22: Imagen de banner bienvenida estudiantes extranjeros](https://universidadeafit.widen.net/content/4752edf3-c953-42bf-91b1-3215ef6b7950/web/Bienvenida-Estudiantes-Extranjeros.jpg?crop=yes&k=c&w=1920&h=788&itok=1gX23ZTQ)

# Bienestar Universitario

*   [Inicio](https://www.eafit.edu.co/)
*    Bienestar Universitario 

###### ​​​​​​​​​​​La filosofía ​​de Bienestar Universitario

La Dirección de Desarrollo Humano y Bienestar pretende hacer del bienestar un valor individual y colectivo en la comunidad eafitense. Desde la conciencia del mutuo cuidado, con base en los valores institucionales invita a que la vida sea un vivir bien. Que las acciones sean una oportunidad para el recto actuar en un ambiente solidario y respetuoso de la diversidad y del entorno.

[Conoce más](https://www.eafit.edu.co/bienestar-universitario/sobre-la-direccion-de-desarrollo-humano-y-bienestar)

[![Image 23: Imagen de estudiantes caminando por el campus universitario](https://universidadeafit.widen.net/content/bf65a423-bcf4-44a6-a433-7f25249915f9/web/intercambio-academico-nacional-1.jfif)](https://www.eafit.edu.co/bienestar-universitario)

![Image 24](https://www.eafit.edu.co/bienestar-universitario)

​Para lograrlo, la Dirección desarrolla programas y servicios para:

Contribuir al desarrollo de las personas en las dimensiones cultural, social, moral, intelectual, psicoafectiva y física.

Promover acciones que mejoren las condiciones de vida de la comunidad eafitense. ​​​

Fomentar hábitos y comportamientos que propicien el bienestar, el cuidado en el relacionamiento con otros y con el entorno, a partir del respeto por la diversidad.

Promover y trabajar por una cultura de respeto y una vida libre de violencia y discriminación, en temas de género, diversidad e inclusión, en la comunidad universitaria.

Promover el acceso, permanencia y graduación oportuna de

 los estudiantes de pregrado y posgrado.

​La Prestación de programas y servicios que se ofrecen desde la Dirección de Desarrollo Humano - Bienestar Universitario de la Universidad EAFIT, se llevan a cabo a partir de tres líneas de acción:

Vida Universitaria

Servicios dirigidos al cuidado, bienestar y mejoramiento de la calidad de vida estudiantil y laboral.

[Conoce más aquí](https://www.eafit.edu.co/bienestar-universitario/vida-universitaria)

Representación Universitaria

Acompañamiento para la participación y representación universitaria. ​​​

[Conoce más aquí](https://www.eafit.edu.co/bienestar-universitario/representacion-universitaria)

Formación y Desarrollo

Servicios de apoyo que contribuyen al mejoramiento académico, laboral y a la formación integral.​​​

[Conoce más aquí](https://www.eafit.edu.co/bienestar-universitario/formacion-desarrollo)

​Estas son algunas de las áreas que propician condiciones de bienestar en EAFIT:​

![Image 25: Imagen Departamento de Servicio Médico y Seguridad y Salud en el Trabajo](https://universidadeafit.widen.net/content/86a415d8-b883-4562-a19c-d9cb989d4cb5/web/servicio-medico-desarrollo-humano.jpg?crop=yes&k=c&w=397&h=253&itok=ihCkXsHh)

Departamento de Servicio Médico y Seguridad y Salud en el Trabajo

[Conoce más](https://www.eafit.edu.co/bienestar-universitario/centro-servicio-medico)

![Image 26: Imagen Deportes y Recreación](https://universidadeafit.widen.net/content/53372e50-ba84-45dc-90e4-118979bd7e9a/web/deportes.jpg?crop=yes&k=c&w=397&h=253&itok=ZheGSRsP)

Deportes y Recreación

[Conoce Deportes](https://www.eafit.edu.co/bienestar-universitario/deportes)

![Image 27: Imagen Desarrollo Artístico](https://universidadeafit.widen.net/content/97bd3474-dc9c-4462-9229-d8c097bd124f/web/desarrollo-artistico.jpg?crop=yes&k=c&w=397&h=253&itok=ivybajVU)

Desarrollo Artístico

[Conoce Desarrollo artístico](https://www.eafit.edu.co/bienestar-universitario/desarrollo-artistico)

![Image 28: Imagen Desarrollo Estudiantil](https://universidadeafit.widen.net/content/bfc7c113-78f7-4458-9c84-37b7937d6b78/web/desarrollo-estudiantil-destacado.jpg?crop=yes&k=c&w=397&h=253&itok=Wy8_l_60)

Desarrollo Estudiantil

[Conoce Desarrollo estudiantil](https://www.eafit.edu.co/bienestar-universitario/desarrollo-estudiantil)

![Image 29: Imagen Género, diversidad e inclusión](https://universidadeafit.widen.net/content/34057cb8-150f-4fc0-a400-3902144e6af7/web/genero-identidad-destacado.jpg?crop=yes&k=c&w=397&h=253&itok=eE7Hr_Vu)

Género, diversidad e inclusión

[Conoce más](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

![Image 30: Imagen Talento Humano](https://universidadeafit.widen.net/content/5cf1ed75-9f4a-41ef-9996-564e7f630a25/web/desarrollo-empleados.jpg?crop=yes&k=c&w=397&h=253&itok=6psfyaCm)

Talento Humano

[Conoce Talento humano](https://www.eafit.edu.co/bienestar-universitario/talento-humano)

[![Image 31: Imagen de logo mutuo cuidado](https://universidadeafit.widen.net/content/58de97f5-ebb6-49bc-8fa1-fa386bf25a85/web/mutuo-cuidado.gif?animate=true)](https://www.eafit.edu.co/bienestar-universitario)

![Image 32](https://www.eafit.edu.co/bienestar-universitario)

[¿Qué es Mutuo Cuidado?](https://universidadeafit.widen.net/s/jqtj6js6mg/cuidado-mutuo-cuidado)

Contacto - Bienestar universitario 

A continuación, encontrarás el formulario que debes diligenciar. Por favor, ten en cuenta lo siguiente:

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Contacto - Bienestar universitario

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Celular*? 

Correo electrónico*? 

Contenido de interés 

Su consulta*? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 33](https://www.eafit.edu.co/bienestar-universitario)

![Image 34: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 35: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 36: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 37: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 38: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 39: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 40: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 41: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
