Title: Autoevaluación Institucional

URL Source: https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion

Markdown Content:
# Acreditación - Autoevaluación
[Pasar al contenido principal](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

Powered by [![Image 2: Google Translate](https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png)Translate](https://translate.google.com/)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#)

[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion# "Spanish")[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion# "English")

 Información para ti

[![Image 6: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 7: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 8: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 9: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 10: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 11: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 12: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 13: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 14: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 15: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 16: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 17: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 18: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 19: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 20: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 21: Imagen de banner induccion estudiantes foraneos ](https://universidadeafit.widen.net/content/8ebf13a2-2f7c-4fd6-bca4-ace081d3d412/web/induccion-estudiantes-foraneos-2024213.jpg?crop=yes&k=c&w=1920&h=788&itok=a-HgrK_x)

# ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Autoevaluación Institucional

*   [Inicio](https://www.eafit.edu.co/)
*   [Información Institucional](https://www.eafit.edu.co/institucional)
*   [​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Renovación de La Acreditación Institucional](https://www.eafit.edu.co/institucional/acreditacion)
*    Autoevaluación Institucional 

Desplegar menú
*   [Autoevaluación](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion "Ancla menú")
*   [Logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion "Ancla menú")
*   [Qué evaluamos](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion "Ancla menú")
*   [Renovación](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion "Ancla menú")
*   [Resultados](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion "Ancla menú")
*   [Acreditaciones](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion "Ancla menú")

## ¿Qué es la Autoevaluación?​

​​Avanzamos en los primeros pasos​ de nuestra Autoevaluación con miras a la renovación de la Acreditación Institucional, u​n proceso que nos da la oportunidad de aprender y mejorar como Universidad a través de la evaluación de 12 factores institucionales, académicos, investigativos y otros que evidencian nuestro impacto en la sociedad.

## Divulgación de los resultados

###### ​​​​Seguimos avanzando en el proceso de Acreditación Institucional

Ya terminó la Autoevaluación con miras a la renovación de la Acreditación Institucional. Así mismo, durante el primer semestre de 2024, el equipo de Calidad Académica comenzó la consolidación del informe que la Universidad entregará al Ministerio de Educación Nacional. Y para seguir recordando nuestro compromiso con la alta calidad, comenzaremos a socializar en la Intranet Entrenos cómo nos fue en este proceso.​​​

Pero primero, un espacio para reflexionar sobre el camino recorrido, para agradecer la participación de todos, y para recordar que aún tenemos una responsabilidad con esta tarea, que nos convoca a todos los eafitenses en torno a un propósito común: reconocernos como integrantes de este proyecto educativo y aportar a la renovación de nuestro máximo aval de calidad. Esa es la invitación que nos hacen Claudia Restrepo, rectora de EAFIT, y Paola Podestá, vicerrectora de Aprendizaje.

Logros y aprendizajes

![Image 22: Imagen Identidad Institucional](https://universidadeafit.widen.net/content/daf58bc3-a62a-49fa-9fd7-dcdb3f6d5673/web/banner-autoevaluacion-factor1-identidadinstitucional.png?crop=yes&k=c&w=397&h=253&itok=n1kXq_mM)

Identidad Institucional

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/logros-aprendizajes-de-la-acreditacion-factor1-identidad-institucional)

![Image 23: Imagen Gobierno institucional y transparencia](https://universidadeafit.widen.net/content/010a2ffd-49c8-4bb9-b692-468bf43baf44/web/sin%20t%C3%ADtulo-09254.jpg?crop=yes&k=c&w=397&h=253&itok=hhGi_83w)

Gobierno institucional y transparencia

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/logros-aprendizajes-de-la-autoevaluacion?elqTrackId=44097C3B3DBEA35A2A59C8AE691BBA56&elqTrack=true)

![Image 24: Imagen Desarrollo, gestión y sostenibilidad institucional](https://universidadeafit.widen.net/content/1c34c51b-c31f-4c63-836a-b1417eedff18/web/desarrollo-y-gestion.png?crop=yes&k=c&w=397&h=253&itok=wS96lCRL)

Desarrollo, gestión y sostenibilidad institucional

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/estos-son-nuestros-logros-y-aprendizajes-en-la-autoevaluacion-desarrollo-gestion-sostenigilidad-financiera?elqTrackId=1F04F62A4978B6CCD6ED5E284CA16C90&elqTrack=true)

![Image 25: Imagen Repasemos los 12 factores de la Autoevaluación Institucional](https://universidadeafit.widen.net/content/9b604621-3f62-4cab-a2e6-c1f228e972da/web/mejoramientocontinuo.jpg?crop=yes&k=c&w=397&h=253&itok=XcKRxRbp)

Mejoramiento Continuo y Autorregulación

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/mejoramientocontinuo?elqTrackId=36F7C7E8AF49D15C49A65F5BA5C6B9AE&elqTrack=true)

![Image 26: Imagen Estructura y procesos académicos](https://universidadeafit.widen.net/content/06cd3c23-85fa-40c5-a44e-ee5901986b49/web/estructura-y-procesos-academicos2.jpg?crop=yes&k=c&w=397&h=253&itok=H8li9Lbo)

Estructura y procesos académicos

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/logros-aprendizajes-de-la-autoevaluacion-estructura-procesos-academicos)

![Image 27: Imagen Investigación, la innovación, el desarrollo tecnológico y la creación al entorno](https://universidadeafit.widen.net/content/6484bcab-62f6-48e2-8a20-693bd5467366/web/aportes-en-ctei.jpg?crop=yes&k=c&w=397&h=253&itok=U_SKEOCw)

Investigación, la innovación, el desarrollo tecnológico y la creación al entorno

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/logros-aprendizajes-de-la-autoevaluacion-ctei)

![Image 28: Imagen Impacto social](https://universidadeafit.widen.net/content/47ada70d-049e-483c-9a64-b49a42745e49/web/impacto-social.jpg?crop=yes&k=c&w=397&h=253&itok=M_Q3NYiB)

Impacto social

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/nuestros-logros-aprendizajes-autoevaluacion-proyeccion-social)

![Image 29: Imagen Visibilidad Nacional e Internacional](https://universidadeafit.widen.net/content/e3576fdd-c307-48f0-999e-6dac36079c6a/web/interancional.jpg?crop=yes&k=c&w=397&h=253&itok=2LZpjwc-)

Visibilidad Nacional e Internacional

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/estos-son-nuestros-logros-y-aprendizajes-en-la-autoevaluacion-visibilidad-nacional-e-internacional)

![Image 30: Imagen Bienestar](https://universidadeafit.widen.net/content/40969d17-4188-46bd-9a18-614a5a13909f/web/Espacios-aprendizaje-LabFotointerpretacion-16.jpg?crop=yes&k=c&w=397&h=253&itok=5HL5amwN)

Bienestar

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/estos-son-nuestros-logros-y-aprendizajes-en-la-autoevaluacion-bienestar-institucional)

![Image 31: Imagen Conexión con profesores](https://universidadeafit.widen.net/content/749ebd2e-5789-4d13-b997-1b5700e637d7/web/profes-espacios.jpeg?crop=yes&k=c&w=397&h=253&itok=yWn-6JFb)

Conexión con profesores

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/estos-son-nuestros-logros-y-aprendizajes-en-la-autoevaluacion-comunidad-profesores)

![Image 32: Imagen Conexión con estudiantes](https://universidadeafit.widen.net/content/f1c09dba-6411-4b6b-b43c-11ebc9c92261/web/iduccion-pregrado-00905.jpg?crop=yes&k=c&w=397&h=253&itok=NAGk0vwb)

Conexión con estudiantes

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/estos-son-nuestros-logros-y-aprendizajes-en-la-autoevaluacion-comunidad-estutiantes)

![Image 33: Imagen Conexión con graduados](https://universidadeafit.widen.net/content/61c44160-4158-46f8-ae04-4fdd7b4b22e9/web/autoevaluacion-comunidadgraduados.jpg?crop=yes&k=c&w=397&h=253&itok=6L_JMegL)

Conexión con graduados

[Conoce nuestros logros y aprendizajes](https://www.eafit.edu.co/institucional/acreditacion/estos-son-nuestros-logros-y-aprendizajes-en-la-autoevaluacion-comunidad-graduados)

Lo que debes saber

![Image 34: Imagen Avanzamos, seguimos aprendiendo y tenemos la mirada puesta en la Acreditación Institucional 2026.](https://universidadeafit.widen.net/content/3138b56b-c26f-4a12-859a-d28cbd09260d/web/Lab.Fotointerpretaci%C3%B3n%20Geoog%C3%ADa-Profe%20Paniagua-02662.jpg?crop=yes&k=c&w=397&h=253&itok=73zmfSYG)

Avanzamos, seguimos aprendiendo y tenemos la mirada puesta en la Acreditación Institucional 2026.

[Conoce más](https://www.eafit.edu.co/avanzamos-seguimos-aprendiendo-y-tenemos-la-mirada-puesta-en-la-acreditacion-insti-tucion-al-2026)

![Image 35: Imagen Todos trabajamos en el mismo proyecto:  la Acreditación Institucional de Alta Calidad](https://universidadeafit.widen.net/content/b358dc4a-5ec4-406d-b281-50f273e7304e/web/Simulacro%205.JPG?crop=yes&k=c&w=397&h=253&itok=SD7R--33)

Todos trabajamos en el mismo proyecto: la Acreditación Institucional de Alta Calidad

[Lee la nota](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion/todos-trabajamos-el-mismo-proyecto-acreditacion-intitucional-alta-calidad)

![Image 36: Imagen Todo lo que, como eafitenses, necesitamos saber para la visita de los pares evaluadores](https://universidadeafit.widen.net/content/ec3d115f-e39d-4377-932f-beb837241c59/web/foto-futuro.jpg?crop=yes&k=c&w=397&h=253&itok=iz6KO6gh)

Todo lo que, como eafitenses, necesitamos saber para la visita de los pares evaluadores

[Lee la nota](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion/necesitas-saber-para-visita-pares-evaluadores)

![Image 37: Imagen Repasemos los 12 factores de la Autoevaluación Institucional](https://universidadeafit.widen.net/content/9b604621-3f62-4cab-a2e6-c1f228e972da/web/mejoramientocontinuo.jpg?crop=yes&k=c&w=397&h=253&itok=XcKRxRbp)

Repasemos los 12 factores de la Autoevaluación Institucional

[Conoce más](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion/repasemos-factores-autoevaluacion-institucional)

## ¿Qué evaluamos?

Los lineamientos de acreditación en alta calidad de instituciones y de programas académicos se componen de factores, características y aspectos a evaluar, los cuales se define​n así:

Evalúa la apropiación y coherencia de nuestro quehacer universitario con los siguientes elementos: Declaraciones Institucionales. Proyecto Educativo Institucional (PEI). Valores.

#### Factor 1. Identidad Institucional

Reconoce a EAFIT como institución de alta calidad, que tiene un gobierno que se adapta a las nuevas realidades a través de un sistema de normas, reglamentos, políticas, decisiones, estructuras y procesos.

#### Factor 2. Gobierno institucional y transparencia

Asegura una arquitectura institucional articulada al servicio del desarrollo permanente de sus labores formativas, académicas, docentes, científicas, culturales y de extensión.

#### Factor 3. Desarrollo, gestión y sostenibilidad institucional

Demuestra la capacidad de EAFIT para planear su desarrollo y autoevaluarse de manera sistemática y periódica, generando estrategias y retos que impacten las decisiones institucionales en todos sus niveles y ámbitos de influencia, generando un constante aprendizaje organizacional.

#### Factor 04. Mejoramiento continuo y autorregulación

Garantiza la efectividad e integridad de la articulación entre las políticas, procesos, y procedimientos institucionales orientados a la gestión de los componentes formativos, pedagógicos, de evaluación, de interacción y de relación social.

#### Factor 5. Estructura y procesos académicos

Reconoce la efectividad en los procesos de formación para la investigación, el espíritu crítico y la creación, y por los aportes al conocimiento científico, el desarrollo tecnológico, la innovación, la transferencia y el desarrollo cultural, en todo su ámbito de influencia.

#### Factor 6. Aportes de la investigación, la innovación, el desarrollo tecnológico y la creación al entorno

Demuestra el compromiso con el entorno donde EAFIT hace presencia, por medio de programas académicos y la ejecución de sus labores formativas, académicas, docentes, científicas, culturales y de extensión.

#### Factor 07. Impacto social

Evidencia el reconocimiento y capacidades para acceder a recursos y saberes a nivel nacional e internacional, que permiten la comunicación intercultural y el análisis comparativo de sus procesos académicos.

#### Factor 08. Visibilidad nacional e internacional

Asegura que se disponen de mecanismos e instrumentos para buscar el desarrollo humano, el mejoramiento de la calidad de vida de las personas y del grupo institucional (estudiantes, profesores y personal administrativo) y la cohesión como comunidad académica.

#### Factor 09. Bienestar institucional

Asegura que se promueva la consolidación de una comunidad de profesores caracterizada por su diversidad, compromiso y participación para el logro de la misión institucional.

#### Factor 10. Comunidad de profesores

Demuestra que EAFIT reconoce los derechos y deberes de sus estudiantes, al aplicar las normas establecidas para tal fin, respetar y promover su participación en los órganos de gobierno y garantizar su ingreso y permanencia en el marco de políticas de equidad e inclusión que ofrezcan condiciones para la graduación.

#### Factor 11. Comunidad de estudiantes

Demuestra que EAFIT cuenta con programas y mecanismos de acompañamiento a sus egresados, con el propósito de favorecer el ejercicio profesional y la inserción laboral de los mismos, el aprendizaje continuo y el retorno curricular desde su experiencia hacia los programas académicos, apoyándose en sistemas de información adecuados.

#### Factor 12. Comunidad de egresados

## Hacia la renovación de nuestra acreditación institucional

## Registro fotográfico de las etapas del proyecto de autoevaluación

[Evento inicio Autoevaluación Institucional](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#230548828-4010152672)

###### Evento inicio Autoevaluación Institucional

![Image 38: Imagen ](https://universidadeafit.widen.net/content/12b702a9-7ef7-4614-9b4b-a002405b1d32/web/0.1.jpg?crop=yes&k=c&w=397&h=253&itok=S3qApoHz)

![Image 39: Imagen ](https://universidadeafit.widen.net/content/5e35fba1-7fd9-4d52-a3ee-82b098674038/web/0.3.jpg?crop=yes&k=c&w=397&h=253&itok=m74l_F4p)

![Image 40: Imagen ](https://universidadeafit.widen.net/content/538a1a36-1d7b-411b-8bb8-b038b2d5ad8f/web/0.2.jpg?crop=yes&k=c&w=397&h=253&itok=QucZ_fja)

[Desayunos mesas de trabajo](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#230548828-1933408950)

###### Desayunos mesas de trabajo

![Image 41: Imagen ](https://universidadeafit.widen.net/content/69bc3e8a-9c54-4820-923e-f9e0ad96e403/web/Desayuno%20Factor%201.jpeg?crop=yes&k=c&w=397&h=253&itok=2Uxmda1A)

![Image 42: Imagen ](https://universidadeafit.widen.net/content/5c61a854-1714-4c5a-b0d7-94da76003a03/web/Desayuno%20F10%20edited.png?crop=yes&k=c&w=397&h=253&itok=pI0_Rtl1)

![Image 43: Imagen ](https://universidadeafit.widen.net/content/a9cacd41-05f0-4307-99d2-eeda23303602/web/Desayuno%20Factor%209.JPG?crop=yes&k=c&w=397&h=253&itok=fvmR9pU5)

![Image 44: Imagen ](https://universidadeafit.widen.net/content/dcc27cdc-b55d-4b00-ba04-24fc15d4ea69/web/_DSC1974.JPG?crop=yes&k=c&w=397&h=253&itok=absE2Cgp)

![Image 45: Imagen ](https://universidadeafit.widen.net/content/4b78afbb-1a84-453d-9740-772b6ef6bb0a/web/Desayuno%20Factor%207.JPG?crop=yes&k=c&w=397&h=253&itok=EPNs25el)

![Image 46: Imagen ](https://universidadeafit.widen.net/content/0152df4a-4d33-49f1-a0d8-ecfe1fb5de24/web/Desayuno%20Factor%2012.jpeg?crop=yes&k=c&w=397&h=253&itok=ExVaVgDU)

![Image 47: Imagen ](https://universidadeafit.widen.net/content/dccc1377-82eb-4217-8dc2-7fb69d28ff68/web/Desayuno%20Factor%202.jpeg?crop=yes&k=c&w=397&h=253&itok=-fC6WXoQ)

![Image 48: Imagen ](https://universidadeafit.widen.net/content/bd78e5df-da78-45d1-9db1-a210947c64f8/web/Desayuno%20Factor%203.png?crop=yes&k=c&w=397&h=253&itok=RVGsyo4F)

![Image 49: Imagen ](https://universidadeafit.widen.net/content/d536fef7-4028-4080-a1d0-6cf588287630/web/Desayuno%20Factor%206.JPG?crop=yes&k=c&w=397&h=253&itok=gSEJCbrR)

![Image 50: Imagen ](https://universidadeafit.widen.net/content/0152f23b-9fb7-4664-a377-b0923f15e732/web/_DSC2287.JPG?crop=yes&k=c&w=397&h=253&itok=yF7WNng_)

![Image 51: Imagen ](https://universidadeafit.widen.net/content/060be0fb-87c9-4793-ae45-d630ac6a0a5c/web/_DSC2175.JPG?crop=yes&k=c&w=397&h=253&itok=IFJUToQh)

![Image 52: Imagen ](https://universidadeafit.widen.net/content/244dbae6-e6df-4c62-9fcf-4e9a5793aa04/web/Desayuno%20Factor%2011.JPG?crop=yes&k=c&w=397&h=253&itok=NXx34hM9)

![Image 53: Imagen ](https://universidadeafit.widen.net/content/f5bf8656-270c-482e-8d1f-827a91df2159/web/_DSC2237.JPG?crop=yes&k=c&w=397&h=253&itok=3E5fAoOp)

![Image 54: Imagen ](https://universidadeafit.widen.net/content/c4605dc3-c866-4fb4-ae09-8a64d9c65d09/web/_DSC1366.JPG?crop=yes&k=c&w=397&h=253&itok=J1H_x4dm)

![Image 55: Imagen ](https://universidadeafit.widen.net/content/93605f88-9e01-4222-b8e4-e630891e4b5f/web/Desayuno%20Factor%205.JPG?crop=yes&k=c&w=397&h=253&itok=z7H1JB7q)

![Image 56: Imagen ](https://universidadeafit.widen.net/content/6b794ade-d36c-488e-a89d-a73de4bcbff5/web/Desayuno%20Factor%208.JPG?crop=yes&k=c&w=397&h=253&itok=0vj8q5NJ)

[Desarrollo grupos focales](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#230548828-1168351625)

###### Desarrollo grupos focales

![Image 57: Imagen ](https://universidadeafit.widen.net/content/bc17f6f2-860a-48c5-82f1-62315a2ecf9c/web/Grupo%20Focal%20-%20Comite%CC%81%20Rectoral.jpg?crop=yes&k=c&w=397&h=253&itok=llTjccTB)

![Image 58: Imagen Resultados de la autoevaluación Institucional](https://universidadeafit.widen.net/content/0c1079b8-bc78-405c-8c8b-8f6a00623351/web/Grupo%20Focal%20-%20Sector%20Pu%CC%81blico.jpg?crop=yes&k=c&w=397&h=253&itok=qLg88CjB)

![Image 59: Imagen ](https://universidadeafit.widen.net/content/6b1ee2e2-47c3-4f1e-9230-5e0ac6c76a3f/web/Grupo%20Focal%20-%20Sector%20Privado.jpg?crop=yes&k=c&w=397&h=253&itok=Syg2fowy)

![Image 60: Imagen ](https://universidadeafit.widen.net/content/87b24fba-9992-43d0-b746-922dd19eaa65/web/Grupo%20Focal%20-%20Sector%20Privado%20(2).jpg?crop=yes&k=c&w=397&h=253&itok=kTd7fNMX)

![Image 61: Imagen ](https://universidadeafit.widen.net/content/87b24fba-9992-43d0-b746-922dd19eaa65/web/Grupo%20Focal%20-%20Sector%20Privado%20(2).jpg?crop=yes&k=c&w=397&h=253&itok=kTd7fNMX)

![Image 62: Imagen ](https://universidadeafit.widen.net/content/a38a22c2-6e2f-41e5-894a-c3f0cdef4f64/web/Grupo%20Focal%20-%20Sector%20Pu%CC%81blico%20(1).jpg?crop=yes&k=c&w=397&h=253&itok=3CJUSLoN)

[Socialización en Comité de Autoevaluación Institucional](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#230548828-55592779)

###### Socialización en Comité de Autoevaluación Institucional

![Image 63: Imagen ](https://universidadeafit.widen.net/content/5cb9f370-6882-4346-a911-e546678990f2/web/_DSC2773.JPG?crop=yes&k=c&w=397&h=253&itok=nmO5H8XN)

![Image 64: Imagen ](https://universidadeafit.widen.net/content/c4036b0c-e816-46fc-a9d9-0cf66f4714b1/web/_DSC0726.jpg?crop=yes&k=c&w=397&h=253&itok=nKs1JzBD)

![Image 65: Imagen ](https://universidadeafit.widen.net/content/8d7635d0-7091-49c5-87a8-eda64f2ad618/web/_DSC0711.jpg?crop=yes&k=c&w=397&h=253&itok=wNEIbhyu)

![Image 66: Imagen ](https://universidadeafit.widen.net/content/543e582a-2d97-4ef1-9a30-c9d63b00ad2b/web/_DSC0671.jpg?crop=yes&k=c&w=397&h=253&itok=A55Ad3CF)

[Presentación del balance del Itinerario y resultados de Autoevaluación Institucional](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#230548828-2355756414)

###### Presentación del balance del Itinerario y resultados de Autoevaluación Institucional

![Image 67: Imagen ](https://universidadeafit.widen.net/content/c9f39293-6d99-4f6f-ae80-fa1b60f80d26/web/Presentacio%CC%81n%20balance%203.JPG?crop=yes&k=c&w=397&h=253&itok=tOpAjona)

![Image 68: Imagen ​Síntesis del informe de Autoevaluación Institucional 2024​](https://universidadeafit.widen.net/content/c57188e9-aec7-4258-b2c7-da53a59b7755/web/Presentacio%CC%81n%20balance%201.JPG?crop=yes&k=c&w=397&h=253&itok=rsjPgXrS)

![Image 69: Imagen ](https://universidadeafit.widen.net/content/d231cece-1b88-4d02-bb3e-cc0e159a9dbf/web/Presentacio%CC%81n%20balance%204.JPG?crop=yes&k=c&w=397&h=253&itok=qhcgAFsM)

![Image 70: Imagen ](https://universidadeafit.widen.net/content/732186bc-4dfc-4933-9699-65a24c0fa9bd/web/Presentacio%CC%81n%20balance%202.JPG?crop=yes&k=c&w=397&h=253&itok=lErn02Hx)

[Simulacro de pares amigosAutoevaluación](https://www.eafit.edu.co/institucional/acreditacion/autoevaluacion#230548828-759751018)

###### Simulacro de pares amigosAutoevaluación

![Image 71: Imagen ](https://universidadeafit.widen.net/content/054f3cab-28be-4b6c-acf4-6204dbcb6a68/web/Simulacro%204.JPG?crop=yes&k=c&w=397&h=253&itok=7hFWaVIM)

![Image 72: Imagen ](https://universidadeafit.widen.net/content/7dc1c980-9291-4b5f-bfa0-c190d0fa34ba/web/Simulacro%206.JPG?crop=yes&k=c&w=397&h=253&itok=AhFj2z6B)

![Image 73: Imagen ](https://universidadeafit.widen.net/content/a4775e28-55cc-4a6f-82ea-52f2dd1ad87c/web/Simulacro%202.JPG?crop=yes&k=c&w=397&h=253&itok=qy6NDmbu)

![Image 74: Imagen ](https://universidadeafit.widen.net/content/1a83e838-b557-4ca6-b213-a56447b708fa/web/Simulacro%203.JPG?crop=yes&k=c&w=397&h=253&itok=c91zM9-O)

![Image 75: Imagen ](https://universidadeafit.widen.net/content/8bba75e8-98b2-4f8d-a7f5-bb696de0c100/web/Simulacro%201.JPG?crop=yes&k=c&w=397&h=253&itok=ZZ1fWKII)

![Image 76: Imagen ](https://universidadeafit.widen.net/content/8bba75e8-98b2-4f8d-a7f5-bb696de0c100/web/Simulacro%201.JPG?crop=yes&k=c&w=397&h=253&itok=ZZ1fWKII)

## Resultados de nuestra autoevaluación institucional

##### Informe Autoevaluación Institucional - EAFIT 2025​​​​

[Ver el informe](https://universidadeafit.widen.net/s/r6hzwxlxjs/informe-autoevaluacion-institucional-eafit-2025)

![Image 77: Imagen Balance 2017​ - 2024](https://universidadeafit.widen.net/content/083951d5-43b9-4578-b7e7-3bd1ceba6199/web/Foto-estudiantesRegresoclases-021.jpg?crop=yes&k=c&w=397&h=253&itok=lWlgd19j)

Balance 2017​ - 2024

[Ver archivo](https://universidadeafit.widen.net/s/htr59zpwvk/balance-itinerario-2017-2024)

![Image 78: Imagen ​Síntesis del informe de Autoevaluación Institucional 2024​](https://universidadeafit.widen.net/content/c57188e9-aec7-4258-b2c7-da53a59b7755/web/Presentacio%CC%81n%20balance%201.JPG?crop=yes&k=c&w=397&h=253&itok=rsjPgXrS)

​Síntesis del informe de Autoevaluación Institucional 2024​

[Ver archivo](https://universidadeafit.widen.net/s/sqdm2bgld5/cartilla)

![Image 79: Imagen Resultados de la autoevaluación Institucional](https://universidadeafit.widen.net/content/0c1079b8-bc78-405c-8c8b-8f6a00623351/web/Grupo%20Focal%20-%20Sector%20Pu%CC%81blico.jpg?crop=yes&k=c&w=397&h=253&itok=qLg88CjB)

Resultados de la autoevaluación Institucional

[Ingresa aquí](https://universidadeafit.widen.net/s/8dxzqtmmjz/infografia-autoevalaucioninstitucional)

La Autoevaluación Institucional es un compromiso y una reflexión periódica sobre nuestros ejes misionales, que nos brinda oportunidades de aprendizaje permanente para reconocernos como una comunidad de conocimientos y saberes aplicados.​

![Image 80: Imagen Nuestras acreditaciones:](https://universidadeafit.widen.net/content/8c64b5e2-0e66-45b8-8a18-3d463e6b6f1d/web/acreditacion-eafit-institucional.jpg?h=480&itok=W-ncRc0x)

## Nuestras acreditaciones:

​Entre 1994 y 2020 se han adelantado cuatro procesos de Autoevaluación y más de 50 autoevaluaciones de programas. El primer proceso que transitamos como Institución fue previo a la consolidación del Sistema Nacional de Acreditación, y se realizó entre 1994 y 1995. De manera posterior, en 2002, 2008 y 2016, adelantamos tres autoevaluaciones con fines de Acreditación Institucional bajo los lineamientos del Consejo Nacional de Acreditación (CNA). 

 Para la Universidad EAFIT estos procesos son indispensables, pues han permitido la formulación de reformas curriculares, la creación de nuevas Escuelas, el reconocimiento de la alta calidad de los programas académicos y de la Institución misma y especialmente, el fortalecimiento de una cultura de autoevaluación y autorregulación a través del análisis periódico de sus funciones sustantivas, que derivan en planes de mejoramiento que permiten asegurar la transformación constante de la Institución. ​​​

[Conócelas](https://www.eafit.edu.co/institucional/acreditacion/acreditacion-institucional)

![Image 81: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 82: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 83: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 84: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 85: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 86: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 87: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 88: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)

![Image 89](https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg)

Original text

Rate this translation

Your feedback will be used to help improve Google Translate
