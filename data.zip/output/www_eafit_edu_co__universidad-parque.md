Title: Universidad Parque

URL Source: https://www.eafit.edu.co/universidad-parque

Markdown Content:
# Universidad Parque - Universidad EAFIT
[Pasar al contenido principal](https://www.eafit.edu.co/universidad-parque#main-content)

[![Image 1: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 2: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/universidad-parque#)

[![Image 3: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/universidad-parque# "Spanish")[![Image 4: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/universidad-parque# "English")

*   [Spanish](https://www.eafit.edu.co/universidad-parque)
*   [Inglés](https://www.eafit.edu.co/en/universidad-parque)

 Información para ti

[![Image 5: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 6: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 7: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 8: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 9: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 10: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Buscar 

Búsqueda

Menú

Información para ti

[![Image 11: Inicio](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/institucional/pei)
    *   [Vida en el campus](https://www.eafit.edu.co/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/nuestras-sedes)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/sostenibilidad-ambiental)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/registro-academico)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion)
    *   [Cultura CTeI](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/cultura-ciencia-tecnologia-innovacion)
    *   [Formación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/formacionctei)
    *   [Universidad de los Niños](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/innovacion-desarrollo-tecnologico/proyectos-ctei)
    *   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/organizaciones)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/ongoing)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/centros-estudio-incidencia)
    *   [Transforma con nosotros](https://www.eafit.edu.co/filantropia)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-en-el-exterior)
    *   [Intercambios nacionales](https://www.eafit.edu.co/internacionalizacion/intercambio-academico-nacional)
    *   [Convenios](https://www.eafit.edu.co/internacionalizacion/convenios)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/practicas-en-el-exterior)
    *   [Misiones internacionales](https://www.eafit.edu.co/internacionalizacion/misiones-en-eafit-programas-cortos-de-intercambio)
    *   [Aprendizaje global](https://www.eafit.edu.co/internacionalizacion/aprendizaje-global)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/vida-cultural)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/orquesta-sinfonica-eafit)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/editorial)
    *   [Centro de artes](https://www.eafit.edu.co/centro-de-artes)
    *   [Sala patrimonial](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas/patrimonio-y-cultura)
    *   [Bienestar universitario](https://www.eafit.edu.co/bienestar-universitario)
    *   [Salud mental](https://www.eafit.edu.co/bienestar-universitario/salud-mental)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/noticias)
    *   [Sala de prensa](https://www.eafit.edu.co/noticias/sala-de-prensa)
    *   [Agenda y eventos](https://www.eafit.edu.co/calendario-eventos)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 12: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 13: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 14: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 15: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 16: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 17: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 18: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 19: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 20: Imagen de banner la ceiba ](https://universidadeafit.widen.net/content/36a7112f-723b-4c8d-8a45-a0d0757b2d85/web/la-ceiba.jpg?crop=yes&k=c&w=1920&h=788&itok=726rdddw)

# Universidad Parque

Un plan maestro vivo para un campus que invita a ​aprender, crear, conectar... ​respirar​​​

*   [Inicio](https://www.eafit.edu.co/)
*    Universidad Parque 

Creamos escenarios donde convergen las preguntas, la cultura, la ciencia, el juego y la vida; en los que se promueven encuentros y se renuevan conexiones.

Generamos hábitats más sostenibles donde es posible estar cerca del agua y ser uno con la naturaleza; en los que el conocimiento permea los rincones e invita a la creación, la innovación y al trabajo colaborativo.

Construimos espacios en los que la tecnología expande los límites de la Universidad y amplifica la experiencia; en los que las oportunidades crece​n y los saberes llegan a más personas.

Propiciamos experiencias memorables que promueven el mutuo cuidado; donde se incentivan hábitos sostenibles y se crean condiciones para un mayor equilibrio mental.En nuestro campus creamos soluciones y regalamos naturaleza y oportunidades. Somos una comunidad de saberes y conocimientos que resuelven problemas, espacios que transforman.

#### ​​​Nuestros ​​principios

## Actúa sosten​​ible

La Universidad conoce y se conecta con el planeta y la naturaleza. Crea espacios de educación para el desarrollo sostenible, promueve la regeneración de ecosistemas y aporta a la cultura de la responsabilidad y del buen vivir. En EAFIT, el paisaje y la infraestructura se transforman en pro de la sostenibilidad.

## Teje con el t​erritorio

La Univers​idad reconoce el territorio en el que se emplaza y asume una vocación de servicio social y cultural con este. Propicia el diálogo y la creación con vecinos, con actores sociales, con emprendedores, académicos y con las organizaciones de la región. En EAFIT se crean espacios para el encuentro de ideas, proyectos, miradas, géneros y generaciones.

## Crea colectiva​mente

La Universidad promueve el aprendizaje colaborativo y por proyectos. Consolida escenarios para la cualificación de las preguntas, el desarrollo de habilidades para la investigación y la resolución de problemas a través de retos. En EAFIT suceden y se intencionan, con las infraestructuras y decisiones de usos de espacios, encuentros entre conocimientos y disciplinas. Se hacen visibles las creaciones y procesos de diversidad de comunidades y personas.

## Cuida y abra​​za

La Universidad es un espacio de bienestar que promueve el mutuo cuidado. Es un campus vivo y activo cuyos escenarios invitan a la adopción o consolidación de hábitos saludables de vida. Se promueve la generación de vínculos e interacciones entre las personas, la sana alimentación, el encuentro con la naturaleza y el disfrute del tiempo de ocio. EAFIT es un dispositivo de bienestar que contribuye al florecimiento de su comunidad y, con esta, de sus familias y la sociedad.

## Conecta e inn​​ova

La Universidad es tecnología al servicio del aprendizaje, la investigación, la creación y la solución de problemas. Alberga, difunde y crea conocimiento con múltiples medios y plataformas. Con dispositivos, escenarios y formas de habitar los espacios se propicia el entendimiento de fenómenos de la naturaleza y de los comportamientos humanos para la solución de problemáticas sociales, culturales y medioambientales. Además, con la tecnología como herramienta, se gestionan los espacios, procesos e infraestructuras del campus. En EAFIT se generan interacciones y encuentros en diversos medios y formatos. Se complementan y desarrollan saberes desde la vivencia de un ecosistema de innovación.

### **Las palabras ​de la c​risis**

Un diccionario para conversar, sin miedo, sobre el cambio climático.​

[Descarga el diccionario completo](https://universidadeafit.widen.net/s/ldgkhdnbbg/diccionario-naturaleza)

### **​​Nuestros parques**

[![Image 21](https://universidadeafit.widen.net/content/652af366-ac34-447b-9c7c-9910c6e84836/web/parque-cti2.jpg)](https://www.eafit.edu.co/universidad-parque)

![Image 22](https://www.eafit.edu.co/universidad-parque)

###### Un parque t​ecnológico:

Corazón de la ciencia, la tecnología y la innov​ación​

Este proyecto estratégico tiene como objetivo fortalecer el ecosistema de ciencia, la tecnología y la innovación de​ la universidad mediante la integración de los bloques Argos y 18 a las nuevas dinámicas que aportará el bloque 20 cuando se inaugure. Esta integración se plantea a partir de la transformación de los primeros pisos, la articulación de los edificios desde los jardines y el espacio público, la configuración de espacios y paseos emblemáticos para la apropiación y encuentro de la comunidad universitaria y la creación de una agenda de actividade​s y retos que la vincule a este proceso de transformación.

Si bien los procesos de ciencia, tecnología e innovación suceden en varias partes de la universidad se busca potenciar, en el centro geográfico y de cruce de caminos del campus, el espacio para vivirlo de manera más intensa y conectar desde allí por medio de experiencias interactivas.

Este proyecto estratégico articula y potencia la intervención del Bloque 20 con la inclusión de dos piezas fundamentales para contar la historia del corazón de la ciencia, la tecnología y la innovación en la Universidad: el Centro Argos y el Bloque 18.

[![Image 23](https://universidadeafit.widen.net/content/6dc3d5e1-0f1b-44fa-be80-bb51637365a9/web/la-volcana2.jpg?crop=yes&k=c&w=1024&h=788&itok=nNup3Pdr)](https://www.eafit.edu.co/universidad-parque)

![Image 24](https://www.eafit.edu.co/universidad-parque)

###### Un parque para la cultura:

El encuentro con otros y con la naturaleza

Quebrada La Volca​​na: laboratorio vivo del agua, la biodiversidad y la cultura.

Este proyecto estratégico tiene como objetivo conectar la universidad y la ciudad a través del corredor ecológico de la Quebrada La Volcana, entre el río Medellín y la avenida El Poblado. Este se convertirá en un laboratorio vivo donde convergerán los saberes ambientales: un espacio para el cuidado y para seguir fortaleciendo la cultura en el campus.

El aumento en la frecuencia e intensidad de los fenómenos climáticos extremos, producto de la variación en las condiciones atmosféricas, ha desencadenado la ocurrencia de inundaciones y avenidas torrenciales que afectan los cauces y cuencas en su conjunto. El campus no es ajeno a esta dinámica que ha afectado en varias ocasiones las actividades. Por ello, se busca definir la quebrada como un proyecto estratégico que integre procesos de anticipación de estos fenómenos, enriquezca la exploración de soluciones híbridas y sea un espacio abierto y demostrativo para otras cuencas de la ciudad.

Para esto se transformará el cauce actual acercando a la quebrada a su condición natural sinuosa y rodeada de ​áreas permeables, incorporando soluciones basadas en la naturaleza que permitan: ralentizar el flujo del agua, brindar una respuesta sensible al crecimiento del caudal y la posible inundación que genere el mismo, gestionar de manera sostenible el agua y devolver cualidades paisajísticas a este espacio del campus. En los alrededores de la quebrada se configurará un corredor sensible al agua y a la biodiversidad a lo largo del cual será posible experimentar, visibilizar e implementar diferentes estrategias de la cadena de gestión del agua para mejorar el balance hídrico, así como enriquecer y diversificar la vegetación para mejorar y aumentar la conectividad ecológica. Dichas intervenciones buscarán resiliencia, adaptación y mitigación frente a los efectos del cambio climático.

Adicionalmente, la configuración de este nuevo paisaje y su ubicación central en la universidad, cercana a los principales espacios de encuentro, permitirán hacer de este lugar un verdadero parque, donde se integren los costados norte y sur del campus. Los jardines superarán las funciones ornamentales y la comunidad universitaria encontrará espacios para el goce, la conversación, el aprendizaje y el muto cuidado.

[![Image 25](https://universidadeafit.widen.net/content/381124fe-dbc4-4f21-ab27-0e6b596ee4b3/web/parque-guayabos.jpg)](https://www.eafit.edu.co/universidad-parque)

![Image 26](https://www.eafit.edu.co/universidad-parque)

###### Parque Los Guayabos:

Un campus abierto a la ciudad, al cuidado y al emprendimiento de alto impacto

Este cuarto proyecto estratégico busca la consolidación del lote de Los Guayabos bajo un modelo de campus abierto con una oferta de múltiples servicios, tanto para la comunidad interna como externa. En este espacio se busca promover la creación de un ecosistema de emprendimiento de alto impacto en articulación con las organizaciones y con las actividades de aprendizaje de la Universidad. Adicionalmente, también se busca que este lugar acoja los espacios que configurarán la nueva área académica de Ciencias del Cuidado y de la Vida.

Estas acciones previstas para el predio de Los Guayabos también tienen como objetivo la creación de espacios públicos y semipúblicos con alta conectividad ecológica, así como la incorporación de principios de construcción sostenible y eficiencia energética en las edificaciones a construir.​

[![Image 27](https://universidadeafit.widen.net/content/9b477038-1553-4fd2-bac7-ba1761a98afd/web/aguacatala.jpg)](https://www.eafit.edu.co/universidad-parque)

![Image 28](https://www.eafit.edu.co/universidad-parque)

###### La Universidad Parque en el barrio:

La Aguacatala 2, un modelo de regeneració​n urbana en suelos de renovación

El quinto proyecto estratégico del Plan maestro tiene como objetivo modelar escenarios de renovación urbana para las unidades de actuación urbanística donde la Universidad tiene presencia con sus casas. Estos escenarios buscan trazar un horizonte de desarrollo que incluye alternativas en cuanto a la materialización de los usos permitidos, la configuración de una estructura pública ecológica y urbanamente funcional que conecte a la universidad con el barrio y al barrio con la ciudad y la implementación de criterios de sostenibilidad para la conformación de un eco-barrio que posibilite el aprendizaje y la experimentación.​

## Conoce más sobre el campus de EAFIT

[Conoce el campus](https://www.eafit.edu.co/campus-eafit)

![Image 29: Imagen Conoce más sobre el campus de EAFIT](https://universidadeafit.widen.net/content/a4e11f6e-fa26-476c-b59d-9014341c8950/web/Campus1.png)

![Image 30: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 31: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 32: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 33: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 34: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 35: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 36: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 37: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Nuestros pregrados](https://www.eafit.edu.co/pregrados)
*   [Nuestros posgrados](https://www.eafit.edu.co/posgrados)
*   [Otros programas](https://www.eafit.edu.co/otros-programas)
*   [Conoce nuestras tarifas](https://www.eafit.edu.co/tarifas)
*   [Biblioteca](https://www.eafit.edu.co/centro-cultural-biblioteca-luis-echavarria-villegas)

Conéctate con EAFIT

*   [Transformemos juntos](https://www.eafit.edu.co/filantropia)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/organizaciones)
*   [Trabaja con nosotros](https://www.eafit.edu.co/trabaja-con-nosotros)

Contáctanos

*   [Registra una PQRSF](https://www.eafit.edu.co/pqrsf)
*   [Atención al visitante](https://www.eafit.edu.co/centro-visitantes)
*   [Línea de transparencia](https://www.eafit.edu.co/linea-de-transparencia)

Información de ley

*   [Personería jurídica](https://www.eafit.edu.co/constitucion)
*   [Reglamentos y estatutos](https://www.eafit.edu.co/institucional/reglamentos/reglamentos)
*   [Gén​ero, Diversidad ​e Inclusión](https://www.eafit.edu.co/bienestar-universitario/genero-diversidad-e-inclusion)
*   [Notificaciones judiciales y certificados](https://www.eafit.edu.co/notificaciones-judiciales-y-certificados)
*   [Actualiza tus datos](https://www.eafit.edu.co/sigamos-en-contacto)
*   [Política de protección de datos](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)
*   [Términos de uso](https://www.eafit.edu.co/terminos-condiciones)

[Mapa del sitio](https://www.eafit.edu.co/mapa-del-sitio)

Universidad con Acreditación Institucional hasta 2026.

Vigilada Mineducación.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Nuestras sedes

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellín](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

Línea nacional: 01 8000 515 900

Línea de atención: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Línea de atención: (57) 606 3214115, 606 3214119

Correo electrónico: [eafit.pereira@eafit.edu.co](mailto:eafit.pereira@eafit.edu.co)

[EAFIT Bogotá](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Línea de atención: (57) 601 6114618

Correo electrónico: [eafit.bogota@eafit.edu.co](mailto:eafit.bogota@eafit.edu.co)

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego –Rionegro

Línea de atención: (57) 604 2619500​, ext. 9188

Correo electrónico: [llanogrande@eafit.edu.co](mailto:llanogrande@eafit.edu.co)
