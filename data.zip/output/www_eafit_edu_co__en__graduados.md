Title: Eafit graduates

URL Source: https://www.eafit.edu.co/en/graduados

Markdown Content:
# Eafit graduates - Universidad EAFIT
[Skip to main content](https://www.eafit.edu.co/en/graduados#main-content)

[![Image 4: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Accesibilidad

Más información Activar contraste Disminuir tamaño de letra Tamaño de letra estándar Aumentar tamaño de letra Habilitar o desactivar audio para usuarios con discapacidad visual

Mostrar el contenido con alto contraste para personas con discapacidad visual.

A- Reducir el tamaño de la letra.

A Restablecer el tamaño original de la letra.

A+ Aumentar el tamaño de la letra.

Habilitar el audio para usuarios con discapacidad visual u otras necesidades parecidas.

Atención al cliente en lengua de señas.

Configurar el idioma del sitio web.

Cerrar modal

Idioma

[![Image 5: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/graduados#)

[![Image 6: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)Spanish](https://www.eafit.edu.co/en/graduados# "Spanish")[![Image 7: English](https://www.eafit.edu.co/modules/contrib/g_translate/gtranslate-files/blank.png)English](https://www.eafit.edu.co/en/graduados# "English")

*   [Spanish](https://www.eafit.edu.co/graduados)
*   [Inglés](https://www.eafit.edu.co/en/graduados)

 Información para ti

[![Image 8: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

Descubre tu perfil en EAFIT

¿Eres estudiante, profesor, graduado o haces parte de una organización? Explora las opciones y encuentra la información personalizada que EAFIT tiene para ti. Haz clic en tu perfil y accede a recursos, noticias y eventos diseñados especialmente para ti. ¡Tu experiencia en EAFIT comienza aquí!

**¡Tu experiencia en EAFIT comienza aquí!**

Estudiantes y graduados

![Image 9: Imagen Estudiantes y graduados](https://universidadeafit.widen.net/content/f14ce09a-f792-40f6-8f10-20a182e3ed99/web/tienda-universitaria-eafit.jpg?crop=yes&k=c&w=448&h=300&itok=C6ClwVj8)

Empleados

[Iniciar sesión](https://entrenos.eafit.edu.co/ "Iniciar sesión")

![Image 10: Imagen Empleados](https://universidadeafit.widen.net/content/d4160989-8a24-40a6-865b-8023ce49bf24/web/empleados-eafit-medellin26.jpg?crop=yes&k=c&w=448&h=300&itok=3-3m6DjB)

Profesores

[Conoce más](https://www.eafit.edu.co/profes-que-inspiran "Conoce más")

![Image 11: Imagen Profesores](https://universidadeafit.widen.net/content/37c14ae4-4264-4e63-81fd-74367d47c69b/web/Posgrados-Maestria-en-comunicacion-politica-03.jpg?crop=yes&k=c&w=448&h=300&itok=FLFrew4Y)

Niños y jóvenes

[Conoce más](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/universidad-ninos "Conoce más")

![Image 12: Imagen Niños y jóvenes](https://universidadeafit.widen.net/content/6a6a5f91-4b0c-49d1-95f3-432ba98baea2/web/universidad-de-los%20Nin%CC%83os-nos-mueven-las-preguntas-el-asombro-y-la-curiosidad.jpg?crop=yes&k=c&w=448&h=300&itok=F79m8ujf)

Organizaciones

[Conoce más](https://www.eafit.edu.co/organizaciones "Conoce más")

![Image 13: Imagen Organizaciones](https://universidadeafit.widen.net/content/5895998e-9f82-4555-8e6e-8933924e7c83/web/cursos-para-empresas-educacion-continua.jpg?crop=yes&k=c&w=448&h=300&itok=1OGXR9jI)

Cerrar perfiles

Search 

Búsqueda

Menú

Información para ti

[![Image 14: Home](https://www.eafit.edu.co/sites/default/files/logo_EAFIT_negro.svg)](https://www.eafit.edu.co/en)

*   Así es EAFIT

Volver
    *   [Información Institucional](https://www.eafit.edu.co/en/institucional)
    *   [Así aprendemos en EAFIT](https://www.eafit.edu.co/en/node/42116)
    *   [Vida en el campus](https://www.eafit.edu.co/en/universidad-parque)
    *   [Escuelas y áreas académicas](https://www.eafit.edu.co/en/nuestras-escuelas)
    *   [Sedes](https://www.eafit.edu.co/en/node/45896)
    *   [Logros y excelencia académica](https://www.eafit.edu.co/en/institucional/acreditacion)
    *   [Sostenibilidad ambiental​](https://www.eafit.edu.co/en/node/45926)

*   Estudia en EAFIT

Volver
    *   [Pregrados](https://www.eafit.edu.co/en/pregrados)
    *   [Posgrados](https://www.eafit.edu.co/en/posgrados)
    *   [Educación continua](https://www.eafit.edu.co/en/otros-programas)
    *   [Idiomas](https://www.eafit.edu.co/en/idiomas)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Eventos, congresos y seminarios](https://www.eafit.edu.co/en/otros-programas/eventos)
    *   [Becas y financiación](https://www.eafit.edu.co/en/becas-y-financiacion)
    *   [Inscripción y matrícula](https://www.eafit.edu.co/en/registrars-office)

*   Ciencia, Tecnología e Innovación

Volver
    *   [Sistema CTel](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
    *   [Investigación](https://www.eafit.edu.co/sistema-ciencia-tecnologia-innovacion/investigacion)
    *   [Innovación, transferencia y tecnología](https://www.eafit.edu.co/en/node/31081)
    *   [Cultura CTeI](https://www.eafit.edu.co/en/node/31171)
    *   [Formación](https://www.eafit.edu.co/en/node/31201)
    *   [Universidad de los Niños](https://www.eafit.edu.co/en/node/30671)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Portafolio de proyectos](https://www.eafit.edu.co/en/node/39301)
    *   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

*   Conexión con las organizaciones

Volver
    *   [Conexiones y servicios](https://www.eafit.edu.co/en/node/30186)
    *   [Empresas](https://www.eafit.edu.co/empresas)
    *   [Sistemas públicos](https://www.eafit.edu.co/conexion-asuntos-publicos)
    *   [Emprendimientos / On.going](https://www.eafit.edu.co/en/node/29776)
    *   [Centro de tecnologías emergentes / Nodo](https://es.nodoeafit.com/)
    *   [Centros de estudio e incidencia](https://www.eafit.edu.co/en/node/16476)
    *   [Transforma con nosotros](https://www.eafit.edu.co/en/node/43361)
    *   [Rutas de talento y prácticas](https://www.eafit.edu.co/en/organizaciones/talento-eafit)
    *   [Graduados](https://www.eafit.edu.co/en/graduados)
    *   [Investigación y consultoría](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)

*   Internacionalización

Volver
    *   [Internacionalización en EAFIT](https://www.eafit.edu.co/en/internacionalizacion)
    *   [Intercambios internacionales](https://www.eafit.edu.co/en/node/1151)
    *   [Intercambios nacionales](https://www.eafit.edu.co/en/node/1146)
    *   [Convenios](https://www.eafit.edu.co/en/node/1111)
    *   [Prácticas en el exterior](https://www.eafit.edu.co/en/node/16436)
    *   [Misiones internacionales](https://www.eafit.edu.co/en/node/1136)
    *   [Aprendizaje global](https://www.eafit.edu.co/en/node/1131)

*   Cultura y Bienestar

Volver
    *   [Cultura](https://www.eafit.edu.co/en/node/45976)
    *   [Orquesta Sinfónica EAFIT](https://www.eafit.edu.co/en/node/43446)
    *   [Editorial EAFIT y librería](https://www.eafit.edu.co/en/node/47981)
    *   [Centro de artes](https://www.eafit.edu.co/en/node/47976)
    *   [Sala patrimonial](https://www.eafit.edu.co/en/node/39836)
    *   [Bienestar universitario](https://www.eafit.edu.co/en/bienestar)
    *   [Salud mental](https://www.eafit.edu.co/en/node/45826)
    *   [Género, diversidad e inclusión](https://www.eafit.edu.co/en/node/38366)

*   Noticias

Volver
    *   [Nuestras historias y noticias](https://www.eafit.edu.co/en/node/38196)
    *   [Sala de prensa](https://www.eafit.edu.co/en/node/38391)
    *   [Agenda y eventos](https://www.eafit.edu.co/en/node/18151)
    *   [Comunicados](https://www.eafit.edu.co/institucional/comunicados-institucionales/comunicados-2026)

[Transparencia y Acceso a Información Pública](https://www.eafit.edu.co/transparencia-y-acceso-la-informacion-publica "Transparencia y Acceso a Información Pública")[Atención y Servicios a la Ciudadanía](https://www.eafit.edu.co/atencion-y-servicios-la-ciudadania "Atención y Servicios a la Ciudadanía")[Participa](https://www.eafit.edu.co/participa "Participa")

###### **Transformemos juntos**

Hagamos posible que más jóvenes accedan a la Universidad.

[Dona aquí](https://www.eafit.edu.co/filantropia)

![Image 15: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 16: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 17: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 18: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 19: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 20: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 21: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 22: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Cerrar Menú

![Image 23](https://universidadeafit.widen.net/content/53343e70-85a1-4001-84c5-5353c221d25a/web/grados-2.jpg?crop=yes&k=c&w=1920&h=788&itok=-KmV3aiM)

# EAFIT Alumni

![Image 24](https://universidadeafit.widen.net/content/cfc92fb2-8eb0-48af-8c1a-42bbee9047ab/web/Banner-actualizar-datos-graduados.jpg?crop=yes&k=c&w=1920&h=788&itok=NeMg_zu0)

## **EAFIT Alumni**

![Image 25](https://universidadeafit.widen.net/content/70e130a4-fa25-4b16-b123-1687caffd9b2/web/posgrados-2025-1.jpg?crop=yes&k=c&w=1920&h=788&itok=AdWBikyO)

## **EAFIT Alumni**

*   [Inicio](https://www.eafit.edu.co/en)
*    Eafit Graduates 

​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​Un espacio p​ara los profesion​ales **eafitenses.**

Servicios, noticias, perfiles, eventos. Un lugar para tejer conexiones con la comunidad de graduados de EAFIT.

**Conoce el protocolo para el seguimiento y promoción de graduados​.**

## Oportunidades de talento

[Conoce más](https://www.eafit.edu.co/en/organizaciones/talento-eafit)

## Certificados académicos

[Conoce más](https://www.eafit.edu.co/en/registrars-office)

## Idiomas

[Conoce más](https://www.eafit.edu.co/idiomas)

## Eventos

[Conoce más](https://www.eafit.edu.co/calendario-eventos)

## Carnetización

[Conoce más](https://www.eafit.edu.co/carnetizacion)

## Convenios

[Conoce más](https://www.eafit.edu.co/bienestar-universitario/convenios/graduados)

## Filantropía

[Conoce más](https://www.eafit.edu.co/filantropia)

## On.going

[Conoce más](https://www.eafit.edu.co/ongoing)

## Tarjeta profesional

[Conoce más](https://www.eafit.edu.co/graduados/tarjeta-profesional)

![Image 26: Icono Scroll](https://universidadeafit.widen.net/content/4b28e37a-a8e7-4a2e-96a3-b879c1dea309/web/manito.gif?animate=true)

#### **Noticias**

![Image 27: Imagen Debate global con sello estudiantil ](https://universidadeafit.widen.net/content/f1103a4b-4ef9-4c46-9445-2b62c7d43a00/web/debate-global-con-sello-estudiantil.jpg?crop=yes&k=c&w=409&h=193&itok=JkRzgs7h)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

## Debate global con sello estudiantil

[Ver noticia](https://www.eafit.edu.co/en/node/60456 "Ver noticia")

April 7, 2026

![Image 28: Imagen De una inspiración a la competencia internacional](https://universidadeafit.widen.net/content/2f3d600d-36e7-45c1-81f8-c203e88ec782/web/de-una-inspiracion-la-competencia-internacional.jpg?crop=yes&k=c&w=409&h=193&itok=NgUwJ00O)

[Alcampus](https://www.eafit.edu.co/taxonomy/term/3121)

[Cuidado y bienestar](https://www.eafit.edu.co/taxonomy/term/1821)

## De una inspiración a la competencia internacional

[Ver noticia](https://www.eafit.edu.co/en/node/60446 "Ver noticia")

March 16, 2026

![Image 29: Imagen Un laboratorio vivo para aprender haciendo ](https://universidadeafit.widen.net/content/cf4f3315-032a-4a7e-a98d-942f0ba10cda/web/banner-un-laboratorio-vivo-para-aprender-haciendo.jpg?crop=yes&k=c&w=409&h=193&itok=Y_JcZf72)

[Educación y futuro](https://www.eafit.edu.co/taxonomy/term/1836)

## Un laboratorio vivo para aprender haciendo

[Ver noticia](https://www.eafit.edu.co/en/node/60441 "Ver noticia")

March 12, 2026

[Conoce más historias y noticias](https://www.eafit.edu.co/noticias/eafit-es-noticia)

Graduados 

¡Sigamos en contacto!

Actualiza tus datos y continuemos fortaleciendo nuestro vínculo como eafitenses

Los campos marcados con asterisco (*) son obligatorios.

Diligencia la información según lo que se indica en cada uno de los campos.

Antes de enviar la información autoriza el tratamiento de datos personales y acepta los términos y condiciones.

Graduados

Nombres*? 

Apellidos*? 

Tipo de documento*? 

Número de documento*? 

Teléfono móvil*? 

Dirección de correo electrónico personal más utilizado*? 

País de residencia*? 

Departamento de residencia? 

Ciudad o municipio de residencia*? 

Selecciona la opción que describe tu situación laboral actual*  

Nombre de la empresa*? 

Selecciona la opción que mejor describa el cargo que desempeña? 

De los siguientes servicios o iniciativas cuéntanos con cuál ó cuáles te gustaría vincularte*? 

¿A través de cuál o cuáles de los siguientes medios prefieres que nos comuniquemos contigo?*? 

- [x] 

[Acepto la política de manejo y tratamiento de datos*](https://www.eafit.edu.co/politica-de-tratamiento-y-proteccion-de-datos-personales)

- [x] 

[Acepto términos y condiciones](https://www.eafit.edu.co/terminos-condiciones)

![Image 30](https://www.eafit.edu.co/en/graduados)

![Image 31: Logo Universidad EAFIT en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/logo_EAFIT_blanco.svg)

[![Image 32: Ícono Facebook en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/fb.svg)](https://www.facebook.com/universidadeafit)[![Image 33: Ícono Instagram en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/ig.svg)](https://www.instagram.com/eafit/)[![Image 34: Ícono LinkedIn en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/in.svg)](https://co.linkedin.com/school/universidadeafit/)[![Image 35: Ícono YouTube en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/yt.svg)](https://www.youtube.com/user/ueafit)[![Image 36: Ícono X en color blanco](https://universidadeafit.widen.net/content/ae5f17aa-686c-4e1c-b6f7-1d0bf31f85c3/web/logo-x-color-blanco.png)](https://x.com/eafit)[![Image 37: Ícono Spotify en color blanco](https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg)](https://open.spotify.com/show/7CcuvStr0qJRBv0hU8cvwX?si=bc16896ca1934f86&nd=1&dlsi=83a38bb97a5945ba)[![Image 38: Ícono Tik Tok en color blanco](https://universidadeafit.widen.net/content/cbbcfc05-32cc-4e03-866e-b91705ff0675/web/logo-tik-tok-blanco.png)](https://www.tiktok.com/@eafit)

Estudia en EAFIT

*   [Our undergraduates](https://www.eafit.edu.co/en/pregrados)
*   [Our postgraduates programs](https://www.eafit.edu.co/en/posgrados)
*   [Other programs](https://www.eafit.edu.co/en/otros-programas)
*   [Learn about tuition and fees](https://www.eafit.edu.co/en/node/1171)
*   [Biblioteca](https://www.eafit.edu.co/en/node/31681)

Conéctate con EAFIT

*   [Transform with us](https://www.eafit.edu.co/en/node/43361)
*   [Ciencia, Tecnologia e Innovación](https://www.eafit.edu.co/en/ciencia-tecnologia-innovacion)
*   [Conexión con las organizaciones](https://www.eafit.edu.co/en/node/30186)
*   [Work with us](https://www.eafit.edu.co/en/node/45751)

Contáctanos

*   [Register a PQRSF](https://www.eafit.edu.co/en/node/45736)
*   [Visitor center](https://www.eafit.edu.co/en/node/45661)
*   [Transparency line](https://www.eafit.edu.co/en/node/42081)

Información de ley

*   [Legal Status](https://www.eafit.edu.co/en/node/42106)
*   [Regulations and statutes](https://www.eafit.edu.co/en/node/35101)
*   [Gender, diversity and inclusion](https://www.eafit.edu.co/en/node/38366)
*   [Legal notices and certificates](https://www.eafit.edu.co/en/node/42111)
*   [Update your information](https://www.eafit.edu.co/en/node/45776)
*   [Data protection policy](https://www.eafit.edu.co/en/node/15276)
*   [Terms of use](https://www.eafit.edu.co/en/node/42146)

[Map of the website](https://www.eafit.edu.co/en/graduados#mapa-del-sitio)

Institutional Accreditation until 2026.

Supervised by Ministry of Education.

[EAFIT Interactiva](https://www.eafit.edu.co/interactiva)[Epik](https://www.eafit.edu.co/en/epik)[Reserva de espacios](https://www.eafit.edu.co/reserva-espacios)[Correo](https://outlook.office.com/)[Más aplicaciones](https://www.eafit.edu.co/servicios-en-linea)

Our campuses

**Línea nacional:**01 8000 515 900

**WhatsApp:** (57) 310 899 2908

[EAFIT Medellin](https://www.eafit.edu.co/campus-eafit)

Carrera 49 N° 7 Sur-50

National line: 01 8000 515 900

Service line: (57) 604 2619500

[EAFIT Pereira](https://www.eafit.edu.co/eafit-pereira)

Carrera 19 #12-70 Megacentro Pinares

Service line: (57) 606 3214115, 606 3214119

[EAFIT Bogota](https://www.eafit.edu.co/eafit-bogota)

Carrera 15 #88-64 oficina 401

Service line: (57) 601 6114618

[EAFIT Llanogrande](https://www.eafit.edu.co/eafit-llanogrande)

Km 3.5 vía Don Diego – Rionegro
