Title: Liderazgo de Impacto

URL Source: https://www.eafit.edu.co/in-sight

Markdown Content:
![Image 1: Imagen Análisis del liderazgo posibilista en los líderes colombianos con mayor reputación](https://universidadeafit.widen.net/content/8599e90d-e023-4890-82fe-564c8598ddc9/web/Imagen-Posibilista.png?crop=yes&k=c&w=397&h=253&itok=FwDjc1tS)

Análisis del liderazgo posibilista en los líderes colombianos con mayor reputación

Autor: Maria Alejandra Gonzalez-Perez, Cristina Velez-Valencia, Camilo Andrés Solano Cobos, Alexa Barco López, Fernando Alexander Garzon-Lasso, Marco Antonio Londoño Zuluaga, Jesus Eduardo Briñez Vera

[Ver informe](https://universidadeafit.widencollective.com/assets/share/asset/gse9a4lfjb)

![Image 2: Imagen Unidades de Sostenibilidad Empresarial en Colombia 2026. Diagnóstico, tendencias y hoja de ruta para la gestión de Impacto ](https://universidadeafit.widen.net/content/e6bef528-49f6-42c4-84fc-d2a521525384/web/informe-sostenibilidad-empresarial-en-colombia-insight-2026.jpg?crop=yes&k=c&w=397&h=253&itok=6L6bdOMA)

Unidades de Sostenibilidad Empresarial en Colombia 2026. Diagnóstico, tendencias y hoja de ruta para la gestión de Impacto

Autores: Maria Alejandra Gonzalez-Perez, Franco Piza Rondón, Beatriz Vélez González, Camilo Solano Cobos

[Ver el informe](https://universidadeafit.widen.net/s/mb5nftppgf/informe-sostenibilidad-empresarial-en-colombia-insight-2026)

![Image 3: Imagen ¿Es el seguidorazgo un componente fundamental en la estructura social?](https://universidadeafit.widen.net/content/0321fd66-cb0a-4c31-98d2-265025931316/web/seguidorazgo-destacado.jpg?crop=yes&k=c&w=397&h=253&itok=lgZZDuQ6)

¿Es el seguidorazgo un componente fundamental en la estructura social?

Autor: Dario Monsalve Uribe

[Ver el informe](https://universidadeafit.widen.net/s/7jtdpzwqgk/informe-seguidorazgo)

![Image 4: Imagen 5 prioridades para los líderes de gestión humana](https://universidadeafit.widen.net/content/6ecf0fd7-3eb2-4b35-b246-6e9fdf932b94/web/imagen-varias-para-insight.jpeg?crop=yes&k=c&w=397&h=253&itok=CRMWoROa)

5 prioridades para los líderes de gestión humana

Autor: Área de Gestión Humana- EAFIT

[Ver el informe](https://universidadeafit.widen.net/s/vzlswqc87d/prioridades-para-lideres-de-gestion-humana)

![Image 5: Imagen 6 Tendencias para líderes en gestión de proyectos](https://universidadeafit.widen.net/content/80e3855f-4b19-473d-b053-1d646df1c881/web/imagen-documento-in-sight1.jpeg?crop=yes&k=c&w=397&h=253&itok=fGnq9qS4)

Tendencias digitales para conectar con la Generación Z

Autor: Daniela Bayter de Rio, Laura Montes Rosas

[Ver el informe](https://universidadeafit.widen.net/s/hmp6lmswfp/tendencias-digitales-para-conectar-con-la-generacion-z)

![Image 6: Imagen Tendencias de inteligencia artificial para líderes](https://universidadeafit.widen.net/content/6c5c381b-88b1-4f75-aeec-47d27ff55f5b/web/tendenciasdigitalesai.jpg?crop=yes&k=c&w=397&h=253&itok=2qwz-zyd)

Tendencias de inteligencia artificial para líderes

Autor: Francisco Vargas Bonilla, Juan David Correa Toro

[Ver el informe](https://universidadeafit.widen.net/s/bgz2rsmkxr/informe-de-tendencias-para-lideres)

![Image 7: Imagen 6 Tendencias para líderes en gestión de proyectos](https://universidadeafit.widen.net/content/80e3855f-4b19-473d-b053-1d646df1c881/web/imagen-documento-in-sight1.jpeg?crop=yes&k=c&w=397&h=253&itok=fGnq9qS4)

6 Tendencias para líderes en gestión de proyectos

Autor: Area de gestión de la información y de Riesgos- Escuela de Administración

[Ver el informe](https://universidadeafit.widen.net/s/2jmx65dxd9/6-tendencias-para-lideres-en-gestion-de-proyectos)

![Image 8: Imagen 5 prioridades para los líderes de Gestión Global en 2025](https://universidadeafit.widen.net/content/0d1a21e1-072a-4c7c-83df-a2eca4b12b24/web/imagen-liderazgo.jpeg?crop=yes&k=c&w=397&h=253&itok=kzOrZFW0)

Prioridades para líderes en el campo de pensamiento administrativo

Autor: Olga Lucia Garcés Uribe, Mónica Liliana Arcila Arango, Juan Carlos Jurado Jurado, Juan Fernando Jiménez Hurtado, Isabel Cristina Montes Gutiérrez, Juan Diego Suarez Gómez

[Ver el informe](https://universidadeafit.widen.net/view/pdf/mm3oqdvrgf/prioridades-para-lideres-en-el-campo-de-pensamiento-administrativo.pdf)

![Image 9: Imagen 5 prioridades para los líderes de Gestión Global en 2025](https://universidadeafit.widen.net/content/0d1a21e1-072a-4c7c-83df-a2eca4b12b24/web/imagen-liderazgo.jpeg?crop=yes&k=c&w=397&h=253&itok=kzOrZFW0)

5 tendencias para líderes de turismo

Autor: Beatriz Bedoya Velásquez, Sandra Echeverri Duque, Ana Lucía López Londoño

[Ver el informe](https://universidadeafit.widen.net/view/pdf/wcs8gztrbn/5-tendencias-para-lideres-de-turismo-2025.pdf?u=uqondw)

![Image 10: Imagen 5 prioridades para los líderes de Gestión Global en 2025](https://universidadeafit.widen.net/content/0d1a21e1-072a-4c7c-83df-a2eca4b12b24/web/imagen-liderazgo.jpeg?crop=yes&k=c&w=397&h=253&itok=kzOrZFW0)

3 tendencias para líderes en gestión de riesgos

Autor: Área de gestión de la información y de Riesgos- Escuela de Administración

[Ver el informe](https://universidadeafit.widen.net/s/bwtbnlhvrk/tendencias-para-lideres-en-gestion-de-riesgos)

![Image 11: Imagen 5 prioridades para los líderes de Gestión Global en 2025](https://universidadeafit.widen.net/content/0d1a21e1-072a-4c7c-83df-a2eca4b12b24/web/imagen-liderazgo.jpeg?crop=yes&k=c&w=397&h=253&itok=kzOrZFW0)

3 tendencias para líderes contables

Autor: Área de gestión de la información y de Riesgos - Escuela de Administración

[Ver el informe](https://universidadeafit.widen.net/s/jvdtktrshp/tendencias-para-lideres-contables)

![Image 12: Imagen 5 prioridades para los líderes de Gestión Global en 2025](https://universidadeafit.widen.net/content/0d1a21e1-072a-4c7c-83df-a2eca4b12b24/web/imagen-liderazgo.jpeg?crop=yes&k=c&w=397&h=253&itok=kzOrZFW0)

5 prioridades para los líderes de Gestión Global en 2025

Autor: Maria Alejandra Calle Saldarriaga, Juliana Correa Jaramillo, Luis Fernando Vargas Alzate, Andrés Velez Calle, Camilo Perez Restrepo

[Ver el informe](https://universidadeafit.widen.net/view/pdf/cbxpil4w2t/pdf-prioridades-para-los-lideres-de-gestion-global-2025.pdf)

![Image 13: Imagen Liderazgo empresarial de impacto](https://universidadeafit.widen.net/content/868bdf66-3e32-4aac-b9f5-63b6587d1d1c/web/Imagen-informe-liderazgo-empresarial.png?crop=yes&k=c&w=397&h=253&itok=LRlKoTGs)

Liderazgo empresarial de impacto

Autor: Camilo Andrés Solano Cobos, Alexa Barco López, Maria Alejandra Gonzalez-Perez, Cristina Velez-Valencia, Fernando Alexander Garzón-Lasso

[Ver el informe](https://universidadeafit.widen.net/s/dbgbsqdbhx/informe-liderazgo-empresarial-de-impacto)

![Image 14: Imagen ¿Cómo liderar ante una crisis de desacople comercial?](https://universidadeafit.widen.net/content/6fa421fb-28a7-441d-9bcf-7778691a2762/web/presentacion-desacople-comercial-insight-2025.jpg?crop=yes&k=c&w=397&h=253&itok=Sejmurlj)

¿Cómo liderar ante una crisis de desacople comercial?

Autor: Luis M. Bolivar

[Ver el informe](https://universidadeafit.widen.net/view/pdf/mq3dcdzewn/presentacion-desacople-comercial-insight-2025.pdf?u=uqondw)

![Image 15: Imagen Impacto efectivo: Estrategias de Comunicación Efectiva para Organizaciones Sociales](https://universidadeafit.widen.net/content/8cb752d5-5756-4b04-a36b-ef9b0aba3b5d/web/publicacion-impacto-efectivo-imagen.jpg?crop=yes&k=c&w=397&h=253&itok=pRYNa7iL)

Impacto efectivo: Estrategias de Comunicación Efectiva para Organizaciones Sociales

Autor: Erika Porras, Maria Alejandra Gonzalez-Perez, Salome Arango, Jesús Botero

[Ver el informe](https://universidadeafit.widen.net/view/pdf/nmkfreedtn/impacto-efectivo-estrategias-comunicacion-efectiva-para-organizaciones-sociales.pdf)

![Image 16: Imagen Equidad de género en empresas colombianas](https://universidadeafit.widen.net/content/590181cb-89ec-47e4-b3aa-4ab93b95983e/web/publicacion-equidad-de-genero-imagen.jpg?crop=yes&k=c&w=397&h=253&itok=0lOW9WMp)

Equidad de género en empresas colombianas

Autor: Alexa Barco López, Camilo Andrés Solano Cobos, Cristina Velez-Valencia, Irene Villegas Llano, Juan Camilo Ortiz

[Ver el informe](https://universidadeafit.widen.net/view/pdf/ughobx9pbg/equidad-genero-empesas-colombianas.pdf)

![Image 17: Imagen Diccionario Terminológico de Finanzas Sostenibles e Inversión Responsable](https://universidadeafit.widen.net/content/16f82bcb-71db-404d-952f-0ec0f6661d98/web/imagen-diccionario-terminologico.jpg?crop=yes&k=c&w=397&h=253&itok=jGTuHrQl)

Diccionario Terminológico de Finanzas Sostenibles e Inversión Responsable

Autor: Diana Piedrahita-Carvajal, Maria Alejandra Gonzalez-Perez, Camilo Andrés Solano Cobos, Daiana Mira Montoya, Pilar Alvarez, Santiago Bernal Nuñez

[Ver el informe](https://universidadeafit.widen.net/view/pdf/3mzqlligea/diccionario-terminologico-de-finanzas-sostenibles.pdf)

![Image 18: Imagen El Imperativo Sostenible: Transformando la Agricultura Latinoamericana antes del punto de no retorno](https://universidadeafit.widen.net/content/c75bc6b6-963e-4fba-9ec5-bd8c3cc2f649/web/imagen-lider.jpeg?crop=yes&k=c&w=397&h=253&itok=qzoRJKUJ)

El Imperativo Sostenible: Transformando la Agricultura Latinoamericana antes del punto de no retorno

Autor: Maria Alejandra Perez-Gonzalez

[Ver el informe](https://universidadeafit.widen.net/view/pdf/tzj3fwd1kf/presentacion-agribusines-insight.pdf?u=uqondw)

![Image 19: Imagen 5 Puntos para el pensamiento de futuros en liderazgo organizacional y gerencia innovadora](https://universidadeafit.widen.net/content/e12fa250-790b-4c13-9f9c-0b64faa495f4/web/5-puntos-para-el-pensamiento-de-futuro.jpg?crop=yes&k=c&w=397&h=253&itok=wpGmGQ7o)

5 Puntos para el pensamiento de futuros en liderazgo organizacional y gerencia innovadora

Autor: Daniela Valencia Gonzalez, Karen Natalia Villamil Paez, Laura Rojas De Francisco, Tatiana Ortiz Pradilla

[Ver informe](https://universidadeafit.widen.net/view/pdf/1sivrzdbsd/5-puntos-para-el-pensamiento-de-futuro-insight-2025.pdf?u=uqondw)
