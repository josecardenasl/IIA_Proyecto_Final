Title: sfy.svg

URL Source: https://www.eafit.edu.co/sites/default/files/2024-07/sfy.svg

Published Time: Wed, 31 Jul 2024 02:38:26 GMT

Markdown Content:
# sfy.svg

A 52x48 small image, likely a logo, icon or avatar
